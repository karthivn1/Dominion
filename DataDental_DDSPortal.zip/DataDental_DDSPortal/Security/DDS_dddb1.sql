﻿CREATE USER [DDS\dddb1] FOR LOGIN [DDS\cognizantdb1];

