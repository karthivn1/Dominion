﻿ALTER ROLE [db_owner] ADD MEMBER [DDS\dddb1];

