﻿CREATE TYPE [dbo].[InviteCodes] AS TABLE (
    [Id]         INT           NULL,
    [invitecode] VARCHAR (20)  NULL,
    [group_zip]  VARCHAR (10)  NULL,
    [email]      VARCHAR (250) NULL,
    [last_name]  VARCHAR (40)  NULL,
    [con_type]   VARCHAR (2)   NULL);

