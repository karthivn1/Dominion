﻿CREATE TYPE [dbo].[GroupUserDetailsMapping] AS TABLE (
    [username] VARCHAR (20) NULL,
    [groupid]  INT          NULL,
    [status]   VARCHAR (10) NULL,
    [isremove] BIT          NULL);

