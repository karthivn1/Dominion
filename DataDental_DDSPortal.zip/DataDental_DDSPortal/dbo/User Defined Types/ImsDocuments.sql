﻿CREATE TYPE [dbo].[ImsDocuments] AS TABLE (
    [doc_id]     INT            NULL,
    [doc_type]   NVARCHAR (100) NULL,
    [doc_date]   DATE           NULL,
    [ref_id]     INT            NULL,
    [first_name] NVARCHAR (100) NULL,
    [last_name]  NVARCHAR (100) NULL);

