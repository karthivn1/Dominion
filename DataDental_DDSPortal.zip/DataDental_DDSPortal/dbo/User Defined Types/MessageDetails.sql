﻿CREATE TYPE [dbo].[MessageDetails] AS TABLE (
    [message_id]          INT            NULL,
    [message]             VARCHAR (MAX)  NULL,
    [message_subject]     VARCHAR (1500) NULL,
    [parentid]            INT            NULL,
    [message_type_id]     INT            NULL,
    [created_by]          INT            NULL,
    [created_date]        DATETIME       NULL,
    [from_address]        VARCHAR (300)  NULL,
    [message_receiver_id] INT            NULL,
    [received_date]       DATETIME       NULL,
    [is_read]             BIT            NULL,
    [is_new]              BIT            NULL,
    [is_delete]           BIT            NULL,
    [is_reply]            BIT            NULL);

