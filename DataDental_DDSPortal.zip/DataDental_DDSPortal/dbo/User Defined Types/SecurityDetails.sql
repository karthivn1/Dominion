﻿CREATE TYPE [dbo].[SecurityDetails] AS TABLE (
    [security_question_id] INT           NOT NULL,
    [answer]               VARCHAR (MAX) NOT NULL,
    [question_order]       INT           NOT NULL,
    [user_id]              INT           NOT NULL);

