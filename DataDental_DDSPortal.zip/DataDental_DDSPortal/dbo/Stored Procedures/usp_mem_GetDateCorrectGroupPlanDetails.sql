﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <26-10-2016>
-- Description:	<This sp gets the Details for Date correct Tab for Group/Plan ,Rate and Facility  by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetDateCorrectGroupPlanDetails]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;

	--Member OED date
	SELECT member.oed FROM member WHERE member.member_id = member.family_id AND member.member_id=@memberId
	
	--List Of Group/Plan
	SELECT  rlmbgrpl.mb_gr_pl_id AS MemGroupPlanId,
        rlmbgrpl.member_id , 
        rlmbgrpl.plan_id AS PlnID,    
		rlmbgrpl.group_id AS GrpID ,     
		rlmbgrpl.sign_flag ,    
		rlmbgrpl.cobra_flag ,   
        rlmbgrpl.eff_gr_pl AS EffGrPln,
		rlmbgrpl.exp_gr_pl AS ExpGrPln,
		rlmbgrpl.eff_gr_pl AS OldEffGrPln,
		rlmbgrpl.exp_gr_pl AS OldExpGrPln,    
		rlmbgrpl.h_datetime AS "Date",        
		rlmbgrpl.h_msi,        
		rlmbgrpl.h_action ,      
		rlmbgrpl.h_user AS "User",      
		grp.group_name AS GrpName,     
		grp.group_oed  AS GrpOed,     
		grp.group_type AS GrpType,      
		pln.plan_name AS PlnName

		FROM rlmbgrpl 
		INNER JOIN [group] grp ON grp.group_id = rlmbgrpl.group_id          
		INNER JOIN [plan] pln ON pln.plan_id = rlmbgrpl.plan_id

	WHERE rlmbgrpl.member_id = @memberId

	--List of Rate
	SELECT  rlmbrt.rlmbrt_id AS relMemberRateId,   
        rlmbrt.mb_gr_pl_id AS MemGroupPlanId,  
        rlmbrt.rate_code AS RateCode,
		pl_rat.rate_short_desc AS RateDescription,
		rlmbrt.eff_rt_date AS EffDate,    
		rlmbrt.exp_rt_date AS ExpDate,
		rlmbrt.eff_rt_date AS OldEffDate,    
		rlmbrt.exp_rt_date AS OldExpDate, 
        rlmbrt.action_code AS ActionCode,   
        rlmbrt.h_datetime AS "Date",     
		rlmbrt.h_msi ,       
		rlmbrt.h_action ,       
		rlmbrt.h_user AS "User",      
		rlmbgrpl.member_id ,
        member.family_id 

		FROM  rlmbgrpl 
		INNER JOIN rlmbrt ON rlmbgrpl.mb_gr_pl_id = rlmbrt.mb_gr_pl_id
		INNER JOIN pl_rat ON rlmbrt.rate_code=pl_rat.rate_code
        INNER JOIN member ON rlmbgrpl.member_id = member.family_id AND member.member_id=member.family_id
			 
	WHERE   member.family_id = @memberId
	  --(( member.family_id =  ) and       
	  --( member.member_id = member.family_id ) )

	--List Of Facility
	SELECT  rlplfc.rlplfc_id AS RelPlanFacilityId,  
        rlplfc.mb_gr_pl_id AS MemGroupPlanId,      
		rlplfc.member_id AS MemberId,         
		rlplfc.eff_date AS EffDate,        
		rlplfc.exp_date AS ExpDate,
		rlplfc.eff_date AS OldEffDate,        
		rlplfc.exp_date AS OldExpDate,
		rlplfc.action_code ,    
		rlplfc.h_datetime AS "Date",   
        rlplfc.h_msi ,         
		rlplfc.h_action ,         
		rlplfc.h_user AS "User",          
		rlplfc.facility_id AS FCID,       
		facility.fc_name AS FCName,          
		member.first_name AS Name,           
		member.member_code ,        
		member.family_id ,       
		member.member_ssn AS SSN

		FROM rlplfc 
		INNER JOIN member ON  rlplfc.member_id = member.member_id
		INNER JOIN facility ON rlplfc.facility_id=facility.fc_id
		  
	WHERE member.family_id=@memberId
	--(type variables long i_memberid, i_dw
	--date i_oeddate
	--long i_mbgrplid
	--date i_gp_eff_date
	--Transaction DBTrans
	--w_passwd w_pass
	--w_vwactlog w_mvwactlog
	--w_mbr_browse w_browse_win) and
	--( ( member.family_id = :family_id ) )

SET NOCOUNT OFF;
END