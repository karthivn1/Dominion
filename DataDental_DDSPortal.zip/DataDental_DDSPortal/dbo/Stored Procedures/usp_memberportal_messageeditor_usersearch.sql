﻿
-- =============================================
-- Author:		<Rajthilak>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_messageeditor_usersearch] 
	-- Add the parameters for the stored procedure here
	(
		@lastname as Varchar(25)= NULL,
		@firstname as Varchar(25)=NULL,
		@username as Varchar(20)=NULL,
		@familyId as int,
		@email as Varchar(350)=NULL,
		@role as int =null
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT DISTINCT
			userdetails.[user_name] as UserName, 
			userdetails.last_name as LastName,
			userdetails.first_name as FirstName,
			userdetails.date_of_birth as DOB,
			userdetails.member_id as MemberID,
			'Test' as GroupName,
			tbl_status.status as [Status],
			tbl_rolemaster.role_name as RoleName,
			userdetails.role_id as RoleId
			FROM dbo.member_user_details as userdetails
			inner join user_status_master as tbl_status on tbl_status.status_id =userdetails.status_id
			inner join role_master  as tbl_rolemaster on   userdetails.role_id  =tbl_rolemaster.role_id 
			WHERE (userdetails.[user_name]=@username) or (userdetails.last_name = @lastname) or (userdetails.first_name=@firstname)
			 or  (userdetails.email =@email) or (userdetails.role_id=@role)

 SET NOCOUNT OFF
END