﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <23-11-2016>
-- Description:	<This sp gets the Member Designation value by passing member design id>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberDesignationValue]
(
	@designId INT
)
AS
BEGIN
SET NOCOUNT ON;

	SELECT mb_desig_det.desig_det_id AS MemberDesignValueId,
		mb_desig_det.dd_desig_id,
		mb_desig_det.desig_value AS Designation,
		mb_desig_det.eff_date AS EffDate,
		mb_desig_det.exp_date AS ExpDate,
		mb_desig_det.h_user AS "User",
		mb_desig_det.h_datetime AS "Date"
	FROM mb_desig
	INNER JOIN mb_desig_det ON mb_desig.dd_desig_id=mb_desig_det.dd_desig_id
	WHERE mb_desig.dd_desig_id=@designId

SET NOCOUNT OFF
END