﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <18-10-2016>
-- Description:	<This sp gets the Address for member by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetAddressForMember]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;	
  
  SELECT 
		--address.address_id AS,   
         --address.subsys_code AS,   
         --address.sys_rec_id AS,
		 address.addr_type AS  Type,
         typeAddrTy.descr AS TypeDescription,   
         address.addr1 AS Addr1,   
         address.addr2 AS Addr2,   
         address.city AS City,   
         address.country AS Country,   
         address.county AS County,   
         address.state AS State,   
         address.zip AS Zip,   
         --address.mail AS,   
         --address.history_rec AS,   
         --address.geo_x AS,   
         --address.geo_y AS,   
         --mbr_phone.mbr_phone_id AS,   
         --mbr_phone.address_id AS,   
         mbr_phone.home_phone AS Home,   
         mbr_phone.home_ext AS HomeX,   
         mbr_phone.work_phone AS Work,   
         mbr_phone.work_ext AS WorkX,   
         mbr_phone.fax AS Fax,   
         mbr_phone.email AS Email
		   
    FROM [address]
	LEFT JOIN mbr_phone ON address.address_id = mbr_phone.address_id   
    LEFT JOIN member  ON member.member_id = address.sys_rec_id
	LEFT JOIN typ_table typeAddrTy ON typeAddrTy.subsys_code='AM' AND typeAddrTy.tab_name='address' AND typeAddrTy.code=address.addr_type	
    WHERE address.subsys_code = 'MB' AND member.family_id = @memberId

SET NOCOUNT OFF
END