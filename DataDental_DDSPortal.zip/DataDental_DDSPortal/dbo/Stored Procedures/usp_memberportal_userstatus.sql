﻿CREATE Procedure [dbo].[usp_memberportal_userstatus](
@username varchar(max))
AS
Begin
SET NOCOUNT ON

Declare @userid int;
Declare @DOB Datetime;

If exists (select user_id from member_user_details where UPPER(user_name)=UPPER(@username) and status_id=1)
Begin
   select 'Success' as StatusMsg
End
Else
Begin

    If not exists(select user_id from member_user_details where UPPER(user_name)=UPPER(@username))
	 Begin 
	 select 'Invalid Username' as StatusMsg
	 End
	 else
	 If  exists(select user_id from member_user_details where UPPER(user_name)=UPPER(@username) and status_id <> 1)
	 Begin 
	  If  exists(select user_id from member_user_details where UPPER(user_name)=UPPER(@username) and status_id =3)
	  Begin
	 select @userid=user_id, @DOB =date_of_birth from member_user_details where UPPER(user_name)=UPPER(@username) 
	 select 'Thank you for your request to change your password. Your account is locked.  Please contact our Member Services Department at 888-518-5338 or dds_techsupport@dominionnational.com  to have your account unlocked.' as StatusMsg
	 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userid,9,1001,0,convert(date,getdate()));
	 end
	 else
	  If  exists(select user_id from member_user_details where UPPER(user_name)=UPPER(@username) and status_id =2)
	  Begin
	 select @userid=user_id, @DOB =date_of_birth from member_user_details where UPPER(user_name)=UPPER(@username)
	 select 'Thank you for your request to change your password. Your account is deactivated.  Please contact our Member Services Department at 888-518-5338 or dds_techsupport@dominionnational.com  to have your account activate.' as StatusMsg
	 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userid,9,1001,0,convert(date,getdate()));
	 end
	 End
End

SET NOCOUNT OFF
END