﻿
-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <14-12-2016>
-- Description:	<This SP is used to Save the Rate Update Details >
-- =============================================
 
CREATE PROCEDURE [dbo].[usp_mem_SaveRateUpdateDetails]
(
@memberId INT=NULL,
@memberGroupPlanId INT=NULL,
@rateCode VARCHAR(100)=NULL,
@effDate DATETIME=NULL,
@hUser VARCHAR(100)=NULL,
@activityMasterId INT=NULL,
@subsystemCode	VARCHAR(2)=NULL,
@reasonCode  VARCHAR(2)=NULL

)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRAN 
	BEGIN TRY
DECLARE @hmsi INT

	UPDATE rlmbrt set exp_rt_date=@effDate where mb_gr_pl_id=@memberGroupPlanId AND exp_rt_date IS NULL

	SELECT @hmsi=msi+1 from sysdatetime

    INSERT INTO rlmbrt(mb_gr_pl_id,rate_code, eff_rt_date,action_code,h_datetime, h_msi,h_action,h_user )
    SELECT TOP 1 mb_gr_pl_id,@rateCode,@effDate,action_code, getdate(), @hmsi,h_action, @hUser
	FROM rlmbrt where mb_gr_pl_id=@memberGroupPlanId ORDER BY h_datetime DESC ;
    
    UPDATE sysdatetime set msi=msi+1 
	

 BEGIN 
 IF @activityMasterId>0 
 BEGIN
		EXEC usp_SaveActivity @subsystemCode,@memberId,@reasonCode,@activityMasterId,@hUser
	END
	END
	COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
   	SET NOCOUNT OFF
END