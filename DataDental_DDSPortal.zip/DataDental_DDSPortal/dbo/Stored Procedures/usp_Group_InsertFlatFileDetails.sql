﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_Group_InsertFlatFileDetails
-- =============================================
CREATE PROCEDURE [dbo].[usp_Group_InsertFlatFileDetails]	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempEmail') IS NOT NULL
    DROP TABLE #tempEmail

IF OBJECT_ID('tempdb..#FindDuplicate') IS NOT NULL
    DROP TABLE 	#FindDuplicate

DECLARE @ctDate DATETIME=GETDATE();
DECLARE @user varchar(10)='invitecode'

DECLARE @newEmail AS Table
(
id int identity(1,1),
email varchar(250)
)

INSERT INTO @newEmail(email) 
SELECT DISTINCT c.email
	FROM contact_sec c
	WHERE c.subsys_code='GP' AND c.addr_type='L'
	AND LEN(c.email)>0
EXCEPT
Select DISTINCT f.email COLLATE SQL_Latin1_General_CP1_CS_AS
	From flatfile_details f


--drop table #temp1

SELECT DISTINCT c.lname,a.zip,c.email,c.con_type
	INTO #tempEmail
	FROM contact_sec c (nolock)
	JOIN @newEmail n ON n.email=c.email 
	JOIN address_sec a (nolock) ON c.subsys_code=a.subsys_code AND c.sys_rec_id=a.sys_rec_id 
	AND c.addr_type=a.addr_type
	WHERE c.subsys_code='GP' 
	AND c.addr_type='L' 
	AND LEN(c.lname)>0 AND LEN(a.zip)>0
	AND c.con_type NOT IN ('GC','AM')
	order by c.email

SELECT ROW_NUMBER() OVER(PARTITION BY email ORDER BY email) AS Id,*
	INTO #FindDuplicate
	From #tempEmail

INSERT INTO flatfile_details(last_name,
group_zip,
email,
con_type,
created_date,
h_user)
SELECT t.lname,t.zip,t.email,t.con_type,@ctDate AS created_date,@user AS h_user
	From #FindDuplicate t
	WHERE t.Id=1

END