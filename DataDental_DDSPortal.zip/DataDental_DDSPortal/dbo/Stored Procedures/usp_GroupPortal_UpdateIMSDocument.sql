﻿CREATE PROCEDURE [dbo].[usp_GroupPortal_UpdateIMSDocument]
(
@groupid int,
@docid int
)
AS 
BEGIN 
SET NOCOUNT ON 

Update group_ims_doc set isNew=0 where doc_id=@docid and group_id=@groupid
select 'success'

SET NOCOUNT OFF 
END