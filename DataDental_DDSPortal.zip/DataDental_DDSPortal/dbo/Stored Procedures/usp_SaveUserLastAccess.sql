﻿CREATE procedure [dbo].[usp_SaveUserLastAccess]
(@username varchar(max),
 @groupid varchar(max),
 @planid varchar(max)
)
 AS
 Declare @userid int;
 Begin
 If exists ( select user_id from group_user_details  where user_name =@username)
 Begin 
 set @userid=(select user_id from group_user_details  where user_name =@username)
 update group_user_details set group_id=@groupid , plan_id=@planid where user_id =@userid 
 
 select distinct grp.group_id as GroupID,pln.plan_id as PlanID,RTRIM(grp.group_name) as GroupName,RTRIM(pln.plan_name) as PlanName,gpdet.elig_opt as MidmonthEligibility,grp.group_type as GroupType,LTRIM(RTRIM(tbl_address.zip)) AS Zip 
 from group_sec grp 
 inner join rel_gppl_sec gpdet ON grp.group_id = gpdet.group_id
 inner join plan_sec  pln on pln.plan_id = gpdet.plan_id 
 Left outer JOIN [address_sec] tbl_address  ON grp.group_id = tbl_address.sys_rec_id and  tbl_address.subsys_code = 'GP' and  tbl_address.addr_type ='L' 
 where grp.group_id=@groupid and pln.plan_id=@planid

 
 End 
 End