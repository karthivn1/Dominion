﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateCustomerProfile]
@GroupId INT,
@CustomerProfile nvarchar(100),
@PaymentProfile nvarchar(max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @ctDate DATETIME=GETDATE();

IF EXISTS(SELECT a.group_id
	FROM authorize_net_profile a
	WHERE a.group_id=@GroupId AND a.customer_profile=@CustomerProfile)
	BEGIN
	--Select *
		UPDATE a SET a.payment_profile=@PaymentProfile,a.modified_date=@ctDate
			FROM authorize_net_profile a
			WHERE a.group_id=@GroupId AND a.customer_profile=@CustomerProfile
	END
	ELSE IF EXISTS(SELECT a.group_id
	FROM authorize_net_profile a
	WHERE a.customer_profile=@CustomerProfile)
	BEGIN
		UPDATE a SET a.payment_profile=@PaymentProfile,a.modified_date=@ctDate
			FROM authorize_net_profile a
			WHERE a.group_id=@GroupId 
	END
	ELSE IF EXISTS(SELECT a.group_id
	FROM authorize_net_profile a
	WHERE a.group_id=@GroupId AND a.group_id>0)
	BEGIN
		UPDATE a SET a.customer_profile=@CustomerProfile,a.payment_profile=@PaymentProfile,a.modified_date=@ctDate
			FROM authorize_net_profile a
			WHERE a.group_id=@GroupId 
	END
	ELSE
	BEGIN
		INSERT INTO authorize_net_profile(group_id,customer_profile,payment_profile,created_date,modified_date)
		VALUES(@GroupId,@CustomerProfile,@PaymentProfile,@ctDate,@ctDate)
	END

END