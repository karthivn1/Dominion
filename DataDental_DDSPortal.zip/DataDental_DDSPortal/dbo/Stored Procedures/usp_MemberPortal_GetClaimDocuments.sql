﻿CREATE PROCEDURE [dbo].[usp_MemberPortal_GetClaimDocuments]
(
@MessageReceiverID varchar(25)
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @ClaimDocuments TABLE
(
id INT IDENTITY(1,1),
FromAddress VARCHAR(MAX) ,
MessageSubject VARCHAR(max),
CreatedDate DATETIME NULL,
IsNew BIT NULL,
IsRead BIT NULL,
IsReply BIT NULL,
IsDeleted BIT NULL,
MessageID INT,
Message VARCHAR(MAX),
ParentID INT,
MessageTypeID INT,
ClaimCount INT NULL,
FromClaimCount VARCHAR(50)
)

DECLARE @ClaimDocumentDetails TABLE
(
id INT IDENTITY(1,1),
FromAddress VARCHAR(MAX) ,
MessageSubject VARCHAR(max),
CreatedDate DATETIME NULL,
IsNew BIT NULL,
IsRead BIT NULL,
IsReply BIT NULL,
IsDeleted BIT NULL,
MessageID INT,
Message VARCHAR(MAX),
ParentID INT,
MessageTypeID INT,
ClaimCount INT NULL,
FromClaimCount VARCHAR(50)
)

DECLARE @ClaimDocumentsCount TABLE
(
id INT IDENTITY(1,1),
ParentID INT,
ClaimCount INT NULL
)

declare @userId varchar(20)
select @userId= user_id from member_user_details where user_name=@MessageReceiverID

INSERT INTO @ClaimDocumentDetails(FromAddress ,MessageSubject ,CreatedDate ,IsNew ,IsRead ,IsReply,IsDeleted,MessageID ,Message,ParentID,MessageTypeID)

SELECT msg.from_address,msg.message_subject,msg.created_date,md.is_new,md.is_read,md.is_reply,md.is_delete,msg.message_id,msg.message,msg.parentid,msg.message_type_id
FROM member_message msg join member_message_detail md on  msg.parentid=md.message_id --msg.message_id=md.message_id and
WHERE md.is_delete=0 and md.message_receiver_id=@userId

INSERT INTO @ClaimDocuments(FromAddress ,MessageSubject ,CreatedDate ,IsNew ,IsRead ,IsReply,IsDeleted,MessageID ,Message,ParentID,MessageTypeID)

SELECT msg.from_address,msg.message_subject,msg.created_date,md.is_new,md.is_read,md.is_reply,md.is_delete,msg.message_id,msg.message,msg.parentid,msg.message_type_id
FROM member_message msg join member_message_detail md on msg.parentid=md.message_id
WHERE md.is_delete=0 and md.message_receiver_id=@userId

INSERT INTO @ClaimDocumentsCount(ParentID,ClaimCount)
SELECT ParentID,count(*) FROM @ClaimDocuments group by ParentID

UPDATE CD SET CD.ClaimCount=CDC.ClaimCount FROM @ClaimDocuments CD JOIN @ClaimDocumentsCount CDC ON 
CD.ParentID=CDC.ParentID

UPDATE @ClaimDocuments SET ClaimCount=null WHERE  ClaimCount=1

UPDATE @ClaimDocuments SET FromClaimCount = CASE  
                        WHEN ClaimCount IS NULL THEN FromAddress                        
                        ELSE FromAddress+', me('+CONVERT(varchar(50), ClaimCount)+')'
                    END 



UPDATE CD SET CD.ClaimCount=CDC.ClaimCount FROM @ClaimDocumentDetails CD JOIN @ClaimDocumentsCount CDC ON 
CD.ParentID=CDC.ParentID

UPDATE @ClaimDocumentDetails SET ClaimCount=null WHERE  ClaimCount=1

UPDATE @ClaimDocumentDetails SET FromClaimCount = CASE  
                        WHEN ClaimCount IS NULL THEN FromAddress                        
                        ELSE FromAddress+', me('+CONVERT(varchar(50), ClaimCount)+')'
                    END 

SELECT * FROM @ClaimDocumentDetails

SELECT * FROM @ClaimDocuments

SET NOCOUNT OFF 
END