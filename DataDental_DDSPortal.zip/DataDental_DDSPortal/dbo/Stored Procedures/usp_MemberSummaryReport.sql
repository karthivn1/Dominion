﻿
CREATE PROCEDURE [dbo].[usp_MemberSummaryReport]
AS 
BEGIN 
SET NOCOUNT ON 



select mud.user_name as UserId, iif((mud.role_id=2 or mud.role_id=3),'N/A',case(isnull(mud.email_notification,'')) when 1 then 'On' else 'Off' end) as EmailNotification, iif((mud.role_id=2 or mud.role_id=3),'N/A',isnull(mbr.paperless,'N')) as PaperlessStatement from member_user_details mud 
left join member_sec mbr on mud.member_id=mbr.member_id
inner join role_master rol on rol.role_id=mud.role_id


SET NOCOUNT OFF 
END