﻿

-- =============================================
-- Author:		Harishraj.R
-- Create date:  22/02/2017
-- Description:	 TO Update THE MEMBER by MEMBER ID 
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_UpdateMemberDetails]
	-- Add the parameters for the stored procedure here
	(@memberId            INT,
	 @alt_id              VARCHAR (20) =NULL, 
	 @member_code         INT, 
	 @first_name          VARCHAR (15), 
	 @middle_init         VARCHAR (1), 
	 @last_name           VARCHAR (15), 
	 @date_of_birth       DATE =NULL,
	 @member_ssn          VARCHAR (11),
	 @student_flag        VARCHAR (1),       
	 @disable_flag        VARCHAR (1),
	 @action_code         VARCHAR (2),
	 @h_datetime          DATE =NULL,  
	 @h_action            VARCHAR (2), 
	 @h_user              VARCHAR (10), 
	 @hire_date           DATE =NULL,
	 @new_ssn             VARCHAR (11), 
	 @source_id           VARCHAR (20),
	 @ext_id_type         VARCHAR (2),
	 @paperless           VARCHAR (1),	 
	 @addr1              VARCHAR (30) = NULL,
	 @addr2              VARCHAR (30) = NULL, 
	 @city               VARCHAR (15) = NULL,
	 @country            VARCHAR (30) = NULL,
	 @county             VARCHAR (30) = NULL,
	 @state              VARCHAR (30) = NULL,
	 @zip                VARCHAR (15) = NULL,
	 @undeliverable      VARCHAR(2)=NULL,
	 @home_phone         VARCHAR (10) = NULL,
     @home_ext           VARCHAR (5) = NULL,
     @work_phone         VARCHAR (10) = NULL,
     @work_ext           VARCHAR (5) = NULL,
     @fax                VARCHAR (14) = NULL,
     @email              VARCHAR (30) = NULL)
AS
BEGIN   
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @addressid INT;
	BEGIN TRAN 
		BEGIN TRY 
    -- Update statements for procedure here	 
	    
	--Update THE SUBSCRIBER 
	UPDATE member SET alt_id=@alt_id , 
					   member_code=@member_code , 
					   first_name=@first_name , 
					   middle_init=@middle_init,
					   last_name=@last_name,
					   date_of_birth=@date_of_birth, 
					   member_ssn=@member_ssn,
					   student_flag=@student_flag,
					   disable_flag=@disable_flag,
					   action_code=@action_code,
					   h_datetime=@h_datetime,
					   h_action=@h_action, 
					h_user=@h_user,
					hire_date=@hire_date,
					new_ssn=@new_ssn,
					source_id=@source_id,
					ext_id_type=@ext_id_type,
					paperless=@paperless 
					  WHERE member_id=@memberId;

UPDATE [address] SET
		  addr1=@addr1,
		  addr2=@addr2,
		  city=@city,
		  country=@country,
		  county=@county,
		  state=@state,
		  zip=@zip  WHERE sys_rec_id=@memberId	;

		 --SET @addressid = (SELECT address_id FROM [address] WHERE sys_rec_id=@memberId);

UPDATE mbr_phone SET
		  home_phone= @home_phone,
		  home_ext=@home_ext,
		  work_phone=@work_phone,
		  work_ext=@work_ext,
		  fax=@fax,
		  email=@email 
		  WHERE address_id   IN (SELECT address_id FROM [address] WHERE sys_rec_id=@memberId);

		

	COMMIT TRAN 
	END TRY 

	BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState ) 

	END CATCH 
END