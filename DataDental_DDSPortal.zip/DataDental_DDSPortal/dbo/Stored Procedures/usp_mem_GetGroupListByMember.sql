﻿
-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <06-10-2016>
-- Description:	<This sp gets the List of Groups for Member by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetGroupListByMember] --657306
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;
	DECLARE @groupId INT
	--DECLARE @MemGroupPlanId INT

	--List Of Group 
	SELECT DISTINCT tblGroup.group_id AS GroupID,
		tblGroup.bill_type AS BillType,--Modified by Selvakumar K
		 rlMemGroupPlan.mb_gr_pl_id AS MemGroupPlanID, 
         tblGroup.group_name AS GroupName,   
         LTRIM(RTRIM((typeGr.descr))) AS GroupType, 
		 LTRIM(RTRIM(tblGroup.group_type)) As GroupTypeCode,  
         tblGroup.group_parent AS ParentGroup            ,
         tblGroup.oc_id AS OCID,
		 rlMemGroupPlan.eff_gr_pl AS GroupEffectiveDate,
		 rlMemGroupPlan.exp_gr_pl AS GroupExpireDate,
		 groupStatus.group_status AS StatusCode,		 
		 LTRIM(RTRIM((typeSt.descr))) AS "Status",
         tblGroup.vision_cnt AS 'VisionCount'  ,
		 tblGroup.dental_cnt As 'DentalCount',
		 groupStatus.eff_date,
		 groupStatus.exp_date
		 ,ROW_NUMBER() OVER(ORDER BY rlMemGroupPlan.exp_gr_pl ASC) AS RowNumber 
    INTO #MemberGroupTemp
    FROM [group] tblGroup 
		INNER JOIN  rlmbgrpl rlMemGroupPlan ON rlMemGroupPlan.group_id=tblGroup.group_id
		INNER JOIN group_status groupStatus ON groupStatus.group_id=tblGroup.group_id		
		LEFT JOIN oper_company opCompany ON opCompany.oc_id=tblGroup.oc_id
		LEFT JOIN typ_table typeGr ON typeGr.subsys_code='GP' AND typeGr.tab_name='group_type' AND typeGr.code=tblGroup.group_type          
		LEFT JOIN typ_table typeSt ON typeSt.subsys_code='GP' AND typeSt.tab_name='group_status' AND typeSt.code= groupStatus.group_status
	WHERE rlMemGroupPlan.member_id=@memberId AND groupStatus.exp_date IS NULL
		and rlMemGroupPlan.mb_gr_pl_id=(CASE WHEN 
		(SELECT MAX(mb_gr_pl_id) from rlmbgrpl rl2 WHERE rlMemGroupPlan.group_id = rl2.group_id AND rlMemGroupPlan.member_id = rl2.member_id AND rl2.exp_gr_pl IS NULL) 
		IS NOT NULL THEN 
		(SELECT MAX(mb_gr_pl_id) from rlmbgrpl rl2 WHERE rlMemGroupPlan.group_id = rl2.group_id AND rlMemGroupPlan.member_id = rl2.member_id AND rl2.exp_gr_pl IS NULL) ELSE 
		(SELECT MAX(mb_gr_pl_id) from rlmbgrpl rl2 WHERE rlMemGroupPlan.group_id = rl2.group_id AND rlMemGroupPlan.member_id = rl2.member_id)END)
	

	SELECT * FROM #MemberGroupTemp ORDER BY RowNumber ASC
	
	SET @groupId= (SELECT GroupID FROM #MemberGroupTemp WHERE RowNumber=1)		

	EXEC usp_mem_GetPlanListByMemberAndGroup @memberId,@groupId
	
	/*
	--List Of Plan
	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.plan_dsp_name AS PlanName,
		rlMebGroupPlan.sub_in_plan AS Sip,
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		(typeMa.descr) AS PlanAction,
		--rlMebGroupPlan.action_code AS PlanAction,
		rlMebGroupPlan.mb_gr_pl_id AS MemGrpPlnId,
		rlMebRate.rate_code AS RC,
		rlMebRate.eff_rt_date AS RateEffectiv,
		rlMebRate.exp_rt_date AS RateExpired,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName
	from [plan] tblPlan
	LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	LEFT JOIN typ_table typeMa ON typeMa.subsys_code='MB' AND typeMa.tab_name='action_code' AND typeMa.code=rlMebGroupPlan.action_code	
	WHERE rlMebGroupPlan.group_id=@groupId AND rlMebGroupPlan.member_id=@memberId AND rlMebRate.exp_rt_date IS NULL
	ORDER BY rlMebGroupPlan.eff_gr_pl ASC ,rlMebGroupPlan.exp_gr_pl ASC

	SET @MemGroupPlanId=(SELECT TOP 1 rlMebGroupPlan.mb_gr_pl_id AS PlanID					
				  from [plan] tblPlan
				  LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
				  LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
				  WHERE rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId AND rlMebRate.exp_rt_date IS NULL 
				  ORDER BY rlMebGroupPlan.eff_gr_pl ASC ,rlMebGroupPlan.exp_gr_pl ASC)

	--Plan Details
	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.ins_opt AS InsOptionType,
		LTRIM(RTRIM((typePl.descr))) +' '+ insOpt.ins_opt_sd AS TypeorOption,
		tblPlan.plan_dsp_name AS PlanName,
		tblPlan.tiered_sw AS Tiered,		
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		LTRIM(RTRIM(typeMb.descr)) AS PlanAction,
		--rlMebGroupPlan.action_code AS PlanAction,
		planRate.rate_short_desc AS Rate,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName,
		rlMebGroupPlan.sub_in_plan AS SubinPlane,
		rlMebRate.eff_rt_date AS RateEffectiv,
		rlMebRate.exp_rt_date AS RateExpired,
		(typeRT.descr) AS RateAction
		
	from [plan] tblPlan
	INNER JOIN ins_opt insOpt ON insOpt.ins_opt=tblPlan.ins_opt
	LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	LEFT JOIN pl_rat planRate ON planRate.rate_code=rlMebRate.rate_code
	LEFT JOIN typ_table typePl ON typePl.subsys_code='PL' AND typePl.tab_name='ins_type' AND typePl.code=tblPlan.ins_type
	LEFT JOIN typ_table typeMb ON typeMb.subsys_code='MB' AND typeMb.tab_name='action_code' AND typeMb.code=rlMebGroupPlan.action_code
	LEFT JOIN typ_table typeRT ON typeRT.subsys_code='MB' AND typeRT.tab_name='action_code' AND typeRT.code=rlMebRate.action_code
	WHERE rlMebGroupPlan.mb_gr_pl_id=@MemGroupPlanId
	--tblPlan.plan_id=@planId AND rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId 
	AND rlMebRate.exp_rt_date IS NULL 

	--Facility Details
	SELECT DISTINCT Facilty.fc_id AS FacilityID,
		   Facilty.fc_name AS FacilityName,
		   relPlanFacility.eff_date AS EffDate,
		   relPlanFacility.exp_date AS ExpDate,
		   LTRIM(RTRIM((typeFc.descr))) AS "Action"

	 FROM facility Facilty
	 INNER JOIN rlplfc relPlanFacility ON relPlanFacility.facility_id=Facilty.fc_id
	 INNER JOIN rlmbgrpl relMebGroupPlan ON relMebGroupPlan.mb_gr_pl_id=relPlanFacility.mb_gr_pl_id
	 LEFT JOIN typ_table typeFc ON typeFc.subsys_code='MB' AND typeFc.tab_name='action_code' AND typeFc.code=relPlanFacility.action_code
	 WHERE relPlanFacility.member_id=@memberId AND relMebGroupPlan.mb_gr_pl_id=@MemGroupPlanId
	 --AND relMebGroupPlan.group_id=@groupId AND relMebGroupPlan.plan_id=@planId 
	 AND relPlanFacility.exp_date IS NULL
	 */

	DROP TABLE #MemberGroupTemp


SET NOCOUNT OFF
END