﻿--EXEC [usp_memberportal_viewmyplan_getplan_byusername_NewConstituecy] 'LDKerr'
CREATE PROCEDURE [dbo].[usp_memberportal_viewmyplan_getplan_byusername_NewConstituecy] 
(@username VARCHAR(max))
AS
BEGIN
SET NOCOUNT ON 
DECLARE @userid int;
DECLARE @zip VARCHAR(max);
DECLARE @email VARCHAR(max);
DECLARE @lname VARCHAR(max);
DECLARE @memberid int;
DECLARE @plan_id int;
DECLARE @group_id int;
DECLARE @status VARCHAR(max);
DECLARE @roleid VARCHAR(max);


SELECT @userid=m.user_id,@memberid=m.member_id,@plan_id=m.plan_id,
	@group_id=m.group_id,@roleid=m.role_id
	FROM member_user_details m
	WHERE [user_name]=@username

IF @roleid=4 OR @roleid=5
BEGIN
	IF EXISTS(SELECT 1 FROM member_user_details mbr 
			JOIN rlmbgrpl_sec grppln on mbr.member_id = grppln.member_id
			JOIN [group_sec] reg on reg.group_id=grppln.group_id
			JOIN [plan_sec] pln on pln.plan_id=grppln.plan_id
			JOIN [group_sec] grpParent on reg.group_parent = grpParent.group_id
			WHERE mbr.user_name=@username AND 
			(grppln.exp_gr_pl is null or grppln.exp_gr_pl > GETDATE()))
			BEGIN
				SELECT DISTINCT TOP 1 user_id AS User_Id,reg.group_id AS Group_Id ,reg.group_name AS Group_Name,grpParent.group_name AS Parent_Name,
					pln.plan_id AS Plan_Id,pln.plan_name AS Plan_Name,pln.ins_opt AS Plan_Type, role_id AS Role_ID,mbr.member_id AS MemberID ,
					LTRIM(RTRIM(tbl_address.zip)) AS Zip,reg.group_type Group_Type
					FROM member_user_details mbr
					JOIN rlmbgrpl_sec grppln ON mbr.member_id = grppln.member_id
					JOIN [group_sec] reg ON reg.group_id=grppln.group_id
					JOIN [plan_sec] pln ON pln.plan_id=grppln.plan_id
					JOIN [group_sec] grpParent ON reg.group_parent = grpParent.group_id
					Left outer JOIN [address_sec] tbl_address  ON mbr.member_id = tbl_address.sys_rec_id and  tbl_address.subsys_code = 'MB' and  tbl_address.addr_type ='L' 
					where mbr.user_name=@username AND
					(grppln.exp_gr_pl is null or grppln.exp_gr_pl > GETDATE())
					
			END
			ELSE
			BEGIN
				SELECT null Error_Msg,@roleid AS Role_ID
			END
END
	ELSE IF @roleid=1 OR @roleid=2
	BEGIN
		IF @memberid>0
		BEGIN
			IF EXISTS(SELECT 1 FROM [group_sec] grp
	  		JOIN rlmbgrpl_sec reg ON reg.group_id=grp.group_id
			JOIN member_sec mbr ON mbr.member_id =reg.member_id
			JOIN [plan_sec] pln ON pln.plan_id=reg.plan_id
			JOIN [group_sec] grpParent ON grp.group_parent = grpParent.group_id
			WHERE mbr.member_id = @memberid AND grp.group_id=@group_id AND pln.plan_id=@plan_id)
			BEGIN
				SELECT TOP 1 grp.group_id AS Group_Id,grp.group_name AS Group_Name,grpParent.group_name AS Parent_Name,grp.group_type AS Group_Type,
				pln.plan_id AS Plan_Id,pln.plan_name AS Plan_Name,pln.ins_opt AS Plan_Type,@roleid AS Role_ID,mbr.member_id AS MemberID ,
				LTRIM(RTRIM(tbl_address.zip)) AS Zip,grp.group_type Group_Type
					FROM [group_sec] grp
	  				JOIN rlmbgrpl_sec reg ON reg.group_id=grp.group_id
					JOIN member_sec mbr ON mbr.member_id =reg.member_id
					JOIN [plan_sec] pln ON pln.plan_id=reg.plan_id
					JOIN [group_sec] grpParent ON grp.group_parent = grpParent.group_id
					Left outer JOIN [address_sec] tbl_address  ON mbr.member_id = tbl_address.sys_rec_id and  tbl_address.subsys_code = 'MB' and  tbl_address.addr_type ='L' 
					WHERE mbr.member_id = @memberid AND grp.group_id=@group_id AND pln.plan_id=@plan_id
			END
			ELSE
			BEGIN
				SELECT null Error_Msg,@roleid AS Role_ID
			END
		END
		ELSE
		BEGIN
			SET @status ='DDS User with no previous groupid';

			SELECT @status,@roleid AS Role_ID 
		END

	END

END