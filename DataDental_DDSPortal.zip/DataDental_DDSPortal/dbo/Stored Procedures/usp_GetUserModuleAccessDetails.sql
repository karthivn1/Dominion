﻿
-- =============================================

-- Author:		<Neetha Joseph>

-- Create date: <13-Sep-2016>

-- Description:	<This stored procedure is used to get role details(module access) for the user>

-- =============================================

--exec [usp_GetUserModuleAccessDetails] 'kashok'

CREATE PROCEDURE [dbo].[usp_GetUserModuleAccessDetails]
(
@userCode varchar(15)=NULL 
)
AS

BEGIN

SET NOCOUNT ON
	Declare @userId int, @parentId int, @override int, @super Int, @acc smallint
	SELECT @userId = usersl_id, @super = super, @override = ovr_ride, @parentId = parent_id  from user_tbl where ltrim(rtrim([user_tbl].user_id)) = @userCode
	SET @acc = 1;


IF OBJECT_ID('tempdb..##tempmenuwithnomenudef') IS NOT NULL
DROP TABLE #tempmenuwithnomenudef


SELECT 
@userId UserId,
0 ModuleId,
GETDATE() EffectiveDate,
GETDATE() ExpirationDate,
@acc Access,
'' ModuleCode,		
menudef.subsys_code SubSystemCode,
'' MenuOption,		
menudef.module Module,
menudef.module_controller ModuleController,
menudef.[sub_module] [SubModule],
menudef.[action] Action,
menudef.menu Menu,
menudef.menu_description MenuDescription,
menudef.menu_action MenuAction,
menudef.submenu SubMenu,
menudef.submenu_description SubMenuDescription,
menudef.submenu_action SubMenuAction,	
menudef.tab_name  TabName,	
0 ActivityMasterId,
'' ActivityReasonFlag into #tempmenuwithnomenudef
		
FROM menu_definition menudef 	
WHERE  menudef.active=1 and menudef.mod_id=0 and menudef.menu_opt='' and menudef.subsys_code not in ('DL','TL')




	IF(@super = 1)
	BEGIN
		SELECT 
			[user].usersl_id UserId,
			modacc.mod_id ModuleId,
			GETDATE() EffectiveDate,
			NULL ExpirationDate,
			@acc Access,
			moddef.code ModuleCode,		
			moddef.subsys_code SubSystemCode,
			moddef.menu_opt MenuOption,		
			menudef.module Module,
			menudef.module_controller ModuleController,
			menudef.[sub_module] [SubModule],
			menudef.[action] Action,
			menudef.menu Menu,
			menudef.menu_description MenuDescription,
			menudef.menu_action MenuAction,
			menudef.submenu SubMenu,
			menudef.submenu_description SubMenuDescription,
			menudef.submenu_action SubMenuAction,
			menudef.tab_name  TabName,			
			actmast.act_mast_id ActivityMasterId,
			(Case when actmast.reason_flag='Y' then 1 else 0 end) ActivityReasonFlag
		FROM user_tbl  [user] 
		INNER JOIN (select distinct mod_id, @userId as userid from mod_acc) modacc ON modacc.userid=[user].usersl_id
		INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
		INNER JOIN menu_definition menudef ON menudef.mod_id=moddef.mod_id and menudef.menu_opt=moddef.menu_opt and menudef.subsys_code not in ('DL','TL')
		LEFT OUTER JOIN act_mast actmast ON actmast.mod_id=moddef.mod_id and actmast.activity_flag='Y'
		WHERE ltrim(rtrim([user].user_id)) = @userCode	
		AND menudef.active=1

		UNION

		select * from #tempmenuwithnomenudef
		
		
	END
	ELSE IF(@override = 1)
	BEGIN
			SELECT 
			[user].usersl_id UserId,
			modacc.mod_id ModuleId,
			modacc.eff_date EffectiveDate,
			modacc.exp_date ExpirationDate,
			modacc.access Access,
			moddef.code ModuleCode,		
			moddef.subsys_code SubSystemCode,
			moddef.menu_opt MenuOption,		
			menudef.module Module,
			menudef.module_controller ModuleController,
			menudef.[sub_module] [SubModule],
			menudef.[action] Action,
			menudef.menu Menu,
			menudef.menu_description MenuDescription,
			menudef.menu_action MenuAction,
			menudef.submenu SubMenu,
			menudef.submenu_description SubMenuDescription,
			menudef.submenu_action SubMenuAction,
			menudef.tab_name  TabName,		
			actmast.act_mast_id ActivityMasterId,
			(Case when actmast.reason_flag='Y' then 1 else 0 end) ActivityReasonFlag
		FROM user_tbl  [user] 
		INNER JOIN  mod_acc modacc ON modacc.usersl_id=[user].usersl_id
		INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
		INNER JOIN menu_definition menudef ON menudef.mod_id=moddef.mod_id and menudef.menu_opt=moddef.menu_opt and menudef.subsys_code not in ('DL','TL')
		LEFT OUTER JOIN act_mast actmast ON actmast.mod_id=moddef.mod_id and actmast.activity_flag='Y'
		WHERE	modacc.eff_date <=getdate() 
		AND modacc.type is NULL
		AND (modacc.exp_date >= getdate() OR modacc.exp_date IS NULL)
		AND ltrim(rtrim([user].user_id))=@userCode	
		and menudef.active=1
		union
		select * from #tempmenuwithnomenudef
	END
	ELSE
	BEGIN
		WITH 
				ModuleGroupAccess_CTE (modAccessId) AS  
				(  
					select 
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					 from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					 where usersl_id = @parentId and type = 'GP'
				),
				ModuleUserAccess_CTE (modAccessId) AS  
				(  
					select 
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					where usersl_id = @userId and type is null
				)  

				SELECT 
					[user].usersl_id UserId,
					modaccJoin.modId ModuleId,
					modaccJoin.effDate EffectiveDate,
					modaccJoin.expDate ExpirationDate,
					modaccJoin.access Access,
					moddef.code ModuleCode,		
					moddef.subsys_code SubSystemCode,
					moddef.menu_opt MenuOption,			
					menudef.module Module,
					menudef.module_controller ModuleController,
					menudef.[sub_module] [SubModule],
					menudef.[action] Action,
					menudef.menu Menu,
					menudef.menu_description MenuDescription,
					menudef.menu_action MenuAction,
					menudef.submenu SubMenu,
					menudef.submenu_description SubMenuDescription,
					menudef.submenu_action SubMenuAction,	
					menudef.tab_name  TabName,		
					actmast.act_mast_id ActivityMasterId,
					(Case when actmast.reason_flag='Y' then 1 else 0 end) ActivityReasonFlag
					FROM user_tbl  [user] 
					INNER JOIN (SELECT @userId as userId, modacc.modacc_id as modaccId, modacc.mod_id as modId, modacc.eff_date as effDate, modacc.exp_date as expDate, modacc.access as access from mod_acc modacc
					INNER JOIN (SELECT modAccessId from ModuleGroupAccess_CTE UNION SELECT modAccessId FROM ModuleUserAccess_CTE) modAccCTE ON modAccCTE.modAccessId = modacc.modacc_id) modaccJoin ON modaccJoin.userId=[user].usersl_id
					INNER JOIN mod_def moddef ON moddef.mod_id=modaccJoin.modId
					INNER JOIN menu_definition menudef ON menudef.mod_id=moddef.mod_id and menudef.menu_opt = moddef.menu_opt and menudef.subsys_code not in ('DL','TL')
					LEFT OUTER JOIN act_mast actmast ON actmast.mod_id=moddef.mod_id and actmast.activity_flag='Y'
					WHERE modaccJoin.effDate <=getdate()
					AND (modaccJoin.expDate>=getdate() OR modaccJoin.expDate IS NULL)
					AND ltrim(rtrim([user].user_id))=@userCode
					and menudef.active=1
					union
		select * from #tempmenuwithnomenudef
	END	
	

SET NOCOUNT OFF
END