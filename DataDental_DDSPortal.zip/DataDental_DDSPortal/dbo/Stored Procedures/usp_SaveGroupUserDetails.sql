﻿CREATE PROC [dbo].[usp_SaveGroupUserDetails]
(
@GroupUserDetails dbo.GroupUserDetails readonly
)
AS
BEGIN
Begin try
BEGIN TRAN
	INSERT INTO group_user_details (user_name,temp_password,last_name,invitecode,group_zip,email,status_id,role_id,is_firstlogin,created_date)
	SELECT t.user_name,t.temp_password,t.last_name,t.invitecode,t.group_zip,t.email,4,IIF(i.con_type='P',7,3),1,getdate() 
	from @GroupUserDetails t
	JOIN invitecode_details i ON i.invitecode COLLATE SQL_Latin1_General_CP1_CS_AS =t.invitecode

	INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
	VALUES (SCOPE_IDENTITY(),1,1001,0,CONVERT(date,GETDATE()));
COMMIT
end try
Begin Catch
    ROLLBACK
	Select 0
End catch
SELECT 1
END