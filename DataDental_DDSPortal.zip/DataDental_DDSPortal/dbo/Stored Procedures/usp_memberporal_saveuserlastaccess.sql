﻿CREATE procedure [dbo].[usp_memberporal_saveuserlastaccess]
(@username varchar(max),
 @groupid int,
 @planid int,
 @memberid int
)
 AS
 Declare @userid int;
 Begin
 If exists ( select user_id from member_user_details  where user_name =@username)
 Begin 
 set @userid=(select user_id from member_user_details  where user_name =@username)
 update member_user_details set member_id=@memberid, group_id=@groupid , plan_id=@planid where user_id =@userid 
 
 select distinct grp.group_id as GroupID,pln.plan_id as PlanID,grp.group_name as GroupName,pln.plan_name as PlanName, @memberid as MemberID,LTRIM(RTRIM(tbl_address.zip)) Zip
 from group_sec grp 
 inner join rel_gppl_sec gpdet ON grp.group_id = gpdet.group_id
 inner join plan_sec  pln on pln.plan_id = gpdet.plan_id 
 Left outer JOIN [address_sec] tbl_address  ON @memberid = tbl_address.sys_rec_id and  tbl_address.subsys_code = 'MB' and  tbl_address.addr_type ='L' 
 where grp.group_id=@groupid and pln.plan_id=@planid

 
 End 
 End