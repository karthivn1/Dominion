﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_UpdateTempPassword 29,'group_user_details','AMZukv9nvsKx7KBhDiqPPaGSJVWP/wNZ6KIyq6A9STeg9CRtOK+NVzuOWQ2Uqq10+w=='
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateTempPassword]
@ref_id INT,
@ref_object nVarchar(100),
@tempPassword VARCHAR(300)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
DECLARE @errorMsg NVARCHAR(100)='';

    -- Insert statements for procedure here

IF OBJECT_ID(@ref_object) IS NOT NULL
BEGIN

	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @sqlStr NVARCHAR(1000);
	DECLARE @user_name VARCHAR(100)=NULL;

	SET @sqlStr='SELECT @user_name=user_name FROM '+@ref_object +' WHERE [user_id]=@ref_id'

	SET @ParmDefinition = N'@user_name VARCHAR(100) OUT,' + N'@ref_id int';

	EXECUTE sp_executesql @sqlStr,@ParmDefinition,@user_name OUT,@ref_id=@ref_id

	IF LEN(@user_name)>0
	BEGIN
		SET @sqlStr ='Update s Set s.temp_password= @tempPassword From '+ @ref_object +' s WHERE s.[user_name]=@user_name'

		SET @ParmDefinition = N'@tempPassword nVARCHAR(300),' + N'@user_name VARCHAR(100)';

		EXECUTE sp_executesql @sqlStr,@ParmDefinition,@tempPassword=@tempPassword,@user_name=@user_name

		SET @sqlStr='Select email From '+ @ref_object +' s WHERE s.[user_id]=@ref_id'

		SET @ParmDefinition = N'@ref_id int';

		EXECUTE sp_executesql @sqlStr,@ParmDefinition,@ref_id=@ref_id

	END
	ELSE
	 BEGIN
		SET @errorMsg='User Not Found'+ @ref_object
		RAISERROR (@errorMsg,16,1)
	 END

END	
ELSE
BEGIN
	SET @errorMsg='Object Not Found'+ @ref_object
	RAISERROR (@errorMsg,1,16)
	RETURN
 END
END