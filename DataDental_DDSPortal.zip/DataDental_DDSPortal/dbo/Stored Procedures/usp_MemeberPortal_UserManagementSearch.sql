﻿CREATE procedure [dbo].[usp_MemeberPortal_UserManagementSearch]
(
@lastname as Varchar(max)= NULL,
@firstname as Varchar(max)=NULL,
@username as Varchar(max)=NULL,
@email as Varchar(max)=NULL,
@subscriberid as int =NULL,
@role as int =NULL,
@role_loggedin as int =null)
AS
Begin
SET NOCOUNT ON 
				if(@lastname ='')
				set @lastname = NULL
				if(@firstname ='')
				set @firstname = NULL
				if(@username ='')
				set @username = NULL

				if(@email ='')
				set @email = NULL
				if(@role ='')
				set @role = NULL
				if(@role_loggedin ='')
				set @role_loggedin = NULL
				if(@subscriberid='' and  @subscriberid <> 0)
				set @subscriberid=NULL

			
if(@role = 0)
	Begin

		if((ISNULL(@lastname,'') ='') and (ISNULL(@firstname,'') ='') and (ISNULL(@username,'') ='') and (ISNULL(@email,'') ='' ) and (ISNULL(@subscriberid,'') ='' ) )
				 begin

						select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,
						convert(nvarchar(MAX),tbl_udetails.DOB, 101) as DOB,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id, tbl_udetails.GroupName
					from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,
					tbl_status.status as Status, RTRIM (tbl_grp.group_name)  + '(' + RTRIM ( cast (tbl_userdetails.group_id as varchar(max)) )+')' as GroupName,
					 tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id
					 from member_user_details as tbl_userdetails
					inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
					inner join role_master as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='mbr' or tbl_rolemaster.portal_type='common')
					Left join group_sec as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id 
					where status in('Active', 'Pending','Deactivated'))  tbl_udetails
				   where 1=1 order by tbl_udetails.LastName asc ;

			   end 
	else
	begin
		if(@role_loggedin =1)
		   begin
		        select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,convert(nvarchar(MAX),tbl_udetails.DOB, 101) as DOB,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id,tbl_udetails.GroupName
				from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,
				tbl_status.status as Status,RTRIM (tbl_grp.group_name)  + '(' + RTRIM ( cast (tbl_userdetails.group_id as varchar(max)) )+')' as GroupName,
				 tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id,tbl_userdetails.member_id as member_id
				 from member_user_details as tbl_userdetails
				inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
				inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='mbr' or tbl_rolemaster.portal_type='common')
			    Left join group_sec as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id 		
				where status in('Active', 'Pending','Deactivated'))  tbl_udetails
				where ((lower(tbl_udetails.UserName) like '%'+lower(@username)+'%') or (lower(tbl_udetails.LastName) like '%'+lower(@lastname)+'%') or (lower(tbl_udetails.FirstName) like '%'+lower(@firstname)+'%') or (lower(tbl_udetails.email) like '%'+lower(@email)+'%') or ((tbl_udetails.member_id =@subscriberid))) order by tbl_udetails.LastName asc ;
			end
			else
			begin
			  select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,convert(nvarchar(MAX),tbl_udetails.DOB, 101) as DOB,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id,tbl_udetails.GroupName
				from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,
				tbl_status.status as Status,RTRIM (tbl_grp.group_name)  + '(' + RTRIM ( cast (tbl_userdetails.group_id as varchar(max)) )+')' as GroupName,
				 tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id,tbl_userdetails.member_id as member_id
				 from member_user_details as tbl_userdetails
				inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
				inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='mbr' or tbl_rolemaster.portal_type='common')
			    Left join group_sec as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id 		
				where status in('Active', 'Pending','Deactivated') and tbl_userdetails.role_id not in (4) )  tbl_udetails
				where ((lower(tbl_udetails.UserName) like '%'+lower(@username)+'%') or (lower(tbl_udetails.LastName) like '%'+lower(@lastname)+'%') or (lower(tbl_udetails.FirstName) like '%'+lower(@firstname)+'%') or (lower(tbl_udetails.email) like '%'+lower(@email)+'%') or ((tbl_udetails.member_id =@subscriberid)))  order by tbl_udetails.LastName asc ;
			end
	end
	end
else 
if(@role=4)
begin
	Declare @memberdetails as table( Memberrole int )
	Insert into @memberdetails (Memberrole) (select role_id from member_user_details where role_id in (4,5))

		   select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,convert(nvarchar(MAX),tbl_udetails.DOB, 101) as DOB,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id,tbl_udetails.GroupName
			from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,
			tbl_status.status as Status,RTRIM (tbl_grp.group_name)  + '(' + RTRIM ( cast (tbl_userdetails.group_id as varchar(max)) )+')'as GroupName,
				IIf (tbl_status.status = 'pending', 'Member Pend', tbl_rolemaster.role_name) as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id,tbl_userdetails.member_id as member_id
			 from member_user_details as tbl_userdetails
			inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
			inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='mbr' or tbl_rolemaster.portal_type='common') 	
			Left join group_sec as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id 	
			where status in('Active', 'Pending','Deactivated'))  tbl_udetails
		    where 
		
			((@role IS NULL AND (tbl_udetails.Role_Id =tbl_udetails.Role_Id  or tbl_udetails.Role_Id  is null)) 
			OR (@role IS NOT NULL AND tbl_udetails.Role_Id in (select role_id from member_user_details where role_id in (4,5))))
			AND ((@subscriberid IS NULL AND (tbl_udetails.member_id=tbl_udetails.member_id or tbl_udetails.member_id is null)) 
			OR (@subscriberid IS NOT NULL AND tbl_udetails.member_id=@subscriberid))
		AND ((@username IS NULL AND (Lower(tbl_udetails.UserName)=Lower(tbl_udetails.UserName) or Lower(tbl_udetails.UserName) is null)) 
			OR (@username IS NOT NULL AND (lower(tbl_udetails.UserName) like '%'+lower(@username)+'%')))
	    AND ((@lastname IS NULL AND (Lower(tbl_udetails.LastName)=Lower(tbl_udetails.LastName) or Lower(tbl_udetails.LastName) is null)) 
			OR (@lastname IS NOT NULL AND  (lower(tbl_udetails.LastName) like '%'+lower(@lastname)+'%')))
	    AND ((@firstname IS NULL AND (Lower(tbl_udetails.FirstName)=Lower(tbl_udetails.FirstName) or Lower(tbl_udetails.FirstName) is null)) 
			OR (@firstname IS NOT NULL AND (lower(tbl_udetails.FirstName) like '%'+lower(@firstname)+'%')))
 AND ((@email IS NULL AND (tbl_udetails.email=tbl_udetails.email or tbl_udetails.email is null)) 
			OR (@email IS NOT NULL AND (lower(tbl_udetails.email) like '%'+lower(@email)+'%'))) order by tbl_udetails.LastName asc
			

end 
else
   Begin
			select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,convert(nvarchar(MAX),tbl_udetails.DOB, 101) as DOB,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id,tbl_udetails.GroupName
			from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,
			tbl_status.status as Status,RTRIM (tbl_grp.group_name)  + '(' + RTRIM ( cast (tbl_userdetails.group_id as varchar(max)) )+')' as GroupName,
			 tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id,tbl_userdetails.member_id as member_id
			 from member_user_details as tbl_userdetails
			inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
			inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='mbr' or tbl_rolemaster.portal_type='common')
			Left join group_sec as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id 
			where status in('Active', 'Pending','Deactivated'))  tbl_udetails
		    where 
		
			((@role IS NULL AND (tbl_udetails.Role_Id =tbl_udetails.Role_Id  or tbl_udetails.Role_Id  is null)) 
			OR (@role IS NOT NULL AND tbl_udetails.Role_Id =@role))
			AND ((@subscriberid IS NULL AND (tbl_udetails.member_id=tbl_udetails.member_id or tbl_udetails.member_id is null)) 
			OR (@subscriberid IS NOT NULL AND tbl_udetails.member_id=@subscriberid))
		AND ((@username IS NULL AND (Lower(tbl_udetails.UserName)=Lower(tbl_udetails.UserName) or tbl_udetails.UserName is null)) 
			OR (@username IS NOT NULL AND (lower(tbl_udetails.UserName) like '%'+lower(@username)+'%')))
	    AND ((@lastname IS NULL AND (Lower(tbl_udetails.LastName)=Lower(tbl_udetails.LastName) or tbl_udetails.LastName is null)) 
			OR (@lastname IS NOT NULL AND (lower(tbl_udetails.LastName) like '%'+lower(@lastname)+'%')))
	    AND ((@firstname IS NULL AND (Lower(tbl_udetails.FirstName)=Lower(tbl_udetails.FirstName) or tbl_udetails.FirstName is null)) 
			OR (@firstname IS NOT NULL AND (lower(tbl_udetails.FirstName) like '%'+lower(@firstname)+'%')))
 AND ((@email IS NULL AND (tbl_udetails.email=tbl_udetails.email or tbl_udetails.email is null)) 
			OR (@email IS NOT NULL AND (lower(tbl_udetails.email) like '%'+lower(@email)+'%'))) order by tbl_udetails.LastName asc
			
End
SET NOCOUNT OFF
End