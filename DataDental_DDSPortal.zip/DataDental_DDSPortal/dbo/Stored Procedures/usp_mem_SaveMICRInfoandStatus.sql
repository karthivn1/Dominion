﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <26-12-2016>
-- Description:	<This sp is used to save the MICR info and Status using parameters>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_SaveMICRInfoandStatus] 
(
@groupId INT=NULL,
@accType VARCHAR(100)=NULL,
@accName VARCHAR(100)=NULL,
@bankAcc VARCHAR(100)=NULL,
@transiTroutenbr VARCHAR(100)=NULL,
@processCode VARCHAR(100)=NULL,
@transactioncode VARCHAR(100)=NULL,
@preAuth VARCHAR(100)=NULL,
@voidcheck VARCHAR(100)=NULL,
@returndescr VARCHAR(100)=NULL, 
@lastmodUser VARCHAR(100)=NULL,
@effDate DATETIME=NULL,
@optional VARCHAR(100)=NULL,
@statusCode VARCHAR(100)=NULL,
@achMICRStatusId INT=NULL,
@actionScreen VARCHAR(100)=NULL,
@activityMasterId INT=NULL,
@subsystemCode	VARCHAR(2)=NULL,
@reasonCode  VARCHAR(2)=NULL,
@memberId INT=NULL,
@hUser VARCHAR(100)=NULL
)
AS
BEGIN
SET NOCOUNT ON;

 BEGIN TRAN 
	BEGIN TRY

IF @actionScreen='AddMICRInfo'
BEGIN

INSERT INTO ach_micrs ( group_id, account_type, account_name, bank_account, transit_route_nbr,
 process_code, transaction_code, pre_authorization, void_check, return_descr, last_mod_date,
  last_mod_user, eff_date, optional_5 ) VALUES ( @groupId, @accType, @accName, @bankAcc, @transiTroutenbr,
   @processCode,   @transactioncode, @preAuth, @voidcheck, @returndescr,getdate(),
    @lastmodUser, @effDate, @optional ) 
 
END
 
 
ELSE 
  

INSERT INTO ach_micrs_d ( ach_micrs_id, status_code, last_mod_date, last_mod_user, eff_date ) VALUES 
(@achMICRStatusId, @statusCode, getdate(), @lastmodUser, @effDate ) 

 BEGIN 

 IF @activityMasterId>0 
 BEGIN
		EXEC usp_SaveActivity @subsystemCode,@memberId,@reasonCode,@activityMasterId,@hUser
		END
	END
	
	COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
 SET NOCOUNT OFF

END