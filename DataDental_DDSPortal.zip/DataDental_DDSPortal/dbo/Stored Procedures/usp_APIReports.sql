﻿
CREATE procedure [dbo].[usp_APIReports]
(
@startdate date,
@enddate date )
AS
Begin
SET NOCOUNT ON 
Declare @userid int;
 
 Select COUNT(convert(DATE,completed_time)) dtCount,is_error,convert(DATE,completed_time) as Date
     INTO #temp
       FROM api_process_details
       group by convert(DATE,completed_time),is_error
       order by 3    

    
    
  Select t.Date,IIF(t.is_error=1,t.dtCount,0) as ISFail,t.dtCount+ISNULL(t1.dtCount,0) AS Total
       INTO #temp1
              From #temp t
              Left JOIN #temp t1 ON t1.Date=t.Date AND t1.is_error<>t.is_error

 if ((@startdate is NULL )and (@enddate is NULL))
 begin
   Select Date as Created_Date,Total as Transaction_Count,SUM(ISFail) AS Fail_count
       From #temp1  
       group by Date,Total
       ORDER by Date
end
else
begin
Select Date as Created_Date,Total as Transaction_Count,SUM(ISFail) AS Fail_count
       From #temp1  where  Date Between Convert(date,@startdate) and Convert(date,@enddate)
       group by Date,Total
       ORDER by Date
end

SET NOCOUNT OFF
End