﻿




-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <04-10-2016>
-- Description:	<This sp gets the Member Details by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberDetails]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;
	--DECLARE @groupId INT
	--DECLARE @planId INT
DECLARE @NotesCount INT;
DECLARE @ActionFollowUpCount INT;
DECLARE @GrievanceCount INT;
SET @ActionFollowUpCount = (SELECT COUNT(follow_id) from follow where sub_sys = 'MB' and external_key = @memberId)
SET @GrievanceCount = (SELECT COUNT(grievance_id) from grievances where (griev_by_sc = 'MB' and griev_by_id = @memberId) OR (against_sc = 'MB' and  against_id = @memberId))

	--Member Detail
	 SELECT DISTINCT member.member_id AS MemberID,			     
			member.ext_id_type AS IdType,
			case 
			   when str_1='new_ssn' then cast(member.new_ssn as varchar) 
			   when str_1='member_id' then cast(member.member_id as varchar)
			   when str_1='source_id' then cast(member.source_id as varchar)
			   else
			   cast(member.alt_id as varchar) 
			end 'ExternalID',
			member.new_ssn AS SSN,
			LTRIM(RTRIM(member.source_id)) AS SrcID,
			LTRIM(RTRIM(member.alt_id)) AS AltID,
			member.oed AS OED,			     
			LTRIM(RTRIM(member.first_name)) AS FirstName ,			      
			LTRIM(RTRIM(member.last_name)) AS LastName,
			LTRIM(RTRIM(member.middle_init)) AS MiddleInitial,
			member.member_code AS Gender,
			mbrCode.mbr_code_desc AS GenderDesc,
			member.date_of_birth AS DOB,
			convert(int,DATEDIFF(d, member.date_of_birth, getdate())/365.25)  AS Age,
			member.hire_date AS Hire,
			member.student_exp AS StudentExp,
			CAST(CASE WHEN member.student_flag= 'N' THEN 0 ELSE 1 END AS BIT) AS "Student",   
			CAST(CASE WHEN member.disable_flag= 'N' THEN 0 ELSE 1 END AS BIT) AS "Disabled",
			CAST(CASE WHEN member.paperless= 'N' THEN 0 ELSE 1 END AS BIT) AS "Paperless",
			 dbo.udf_member_getMemberStatus(member.member_id) as Status,
			 (SELECT    COUNT(DISTINCT(FA.fc_alert_notes_id)) FROM fc_alert_notes(NOLOCK) FA INNER JOIN rlplfc rlplfc ON  rlplfc.facility_id = FA.fc_id 
              INNER JOIN facility  facility ON facility.fc_id = FA.fc_id 
              INNER JOIN fcstat fcstat ON facility.fc_id = fcstat.facility_id AND (fcstat.eff_date <= GETDATE() AND (fcstat.exp_date > GETDATE() OR ( fcstat.exp_date is NULL)) ) 
              INNER JOIN typ_table typ_table ON typ_table.subsys_code='FC' AND typ_table.tab_name='fcstat' AND typ_table.code=fcstat.status 
              WHERE  FA.display = 'Y' AND  typ_table.code NOT IN ('TR') AND rlplfc.member_id = @memberId)  AS FacilityAlertCount,
			  ( SELECT COUNT(DISTINCT(GN.group_note_id)) FROM group_notes(NOLOCK) GN INNER JOIN rlmbgrpl rlmbgrpl ON rlmbgrpl.group_id = GN.group_id WHERE rlmbgrpl.member_id = @memberId)AS GroupAlertCount,
			  
			  @ActionFollowUpCount AS ActionFollowUpCount,
			  @GrievanceCount AS GrievanceCount,	  
             (SELECT COUNT(notes_id) from notes N INNER JOIN member MB on MB.member_id = N.external_key  and N.sub_sys = 'MB' and MB.family_id = member.member_id) AS NotesCount
	  FROM member
	  INNER JOIN mbr_code mbrCode ON mbrCode.mbr_code=member.member_code
	  INNER JOIN typ_table ON   typ_table.subsys_code = 'MB'
	  INNER JOIN typ_table_exp ON typ_table_exp.tab_name = 'ext_id_type' and typ_table_exp.int_1=member.ext_id_type and        
		         typ_table.tab_name = 'action_code'   
	  WHERE member.member_id =@memberId

	/*
	--List Of Group 
	SELECT DISTINCT tblGroup.group_id AS GroupID,
		 rlMemGroupPlan.mb_gr_pl_id AS MemGroupPlanID,  
         tblGroup.group_name AS GroupName,   
         LTRIM(RTRIM((typeGr.descr))) AS GroupType,   
         tblGroup.group_parent AS ParentGroup,            
         tblGroup.oc_id AS OCID,
		 tblGroup.bill_type AS BillType,
		 rlMemGroupPlan.eff_gr_pl,
		 rlMemGroupPlan.exp_gr_pl,
		 LTRIM(RTRIM((typeSt.descr))) AS "Status"
         --opCompany.name   
       
    FROM [group] tblGroup 
		INNER JOIN  rlmbgrpl rlMemGroupPlan ON rlMemGroupPlan.group_id=tblGroup.group_id
		INNER JOIN group_status groupStatus ON groupStatus.group_id=tblGroup.group_id		
		LEFT JOIN oper_company opCompany ON opCompany.oc_id=tblGroup.oc_id
		LEFT JOIN typ_table typeGr ON typeGr.subsys_code='GP' AND typeGr.tab_name='group_type' AND typeGr.code=tblGroup.group_type          
		LEFT JOIN typ_table typeSt ON typeSt.subsys_code='GP' AND typeSt.tab_name='group_status' AND typeSt.code= groupStatus.group_status
	WHERE rlMemGroupPlan.member_id=@memberId AND groupStatus.exp_date IS NULL
		and rlMemGroupPlan.mb_gr_pl_id=(SELECT MAX(mb_gr_pl_id) from rlmbgrpl rl2 
										WHERE rlMemGroupPlan.group_id = rl2.group_id AND rlMemGroupPlan.member_id = rl2.member_id)
	ORDER BY tblGroup.group_id ASC, rlMemGroupPlan.eff_gr_pl DESC

	SET @groupId= (SELECT TOP 1 tblGroup.group_id         
					FROM [group] tblGroup 
					INNER JOIN  rlmbgrpl rlMemGroupPlan ON rlMemGroupPlan.group_id=tblGroup.group_id		   
					WHERE rlMemGroupPlan.member_id=@memberId
					and rlMemGroupPlan.mb_gr_pl_id=(SELECT MAX(mb_gr_pl_id) from rlmbgrpl rl2 
										WHERE rlMemGroupPlan.group_id = rl2.group_id AND rlMemGroupPlan.member_id = rl2.member_id)
				    ORDER BY tblGroup.group_id ASC,rlMemGroupPlan.eff_gr_pl DESC)
	
	
	--List Of Plan
	SELECT DISTINCT 
		--rlMebGroupPlan.mb_gr_pl_id ,
		rlMebGroupPlan.group_id,
		tblPlan.plan_id AS PlanID,
		tblPlan.plan_dsp_name AS PlanName,
		rlMebGroupPlan.sub_in_plan AS Sip,
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		(typeMa.descr) AS PlanAction,
		--rlMebGroupPlan.action_code AS PlanAction,
		rlMebRate.rate_code AS RC,
		rlMebRate.eff_rt_date AS RateEffective,
		rlMebRate.exp_rt_date AS RateExpired,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName
	from [plan] tblPlan
	LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	LEFT JOIN typ_table typeMa ON typeMa.subsys_code='MB' AND typeMa.tab_name='action_code' AND typeMa.code=rlMebGroupPlan.action_code	
	WHERE rlMebGroupPlan.group_id=@groupId AND rlMebGroupPlan.member_id=@memberId AND rlMebRate.exp_rt_date IS NULL
	ORDER BY rlMebGroupPlan.eff_gr_pl ASC ,rlMebGroupPlan.exp_gr_pl ASC

	SET @planId=(SELECT TOP 1 tblPlan.plan_id AS PlanID					
				  from [plan] tblPlan
				  LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
				  LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
				  WHERE rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId
						AND rlMebRate.exp_rt_date IS NULL 
				   ORDER BY rlMebGroupPlan.eff_gr_pl ASC ,rlMebGroupPlan.exp_gr_pl ASC)
	
	
	--Plan Details
	SELECT DISTINCT		
		tblPlan.plan_id AS PlanID,
		tblPlan.ins_opt AS InsOptionType,
		LTRIM(RTRIM((typePl.descr))) +' '+ insOpt.ins_opt_sd AS TypeorOption,
		tblPlan.plan_dsp_name AS PlanName,
		tblPlan.tiered_sw AS Tiered,		
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		LTRIM(RTRIM(typeMb.descr)) AS PlanAction,
		--rlMebGroupPlan.action_code AS PlanAction,
		planRate.rate_short_desc AS Rate,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName,
		rlMebGroupPlan.sub_in_plan AS SubinPlane,
		rlMebRate.eff_rt_date AS RateEffective,
		rlMebRate.exp_rt_date AS RateExpired,
		(typeRT.descr) AS RateAction
		
	from [plan] tblPlan
	INNER JOIN ins_opt insOpt ON insOpt.ins_opt=tblPlan.ins_opt
	LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	LEFT JOIN pl_rat planRate ON planRate.rate_code=rlMebRate.rate_code
	LEFT JOIN typ_table typePl ON typePl.subsys_code='PL' AND typePl.tab_name='ins_type' AND typePl.code=tblPlan.ins_type
	LEFT JOIN typ_table typeMb ON typeMb.subsys_code='MB' AND typeMb.tab_name='action_code' AND typeMb.code=rlMebGroupPlan.action_code
	LEFT JOIN typ_table typeRT ON typeRT.subsys_code='MB' AND typeRT.tab_name='action_code' AND typeRT.code=rlMebRate.action_code
	WHERE tblPlan.plan_id=@planId AND rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId AND rlMebRate.exp_rt_date IS NULL 
	--Facility Details

	SELECT DISTINCT Facilty.fc_id AS FacilityID,
		   Facilty.fc_name AS FacilityName,
		   relPlanFacility.eff_date AS EffDate,
		   relPlanFacility.exp_date AS ExpDate,
		   LTRIM(RTRIM((typeFc.descr))) AS "Action"

	 FROM facility Facilty
	 INNER JOIN rlplfc relPlanFacility ON relPlanFacility.facility_id=Facilty.fc_id
	 INNER JOIN member Member ON Member.family_id=relPlanFacility.member_id
	 INNER JOIN rlmbgrpl relMebGroupPlan ON relMebGroupPlan.mb_gr_pl_id=relPlanFacility.mb_gr_pl_id
	 LEFT JOIN typ_table typeFc ON typeFc.subsys_code='MB' AND typeFc.tab_name='action_code' AND typeFc.code=relPlanFacility.action_code
	 WHERE relMebGroupPlan.member_id=@memberId AND relMebGroupPlan.group_id=@groupId AND relMebGroupPlan.plan_id=@planId AND relPlanFacility.exp_date IS NULL
	 */

	 EXEC [usp_mem_GetGroupListByMember] @memberId

SET NOCOUNT OFF
END