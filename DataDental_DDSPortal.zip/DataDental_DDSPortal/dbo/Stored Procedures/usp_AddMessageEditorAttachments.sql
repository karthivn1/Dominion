﻿CREATE procedure [dbo].[usp_AddMessageEditorAttachments] 
(
@messageid as Varchar(max),
@filename as varchar(max)= NULL,
@file as VarBinary(max)
)
AS
Begin
SET NOCOUNT ON 
Begin Transaction [addmessageEditor]

	Begin try
		Declare @userId int; 

		Insert into [message_attachment] (message_id,attachment_filename,attachment_file)
		values
		(@messageid,@filename,@file)

		select @messageid;
		 --End

	commit Transaction [addmessageEditor]
   End try

Begin Catch
rollback Transaction [addmessageEditor]
End Catch
SET NOCOUNT OFF
End