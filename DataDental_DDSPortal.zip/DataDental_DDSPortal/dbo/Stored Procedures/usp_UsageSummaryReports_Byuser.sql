﻿
CREATE procedure [dbo].[usp_UsageSummaryReports_Byuser]
(
--@username varchar(max),
@fromDate varchar(max),
@toDate varchar(max),
@Group_User int = null, 
@DDS_User int = null,
@Admin_User int = null, 
@Member_EG int = null,
@Member_SG int = null,
@Producer_User int = null
 )
AS
Begin
SET NOCOUNT ON 
Declare @userid int;


select *
from 
(
  select  tbl_user.user_name   as User_Name, role_master.role_name  UserTypeName, device_type as Device, tbl_master.page_id,tbl_master.page_name as page_name
  from page_log as tbl_log  inner join page_master as tbl_master on tbl_log.page_id = tbl_master.page_id 
  inner join group_user_details as tbl_user on tbl_user.user_id =tbl_log.user_id 
  inner join role_master on role_master.role_id =tbl_user.role_id  
  where  tbl_user.role_id in(@DDS_User,@Group_User,@Admin_User) and
  convert(date,visited_date)  Between   Convert(date,@fromDate) and Convert(date,@toDate) 

  UNION ALL
   select  tbl_user.user_name   as User_Name, role_master.role_name  UserTypeName, device_type as Device, tbl_master.page_id,tbl_master.page_name as page_name
  from page_log as tbl_log  inner join page_master as tbl_master on tbl_log.page_id = tbl_master.page_id 
  inner join member_user_details as tbl_user on tbl_user.user_id =tbl_log.user_id 
  inner join role_master on role_master.role_id =tbl_user.role_id  
  where  tbl_user.role_id in(@DDS_User,@Member_EG,@Admin_User,@Member_SG)  and
  convert(date,visited_date)  Between   Convert(date,@fromDate) and Convert(date,@toDate) 
 
) src
pivot
(
  Count(page_id)
  for page_name in ([AcctInfo],[AddDepedent], [AddSubscriber], [CostCalculator],[ContEditor], [Documents], [EnrollKit],[Forms], [GroupSummary], 
  [Login],[MemberSummary], [MessageController], [MessageEditor],[SubscriberSearch],[TechnicalSupport], [UserManagement])
) piv;
end

SET NOCOUNT OFF