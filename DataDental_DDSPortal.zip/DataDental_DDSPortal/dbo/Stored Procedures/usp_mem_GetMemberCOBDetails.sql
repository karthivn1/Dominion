﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <23-11-2016>
-- Description:	<This sp gets the Member COB Details by passing memberGroupPlanId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberCOBDetails]
(
@memberGroupPlanId INT
)
AS
BEGIN
SET NOCOUNT ON;
	SELECT  member_cob.cob_id  AS MemberCobId, 
			member_cob.mb_gr_pl_id , 
			member_cob.member_id , 
			member_cob.request_date AS RequestDate, 
			member_cob.verified_date AS VerifiedDate, 
			member_cob.prim_carrier_id AS PrimaryCarrierID,
			CAST(CASE WHEN member_cob.cob_sw= 'N' THEN 0 ELSE 1 END AS BIT) AS COB,
			primary_carrier.name AS CarrierName, 
			member.first_name +' '+ member.last_name AS MemberName,
			member_cob.member_id as DependentID
	FROM member_cob
	INNER JOIN member ON member.member_id = member_cob.member_id
	LEFT OUTER JOIN primary_carrier ON member_cob.prim_carrier_id = primary_carrier.primary_carrier_id		 
	WHERE member_cob.mb_gr_pl_id = @memberGroupPlanId
SET NOCOUNT OFF
END