﻿-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <23-11-2016>
-- Description:	<This sp gets the Member Designation Details by passing memberId>
-- =============================================
 
CREATE PROCEDURE [dbo].[usp_mem_GetMemberMICRDetails] --2411647
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;	

	SELECT ach_micrs.ach_micrs_id AS AccountMICRId,
		   ach_micrs.group_id,
		   ach_micrs.account_type AS AccType,
		   typAcc.descr AS AccountDescr,
		   ach_micrs.account_name AS AccName,
		   ach_micrs.bank_account AS Account,
		   ach_micrs.transit_route_nbr AS "Route",
		   ach_micrs.process_code AS ProcessCode,
		   ach_micrs.transaction_code AS TransactionCode,
		   ach_micrs.pre_authorization AS PreAuth,
		   ach_micrs.void_check AS VoidCheck,
		   ach_micrs.return_code AS ReturnCode,
		   ach_micrs.return_descr AS ReturnDesc,
		   ach_micrs.last_mod_date,
		   ach_micrs.last_mod_user AS LastModUser,
		   ach_micrs.eff_date AS EffDate,
		   ach_micrs.exp_date AS ExpDate,
		   ach_micrs.optional_5 AS OptValue
    INTO #MICRTemp
	FROM ach_micrs	
	LEFT JOIN typ_table typAcc ON typAcc.subsys_code='MB' AND typAcc.tab_name='ach_acc_type' AND typAcc.code=ach_micrs.account_type
	WHERE ach_micrs.group_id in (SELECT DISTINCT rlmbgrpl.group_id FROM rlmbgrpl WHERE rlmbgrpl.member_id=@memberId)
	order by ach_micrs.last_mod_date desc--Modified by Selva K --(Added Order by) to get latest records on top.
	
	SELECT * FROM #MICRTemp
	
	--MICR Status
	SELECT ach_micrs_d.ach_micrs_d_id AS AccountMicrStatusId,
		ach_micrs_d.ach_micrs_id,
		ach_micrs_d.status_code AS StatusCode,
		typ_table.descr AS StatusDescr,
		ach_micrs_d.last_mod_date AS LastModDate,
		ach_micrs_d.last_mod_user AS LastModuser,
		ach_micrs_d.eff_date AS EffDate,
		ach_micrs_d.exp_date AS ExpDate

	 FROM ach_micrs_d 
	 INNER JOIN ach_micrs ON ach_micrs_d.ach_micrs_id=ach_micrs.ach_micrs_id
	 LEFT JOIN typ_table ON typ_table.subsys_code='MB' AND typ_table.tab_name='ach_stat_code' AND typ_table.code=ach_micrs_d.status_code
	 WHERE ach_micrs.group_id IN (SELECT DISTINCT rlmbgrpl.group_id FROM rlmbgrpl WHERE rlmbgrpl.member_id =@memberId) AND ach_micrs_d.ach_micrs_id=(SELECT TOP 1 AccountMICRId FROM #MICRTemp)
	 order by ach_micrs_d.last_mod_date desc --Modified by Selva K --(Added Order by) to get latest records on top.

	 DROP TABLE #MICRTemp

 SET NOCOUNT OFF
END