﻿
-- =============================================
-- Author:		<V.M.HEMANANTH>
-- Create date: <11/02/2016>
-- Description:	<Get the Plans realted to Group for Member Module>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetGroupPlansforMember] 
	-- Add the parameters for the stored procedure here
	(@GroupID INT,
	 @AsofDate DATETIME)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT rel_gppl.rel_gppl_id , 
	    rel_gppl.plan_id AS 'PlanID' , 
	       rel_gppl.eff_date AS 'EffDate' ,
		    rel_gppl.exp_date AS 'ExpDate' , 
		   rel_gppl.elig_opt ,
		    rel_gppl.elig_opt_dtl_bill ,
           rel_gppl.nnm_date , 
		   pl.plan_dsp_name AS 'PlanName' , 
		   typ_table.descr AS 'PlanType' , 
		   pl.ins_opt As 'Option', 
		   ins_opt.ins_opt_qual ,
		   pl.tiered_sw AS 'Tiread',
		   LTRIM(RTRIM(pl.ins_type)) As 'InsType'
		   FROM [plan] pl, ins_opt , 
           rel_gppl , typ_table WHERE rel_gppl.group_id = @GroupID AND  typ_table.code = pl.ins_type AND
		    ( typ_table.tab_name = 'ins_type' )
			AND ((typ_table.eff_date <= GETDATE() or ( typ_table.eff_date is NULL) ) 
			AND  (typ_table.exp_date > GETDATE() or ( typ_table.exp_date is NULL)) ) AND
		   ( pl.ins_opt =ins_opt.ins_opt ) AND ( pl.plan_id =rel_gppl.plan_id ) 
           AND ( ( rel_gppl.eff_date <= @AsofDate AND ( rel_gppl.exp_date > @AsofDate  OR rel_gppl.exp_date is null ) ) OR ( rel_gppl.eff_date > @AsofDate  AND 
          ( rel_gppl.exp_date > rel_gppl.eff_date OR rel_gppl.exp_date is null ) ) ) ORDER BY rel_gppl.rel_gppl_id , rel_gppl.plan_id , rel_gppl.eff_date 

END