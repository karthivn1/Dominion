﻿-- =============================================
-- Author:		<Mari Selvam Sornaraj>
-- Create date: <26-01-2017>
-- Description:	<This SP is used to Save the Changed Plan Details >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_ChangePlan]
(
@memberId INT=NULL,
@memberGroupPlanId INT=NULL,
@groupId INT=NULL,
@planId INT=NULL,
@effDate DATETIME=NULL,
@actionCode VARCHAR(100)=NULL,
@hUser VARCHAR(100)=NULL,
@SiP INT=NULL,
@rateCode VARCHAR(100)=NULL,
@NewMemberGroupPlanId	int output,
@Newhmsi	int output,
@WaitFlag varchar(1)
)
AS
BEGIN
SET NOCOUNT ON;
    
 
DECLARE @hmsi INT

UPDATE rlmbgrpl SET exp_gr_pl=@effDate, action_code =@actionCode where  mb_gr_pl_id=@memberGroupPlanId and exp_gr_pl IS NULL
 

 Declare @GroupParentID int, @GroupType varchar(2)
 set @GroupType = (select group_type from [group] where group_id=@groupId)
 if(@GroupType='SG')
 begin
 set @GroupParentID=(select group_parent from [group] where group_id=@groupId)
 Declare @CurrentDate datetime=GETDATE()
 exec mb_add_group_plan @effDate,@planId,@GroupParentID,@groupId,@hUser, @CurrentDate
 end

 SELECT @hmsi=msi+1 from sysdatetime  
 INSERT INTO rlmbgrpl ( member_id, group_id, plan_id, eff_gr_pl, action_code, h_datetime, h_msi, h_action, h_user, sub_in_plan)
 VALUES(@memberId,@groupId,@planId,@effDate,@actionCode,GETDATE(),@hmsi,@actionCode,@hUser,@SiP)
 SET @NewMemberGroupPlanId=SCOPE_IDENTITY()
 UPDATE sysdatetime set msi=msi+1 
 SELECT @hmsi=msi+1 from sysdatetime  

 INSERT INTO rlmbrt ( mb_gr_pl_id, rate_code, eff_rt_date, action_code, h_datetime, h_msi, h_action, h_user )
 VALUES (@NewMemberGroupPlanId,@rateCode,@effDate,@actionCode,GETDATE(),@hmsi,@actionCode,@hUser)
 set @Newhmsi=@hmsi
  SELECT @NewMemberGroupPlanId,@Newhmsi
 
 UPDATE sysdatetime set msi=msi+1 

 
 exec mb_add_cat_opt @NewMemberGroupPlanId,@memberId,@WaitFlag

	SET NOCOUNT OFF
END