﻿CREATE procedure [dbo].[usp_memberportal_forgotusernamedeails]
(
@lastname varchar(max) =null,
@email varchar(max),
@DOB datetime =null,
@value varchar(max)
)
As Begin
set nocount on
Declare @user_id int;
Declare @user_name varchar(max);
		
if(@value = 'Next')
		Begin
		If Exists (Select user_name from member_user_details where last_name=@lastname and email=@email and date_of_birth=convert(date,@DOB))
	
			Begin
		
			set @user_name=(Select user_name from member_user_details where last_name=@lastname and email=@email and date_of_birth=convert(date,@DOB));
			print '@user_name';
			select 'The User Name is  -' + @user_name + ' If you have any questions, please contact our Member Services Department at 888-518-5338';
			End
		Else
		    Begin
			select 'No Account matches with '+ @email;
			End
			
		End
else
if(@value= 'Email Password')
		Begin	

		If Exists (select user_id from member_user_details Where lower(email)=lower(@email ))
				Begin
				set @user_id=(select user_id from member_user_details Where lower(email)=lower(@email ));
				insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@user_id,8,1001,0,convert(date,getdate()));
				select 'Thank you for your request. Please check your email to receive your user account details. If you have any questions, please contact our Member Services Department at 888-518-5338.” '
				End
        Else
		       Begin
			   select  'No Account matches with '+ @email;
			   End
		End

set nocount off
end