﻿CREATE PROCEDURE [dbo].[usp_AutoDebitFlagReport]
(
@fromDate DATETIME,
@toDate DATETIME
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @AutoDebitFlag TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(MAX),
AutoDebit VARCHAR(MAX),
ChangeDate VARCHAR(MAX),
ChangedBy VARCHAR(MAX)
)

INSERT INTO @AutoDebitFlag(GroupID ,AutoDebit ,ChangeDate,ChangedBy)

SELECT CONVERT(varchar(MAX), ad.group_id),CASE ad.autodebit WHEN 1 THEN 'Yes' ELSE 'No' END,	
CONVERT(nvarchar(MAX),ad.modified_date, 101)+' '+CONVERT(nvarchar(MAX),FORMAT(CAST(ad.modified_date AS DATETIME),'hh:mm:ss tt')),RTRIM(gud.first_name) +' '+RTRIM(gud.middle_name)+' '+RTRIM(gud.last_name) from autodebit_details ad 
LEFT JOIN group_user_details gud on ad.modified_by =gud.user_id 
 WHERE ad.modified_date BETWEEN @fromDate AND @toDate
SELECT * FROM @AutoDebitFlag

SET NOCOUNT OFF 
END