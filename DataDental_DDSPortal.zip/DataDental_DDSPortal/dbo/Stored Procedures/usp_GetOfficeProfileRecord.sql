﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetOfficeProfileRecord]
	-- Add the parameters for the stored procedure here
@BatchId INT,
@EventId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for procedure here

SELECT f.office_profile_id AS RequestId,
		f.facility_id AS SysRecId,
		f.category AS SubSysCode,
		f.req_value AS RequestValue
		FROM provider_office_profile f
		JOIN batch_process_details b ON f.office_profile_id=b.ref_id
		WHERE b.batch_id=@BatchId
		AND b.event_id=@EventId

END