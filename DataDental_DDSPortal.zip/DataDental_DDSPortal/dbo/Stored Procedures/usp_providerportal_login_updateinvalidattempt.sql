﻿CREATE PROCEDURE [dbo].[usp_providerportal_login_updateinvalidattempt]
(
@userId INT
)
AS
BEGIN
SET NOCOUNT ON;
Declare @loginatempt INT;
Declare @isLockattempt INT;
Declare @username varchar(max)=(select user_name from provider_user_details where user_id= @userId);
set @loginatempt=(select failed_login_attempt from provider_user_details where user_id= @userId)

If(@loginatempt  IS NULL or @loginatempt = 2 or @loginatempt =0)
Begin
update provider_user_details set 
  failed_login_attempt = ISNULL(failed_login_attempt,0)+1 where user_name= @username 
End

If(@loginatempt = 1)
Begin
update provider_user_details set 
  failed_login_attempt = ISNULL(failed_login_attempt,0)+1 
   where user_name= @username 

End

set @isLockattempt=(select failed_login_attempt from provider_user_details where user_id= @userId )

If(@isLockattempt = 3)
Begin
update provider_user_details set status_id  = 3  where user_name= @username  

End

select status_id as Status,failed_login_attempt as LoginAttempt from provider_user_details  where user_id= @userId 

SET NOCOUNT OFF
END