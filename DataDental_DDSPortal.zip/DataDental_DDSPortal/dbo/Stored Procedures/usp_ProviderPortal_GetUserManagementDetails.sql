﻿CREATE proc [dbo].[usp_ProviderPortal_GetUserManagementDetails]
as
begin

select usr.user_id UserID,usr.user_name UserName,usr.facility_id FacilityID,usr.facility_tax_id TaxID,usr.last_name LastName,rm.role_name Portal,CASE WHEN sta.status='Pending' THEN 'Change Password' ELSE sta.status END Status,
'License' License,usr.email Email, usr.status_id StatusID
from provider_user_details usr inner join user_status_master sta on usr.status_id=sta.status_id  and sta.portal_type='pvr'
join role_master rm on rm.role_id=usr.role_id and rm.portal_type='pvr'

end