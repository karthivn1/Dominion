﻿

-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <16-01-2017>
-- Description:	<This sp gets the Member Facility Details by passing MemberGroupPlanId and Ratecode>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetChangeFacilityMemberDetailsByMemberGroupPlanId] 
(
@MemberGroupPlanId INT,
@RateCode NVARCHAR(2)
)
AS
BEGIN
SET NOCOUNT ON;

	SELECT member.member_code AS MemberCode,   
         member.last_name AS LastName,   
         member.first_name AS FirstName,   
         member.date_of_birth AS DateOfBirth,   
         rlplfc.facility_id AS FacilityId,   
         facility.fc_name AS FacilityName,   
         rlplfc.eff_date AS PlanFacilityEffectiveDate,                 
         rlplfc.exp_date AS PlanFacilityExpireDate,   
         rlplfc.action_code AS PlanFacilityActionCode,   
         rlplfc.rlplfc_id AS RelPlanFaclityId,
		 rlplfc.mb_gr_pl_id AS MemGroupPlanId,   
         member.member_id AS MemberId,   
         member.family_id AS FamilyId,
		 CAST(CASE WHEN (SELECT num_facil FROM pl_rat WHERE rate_code=@RateCode) <= 1 THEN 'Yes' ELSE 'No' END AS NVARCHAR) AS TransferMessage
    FROM rlplfc 
	     INNER JOIN facility ON rlplfc.facility_id = facility.fc_id  
         INNER JOIN member ON  member.member_id = rlplfc.member_id           
   WHERE rlplfc.mb_gr_pl_id = @MemberGroupPlanId AND rlplfc.exp_date is NULL


SET NOCOUNT OFF
END