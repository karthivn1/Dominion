﻿CREATE PROCEDURE [dbo].[usp_ChangePassword]
(
@UserID INT = NULL,
@UserName VARCHAR(MAX),
@Password VARCHAR(MAX),
@NewPassword VARCHAR(MAX),
@HashValue VARCHAR(MAX)
)
AS
BEGIN
SET NOCOUNT ON;

 update group_user_details set password_hash=@NewPassword,status_id=1,is_firstlogin=null, password_reset_date=getdate() WHERE user_name =@UserName 
 SET @UserID=(SELECT user_id from group_user_details where user_name =@UserName)
  
 --INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
 --VALUES (@UserID,1,1001,0,CONVERT(date,GETDATE()));

 SELECT user_id UserID,user_name UserName,temp_password Password from group_user_details WHERE user_id=@UserID

SET NOCOUNT OFF;
END