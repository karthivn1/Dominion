﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_getUserInfo_provider 541725982
-- =============================================
CREATE PROCEDURE [dbo].[usp_getUserInfo_provider] 
	-- Add the parameters for the stored procedure here
@tinNumber varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @TempRec AS TABLE 
(
fc_id INT null,
fc_tax_id varchar(50) null,
zip INT null
)


IF EXISTS(Select *
	From facility_sec f
	where f.fc_tax_id=@tinNumber AND f.tin='Y')
BEGIN

INSERT INTO @TempRec
SELECT f.fc_id,f.fc_tax_id,a.zip
	--INTO #tempRec
	FROM facility_sec f
	JOIN address_sec a ON a.sys_rec_id=f.fc_id AND a.subsys_code='FC'
	WHERE a.addr_type='L' AND fc_tax_id=@tinNumber AND tin='Y' 
	ORDER BY 1 DESC

IF EXISTS(Select TOP 1 *
		From fc_assoc_sec f
		JOIN @TempRec t ON t.fc_id=f.fc_id
		JOIN providers_sec p ON p.pv_id=f.pv_id
		WHERE f.exp_date IS NULL
		ORDER BY 1 DESC)
		BEGIN
				IF NOT EXISTS(Select *
				From provider_user_details p
				where facility_tax_id=@tinNumber AND p.role_id=9)
				BEGIN
				INSERT INTO provider_user_details([user_name],status_id,facility_id,facility_tax_id,facility_zip_code,last_name,failed_login_attempt,
				created_date,role_id,is_firstlogin)
	
				Select TOP 1 p.pv_id,1 as status_id,t.fc_id,@tinNumber AS taxId,t.zip,p.last_name,0 AS failed_login_attempt,GETDATE() AS created_date,9 role_id,0 is_firstlogin
				From fc_assoc_sec f
				JOIN @TempRec t ON t.fc_id=f.fc_id
				JOIN providers_sec p ON p.pv_id=f.pv_id
				WHERE f.exp_date IS NULL
				ORDER BY 1 DESC

				--SELECT TOP 1 p.pv_id,1 as status_id,t.fc_id,@tinNumber AS taxId,t.zip,p.last_name,0 AS failed_login_attempt,GETDATE() AS created_date,9 role_id,0 is_firstlogin
				--FROM providers_sec p
				--JOIN @TempRec t ON t.fc_tax_id=p.tax_id
				--ORDER BY 1 DESC
	
				END
		END
END
--ELSE
--BEGIN
--	RAISERROR ('Provider not found',16,1);
--END

select user_id as ID, user_name as username, password_hash as PasswordHash,status_id as Status,temp_password as TempPassword,
role_id as UserRoleId,is_firstlogin as ISFirstLogin,facility_id as Facility_ID, facility_tax_id as Tax_ID, facility_zip_code as Zip 
from provider_user_details  where facility_tax_id=@tinNumber AND role_id=9
	
END