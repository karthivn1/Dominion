﻿CREATE PROCEDURE [dbo].[usp_GroupPortal_GetGroupDetails]
(
@UserName varchar(max)
) 
AS 
Begin
SET NOCOUNT ON 
Declare @userid int;
Declare @zip varchar(max);
Declare @email varchar(max);
Declare @lname varchar(max);
Declare @groupid int;
Declare @plan_id int;
Declare @status varchar(max);
Declare @roleid varchar(max);

Declare @roledetails Table
(roleid int);
set @userid= (select user_id from group_user_details where user_name=@UserName);

insert into @roledetails (roleid) 
select role_id  from group_user_details where  user_id=@userid;

      If exists( select * from @roledetails where roleid =3)
     Begin
        If exists(select group_id,plan_id  from group_user_details where user_id =@userid and group_id IS NOT NULL and group_id <> 0)
		  begin
  
		 select @email=email, @lname=last_name, @zip=group_zip,@roleid =role_id from group_user_details where  user_id=@userid
				select grp.group_id as GroupID,(RTRIM (grp.group_name) + ' (' + RTRIM (pln.plan_name) + ')')  as GroupName, grp.group_type as GroupType , pln.plan_id as PlanID,pln.plan_name as PlanName,RTRIM(ISNULL(pln.ins_type,''))+RTRIM(ISNULL(pln.ins_opt,'')) as PlanType 
				from contact_sec as contact
				join [address_sec] addr on addr.sys_rec_id=contact.sys_rec_id
				join [group_sec] grp on grp.group_id=addr.sys_rec_id
				join group_status_sec sta on grp.group_id=sta.group_id
				join rel_gppl_sec reg on reg.group_id=grp.group_id
				join [plan_sec] pln on pln.plan_id=reg.plan_id
				where contact.subsys_code='GP' and contact.lname=@lname and contact.addr_type='L'
				--and addr.zip=@zip
				 and sta.group_status='A4' and addr.subsys_code='GP' and contact.email=@email

		End
 else
		 Begin
 
		 set @status ='DDS User with no previous groupid';
 
		  DECLARE @Err as table
		(
		 Error_Msg varchar(max)
		)

		INSERT INTO @Err(Error_Msg)VALUES(@status)
		SELECT * FROM @Err
		 End
End

 SET NOCOUNT OFF

End