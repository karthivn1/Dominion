﻿-- =============================================
-- Author:		<Venkatesh J>
-- Create date: <20-Feb-2017>
-- Description:	<This stored procedure is used to get the claim history details with address>
-- =============================================
CREATE PROCEDURE [dbo].[usp_claim_GetClaimHistory]
(
@claimId INT
--,@pvrId INT
)

AS

BEGIN
SET NOCOUNT ON	
 DECLARE @NotesCount INT;
 DECLARE @ActionFollowUpCount INT;
 SET @NotesCount = (SELECT COUNT(notes_id) from notes where sub_sys = 'CL' and external_key = @claimId)
 SET @ActionFollowUpCount = (SELECT COUNT(follow_id) from follow where sub_sys = 'CL' and external_key = @claimId)

SELECT DISTINCT 
		 claim_h.claim_id as ClaimId,   
         claim_h.claim_no as ClaimNo, 
		 LTrim(RTrim(claim_h.claim_status)) as ClaimStatus,
		 claim_h.received_date as ReceiveDate,  
		 LTrim(RTrim(claim_h.alt_id)) as AltId,   
		 LTrim(RTrim(claim_h.document_no)) as DocNo,
		 claim_h.approval_date as Approved,
		 claim_h.use_by as UseBy,   
		 claim_h.x_rays_rqd as XRay, 
		 claim_h.returned_date as Returned,   
		 claim_h.reopen_date as Reopened,   
		 [plan].ins_type as InsType,    
		 object_queue.status as ProcessStatus, 
		 claim_h.preauth_switch as PreAuth,   
		 claim_h.preauth_number as Num,
		 claim_h.svc_date_beg as ServiceBegin,   
         claim_h.svc_date_end as [End],
		 LTrim(RTrim(typEx.descr)) as Pay,
		 object_queue.service_requested as Task,
		 object_queue.service as RequiredService,
		 claim_h.emergency_switch as [Emergency],
		 LTrim(RTrim(typ.descr)) as ClaimType,   
         LTrim(RTrim(typSp.descr)) as Speciality,
		 case when claim_h.manual_entry=1 
		 then 'Manual' else 'Electronic' end as EntryType
		 		
    FROM claim_h 
       LEFT OUTER JOIN facility facility_b ON  claim_h.fc_id=facility_b.fc_id
	   LEFT OUTER JOIN providers ON  claim_h.prv_id=providers.pv_id
       LEFT OUTER JOIN rlplfc ON rlplfc.facility_id = facility_b.fc_id and claim_h.rlplfc_id = rlplfc.rlplfc_id
       LEFT OUTER JOIN pv_license ON pv_license.pv_id = claim_h.prv_id
       LEFT OUTER JOIN object_queue ON claim_h.claim_id= object_queue.object_id
       LEFT OUTER JOIN rlmbgrpl ON claim_h.mbgrpl_id = rlmbgrpl.mb_gr_pl_id   
       LEFT OUTER JOIN member member_a ON member_a.member_id = rlmbgrpl.member_id   
       LEFT OUTER JOIN member member_b ON rlplfc.member_id = member_b.member_id   
       LEFT OUTER JOIN  [group] ON [group].group_id = rlmbgrpl.group_id   
       LEFT OUTER JOIN  [plan] ON  [plan].plan_id = rlmbgrpl.plan_id 
	   LEFT OUTER JOIN  typ_table typ on typ.code=claim_h.type and typ.subsys_code='CL' and typ.tab_name='spcl_type'
	   LEFT OUTER JOIN  typ_table typSp on typSp.code=claim_h.speciality_type and typSp.subsys_code='CL' and typSp.tab_name='specialist'
	   LEFT OUTER JOIN typ_table_exp typEx on typEx.code=claim_h.pay_prv_switch and typEx.subsys_code='CL' and typEx.tab_name='pay_sw'
    WHERE claim_h.claim_id=ISNULL(@claimId, claim_h.claim_id)
	
	SELECT  DISTINCT
		 member_a.member_ssn as SubExtId,   
		 LTrim(RTrim(isnull(member_a.first_name,'')))+' '+ LTrim(RTrim(isnull(member_a.middle_init,''))) +' '+ LTrim(RTrim(isnull(member_a.last_name,''))) as Name,   
		 rlmbgrpl.plan_id as PlanId,  
		 LTrim(RTrim([plan].plan_dsp_name)) as PlanName,   
		 LTrim(RTrim(member_a.first_name)) as PatientName, 
		 LTrim(RTrim(facility_b.fc_name)) as AssignedFacility, 
		 claim_h.prv_id as ProviderId,   
		 (rtrim(ltrim(isnull(providers.last_name,'')))+' '+ rtrim(ltrim(isnull(providers.first_name,''))) +' '+ rtrim(ltrim(isnull(providers.middle_init,'')))) as ProviderName,
		 claim_h.fc_id as FacilityId,   
		 LTrim(RTrim(facility_b.fc_name)) as FacilityName,
		  member_a.member_id as MemberId,
		 (SELECT COUNT(notes_id) from notes where sub_sys = 'CL' and external_key =  member_a.member_id ) AS NotesCount,
		 --(SELECT COUNT(notes_id) from notes where sub_sys = 'MB' and external_key =  member_a.member_id ) AS MemberNotesCount,
		  (SELECT COUNT(notes_id) from notes N INNER JOIN member MB on MB.member_id = N.external_key  and N.sub_sys = 'MB' and MB.family_id = member_a.member_id) AS MemberNotesCount,
		  @ActionFollowUpCount AS ActionFollowUpCount,
		  (select count(*) from claim_d where claim_id=@claimId and lower(rtrim(ltrim(status)))='denied') as ResubmitEnabled 
		 into #temp
	FROM claim_h 
			LEFT OUTER JOIN facility facility_b ON facility_b.fc_id = claim_h.fc_id
			LEFT OUTER JOIN providers ON providers.pv_id = claim_h.prv_id
		    LEFT OUTER JOIN rlplfc ON facility_b.fc_id = rlplfc.facility_id and claim_h.rlplfc_id = rlplfc.rlplfc_id
			LEFT OUTER JOIN pv_license ON pv_license.pv_id = claim_h.prv_id and claim_h.pvlic_id = pv_license.pv_licid
			LEFT OUTER JOIN object_queue ON object_queue.object_id = claim_h.claim_id
			LEFT OUTER JOIN rlmbgrpl ON claim_h.mbgrpl_id = rlmbgrpl.mb_gr_pl_id   
			LEFT OUTER JOIN member member_a ON member_a.member_id = rlmbgrpl.member_id   
			LEFT OUTER JOIN member member_b ON rlplfc.member_id = member_b.member_id   
			LEFT OUTER JOIN [group] ON  [group].group_id = rlmbgrpl.group_id   
			LEFT OUTER JOIN [plan] ON  [plan].plan_id = rlmbgrpl.plan_id
   WHERE claim_h.claim_id=ISNULL(@claimId, claim_h.claim_id) 

	SELECT * 
	FROM #temp		

	SELECT addr.address_id								AS 'AddressId',             
             Rtrim(Ltrim(addr.addr_type))				AS 'AddressType', 
             rtrim(ltrim(typ.descr))                    AS 'AddressTypeDescription', 
             rtrim(ltrim(addr.addr1))                   AS 'AddressLine1', 
             rtrim(ltrim(addr.addr2))                   AS 'AddressLine2', 
             rtrim(ltrim(addr.zip))                     AS 'ZIP', 
             rtrim(ltrim(addr.city))                    AS 'City', 
             rtrim(ltrim(addr.state))                   AS 'State', 
             rtrim(ltrim(addr.county))                  AS 'County', 
             rtrim(ltrim(addr.country))                 AS 'Country',           
             case 
               when addr.mail = 'Y' then 'Yes' 
               else 'No' 
             end										AS 'Undeliverable' 
      FROM   address addr (NOLOCK)             
             INNER JOIN typ_table typ (NOLOCK) 
                     ON typ.code = addr.addr_type 
                        and typ.subsys_code = addr.subsys_code 
   WHERE addr.subsys_code = 'PV'  
          AND addr.sys_rec_id = (SELECT TOP 1 ProviderId FROM #temp)
          AND typ.subsys_code = 'PV' AND typ.tab_name = 'address' 	

SET NOCOUNT OFF
END