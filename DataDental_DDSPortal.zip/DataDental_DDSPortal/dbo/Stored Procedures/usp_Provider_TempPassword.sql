﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--exec usp_Provider_TempPassword 'K#e93qL$@T4y',28
-- =============================================
CREATE PROCEDURE [dbo].[usp_Provider_TempPassword]
	-- Add the parameters for the stored procedure here
@password VARCHAR(50),
@userId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @value VARCHAR(50)=null;

    -- Insert statements for procedure here
IF EXISTS(SELECT p.[user_id]
	FROM provider_user_details p
	WHERE p.[user_id]=@userId)
	BEGIN
		SELECT @value=IIF(p.temp_password_unhashed IS NULL,@password,p.temp_password_unhashed)
			FROM provider_user_details p
			WHERE p.[user_id]=@userId

		--SELECT *
		UPDATE p SET p.temp_password_unhashed=@value
			FROM provider_user_details p
			JOIN provider_user_details  s ON s.user_name=p.user_name
			WHERE p.[user_id]=@userId AND p.temp_password_unhashed IS NULL

	END
	ELSE
	BEGIN
		RAISERROR('Unkown user details',16,1)
	END

SELECT @value AS value

END