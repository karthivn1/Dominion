﻿CREATE PROC [dbo].[usp_GroupPortal_AddGroupDetails]
(
@GroupUserMapping dbo.[GroupUserDetailsMapping] readonly
)
AS
BEGIN
Begin try
BEGIN TRAN
Declare @userid int;
declare @user varchar(100)
SET @user=(select top 1 username from @GroupUserMapping)
SET @userid= (select user_id from group_user_details where user_name = @user)
INSERT INTO group_user_mapping(user_id,group_id,status)
SELECT @userid,groupid,isremove from @GroupUserMapping where status='New' OR (status='old' AND isremove=0)
AND groupid in (select group_id from group_user_mapping where group_id not in (SELECT groupid from @GroupUserMapping)) 
UPDATE group_user_mapping SET status=0 
WHERE group_id in (select group_id from group_user_mapping where group_id in (SELECT groupid from @GroupUserMapping)) 
COMMIT
end try
Begin Catch
ROLLBACK
Select 'Fail'
End catch
SELECT 'Success'
END