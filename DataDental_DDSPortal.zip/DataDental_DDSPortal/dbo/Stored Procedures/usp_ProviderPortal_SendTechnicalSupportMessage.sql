﻿CREATE PROC [dbo].[usp_ProviderPortal_SendTechnicalSupportMessage]
(
@username VARCHAR(MAX),
@message VARCHAR(MAX),
@portalType VARCHAR(MAX)
)
AS
BEGIN
DECLARE @userid INT; 
Declare @roleid int = CASE @portalType WHEN 'Dominion' THEN (select role_id from role_master where role_name ='Dominion Provider')
WHEN 'CBC' THEN (select role_id from role_master where role_name ='CBC Provider')
ELSE
(select role_id from role_master where portal_type='pvr' and role_name ='Premera Provider')
END
SET @userid=(select user_id from provider_user_details where user_name =@username and role_id=@roleid)
INSERT into provider_technical_support values(@userid,@message,CONVERT(date,GETDATE()))
INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
VALUES (SCOPE_IDENTITY(),15,1001,0,CONVERT(date,GETDATE()));
SELECT 'Success' 
END