﻿CREATE procedure [dbo].[usp_EditUserSearch] 
(
@username as Varchar(max)=NULL
)
AS
Begin
SET NOCOUNT ON 
Declare @userid int;
Declare @email varchar(max);
Declare @lname varchar(max);
Declare @groupid int;
Declare @plan_id int;

set @userid= (select user_id from group_user_details where user_name=@username);
select @email=email, @lname=last_name from group_user_details where  user_id=@userid

select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,tbl_udetails.Role as Role,tbl_udetails.Role_Id as RoleId,tbl_udetails.EmailNotifications ,
tbl_udetails.Phone,tbl_udetails.Email,tbl_udetails.MiddleInitial ,Status as User_Status
from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,
tbl_userdetails.middle_name as MiddleInitial, tbl_userdetails.phone as Phone,tbl_userdetails.email_notification as EmailNotifications ,
tbl_userdetails.date_of_birth as DOB,tbl_grp.group_name as GroupName, 
tbl_status.status as Status,
role_master.role_name as  Role,
tbl_userdetails.email as Email,tbl_userdetails.role_id as Role_Id
from group_user_details as tbl_userdetails
inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
inner join role_master on tbl_userdetails.role_id =role_master .role_id and (role_master.portal_type='grp' or role_master.portal_type='common')
Left join [group_sec] as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id where status in('Active', 'Pending','Deactivated'))  tbl_udetails
where  (tbl_udetails.UserName=@username)  

select distinct grp.group_id as Group_Id,RTRIM (grp.group_name) as Group_Name, grp.group_type ,0 as Plan_Id,'' as Plan_Name,'Old' RecordStatus
from contact_sec as contact 
join [address_sec] addr on addr.sys_rec_id=contact.sys_rec_id and addr.subsys_code=contact.subsys_code
join [group_sec] grp on grp.group_id=addr.sys_rec_id
join group_status_sec sta on grp.group_id=sta.group_id
where contact.subsys_code='GP' and contact.lname=@lname and contact.addr_type='L'				
and sta.group_status='A4' and contact.email=@email and contact.sys_rec_id not in (select group_id from [group_user_mapping] where status=0 and user_id=@userid)
--UNION 
--SELECT grp.group_id as Group_Id,RTRIM (grp.group_name) as Group_Name, grp.group_type , 0 as Plan_Id,'' as Plan_Name,'Old' RecordStatus
--from  [group_user_mapping] gup 
--join [group_sec] grp on grp.group_id=gup.group_id
--join group_status_sec sta on grp.group_id=sta.group_id
--WHERE gup.user_id=@userid and sta.group_status='A4' and gup.status=1

SET NOCOUNT OFF
End