﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <24-10-2016>
-- Description:	<This sp gets the List for Wait Tab by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetWaitTabListForMember]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;

SELECT 	--mbr_pl_cat.mbr_pl_cat_id,
		--mbr_pl_cat.gppl_cat_id,
		gppl_cat.cat_name AS CategoryName,
		--gppl_cat.rel_gppl_id,
		gppl_cat.waiting_period AS WaitingPeriod,
		gppl_cat.eff_date AS CategoryEff,
		--member.middle_init,
		member.first_name + member.last_name AS MemberName,
		--member.oed,
		--mbr_pl_cat.mbgrpl_id,
		--mbr_pl_cat.member_id,
		mbr_pl_cat.lock AS Lock
		--,mbr_pl_cat.oed,
		--mbr_pl_cat.h_user,
		--mbr_pl_cat.h_datetime

FROM	gppl_cat
		LEFT JOIN mbr_pl_cat ON mbr_pl_cat.gppl_cat_id = gppl_cat.gppl_cat_id
		LEFT JOIN member ON mbr_pl_cat.member_id =  member.member_id

WHERE  member.member_id=@memberId
	--and mbr_pl_cat.mbgrpl_id =

SET NOCOUNT OFF;
END