﻿




-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <06-10-2016>
-- Description:	<This sp gets the List of Plan based on member and group by passing memberId and GroupId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetPlanListByMemberAndGroup] --657306,317
(
@memberId INT,
@groupId INT
)
AS
BEGIN
SET NOCOUNT ON;	
	DECLARE @MemGroupPlanId INT
	
	
	 
	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.plan_dsp_name AS PlanName,
		rlMebGroupPlan.sub_in_plan AS Sip,
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		(typeMa.descr) AS PlanAction,
		--rlMebGroupPlan.action_code AS PlanAction,
		rlMebGroupPlan.mb_gr_pl_id AS MemGrpPlnId,
		rlMebRate.rate_code AS RC,
		rlMebRate.eff_rt_date AS RateEffective,
		rlMebRate.exp_rt_date AS RateExpired,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName,
		facility.fc_id as 'FacilityId',
		facility.fc_name as 'FacilityName',
		tblPlan.ins_opt as 'Option',
		LTRIM(RTRIM(tblPlan.ins_type)) as 'InsType'
	   ,ROW_NUMBER() OVER(ORDER BY rlMebGroupPlan.exp_gr_pl ASC) AS RowNumber 
	INTO #PlanTemp
	from rlmbgrpl rlMebGroupPlan  
	LEFT JOIN [plan] tblPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	INNER JOIN typ_table typeMa ON typeMa.subsys_code='MB' AND typeMa.tab_name='action_code' AND typeMa.code=rlMebGroupPlan.action_code	
	LEFT JOIN rlplfc relPlanFacility ON relPlanFacility.mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id AND relPlanFacility.exp_date IS NULL AND relPlanFacility.member_id = @memberId
	LEFT JOIN facility ON facility.fc_id = relPlanFacility.facility_id
	WHERE rlMebGroupPlan.group_id=@groupId AND rlMebGroupPlan.member_id=@memberId AND rlMebRate.exp_rt_date IS NULL
	

	SELECT * FROM #PlanTemp ORDER BY RowNumber ASC

	--SET @MemGroupPlanId= (SELECT TOP 1 rlMebGroupPlan.mb_gr_pl_id
	--			  from [plan] tblPlan
	--			  LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	--			  LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	--			  INNER JOIN typ_table typeMa ON typeMa.subsys_code='MB' AND typeMa.tab_name='action_code' AND typeMa.code=rlMebGroupPlan.action_code
	--			  WHERE rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId AND rlMebRate.exp_rt_date IS NULL  
	--			  ORDER BY rlMebGroupPlan.eff_gr_pl ASC, rlMebGroupPlan.exp_gr_pl ASC)

	SET @MemGroupPlanId=(SELECT MemGrpPlnId from #PlanTemp WHERE RowNumber=1)
	
	--Get Member Status
	SELECT dbo.udf_member_getMemberStatusByMemberGroupPlanID(@MemGroupPlanId) as [Status]

	--SET @MemGroupPlanId=(SELECT TOP 1 MemGrpPlnId FROM #PlanListTemptable )

	--Plan Details & Facility Details
	EXEC usp_mem_GetMemberPlanAndFacilityByMemberGroup @memberId,@MemGroupPlanId

	DROP TABLE #PlanTemp
	/*
	--Plan Details
	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.ins_opt AS InsOptionType,
		LTRIM(RTRIM((typePl.descr))) +' '+ insOpt.ins_opt_sd AS TypeorOption,
		tblPlan.plan_dsp_name AS PlanName,
		tblPlan.tiered_sw AS Tiered,		
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		LTRIM(RTRIM(typeMb.descr)) AS PlanAction,
		--rlMebGroupPlan.action_code AS PlanAction,
		planRate.rate_short_desc AS Rate,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName,
		rlMebGroupPlan.sub_in_plan AS SubinPlane,
		rlMebRate.eff_rt_date AS RateEffectiv,
		rlMebRate.exp_rt_date AS RateExpired,
		(typeRT.descr) AS RateAction
		
	from [plan] tblPlan
	INNER JOIN ins_opt insOpt ON insOpt.ins_opt=tblPlan.ins_opt
	LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	LEFT JOIN pl_rat planRate ON planRate.rate_code=rlMebRate.rate_code
	LEFT JOIN typ_table typePl ON typePl.subsys_code='PL' AND typePl.tab_name='ins_type' AND typePl.code=tblPlan.ins_type
	LEFT JOIN typ_table typeMb ON typeMb.subsys_code='MB' AND typeMb.tab_name='action_code' AND typeMb.code=rlMebGroupPlan.action_code
	LEFT JOIN typ_table typeRT ON typeRT.subsys_code='MB' AND typeRT.tab_name='action_code' AND typeRT.code=rlMebRate.action_code
	WHERE rlMebGroupPlan.mb_gr_pl_id=@MemGroupPlanId --tblPlan.plan_id=@planId 	AND rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId 
	AND rlMebRate.exp_rt_date IS NULL

	--Facility Details
	SELECT DISTINCT Facilty.fc_id AS FacilityID,
		   Facilty.fc_name AS FacilityName,
		   relPlanFacility.eff_date AS EffDate,
		   relPlanFacility.exp_date AS ExpDate,
		   LTRIM(RTRIM((typeFc.descr))) AS "Action"

	 FROM facility Facilty
	 INNER JOIN rlplfc relPlanFacility ON relPlanFacility.facility_id=Facilty.fc_id
	 INNER JOIN rlmbgrpl relMebGroupPlan ON relMebGroupPlan.mb_gr_pl_id=relPlanFacility.mb_gr_pl_id
	 LEFT JOIN typ_table typeFc ON typeFc.subsys_code='MB' AND typeFc.tab_name='action_code' AND typeFc.code=relPlanFacility.action_code
	 WHERE  relMebGroupPlan.mb_gr_pl_id=@MemGroupPlanId AND relPlanFacility.member_id=@memberId AND relPlanFacility.exp_date IS NULL
	 -- relMebGroupPlan.group_id=@groupId AND

	 */

SET NOCOUNT OFF
END