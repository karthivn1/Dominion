﻿



-- =============================================
-- Author:		<Mari Slevam Sornaraj>
-- Create date: <22-12-2016>
-- Description:	<This stored procedure is used to get list  of annual coupon>
-- =============================================
--exec [usp_mem_GetAnnualCouponTotalCount] null
CREATE PROCEDURE [dbo].[usp_mem_GetAnnualCouponTotalCount]
(
 @totalCount int output,
 @renewDate datetime
)
AS
BEGIN
SET NOCOUNT ON
	
	Declare @count1 int =(select count(*)  
			from [group] g , group_status gs ,typ_table t
			where g.group_id = gs.group_id
 			and  (gs.group_id = g.group_id and
			(gs.eff_date <= g.next_renew_date
			and (gs.exp_date > g.next_renew_date or
 			gs.exp_date is null))) and
			(g.group_type = 'SG' or
			g.group_type = 'SB') AND
			( g.bill_type <> 'AH') AND
			(t.subsys_code = 'GP' and t.tab_name = 'group_status'
			and gs.group_status = t.code and t.action = 'A4' ) and
			g.group_id not in (select a.group_id from annual_proc a
			where (a.flag = 'N' or a.flag is null) ) and g.next_renew_date = @renewDate)


Declare @count2 int =(select count(*) 
			from [group] g , group_status gs ,typ_table t
			where g.group_id = gs.group_id
			and  (gs.group_id = g.group_id and
			(gs.eff_date <= g.next_renew_date
			and (gs.exp_date > g.next_renew_date or
 			gs.exp_date is null))) and
			(g.group_type = 'SG' or
			g.group_type = 'SB') AND
			( g.bill_type <> 'AH') AND
			(t.subsys_code = 'GP' and t.tab_name = 'group_status'
			and gs.group_status = t.code and t.action = 'A4' ) and
			g.group_id  in (select a.group_id from annual_proc a
			where (a.flag = 'N' or a.flag is null) ) and g.next_renew_date = @renewDate)


 set @totalCount=isnull(@count1,0)+isnull(@count2,0)

 
SET NOCOUNT OFF
END