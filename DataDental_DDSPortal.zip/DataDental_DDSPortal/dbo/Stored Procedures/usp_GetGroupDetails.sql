﻿CREATE PROCEDURE [dbo].[usp_GetGroupDetails] 
(
@UserID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 


DECLARE @GroupDetails TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(50),
GroupName VARCHAR(MAX),
GroupType VARCHAR(MAX),
PlanID VARCHAR(MAX),
PlanName VARCHAR(MAX),
PlanType VARCHAR(MAX)
)


INSERT INTO @GroupDetails(GroupID,GroupName,GroupType,PlanID,PlanName,PlanType)

select grp.group_id, RTRIM(grp.group_name)+'('+RTRIM(pln.plan_name)+')', grp.group_type, pln.plan_id,RTRIM(pln.plan_name),pln.ins_opt 
from contact_sec contact
join [address_sec] addr on addr.sys_rec_id=contact.sys_rec_id
join [group_sec] grp on grp.group_id=addr.sys_rec_id
join group_status_sec sta on grp.group_id=sta.group_id
join rel_gppl_sec reg on reg.group_id=grp.group_id
join [plan_sec] pln on pln.plan_id=reg.plan_id
where contact.subsys_code='GP' and contact.lname='Rivera' and contact.addr_type='L'
and addr.zip='19425' and sta.group_status='A4' and addr.subsys_code='GP' 
and (contact.email='' OR contact.email='test@test.com')

SELECT * FROM @GroupDetails

SET NOCOUNT OFF 
END