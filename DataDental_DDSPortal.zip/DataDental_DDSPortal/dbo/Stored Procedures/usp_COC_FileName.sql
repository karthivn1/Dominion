﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--DECLARE @result INT=0
--DECLARE @FileName nvarchar(100)
--EXEC @result=usp_COC_FileName 1,69,@FileName out
--SELECT @FileName,@result
-- =============================================
CREATE PROCEDURE [dbo].[usp_COC_FileName]
@GroupId INT,
@PlanId INT,
@MemberId INT=0,
@FileName nvarchar(100) OUT		
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON
	DECLARE @result INT=0

IF EXISTS(Select g.group_id, g.group_parent, g.close_territory
	From group_sec g
	JOIN group_sec Parent ON g.group_parent=Parent.group_id
	AND Parent.close_territory=33 
	WHERE g.group_id=@GroupId)
	BEGIN
		EXEC usp_GetHCR_COC_FileName @GroupId,@PlanId,@MemberId,@FileName out
		SET @result=1
	END
	ELSE
	BEGIN
		EXEC usp_GetID_COC_FileName @GroupId,@PlanId,@MemberId,@FileName out
	END	
	RETURN @result
END