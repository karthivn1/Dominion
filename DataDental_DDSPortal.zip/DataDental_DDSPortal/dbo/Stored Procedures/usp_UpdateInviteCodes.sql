﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateInviteCodes]
	-- Add the parameters for the stored procedure here
@InviteCodes InviteCodes READONLY	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @currntDt DATETIME=GETDATE();

IF OBJECT_ID('tempdb..#tempInviteCodes') IS NOT NULL
    DROP TABLE #tempInviteCodes

IF OBJECT_ID('tempdb..#processedCode') IS NOT NULL
    DROP TABLE #processedCode

--CREATE TABLE #InviteCodesTest(
--	[Id] [int] NULL,
--	[invitecode] [varchar](20) NULL,
--	[group_zip] [varchar](20) NULL,
--	[email] [varchar](40) NULL,
--	[last_name] [varchar](40) NULL
--	con_type varchar(2) null
--)

----drop table [InviteCodesTest]

--INSERT INTO #InviteCodesTest(id,invitecode,group_zip,email,last_name)

--Select f.detail_id,'Test',f.group_zip,f.email,f.last_name
----delete from f
--	From flatfile_details f

Select *
INTO #tempInviteCodes
	From @InviteCodes 


IF EXISTS(SELECT *
				FROM #tempInviteCodes t
				WHERE t.invitecode IS NULL)
BEGIN

 UPDATE f SET f.invitecode_processed_date=null,f.is_invitecode_processed=null
	FROM #tempInviteCodes p 
	JOIN flatfile_details f ON p.Id=f.detail_id
	WHERE p.invitecode IS NULL
END


SELECT ROW_NUMBER() Over(Order by i.Id) AS row_id,*
	INTO #processedCode
	FROM #tempInviteCodes i	
	WHERE i.invitecode IS NOT NULL

DECLARE @Count INT=0;
DECLARE @iRecCount INT=1;

SELECT @Count=COUNT(p.row_id) FROM #processedCode p

WHILE @iRecCount<=@Count
BEGIN
DECLARE @refId INT=0;

	INSERT INTO invitecode_details(
	invitecode,
	group_zip,
	email,
	last_name,
	con_type,
	created_date)
	SELECT p.invitecode,
			group_zip,
			email,
			last_name,
			con_type,
			@currntDt
			FROM #processedCode p 
			WHERE p.row_id=@iRecCount
	SET @refId=SCOPE_IDENTITY();
	--SELECT @refId 
	INSERT INTO batch_process_details
	(ref_id,
	event_id,
	[status],
	retry
	)VALUES(@refId,3,1001,0)

--SELECT *
UPDATE f SET f.invitecode_processed_date=@currntDt,f.is_invitecode_processed=1
	FROM #processedCode p 
	JOIN flatfile_details f ON p.Id=f.detail_id

SET @iRecCount=@iRecCount+1;
END

END