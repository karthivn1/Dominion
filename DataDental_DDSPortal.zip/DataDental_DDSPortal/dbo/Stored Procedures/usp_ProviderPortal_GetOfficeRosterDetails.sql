﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_GetOfficeRosterDetails]
(
@facilityid INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @OfficeRosterDetails TABLE
(
id INT IDENTITY(1,1),
LastName VARCHAR(MAX),
FirstName VARCHAR(MAX),
PlanName VARCHAR(MAX),
GroupID VARCHAR(MAX),
SSN VARCHAR(MAX),
DOB VARCHAR(MAX),
Status VARCHAR(MAX),
FacilityAssignmentEffectiveDate VARCHAR(MAX)
)

INSERT INTO @OfficeRosterDetails(LastName,FirstName,PlanName,GroupID,SSN,DOB,Status,FacilityAssignmentEffectiveDate)

select distinct  last_name , first_name ,pln.plan_name ,rlmbgrpl.group_id,mbr.member_ssn,mbr.date_of_birth,'True' ,rlplfc.eff_date
 from member_sec mbr
inner join rlmbgrpl on rlmbgrpl.member_id = mbr.member_id
--inner join pat_tooth_status  pts on  pts.member_id = mbr.member_id
inner join [plan_sec] pln on pln.plan_id = rlmbgrpl.plan_id
inner join rlplfc on rlplfc.mb_gr_pl_id = mbr.member_id
--where rlplfc.facility_id = @facilityid

select * from @OfficeRosterDetails

SET NOCOUNT OFF 
END