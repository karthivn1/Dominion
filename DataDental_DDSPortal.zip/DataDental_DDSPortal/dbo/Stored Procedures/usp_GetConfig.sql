﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetConfig]
@Environment nvarchar(50)
AS
BEGIN
	SET NOCOUNT ON;

	Select a.[Key],a.Value
		From app_settings a(nolock)
		Where Environment=@Environment
		AND [status]=1

END