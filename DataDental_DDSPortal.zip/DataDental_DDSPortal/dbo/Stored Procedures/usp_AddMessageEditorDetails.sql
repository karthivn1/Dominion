﻿
--EXEC [usp_AddMessageEditorDetails] 'Test','Tes','All Users',null,null,'LDKerr'

CREATE procedure [dbo].[usp_AddMessageEditorDetails] 
(
@subject as Varchar(max),
@body as Varchar(max),
@toEmail as Varchar(max),
@state as Varchar(max) = NULL,
@plan as Varchar(max) = NULL,
@createdby Varchar(100) 
--@filename as varchar(max)= NULL,
--@file as VarBinary(max)
)
AS
Begin
SET NOCOUNT ON 
Begin Transaction [addmessageEditor]
	Begin try
	
		Declare @userId int 
		DECLARE @statusid int
		DECLARE @instype VARCHAR(50)
	    DECLARE @insopt VARCHAR(50)
		
		SELECT @userId = user_id from group_user_details where user_name =@createdby
		select @statusid = status_id from user_status_master where [status] ='Deactivated'
		Insert into [message] ([message],message_subject,message_type_id,from_address,created_by,created_date)
		values
		(@body,@subject,1,'Admin',@userId,GETDATE())
		DECLARE @messageid int
		SET @messageid =@@IDENTITY;
		
		update [message] SET parentid = @messageid where message_id = @messageid 

		DECLARE @ListofIDs TABLE(Id INT IDENTITY(1, 1),UserID VARCHAR(100),Email VARCHAR(100) );
		if(@toEmail = 'DDS Users' OR @toEmail ='All BAs' OR @toEmail ='All Users')
				BEGIN 
					IF @toEmail = 'All Users'
							INSERT INTO @ListofIDs(UserID,Email)
							SELECT [user_id],email from group_user_details where status_id <> @statusid
					ELSE IF  @toEmail = 'DDS Users'
							INSERT INTO @ListofIDs(UserID,Email)
							SELECT [user_id],email from group_user_details where role_id = (SELECT role_id from role_master where role_name ='DDS') and status_id <> @statusid
					ELSE IF  @toEmail = 'All BAs'
					IF @plan ='--Select--' OR @plan ='All Plans'
						BEGIN
							SET @plan = NULL
							SET @instype = NULL
							SET @insopt = NULL
						END
					ELSE IF @plan ='Select Plan'
						BEGIN							
							SET @instype = NULL
							SET @insopt = 'HMO'
						END
					ELSE IF @plan ='Access PPO'
						BEGIN							
							SET @instype = NULL
							SET @insopt = 'PPO'
						END
					ELSE IF @plan ='Vision'
						BEGIN							
							SET @instype = 'V'
							SET @insopt = NULL
						END
					 		 	 IF (@state ='ALL States' OR @state ='')
					 SET @state = NULL

					 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 		 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 	 IF @state IS NULL AND @plan IS NULL
						INSERT INTO @ListofIDs(UserID,Email)
						SELECT [user_id],email from group_user_details where role_id = (SELECT role_id from role_master where role_name ='Group') and status_id <> @statusid
				 ELSE IF @state IS NOT NULL AND @plan is NULL 
					INSERT INTO @ListofIDs(UserID,Email)
						select [user_id],email from group_user_details where email in (
							select email from contact_sec cnt
							where sys_rec_id in(select sys_rec_id from address_sec addr
							INNER JOIN [group_sec] grp ON addr.sys_rec_id=grp.group_id
							where subsys_code='GP' 
							AND ((@state IS NULL AND (addr.[state]=addr.[state] or addr.[state] is null)) 	
							OR (@state IS NOT NULL AND  addr.[state] in( SELECT Item from  dbo.[SplitString](@state,',')))) 
							and addr_type='L'))
				ELSE 						
					INSERT INTO @ListofIDs(UserID,Email)
						SELECT [user_id],email from group_user_details where email in (
							SELECT email from contact_sec cnt
							WHERE sys_rec_id in(select sys_rec_id from address_sec addr
							INNER JOIN [group_sec] grp ON addr.sys_rec_id=grp.group_id
							INNER JOIN rlmbgrpl_sec grppln ON grppln.group_id = grp.group_id
							INNER JOIN plan_sec pln ON grppln.plan_id = pln.plan_id
							where subsys_code='GP'
							AND ((@state IS NULL AND (addr.[state]=addr.[state] or addr.[state] is null)) 	
							OR (@state IS NOT NULL AND  addr.[state]in (SELECT Item from  dbo.[SplitString](@state,','))))
							AND ((@instype IS NULL AND (pln.ins_type=pln.ins_type or pln.ins_type is null)) 	
							OR (@instype IS NOT NULL AND  pln.ins_type=pln.ins_type))
							AND ((@insopt IS NULL AND (pln.ins_opt=pln.ins_opt or pln.ins_opt is null)) 	
							OR (@insopt IS NOT NULL AND  pln.ins_opt=pln.ins_opt))
							and addr_type='L'))

				END 
		ELSE 
		BEGIN			
			INSERT INTO @ListofIDs(UserID,Email)
			select [user_id],email from group_user_details where email in (SELECT Item from  dbo.[SplitString](@toEmail,';'))

			--select * from @ListofIDs
			
		END

		DECLARE @Count INT=0;
		DECLARE @iRecCount INT=1;


		SELECT @Count=COUNT(Id) FROM @ListofIDs

		WHILE @iRecCount<=@Count
		BEGIN		

			Insert into [message_detail] (message_id,message_receiver_id,received_date,is_read,is_new,is_delete,is_reply)
			SELECT 	@messageid,UserID,GETDATE(),0,1,0,0 from @ListofIDs where Id = @iRecCount
		
			SET @iRecCount=@iRecCount+1;
		END	

			insert into batch_process_details (ref_id,event_id,status,retry,created_date) values
			(@messageid,5,1001,0,convert(date,getdate()));
		--Insert into [message_attachment] (message_id,attachment_filename,attachment_file)
		--values
		--(@messageid,@filename,@file)
		--SET @messageid = count(*) from  dbo.[SplitString](@toEmail,';')
	 --   Insert into [message_detail] (message_id,message_receiver_id,received_date,is_read,is_new,is_delete,is_reply)
		--values
		--(@messageid,@filename,@file)
	 -- If NOT Exists( (select user_name from group_user_details where user_name =@username))
	  
	 --   Begin
		
   --insert into batch_process_details (ref_id,event_id,status,retry,created_date) values
   -- (@messageid,3,1001,0,convert(date,getdate()));

		select @messageid;
		 --End

	commit Transaction [addmessageEditor]
   End try

Begin Catch
rollback Transaction [addmessageEditor]
End Catch
SET NOCOUNT OFF
End