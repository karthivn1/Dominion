﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <22-11-2016>
-- Description:	<This sp gets the Member Producer Details by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberProducerDetails]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;
	DECLARE @commSchemeId INT
	DECLARE @pdType NVARCHAR(MAX)
--Producer

  SELECT group_pdcomm.group_pdcomm_id As GroupPdCommonID,   
         group_pdcomm.rel_gppl_id,   
         group_pdcomm.group_id,   
         group_pdcomm.plan_id,   
         group_pdcomm.prod_id AS ProducerID,   
         group_pdcomm.pd_type AS ProducerType,
		 typPrdType.descr AS ProducerTypeDescr,  
         group_pdcomm.license_number,   
         group_pdcomm.comm_flag,   
         group_pdcomm.comm_scheme_id AS CommSchemeId,   
         group_pdcomm.eff_date AS EffDate,   
         group_pdcomm.exp_date AS ExpDate,   
         group_pdcomm.selling_prod AS Selling,   
         group_pdcomm.h_datetime,   
         group_pdcomm.h_msi,   
         group_pdcomm.h_action,   
         group_pdcomm.h_user,   
         pd.last_name,   
         pd.first_name,   
         pd.producer_name AS CompanyName  
    FROM rel_gppl 
	INNER JOIN group_pdcomm ON  group_pdcomm.rel_gppl_id = rel_gppl.rel_gppl_id  
	INNER JOIN pd ON group_pdcomm.prod_id = pd.producer_id
    INNER JOIN [group] ON [group].group_id = rel_gppl.group_id
	LEFT JOIN typ_table typPrdType ON typPrdType.subsys_code='PD' AND typPrdType.tab_name='producer type' AND typPrdType.code=group_pdcomm.pd_type
    WHERE (rel_gppl.group_id in (SELECT DISTINCT rlmbgrpl.group_id FROM rlmbgrpl WHERE rlmbgrpl.member_id = @memberId )) AND  
          [group].group_type = 'SG'

--********************************************************************

SET @commSchemeId=(SELECT TOP 1 group_pdcomm.comm_scheme_id 
					FROM rel_gppl 
					INNER JOIN group_pdcomm ON  group_pdcomm.rel_gppl_id = rel_gppl.rel_gppl_id  
					INNER JOIN pd ON group_pdcomm.prod_id = pd.producer_id
					INNER JOIN [group] ON [group].group_id = rel_gppl.group_id
					WHERE (rel_gppl.group_id in (SELECT DISTINCT rlmbgrpl.group_id FROM rlmbgrpl WHERE rlmbgrpl.member_id = @memberId )) AND  
						  [group].group_type = 'SG')

SET @pdType=(SELECT TOP 1 group_pdcomm.pd_type 
					FROM rel_gppl 
					INNER JOIN group_pdcomm ON  group_pdcomm.rel_gppl_id = rel_gppl.rel_gppl_id  
					INNER JOIN pd ON group_pdcomm.prod_id = pd.producer_id
					INNER JOIN [group] ON [group].group_id = rel_gppl.group_id
					WHERE (rel_gppl.group_id in (SELECT DISTINCT rlmbgrpl.group_id FROM rlmbgrpl WHERE rlmbgrpl.member_id = @memberId )) AND  
						  [group].group_type = 'SG')


--Commission Scheme

		SELECT comm_scheme.comm_scheme_title AS CommissionSchemeTitle, 
			   comm_scheme.comm_scheme_type, 
			   comm_scheme.comm_type AS CommissionType, 
			   st_prd_perc.sequence, 
			   st_comm_timeline.comm_st_time_lb AS FromMonths,
			   st_comm_timeline.comm_st_time_ub AS ToMonths,
			   st_prd_perc.producer_perc AS 'Percent'
		FROM comm_scheme
			 INNER JOIN st_prd_perc ON comm_scheme.comm_scheme_id = st_prd_perc.comm_scheme_id  
			 INNER JOIN st_comm_timeline ON st_prd_perc.comm_st_time_id = st_comm_timeline.comm_st_time_id AND st_comm_timeline.comm_scheme_id = st_prd_perc.comm_scheme_id
			 LEFT JOIN typ_table typComTyp ON  typComTyp.subsys_code='PL' AND typComTyp.tab_name='comm_scheme' AND typComTyp.code=comm_scheme.comm_type
			 
		WHERE st_prd_perc.comm_scheme_id = @commSchemeId AND st_prd_perc.producer_type = @pdType
		UNION 
		SELECT comm_scheme.comm_scheme_title AS CommissionSchemeTitle,
			   comm_scheme.comm_scheme_type,
			   comm_scheme.comm_type AS CommissionType,
			   prd_grad_perc.sequence,
		       grad_comm_amt.comm_grad_lb AS FromMonths,
			   grad_comm_amt.comm_grad_ub AS ToMonths,
			   prd_grad_perc.prd_grad_perc AS 'Percent'
		 FROM grad_comm_amt 
			  INNER JOIN prd_grad_perc ON prd_grad_perc.comm_grad_id = grad_comm_amt.comm_grad_id
			  INNER JOIN comm_scheme ON grad_comm_amt.comm_scheme_id = prd_grad_perc.comm_scheme_id AND comm_scheme.comm_scheme_id = prd_grad_perc.comm_scheme_id
			  LEFT JOIN typ_table typComTyp ON  typComTyp.subsys_code='PL' AND typComTyp.tab_name='comm_scheme' AND typComTyp.code=comm_scheme.comm_type
		WHERE prd_grad_perc.comm_scheme_id = @commSchemeId AND prd_grad_perc.producer_type = @pdType

SET NOCOUNT OFF
END