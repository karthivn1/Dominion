﻿

-- =============================================  
-- Author: Neetha Joseph
-- Create date: <01-Nov-2016>  
-- Description: This procedure is to save rule and parameter details
-- =============================================  
CREATE PROCEDURE [dbo].[usp_mem_SaveDateCorrectDetails]	
(
	@date_corr_id				int,
	@table_name					NVARCHAR(MAX),
	@recordId					int,
	@memberId					int,   
	@facilityId				    int, 
	@groupId					int,
	@planId						int,
	@orignalEffectiveDate		DateTime,
	@newEffectiveDate			DateTime,
	@orignalExpiryDate			DateTime,
	@newExpiryDate				DateTime,
	@orignalAmount				decimal,
	@newAmount					decimal
)
                                                   
AS 
BEGIN 
	SET NOCOUNT ON
		INSERT INTO date_corr_d(date_corr_id,table_name,rec_id,member_id,facility_id,group_id,plan_id,orig_eff_date,new_eff_date,orig_exp_date,new_exp_date,orig_amount,new_amount)
		VALUES(@date_corr_id,@table_name,@recordId,@memberId,@facilityId,@groupId,@planId,@orignalEffectiveDate,@newEffectiveDate,@orignalExpiryDate,@newExpiryDate,@orignalAmount,@newAmount)
	SET NOCOUNT OFF
END