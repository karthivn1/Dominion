﻿ 
CREATE procedure [dbo].[usp_SavePageDetials]
(@username varchar(max),
 @pageid int,
 @devicetype varchar(max),
 @portalType varchar(max)
)
 AS
 Declare @userid int;
 Begin
 If exists ( select user_id from group_user_details  where user_name =@username)
 Begin 
 set @userid=(select user_id from group_user_details  where user_name =@username)

 insert into page_log values (@pageid,@userid,convert(date,getdate()),@devicetype,@portalType)

 select 1
 
 End 
 End