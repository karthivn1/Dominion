﻿CREATE procedure [dbo].[usp_UpdateUserStatus] 
(
@username as Varchar(max)
)
AS
Begin
SET NOCOUNT ON 

Declare @userId int; 

If  Exists(select * from  group_user_details where user_name =@username and status_id in(1,4))
begin 
  update group_user_details set status_id =2 where user_name =@username

  select user_id from group_user_details where user_name =@username
  end
 else
 If  Exists(select * from  group_user_details where user_name =@username and status_id =2)
  Begin
  update group_user_details set status_id =1 where user_name =@username
    select user_id from group_user_details where user_name =@username
  End
SET NOCOUNT OFF
End