﻿

-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <26-01-2017>
-- Description:	<This sp Trasfer the Member Facility to new facility>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_TransferFacility]
(
@relPlanFaclityId INT=NULL,
@memGroupPlanId INT=NULL,
@memberId INT=NULL,
@facilityId INT=NULL,
@planFacilityEffectiveDate DATETIME=NULL,
@newPlanFacilityEffectiveDate DATETIME=NULL,
@planFacilityActionCode VARCHAR(2)=NULL,
@letterId INT=NULL,
@planTiered INT=NULL,
@reCoupActionCode VARCHAR(2)=NULL,
@activityMasterId INT=NULL,
@subsystemCode	VARCHAR(2)=NULL,
@reasonCode  VARCHAR(2)=NULL,
@hUser VARCHAR(100)=NULL
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @NewMSI INT, @NewRlPlFcID INT, @OldCarryOver INT, @OldAdj INT,@NewCarryOver INT
BEGIN TRAN 
	BEGIN TRY
		UPDATE [sysdatetime] SET msi = msi + 1
		SET @NewMSI=(SELECT msi FROM [sysdatetime])

		UPDATE rlplfc SET exp_date = @newPlanFacilityEffectiveDate ,action_code = @reCoupActionCode ,h_msi = @NewMSI,h_datetime = GETDATE(),h_user = @hUser WHERE rlplfc.rlplfc_id = @relPlanFaclityId

		UPDATE [sysdatetime] SET msi = msi + 1
		SET @NewMSI=(SELECT msi FROM [sysdatetime])

		INSERT INTO rlplfc (mb_gr_pl_id, member_id, facility_id, eff_date, exp_date, action_code,h_datetime, h_msi, h_action, h_user )  
			VALUES (@memGroupPlanId, @memberId, @facilityId, @newPlanFacilityEffectiveDate, null, @reCoupActionCode,GETDATE(), @NewMSI, @planFacilityActionCode, @hUser )

		IF(@planTiered=1)
		BEGIN
			SET @NewRlPlFcID=SCOPE_IDENTITY()

			SELECT @OldCarryOver=carry_over, @OldAdj=adjustment  FROM tiered_benefit_mbr WHERE rlplfc_id =@relPlanFaclityId

			SET @NewCarryOver=(SELECT DATEDIFF(day,@planFacilityEffectiveDate,@newPlanFacilityEffectiveDate)) +@OldCarryOver +@OldAdj

			INSERT INTO tiered_benefit_mbr(rlplfc_id, carry_over, adjustment, h_user, h_datetime)
			VALUES ( @NewRlPlFcID, @NewCarryOver, 0, @hUser,  GETDATE() )
		END

		IF(@letterId>0)
		BEGIN
			INSERT INTO ltr_hst (subsys_code, sys_rec_id,letter_def_id,date_created,h_datetime,h_user) 
			VALUES ('MB', @memberId,@letterId,GETDATE(),GETDATE(),@hUser)
		END

		IF @activityMasterId>0 
		BEGIN
			EXEC usp_SaveActivity @subsystemCode,@memberId,@reasonCode,@activityMasterId,@hUser
		END
COMMIT TRAN 
	END TRY
	BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH 
SET NOCOUNT OFF
END