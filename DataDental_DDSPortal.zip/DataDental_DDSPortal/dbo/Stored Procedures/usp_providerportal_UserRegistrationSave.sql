﻿--usp_providerportal_UserRegistrationSave '','ghasdfasd','raj@cc.com','541348038','Jennings','23325',''
CREATE procedure [dbo].[usp_providerportal_UserRegistrationSave] 
(
@status varchar(max) output,
@user_name varchar(max),
@email varchar(max),
@tax_id varchar(max),
@lastname varchar(max)  ,
@zip varchar(max),
@portalType varchar(max)
 )
AS
Begin
SET NOCOUNT ON 
Declare @fc_id int;
Declare @role_id int;
	   select @fc_id =fac.fc_id from facility_sec fac
		LEFT JOIN fcstat_sec fcstatus (NOLOCK)
				ON fcstatus.fc_stat_id = (SELECT MAX(fc_stat_id) FROM fcstat_sec (NOLOCK) WHERE facility_id = fac.fc_id)
		LEFT OUTER join typ_table_sec fctype (NOLOCK)
				ON fctype.code = fcstatus.status AND fctype.subsys_code='FC' AND fctype.tab_name='fcstat' 
		where fac.fc_tax_id = @tax_id  and fcstatus.status='AC'


	set @fc_id= (select top 1 facility_sec.fc_id
    FROM facility_sec, fc_assoc_sec,   
         providers_sec,   
         pv_status_sec  ,
		 [address_sec] addr
    WHERE ( fc_assoc_sec.pv_id = providers_sec.pv_id ) and  
         ( providers_sec.pv_id = pv_status_sec.pv_id ) and  
          (facility_sec.fc_id = fc_assoc_sec.fc_id ) and
         ( pv_status_sec.exp_date is null )  and (facility_sec.fc_tax_id = @tax_id)
		 and Lower(RTRIM (providers_sec.last_name)) = Lower(@lastname)
		 and addr.sys_rec_id=facility_sec.fc_id and addr.subsys_code ='FC'
		 and addr.zip=@zip  and facility_sec.fc_id= @fc_id)

		 if(@portalType='CBC')
			Begin
				select @role_id = role_id from role_master where role_name='CBC Provider'
			End
			else if(@portalType='Premera')
			Begin
			   --set @role_id=9
			   select @role_id = role_id from role_master where role_name='Premera Provider'
			End
			else 
			Begin
			   select @role_id = role_id from role_master where role_name='Dominion Provider'
			End
--set @fc_id=(select top 1 fc.fc_id from providers_sec pro inner join facility_sec fc on pro.tax_id=fc.fc_tax_id inner join [address_sec] addr on (addr.sys_rec_id=fc.fc_id and subsys_code='FC')
--		where pro.tax_id=@tax_id and pro.last_name=@lastname and addr.zip=@zip);
		If not exists(select user_id  from provider_user_details where user_name =@user_name)
		Begin
       insert into [dbo].[provider_user_details] ( user_name, 
                                      last_name,
                                       email,
                                      role_id,
                                      status_id,
									  facility_id,
									  facility_tax_id,
									  facility_zip_code, 
									  is_firstlogin,                               
                                      created_date
                                      )
                                      values( @user_name ,                                           
                                             @lastname,
                                             @email,
                                             @role_id,
                                             4,
											 @fc_id,
											 @tax_id,
                                             @zip, 
											 'True',                                        
                                          getdate()
                                         )
	  
			INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
			VALUES (SCOPE_IDENTITY(),13,1001,0,CONVERT(date,GETDATE()));
								set @status	='Success'
						End
             Else
			Begin	
			Print 'hai'
						set @status	='User ID already exists, please choose a different user ID.'
             End


End
SET NOCOUNT OFF