﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetCustomerProfile]
@GroupId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

select a.group_id AS UserId,a.customer_profile AS CustomerProfileId,
	a.payment_profile AS CustomerPaymentProfileId
	From authorize_net_profile a
	Where a.group_id=@GroupId

END