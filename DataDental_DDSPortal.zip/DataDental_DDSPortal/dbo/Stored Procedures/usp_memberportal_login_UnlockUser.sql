﻿CREATE PROCEDURE [dbo].[usp_memberportal_login_UnlockUser]
(
@userId INT
)
AS
BEGIN
SET NOCOUNT ON;
UPDATE member_user_details SET status_id  = 1 ,failed_login_attempt=0, incorrect_attempt_time=NULL  
	WHERE user_id= @userId

SELECT status_id AS Status,failed_login_attempt AS LoginAttempt 
	FROM member_user_details  
	WHERE user_id= @userId 

SET NOCOUNT OFF
END