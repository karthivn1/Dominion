﻿CREATE PROCEDURE [dbo].[usp_GetGroupSummaryDependentDetails]
(
@GroupID INT,
@PlanID INT,
@CoverageTier VARCHAR(MAX)
) 
AS 
BEGIN 
SET NOCOUNT ON 

--SELECT  member_sec.first_name FirstName,member_sec.last_name LastName, member_sec.date_of_birth DOB,rlmbrt_sec.exp_rt_date, rlmbgrpl_sec.group_id,rlmbgrpl_sec.plan_id from member_sec
--inner join rlplfc_sec on  rlplfc_sec.member_id=member_sec.member_id
--inner join rlmbgrpl_sec on rlmbgrpl_sec.mb_gr_pl_id=rlplfc_sec.mb_gr_pl_id
--inner join rlmbrt_sec on rlmbrt_sec.mb_gr_pl_id=rlmbgrpl_sec.mb_gr_pl_id
--inner join pl_rat_sec on rlmbrt_sec.rate_code =pl_rat_sec.rate_code WHERE rlmbgrpl_sec.plan_id=@PlanID AND rlmbgrpl_sec.group_id=@GroupID AND
--member_sec.member_id <> member_sec.family_id  AND pl_rat_sec.rate_text=@CoverageTier
--AND (( rlmbrt_sec.exp_rt_date is null ) or  ( rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))) ) 


select distinct RTRIM(member_sec.first_name) FirstName,RTRIM(member_sec.last_name) LastName, convert(nvarchar(MAX), member_sec.date_of_birth, 101) DOB,rlmbrt_sec.exp_rt_date, rlmbgrpl_sec.group_id,rlmbgrpl_sec.plan_id 
from member_sec inner join rlmbgrpl_sec 
on member_sec.family_id = rlmbgrpl_sec.member_id 
inner join rlmbrt_sec on rlmbrt_sec.mb_gr_pl_id = rlmbgrpl_sec.mb_gr_pl_id
inner join pl_rat_sec on pl_rat_sec.rate_code=rlmbrt_sec.rate_code
where rlmbgrpl_sec.group_id=@GroupID and rlmbgrpl_sec.plan_id=@PlanID
and member_sec.member_id<>member_sec.family_id
and((rlmbrt_sec.exp_rt_date is null) or  (rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))))
and pl_rat_sec.rate_text=@CoverageTier




 

SET NOCOUNT OFF 
END