﻿CREATE procedure [dbo].[usp_viewmyplan_getlastaccess_details] 
(
@username varchar(max)
)
AS
Begin
SET NOCOUNT ON 

DECLARE @UserID INT,@GroupID INT,@PlanID INT,@MemberID INT

select user_id as User_Id,grp.group_id as Group_Id ,reg.group_name as Group_Name,grp.plan_id as Plan_Id,pln.plan_name as Plan_Name, role_id as Role_ID,member_id as MemberID,LTRIM(RTRIM(tbl_address.zip)) AS Zip 
from member_user_details as grp
join [group_sec] reg on reg.group_id=grp.group_id
join [plan_sec] pln on pln.plan_id=grp.plan_id
Left outer JOIN [address_sec] tbl_address  ON reg.group_id = tbl_address.sys_rec_id and  tbl_address.subsys_code = 'GP' and  tbl_address.addr_type ='L' 
where user_name=@username 

select @UserID=user_id,@GroupID=grp.group_id,@PlanID=grp.plan_id,@MemberID=member_id  from member_user_details as grp
join [group_sec] reg on reg.group_id=grp.group_id
join [plan_sec] pln on pln.plan_id=grp.plan_id
where user_name=@username 

SELECT DISTINCT mem_b.member_id
from member_sec mem_a inner join member_sec mem_b on mem_a.member_id=mem_b.family_id
join rlplfc_sec rel on rel.member_id=mem_b.member_id
join rlmbgrpl_sec rlg on rlg.mb_gr_pl_id=rel.mb_gr_pl_id
where mem_a.member_id=@MemberID --and rlg.group_id=@GroupID and rlg.plan_id=@PlanID 

SET NOCOUNT OFF
END