﻿CREATE PROCEDURE [dbo].[usp_GetBillingInformation]  
(
@GroupID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @BillingDetails TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(max),
BalanceDue VARCHAR(max),
NextPaymentDue VARCHAR(max),
GroupRenewalDate VARCHAR(MAX)
)

DECLARE @BillingHistory TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(max),
Invoice VARCHAR(max),
BillDate VARCHAR(max),
Premium VARCHAR(MAX),
Fees VARCHAR(MAX),
Adjustments VARCHAR(50),
PriorBalance VARCHAR(50),
CurrentBill VARCHAR(50),
TotalDue VARCHAR(MAX)
)

DECLARE @PaymentHistory TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(max),
PaymentDate VARCHAR(max),
AmountPaid VARCHAR(max),
PaymentMethod VARCHAR(MAX)
)


INSERT INTO @BillingHistory(GroupID ,Invoice ,BillDate ,Premium ,Fees ,Adjustments ,PriorBalance,CurrentBill ,TotalDue)

SELECT top 6 group_id,invoice_num,convert(nvarchar(MAX), bil_gen_date, 101),
'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(tot_prems, '#,##0.00'))),
'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(tot_fees, '#,##0.00'))),
'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(tot_adj, '#,##0.00'))),
(select Top 1 CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(bal_forward, '#,##0.00')))  
from bill_sum_sec where group_id=@GroupID  
and invoice_num < s.invoice_num order by bil_gen_date desc),
--'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(bal_forward, '#,##0.00'))),
'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(ISNULL(s.tot_prems,0) + ISNULL(s.tot_fees,0) + isnull(s.tot_adj,0), '#,##0.00'))) ,
'$'+ CONVERT(VARCHAR(MAX),FORMATMESSAGE(format((bal_forward), '#,##0.00'))) FROM bill_sum_sec s
WHERE group_id=@GroupID   
order by bil_gen_date desc

INSERT INTO @PaymentHistory (GroupID,PaymentDate,AmountPaid,PaymentMethod)
select * from (
select group_id as  GroupID,convert(nvarchar(MAX), recv_date, 101) as PaymentDate ,'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(amount, '#,##0.00'))) as AmountPaid, case when check_no is null then 'Card' else 'Check' end as PaymentMethod  from al_batches_sec --where group_id =32943
where recv_date > =  Dateadd(Month, Datediff(Month, 0, DATEADD(m, -6, current_timestamp)), 0) and  group_id =@GroupID 
  UNION 
 --GroupID,PaymentDate,AmountPaid,PaymentMethod
 select group_id as GroupID ,convert(nvarchar(MAX), payment_date, 101) as PaymentDate,'$'+CONVERT(VARCHAR(MAX),FORMATMESSAGE(format(amountpaid, '#,##0.00'))) as AmountPaid, case when payment_method is null then 'Card' else 'Check' end as PaymentMethod from payment_history 
 where group_id=@GroupID and payment_date > =Dateadd(Month, Datediff(Day, 0, DATEADD(d, -6, current_timestamp)), 0) 
 ) t
 order by t.PaymentDate desc
--SELECT group_id,convert(nvarchar(MAX), payment_date, 101),amountpaid,payment_method FROM payment_history 
INSERT INTO @BillingDetails(GroupID,BalanceDue,NextPaymentDue,GroupRenewalDate)
SELECT group_id,(SELECT TOP 1 TotalDue FROM @BillingHistory),convert(nvarchar(MAX), next_enrol_date, 101),convert(nvarchar(MAX), next_renew_date, 101) FROM group_sec WHERE group_id=@GroupID

SELECT * FROM @BillingDetails

SELECT * FROM @BillingHistory order by Invoice desc

SELECT * FROM @PaymentHistory order by PaymentDate desc


SET NOCOUNT OFF 
END