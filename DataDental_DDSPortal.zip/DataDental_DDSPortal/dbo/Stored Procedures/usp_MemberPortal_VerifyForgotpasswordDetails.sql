﻿--exec [usp_MemberPortal_VerifyForgotpasswordDetails] 0,'','11/1/2010','LDKerr','Next'
CREATE Procedure [dbo].[usp_MemberPortal_VerifyForgotpasswordDetails](
@securityquestionid int,
@securityanswer varchar(max),
@dateofbirth Datetime,
@username varchar(max),
@value Varchar(max))
AS
Begin
SET NOCOUNT ON

Declare @userid int;
Declare @DOB Datetime;
Declare @verificationMessage varchar(max);
Declare @userinfo as table (
Security_Question_ID int,
Security_Question varchar(max),
answer varchar(max),
DOB Datetime)
DECLARE @email  varchar(100),@charlen int 

select @userid=user_id, @DOB = date_of_birth, @email = email from member_user_details where UPPER(user_name) =UPPER(@username)

if(LEN(@email)>0)
 begin
	set @charlen=(select CHARINDEX('@',@email))
	set @email = (select LEFT(@email, 1)+'****'+SUBSTRING(@email,@charlen-1,LEN(@email)))
 end

Insert into @userinfo (Security_Question_ID,Security_Question,answer,DOB)

select usd.security_question_id as Security_Question_ID,sqm.question as Security_Question,usd.answer,Convert(Date,@DOB) as DOB
from 
member_user_details mu
LEFT outer join user_security_detail usd on mu.user_id=usd.user_id
Left join security_question_master sqm on  sqm.security_question_id =usd.security_question_id  
 where mu.user_id  =@userid


--select usd.security_question_id as Security_Question_ID,sqm.question as Security_Question,usd.answer,Convert(Date,@DOB) as DOB
--from user_security_detail usd  inner join security_question_master sqm on  sqm.security_question_id =usd.security_question_id   where usd.user_id  =@userid

If( @value='EmailPassword')

Begin 


			
					If Exists(select  user_id as UserID, user_name as UserName, password as Password,status_id as Status,is_firstlogin as ISFirstLogin,temp_password as TempPassword from member_user_details  where UPPER(user_name) = UPPER(@username) and status_id =1 )--and password IS NOT NULL)
							Begin
							
							  set @verificationMessage= 'Success-'+@email;
							   update member_user_details set status_id=4,forgot_password_time =convert(date,getdate()) where user_id=@userid 
							   insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userid,7,1001,0,convert(date,getdate()))
							End


End

else
If(@value='Next')
Begin

IF (@securityquestionid <> 0)
BEGIN
	
	If Exists( select * from @userinfo where Security_Question_ID=@securityquestionid and answer=@securityanswer and DOB=@dateofbirth )
	  Begin
		  set @verificationMessage='Success';
	  End
	  ELSE
		BEGIN
		If exists( select * from @userinfo where Security_Question_ID=@securityquestionid and answer <> @securityanswer)
			  Begin			 
			     set @verificationMessage='Invalid answer. Please try again.';
			  End
			  else
			  Begin			 
			    set @verificationMessage='Date of birth does not match';
			  end
		End

	  
END 
ELSE
BEGIN
	
	If Exists( select * from @userinfo where  DOB=@dateofbirth )
	BEGIN
		set @verificationMessage='Success';

	END 
	ELSE
	BEGIN
		set @verificationMessage='Date of birth does not match';
	END
END 

END

declare @Status as Table(
Verification varchar(max)
)
insert into @Status(Verification) values (@verificationMessage)
select * from @Status;
SET NOCOUNT OFF
END