﻿CREATE PROCEDURE [dbo].[usp_GetEditSubscriberSummaryDetails] 
(
@GroupID INT,
@PlanID INT,
@MemberID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @SubscriberSummary TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(MAX),
PlanID VARCHAR(MAX),
MemberID VARCHAR(MAX),
FirstName VARCHAR(MAX),
LastName VARCHAR(MAX),
MiddleInitial VARCHAR(MAX),
Phone VARCHAR(MAX),
Email VARCHAR(MAX),
DOB VARCHAR(50),
EmailNotifications VARCHAR(MAX),
PaperlessStatements VARCHAR(MAX),
Address1 VARCHAR(MAX),
Address2 VARCHAR(MAX),
City VARCHAR(max),
State VARCHAR(MAX),
Zip VARCHAR(MAX),
Gender VARCHAR(50)
)

DECLARE @GroupDetails TABLE
(
id INT IDENTITY(1,1),
PlanID INT NULL,
PlanName VARCHAR(MAX),
PlanType VARCHAR(MAX),
RenewalDate VARCHAR(50),
EmailNotifications VARCHAR(50),
PaperlessNotifications VARCHAR(50),
GroupID VARCHAR(50),
GroupName VARCHAR(MAX),
Address VARCHAR(MAX),
Phone VARCHAR(MAX),
Email VARCHAR(MAX)
)


INSERT INTO @SubscriberSummary(GroupID,PlanID,MemberID,FirstName,LastName,MiddleInitial,Phone,Email,DOB,
EmailNotifications,PaperlessStatements,Address1,Address2,City,State,Zip,Gender)

SELECT @GroupID,@PlanID,mem.member_id,RTRIM(Isnull(mem.first_name,'')),RTRIM(Isnull(mem.last_name,'')),RTRIM(isnull(mem.middle_init,'')),RTRIM(isnull(ph.home_phone,'')),RTRIM(isnull(ph.email,'')),
convert(nvarchar(MAX),  mem.date_of_birth, 101),
RTRIM(addr.mail), RTRIM(mem.paperless),RTRIM(isnull(addr.addr1,'')),RTRIM(isnull(addr.addr2,'')),RTRIM(addr.city),RTRIM(addr.[state]),RTRIM(addr.zip),RTRIM(mbrcode.gender)
FROM member_sec mem inner join address_sec addr ON addr.sys_rec_id=mem.member_id
Left JOIN mbr_phone_sec ph ON ph.address_id=addr.address_id
Left JOIN mbr_code_sec mbrcode ON mem.member_code=mbrcode.mbr_code
WHERE mem.member_id=@MemberID and addr.addr_type='L' and addr.subsys_code='MB'


INSERT INTO @GroupDetails(PlanID,PlanName,PlanType,RenewalDate,EmailNotifications,PaperlessNotifications,GroupID,GroupName,Address,Phone,Email)

SELECT distinct top 1 tbl_plan.plan_id,RTRIM(tbl_plan.plan_name),RTRIM(tbl_plan.ins_type) as plan_type,
convert(nvarchar(MAX),  grp.next_renew_date, 101),
'YES',
'NO',
grp.group_id,RTRIM(grp.group_name),RTRIM(ISNULL(tbl_address.addr1,'')) + RTRIM(ISNULL(tbl_address.addr2,'')) +RTRIM(ISNULL(tbl_address.city,'')) + ' '+RTRIM(ISNULL(tbl_address.country,'')) +' , '+RTRIM(ISNULL(tbl_address.[state],'')) +' '+RTRIM(ISNULL(tbl_address.zip,'')) as addresss,
RTRIM(ISNULL(tbl_contact.phone1,'')),RTRIM(ISNULL(tbl_contact.email,''))
FROM group_sec grp 
JOIN rel_gppl_sec rgroupplan ON rgroupplan.group_id =grp.group_id
JOIN  plan_sec tbl_plan ON tbl_plan.plan_id =rgroupplan.plan_id 
Left JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id and tbl_address.subsys_code = 'GP'AND tbl_address.addr_type ='L'
Left JOIN contact_sec tbl_contact  ON grp.group_id = tbl_contact.sys_rec_id  AND tbl_contact.subsys_code='GP'
JOIN group_status_sec tbl_status ON tbl_status.group_id = grp.group_id
JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type and typ.subsys_code='PL' AND typ.tab_name='ins_type'
WHERE grp.group_id =@GroupID AND tbl_plan.plan_id =@PlanID 

SELECT * FROM @SubscriberSummary

SELECT * FROM @GroupDetails

SELECT * FROM @GroupDetails

SELECT code StateCode,sname StateName FROM state_sec

SET NOCOUNT OFF 
END