﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <26-10-2016>
-- Description:	<This sp gets the List for Date correct Tab for Capitation by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetListOfDateCorrectCapitation]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;

	SELECT  cap.cap_id AS CapId,
			cap.member_id AS MemberId, 
			cap.facility_id AS FacilityID,  
			cap.family_id ,    
			cap.group_id AS GrpID,       
			cap.plan_id AS PlnID,      
			cap.oed_fac AS CapOEDFac,     
			cap.member_ssn AS MemSSN, 
			cap.memb_eff_date AS MemberEffDate,   
			cap.memb_term_date AS TermDate,    
			cap.prem_amnt ,
			cap.action_code ,
			cap.cap_eff_date AS CapEffDate,
			cap.cap_eff_date AS OldCapEffDate,
			cap.memb_term_date AS OldTermDate,
			cap.memb_eff_date AS OldMemberEffDate,
			cap.cap_rate_code AS RateCode,      
			cap.cap_amount AS CapAmount,
			cap.cap_amount AS OldCapAmount,
			cap.cap_paid_date ,    
			cap.cap_roster_id , 
			cap.cap_adj_flg ,    
			LTRIM(RTRIM(cap.last_name)) + ' '+ LTRIM(RTRIM(cap.first_name))  AS MemName,			          
			cap.date_of_birth ,
			cap.oed AS CapOED,
			cap.oed AS OldCapOED,
			cap.oed_fac AS OldCapOEDFac
	FROM cap      
WHERE cap.family_id = @memberId

SET NOCOUNT OFF;
END