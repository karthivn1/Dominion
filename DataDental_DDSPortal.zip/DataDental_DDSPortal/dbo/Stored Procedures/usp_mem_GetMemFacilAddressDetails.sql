﻿-- =============================================
-- Author:		<Selvakumar K>
-- Create date: <24-Oct-2016>
-- Description:	<This stored procedure is used to get Member, Facility and Address of member deatils for the given search criteria>
-- =============================================

 
CREATE PROCEDURE [dbo].[usp_mem_GetMemFacilAddressDetails] --1142720, 3159961
(
@MemberId INT=NULL,
@FacilityId INT=NULL
 
)
AS
BEGIN
SET NOCOUNT ON
BEGIN TRAN 
	BEGIN TRY
 SELECT DISTINCT
		 member.last_name AS LastName,
		 member.first_name AS FirstName,
		 member.middle_init AS MiddleInitial,
		 mbr_code.mbr_code_desc 'Relationship',
		 convert(int,DATEDIFF(d, member.date_of_birth, getdate())/365.25)  AS Age,
         member.member_id AS MemberID,  
         member.date_of_birth AS DOB,   
         member.member_ssn AS SSN,   
         member.oed AS OED, 		 
		CAST(CASE WHEN member.student_flag= 'N' THEN 0 ELSE 1 END AS BIT) AS Student,
		CAST(CASE WHEN member.disable_flag= 'N' THEN 0 ELSE 1 END AS BIT) 'Disabled',  
		CASE 
		   WHEN str_1='new_ssn' THEN cast(member.new_ssn AS VARCHAR) 
		   WHEN str_1='member_id' THEN cast(member.member_id AS VARCHAR)
		   WHEN str_1='source_id' THEN cast(member.source_id AS VARCHAR)
		   ELSE
		   CAST(member.alt_id AS VARCHAR) 
		 END 'ExternalID',       
         member.new_ssn,   
         member.source_id AS SrcID,
		 member.alt_id AS AltID,   
         member.ext_id_type , 
		 member.member_id AS MemberID,
         member.student_exp AS StudentExp ,
		 rlplfc.rlplfc_id,   
         rlplfc.mb_gr_pl_id,   
         rlplfc.member_id,			   
         rlplfc.facility_id AS FacilityId, 
		 facility.fc_name AS FacilityName,    
         rlplfc.eff_date AS EffDate,   
         rlplfc.exp_date AS ExpDate, 
		 typ_table.descr 'ActionCode'      
    FROM member INNER JOIN mbr_code ON mbr_code.mbr_code=  member.member_code	
	    INNER JOIN typ_table ON   typ_table.subsys_code = 'MB' 
		INNER JOIN typ_table_exp ON typ_table_exp.tab_name = 'ext_id_type'  
		LEFT OUTER JOIN rlplfc  ON rlplfc.member_id = member.member_id 		
		LEFT JOIN  facility ON rlplfc.facility_id = facility.fc_id 
        INNER JOIN rlmbgrpl  ON  rlplfc.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id 		 
	    and typ_table_exp.int_1=member.ext_id_type	
	    and member.member_id=@MemberId 
		 and typ_table_exp.int_1=member.ext_id_type 
		and  typ_table.tab_name = 'action_code'  
		WHERE (typ_table.eff_date <= GETDATE () or     
	        typ_table.eff_date is NULL ) and 
			(typ_table.exp_date > GETDATE() or      
		        typ_table.exp_date is NULL) 
				and typ_table.code= rlplfc.action_code and  rlplfc.rlplfc_id=@FacilityId

		SELECT  LTRIM(RTRIM((SELECT descr FROM typ_table WHERE subsys_code='AM' AND 
		tab_name='address' AND code=address.addr_type AND 
		((typ_table.eff_date <= getdate() or ( typ_table.eff_date is NULL) ) and 
		(typ_table.exp_date > getdate() or ( typ_table.exp_date is NULL)))))) AS Type,   
         address.addr1 AS Addr1,   address.addr2 AS Addr2,   
         address.city AS City,     address.country AS Country,   
         address.county AS County,   address.state AS State,   
         address.zip AS Zip,           
         mbr_phone.home_phone AS Home,   
         mbr_phone.home_ext AS HomeX,   
         mbr_phone.work_phone AS Work,   
         mbr_phone.work_ext AS WorkX,   
         mbr_phone.fax AS Fax,   
         mbr_phone.email AS Email,

		 CASE 
		   WHEN mbr_phone.email='Y' THEN 
			cast(member.new_ssn AS VARCHAR) 
		    ELSE
		   CAST(member.alt_id AS VARCHAR) 
			END 'ExternalID'		   
    FROM [address]
	LEFT JOIN mbr_phone ON address.address_id = mbr_phone.address_id   
    LEFT JOIN member  ON member.member_id = address.sys_rec_id
    WHERE address.subsys_code = 'MB' AND member.member_id = @MemberId
 
       COMMIT TRAN 
	END TRY
	
BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH  
 SET NOCOUNT OFF

END