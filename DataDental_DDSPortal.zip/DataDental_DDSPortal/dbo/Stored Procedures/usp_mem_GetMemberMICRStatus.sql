﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <23-11-2016>
-- Description:	<This sp gets the Member MICR Status by passing member MICR id>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberMICRStatus]
(
	@achMICRsId INT
)
AS
BEGIN
SET NOCOUNT ON;

	SELECT ach_micrs_d.ach_micrs_d_id AS AccountMicrStatusId,
		ach_micrs_d.ach_micrs_id,
		ach_micrs_d.status_code AS StatusCode,
		typ_table.descr AS StatusDescr,
		ach_micrs_d.last_mod_date AS LastModDate,
		ach_micrs_d.last_mod_user AS LastModUser,
		ach_micrs_d.eff_date AS EffDate,
		ach_micrs_d.exp_date AS ExpDate

	 FROM ach_micrs_d 
	 INNER JOIN ach_micrs ON ach_micrs_d.ach_micrs_id=ach_micrs.ach_micrs_id
	 LEFT JOIN typ_table ON typ_table.subsys_code='MB' AND typ_table.tab_name='ach_stat_code' AND typ_table.code=ach_micrs_d.status_code
	 WHERE ach_micrs.ach_micrs_id=@achMICRsId

SET NOCOUNT OFF
END