﻿-- =============================================
-- Author:		<Rajthilak>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_creatememberuser] 
	-- Add the parameters for the stored procedure here
	(
	@userid int output,
	@username varchar(15), 
	@lastname varchar(15),
	@dateofbirth varchar(15) ,
	@phone varchar(15),
	@zip varchar(10),
	@email varchar(250)	
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Begin try
		BEGIN TRAN
		    
			declare @member_id int
			declare @grouptype varchar(4)
			declare @roleid int
			declare @firstname varchar(20)
			declare @middlename varchar(15)
			declare @plan_id int
			declare @group_id int
			select @member_id= member_id,@firstname=first_name,@middlename=middle_init from member_sec mbr inner join address_sec addr on mbr.member_id=addr.sys_rec_id where addr.subsys_code='MB' and addr.addr_type='L' and mbr.last_name=@lastname and mbr.date_of_birth=@dateofbirth and addr.zip=@zip
			select top 1 @grouptype=RTRIM(grp.group_type), @group_id=rel.group_id, @plan_id=rel.plan_id from group_sec grp inner join rlmbgrpl_sec rel on rel.group_id=grp.group_id where rel.member_id=@member_id
			if(@grouptype='SG')
				Begin
					select @roleid=role_id from role_master where role_name='Member SG'
				end
			else
				Begin
					select @roleid=role_id from role_master where role_name='Member EG'
				end
			INSERT INTO member_user_details (member_id,user_name,first_name,last_name,email,date_of_birth,home_phone,zip,status_id,role_id,is_firstlogin,created_date,middle_name,group_id,plan_id) values
			(@member_id,@username,@firstname,@lastname,@email,@dateofbirth,@phone,@zip,4,@roleid,'TRUE',getdate(),@middlename,@group_id,@plan_id)
			SET @userid = cast(scope_identity() as int)
			INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
			VALUES (SCOPE_IDENTITY(),6,1001,0,CONVERT(date,GETDATE()));
		COMMIT
   end try
   Begin Catch
		ROLLBACK
   End catch
END