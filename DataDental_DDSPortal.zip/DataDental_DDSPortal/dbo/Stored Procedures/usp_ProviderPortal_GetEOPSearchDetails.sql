﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_GetEOPSearchDetails]
(
@fromDate DATETIME,
@toDate DATETIME,
@claim VARCHAR(MAX),
@check VARCHAR(MAX)
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @EOPSearchDetails TABLE
(
id INT IDENTITY(1,1),
EOPID VARCHAR(MAX),
CheckValue VARCHAR(MAX),
Payee VARCHAR(MAX),
Amount VARCHAR(MAX),
CheckDate VARCHAR(MAX)
)

INSERT INTO @EOPSearchDetails(EOPID,CheckValue,Payee,Amount,CheckDate)

SELECT top 20 tbl_contact.contact_id,tbl_renewal.group_renewal_id,
'Payee',
'$62123.34',
convert(nvarchar(MAX),  tbl_status.eff_date, 101)
 FROM group_sec grp 
               JOIN rel_gppl_sec rgroupplan on rgroupplan.group_id =grp.group_id
              JOIN  plan_sec tbl_plan on tbl_plan.plan_id =rgroupplan.plan_id 
               JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id 
               JOIN contact_sec tbl_contact  on grp.group_id = tbl_contact.sys_rec_id  
               JOIN group_status_sec tbl_status ON tbl_status.group_id = tbl_address.sys_rec_id                
               JOIN group_renewal_sec tbl_renewal on tbl_renewal.group_id=grp.group_id
            JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type
       WHERE  
	   tbl_address.subsys_code = 'GP'and 
                 tbl_address.addr_type ='L' and 
                 tbl_contact.subsys_code='GP' and
                typ.subsys_code='PL' and typ.tab_name='ins_type' and
				tbl_status.group_status='A4' and
                 grp.group_id =3 and 
                 tbl_plan.plan_id =161
			order by tbl_status.eff_date desc

select * from @EOPSearchDetails

SET NOCOUNT OFF 
END