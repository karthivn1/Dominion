﻿CREATE PROCEDURE [dbo].[usp_GroupPortal_GetMessageCount]
(
@MessageReceiverID varchar(25)
)
AS 
BEGIN 
SET NOCOUNT ON 

SELECT COUNT(is_read) from message_detail where message_receiver_id = @MessageReceiverID
and is_read = 0 and is_new = 1

SET NOCOUNT OFF 
END