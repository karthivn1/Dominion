﻿
CREATE PROCEDURE [dbo].[usp_memberportal_getbillinginformation] 
(
@GroupID INT = NULL
) 
AS 
BEGIN 
SET NOCOUNT ON 

	 SELECT TOP 10 group_id,
			invoice_num as InvoiceNum,
			bil_gen_date as BillGenDate,
			bil_from_date,
			bil_to_date,
			tot_prems as Premium,
			tot_fees as Fees,
			tot_adj as Adj,
			subs_added,
			subs_termed,
			bal_forward as PriorBalance,
			tot_prems as CurrBill,
			bal_forward + tot_prems as TotDue,
			'' as IMSDocId
			FROM [bill_sum_sec] 
			WHERE group_id =@GroupID ORDER BY bil_gen_date DESC

SET NOCOUNT OFF 
END