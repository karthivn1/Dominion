﻿CREATE PROCEDURE [dbo].[usp_GetMemberTypeDetails]
AS 
BEGIN 
SET NOCOUNT ON 

SELECT mbr_code MemberTypeCode,mbr_code_desc MemberTypeName,gender Gender,relation Relation FROM mbr_code

SET NOCOUNT OFF 
END