﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_GetOfficeRosterFacilityDetails] 
(
@facilityid int
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @OfficeRosterFacilityDetails TABLE
(
id INT IDENTITY(1,1),
ActiveEligibilityRoster VARCHAR(MAX),
FacilityName VARCHAR(MAX),
FacilityID VARCHAR(MAX),
TaxID VARCHAR(MAX),
Address1 VARCHAR(MAX),
Address2 VARCHAR(MAX)
)

INSERT INTO @OfficeRosterFacilityDetails(ActiveEligibilityRoster,FacilityName,FacilityID,TaxID,Address1,Address2)
select top 5 getdate(), fc.fc_name ,fc.fc_id,fc.fc_tax_id,addr1,addr2 
from facility_sec fc
left join [address_sec]  addr on addr.sys_rec_id= fc.fc_id
where addr.subsys_code='FC' --and addr.addr_type='FC'
--VALUES('October 20, 2016','Dental LLC','000635','113645254785','3736 Northhampton St, NW','Chevy Chase, DC 20015')

SELECT * FROM @OfficeRosterFacilityDetails

SET NOCOUNT OFF 
END