﻿

CREATE procedure [dbo].[usp_MemberPortal_Contactus]
(
	@username varchar(max),
	@Category varchar(max),
	@message varchar(max)
)
 AS
 Begin

   Begin Transaction [dds_portal]
	 Begin try
			 Declare @userid int;
			 Declare @message_id int;
			 Declare @value varchar(max);
			 Begin
			 If exists ( select user_id from member_user_details  where user_name =@username)
			 Begin 

			 set @userid=(select user_id from member_user_details  where user_name =@username)
			 --message_type_id =2 for contactus reference from Message_type--
			 INSERT into member_message(message,message_type_id,created_by,created_date) values(@message,2,@userid,GETDATE())
	         set @message_id=(SELECT SCOPE_IDENTITY());			
			 set @value=(select Value from app_settings where [Key]= @Category);
		
			if(@value IS NOT NULL)
			 begin
			 Insert into member_message_detail (message_id,message_receiver_id) (select @message_id as message_id,cast( Item as Integer) as message_receiver_id from dbo.SplitString (@value,',') )		  
			end
			
			 INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date) VALUES (@message_id,12,1001,0,CONVERT(date,GETDATE()));

			 select user_id from member_user_details  where user_name =@username
			 
			 End 
			 End
	 commit
	End try

   Begin Catch
    rollback Transaction [adduser]
   End Catch

End