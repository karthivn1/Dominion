﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_ContactUsEmailInfo
-- =============================================
CREATE PROCEDURE [dbo].[usp_ContactUsEmailInfo]
@ref_id INT,
@EventId INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF @EventId=4 OR @EventId=5
BEGIN
	SELECT --m.message_id,
	DISTINCT
	    g.email AS [From],receiver.email AS [To]
		From [message] m
		JOIN group_user_details g on g.[user_id]=m.created_by
		JOIN message_detail d on d.message_id=m.message_id
		JOIN group_user_details receiver on receiver.[user_id]=d.message_receiver_id
		Where m.message_id=@ref_id
		order by  g.email 
END
ELSE 
BEGIN
	SELECT --m.message_id,
	DISTINCT
	    g.email AS [From],receiver.email AS [To]
		From member_message m
		JOIN member_user_details g on g.[user_id]=m.created_by
		JOIN member_message_detail d on d.message_id=m.message_id
		JOIN member_user_details receiver on receiver.[user_id]=d.message_receiver_id
		Where m.message_id=@ref_id
		order by  g.email 
END

END