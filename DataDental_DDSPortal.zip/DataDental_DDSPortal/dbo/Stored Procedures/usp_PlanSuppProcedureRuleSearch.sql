﻿

-- =============================================
-- Author:		chandu
-- Create date: <11-November-2016>
-- Description:	<This sp is used to get list of procedure rules for the given search criteria>
-- =============================================
CREATE PROCEDURE [dbo].[usp_PlanSuppProcedureRuleSearch]
(
@procId int = NULL,
@name varchar(25) = NULL,
@description varchar(30) = NULL,
@codeType varchar(10) = NULL,
@effDate date = NULL,
@expDate date = NULL
)
AS
BEGIN	
	SET NOCOUNT ON;	
SELECT  pl_proc_h.pl_proc_id AS ProcId,
        rtrim(ltrim(pl_proc_h.scheme_cd)) AS Name,           
	rtrim(ltrim(pl_proc_h.code_type)) AS CodeType ,           
	rtrim(ltrim(pl_proc_h.descr)) AS Description,           
	pl_proc_h.eff_date AS EffDate,           
	pl_proc_h.exp_date AS ExpDate     
FROM pl_proc_h (NOLOCK)
WHERE 
((@procId is null and (pl_proc_h.pl_proc_id=pl_proc_h.pl_proc_id or pl_proc_h.pl_proc_id is null))
								or (@procId is not null and  pl_proc_h.pl_proc_id=@procId))
AND
((@name is null and (pl_proc_h.scheme_cd=pl_proc_h.scheme_cd or pl_proc_h.scheme_cd is null))
								or (@name is not null and  pl_proc_h.scheme_cd=@name))
AND
((@description is null and (pl_proc_h.descr=pl_proc_h.descr or pl_proc_h.descr is null))
								or (@description is not null and  pl_proc_h.descr=@description))
AND
((@codeType is null and (pl_proc_h.code_type=pl_proc_h.code_type or pl_proc_h.code_type is null))
								or (@codeType is not null and  pl_proc_h.code_type=@codeType))
AND
((@effDate is null and (pl_proc_h.eff_date=pl_proc_h.eff_date or pl_proc_h.eff_date is null))
								or (@effDate is not null and  pl_proc_h.eff_date=@effDate))
AND
((@expDate is null and (pl_proc_h.exp_date=pl_proc_h.exp_date or pl_proc_h.exp_date is null))
								or (@expDate is not null and  pl_proc_h.exp_date =@expDate))

SET NOCOUNT OFF 
END