﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_ChangePassword]
(
@UserID INT = NULL,
@UserName VARCHAR(MAX),
@Password VARCHAR(MAX),
@NewPassword VARCHAR(MAX),
@HashValue VARCHAR(MAX)
)
AS
BEGIN
SET NOCOUNT ON;
update provider_user_details set password_hash=@NewPassword,status_id=1,is_firstlogin=0, password_reset_date=getdate(), temp_password_unhashed=null WHERE UPPER(user_name) =UPPER(@UserName)
--SET @UserID=(SELECT user_id from provider_user_details where user_name =@UserName)
  
--INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
--VALUES (@UserID,14,1001,0,CONVERT(date,GETDATE()));

SELECT top 1 user_id UserID,user_name UserName,temp_password Password from provider_user_details WHERE UPPER(user_name) =UPPER(@UserName)

SET NOCOUNT OFF;
END