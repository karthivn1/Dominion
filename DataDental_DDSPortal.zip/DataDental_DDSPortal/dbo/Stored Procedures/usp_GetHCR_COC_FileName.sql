﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--DECLARE @fileName NVARCHAR(100)=NULL
--exec usp_GetHCR_COC_FileName 24175,273,@fileName out
--SELECT @fileName
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetHCR_COC_FileName]
@GroupId INT,
@PlanId INT,
@MemberId INT=0,
@FileName nvarchar(100) OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets FROM
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


IF OBJECT_ID('tempdb..#tmpPlan') IS NOT NULL
    DROP TABLE #tmpPlan

DECLARE @EnrolTerr nvarchar(2)=NULL;
DECLARE @CloseTerr INT=NULL;
SET @FileName =''


SELECT @CloseTerr=Parent.close_territory
	FROM group_sec g
	LEFT JOIN group_sec Parent ON Parent.group_id=g.group_parent
	WHERE g.group_id=@GroupId

EXEC usp_GetPrefixPlanFileName @GroupId,@PlanId,@MemberId,@EnrolTerr OUT



SELECT *
	INTO #tmpPlan
	FROM plan_sec p
	WHERE p.plan_id=@PlanId

IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('MA',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	Left(t.id_card_msg,CHARINDEX('MA',t.id_card_msg)-1)+@EnrolTerr+SUBSTRING(t.id_card_msg,(CHARINDEX('MA',t.id_card_msg)+2),20) 
   FROM #tmpPlan t WHERE CHARINDEX('MA',t.id_card_msg)>0

   RETURN 
END



IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('@@@',t.id_card_msg)>0
	AND CHARINDEX('DMNVA',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	REPLACE(t.id_card_msg,'DMNVA','DNIVA') 
   FROM #tmpPlan t WHERE CHARINDEX('@@@',t.id_card_msg)>0
   AND CHARINDEX('DMNVA',t.id_card_msg)>0
   
   RETURN 
END



IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('@@@',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	t.id_card_msg
   FROM #tmpPlan t WHERE CHARINDEX('@@@',t.id_card_msg)>0
   
   RETURN 
END



IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('HIX',t.id_card_msg)>0
	AND CHARINDEX('DMNVA',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	REPLACE(t.id_card_msg,'DMNVA','DNIVA') 
   FROM #tmpPlan t WHERE CHARINDEX('HIX',t.id_card_msg)>0
   AND CHARINDEX('DMNVA',t.id_card_msg)>0
   
   RETURN 
END



IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('HIX',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	t.id_card_msg
   FROM #tmpPlan t WHERE CHARINDEX('HIX',t.id_card_msg)>0
   
   RETURN 
END



IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr=33
	AND CHARINDEX('VA',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	REPLACE(REPLACE(t.id_card_msg,'EHB','HIX'),'DMN','DNI') 
   FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr=33
	AND CHARINDEX('VA',t.id_card_msg)>0
   
   RETURN 
END

IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr<>33
	AND CHARINDEX('VA',t.id_card_msg)>0)
BEGIN

SELECT @FileName= 
	REPLACE(REPLACE(t.id_card_msg,'EHB','@@@'),'DMN','DNI') 
   FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr<>33
	AND CHARINDEX('VA',t.id_card_msg)>0
   
   RETURN 
END

IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr=33)
BEGIN

SELECT @FileName= 
	REPLACE(t.id_card_msg,'EHB','HIX')
   FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr=33
	
   RETURN 
END

IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr<>33)
BEGIN

SELECT @FileName= 
	REPLACE(t.id_card_msg,'EHB','@@@')
   FROM #tmpPlan t WHERE CHARINDEX('EHB',t.id_card_msg)>0
	AND @CloseTerr<>33
	
   RETURN 
END



SELECT @FileName= 
	t.id_card_msg
   FROM #tmpPlan t 

RETURN 
    
END