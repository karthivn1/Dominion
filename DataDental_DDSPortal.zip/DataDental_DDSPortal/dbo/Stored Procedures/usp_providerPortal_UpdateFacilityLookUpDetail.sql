﻿-- =================================================================================================
-- Author:		<Manikandan>
-- Create date: <21-June-2017>
-- Description:	<This stored procedure is used to update the facility details for specific facility>
-- ==================================================================================================
CREATE  PROCEDURE [dbo].[usp_providerPortal_UpdateFacilityLookUpDetail]
(
@facilityid INT,
@category varchar(10),
@reqvalue varchar(max)
)
AS
BEGIN
SET NOCOUNT ON

DECLARE @refId INT, @eventId INT;


		INSERT INTO provider_office_profile (
					facility_id, 
					category, 
					req_value) 
				values (
				@facilityid, 
				@category, 
				@reqvalue) 
				
		SET @refId=SCOPE_IDENTITY() 

		SELECT @eventId = event_id from event_master where event_category = 'OfficeProfile'

		INSERT INTO batch_process_details (
					ref_id, 
					event_id, 
					status,
					retry,
					created_date) 
				values (
				@refId, 
				@eventId, 
				1001,
				0,
				GetDate()) 

SET NOCOUNT OFF
END