﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_group_UpdateImsDocument]
	-- Add the parameters for the stored procedure here
@groupId INT,
@ImsDocuments ImsDocuments READONLY	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @currntDt DATETIME=GETDATE();

IF OBJECT_ID('tempdb..#tempImsDocuments') IS NOT NULL
    DROP TABLE #tempImsDocuments

IF OBJECT_ID('tempdb..#exceptRecord') IS NOT NULL
    DROP TABLE #exceptRecord

--CREATE TABLE #ImsDocuments(
--	doc_id int,
--	doc_type nvarchar(100) NULL,
--	doc_date date NULL,
--	ref_id int NULL,
--	first_name nvarchar(100) NULL,
--	last_name nvarchar(100) NULL
--)

------drop table #tempImsDocuments

--INSERT INTO #ImsDocuments values(435,'Test','2015/07/01',1,'L','R')

--Select *
--INTO #tempImsDocuments
--	From #ImsDocuments 

Select *
INTO #tempImsDocuments
	From @ImsDocuments 


IF EXISTS(SELECT t.doc_id
				FROM #tempImsDocuments t
				WHERE t.doc_id>0)
BEGIN


SELECT t.doc_id,t.ref_id
	INTO #exceptRecord
	FROM #tempImsDocuments t
	EXCEPT 
	SELECT m.doc_id,m.group_id
		FROM group_ims_doc m
		JOIN #tempImsDocuments a ON a.doc_id=m.doc_id AND m.group_id=a.ref_id

		INSERT INTO group_ims_doc(doc_id,
		doc_type,
		doc_date,
		group_id,
		isNew,
		InsertedOn)
		SELECT t.doc_id,t.doc_type,t.doc_date,t.ref_id,1 AS isNew,@currntDt AS insertDate
			FROM #tempImsDocuments t
			JOIN #exceptRecord e on e.doc_id=t.doc_id AND e.ref_id=t.ref_id

END

IF EXISTS(SELECT m.Id
	FROM group_ims_history m WHERE m.group_id=@groupId)
	BEGIN
		--SELECT *
		UPDATE m SET m.updated_on=@currntDt
		FROM group_ims_history m WHERE m.group_id=@groupId
		
	END
	ELSE 
	BEGIN

		INSERT INTO group_ims_history(group_id,updated_on) 
		VALUES(@groupId,@currntDt)	
	END

END