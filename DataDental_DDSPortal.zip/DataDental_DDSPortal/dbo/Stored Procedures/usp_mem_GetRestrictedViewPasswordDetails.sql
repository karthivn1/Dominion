﻿
-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <28-12-2016>
-- Description:	<This SP is used to Display the details for Restricted View Password Screen >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_GetRestrictedViewPasswordDetails]   
(
@memId INT=NULL

)AS
BEGIN
SET NOCOUNT ON;
  SELECT sub_restrict.sub_restrict_id ,   
         sub_restrict.password AS [Password],   
         sub_restrict.void_sw AS Void,   
         member.last_name+member.first_name AS Name,  
         
         member.date_of_birth AS DOB,   
		 mbrcode.mbr_code_desc AS Relation
    FROM   sub_restrict join  member  
   ON  sub_restrict.family_id = member.family_id 
   join mbr_code mbrcode ON mbrcode.mbr_code=member.member_code  and  
          sub_restrict.member_id = member.member_id 
         WHERE  member.family_id =  @memId

			SET NOCOUNT OFF
END