﻿
CREATE proc [dbo].[usp_ProviderPortal_GetRoleMaster]
as
begin

select role_id RoleID,role_name RoleName,portal_type PortalType from role_master

where role_id in (10,11,12)

end