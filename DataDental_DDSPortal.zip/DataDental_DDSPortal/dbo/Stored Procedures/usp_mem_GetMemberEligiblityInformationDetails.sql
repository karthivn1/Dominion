﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <25-11-2016>
-- Description:	<This sp gets the Member Eligiblity Information Details by passing memberId And AsOfDate>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberEligiblityInformationDetails] --1081528,'03-01-2014'
(
@memberId INT,
@asOfDate Datetime
)
AS
BEGIN
SET NOCOUNT ON;
		SELECT member.member_id,   
			 rlplfc.rlplfc_id,   
			 member.family_id,			    
			 member.first_name +' '+member.last_name AS Name,   
			 member.middle_init,   
			 member.member_code,
			 mbrCode.mbr_code_desc AS Relation, 
			 rlplfc.eff_date AS EffDate,
			 (SELECT CASE WHEN rlmbgrpl.exp_gr_pl IS NOT NULL THEN 
				(CASE WHEN rlplfc.exp_date IS NOT NULL THEN (CASE WHEN rlplfc.exp_date>rlmbgrpl.exp_gr_pl THEN rlmbgrpl.exp_gr_pl ELSE rlplfc.exp_date END) 
				  ELSE (CASE WHEN rlplfc.eff_date>rlmbgrpl.eff_gr_pl THEN rlplfc.eff_date ELSE rlmbgrpl.eff_gr_pl END) END ) 
			  ELSE rlplfc.exp_date END) AS ExpDate, 
			 rlplfc.exp_date,   
			 member.date_of_birth,
			 CAST (rlplfc.facility_id AS NVARCHAR)+'-'+ facility.fc_name AS Facility,   
			 facility.fc_type,
			 member.member_ssn,
			 member.student_flag,
			 member.disable_flag,
			 rlmbgrpl.eff_gr_pl,
			 rlmbgrpl.exp_gr_pl,  
			 rlmbgrpl.action_code,
			 rlplfc.action_code,
			 CAST (rlmbgrpl.plan_id AS NVARCHAR)+'-'+[plan].plan_dsp_name AS PlanNameorID,
			 [plan].ins_type,   
			 [plan].ins_opt

		FROM rlplfc
		INNER JOIN member ON member.member_id = rlplfc.member_id
		INNER JOIN mbr_code mbrCode ON mbrCode.mbr_code=member.member_code
		INNER JOIN rlmbgrpl ON rlmbgrpl.mb_gr_pl_id = rlplfc.mb_gr_pl_id
		INNER JOIN [plan] ON [plan].plan_id = rlmbgrpl.plan_id
		LEFT OUTER JOIN facility ON rlplfc.facility_id = facility.fc_id
	   WHERE member.family_id = @memberId  AND (((rlmbgrpl.eff_gr_pl <= @asOfDate AND (rlmbgrpl.exp_gr_pl > @asOfDate OR rlmbgrpl.exp_gr_pl IS NULL)) 
			 AND ((rlplfc.eff_date <= @asOfDate AND (rlplfc.exp_date > @asOfDate OR rlplfc.exp_date IS NULL))  
			 OR (rlplfc.eff_date > @asOfDate AND (rlplfc.exp_date > rlplfc.eff_date OR rlplfc.exp_date IS NULL) ) ))
			 OR ((rlmbgrpl.eff_gr_pl > @asOfDate AND (rlmbgrpl.exp_gr_pl > rlmbgrpl.eff_gr_pl OR  rlmbgrpl.exp_gr_pl IS NULL) ) 
			 AND (rlplfc.eff_date > @asOfDate AND (rlplfc.exp_date > rlplfc.eff_date OR rlplfc.exp_date IS NULL)) )) 
			 AND (rlmbgrpl.cobra_flag IS NULL OR (rlmbgrpl.cobra_flag IS NOT NULL AND rlmbgrpl.cobra_flag <> 'P'))
	ORDER BY rlmbgrpl.plan_id ASC,member.member_code ASC


 SET NOCOUNT OFF
END