﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_insert_payment_history]
	-- Add the parameters for the stored procedure here
@CustomerProfile nVarchar(100),
@TransactionId nVarchar(100),
@Amount decimal(16,2)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @groupId INT=0
DECLARE @ctDate DATETIME=GETDATE();
DECLARE @payment_method nVarchar(150)=NULL

SELECT @groupId=a.group_id
	FROM authorize_net_profile a
	WHERE a.customer_profile=@CustomerProfile

INSERT INTO payment_history(transaction_id,group_id,payment_date,amountpaid,payment_method)
	VALUES(@TransactionId,@groupId,@ctDate,@Amount,@payment_method)

END