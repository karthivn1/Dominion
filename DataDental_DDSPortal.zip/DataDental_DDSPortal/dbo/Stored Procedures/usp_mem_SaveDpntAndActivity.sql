﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <17-01-2017>
-- Description:	<This SP is used to Update Cobra pending Status on Terminate Subscriber Function>
-- =============================================
 


CREATE PROCEDURE [dbo].[usp_mem_SaveDpntAndActivity]
(
@MemberGroupPlanId INT,
@subsystemCode VARCHAR(100)=NULL,
@systemRecordId INT=NULL,
@reasonCode VARCHAR(100)=NULL,
@activityMasterId INT=NULL, 
@userCode VARCHAR(100)=NULL,
@groupId INT=NULL, 
@actionCode	VARCHAR(2)=NULL,
@effDate DATETIME=NULL,
@rateCode NVARCHAR(2)=NULL
)
AS
BEGIN
SET NOCOUNT ON;

 DECLARE @NewMSI INT 
 DECLARE @newMbrGroupPlanId INT
  BEGIN TRAN 
	BEGIN TRY

  IF (@actionCode='CP')
  BEGIN
   
   UPDATE [sysdatetime] SET msi = msi + 1
   SET @NewMSI=(SELECT msi FROM [sysdatetime])

   INSERT INTO rlmbgrpl(member_id,group_id,plan_id,sub_in_plan,eff_gr_pl,exp_gr_pl,cobra_flag,action_code,h_datetime,h_action,h_user,h_msi)
   SELECT @systemRecordId,@groupId,plan_id,sub_in_plan,@effDate,null,'P',@actionCode,GETDATE(),@actionCode,@userCode,@NewMSI FROM rlmbgrpl WHERE mb_gr_pl_id=@MemberGroupPlanId 

   SET @newMbrGroupPlanId=SCOPE_IDENTITY()
   --UPDATE rlmbgrpl SET eff_gr_pl=@effDate,exp_gr_pl=null,cobra_flag='P',action_code=@actionCode,h_datetime=GETDATE() WHERE mb_gr_pl_id=SCOPE_IDENTITY()

   --UPDATE rlplfc SET exp_date=@effDate WHERE mb_gr_pl_id = @MemberGroupPlanId

   UPDATE [sysdatetime] SET msi = msi + 1
   SET @NewMSI=(SELECT msi FROM [sysdatetime])

   INSERT INTO rlplfc (mb_gr_pl_id,member_id, facility_id, eff_date, action_code, h_datetime, h_msi, h_action, h_user )
   SELECT @newMbrGroupPlanId,member_id,facility_id, @effDate, @actionCode, GETDATE(), @NewMSI, @actionCode,@userCode
   FROM rlplfc where  mb_gr_pl_id=@MemberGroupPlanId    
   
   UPDATE [sysdatetime] SET msi = msi + 1
   SET @NewMSI=(SELECT msi FROM [sysdatetime])

   INSERT INTO rlmbrt ( mb_gr_pl_id, rate_code, eff_rt_date, action_code, h_datetime, h_msi, h_action, h_user )
   VALUES (@newMbrGroupPlanId,@rateCode,@effDate,@actionCode,GETDATE(),@NewMSI,@actionCode,@userCode)
 
   END

 
 BEGIN 
 IF @activityMasterId>0 
 BEGIN
		EXEC usp_SaveActivity @subsystemCode,@systemRecordId,@reasonCode,@activityMasterId,@userCode
 END
 END 
 COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
   	SET NOCOUNT OFF
END