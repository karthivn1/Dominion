﻿

-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <03-01-2017>
-- Description:	<This SP is used to Update the Susbcriber Stasus as Cobra >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_SaveCobraUpdate] 
(
@memberId INT=NULL, 
@memberGroupPlanId INT=NULL, 
@groupId INT=NULL, 
@planId INT=NULL, 
@effDate DATETIME=NULL, 
@actionCode VARCHAR(100)=NULL, 
@hUser VARCHAR(100)=NULL, 
@SiP INT=NULL, 
@rateCode VARCHAR(100)=NULL,
@NewMemberGroupPlanId INT output
) 
AS 
  BEGIN 
      SET NOCOUNT ON; 

      BEGIN TRAN 

      BEGIN TRY 
          DECLARE @hmsi INT 

          IF ( @actionCode = 'COBRA Active' ) 
            BEGIN 
                --UPDATE rlmbrt 
                --SET    exp_rt_date = @effDate, 
                --       action_code = 'CT' 
                --WHERE  mb_gr_pl_id = @memberGroupPlanId 
                --       AND exp_rt_date IS NULL 

                UPDATE rlmbgrpl 
                SET    exp_gr_pl = @effDate, 
                       action_code = 'CT' 
                WHERE  mb_gr_pl_id = @memberGroupPlanId 
                       AND exp_gr_pl IS NULL 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                INSERT INTO rlmbgrpl 
                            (member_id, 
                             group_id, 
                             plan_id, 
                             eff_gr_pl, 
                             action_code, 
                             cobra_flag, 
                             h_datetime, 
                             h_msi, 
                             h_action, 
                             h_user, 
                             sub_in_plan) 
                VALUES     (@memberId, 
                            @groupId, 
                            @planId, 
                            @effDate, 
                            'CC', 
                            'C', 
                            Getdate(), 
                            @hmsi, 
                            'CC', 
                            @hUser, 
                            @SiP) 

                SET @NewMemberGroupPlanId=Scope_identity() 

                UPDATE sysdatetime 
                SET    msi = msi + 1 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                INSERT INTO rlmbrt 
                            (mb_gr_pl_id, 
                             rate_code, 
                             eff_rt_date, 
                             action_code, 
                             h_datetime, 
                             h_msi, 
                             h_action, 
                             h_user) 
                VALUES      (@NewMemberGroupPlanId, 
                             @rateCode, 
                             @effDate, 
                             'CC', 
                             Getdate(), 
                             @hmsi, 
                             'CC', 
                             @hUser) 

                UPDATE sysdatetime 
                SET    msi = msi + 1 
            END 
          ELSE IF @actionCode = 'Active' 
            BEGIN 
                --UPDATE rlmbrt 
                --SET    exp_rt_date = @effDate, 
                --       action_code = 'ST' 
                --WHERE  mb_gr_pl_id = @memberGroupPlanId 
                --       AND exp_rt_date IS NULL 

                UPDATE rlmbgrpl 
                SET    exp_gr_pl = @effDate, 
                       action_code = 'ST' 
                WHERE  mb_gr_pl_id = @memberGroupPlanId 
                       AND exp_gr_pl IS NULL 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                INSERT INTO rlmbgrpl 
                            (member_id, 
                             group_id, 
                             plan_id, 
                           eff_gr_pl, 
                         action_code, 
                             cobra_flag, 
                             h_datetime, 
                             h_msi, 
                             h_action, 
                             h_user, 
                             sub_in_plan) 
                VALUES     (@memberId, 
                            @groupId, 
                            @planId, 
                            @effDate, 
                            'CA', 
                            'A', 
                            Getdate(), 
                            @hmsi, 
                            'CA', 
                            @hUser, 
                            @SiP) 

                SET @NewMemberGroupPlanId=Scope_identity() 

                UPDATE sysdatetime 
                SET    msi = msi + 1 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                INSERT INTO rlmbrt 
                            (mb_gr_pl_id, 
                             rate_code, 
                             eff_rt_date, 
                             action_code, 
                             h_datetime, 
                             h_msi, 
                             h_action, 
                             h_user) 
                VALUES      (@NewMemberGroupPlanId, 
                             @rateCode, 
                             @effDate, 
                             'CA', 
                             Getdate(), 
                             @hmsi, 
                             'CA', 
                             @hUser) 

                UPDATE sysdatetime 
                SET    msi = msi + 1 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                UPDATE sysdatetime 
                SET    msi = msi + 1 
            END 
          ELSE IF @actionCode = 'Terminated' 
            BEGIN 
                --UPDATE rlmbrt 
                --SET    exp_rt_date = @effDate, 
                --       h_action = 'ST' 
                --WHERE  mb_gr_pl_id = @memberGroupPlanId 
                --       AND exp_rt_date IS NULL 

                UPDATE rlmbgrpl 
                SET    exp_gr_pl = @effDate, 
                       h_action = 'ST' 
                WHERE  mb_gr_pl_id = @memberGroupPlanId 
                       AND exp_gr_pl IS NULL 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                INSERT INTO rlmbgrpl 
                            (member_id, 
                             group_id, 
                             plan_id, 
                             eff_gr_pl, 
                             action_code, 
                             cobra_flag, 
                             h_datetime, 
                             h_msi, 
                             h_action, 
                             h_user, 
                             sub_in_plan) 
                VALUES     (@memberId, 
                            @groupId, 
                            @planId, 
                            @effDate, 
                            'CP', 
                            'P', 
                            Getdate(), 
                            @hmsi, 
                            'CP', 
                            @hUser, 
                            @SiP) 

                SET @NewMemberGroupPlanId=Scope_identity() 

                UPDATE sysdatetime 
                SET    msi = msi + 1 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                INSERT INTO rlmbrt 
                            (mb_gr_pl_id, 
                             rate_code, 
                             eff_rt_date, 
                             action_code, 
                             h_datetime, 
                             h_msi, 
                             h_action, 
               h_user) 
                VALUES      (@NewMemberGroupPlanId, 
                             @rateCode, 
                             @effDate, 
                             'CP', 
                             Getdate(), 
                             @hmsi, 
                             'CP', 
                             @hUser) 

                UPDATE sysdatetime 
                SET    msi = msi + 1 

                SELECT @hmsi = msi + 1 
                FROM   sysdatetime 

                UPDATE sysdatetime 
                SET    msi = msi + 1 
            END 
		  ELSE
			BEGIN
                UPDATE rlmbgrpl 
                SET    exp_gr_pl = @effDate,
					   cobra_flag=null, 
					   action_code='ST',
                       h_action = 'ST' 
                WHERE  mb_gr_pl_id = @memberGroupPlanId 
                       AND exp_gr_pl IS NULL                 

                SET @NewMemberGroupPlanId=0 

                
            END 
          COMMIT TRAN 
      END TRY 

      BEGIN CATCH 
          ROLLBACK TRAN 

          DECLARE @erMessage  NVARCHAR(2048), 
                  @erSeverity INT, 
                  @erState    INT 

          SELECT @erMessage = Error_message(), 
                 @erSeverity = Error_severity(), 
                 @erState = Error_state() 

          RAISERROR (@erMessage,@erSeverity,@erState ) 
      END CATCH 

      SET NOCOUNT OFF 
  END