﻿CREATE PROCEDURE [dbo].[usp_GetEditGroupSummaryDetails] 
(
@GroupID INT,
@PlanID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @GroupSummary TABLE
(
id INT IDENTITY(1,1),
GroupID INT ,
GroupName VARCHAR(max),
PlanID INT,
PlanName VARCHAR(MAX),
Address VARCHAR(MAX),
Phone VARCHAR(50),
EffectiveDate VARCHAR(50),
PlanEffectiveDate VARCHAR(50),
PlanType VARCHAR(MAX),
RenewalDate VARCHAR(50),
Address1 VARCHAR(MAX),
Address2 VARCHAR(MAX),
City VARCHAR(MAX),
StateCode VARCHAR(50),
Zip VARCHAR(MAX)
)

INSERT INTO @GroupSummary(GroupID ,GroupName ,PlanID ,PlanName ,Address ,Phone ,EffectiveDate,PlanEffectiveDate ,PlanType ,RenewalDate,Address1,Address2,City,StateCode,Zip)
SELECT top 1 grp.group_id,RTRIM(grp.group_name),
tbl_plan.plan_id,RTRIM(tbl_plan.plan_name), 
RTRIM(tbl_address.addr1) + + RTRIM(tbl_address.addr2) + +RTRIM(tbl_address.city) + ' '+RTRIM(tbl_address.country) +' , '+RTRIM(tbl_address.[state]) +' '+RTRIM(tbl_address.zip) as addresss,
RTRIM(tbl_contact.phone1),
convert(nvarchar(MAX),  tbl_status.eff_date, 101),
convert(nvarchar(MAX),  tbl_status.eff_date, 101),
RTRIM(tbl_plan.ins_type) as plan_type,
convert(nvarchar(MAX),  tbl_renewal.renewal_date, 101),
RTRIM(tbl_address.addr1),RTRIM(tbl_address.addr2),RTRIM(tbl_address.city),RTRIM(tbl_address.state),RTRIM(tbl_address.zip)
 FROM group_sec grp 
               JOIN rel_gppl_sec rgroupplan on rgroupplan.group_id =grp.group_id
              JOIN  plan_sec tbl_plan on tbl_plan.plan_id =rgroupplan.plan_id 
               JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id 
               JOIN contact_sec tbl_contact  on grp.group_id = tbl_contact.sys_rec_id  
               JOIN group_status_sec tbl_status ON tbl_status.group_id = tbl_address.sys_rec_id 
               --JOIN group_rules tbl_group_rules on tbl_group_rules.rel_gppl_id=rgroupplan.rel_gppl_id
               JOIN group_renewal_sec tbl_renewal on tbl_renewal.group_id=grp.group_id
            JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type
       WHERE  
	   tbl_address.subsys_code = 'GP'and 
                 tbl_address.addr_type ='L' and 
                 tbl_contact.subsys_code='GP' and
                typ.subsys_code='PL' and typ.tab_name='ins_type' and
				tbl_status.group_status='A4' and
                 grp.group_id =@GroupID and 
                 tbl_plan.plan_id =@PlanID
			order by tbl_status.eff_date desc

SELECT * FROM @GroupSummary

SELECT * FROM @GroupSummary

select distinct rtrim(contact_sec.lname) + ','+ rtrim(contact_sec.fname) GroupAdminName, contact_sec.phone1 ContactNo
from contact_sec 
join address_sec addr on addr.sys_rec_id=contact_sec.sys_rec_id
join group_sec grp on grp.group_id=addr.sys_rec_id
join group_status_sec sta on grp.group_id=sta.group_id
join rel_gppl_sec reg on reg.group_id=grp.group_id
join plan_sec pln on pln.plan_id=reg.plan_id
where contact_sec.subsys_code='GP' and contact_sec.addr_type='L'
and sta.group_status='A4' and addr.subsys_code='GP' and grp.group_id=@GroupID

SELECT code StateCode,sname StateName FROM state_sec

SET NOCOUNT OFF 
END