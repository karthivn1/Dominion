﻿
-- =============================================
-- Author:		<Rajthilak.S, 597994>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_messageeditor_addattachments] 
	-- Add the parameters for the stored procedure here
	(
@messageid int,
@filename as varchar(350)= NULL,
@file as VarBinary(max)
	)
AS
Begin
SET NOCOUNT ON 
Begin Transaction 

	Begin try
		Declare @userId int; 

		Insert into [member_message_attachment] (message_id,attachment_filename,attachment_file)
		values
		(@messageid,@filename,@file)

		select @messageid;
		 --End

commit Transaction
   End try

	Begin Catch
		rollback Transaction 
	End Catch
SET NOCOUNT OFF
End