﻿

-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <21-02-2017>
-- Description:	<This sp gets the Member Eligiblity Next benefit by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberEligiblityNextBenefitDetails]
(
@memberGroupPlanId INT
)
AS
BEGIN
SET NOCOUNT ON;
	  
	   SELECT rlmbgrpl.group_id,   
			  member.last_name AS LastName,   
			  member.first_name AS FirstName,   
			  member.middle_init,   
			  rlmbgrpl.plan_id,   
			  rlmbgrpl.mb_gr_pl_id,   
			  gppl_benefit.benefit_category AS BenefitCategory,   
			  gppl_benefit.benefit_period AS BenefitPeriod,   
			  gppl_benefit_d.list_name AS ListName,   
			  (SELECT DATEADD(m,gppl_benefit.benefit_period,max(claim_d.svc_beg))  --max(claim_d.svc_beg) + gppl_benefit.benefit_period UNITS MONTH  
					FROM claim_d 
					INNER JOIN claim_h ON claim_h.claim_id = claim_d.claim_id
					INNER JOIN rlplfc plfc ON plfc.rlplfc_id = claim_h.rlplfc_id AND claim_h.mbgrpl_id = plfc.mb_gr_pl_id
					INNER JOIN member mb ON plfc.member_id = mb.member_id
					INNER JOIN claim_lists ON claim_lists.list_name = gppl_benefit_d.list_name
					INNER JOIN claim_lists_d ON claim_lists_d.claim_list_id = claim_lists.claim_list_id AND claim_d.d_proc_code = claim_lists_d.value
					WHERE claim_d.status = 'Processed' AND plfc.member_id = member.member_id  AND claim_h.mbgrpl_id = @memberGroupPlanId )  AS NextBenefitdate
		FROM gppl_benefit   
			 INNER JOIN	gppl_benefit_d ON gppl_benefit.gppl_benefit_id = gppl_benefit_d.gppl_benefit_id			 
			 INNER JOIN	rel_gppl ON rel_gppl.rel_gppl_id = gppl_benefit.rel_gppl_id
			 INNER JOIN	rlmbgrpl ON rlmbgrpl.plan_id = rel_gppl.plan_id AND rlmbgrpl.group_id = rel_gppl.group_id
			 INNER JOIN	rlplfc ON  rlmbgrpl.mb_gr_pl_id = rlplfc.mb_gr_pl_id
			 INNER JOIN	member ON rlplfc.member_id = member.member_id
		WHERE  rlmbgrpl.mb_gr_pl_id = @memberGroupPlanId  AND rlmbgrpl.exp_gr_pl IS NULL AND gppl_benefit.exp_date IS NULL

SET NOCOUNT OFF
END