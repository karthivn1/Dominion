﻿CREATE procedure [dbo].[usp_MemberPortal_EditUserSearch] 
(

@username as Varchar(max)=NULL
)
AS
Begin
SET NOCOUNT ON 



select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,tbl_udetails.Role as Role,tbl_udetails.Role_Id as RoleId,tbl_udetails.EmailNotifications ,
tbl_udetails.Phone,tbl_udetails.Email,tbl_udetails.MiddleInitial ,Status as User_Status, CONVERT(VARCHAR(10), tbl_udetails.DateOfBirth, 101) as DateOfBirth
from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,
tbl_userdetails.middle_name as MiddleInitial, tbl_userdetails.home_phone as Phone,tbl_userdetails.email_notification  as EmailNotifications ,
tbl_userdetails.date_of_birth as DateOfBirth,
tbl_status.status as Status,
 role_master.role_name as  Role,
tbl_userdetails.email as Email,tbl_userdetails.role_id as Role_Id

 from member_user_details as tbl_userdetails
inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
inner join role_master on tbl_userdetails.role_id =role_master .role_id and ( role_master.portal_type='mbr' or role_master.portal_type='common')
--Left join [dds_prod_data].[dbo].[group] as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id 
where status in('Active', 'Pending','Deactivated'))  tbl_udetails
where  (tbl_udetails.UserName=@username)  
SET NOCOUNT OFF
End