﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <25-11-2016>
-- Description:	<This sp gets the Member Eligiblity Rollover Details by passing memberId and AsOfDate>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberEligiblityRolloverDetails]
(
@memberId INT,
@asOfDate Datetime
)
AS
BEGIN
SET NOCOUNT ON;
	SELECT  rollover.rollover_id,
		rollover.group_id AS GroupID,
		rollover.plan_id AS PlanID,
		rollover.member_id,
		rollover.[year] AS [Year],
		rollover.from_date AS [From],
		rollover.to_date AS [To],
		rollover.carried_over AS Carriedover,
		rollover.plan_paid AS PlanPaid,
		rollover.ro_applied AS RoApplied,
		rollover.manual_adj,
		rollover.[status],
		rollover.msg,
		rollover.created_by,
		rollover.created_on,
		rollover.h_user,
		rollover.h_datetime,
		member.first_name +' '+member.last_name AS Name,
		member.middle_init,
		member.date_of_birth,
		member.member_code,
		mbrCode.mbr_code_desc AS Relation,
		rollover.plan_max AS PlanMax,
		rollover.rollover AS RollOver,
		rollover.threshold AS ThresHold,
		rollover.max_rollover,
		rollover.preventive_met AS PrvMet,
		rollover.preventive_list,
		rollover.preventive_num
	FROM rollover
	INNER JOIN member ON rollover.member_id = member.member_id AND member.family_id = rollover.family_id
	INNER JOIN rlmbgrpl ON rlmbgrpl.group_id = rollover.group_id AND rlmbgrpl.plan_id = rollover.plan_id AND rollover.family_id = rlmbgrpl.member_id
	INNER JOIN mbr_code mbrCode ON mbrCode.mbr_code=member.member_code
	WHERE rollover.family_id  = @memberId AND rlmbgrpl.eff_gr_pl <= @asOfDate AND rlmbgrpl.exp_gr_pl IS NULL OR rlmbgrpl.exp_gr_pl > @asOfDate

 SET NOCOUNT OFF
END