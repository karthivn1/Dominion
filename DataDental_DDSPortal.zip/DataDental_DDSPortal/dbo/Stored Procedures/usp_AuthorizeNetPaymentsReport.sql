﻿CREATE PROCEDURE [dbo].[usp_AuthorizeNetPaymentsReport]
(
@fromDate DATETIME,
@toDate DATETIME
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @AuthorizeNetPayments TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(MAX),
Amount VARCHAR(MAX),
TransactionID VARCHAR(MAX),
Date VARCHAR(MAX)
)

INSERT INTO @AuthorizeNetPayments(GroupID ,Amount ,TransactionID ,Date)

select CONVERT(varchar(MAX), group_id),CONVERT(varchar(MAX), amountpaid),
CONVERT(varchar(MAX), transaction_id),
CONVERT(nvarchar(MAX),payment_date, 101)+' '+CONVERT(nvarchar(MAX),FORMAT(CAST(payment_date AS DATETIME),'hh:mm:ss tt')) from payment_history WHERE payment_date BETWEEN @fromDate AND @toDate

SELECT * FROM @AuthorizeNetPayments

SET NOCOUNT OFF 
END