﻿


-- =============================================
-- Author:		V.M.HEMANANTH
-- Create date: 17/04/2017
-- Description:	TO GET MEMBER CLAIM DETAILS FOR MEMBER CLAIM HISTROY TAB
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberClaimDetails]
	-- Add the parameters for the stored procedure here
	(@memberId INT,
	 @groupId INT,
	 @planId INT)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Declare @begindate DATE, @enddate DATE, @OrthoPaid INT, @Prophy INT ,@Bitewings INT,@ProblemFocussed INT, @Flouride INT, @FMPAN INT ,@Emer INT,@planpaid INT;
		 
	SET @begindate = CONVERT(varchar(10),  CONVERT(varchar(10), YEAR(GETDATE())) + '-01-01', 101);
    SET @enddate = CONVERT(varchar(10),  CONVERT(varchar(10), YEAR(GETDATE()) +1) + '-01-01', 101);
	 
 SELECT  @OrthoPaid = sum(claim_d.plan_resp) FROM claim_d,  claim_h,  rlmbgrpl,  rlplfc,  member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'Ortho' AND typ_table_exp.code = claim_d.d_proc_code	AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND claim_d.svc_beg >= @begindate AND
			claim_d.svc_beg < @enddate	GROUP BY member.member_id;
					
					
 SELECT @Prophy = count(claim_d.claim_d_id) FROM claim_d,  claim_h,   rlmbgrpl,   rlplfc,  member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and  ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'Prophy' AND typ_table_exp.code = claim_d.d_proc_code AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND
			claim_d.svc_beg >= @begindate AND claim_d.svc_beg < @enddate	GROUP BY member.member_id;	

 SELECT @Bitewings = count(claim_d.claim_d_id) FROM claim_d,  claim_h,   rlmbgrpl,   rlplfc,  member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and  ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'Bitewings' AND typ_table_exp.code = claim_d.d_proc_code AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND
			claim_d.svc_beg >= @begindate AND claim_d.svc_beg < @enddate	GROUP BY member.member_id;

 SELECT  @ProblemFocussed = count(claim_d.claim_d_id) FROM claim_d,  claim_h,   rlmbgrpl,   rlplfc,  member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and  ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'ProblemFocussed' AND typ_table_exp.code = claim_d.d_proc_code AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND
			claim_d.svc_beg >= @begindate AND claim_d.svc_beg < @enddate	GROUP BY member.member_id;

			
 SELECT  @Flouride = count(claim_d.claim_d_id) FROM claim_d,  claim_h,   rlmbgrpl,   rlplfc, member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and  ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'Flouride' AND typ_table_exp.code = claim_d.d_proc_code AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND
			claim_d.svc_beg >= @begindate AND claim_d.svc_beg < @enddate	GROUP BY member.member_id;

SELECT  @FMPAN = count(claim_d.claim_d_id) FROM claim_d,  claim_h,   rlmbgrpl,   rlplfc,  member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and  ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'FMPAN' AND typ_table_exp.code = claim_d.d_proc_code AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND
			claim_d.svc_beg >= @begindate AND claim_d.svc_beg < @enddate	GROUP BY member.member_id;

SELECT  @Emer = count(claim_d.claim_d_id) FROM claim_d,  claim_h,   rlmbgrpl,   rlplfc,  member , typ_table_exp 
   WHERE ( claim_h.claim_id = claim_d.claim_id ) and  ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and  ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and  
         ( rlplfc.member_id = member.member_id ) and  ( ( claim_d.reversal_switch = 0 ) AND  ( claim_d.status = 'Processed' ) AND
			typ_table_exp.subsys_code = 'CL' AND typ_table_exp.tab_name = 'Emer' AND typ_table_exp.code = claim_d.d_proc_code AND  
         ( rlmbgrpl.group_id = @groupId ) AND  ( rlmbgrpl.plan_id = @planId ) AND  ( rlplfc.member_id = @memberId ) ) AND
			claim_d.svc_beg >= @begindate AND claim_d.svc_beg < @enddate	GROUP BY member.member_id;


 SELECT top 1 @planpaid = sum(claim_d.plan_resp)     FROM        claim_d ,      
            claim_h ,                  rlmbgrpl ,                  rlplfc ,                  member     WHERE ( claim_h.claim_id = claim_d.claim_id ) and  
			( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and          ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and       
			( rlplfc.member_id = member.member_id ) and          ( ( claim_d.reversal_switch = 0 ) and          ( claim_d.status = 'Processed' ) and  
			( rlmbgrpl.group_id = @groupId ) and          ( rlmbgrpl.plan_id = @planId ) and          ( rlplfc.member_id = @memberId ) and     
			( claim_d.svc_beg >= @begindate ) and          ( claim_d.svc_beg <= @enddate  ) ) 
			GROUP BY member.member_id 


	 SELECT DISTINCT  member.first_name AS 'MemberName',      
                  member.middle_init ,   
				  member.last_name ,
				  member.member_code ,    
                  member.member_id ,        
		          member.family_id ,        
				  member.date_of_birth AS 'DOB' ,   
				  YEAR(GETDATE()) AS 'Year', 
				  ( SELECT top 1      sum(claim_d.ded_applied) deduct    FROM        claim_d ,      
            claim_h ,                  rlmbgrpl ,                  rlplfc ,                  member     WHERE ( claim_h.claim_id = claim_d.claim_id ) and  
			( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) and          ( rlplfc.rlplfc_id = claim_h.rlplfc_id ) and       
			( rlplfc.member_id = member.member_id ) and          ( ( claim_d.reversal_switch = 0 ) and          ( claim_d.status = 'Processed' ) and  
			( rlmbgrpl.group_id = @groupId ) and          ( rlmbgrpl.plan_id = @planId ) and          ( rlplfc.member_id = @memberId ) and     
			( claim_d.svc_beg >= @begindate  ) and          ( claim_d.svc_beg <= @enddate  ) ) 
			GROUP BY member.member_id ) AS 'DedPaid' ,
		(@planpaid - @OrthoPaid) AS 'PlanIDPaid',
				 @OrthoPaid AS 'OrthoPaid',
				  @planpaid AS 'TotalBenefit',
				 @Prophy AS 'Prophy',
				 @FMPAN AS 'FMorPlan',
				 @Bitewings AS 'BiteWing',
				 @Flouride AS 'Flouride',
				 @Emer AS 'EmerExam',
				 @ProblemFocussed AS 'ProbFocus', 
				 @begindate AS 'From' ,
				 @enddate AS 'To'    FROM     
				 member ,  rlmbgrpl     WHERE ( member.family_id = rlmbgrpl.member_id ) and  
			     ( ( rlmbgrpl.member_id = @memberId ) and          ( rlmbgrpl.group_id = @groupId ) and  
				 ( rlmbgrpl.plan_id = @planId ) )


				 EXEC [usp_mem_GetMemberClaimDatas] @memberId,@groupId,@planId,0
 
END