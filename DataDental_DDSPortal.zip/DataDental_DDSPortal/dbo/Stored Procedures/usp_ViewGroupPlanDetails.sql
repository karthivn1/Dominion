﻿CREATE procedure [dbo].[usp_ViewGroupPlanDetails] 
(
@username varchar(max)
)
AS
Begin
SET NOCOUNT ON 
Declare @userid int;
Declare @zip varchar(max);
Declare @email varchar(max);
Declare @lname varchar(max);
Declare @groupid int;
Declare @plan_id int;
Declare @status varchar(max);
Declare @roleid varchar(max);

Declare @roledetails Table
(roleid int);
select @userid=user_id,@lname=last_name,@email=email,@zip=group_zip from group_user_details where user_name=@username
insert into @roledetails (roleid) 
select role_id  from group_user_details where  user_id=@userid;
  If exists( select * from @roledetails where roleid in (3,7))
          Begin
		  if exists(select 1 from contact_sec as contact join [address_sec] addr on addr.sys_rec_id=contact.sys_rec_id
				join [group_sec] grp on grp.group_id=addr.sys_rec_id
				join group_status_sec sta on grp.group_id=sta.group_id
				join rel_gppl_sec reg on reg.group_id=grp.group_id
				join [plan_sec] pln on pln.plan_id=reg.plan_id
				where contact.subsys_code='GP' and contact.lname=@lname and contact.addr_type='L'
				--and addr.zip=@zip
				 and sta.group_status='A4' and addr.subsys_code='GP' and contact.email=@email)
				 begin
            select @email=email, @lname=last_name, @zip=group_zip,@roleid =role_id from group_user_details where  user_id=@userid
				select grp.group_id as Group_Id,(RTRIM (grp.group_name) + ' (' + RTRIM (pln.plan_name) + ')')  as Group_Name, grp.group_type as Group_Type, pln.plan_id as Plan_Id,pln.plan_name as Plan_Name,@roleid as Role_ID,reg.elig_opt as MidmonthEligibility,
				LTRIM(RTRIM(addr.zip)) Zip from contact_sec as contact
				join [address_sec] addr on addr.sys_rec_id=contact.sys_rec_id
				join [group_sec] grp on grp.group_id=addr.sys_rec_id
				join group_status_sec sta on grp.group_id=sta.group_id
				join rel_gppl_sec reg on reg.group_id=grp.group_id
				join [plan_sec] pln on pln.plan_id=reg.plan_id
				where contact.subsys_code='GP' and contact.lname=@lname and contact.addr_type='L'
				--and addr.zip=@zip
				 and sta.group_status='A4' and addr.subsys_code='GP' and contact.email=@email			

			end
			else
			begin
			 set @status ='DDS User with no previous groupid';
 
		  DECLARE @Err as table
		(
		 Error_Msg varchar(max)
		)					

		INSERT INTO @Err(Error_Msg)VALUES(@status)
		SELECT *,(select role_id from group_user_details where  user_id=@userid) Role_ID FROM @Err
		select Error_Msg,(select role_id from group_user_details where  user_id=@userid) Role_ID FROM @Err
	    end
        End
    else
   begin 
      If exists( select * from @roledetails where roleid in(1,2) )
     Begin
        If exists(select group_id,plan_id  from group_user_details where user_id =@userid and group_id IS NOT NULL and group_id <> 0)
		  begin
         set @groupid=(select group_id  from group_user_details where user_id =@userid );
		 set @plan_id=(select plan_id  from group_user_details where user_id =@userid );
	     set @roleid = (select role_id from group_user_details where  user_id=@userid);
         if exists(select 1 from [group_sec]  as grp with(nolock)
		join rel_gppl_sec reg with(nolock) on reg.group_id=grp.group_id
		join [plan_sec] pln with(nolock) on pln.plan_id=reg.plan_id
		where (grp.group_id =@groupid  and pln.plan_id =@plan_id ) )
		begin		 
		 select distinct grp.group_id as Group_Id,RTRIM(grp.group_name) as Group_Name ,grp.group_type as Group_Type,
		 pln.plan_id as Plan_Id, @roleid as Role_ID,reg.elig_opt as MidmonthEligibility,LTRIM(RTRIM(tbl_address.zip)) Zip from [group_sec]  as grp with(nolock)
		join rel_gppl_sec reg with(nolock) on reg.group_id=grp.group_id
		join [plan_sec] pln with(nolock) on pln.plan_id=reg.plan_id
		Left outer JOIN [address_sec] tbl_address  ON grp.group_id = tbl_address.sys_rec_id and  tbl_address.subsys_code = 'GP' and  tbl_address.addr_type ='L' 
		where (grp.group_id =@groupid  and pln.plan_id =@plan_id ) 
		end
		else
		begin
		select null Error_Msg,(select role_id from group_user_details where  user_id=@userid) Role_ID
		end		
		End
 else
		 Begin
 
		 set @status ='DDS User with no previous groupid';
 
		  DECLARE @Err_msg as table
		(
		 Error_Msg varchar(max)
		)		
				

		INSERT INTO @Err_msg(Error_Msg)VALUES(@status)
		SELECT *,(select role_id from group_user_details where  user_id=@userid) Role_ID FROM @Err_msg
		select Error_Msg,(select role_id from group_user_details where  user_id=@userid) Role_ID FROM @Err_msg
		 End
End
 SET NOCOUNT OFF
End
End