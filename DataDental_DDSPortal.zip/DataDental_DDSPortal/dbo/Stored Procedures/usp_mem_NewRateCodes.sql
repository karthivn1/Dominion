﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <02-02-2017>
-- Description:	<This SP is used to return List of RateCodes >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_NewRateCodes]  (
@groupId INT=NULL,
@planId INT=NULL
)
AS
BEGIN
SET NOCOUNT ON;
 
 BEGIN TRAN 
	BEGIN TRY
 SELECT   
        group_cap_rate.rate_code AS Rate,
		
		group_cap_rate.rate_code+'-'+ pl_rat.rate_short_desc AS NewRC  
			
		FROM  group_cap_rate    
		INNER JOIN pl_rat ON group_cap_rate.rate_code = pl_rat.rate_code
		INNER JOIN rel_gppl ON rel_gppl.rel_gppl_id = group_cap_rate.rel_gppl_id
		INNER JOIN [plan] pl ON rel_gppl.plan_id = pl.plan_id
		INNER JOIN ins_opt ON ins_opt.ins_opt = pl.ins_opt
		WHERE rel_gppl.group_id = @groupId AND rel_gppl.plan_id = @planId AND 
		(( group_cap_rate.eff_date <= GETDATE()  AND ( group_cap_rate.exp_date is null  or   
		( group_cap_rate.exp_date > group_cap_rate.eff_date)) ) or ( group_cap_rate.eff_date >= GETDATE() and     
		( group_cap_rate.exp_date is null or (  group_cap_rate.exp_date > group_cap_rate.eff_date))) ) 
		and group_cap_rate.exp_date is null
		 


		 COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH

	
	SET NOCOUNT OFF
END