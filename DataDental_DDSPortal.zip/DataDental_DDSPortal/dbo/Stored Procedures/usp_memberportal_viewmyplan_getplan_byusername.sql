﻿CREATE procedure [dbo].[usp_memberportal_viewmyplan_getplan_byusername] 
(@username varchar(max))
AS
Begin
SET NOCOUNT ON 
Declare @userid int;
Declare @zip varchar(max);
Declare @email varchar(max);
Declare @lname varchar(max);
Declare @memberid int;
Declare @plan_id int;
Declare @status varchar(max);
Declare @roleid varchar(max);

Declare @roledetails Table
(roleid int);
set @userid= (select user_id from member_user_details where user_name=@username);

insert into @roledetails (roleid) 
select role_id  from member_user_details where  user_id=@userid;
  If exists( select * from @roledetails where roleid=4 or roleid=5 )
          Begin
		 --   select user_id as User_Id,reg.group_id as Group_Id ,reg.group_name as Group_Name,grpParent.group_name as Parent_Name,pln.plan_id as Plan_Id,pln.plan_name as Plan_Name, role_id as Role_ID,convert(varchar(MAX),mbr.member_id) as MemberID from member_user_details as mbr
			--join rlmbgrpl_sec grppln on mbr.member_id = grppln.member_id
			--join [group_sec] reg on reg.group_id=grppln.group_id
			--join [plan_sec] pln on pln.plan_id=grppln.plan_id
			--join [group_sec] grpParent on reg.group_parent = grpParent.group_id
			--where 
			--(grppln.exp_gr_pl is null or grppln.exp_gr_pl > GETDATE()) and 
			--mbr.user_name=@username 
			select user_id as User_Id,reg.group_id as Group_Id ,reg.group_name as Group_Name,grpParent.group_name as Parent_Name,pln.plan_id as Plan_Id,pln.plan_name as Plan_Name, role_id as Role_ID,
			convert(varchar(MAX),mbr.member_id) as MemberID from rlmbgrpl_sec as grppln
			join member_sec mbr on mbr.member_id = grppln.member_id
			join [group_sec] reg on reg.group_id=grppln.group_id
			join [plan_sec] pln on pln.plan_id=grppln.plan_id
			join [group_sec] grpParent on reg.group_parent = grpParent.group_id
			join member_user_details mud on mud.member_id = grppln.member_id
			where 
			(grppln.exp_gr_pl is null or grppln.exp_gr_pl > GETDATE()) and 
			mud.user_name=@username 

        End
    else
   begin 
      If exists( select * from @roledetails where roleid in(2,3) )
     Begin
        If exists(select member_id  from member_user_details where user_id =@userid and member_id IS NOT NULL and member_id <> 0)
		  begin
  
		 set @memberid=(select member_id  from member_user_details where user_id =@userid );
		 --set @plan_id=(select plan_id  from member_user_details where user_id =@userid );
	     set @roleid = (select role_id from member_user_details where  user_id=@userid);
		 select top 1  grp.group_id as Group_Id,grp.group_name as Group_Name,grp.group_type as Group_Type,pln.plan_id as Plan_Id,pln.plan_name as Plan_Name,@roleid as Role_ID,convert(varchar(MAX),mbr.member_id) as MemberID from [group_sec]  as grp
	  	join rlmbgrpl_sec reg on reg.group_id=grp.group_id
		join member_sec mbr on mbr.member_id =reg.member_id
		join [plan_sec] pln on pln.plan_id=reg.plan_id
		join [group_sec] grpParent on grp.group_parent = grpParent.group_id
		where mbr.member_id = @memberid

		End
 else
		 Begin
 
		 set @status ='DDS User with no previous groupid';
 
		  DECLARE @Err as table
		(
		 Error_Msg varchar(max)
		)

		INSERT INTO @Err(Error_Msg)VALUES(@status)
		SELECT * FROM @Err
		 End
End

 SET NOCOUNT OFF
End
End