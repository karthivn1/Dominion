﻿CREATE PROCEDURE [dbo].[usp_login_updateinvalidattempt]
(
@userId INT
)
AS
BEGIN
SET NOCOUNT ON;
Declare @loginatempt INT;
update group_user_details set failed_login_attempt = ISNULL(failed_login_attempt,0)+1  where user_id= @userId 
set @loginatempt=(select failed_login_attempt from group_user_details where user_id= @userId )
If(@loginatempt >= 3)
Begin
update group_user_details set status_id  = 3  where user_id= @userId  
End
select status_id as Status,failed_login_attempt as LoginAttempt from group_user_details  where user_id= @userId 

SET NOCOUNT OFF
END