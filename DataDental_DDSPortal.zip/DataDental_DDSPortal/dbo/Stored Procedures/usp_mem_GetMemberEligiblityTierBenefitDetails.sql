﻿

-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <21-02-2017>
-- Description:	<This sp gets the Member Eligiblity Tier benefit by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberEligiblityTierBenefitDetails] 
(
@memberId INT,
@asOfDate DATETIME
)
AS
BEGIN
SET NOCOUNT ON;
	  
	  SELECT member.member_id,   
			 rlplfc.rlplfc_id,   
			 member.family_id,   
			 rlmbgrpl.plan_id AS PlanID,   
			 rlplfc.facility_id AS FacilityID,
			 facility.fc_name AS FacilityName,    
			 LTRIM(RTRIM(member.last_name)) +' '+ LTRIM(RTRIM(member.first_name)) +' '+ (SELECT CASE WHEN member.middle_init  IS NULL THEN '' ELSE member.middle_init END) +'.' AS Name,   
			 (SELECT  mbr_code_desc FROM mbr_code WHERE mbr_code=member.member_code) AS Relation,   
			 rlplfc.eff_date  AS EffDate,
			 (SELECT CASE WHEN rlmbgrpl.exp_gr_pl IS NOT NULL THEN 
				(CASE WHEN rlplfc.exp_date IS NOT NULL THEN (CASE WHEN rlplfc.exp_date>rlmbgrpl.exp_gr_pl THEN rlmbgrpl.exp_gr_pl ELSE rlplfc.exp_date END) 
				  ELSE (CASE WHEN rlplfc.eff_date>rlmbgrpl.eff_gr_pl THEN rlplfc.eff_date ELSE rlmbgrpl.eff_gr_pl END) END ) 
			  ELSE rlplfc.exp_date END) AS ExpDate, 
			 rlplfc.exp_date  ,   
			 member.date_of_birth,			   
			 facility.fc_type,   
			 member.member_ssn,   
			 member.student_flag,   
			 member.disable_flag,   
			 rlmbgrpl.eff_gr_pl,   
			 rlmbgrpl.exp_gr_pl,   
			 rlmbgrpl.action_code,   
			 rlplfc.action_code,   
			 [plan].plan_dsp_name AS PlanName,   
			 [plan].ins_type,   
			 [plan].ins_opt,   
			 tiered_benefit_mbr.tiered_bene_mbr_id,   
			 tiered_benefit_mbr.rlplfc_id,   
			 tiered_benefit_mbr.carry_over AS CarryOver,   
			 tiered_benefit_mbr.adjustment AS Adjustment,   
			 tiered_benefit_mbr.h_user AS HUser,   
			 tiered_benefit_mbr.h_datetime AS HDateTime,
			 (SELECT CASE WHEN ((DATEDIFF(d,rlplfc.eff_date,@asOfDate))/30+tiered_benefit_mbr.adjustment+tiered_benefit_mbr.carry_over)>0 THEN ((DATEDIFF(d,rlplfc.eff_date,@asOfDate))/30+tiered_benefit_mbr.adjustment+tiered_benefit_mbr.carry_over) ELSE 0 END) AS TotalCoverageMonths
	 FROM rlplfc 
	      LEFT OUTER JOIN facility ON rlplfc.facility_id = facility.fc_id
		  LEFT JOIN member ON  member.member_id = rlplfc.member_id   
          LEFT JOIN rlmbgrpl ON rlmbgrpl.mb_gr_pl_id = rlplfc.mb_gr_pl_id
          LEFT JOIN [plan] ON [plan].plan_id = rlmbgrpl.plan_id
          LEFT JOIN tiered_benefit_mbr ON tiered_benefit_mbr.rlplfc_id = rlplfc.rlplfc_id
     WHERE member.family_id = @memberId AND  (( (rlmbgrpl.eff_gr_pl <= @asOfDate AND (rlmbgrpl.exp_gr_pl > @asOfDate OR rlmbgrpl.exp_gr_pl is null)) AND  
         ((rlplfc.eff_date <= @asOfDate AND (rlplfc.exp_date > @asOfDate OR rlplfc.exp_date is null)) OR 
		 (rlplfc.eff_date > @asOfDate AND (rlplfc.exp_date > rlplfc.eff_date OR rlplfc.exp_date is null) ) )) OR  
         ( (rlmbgrpl.eff_gr_pl > @asOfDate AND (rlmbgrpl.exp_gr_pl > rlmbgrpl.eff_gr_pl OR rlmbgrpl.exp_gr_pl is null) ) AND (rlplfc.eff_date > @asOfDate AND  
         (rlplfc.exp_date > rlplfc.eff_date OR rlplfc.exp_date is null)) )) AND (rlmbgrpl.cobra_flag is null OR (rlmbgrpl.cobra_flag is not null AND rlmbgrpl.cobra_flag <> 'P'))
    ORDER BY rlmbgrpl.plan_id ASC,member.member_code ASC   

SET NOCOUNT OFF
END