﻿
-- ===================================================================
-- Author:		<Manikandan Palanisamy>
-- Create date: <06/16/2017>
-- Description:	<Get the facility details for the matching criteria>
-- =================================================================== exec [usp_ProviderPortal_FacilitySearch] 227673
CREATE PROCEDURE [dbo].[usp_ProviderPortal_FacilitySearch] 
	(
	@facilityId INT = NULL,
	@practiceName CHAR(50) = NULL,
	@phoneNumber CHAR(14) = NULL,
	@taxId CHAR(9) = NULL,
	@portalRoleId INT = NULL,
	@email VARCHAR(250) = NULL
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	DECLARE @SqlQuery NVARCHAR(MAX)
	
	  
SELECT DISTINCT LTRIM(RTRIM(fc.fc_id)) AS FacilityId,
	(CASE fc.fc_tax_id WHEN '' THEN NULL ELSE fc.fc_tax_id END)
	 AS TaxId,
	LTRIM(RTRIM(fc.np_id)) AS BillNPI,
	LTRIM(RTRIM(fc.fc_name)) AS PracticeName,
	LTRIM(RTRIM(ad.zip)) AS Zip,
	LTRIM(RTRIM(ad.address_id)) AS AddressId,
	LTRIM(RTRIM(ct.phone1)) AS PhoneNumber,
	LTRIM(RTRIM(ct.email)) AS Mail,
	LTRIM(RTRIM(ct.contact_id)) AS ContactId,
	(CASE pud.role_id WHEN 6 THEN 'DDS'
	 WHEN 7 THEN 'CBC' END) AS Portal 
	FROM [dbo].facility_sec fc
	LEFT OUTER JOIN [dbo].address_sec ad ON fc.fc_id = ad.sys_rec_id AND ad.subsys_code = 'FC'
	LEFT OUTER JOIN [dbo].contact_sec ct ON fc.fc_id = ct.sys_rec_id AND ct.subsys_code = 'FC'
	LEFT OUTER JOIN [dbo].provider_user_details pud ON fc.fc_id = pud.facility_id --AND pud.role_id = ISNULL(@portalRoleId,pud.role_id)
	WHERE fc.fc_id = ISNULL(@facilityId,fc.fc_id)
	AND( (@practiceName IS NOT NULL AND fc.fc_name like '%'+LTRIM(RTRIM(@practiceName)) + '%')
	OR (@practiceName IS NULL AND fc.fc_name = fc.fc_name))
	AND fc.fc_tax_id = ISNULL(@taxId,fc.fc_tax_id)
	AND ct.email = ISNULL(@email,ct.email)
	AND ct.phone1 = ISNULL(REPLACE(@phoneNumber,'-',''),ct.phone1) 
	AND ((@portalRoleId IS NOT NULL AND  pud.role_id = @portalRoleId)OR(@portalRoleId IS  NULL AND pud.role_id = pud.role_id )OR(@portalRoleId IS  NULL AND pud.role_id IS NULL ))
	--AND pud.role_id = ISNULL(@portalRoleId,pud.role_id)
END