﻿CREATE PROCEDURE [dbo].[usp_com_GetAppKeyValues]  
AS 
BEGIN 
SET NOCOUNT ON 

	SELECT
		 appkey_id as AppKeyId ,appkey_name as AppKeyName,appkey_value as AppKeyValue
		 from 
		app_keysettings
	

SET NOCOUNT OFF 
END