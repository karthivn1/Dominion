﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <21-10-2016>
-- Description:	<This sp gets the Group Details by passing groupId and related Plans>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetGroupDetailsWithPlans]
(
@groupId INT
)
AS
BEGIN
SET NOCOUNT ON;

	SELECT [group].group_id AS GroupID,
		   [group].group_name AS GroupName, 
		   LTRIM(RTRIM((typeGr.descr))) AS GroupType,
		   [group].group_oed AS GroupOED,
		   [group].paid_to_date AS PaidtoDate,
		   [group].oc_id AS OperatingCoId,
		   oper_company.name AS OperatingCoName,
		   LTRIM(RTRIM((typBill.descr))) AS Billingtype,
		   LTRIM(RTRIM((typBillFreq.descr))) AS Billingfrequency,
		   [group].enrol_territory AS Enrollingterritory,
		   [group].close_territory AS Closingterritory,	  
		   LTRIM(RTRIM((typAllo.descr))) AS Alloctype,
		   [group].pymt_toler AS "Percent",
		   CONVERT(nvarchar,[group].group_payee) +' '+ groupPayee.group_name  AS PayeeGrp,		   
		   LTRIM(RTRIM((typPaGr.descr))) AS Payeetype

		from [group]

		INNER JOIN oper_company ON oper_company.oc_id=[group].oc_id
		LEFT JOIN [group] groupPayee ON groupPayee.group_id=[group].group_payee
		LEFT JOIN typ_table typeGr ON typeGr.subsys_code='GP' AND typeGr.tab_name='group_type' AND typeGr.code=[group].group_type
		LEFT JOIN typ_table typBill ON typBill.subsys_code='GP' AND typBill.tab_name ='bill_type' AND typBill.code=[group].bill_type
		LEFT JOIN typ_table typBillFreq ON typBillFreq.subsys_code='GP' AND typBillFreq.tab_name ='pay_freq' AND typBillFreq.code=[group].bill_freq
		LEFT JOIN typ_table typAllo ON typAllo.subsys_code='GP' AND typAllo.tab_name='alloc_type' AND typAllo.code=[group].alloc_type
		LEFT JOIN typ_table typPaGr ON typPaGr.subsys_code='GP' AND typPaGr.tab_name='group_type' AND typPaGr.code=groupPayee.group_type
		where [group].group_id=@groupId
	


	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.plan_dsp_name AS PlanName
		,ins_type AS PlanType
		,insOpt.ins_opt_sd AS "Option"
		,rlGroupPlan.eff_date AS EffDate
		,rlGroupPlan.exp_date AS ExpDate

	from [plan] tblPlan
	LEFT JOIN rel_gppl rlGroupPlan ON rlGroupPlan.plan_id=tblPlan.plan_id
	INNER JOIN ins_opt insOpt ON insOpt.ins_opt=tblPlan.ins_opt
	WHERE rlGroupPlan.group_id=@groupId

SET NOCOUNT OFF;
END