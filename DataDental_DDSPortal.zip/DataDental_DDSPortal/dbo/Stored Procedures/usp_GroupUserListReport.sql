﻿CREATE PROCEDURE [dbo].[usp_GroupUserListReport]
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @GroupUserList TABLE
(
id INT IDENTITY(1,1),
LastName VARCHAR(MAX),
FirstName VARCHAR(max),
Email VARCHAR(max),
Type VARCHAR(max),
Status VARCHAR(max)
) 

INSERT INTO @GroupUserList(LastName ,FirstName ,Email ,Type ,Status)

SELECT --DISTINCT gud.user_id,
	gud.last_name,gud.first_name,gud.email,rol.role_name,
												--Case rol.role_name 
												--when 'DDS User' then 'DDS'
												--when 'DDS Admin' then 'DDS Admin'
												--when 'GroupBenefitAdmin' then 'Group'end,
												usm.status 
												FROM group_user_details gud 
JOIN role_master rol on rol.role_id =gud.role_id
JOIN user_status_master usm ON gud.status_id=usm.status_id AND usm.portal_type='grp'
where usm.status <> 'Locked' 
AND rol.portal_type in ('common','grp') 


SELECT * FROM @GroupUserList

SET NOCOUNT OFF 
END