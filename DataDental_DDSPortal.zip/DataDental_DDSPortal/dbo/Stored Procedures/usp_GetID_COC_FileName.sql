﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--DECLARE @fileName NVARCHAR(100)=NULL
--exec usp_GetID_COC_FileName 24175,273,@fileName out
--SELECT @fileName
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetID_COC_FileName]
	-- Add the parameters for the stored procedure here
@GroupId INT,
@PlanId INT,
@MemberId INT=0,
@FileName nvarchar(100) OUT	
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

  IF OBJECT_ID('tempdb..#tmpParentGroup') IS NOT NULL
    DROP TABLE #tmpParentGroup

 IF OBJECT_ID('tempdb..#tmpGroup') IS NOT NULL
    DROP TABLE #tmpGroup

  IF OBJECT_ID('tempdb..#tmpPlan') IS NOT NULL
	DROP TABLE #tmpPlan

DECLARE @EnrolTerr nvarchar(2)=NULL;
DECLARE @CloseTerr INT=0


SET @FileName=''


SELECT *
	INTO #tmpGroup
	FROM group_sec g
	WHERE g.group_id=@GroupId

SELECT DISTINCT Parent.*
    INTO #tmpParentGroup
	FROM group_sec g
	JOIN group_sec Parent ON Parent.group_id=g.group_parent
	WHERE g.group_id=@GroupId

SELECT @CloseTerr=t.close_territory
	FROM #tmpParentGroup t

EXEC usp_GetPrefixPlanFileName @GroupId,@PlanId,@MemberId,@EnrolTerr OUT


SELECT *
	INTO #tmpPlan
	FROM plan_sec p
	WHERE p.plan_id=@PlanId

--Dental Only

IF EXISTS(SELECT t.group_id
	FROM #tmpGroup t
	WHERE t.group_parent=63982)
BEGIN
 SET @FileName='';	
 RETURN 
END
-----HCR - Dental Only
--IF @CloseTerr>0
--BEGIN
--SET @FileName=LOWER(CAST(@CloseTerr AS nvarchar)+'_COC'+'.pdf')
--RETURN 
--END
---Guardian
--IF EXISTS(SELECT t.group_id
--	FROM #tmpGroup t
--	WHERE t.group_parent=60467)
--BEGIN
--SET @FileName='GU'+@EnrolTerr+'-GRSP.pdf'
--RETURN 
--END

--Teethkeepers

IF EXISTS(SELECT t.group_id
	FROM #tmpParentGroup t WHERE CHARINDEX('TEETHKEEPERS',UPPER(t.group_name))>0)
BEGIN

	IF @EnrolTerr IN ('VA','MD','DE','DC','PA')
	BEGIN
	--Teethkeepers HMO
		IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE t.ins_opt='HMO' AND CHARINDEX('000X',UPPER(t.plan_dsp_name))=0)
	   BEGIN
		  SET @FileName=@EnrolTerr+'_SGSP.pdf'
		  RETURN 
	   END

	   --Teethkeepers PPO
	   IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE t.ins_opt='FFS') 
	   BEGIN
			IF EXISTS(SELECT t.group_id
			FROM #tmpGroup t WHERE t.oc_id=10) 
			BEGIN
			  SET @FileName=@EnrolTerr+'_SGAP.pdf'
			  RETURN 
		    END 
	   END

	END

END
--none for ASO clients
IF EXISTS(SELECT t.group_id
			FROM #tmpGroup t WHERE t.oc_id in (3,4,5,6,7))
			BEGIN
			SET @FileName=''
			RETURN
			END 
--federal dental - DHMO
IF EXISTS(SELECT t.group_id
			FROM #tmpGroup t WHERE t.group_parent in (20747,20748,20843,20842,26939,26940,26941,26942,26943,26944,26945,26946))
BEGIN
  IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE t.ins_opt='HMO') 
	BEGIN
		SET @FileName='DE_GRSP.pdf'
		RETURN 
	END
END

---federal dental - DHMO
IF EXISTS(SELECT t.group_id
	FROM #tmpParentGroup t WHERE CHARINDEX('FEDERAL DENTAL',UPPER(t.group_name))>0)
BEGIN
 IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE t.ins_opt='HMO') 
	BEGIN
		SET @FileName='DE_GRSP.pdf'
		RETURN 
	END
END
--Teethkeepers and edental - anyone with 000X Discount program
IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE CHARINDEX('000X',UPPER(t.plan_dsp_name))>0)
BEGIN
	SET @FileName='Teethkeepers COC.pdf'
	RETURN 
END

---catch other SG non-teethkeepers, not eDental
IF EXISTS(SELECT t.group_id
	FROM #tmpParentGroup t WHERE CHARINDEX('EDENTAL',UPPER(t.group_name))=0)
BEGIN
	IF EXISTS(SELECT t.group_id
			FROM #tmpGroup t WHERE t.group_type='SG')
			BEGIN
				IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='HMO' 
				AND CHARINDEX('000X',UPPER(t.plan_dsp_name))=0
				AND @EnrolTerr IN ('VA','MD','DE','DC','PA')) 
				BEGIN
					SET @FileName=@EnrolTerr+'_SGSP.pdf'
					RETURN 
				END

				IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='FFS' 
				AND @EnrolTerr IN ('VA','MD','DE','DC','PA')) 
				BEGIN
					IF EXISTS(SELECT t.group_id
					FROM #tmpGroup t WHERE t.oc_id=10) 
					BEGIN
					  SET @FileName=@EnrolTerr+'_SGAP.pdf'
					  RETURN 
					END 
				END

			END
END

IF EXISTS(SELECT t.group_id
FROM #tmpGroup t WHERE t.oc_id=10) 
BEGIN
	IF EXISTS(SELECT t.plan_id
		FROM #tmpPlan t WHERE t.ins_opt='FFS') 
		BEGIN
			SET @FileName=@EnrolTerr+'_GRAP.pdf'
			RETURN 
		END

END

IF EXISTS(SELECT t.plan_id
FROM #tmpPlan t WHERE t.ins_opt='HMO') 
BEGIN
	SET @FileName=@EnrolTerr+'_GRSP.pdf'
	RETURN 
END

--dental and vision combined
IF EXISTS(SELECT t.group_id
	FROM #tmpParentGroup t WHERE CHARINDEX('TEETHKEEPERS',UPPER(t.group_name))>0)
BEGIN
 IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='HMO' 
				AND CHARINDEX('000X',UPPER(t.plan_dsp_name))=0
				AND @EnrolTerr='PA') 
				BEGIN
					SET @FileName='PA_ISDV.pdf'
					RETURN 
				END
	IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='FFS' 
				AND @EnrolTerr ='PA') 
				BEGIN
					IF EXISTS(SELECT t.group_id
					FROM #tmpGroup t WHERE t.oc_id=10) 
					BEGIN
					  SET @FileName='PA_IPDV.pdf'
					  RETURN 
					END 
				END

--////other states HMO and FFS 
--//modified to include DC 01/20/11
IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='HMO' 
				AND CHARINDEX('000X',UPPER(t.plan_dsp_name))=0
				AND @EnrolTerr IN ('VA','MD','DE','DC')) 
				BEGIN
					SET @FileName=@EnrolTerr+'_ISDV.pdf'
					RETURN 
				END

IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='FFS' 
				AND @EnrolTerr IN ('VA','MD','DE','DC')) 
				BEGIN
					IF EXISTS(SELECT t.group_id
					FROM #tmpGroup t WHERE t.oc_id=10) 
					BEGIN
					  SET @FileName=@EnrolTerr+'_IPDV.pdf'
					  RETURN 
					END 
				END

END
--none for ASO clients
IF EXISTS(SELECT t.group_id
			FROM #tmpGroup t WHERE t.oc_id in (3,4,5,6,7))
			BEGIN
			SET @FileName=''
			RETURN 
			END
--federal dental - DHMO
IF EXISTS(SELECT t.group_id
			FROM #tmpGroup t WHERE t.group_parent in (20747,20748,20843,20842,26939,26940,26941,26942,26943,26944,26945,26946))
---{@DisplayCardCategory}="COMBO" and
BEGIN
IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='HMO') 
				BEGIN
					SET @FileName='DE_GSDV.pdf'
					RETURN  
				END
END			

IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE CHARINDEX('000X',UPPER(t.plan_dsp_name))>0) 
				BEGIN
					SET @FileName=@EnrolTerr+'_SGDV.pdf'
					RETURN 
				END


IF EXISTS(SELECT t.group_id
FROM #tmpGroup t WHERE t.oc_id=10) 
BEGIN
	IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='FFS') 
				BEGIN
					IF @EnrolTerr='PA'
					BEGIN 
						SET @FileName='PA_GPDV.pdf'
						RETURN 
					END
					IF @EnrolTerr='VA'
					BEGIN 
						SET @FileName='VA_GPDV.pdf'
						RETURN 
					END
					IF @EnrolTerr='DE'
					BEGIN 
						SET @FileName='DE_GPDV.pdf'
						RETURN 
					END
					IF @EnrolTerr='DC'
					BEGIN 
						SET @FileName='DC_GPDV.pdf'
						RETURN 
					END
					IF @EnrolTerr='MD'
					BEGIN 
						SET @FileName='MD_GPDV.pdf'
						RETURN 
					END
				END

END

IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='HMO') 
				BEGIN
				   
				   SELECT @FileName=CASE @EnrolTerr 
				   WHEN 'PA' THEN 'PA_GSDV.pdf'
				   WHEN 'VA' THEN 'VA_GSDV.pdf'
				   WHEN 'DE' THEN 'DE_GSDV.pdf'
				   WHEN 'DC' THEN 'DC_GSDV.pdf'
				   WHEN 'MD' THEN 'MD_GSDV.pdf'
				   ELSE ''
				   END

				   IF LEN(@FileName)>0
					RETURN 
				END

---vision ONLY
IF EXISTS(SELECT t.group_id
FROM #tmpGroup t WHERE t.group_type='EG') 
BEGIN
IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='FFS') 
				BEGIN
					SET @FileName=@EnrolTerr+'_GRV.pdf'
					RETURN 
				END

END

IF EXISTS(SELECT t.group_id
FROM #tmpGroup t WHERE t.group_type='SG') 
BEGIN
IF EXISTS(SELECT t.plan_id
				FROM #tmpPlan t WHERE t.ins_opt='FFS') 
				BEGIN
					SET @FileName=@EnrolTerr+'_SGV.pdf'
					RETURN 
				END

END

---HCR - Dental Only
IF @CloseTerr>0
BEGIN
SET @FileName=LOWER(CAST(@CloseTerr AS nvarchar)+'_COC'+'.pdf')
RETURN 
END

---Guardian
IF EXISTS(SELECT t.group_id
	FROM #tmpGroup t
	WHERE t.group_parent=60467)
BEGIN
SET @FileName='GU'+@EnrolTerr+'-GRSP.pdf'
RETURN 
END


RETURN 

END