﻿CREATE PROCEDURE [dbo].[usp_memberportal_ChangePassword]
(
@UserID INT,
@UserName VARCHAR(MAX),
@Password VARCHAR(MAX),
@NewPassword VARCHAR(MAX),
@HashValue VARCHAR(MAX)
)
AS
BEGIN
SET NOCOUNT ON;

 update member_user_details set password=@NewPassword,status_id=1, password_reset_date= getdate(),forgot_password_time =getdate()   WHERE user_name =@UserName 
 SET @UserID=(SELECT user_id from member_user_details where user_name =@UserName)
  
 SELECT user_id UserID,user_name UserName,temp_password Password from member_user_details WHERE user_id=@UserID

SET NOCOUNT OFF;
END