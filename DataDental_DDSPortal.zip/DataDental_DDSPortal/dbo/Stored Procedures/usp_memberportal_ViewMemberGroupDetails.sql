﻿CREATE procedure [dbo].[usp_memberportal_ViewMemberGroupDetails]
(
@username varchar(max)
)
AS
Begin
SET NOCOUNT ON 

select user_id as User_Id,reg.group_id as Group_Id ,reg.group_name as Group_Name,pln.plan_id as Plan_Id,pln.plan_name as Plan_Name, role_id as Role_ID from member_user_details as mbr
join rlmbgrpl_sec grppln on mbr.member_id = grppln.member_id
join [group_sec] reg on reg.group_id=grppln.group_id
join [plan_sec] pln on pln.plan_id=grppln.plan_id
 where user_name=@username   


 SET NOCOUNT OFF
End