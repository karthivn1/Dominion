﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_ProviderTechSupport 2
-- =============================================
CREATE PROCEDURE [dbo].[usp_ProviderTechSupport]
@ref_id INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	Select 
	DISTINCT s.[user_id] AS UserId,p.[user_name] AS UserName,p.email AS Email,s.query AS Query
		From provider_technical_support s
		JOIN provider_user_details p on p.[user_id]=s.[user_id]
		WHERE s.support_id=@ref_id
END