﻿ -- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <02-11-2016>
-- Description:	<This SP is used to update the terminated Dependent >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_TerminatedDependent_Details]
(
@mbrGrpPlnId INT=NULL,
@rateCode VARCHAR(30)=NULL,
@effRateDate Datetime=NULL, 
@dpntFacExpDate Datetime=NULL,
@actionCode VARCHAR(10)=NULL,
@dpntFaciId INT=NULL,
@memberId INT=NULL,
@subsystemCode		VARCHAR(2)=NULL,
@reasonCode       VARCHAR(2)=NULL, 
@activityMasterId INT=NULL, 
@userCode        VARCHAR(8)=NULL
 --@planFacilitydetails dbo.PlanFacilityDetails READONLY
)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRAN 
	BEGIN TRY

DECLARE @HMSI INT


UPDATE rlmbrt set exp_rt_date=@dpntFacExpDate where mb_gr_pl_id=@mbrGrpPlnId


SELECT @HMSI=msi+1 from sysdatetime


INSERT INTO rlmbrt ( mb_gr_pl_id, rate_code, eff_rt_date, action_code, h_datetime, h_msi, h_action, h_user ) VALUES 
( @mbrGrpPlnId, 'S', @effRateDate, @actionCode, getdate(), @HMSI, @actionCode, @userCode )

UPDATE sysdatetime set msi=msi+1

UPDATE rlplfc SET action_code=@actionCode,exp_date= @dpntFacExpDate  WHERE rlplfc_id=@dpntFaciId

IF( @activityMasterId != 0 ) 
	BEGIN 
		EXEC usp_SaveActivity @subsystemCode,@memberId,@reasonCode,@activityMasterId,@userCode
	END
	
	COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
	SET NOCOUNT OFF
END