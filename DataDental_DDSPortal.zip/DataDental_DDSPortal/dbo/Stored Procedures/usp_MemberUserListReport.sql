﻿CREATE PROCEDURE [dbo].[usp_MemberUserListReport]
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @MemberUserList TABLE
(
id INT IDENTITY(1,1),
LastName VARCHAR(MAX),
FirstName VARCHAR(max),
Email VARCHAR(max),
Type VARCHAR(max),
Status VARCHAR(max)
)

INSERT INTO @MemberUserList(LastName ,FirstName ,Email ,Type ,Status)

select RTRIM(ISNULL(mud.last_name,'')),RTRIM(ISNULL(mud.first_name,'')),mud.email,rm.role_name,usm.status from member_user_details mud 
JOIN user_status_master usm ON mud.status_id=usm.status_id
JOIN role_master rm ON rm.role_id=mud.role_id WHERE mud.status_id <> 3

UPDATE @MemberUserList SET Type='Member Pend' where Status='Pending'

SELECT * FROM @MemberUserList

SET NOCOUNT OFF 
END