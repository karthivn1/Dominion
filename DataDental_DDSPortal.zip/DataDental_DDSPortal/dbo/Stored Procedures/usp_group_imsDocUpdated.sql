﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_group_imsDocUpdated]
	-- Add the parameters for the stored procedure here
@group_id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
IF EXISTS (Select g.Id
		From group_ims_history g
		Where g.group_id=@group_id
		AND Convert(date,g.updated_on)=convert(date,getdate()))
		BEGIN
			RETURN 1
		END

RETURN 0

END