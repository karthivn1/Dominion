﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetDocTypesWithKeys_Ims] 
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
SELECT Id,
	doc_no AS DocNumber,
	doc_type AS DocName
	FROM lkp_doctype

SELECT Id,
	doc_type_Id AS DocId,
	key_no AS KeyNumber,
	[key_name] AS KeyName
	FROM lkp_dockeys

END