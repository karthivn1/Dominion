﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_GetClaimDetails]
(
@claimid int
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @ClaimBasicDetails TABLE
(
id INT IDENTITY(1,1),
Claim VARCHAR(MAX),
FullName VARCHAR(MAX),
DOB VARCHAR(MAX),
Type VARCHAR(MAX),
Status VARCHAR(MAX),
Dentist VARCHAR(MAX),
ServiceDate VARCHAR(MAX),
PaidDate VARCHAR(MAX),
CheckValue VARCHAR(MAX),
EOPID VARCHAR(MAX)
)

DECLARE @ClaimInformation TABLE
(
id INT IDENTITY(1,1),
ServiceDate VARCHAR(MAX),
Status VARCHAR(MAX),
ADACode VARCHAR(MAX),
Tooth VARCHAR(MAX),
Surface VARCHAR(MAX),
Charge VARCHAR(MAX),
Allowed VARCHAR(MAX),
Deductible VARCHAR(MAX),
PatientResp VARCHAR(MAX),
PlanPays VARCHAR(MAX),
Coverage VARCHAR(MAX),
Remarks VARCHAR(MAX)
)

DECLARE @ClaimTotalDetails TABLE
(
id INT IDENTITY(1,1),
Charge VARCHAR(MAX),
Allowed VARCHAR(MAX),
Deductible VARCHAR(MAX),
PatientResp VARCHAR(MAX),
PlanPays VARCHAR(MAX),
PatientRemainingMaximum VARCHAR(MAX)
)

INSERT INTO @ClaimBasicDetails(Claim,FullName,DOB,Type,Status,Dentist,ServiceDate,PaidDate,CheckValue,EOPID)

select distinct clm.claim_no, mbr.first_name + mbr.last_name as name ,mbr.date_of_birth,clm.[type],clm.claim_status,fc_name as Dentist,
clm.svc_date_beg,clm.received_date,eoph.check_id,eop.eop_id from 
claim_h  clm 
inner join rlmbgrpl rl on rl.mb_gr_pl_id = clm.mbgrpl_id
inner join member mbr on mbr.member_id= rl.member_id
inner join eop_d eop on eop.claim_id = clm.claim_id
inner join eop_h eoph on eoph.eop_id = eop.eop_id
inner join [plan] pln on pln.plan_id = rl.plan_id
inner join rlplfc on rlplfc.mb_gr_pl_id = mbr.member_id
inner join facility_sec fc on rlplfc.facility_id = fc.fc_id
where clm.claim_id=@claimid
--where ((mbr.member_id = @memberid ) OR (mbr.last_name = @lastname AND date_of_birth = @dob)) AND rlplfc.facility_id = @facilityid
--order by svc_date_beg desc 

INSERT INTO @ClaimInformation(ServiceDate,Status,ADACode,Tooth,Surface,Charge,Allowed,Deductible,PatientResp,PlanPays,Coverage,Remarks)
select convert(nvarchar(MAX),claim_d.svc_beg, 101),[status],d_proc_code as ADACode,tooth_no,surface,convert(nvarchar(MAX),claim_d.cob_amt),convert(nvarchar(MAX),allowed),convert(nvarchar(MAX),fam_deductible),convert(nvarchar(MAX),patient_resp),
convert(nvarchar(MAX),ind_deductible),convert(nvarchar(MAX),claim_d.perc_covered),(SELECT ', ' + cast(s.remarks as varchar)
                      FROM [dbo].claim_remarks s where s.claim_id=claim_d.claim_id 
                      ORDER BY s.remarks
                     FOR XML PATH('')) from claim_d 
inner join claim_h clm on clm.claim_id = claim_d.claim_id 
--inner join claim_remarks_sec cr on cr.claim_id=clm.claim_id
where clm.claim_id = @claimid 

INSERT INTO @ClaimTotalDetails(Charge,Allowed,Deductible,PatientResp,PlanPays,PatientRemainingMaximum)
select top 1 convert(nvarchar(MAX),claim_d.cob_amt),convert(nvarchar(MAX),allowed),convert(nvarchar(MAX),fam_deductible),convert(nvarchar(MAX),patient_resp),convert(nvarchar(MAX),ind_deductible),convert(nvarchar(MAX),claim_d.perc_covered) from claim_d 
inner join claim_h clm on clm.claim_id = claim_d.claim_id
where clm.claim_id = @claimid

select * from @ClaimBasicDetails

select * from @ClaimInformation

select * from @ClaimTotalDetails

SET NOCOUNT OFF 
END