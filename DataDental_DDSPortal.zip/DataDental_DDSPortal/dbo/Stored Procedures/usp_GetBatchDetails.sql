﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_GetBatchDetails
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetBatchDetails]
@retry INT=3
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempBatch') IS NOT NULL
    DROP TABLE #tempBatch
IF OBJECT_ID('tempdb..#tempFailure') IS NOT NULL
    DROP TABLE #tempFailure

DECLARE @ctc DATETIME=GETDATE();

SELECT [batch_id]
      ,[ref_id]
      ,[event_id]
      ,[status]
      ,[retry]
      ,[error]
      ,[completed_time]
      ,[created_date]
	  INTO #tempFailure
	  FROM [dbo].[batch_process_details]
	  Where [status]=1004 AND DATEADD(MINUTE,1,[created_date])<=@ctc
	  
--Select *
UPDATE b SET b.[status]=1001,b.[completed_time]=null	
	FROM #tempFailure t
	JOIN [dbo].[batch_process_details] b(nolock) ON t.[batch_id]=b.[batch_id]

SELECT TOP 10 [batch_id]
      ,[ref_id]
      ,[event_id]
      ,[status]
      ,[retry]
      ,[error]
      ,[completed_time]
      ,[created_date]
	  INTO #tempBatch
	  FROM [dbo].[batch_process_details]
	  --Where [retry]>0 OR completed_time IS NULL
	  Where [status]=1001

--Select *
UPDATE b SET b.[status]=1002
	FROM [batch_process_details] b
	JOIN #tempBatch t ON t.batch_id=b.batch_id

--Select *From #tempBatch
SELECT t.batch_id AS BatchId,t.ref_id AS RefId,e.event_id AS EventId,e.event_category,e.event_module AS EventModule,
	e.event_type AS EventType,e.ref_object AS RefObject
	INTO #tempEvent
	FROM #tempBatch t
	JOIN event_master e ON e.event_id=t.event_id

SELECT *
	FROM #tempEvent

SELECT DISTINCT t.BatchId AS Id,i.code_id,i.email AS Email,i.group_zip AS GroupZip,i.invitecode AS Code,i.last_name AS LastName,c.sys_rec_id AS GroupId
	FROM #tempEvent t
	JOIN invitecode_details i on i.code_id=t.RefId
	JOIN contact_sec c ON c.email=i.email COLLATE SQL_Latin1_General_CP1_CS_AS AND c.subsys_code='GP' AND c.addr_type='L'
	AND c.lname=i.last_name COLLATE SQL_Latin1_General_CP1_CS_AS
	WHERE t.EventId=3

END