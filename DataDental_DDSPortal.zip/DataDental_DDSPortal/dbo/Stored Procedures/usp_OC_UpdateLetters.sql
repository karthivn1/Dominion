﻿
--exec usp_GetOperatingCompanyDetails 10
-- =============================================
-- Author:		<Mari Selvam Sornaraj>
-- Create date: <15-mar-2016>
-- Description:	<This stored procedure is used to update the Letters tab details in operating company>

-- =============================================

CREATE PROCEDURE [dbo].[usp_OC_UpdateLetters]
(
 @MemberTermLetter int,
@MemberWelcomeLetter  int,
@EmployerTermLetter  int,
@EmployerWelcomeLetter int,
@OcID int,

@ReasonCode     VARCHAR(2)=NULL, 
@ActivityMasterId INT=NULL, 
@UserId       VARCHAR(15)=NULL
)
AS
BEGIN
update oper_company set
mb_term_letter_id = @MemberTermLetter,
mb_wel_letter_id = @MemberWelcomeLetter,
gp_term_letter_id = @EmployerTermLetter,
gp_wel_letter_id = @EmployerWelcomeLetter
where oc_id= @OcID;


IF( @ActivityMasterId != 0 ) 
            BEGIN 
                EXEC usp_SaveActivity 'OC', @OcID, @ReasonCode, @ActivityMasterId, @UserId 
            END
End