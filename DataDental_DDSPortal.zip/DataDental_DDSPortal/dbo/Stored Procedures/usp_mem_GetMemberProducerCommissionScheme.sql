﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <22-11-2016>
-- Description:	<This sp gets the Member Producer Commission Scheme Details by passing schemeId and Producer Type>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberProducerCommissionScheme]
(
@commSchemeId INT,
@pdType NVARCHAR(MAX)
)
AS
BEGIN
SET NOCOUNT ON;	
--Commission Scheme

		SELECT comm_scheme.comm_scheme_title AS CommissionSchemeTitle, 
			   comm_scheme.comm_scheme_type, 
			   comm_scheme.comm_type AS CommissionType, 
			   st_prd_perc.sequence, 
			   st_comm_timeline.comm_st_time_lb AS FromMonths,
			   st_comm_timeline.comm_st_time_ub AS ToMonths,
			   st_prd_perc.producer_perc AS 'Percent'
		FROM comm_scheme
			 INNER JOIN st_prd_perc ON comm_scheme.comm_scheme_id = st_prd_perc.comm_scheme_id  
			 INNER JOIN st_comm_timeline ON st_prd_perc.comm_st_time_id = st_comm_timeline.comm_st_time_id AND st_comm_timeline.comm_scheme_id = st_prd_perc.comm_scheme_id
			 LEFT JOIN typ_table typComTyp ON  typComTyp.subsys_code='PL' AND typComTyp.tab_name='comm_scheme' AND typComTyp.code=comm_scheme.comm_type
			 
		WHERE st_prd_perc.comm_scheme_id = @commSchemeId AND st_prd_perc.producer_type = @pdType
		UNION 
		SELECT comm_scheme.comm_scheme_title AS CommissionSchemeTitle,
			   comm_scheme.comm_scheme_type,
			   comm_scheme.comm_type AS CommissionType,
			   prd_grad_perc.sequence,
		       grad_comm_amt.comm_grad_lb AS FromMonths,
			   grad_comm_amt.comm_grad_ub AS ToMonths,
			   prd_grad_perc.prd_grad_perc AS 'Percent'
		 FROM grad_comm_amt 
			  INNER JOIN prd_grad_perc ON prd_grad_perc.comm_grad_id = grad_comm_amt.comm_grad_id
			  INNER JOIN comm_scheme ON grad_comm_amt.comm_scheme_id = prd_grad_perc.comm_scheme_id AND comm_scheme.comm_scheme_id = prd_grad_perc.comm_scheme_id
			  LEFT JOIN typ_table typComTyp ON  typComTyp.subsys_code='PL' AND typComTyp.tab_name='comm_scheme' AND typComTyp.code=comm_scheme.comm_type
		WHERE prd_grad_perc.comm_scheme_id = @commSchemeId AND prd_grad_perc.producer_type = @pdType

SET NOCOUNT OFF
END