﻿CREATE PROCEDURE [dbo].[usp_GetGroupSummaryDetails] 
(
@GroupID INT,
@PlanID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @GroupSummary TABLE
(
id INT IDENTITY(1,1),
GroupID INT ,
GroupName VARCHAR(max),
PlanID INT,
PlanName VARCHAR(MAX),
Address VARCHAR(MAX),
Phone VARCHAR(50),
EffectiveDate VARCHAR(50),
PlanEffectiveDate VARCHAR(50),
PlanType VARCHAR(MAX),
RenewalDate VARCHAR(50)
)

DECLARE @GroupSummaryCoverageTierDetails TABLE
(
id INT IDENTITY(1,1),
CoverageTier VARCHAR(MAX),
Rate VARCHAR(MAX),
NumberOfSubscribers INT,
NumberOfDepedents INT,
TotalMembers INT
)

INSERT INTO @GroupSummary(GroupID ,GroupName ,PlanID ,PlanName ,Address ,Phone ,EffectiveDate,PlanEffectiveDate ,PlanType ,RenewalDate)
--SELECT top 1 grp.group_id,
--              RTRIM(grp.group_name),
--              tbl_plan.plan_id,
--              RTRIM(tbl_plan.plan_name),
--              RTRIM(ISNULL(tbl_address.addr1,'')) +''+ RTRIM(ISNULL(tbl_address.addr2,'')) +',' +RTRIM(ISNULL(tbl_address.city,'')) + ','+RTRIM(ISNULL(tbl_address.county,'')) +' , '+RTRIM(ISNULL(tbl_address.country,'')) +' , '+RTRIM(Isnull(tbl_address.[st
--ate],'')) +' '+RTRIM(isnull(tbl_address.zip,'')) as addresss,
--              RTRIM(tbl_contact.phone1),
--			  convert(nvarchar(MAX), tbl_status.eff_date, 101),
--			  convert(nvarchar(MAX), tbl_status.eff_date, 101),              
--			  typ.descr as plan_type,
--			  convert(nvarchar(MAX),  tbl_renewal.renewal_date, 101)             
--       FROM group_sec grp 
--               JOIN rel_gppl_sec rgroupplan on rgroupplan.group_id =grp.group_id
--              JOIN  plan_sec tbl_plan on tbl_plan.plan_id =rgroupplan.plan_id 
--               JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id 
--               JOIN contact_sec tbl_contact  on grp.group_id = tbl_contact.sys_rec_id  
--               JOIN group_status_sec tbl_status ON tbl_status.group_id = tbl_address.sys_rec_id 
--               --JOIN group_rules tbl_group_rules on tbl_group_rules.rel_gppl_id=rgroupplan.rel_gppl_id
--               JOIN group_renewal_sec tbl_renewal on tbl_renewal.group_id=grp.group_id
--            JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type
--       WHERE  
--	   tbl_address.subsys_code = 'GP'and 
--                 tbl_address.addr_type ='L' and 
--                 tbl_contact.subsys_code='GP' and
--                typ.subsys_code='PL' and typ.tab_name='ins_type' and
--				tbl_status.group_status='A4' and
--                 grp.group_id =@GroupID and 
--                 tbl_plan.plan_id =@PlanID
--			order by tbl_status.eff_date desc

 SELECT top 1 grp.group_id,
              RTRIM(grp.group_name) group_name,
              tbl_plan.plan_id,
              RTRIM(tbl_plan.plan_name) plan_name,
              RTRIM(ISNULL(tbl_address.addr1,'')) +''+ RTRIM(ISNULL(tbl_address.addr2,'')) +',' +RTRIM(ISNULL(tbl_address.city,'')) + ','+RTRIM(ISNULL(tbl_address.county,'')) +' , '+RTRIM(ISNULL(tbl_address.country,'')) +' , '+RTRIM(Isnull(tbl_address.[state],'')) +' '+RTRIM(isnull(tbl_address.zip,'')) as addresss,
              RTRIM(tbl_contact.phone1),
			  convert(nvarchar(MAX), tbl_status.eff_date, 101) group_effective_date,
			  convert(nvarchar(MAX), rgroupplan.eff_date, 101) PlanEffectiveDate ,             
			  typ.descr as plan_type,
			   convert(nvarchar(MAX), grp.next_renew_date, 101) group_renewal_date
			--  convert(nvarchar(MAX),  tbl_renewal.renewal_date, 101)             
       FROM rel_gppl_sec rgroupplan   
               JOIN group_sec grp  on rgroupplan.group_id =grp.group_id
              JOIN  plan_sec tbl_plan on tbl_plan.plan_id =rgroupplan.plan_id 
               JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id 
			   JOIN group_status_sec tbl_status ON tbl_status.group_id = grp.group_id 
               JOIN contact_sec tbl_contact  on grp.group_id = tbl_contact.sys_rec_id  
              --JOIN group_rules tbl_group_rules on tbl_group_rules.rel_gppl_id=rgroupplan.rel_gppl_id
               JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type
       WHERE  
	   tbl_address.subsys_code = 'GP'and 
                 tbl_address.addr_type ='L' and 
                 tbl_contact.subsys_code='GP' and
                --typ.subsys_code='PL' and
				 typ.tab_name='ins_type' and
				tbl_status.group_status='A4' and tbl_status.exp_date is null and
                 grp.group_id =@GroupID and 
                 tbl_plan.plan_id =@PlanID
			--order by tbl_status.eff_date desc
 
 INSERT INTO @GroupSummaryCoverageTierDetails (NumberOfSubscribers,NumberOfDepedents,CoverageTier,TotalMembers,Rate)
 SELECT a.NoofSubscribers,b.NoofDependent,a.CoverageTier,(a.NoofSubscribers+b.NoofDependent) as total,'Rate'
FROM
(select pl_rat_sec.rate_text as CoverageTier, count(distinct(member_sec.member_id)) as NoofSubscribers
from rlmbgrpl_sec
inner join member_sec on member_sec.member_id = rlmbgrpl_sec.member_id
inner join rlmbrt_sec on rlmbgrpl_sec.mb_gr_pl_id = rlmbrt_sec.mb_gr_pl_id
INNER JOIN pl_rat_sec ON rlmbrt_sec.rate_code = pl_rat_sec.rate_code
Inner join rlplfc_sec on rlplfc_sec.mb_gr_pl_id = rlmbgrpl_sec.mb_gr_pl_id
where rlmbgrpl_sec.group_id=@GroupID and rlmbgrpl_sec.plan_id=@PlanID
and((rlmbrt_sec.exp_rt_date is null) or  (rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))))
group by pl_rat_sec.rate_text) a 
inner join
(select pl_rat_sec.rate_text as CoverageTier, count(distinct(member_sec.member_id)) as NoofDependent
from member_sec inner join rlmbgrpl_sec 
on member_sec.family_id = rlmbgrpl_sec.member_id 
inner join rlmbrt_sec on rlmbrt_sec.mb_gr_pl_id = rlmbgrpl_sec.mb_gr_pl_id
inner join pl_rat_sec on pl_rat_sec.rate_code=rlmbrt_sec.rate_code
where rlmbgrpl_sec.group_id=@GroupID and rlmbgrpl_sec.plan_id=@PlanID
and member_sec.member_id<>member_sec.family_id
and((rlmbrt_sec.exp_rt_date is null) or  (rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))))
group by pl_rat_sec.rate_text) b
on a.CoverageTier = b.CoverageTier

-- SELECT b.subscriber,b.Depedent,b.rate_text,(b.subscriber+b.Depedent) as Totalmembers,'Rate'  FROM (
--SELECT count (DISTINCT a.subsriber) as subscriber,count(a.depedent) as Depedent , (count(a.subsriber)+ 0) as ex,a.rate_text FROM
--(SELECT DISTINCT (member_sec.family_id ) as subsriber,(member_sec.member_id) as depedent,pl_rat_sec.rate_text as rate_text, tbl_plan.plan_id 
--FROM member_sec
--inner join rlplfc_sec on  rlplfc_sec.member_id=member_sec.member_id
--inner join rlmbgrpl_sec on rlmbgrpl_sec.mb_gr_pl_id=rlplfc_sec.mb_gr_pl_id 
--inner join plan_sec tbl_plan on tbl_plan.plan_id = rlmbgrpl_sec.plan_id 
--inner join group_sec tbl_group on tbl_group.group_id =rlmbgrpl_sec.group_id  
--inner join rlmbrt_sec on rlmbrt_sec.mb_gr_pl_id=rlmbgrpl_sec.mb_gr_pl_id
--inner join pl_rat_sec on rlmbrt_sec.rate_code =pl_rat_sec.rate_code
--WHERE tbl_group.group_id =@GroupID and tbl_plan.plan_id=@PlanID and
--   member_sec.member_id <> member_sec.family_id 
--and (( rlmbrt_sec.exp_rt_date is null ) or  ( rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))) )
--) a GROUP BY a.rate_text)b

SELECT  * FROM @GroupSummary
SELECT  * FROM @GroupSummary
SELECT  * FROM @GroupSummary

select distinct rtrim(contact_sec.lname) + ','+ rtrim(contact_sec.fname) GroupAdminName, contact_sec.phone1 ContactNo
from contact_sec 
join address_sec addr on addr.sys_rec_id=contact_sec.sys_rec_id
join group_sec grp on grp.group_id=addr.sys_rec_id
join group_status_sec sta on grp.group_id=sta.group_id
join rel_gppl_sec reg on reg.group_id=grp.group_id
join plan_sec pln on pln.plan_id=reg.plan_id
where contact_sec.subsys_code='GP' and contact_sec.addr_type='L'
and sta.group_status='A4' and addr.subsys_code='GP' and grp.group_id=@GroupID


SELECT * FROM @GroupSummaryCoverageTierDetails


SET NOCOUNT OFF 
END