﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_getUserInfo_member 'TL23017325000','XXXXXXXXXXX','XXXXXXXXXXX',''
-- =============================================
CREATE PROCEDURE [dbo].[usp_getUserInfo_member] 
	-- Add the parameters for the stored procedure here
@memberId varchar(20),
@firstName varchar(20),
@lastName varchar(20),
@userName varchar(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @member_Id INT=0
DECLARE @first_Name varchar(20)=LTRIM(@firstName)
DECLARE @last_Name varchar(20)=LTRIM(@lastName)

IF LEN(@userName)>0
BEGIN
	
	IF ISNUMERIC(@userName)=1
	BEGIN
		SELECT @member_Id=member_id
			FROM member_sec
			WHERE member_id=@userName
	END
	IF @member_Id IS NULL OR @member_Id<=0
	BEGIN
		SELECT @member_Id=member_id
			FROM member_sec
			WHERE alt_id=@userName
	END 
END
ELSE
BEGIN
	SELECT @member_Id=member_id
			FROM member_sec m
			WHERE alt_id=@memberId
			AND UPPER(m.first_name)=UPPER(@firstName)
			AND UPPER(m.last_name)=UPPER(@lastName)
	
END
--SELECT @member_Id=m.member_id From member_user_details m WHERE m.user_name=@userName

IF EXISTS(
Select m.member_id
		From member_sec m
		JOIN rlmbgrpl_sec r on m.member_id=r.member_id
		Where m.member_id=@member_Id)
BEGIN
	Select top 1 m.member_id,r.group_id,r.plan_id,g.group_type
		INTO #tempMember
		From member_sec m
		JOIN rlmbgrpl_sec r on m.member_id=r.member_id
		JOIN group_sec g on g.group_id=r.group_id
		Where 1=1 
		AND m.member_id=@member_Id
		ORDER BY 1 DESC
		

	IF NOT EXISTS(Select *
	From member_user_details m
	Where m.member_id=@member_Id AND role_id in(5,4))
	BEGIN
		INSERT INTO member_user_details(member_id,[user_name],first_name,last_name,status_id,role_id,created_date,is_firstlogin,group_id,plan_id)
		SELECT t.member_id,t.member_id,@firstName,@lastName,1,IIF(t.group_type='EG',5,4) AS roleId,getdate(),0,t.group_id,t.plan_id
			FROM #tempMember t
	END
END
ELSE
BEGIN
	RAISERROR ('Member not found',16,1);
END

IF EXISTS(SELECT user_id
		FROM member_user_details m WHERE member_id =@member_Id 
		AND role_id in (4,5,6) 
		AND (m.group_id IS NULL OR m.plan_id IS NULL))
BEGIN

DECLARE @groupId INT
DECLARE @planId INT

SELECT TOP 1 @groupId=r.group_id,@planId=r.plan_id
--UPDATE u SET u.group_id=r.group_id,u.plan_id=r.plan_id
		FROM member_user_details u 
		JOIN rlmbgrpl_sec r ON r.member_id=u.member_id
		WHERE u.member_id =@member_Id 
		AND u.role_id in (4,5,6)
		AND (r.exp_gr_pl IS NULL OR r.exp_gr_pl > GETDATE())
		AND (u.group_id IS NULL OR u.plan_id IS NULL)

	IF LEN(@groupId)=0
	BEGIN
		SELECT TOP 1 @groupId=r.group_id,@planId=r.plan_id
			FROM member_user_details u 
			JOIN rlmbgrpl_sec r ON r.member_id=u.member_id
			WHERE u.member_id =@member_Id 
			AND u.role_id in (4,5,6)
			AND (u.group_id IS NULL OR u.plan_id IS NULL)

	END

UPDATE m SET m.group_id=@groupId,m.plan_id=@planId
	FROM member_user_details m 
	WHERE member_id =@member_Id 
	AND role_id in (4,5,6) 
	AND (m.group_id IS NULL OR m.plan_id IS NULL)
	
END

SELECT user_id AS ID, user_name AS username, password AS PasswordHash,status_id AS Status,temp_password AS TempPassword,
		role_id AS UserRoleId,is_firstlogin AS ISFirstLogin,member_id AS MemberID, Rtrim(isnull(first_name,'')) AS FirstName, Rtrim(isnull(last_name,'')) AS Lastname 
		FROM member_user_details WHERE member_id =@member_Id AND role_id in (4,5,6)
	
END