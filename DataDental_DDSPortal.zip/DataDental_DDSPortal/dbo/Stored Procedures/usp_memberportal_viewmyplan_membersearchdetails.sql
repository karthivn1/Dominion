﻿

-- Exec usp_memberportal_viewmyplan_membersearchdetails 0,'XXXXigueXXX','amia'
CREATE procedure [dbo].[usp_memberportal_viewmyplan_membersearchdetails] 
(@memberid int = 0,
@lastname varchar(max) = null ,
@firstname varchar(25) =null)
AS
Begin
 SET NOCOUNT ON 
	if(@memberid ='')
	set @memberid = NULL
	if(@lastname ='')
	set @lastname = NULL

	DECLARE @SqlQuery NVARCHAR(MAX)

	--TO SHOW ALL MEMBER
	--SET @SqlQuery ='select mbr.member_id as MemberID, mbr.last_name as LastName,mbr.first_name as FirstName,rgl.group_id,grp.group_name,pln.plan_name, pln.plan_id from member_sec mbr
	--inner join rlmbgrpl_sec rgl on mbr.member_id=rgl.member_id
	--inner join [group_sec] grp on grp.group_id=rgl.group_id
	--inner join [plan_sec] pln on pln.plan_id=rgl.plan_id
	--WHERE (1=1) '

	-- TO SHOW ONLY ACTIVE MEMBER AND ACTIVE PLANS
	SET @SqlQuery ='select mbr.member_id as MemberID, mbr.last_name as LastName,mbr.first_name as FirstName,rgl.group_id,grp.group_name,pln.plan_name, pln.plan_id from member_sec mbr
	inner join rlmbgrpl_sec rgl on mbr.member_id=rgl.member_id and exp_gr_pl is null
	inner join [group_sec] grp on grp.group_id=rgl.group_id
	inner join [plan_sec] pln on pln.plan_id=rgl.plan_id
	WHERE  (SELECT COUNT(*) FROM rlmbgrpl_sec WHERE member_id = mbr.member_id AND exp_gr_pl  IS NULL) > 0 
	and (SELECT COUNT(*) FROM rlmbgrpl_sec WHERE member_id = mbr.member_id AND exp_gr_pl  IS NULL AND cobra_flag = ''P'') = 0 
	and (SELECT COUNT(*) FROM rlmbgrpl_sec WHERE member_id = mbr.member_id AND exp_gr_pl  IS NULL AND cobra_flag = ''A'') = 0 '

	IF (@memberid IS NOT NULL AND @memberid !=0)
		SET @SqlQuery=@SqlQuery+' AND mbr.member_id='+ CAST(@memberid as VARCHAR) 
	IF (@lastname IS NOT NULL AND @lastname !='')
		SET @SqlQuery=@SqlQuery+' AND LOWER(mbr.last_name) like '''+''+Lower(@lastname)+'%'+''''
		IF (@firstname IS NOT NULL AND @firstname !='')
		SET @SqlQuery=@SqlQuery+' AND LOWER(mbr.first_name) like '''+''+Lower(@firstname)+'%'+''''
	
	
	EXECUTE sp_executesql @SqlQuery
 SET NOCOUNT OFF
End