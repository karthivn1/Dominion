﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_ForgotPassword]
(
@userName varchar(max),
@hashpassword varchar(max),
@portaltype varchar(max)
)
AS
BEGIN
SET NOCOUNT ON;
Declare  @Errormsg varchar(max)=NuLL;
Declare  @Pwdresetdate varchar(max) = NuLL;
declare @userId int;
Declare @temp varchar(max) = NuLL;
declare @email varchar(100);
declare @charlen int;

Declare @roleid int = CASE @portaltype WHEN 'Dominion' THEN (select role_id from role_master where role_name ='Dominion Provider')
WHEN 'CBC' THEN (select role_id from role_master where role_name ='CBC Provider')
ELSE
(select role_id from role_master where portal_type='pvr' and role_name ='Premera Provider')
END
IF EXISTS(select * from provider_user_details where UPPER(user_name)=UPPER(@userName) and role_id=(select role_id from role_master where portal_type='pvr' and role_name ='Internal Admin'))
BEGIN
select @roleid=role_id from role_master where portal_type='pvr' and role_name ='Internal Admin'
END
IF EXISTS(select * from provider_user_details where UPPER(user_name)=UPPER(@userName) and role_id=(select role_id from role_master where portal_type='pvr' and role_name ='Dominion Staff'))
BEGIN
select @roleid=role_id from role_master where portal_type='pvr' and role_name ='Dominion Staff'
END
IF EXISTS(select * from provider_user_details where UPPER(user_name)=UPPER(@userName) and role_id=(select role_id from role_master where portal_type='pvr' and role_name ='BlueCross Dental Sta'))
BEGIN
select @roleid=role_id from role_master where portal_type='pvr' and role_name ='BlueCross Dental Sta'
IF EXISTS(select * from provider_user_details where UPPER(user_name)=UPPER(@userName) and role_id=(select role_id from role_master where portal_type='pvr' and role_name ='PBC Staff'))
BEGIN
select @roleid=role_id from role_master where portal_type='pvr' and role_name ='PBC Staff'
END
END
set @userId=(select  user_id as UserID from provider_user_details  where UPPER(user_name)=UPPER(@userName) and role_id=@roleid);

select  @userId = user_id,@email=email  from provider_user_details  where UPPER(user_name)=UPPER(@userName) and role_id=@roleid

if (@userId is null)
begin
set @userId=0
end

 if(LEN(@email)>0)
 begin
	set @charlen=(select CHARINDEX('@',@email))
	set @email = (select LEFT(@email, 1)+'****'+SUBSTRING(@email,@charlen-1,LEN(@email)))
 end

IF NOT Exists(select user_id as UserID, user_name as UserName from provider_user_details  where UPPER(user_name)=UPPER(@userName) and role_id=@roleid)
Begin
 set @Errormsg= 'Username is invalid.';
End
else
Begin

If Exists(select user_id as UserID, user_name as UserName, password_hash as Password,status_id as Status,is_firstlogin as ISFirstLogin,temp_password as TempPassword from provider_user_details  where UPPER(user_name) = UPPER(@userName) and status_id =4 and

 temp_password


 
IS NOT NULL and role_id=@roleid)
Begin

 set @Pwdresetdate=(select cast((select ISNULL(convert(date,forgot_password_time),' ')from provider_user_details  where UPPER(user_name)=UPPER(@userName) and forgot_password_time  is not NULL and role_id=@roleid) as varchar ));

 set @temp=(select Len(@Pwdresetdate))
 if (@temp IS NULL)
 Begin
 set @temp=' '
 End
 else
 set @temp=@Pwdresetdate
  set @Errormsg= 'A new password was requested for this account on ' + @temp +' We sent out an email .Please wait before trying again. Please check your email and your spam folders for instructions.';
  update provider_user_details set forgot_password_time =convert(date,getdate()) where UPPER(user_name)=UPPER(@userName) 
  insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,14,1001,0,convert(date,getdate()));
End

else
Begin

If Exists(select  user_id as UserID, user_name as UserName, password_hash as Password,status_id as Status,is_firstlogin as ISFirstLogin,temp_password as TempPassword from provider_user_details  where UPPER(user_name)=UPPER(@userName) and status_id =1 and 

role_id=@roleid)
Begin
  set @Errormsg= 'Activate-'+@email;

 update provider_user_details set temp_password=@hashpassword,status_id=4,forgot_password_time =convert(date,getdate()) where UPPER(user_name)=UPPER(@userName)
 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,14,1001,0,convert(date,getdate()))
End
End
End

If (@Errormsg IS NULL)
BEGIN
 set @Errormsg= 'Your account is locked, Please contact our customer support to have your account unlocked';
 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,17,1001,0,convert(date,getdate()));
 END
 DECLARE @Err as table
(
 ErrMsg varchar(max)
)
INSERT INTO @Err(ErrMsg)VALUES(@Errormsg)
SELECT * FROM @Err

SET NOCOUNT OFF
END