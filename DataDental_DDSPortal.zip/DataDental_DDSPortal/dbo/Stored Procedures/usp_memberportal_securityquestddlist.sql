﻿CREATE PROCEDURE [dbo].[usp_memberportal_securityquestddlist]

AS
BEGIN
SET NOCOUNT ON;

Select security_question_id as Security_Question_Id,question as Security_Question_Name from security_question_master where isactive='True'



SET NOCOUNT OFF
END