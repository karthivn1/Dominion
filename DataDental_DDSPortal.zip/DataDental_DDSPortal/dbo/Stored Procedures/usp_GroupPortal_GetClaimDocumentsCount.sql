﻿CREATE PROCEDURE [dbo].[usp_GroupPortal_GetClaimDocumentsCount] 
(
@MessageReceiverID varchar(25)
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @ClaimDocumentsCount TABLE
(
id INT IDENTITY(1,1),
ClaimCount INT NULL
)

DECLARE @userId VARCHAR(20)
DECLARE @groupid VARCHAR(20)
SELECT @userId= user_id,@groupid=group_id FROM group_user_details WHERE user_name=@MessageReceiverID

INSERT INTO @ClaimDocumentsCount(ClaimCount)

SELECT COUNT(*)
FROM message msg join message_detail md on  msg.parentid=md.message_id --msg.message_id=md.message_id and
WHERE md.is_delete=0 and is_new=1 and is_read=0 and md.message_receiver_id=@userId

INSERT INTO @ClaimDocumentsCount(ClaimCount)
select COUNT(*) from group_ims_doc
where group_id=@groupid and doc_date between Cast(dateadd(yy,-2,getdate()) as date) and Cast(getdate() as date)
and isNew =1

SELECT * FROM @ClaimDocumentsCount

SET NOCOUNT OFF 
END