﻿  -- =============================================
-- Author:		<Selvakumar K>
-- Create date: <22-Nov-2016>
-- Description:	<This stored procedure is used to get facility deatils for the given search criteria>
-- =============================================
 
CREATE PROCEDURE [dbo].[usp_mem_DependentFacilDeatils]
(
 @PlanId int=null,
 @facilityDate datetime=null,

 @FacilityID int=null ,
 @npID varchar(10)=null,
 @FacilityName varchar(50),
 @City  varchar(50)=null,
 @State  varchar(50)=null,
 @Country  varchar(50)=null,
 @ZipCode varchar(10)=null,
 @Status varchar(10)=null,
 @Phone varchar(14)=null
)
AS
BEGIN
SET NOCOUNT ON;
	
	BEGIN TRAN 
	BEGIN TRY

	 	--List of Facility
declare @Sql  nvarchar(max)='SELECT DISTINCT  facility.fc_id AS FacilityID,
	       facility.fc_type AS [Type],
		   facility.fc_name AS FacilityName,
		   CAST(CASE WHEN facility.phone_elig= ''N'' THEN 0 ELSE 1 END AS BIT) AS PhoneElig,
		   facility.fc_source ,
		   fcstat.status AS ''Status'',
		   fcstat.eff_date AS EffectiveDate,
		   facility.fc_opr_tory AS Operatories ,
		   adds.addr1 , adds.addr2,
		   adds.addr1 + isnull(adds.addr2,'''') As Address,
		   adds.city AS City,
		   adds.country AS Country,
		   adds.county AS County,
		   adds.state ''State'',     
		   adds.zip AS ZipCode,
		   facility.emergency_phone AS EmergPhone,
		   facility.emg_phone_ext AS EmergPhoneExt,
		   CAST(CASE WHEN facility.fax_elig= ''N'' THEN 0 ELSE 1 END AS BIT) AS FaxElig,  
		   --rlplfc.eff_date AS PlanFacEffectiveDate,
		   --rlplfc.exp_date AS PlanFacExpireDate,
		   contact.phone1 AS Phone,
		   contact.ext1 AS PhoneExt,
		   facility.np_id AS NPID  
   FROM [address] adds, facility, fcstat, contact
    WHERE facility.fc_id = adds.sys_rec_id 
	and adds.subsys_code = ''FC'' AND adds.addr_type = ''L'' 
	AND facility.fc_id = contact.sys_rec_id 
	and contact.subsys_code = ''FC'' 
	and	contact.con_type = ''OF'' 
	and	facility.fc_id = fcstat.facility_id 
	AND fcstat.eff_date <= ''' + convert(varchar(20), @facilityDate) + 
	''' and (fcstat.exp_date >''' + convert(varchar(20), @facilityDate) + ''' or fcstat.exp_date is NULL) 
	AND facility.fc_id in (select DISTINCT net_facility.fc_id from net_facility, net_plans where net_plans.plan_id =' + convert(varchar(20), @PlanId) + 
	' and net_facility.con_type = net_plans.con_type and net_facility.net_id = net_plans.fc_net_id	   
	and net_facility.eff_date <=''' + convert(varchar(20), @facilityDate) + ''' AND (net_facility.exp_date >''' + convert(varchar(20), @facilityDate) + ''' OR net_facility.exp_date is NULL) 
	AND net_plans.eff_date <=''' + convert(varchar(20), @facilityDate) + ''' AND (net_plans.exp_date >''' + convert(varchar(20), @facilityDate) + ''' OR	net_plans.exp_date is NULL) 
	AND not exists (select * from fc_plans where net_facility.net_fc_id = fc_plans.net_facility and net_facility.con_type = fc_plans.con_type and net_facility.ovr_ride = fc_plans.ovr_ride and net_plans.plan_id = fc_plans.plan_id AND 
	fc_plans.eff_date = fc_plans.exp_date AND fc_plans.ovr_ride = ''Y'' )) '   
	
	--select @Country

	IF @FacilityName <> ''
   set @Sql = @Sql + ' AND lower(facility.fc_name) =  lower(''' +@FacilityName+''') '
   	IF @City <> ''
   set @Sql = @Sql + ' AND lower(adds.city) =  lower(''' + @City+''') '
   	IF @State <> ''
   set @Sql = @Sql + ' AND lower(adds.state) =  lower(''' +@State+''') '
   	IF @Country <> ''
   set @Sql = @Sql + ' AND lower(adds.country) =  lower(''' +@Country+''') '
   	IF @ZipCode <> ''
   set @Sql = @Sql + ' AND lower(adds.zip) =  lower(''' +@ZipCode+''') '
   	IF @Status <> ''
   set @Sql = @Sql + ' AND lower(fcstat.status) =  lower(''' +@Status+''') '
	  	IF @Phone <> ''
   set @Sql = @Sql + ' AND lower(facility.emergency_phone) =  lower(''' +@Phone+''') '
     	IF @npID  <> ''
   set @Sql = @Sql + ' AND lower(facility.np_id) =  lower(''' +@npID+''') '
   IF @FacilityID <> 0
   set @Sql = @Sql + ' AND facility.fc_id =  ' + convert(varchar(20), @FacilityID) +'  '
  -- print @Sql
	exec(@Sql)
	
	set @Sql='select @x = FacilityID from('+@Sql+')T order by FacilityID desc'

declare @xx int
set @xx = 0
exec sp_executesql @Sql, N'@x int out', @FacilityID out
--select @FacilityID 
	
	


	--Facility Details

--	SET @FacilityID=(SELECT top 1 
--facility.fc_id AS FacilityID
      
--   FROM [address] adds, facility, fcstat, contact
--    WHERE facility.fc_id = adds.sys_rec_id 
--	and adds.subsys_code = 'FC' AND adds.addr_type = 'L' 
--	AND facility.fc_id = contact.sys_rec_id 
--	and contact.subsys_code = 'FC' 
--	and	contact.con_type = 'OF' 
--	and	facility.fc_id = fcstat.facility_id 
--	AND fcstat.eff_date <= @facilityDate 
--	and (fcstat.exp_date > @facilityDate or fcstat.exp_date is NULL) 
--	AND facility.fc_id in (select DISTINCT net_facility.fc_id from net_facility, net_plans where net_plans.plan_id = @PlanId 
--	and net_facility.con_type = net_plans.con_type and net_facility.net_id = net_plans.fc_net_id 
--	and net_facility.eff_date <= @facilityDate AND (net_facility.exp_date > @facilityDate OR net_facility.exp_date is NULL) 
--	AND net_plans.eff_date <= @facilityDate AND	(net_plans.exp_date > @facilityDate OR	net_plans.exp_date is NULL) 
--	AND not exists (select * from fc_plans where net_facility.net_fc_id = fc_plans.net_facility and net_facility.con_type = fc_plans.con_type and net_facility.ovr_ride = fc_plans.ovr_ride and net_plans.plan_id = fc_plans.plan_id AND fc_plans.eff_date = fc

--plans.exp_date AND fc_plans.ovr_ride = 'Y' ))) 


		--Facility Auxilary Details
	SELECT DISTINCT  RTRIM(LTRIM(fcstaff.staff_code)) AS StaffCode,
			RTRIM(LTRIM(typ.descr)) AS AuxStaffType,
			fcstaff.number_of_type AS AuxNumber,
			fcstaff.fc_id AS FacilityId,
			RTRIM(LTRIM(fcstaff.staff_type)) AS StaffType,
			RTRIM(LTRIM(typ.subsys_code)) AS SubSystemCode 
	FROM fc_staff AS fcstaff 
	LEFT OUTER JOIN typ_table typ ON typ.tab_name = 'fc_staff_ax' AND fcstaff.staff_code = typ.code 
	WHERE 
	  fcstaff.fc_id = @FacilityID AND
	 
	   fcstaff.staff_type = 'A'
	   COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
	SET NOCOUNT OFF;

END