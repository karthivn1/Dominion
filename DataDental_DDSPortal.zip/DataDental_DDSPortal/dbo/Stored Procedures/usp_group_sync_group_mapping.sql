﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_group_sync_group_mapping
-- =============================================
CREATE PROCEDURE [dbo].[usp_group_sync_group_mapping]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @count INT=0
DECLARE @iCount INT=1

DECLARE @groupInfo AS TABLE
(
Id INT identity(1,1),
group_user_id INT,
group_id INT NULL,
first_name NVARCHAR(10) NULL,
last_name NVARCHAR(15) NULL,	
email NVARCHAR(250) NULL,
[status] bit	
)

INSERT INTO @groupInfo(group_user_id,group_id,first_name,last_name,email,[status])
SELECT DISTINCT gm.group_user_id,gm.group_id,g.first_name,g.last_name,g.email,ISNULL(gm.[status],0) AS [status]
	FROM group_user_mapping gm
	JOIN group_user_details g ON gm.[user_id]=g.[user_id]
	WHERE gm.group_user_id>0

SELECT @count=COUNT(Id) FROM @groupInfo

DECLARE @group_user_id INT
DECLARE @groupId INT
DECLARE @FirstName NVARCHAR(10)
DECLARE @LastName NVARCHAR(15)	
DECLARE @Email NVARCHAR(250)
DECLARE @Status BIT
DECLARE @IsTrue INT=0


WHILE @count>=@iCount 
BEGIN

SELECT @group_user_id=g.group_user_id,@groupId=g.group_id,@FirstName=g.first_name,
	@LastName=g.last_name,@Email=g.email,@Status=g.[status]
	FROM @groupInfo g
	WHERE g.Id=@iCount 

EXEC @IsTrue=usp_group_getGroupContact @groupId,@FirstName,@LastName,@Email

IF (@IsTrue=1 AND @Status=1) OR (@IsTrue=0 AND @Status=0)
BEGIN
	--SELECT *
	DELETE g
		FROM group_user_mapping g
		WHERE g.group_user_id=@group_user_id

END

SET @iCount=@iCount+1

END
	
END