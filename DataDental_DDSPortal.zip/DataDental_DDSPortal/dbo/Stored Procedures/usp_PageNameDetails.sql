﻿CREATE procedure [dbo].[usp_PageNameDetails]

 AS
 Declare @userid int;
 Begin
Select page_id as Page_Id ,page_name as Page_Name from page_master
 
 End