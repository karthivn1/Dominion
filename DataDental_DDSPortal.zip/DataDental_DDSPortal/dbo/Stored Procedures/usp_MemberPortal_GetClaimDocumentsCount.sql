﻿CREATE PROCEDURE [dbo].[usp_MemberPortal_GetClaimDocumentsCount]
(
@MessageReceiverID varchar(25)
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @ClaimDocumentsCount TABLE
(
id INT IDENTITY(1,1),
ClaimCount INT NULL
)

DECLARE @userId VARCHAR(20)
DECLARE @memberid VARCHAR(20)
SELECT @userId= user_id,@memberid=member_id FROM member_user_details WHERE user_name=@MessageReceiverID

INSERT INTO @ClaimDocumentsCount(ClaimCount)

SELECT COUNT(*)
FROM member_message msg join member_message_detail md on  msg.parentid=md.message_id --msg.message_id=md.message_id and
WHERE md.is_delete=0 and is_new=1 and is_read=0 and md.message_receiver_id=@userId


INSERT INTO @ClaimDocumentsCount(ClaimCount)
select COUNT(*)
from member_ims_doc im 
JOIN member_sec m ON im.member_id=m.member_id
where m.family_id=@memberid
AND im.doc_type<>'Renewal Notices'
and im.doc_date between Cast(dateadd(yy,-2,getdate()) as date) and Cast(getdate() as date)
and im.isNew=1

SELECT * FROM @ClaimDocumentsCount

SET NOCOUNT OFF 
END