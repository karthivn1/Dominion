﻿
--exec usp_mem_getcobdependentdetail 536681
-- =============================================
-- Author:		Mari Selvam Sornaraj
-- Create date: 02/01/2017
-- Description:	To Get Cob dependent details
-- =============================================
CREATE PROCEDURE  [dbo].[usp_mem_getcobdependentdetail] 
	-- Add the parameters for the stored procedure here
	(
	  @memGroupPlanId int
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select  member.first_name as 'FirstName', 
	member.member_id as 'MemberID',          
member.middle_init  as 'MiddleInitial',           
member.last_name  as 'LastName',           
member.date_of_birth  as 'DOB',           
member.member_code as 'RelCode',           
mbr_code.mbr_code_desc  as 'Relationship',
member.oed  as 'OED',           
 member.student_flag ,
 facility.fc_name as 'FacilityName',
 rlplfc.eff_date as 'EffDate',
 rlplfc.exp_date as 'ExpDate',
 facility.fc_type as 'Status'
from member

inner join mbr_code on mbr_code.mbr_code= member.member_code
inner join rlplfc on rlplfc.member_id = member.member_id
left join facility on rlplfc.facility_id  = facility.fc_id
where  rlplfc.mb_gr_pl_id = @memGroupPlanId and rlplfc.exp_date is null

END