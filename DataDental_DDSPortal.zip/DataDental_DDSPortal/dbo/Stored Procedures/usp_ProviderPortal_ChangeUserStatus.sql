﻿CREATE proc [dbo].[usp_ProviderPortal_ChangeUserStatus]
(
@userid int,
@facilityid int,
@status varchar(max)
)
as
begin

declare @statusid int=(SELECT status_id FROM provider_user_details where user_id=@userid)

IF (@statusid=3)
BEGIN
update provider_user_details set status_id=(select status_id from user_status_master where status=@status and portal_type='pvr'),failed_login_attempt=0
where user_id=@userid
END
ELSE
BEGIN
update provider_user_details set status_id=(select status_id from user_status_master where status=@status and portal_type='pvr')
where user_id=@userid --or facility_id=@facilityid
END
SELECT 'Success'

end