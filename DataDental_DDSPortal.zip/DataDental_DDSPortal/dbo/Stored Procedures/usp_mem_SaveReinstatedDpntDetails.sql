﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <14-12-2016>
-- Description:	<This SP is used to Save the Reinsated Dependent Details >
-- =============================================
 
CREATE PROCEDURE [dbo].[usp_mem_SaveReinstatedDpntDetails]
(
@memberId INT=NULL,
@newMbrGroupPlanId INT=NULL,
@effDate DATETIME=NULL,
@actionCode VARCHAR(100)=NULL,
@hUser VARCHAR(100)=NULL,
@facilId INT=NULL,
@dpntMemberId INT=NULL,
@activityMasterId INT=NULL,
@subsystemCode	VARCHAR(2)=NULL,
@reasonCode  VARCHAR(2)=NULL,
@memberGroupPlanId INT=NULL,
@dpntmemberGroupPlanId INT=NULL,
@waitFlag VARCHAR(1)=NULL
)
AS
BEGIN
SET NOCOUNT ON;
BEGIN TRAN 
	BEGIN TRY

DECLARE @hmsi INT
DECLARE @count INT
DECLARE @SWP_Ret_Value INT = NULL  
DECLARE @SWP_Ret_Value1 CHAR(100) = NULL 
SELECT @hmsi=msi+1 from sysdatetime

IF (@memberGroupPlanId=@dpntmemberGroupPlanId)

BEGIN

  IF (@dpntMemberId>0)
  BEGIN
    
  -- UPDATE rlplfc SET mb_gr_pl_id=@newMbrGroupPlanId where mb_gr_pl_id=@dpntmemberGroupPlanId and exp_date IS NOT NULL and member_id=@dpntMemberId

   INSERT INTO rlplfc (mb_gr_pl_id,member_id, facility_id, eff_date, action_code, h_datetime, h_msi, h_action, h_user )
   SELECT @newMbrGroupPlanId,member_id, @facilId, @effDate, @actionCode, getdate(), @hmsi, @actionCode,@hUser
	FROM rlplfc where  mb_gr_pl_id=@memberGroupPlanId and exp_date IS NOT NULL and member_id=@dpntMemberId
    UPDATE sysdatetime set msi=msi+1 

   --UPDATE rlplfc SET exp_date=@effDate where mb_gr_pl_id=@memberGroupPlanId and exp_date IS NULL
   SET @count=(SELECT count(*) from rlplfc where mb_gr_pl_id=@newMbrGroupPlanId and  member_id=@dpntMemberId)

   IF (@count=0)
   BEGIN
   SELECT @hmsi=msi+1 from sysdatetime

   INSERT INTO rlplfc ( mb_gr_pl_id, member_id, facility_id, eff_date, action_code, h_datetime, h_msi, h_action, h_user )
   VALUES ( @newMbrGroupPlanId, @dpntMemberId, @facilId, @effDate, @actionCode, getdate(), @hmsi, @actionCode,@hUser)
     UPDATE sysdatetime set msi=msi+1 
	END 
	END


	EXEC mb_add_cat_opt @memberGroupPlanId,@dpntMemberId,@waitFlag,@SWP_Ret_Value OUTPUT,@SWP_Ret_Value1 OUTPUT

	IF @SWP_Ret_Value !>0  
	BEGIN
	ROLLBACK TRAN 
	END



 END


ELSE
BEGIN
   --UPDATE rlplfc SET mb_gr_pl_id=@newMbrGroupPlanId,eff_date=@effDate,exp_date=null,action_code=@actionCode,h_datetime=getdate()
   -- where mb_gr_pl_id=@memberGroupPlanId and exp_date IS NULL
   INSERT INTO rlplfc (mb_gr_pl_id,member_id, facility_id, eff_date, action_code, h_datetime, h_msi, h_action, h_user )
   SELECT @newMbrGroupPlanId,member_id, facility_id, @effDate, @actionCode, getdate(), @hmsi, @actionCode,@hUser
	FROM rlplfc where mb_gr_pl_id=@memberGroupPlanId and exp_date IS NOT NULL;
    
 
    UPDATE sysdatetime set msi=msi+1 
	END

	--UPDATE rlplfc SET exp_date=@effDate where mb_gr_pl_id=@memberGroupPlanId and exp_date IS NULL

 BEGIN 
 IF @activityMasterId>0 
 BEGIN
		EXEC usp_SaveActivity @subsystemCode,@memberId,@reasonCode,@activityMasterId,@hUser
		END
	END
	COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
   	SET NOCOUNT OFF
END