﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateBatchStatus]
	-- Add the parameters for the stored procedure here
@BatchId INT,
@Status INT,
@ErrorMsg NVARCHAR(500)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
DECLARE @retry INT=3
DECLARE @currentDate DATETIME=GETDATE();

IF @Status=1004
BEGIN
	--select *
	UPDATE b SET b.status=@Status,b.retry=b.retry+1,b.error=@ErrorMsg,b.completed_time=@currentDate 
		FROM batch_process_details b(nolock)
		WHERE b.batch_id=@BatchId AND b.retry<@retry

--Cancel job

   UPDATE b SET b.status=1005,b.error=@ErrorMsg,b.completed_time=@currentDate 
		FROM batch_process_details b(nolock)
		WHERE b.batch_id=@BatchId AND b.retry>=@retry


END
ELSE IF @Status=1003
BEGIN

--select *
	UPDATE b SET b.status=@Status,b.completed_time=@currentDate 
		FROM batch_process_details b(nolock)
		WHERE b.batch_id=@BatchId

END
ELSE
BEGIN


--select *
	UPDATE b SET b.status=@Status
		FROM batch_process_details b(nolock)
		WHERE b.batch_id=@BatchId

END
END