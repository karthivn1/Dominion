﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <16-10-2016>
-- Description:	<This SP is used to Display Plan and Dependent Details >
-- =============================================


CREATE PROCEDURE [dbo].[usp_mem_CGPlanDependentDpntDetails]  (
@memberId INT=NULL,
@groupId INT=NULL,
@planId INT=NULL
)
AS
BEGIN
SET NOCOUNT ON;
	;with tmp as
	(SELECT  rlplfc.mb_gr_pl_id AS DpntMbrGrpPlanID,             

	    rlplfc.rlplfc_id AS DpntFacilityID,             
         rlplfc.member_id AS DpntMemID,
		 member.last_name+member.first_name AS Member,		   
         rlplfc.facility_id AS FacilityID, 
		 facility.fc_name AS FacilityName,    
         rlplfc.eff_date AS EffDate,   
         rlplfc.exp_date AS ExpDate, 
		typ_table.descr 'Action',
		  mbr_code.mbr_code_desc AS Rel,	        
		 case 
		   when str_1='new_ssn' then cast(member.new_ssn as varchar) 
		   when str_1='member_id' then cast(member.member_id as varchar)
		   when str_1='source_id' then cast(member.source_id as varchar)
		   else
		   cast(member.alt_id as varchar) 
		   end 'ExternalID',
		   row_number() over(partition by rlplfc.member_id order by rlplfc.rlplfc_id desc) FacilDetails
		   
    FROM rlplfc   LEFT OUTER JOIN facility ON 
		rlplfc.facility_id = facility.fc_id 
		INNER JOIN  member ON rlplfc.member_id = member.member_id 
        INNER JOIN rlmbgrpl  ON  rlplfc.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id 
		INNER JOIN mbr_code ON mbr_code.mbr_code=  member.member_code
		INNER JOIN typ_table ON   typ_table.subsys_code = 'MB' 
		INNER JOIN typ_table_exp ON typ_table_exp.tab_name = 'ext_id_type'  
	  and typ_table_exp.int_1=member.ext_id_type and        
		typ_table.tab_name = 'action_code'  
		WHERE (typ_table.eff_date <= GETDATE() or     
	        typ_table.eff_date is NULL ) and (typ_table.exp_date > GETDATE() or      
		        typ_table.exp_date is NULL) 
		and  rlmbgrpl.member_id = @memberId 
		and rlmbgrpl.plan_id=@planId
		 and rlmbgrpl.group_id=@groupId
		and typ_table.code= rlplfc.action_code)
		select * from tmp where FacilDetails=1
SET NOCOUNT OFF
END