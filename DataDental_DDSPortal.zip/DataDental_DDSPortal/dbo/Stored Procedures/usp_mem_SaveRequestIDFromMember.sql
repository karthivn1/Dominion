﻿


-- =============================================   



-- Author: Harishraj.R 



-- Create date: <08-Nov-2016>   



-- Description:Add Request Id for group and plan from Member  



-- =============================================   



CREATE PROCEDURE [dbo].[usp_mem_SaveRequestIDFromMember] 

(

@que_detail_id INT,

@que_master_id INT=NULL,

@tran_type   NVARCHAR(MAX)=NULL, 

@q_type      NVARCHAR(MAX)=NULL, 

@member_id   INT =NULL, 

@contract_id  INT=NULL,

@address_type NVARCHAR(MAX)=NULL,

@group_id     INT =NULL, 

@group_type  NVARCHAR(MAX)=NULL,

@plan_id     INT=NULL, 

@ins_type    NVARCHAR(MAX)=NULL,

@ins_opt_qual NVARCHAR(MAX)=NULL,

@mail_code    NVARCHAR(MAX)=NULL,
@stat      NVARCHAR(MAX)=NULL,
--@ActionCode VARCHAR(10)=NULL,
@subsystemCode		VARCHAR(2)=NULL,
@reasonCode       VARCHAR(2)=NULL, 
@activityMasterId INT=NULL, 
@userCode        VARCHAR(8)=NULL

) 



AS 

BEGIN 

SET NOCOUNT ON 

	BEGIN TRAN 

	BEGIN TRY 



	

	BEGIN 

		INSERT INTO que_detail 

		(--que_detail_id,
		 que_master_id,
		 tran_type,
		 q_type,
		 member_id,
		 contract_id,
		 address_type,
		 group_id,
		 group_type,
		 plan_id,
		 ins_type,
		 ins_opt_qual,
		 mail_code,
		 entry_date,
		 stat ,
		 req_by) 



		Values      

		(

		@que_master_id, 

		@tran_type, 

		@q_type, 

		@member_id, 

		@contract_id, 		

		@address_type,

		@group_id, 

		@group_type, 

		@plan_id, 

		@ins_type, 

		@ins_opt_qual,
		
		@mail_code,
		
		GETDATE(),
		 
		@stat,

		@userCode
		);	

	END 

	

	IF( @activityMasterId != 0 ) 



	BEGIN 

		EXEC usp_SaveActivity @subsystemCode,@member_id,@reasonCode,@activityMasterId,@userCode

	END



	COMMIT TRAN 

	END TRY 



	BEGIN CATCH 

		ROLLBACK TRAN 

		DECLARE @erMessage  NVARCHAR(2048), 

		@erSeverity INT, 

		@erState    INT 

		SELECT @erMessage = ERROR_MESSAGE(),

		@erSeverity = ERROR_SEVERITY(),

		@erState = ERROR_STATE() 

		RAISERROR (@erMessage,@erSeverity,@erState ) 



	END CATCH 

END