﻿
-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <14-12-2016>
-- Description:	<This SP is used to Save the Reinsated Susbcriber Details >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_SaveReinstatedSubsDetails]
(
@memberId INT=NULL,
@memberGroupPlanId INT=NULL,
@groupId INT=NULL,
@planId INT=NULL,
@effDate DATETIME=NULL,
@actionCode VARCHAR(100)=NULL,
@hUser VARCHAR(100)=NULL,
@SiP INT=NULL,
@rateCode VARCHAR(100)=NULL,
@groupType VARCHAR(100)=NULL,
@NewMemberGroupPlanId	int output 
)
AS
BEGIN
SET NOCOUNT ON;
    BEGIN TRAN 
	BEGIN TRY
 
DECLARE @hmsi INT

--UPDATE rlmbgrpl SET exp_gr_pl=@effDate WHERE mb_gr_pl_id=@memberGroupPlanId --AND exp_gr_pl IS NULL

--UPDATE rlmbrt SET exp_rt_date=@effDate where  mb_gr_pl_id=@memberGroupPlanId and exp_rt_date IS NULL
 
IF @groupType='Single Group' 
BEGIN
 UPDATE group_status SET exp_date=@effDate WHERE group_id=@groupId
  SELECT @hmsi=msi+1 from sysdatetime  
 
 INSERT INTO group_status ( group_id , group_status , reason_code , eff_date ,
 h_datetime , h_action , h_user ) VALUES (@groupId , 'A4' , 'DF' , @effDate , getdate() , 'A4' , @hUser ) 
 UPDATE sysdatetime set msi=msi+1 
END


 SELECT @hmsi=msi+1 from sysdatetime  
 INSERT INTO rlmbgrpl ( member_id, group_id, plan_id, eff_gr_pl, action_code, h_datetime, h_msi, h_action, h_user, sub_in_plan)
 VALUES(@memberId,@groupId,@planId,@effDate,@actionCode,GETDATE(),@hmsi,@actionCode,@hUser,@SiP)
 SET @NewMemberGroupPlanId=SCOPE_IDENTITY()
 UPDATE sysdatetime set msi=msi+1 
 SELECT @hmsi=msi+1 from sysdatetime 

 IF @actionCode='CA'
 BEGIN
	UPDATE rlmbgrpl SET cobra_flag='A' WHERE mb_gr_pl_id=@NewMemberGroupPlanId 
 END

 INSERT INTO rlmbrt ( mb_gr_pl_id, rate_code, eff_rt_date, action_code, h_datetime, h_msi, h_action, h_user )
 VALUES (@NewMemberGroupPlanId,@rateCode,@effDate,@actionCode,GETDATE(),@hmsi,@actionCode,@hUser)
 
  SELECT @NewMemberGroupPlanId
 
 UPDATE sysdatetime set msi=msi+1 

 COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH

	SET NOCOUNT OFF
END