﻿CREATE PROCEDURE [dbo].[usp_memberportal_login_updateinvalidattempt]
(
@userId INT
)
AS
BEGIN
SET NOCOUNT ON;
DECLARE @loginatempt INT;

IF EXISTS(SELECT user_id 
			FROM member_user_details 
			WHERE user_id= @userId AND failed_login_attempt=3)
	BEGIN
		UPDATE member_user_details SET status_id  = 3  
			WHERE user_id= @userId  	
	END
	ELSE 
	BEGIN		
		UPDATE member_user_details SET 
			failed_login_attempt = ISNULL(failed_login_attempt,0)+1,incorrect_attempt_time= getdate()   
			WHERE user_id= @userId
	END

SELECT status_id AS Status,failed_login_attempt AS LoginAttempt ,incorrect_attempt_time  AS Incorrect_AttemptTiming 
	FROM member_user_details  
	WHERE user_id= @userId 

SET NOCOUNT OFF
END