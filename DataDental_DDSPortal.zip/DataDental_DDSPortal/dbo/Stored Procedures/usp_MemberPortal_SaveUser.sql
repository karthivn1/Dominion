﻿CREATE procedure [dbo].[usp_MemberPortal_SaveUser] 
(
@username as Varchar(max),
@firstname as Varchar(max),
@lastname as Varchar(max),
@middleinitial as Varchar(max)= NULL,
@phone as varchar(max)= NULL,
@email as Varchar(max),
@emailnotification as bit,
@roleid as int,
@hashpassword as Varchar(max),
@value as Varchar(max) )
AS
Begin
SET NOCOUNT ON 
Begin Transaction [adduser]

	Begin try
		Declare @userId int; 

If (@value = 'ADD')
Begin
	  If NOT Exists( (select user_name from member_user_details where user_name =@username))	  

					 Begin	
				
					Insert into member_user_details(user_name,member_id,first_name,last_name,middle_name,home_phone,email,email_notification,role_id,is_firstlogin) values(@username,0,@firstname,@lastname,@middleinitial,@phone,@email,@emailnotification,@roleid,1)
		       
					set @userId=(select  user_id as UserID from member_user_details  where user_name=@username);
		
					--Insert into user_role_mapping(user_id,role_id ) values(@userId,@roleid);
		print @userId
					 update member_user_details set temp_password=@hashpassword,status_id=4 where user_id=@userId 
		
					 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,6,1001,0,convert(date,getdate()));

					 select user_name from member_user_details where user_name =@username;
					 End
		 Else
					 Begin
		
					 select 'Duplicate User' as result
					 End
 end
  Else
  If (@value <> 'ADD')
  Begin
   If  Exists( (select user_name from member_user_details where user_name =@username))
   Begin
   
  update member_user_details set email =@email where user_name =@username

  	select user_name from member_user_details where user_name =@username;
	End
  End
	commit Transaction [adduser]
   End try

Begin Catch
rollback Transaction [adduser]
End Catch
SET NOCOUNT OFF
End