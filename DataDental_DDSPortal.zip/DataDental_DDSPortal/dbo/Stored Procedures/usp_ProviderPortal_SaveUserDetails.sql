﻿CREATE proc [dbo].[usp_ProviderPortal_SaveUserDetails] 
(
@usertype int,
@username varchar(max),
@email varchar(max)
)
as
begin

declare @status varchar(max)
DECLARE @ROLENAME varchar(25)
select @ROLENAME = role_name from role_master where role_id=@usertype

IF EXISTS(SELECT user_id FROM provider_user_details WHERE (email=@email or user_name=@username) and role_id =@usertype)
	BEGIN
		
			SET @status = 'User Name or Email Address already exists for ' + @ROLENAME
	END
Else 
	BEGIN		
				Insert into provider_user_details (user_name, email, status_id, role_id, facility_id,is_firstlogin) values (@username,@email,4,@usertype,999998,'True')
				INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
                VALUES (SCOPE_IDENTITY(),13,1001,0,CONVERT(date,GETDATE()));
				SET @status = 'Success'
		END

	SELECT @status

end