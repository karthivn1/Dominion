﻿CREATE PROCEDURE [dbo].[usp_GetSubscriberSummaryDetails] 
(
@GroupID INT,
@PlanID INT,
@MemberID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @SubscriberSummary TABLE
(
id INT IDENTITY(1,1),
SubscriberID INT NULL,
Name VARCHAR(max),
Address VARCHAR(MAX),
Phone VARCHAR(MAX),
Email VARCHAR(MAX),
EmailNotifications VARCHAR(50),
PaperlessNotifications VARCHAR(50),
Gender VARCHAR(50)
)

DECLARE @GroupDetails TABLE
(
id INT IDENTITY(1,1),
PlanID INT NULL,
PlanName VARCHAR(MAX),
PlanType VARCHAR(MAX),
GroupType VARCHAR(MAX),
EffectiveDate VARCHAR(50),
RenewalDate VARCHAR(50),
EmailNotifications VARCHAR(50),
PaperlessNotifications VARCHAR(50),
GroupID VARCHAR(50),
GroupName VARCHAR(MAX)
)

DECLARE @MemberDetails TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(MAX),
PlanID VARCHAR(MAX),
MemberID VARCHAR(MAX),
GroupName VARCHAR(MAX),
GroupType VARCHAR(MAX),
FullName VARCHAR(MAX),
Type VARCHAR(MAX),
DOB VARCHAR(50),
EffectiveDate VARCHAR(50),
TerminationDate VARCHAR(50),
FacilityName VARCHAR(100),
FacilityID INT,
Gender VARCHAR(50),
Address VARCHAR(MAX),
Phone VARCHAR(50)
)
DECLARE @GroupName VARCHAR(MAX)
DECLARE @GroupType VARCHAR(MAX)
INSERT INTO @SubscriberSummary(SubscriberID,Name,Address,Phone,Email,EmailNotifications,PaperlessNotifications,Gender)

SELECT mem.member_id,RTRIM(mem.last_name) +' '+RTRIM(mem.first_name) as name
,RTRIM(ISNULL(addr.addr1,'')) +''+ RTRIM(ISNULL(addr.addr2,'')) +',' +RTRIM(ISNULL(addr.city,'')) + ','+RTRIM(ISNULL(addr.county,'')) +' , '+RTRIM(ISNULL(addr.country,'')) +' , '+RTRIM(Isnull(addr.[state],'')) +' '+RTRIM(isnull(addr.zip,'')) as addresss,
isnull(ph.home_phone,''),ph.email, addr.mail, mem.paperless,mbrcode.gender
FROM member_sec mem inner join address_sec addr ON addr.sys_rec_id=mem.member_id
join mbr_phone_sec ph ON ph.address_id=addr.address_id
JOIN mbr_code_sec mbrcode ON mem.member_code=mbrcode.mbr_code
WHERE mem.member_id=@MemberID and addr.addr_type='L' and addr.subsys_code='MB'


INSERT INTO @GroupDetails(PlanID,PlanName,PlanType,GroupType,EffectiveDate,RenewalDate,EmailNotifications,PaperlessNotifications,GroupID,GroupName)

SELECT distinct top 1 tbl_plan.plan_id,RTRIM(tbl_plan.plan_name),tbl_plan.ins_type as plan_type,grp.group_type,
convert(nvarchar(MAX),  tbl_status.eff_date, 101),
convert(nvarchar(MAX),  tbl_renewal.renewal_date, 101),
'YES',
'NO',
grp.group_id,grp.group_name
FROM group_sec grp 
JOIN rel_gppl_sec rgroupplan ON rgroupplan.group_id =grp.group_id
JOIN  plan_sec tbl_plan ON tbl_plan.plan_id =rgroupplan.plan_id 
JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id 
JOIN contact_sec tbl_contact  ON grp.group_id = tbl_contact.sys_rec_id  
JOIN group_status_sec tbl_status ON tbl_status.group_id = tbl_address.sys_rec_id 
--JOIN group_rules tbl_group_rules ON tbl_group_rules.group_id=grp.group_id 
JOIN group_renewal_sec tbl_renewal ON tbl_renewal.group_id=grp.group_id
JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type
WHERE tbl_address.subsys_code = 'GP'AND tbl_address.addr_type ='L' AND grp.group_id =@GroupID 
AND tbl_plan.plan_id =@PlanID AND typ.subsys_code='PL' AND typ.tab_name='ins_type'
AND  tbl_contact.subsys_code='GP'

SELECT @GroupName=GroupName,@GroupType=GroupType FROM @GroupDetails

INSERT INTO @MemberDetails(GroupID,PlanID,MemberID,GroupName,GroupType,FullName,Type,DOB,EffectiveDate,TerminationDate,FacilityName,FacilityID,Gender,Address,Phone)

SELECT @GroupID,@PlanID,mem_b.member_id,@GroupName,@GroupType,RTRIM(mem_b.last_name) +' '+RTRIM(mem_b.first_name) AS name, mc.mbr_code_desc,
convert(nvarchar(MAX),  mem_b.date_of_birth, 101),
convert(nvarchar(MAX),  rel.eff_date, 101),
convert(nvarchar(MAX),  rel.exp_date, 101),
fac.fc_name,fac.fc_id,mc.gender,
RTRIM(ISNULL(addr.addr1,'')) +''+ RTRIM(ISNULL(addr.addr2,'')) +',' +RTRIM(ISNULL(addr.city,'')) + ','+RTRIM(ISNULL(addr.county,'')) +' , '+RTRIM(ISNULL(addr.country,'')) +' , '+RTRIM(Isnull(addr.[state],'')) +' '+RTRIM(isnull(addr.zip,'')) as addresss
,fac.emergency_phone
from member_sec mem_a inner join member_sec mem_b on mem_a.member_id=mem_b.family_id
join rlplfc_sec rel on rel.member_id=mem_b.member_id
join rlmbgrpl_sec rlg on rlg.mb_gr_pl_id=rel.mb_gr_pl_id
join facility_sec fac on fac.fc_id=rel.facility_id
join mbr_code_sec mc on mc.mbr_code=mem_b.member_code 
join address_sec addr on addr.sys_rec_id=fac.fc_id 
where mem_a.member_id=@MemberID and rlg.group_id=@GroupID and rlg.plan_id=@PlanID

SELECT * FROM @SubscriberSummary

SELECT * FROM @GroupDetails

SELECT * FROM @GroupDetails

SELECT * FROM @MemberDetails

SET NOCOUNT OFF 
END