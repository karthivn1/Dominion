﻿CREATE PROCEDURE [dbo].[usp_GroupInviteListReport]
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @GroupInviteList TABLE
(
id INT IDENTITY(1,1),
LastName VARCHAR(MAX),
FirstName VARCHAR(max),
Email VARCHAR(max),
InviteCode VARCHAR(max),
Zip VARCHAR(max),
Sent VARCHAR(max),
UserName VARCHAR(max)
)

INSERT INTO @GroupInviteList(LastName ,FirstName ,Email ,InviteCode ,Zip ,Sent,UserName)

select gud.last_name,gud.first_name,gud.email,icd.invitecode,gud.group_zip,'Sent',gud.user_name 
from group_user_details gud 
JOIN invitecode_details icd ON gud.email=icd.email collate SQL_Latin1_General_CP1_CS_AS

SELECT * FROM @GroupInviteList

SET NOCOUNT OFF 
END