﻿
--exec usp_mem_AnnualCouponRunProcess
CREATE PROCEDURE [dbo].[usp_mem_AnnualCouponRunProcess]
as
begin
Declare @Temp table(id int identity, NoOfDays smallint, Terminate smallint, LetterID int)
insert into @Temp
SELECT annual_proc_parm.no_of_days as 'NoOfDaysBefore',   
         annual_proc_parm.term_group as 'Terminate',  
         annual_proc_parm.letter_id as 'LetterID'
    FROM annual_proc_parm  
ORDER BY annual_proc_parm.no_of_days DESC 


Declare @min int=1, @max int=(select count(*) from @Temp)
while(@min<=@max)
begin
Declare  @NoOfday smallint, @Terminate smallint, @LetterId int, @nextDate datetime=getdate()
set @NoOfday=(select NoOfDays from @Temp where id=@min)
set @Terminate=(select Terminate from @Temp where id=@min)
set @LetterId=(select LetterID from @Temp where id=@min)
set @nextDate=DATEADD(DAY,@NoOfday,@nextDate)
set @nextDate=DATEADD(MONTH,1,@nextDate)
set @nextDate=DATEADD(dd,-(DAY(@nextDate)-1),@nextDate)
--select @nextDate
--exec [dbo].[annual_proc_1] @nextDate,@NoOfday,  @Terminate,@LetterId
--exec [dbo].[annual_proc_2] @nextDate,@NoOfday,  @Terminate,@LetterId

set @min=@min+1

end
SELECT group_id as 'GroupID',error_msg as 'Message',days_b4 as 'NoOfdays' from annual_proc_err
end