﻿

-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <16-01-2017>
-- Description:	<This sp gets the Change facility details by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetChangeFacilityDetailsByMemberAndGroupId]
(
@memberId INT,
@groupId INT
)
AS
BEGIN
SET NOCOUNT ON;

  DECLARE @MemberGroupPlanId INT;
  DECLARE @RateCode VARCHAR(2);

  SELECT rlmbgrpl.plan_id AS PlanId,   
         rlmbgrpl.member_id AS MemberId,   
         rlmbgrpl.group_id AS GroupId,         
         rlmbgrpl.eff_gr_pl AS EffectiveGroupPlan,   
         rlmbgrpl.exp_gr_pl AS ExpireGroupPlan,   
         rlmbgrpl.action_code AS GroupPlanActionCode,   
         rlmbgrpl.h_datetime AS HDateTime,   
         rlmbgrpl.h_msi AS HMSI,   
         rlmbgrpl.h_action AS HAction,   
         rlmbgrpl.h_user AS HUser,   
         rlmbgrpl.mb_gr_pl_id AS MemGroupPlanId,   
         rlmbrt.rate_code AS RateCode,   
         rlmbrt.action_code AS RateActionCode,   
         rlmbrt.eff_rt_date AS EffectiveRateDate,   
         rlmbrt.exp_rt_date AS ExpireRateDate,   
         [plan].plan_name AS PlanName,   
         rlmbrt.rlmbrt_id AS RelMemRateId,   
         ins_opt.ins_opt AS InsOption,
         [plan].tiered_sw AS PlanTiered,
		 (SELECT num_facil FROM pl_rat WHERE rate_code=rlmbrt.rate_code) AS FacPerFamily
		 ,ROW_NUMBER() OVER(ORDER BY rlmbgrpl.exp_gr_pl ASC) AS RowNumber 
    INTO #ChangeFacilityTemp
    FROM rlmbgrpl 
	     INNER JOIN rlmbrt ON rlmbgrpl.mb_gr_pl_id = rlmbrt.mb_gr_pl_id
         INNER JOIN [plan] ON rlmbgrpl.plan_id = [plan].plan_id
         INNER JOIN ins_opt ON [plan].ins_opt = ins_opt.ins_opt
   WHERE rlmbgrpl.member_id = @memberId AND rlmbgrpl.group_id = @groupId
		 AND rlmbgrpl.exp_gr_pl IS NULL AND rlmbrt.exp_rt_date IS NULL

   SELECT * FROM #ChangeFacilityTemp ORDER BY RowNumber ASC
	
   SET @MemberGroupPlanId= (SELECT MemGroupPlanId FROM #ChangeFacilityTemp WHERE RowNumber=1)   

   SET @RateCode=(SELECT RateCode FROM #ChangeFacilityTemp WHERE RowNumber=1)

	--Facility Member details
	EXEC usp_mem_GetChangeFacilityMemberDetailsByMemberGroupPlanId @MemberGroupPlanId,@RateCode
	
	DROP TABLE #ChangeFacilityTemp


SET NOCOUNT OFF
END