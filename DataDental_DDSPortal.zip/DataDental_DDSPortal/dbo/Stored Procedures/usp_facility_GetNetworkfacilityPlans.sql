﻿


-- =============================================
-- Author:		<Srinivasan D>
-- Create date: <27-Sep-2016>
-- Description:	<This stored procedure is used to get Network facility Plan Details>
-- =============================================
--EXEC  [usp_GetNetworkfacilityPlans] 172, 'Y'

CREATE PROCEDURE [dbo].[usp_facility_GetNetworkfacilityPlans]
(
@facilityId INT,
@History varchar
)
AS

if (@History ='N')
BEGIN
SET NOCOUNT ON

SELECT network.net_id AS 'NetworkId',   
         net_facility.fc_id,   
         net_facility.con_type AS Contract,   
         net_plans.plan_id AS PlanID,   
         net_plans.eff_date AS 'EffectiveDate',   
         net_plans.exp_date AS ExpirationDate,   
         network.name AS 'NetworkName',   
         fc_contract_types.descr,   
         fc_plans.eff_date AS EffDate,   
         fc_plans.exp_date AS ExpDate,   
         net_facility.eff_date,   
         net_facility.exp_date,   
		 Case
			When fc_plans.eff_date = null
			Then null
			Else '***' End
		 AS 'Override',
         (Select plan_dsp_name from [plan] where plan_id = net_plans.plan_id) AS PlanName 
    FROM net_facility LEFT OUTER JOIN fc_plans ON net_facility.net_fc_id = fc_plans.net_facility,   
         network,   
         fc_contract_types,   
         net_plans  
   WHERE ( network.net_id = net_plans.fc_net_id ) AND  			
         ( net_facility.net_id = network.net_id ) AND  
         ( net_facility.con_type = fc_contract_types.con_type ) AND  
         ( net_plans.plan_id = fc_plans.plan_id ) AND  
         ( net_facility.con_type = net_plans.con_type ) AND  
         ( net_facility.ovr_ride = fc_plans.ovr_ride ) AND  
         (net_facility.fc_id = @facilityId AND  
         net_facility.con_type <> 'S') AND  
         fc_plans.ovr_ride = 'Y' 
		 AND 
		 ((net_plans.eff_date <= Getdate() AND 
		 (net_plans.exp_date > Getdate()  OR net_plans.exp_date IS NULL))
		 OR 
		  (net_plans.eff_date > Getdate() AND 
		  (net_plans.exp_date > Getdate()  OR net_plans.exp_date IS NULL))) 
		
		


SELECT net_facility.net_id AS 'NetworkId',   
         network.name AS 'NetworkName',   
         fc_contract_types.descr,   
         net_facility.fc_id,   
         net_facility.con_type AS 'Contract',   
         net_plans.prov_type AS 'speciality',   
         net_plans.eff_date AS 'EffectiveDate',   
         net_plans.exp_date AS 'ExpirationDate',  
		 Case
			When fc_plans.eff_date = null
			Then null
			Else '***' End
		 AS 'Override', 
         fc_plans.eff_date AS 'EffDate',   
         fc_plans.exp_date AS 'ExpDate',   
         net_facility.eff_date,   
         net_facility.exp_date  
    FROM net_facility LEFT OUTER JOIN fc_plans ON net_facility.net_fc_id = fc_plans.net_facility,   
         network,   
         fc_contract_types,   
         net_plans  
   WHERE ( net_facility.net_id = network.net_id ) AND 		
         ( net_facility.con_type = fc_contract_types.con_type ) AND  
         ( network.net_id = net_plans.fc_net_id ) AND  
         ( net_facility.con_type = net_plans.con_type ) AND  
         ( net_plans.prov_type = fc_plans.prov_type ) AND  
         ( net_facility.ovr_ride = fc_plans.ovr_ride ) AND  
         (net_facility.fc_id = @facilityId AND  
         net_facility.con_type = 'S') AND  
         fc_plans.ovr_ride = 'Y' 
		 AND
		 ((net_plans.eff_date <= Getdate() AND 
		 (net_plans.exp_date > Getdate()  OR net_plans.exp_date IS NULL))
		 OR 
		  (net_plans.eff_date > Getdate() AND 
		(net_plans.exp_date > Getdate()  OR net_plans.exp_date IS NULL))) 
		
		 

SET NOCOUNT OFF
END

Else 

if (@History ='Y')
BEGIN
SET NOCOUNT ON
SELECT network.net_id AS 'NetworkId',   
         net_facility.fc_id,   
         net_facility.con_type AS Contract,   
         net_plans.plan_id AS PlanID,   
         net_plans.eff_date AS 'EffectiveDate',   
         net_plans.exp_date AS ExpirationDate,   
         network.name AS 'NetworkName',   
         fc_contract_types.descr,   
         fc_plans.eff_date AS EffDate,   
         fc_plans.exp_date AS ExpDate,   
         net_facility.eff_date,   
         net_facility.exp_date,   
		 Case
			When fc_plans.eff_date = null
			Then null
			Else '***' End
		 AS 'Override',
         (Select plan_dsp_name from [plan] where plan_id = net_plans.plan_id) AS PlanName 
    FROM net_facility LEFT OUTER JOIN fc_plans ON net_facility.net_fc_id = fc_plans.net_facility,  
       network,   
         fc_contract_types,   
         net_plans  
    WHERE ( network.net_id = net_plans.fc_net_id ) and  
         ( net_facility.net_id = network.net_id ) and  
         ( net_facility.con_type = fc_contract_types.con_type ) and  
         ( net_plans.plan_id = fc_plans.plan_id ) and  
         ( net_facility.con_type = net_plans.con_type ) and  
         ( net_facility.ovr_ride = fc_plans.ovr_ride ) and  
         (net_facility.fc_id = @facilityId AND  
         net_facility.con_type <> 'S') AND  
         fc_plans.ovr_ride = 'Y'   
		 
		 
		 SELECT net_facility.net_id AS 'NetworkId',   
         network.name AS 'NetworkName',   
         fc_contract_types.descr,   
         net_facility.fc_id,   
         net_facility.con_type AS 'Contract',   
         net_plans.prov_type AS 'speciality',   
         net_plans.eff_date AS 'EffectiveDate',   
         net_plans.exp_date AS 'ExpirationDate',  
		 Case
			When fc_plans.eff_date = null
			Then null
			Else '***' End
		 AS 'Override', 
         fc_plans.eff_date AS 'EffDate',   
         fc_plans.exp_date AS 'ExpDate',   
         net_facility.eff_date,   
         net_facility.exp_date  
    FROM net_facility LEFT OUTER JOIN fc_plans ON net_facility.net_fc_id = fc_plans.net_facility,   
         network,   
         fc_contract_types,   
         net_plans  
   WHERE ( net_facility.net_id = network.net_id ) and  
         ( net_facility.con_type = fc_contract_types.con_type ) and  
         ( network.net_id = net_plans.fc_net_id ) and  
         ( net_facility.con_type = net_plans.con_type ) and  
         ( net_plans.prov_type = fc_plans.prov_type ) and  
         ( net_facility.ovr_ride = fc_plans.ovr_ride ) and  
         (net_facility.fc_id = @facilityId AND  
         net_facility.con_type = 'S') AND  
         fc_plans.ovr_ride = 'Y' 

SET NOCOUNT OFF	 
END