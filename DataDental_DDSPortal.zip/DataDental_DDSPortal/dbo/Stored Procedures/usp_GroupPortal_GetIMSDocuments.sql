﻿CREATE PROCEDURE [dbo].[usp_GroupPortal_GetIMSDocuments]
(
@groupid varchar(25)
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @IMSDocuments TABLE
(
id INT IDENTITY(1,1),
DocID VARCHAR(MAX),
DocType VARCHAR(MAX),
DocDate VARCHAR(MAX),
GroupID VARCHAR(MAX),
IsNew VARCHAR(MAX)
)

INSERT INTO @IMSDocuments(DocID ,DocType ,DocDate ,GroupID ,IsNew)

select doc_id,doc_type,convert(nvarchar(MAX),doc_date, 101),group_id,isNew from group_ims_doc
where group_id=@groupid and doc_date between Cast(dateadd(yy,-2,getdate()) as date) and Cast(getdate() as date)
order by doc_date desc

SELECT * FROM @IMSDocuments order by cast(DocDate as date) desc

SET NOCOUNT OFF 
END