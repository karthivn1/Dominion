﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <23-11-2016>
-- Description:	<This sp gets the Member Designation Details by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberDesignationDetails]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;
	DECLARE @designId INT
	
	--Designation List
	SELECT mb_desig.dd_desig_id AS MemberDesignId,
		mb_desig.subsys_code,
		mb_desig.sys_rec_id,
		mb_desig.desig_id ,
		mb_desig.eff_date AS EffDate,
		mb_desig.exp_date AS ExpDate,
		mb_desig.h_user AS "User",
		mb_desig.h_datetime AS "Date",
		mb_desig.reserved,
		desig.desig_name AS Designation,
		desig.descr,
		desig_type.type_descr AS "Type",
		desig.desig_type_id
	FROM mb_desig
	INNER JOIN desig ON desig.desig_id=mb_desig.desig_id
	INNER JOIN desig_type ON desig_type.desig_type_id=desig.desig_type_id
	WHERE mb_desig.sys_rec_id=@memberId AND mb_desig.subsys_code='MB' ORDER BY mb_desig.eff_date ASC

--********************************************************************

	SET @designId=(SELECT TOP 1 mb_desig.dd_desig_id
				FROM mb_desig				
				WHERE mb_desig.sys_rec_id=@memberId ORDER BY mb_desig.eff_date ASC)


--Designation Value
	SELECT mb_desig_det.desig_det_id AS MemberDesignValueId,
		mb_desig_det.dd_desig_id,
		mb_desig_det.desig_value AS Designation,
		mb_desig_det.eff_date AS EffDate,
		mb_desig_det.exp_date AS ExpDate,
		mb_desig_det.h_user AS "User",
		mb_desig_det.h_datetime AS "Date"
	FROM mb_desig
	INNER JOIN mb_desig_det ON mb_desig.dd_desig_id=mb_desig_det.dd_desig_id
	WHERE mb_desig.dd_desig_id=@designId
  

SET NOCOUNT OFF
END