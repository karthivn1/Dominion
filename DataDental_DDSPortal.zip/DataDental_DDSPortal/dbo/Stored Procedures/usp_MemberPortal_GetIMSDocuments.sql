﻿CREATE PROCEDURE [dbo].[usp_MemberPortal_GetIMSDocuments] 
(
@memberid varchar(25)
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @IMSDocuments TABLE
(
id INT IDENTITY(1,1),
DocID VARCHAR(MAX),
DocType VARCHAR(MAX),
DocDate VARCHAR(MAX),
MemberID VARCHAR(MAX),
FirstName VARCHAR(MAX),
LastName VARCHAR(MAX),
FullName VARCHAR(MAX),	
IsNew VARCHAR(MAX)
)

INSERT INTO @IMSDocuments(DocID ,DocType ,DocDate,MemberID ,FirstName,LastName,FullName,IsNew)

select im.doc_id,Replace(im.doc_type,'ID Cards','Paper ID Card and Policy Document') as doc_type,convert(nvarchar(MAX),im.doc_date, 101),im.member_id,RTRIM(ISNULL(im.firstname,'')),RTRIM(ISNULL(im.lastname,'')),RTRIM(ISNULL(im.lastname,'')) +' '+ RTRIM(ISNULL(im.firstname,'')),im.isNew 
from member_ims_doc im 
JOIN member_sec m ON im.member_id=m.member_id
where m.family_id=@memberid
AND im.doc_type<>'Renewal Notices'
and im.doc_date between Cast(dateadd(yy,-2,getdate()) as date) and Cast(getdate() as date)
order by im.doc_date desc

INSERT INTO @IMSDocuments(DocID ,DocType ,DocDate,MemberID ,FirstName,LastName,FullName,IsNew)
VALUES(0000,'Notice',NULL,@memberid,NULL,NULL,NULL,NULL)

SELECT * FROM @IMSDocuments ORDER by cast(DocDate as date) desc

SET NOCOUNT OFF 
END