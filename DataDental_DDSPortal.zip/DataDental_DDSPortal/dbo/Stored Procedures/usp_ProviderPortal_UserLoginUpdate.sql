﻿CREATE proc [dbo].[usp_ProviderPortal_UserLoginUpdate] (
@username varchar(20),
@portalType varchar(20)
)
as
Begin

Declare @roleid int = CASE @portalType WHEN 'Dominion' THEN (select role_id from role_master where role_name ='Dominion Provider')
WHEN 'CBC' THEN (select role_id from role_master where role_name ='CBC Provider')
ELSE
(select role_id from role_master where portal_type='pvr' and role_name ='Premera Provider')
END
IF EXISTS(select * from provider_user_details where user_name=@username and role_id=(select role_id from role_master where portal_type='pvr' and role_name ='Internal Admin'))
BEGIN
select @roleid=role_id from role_master where portal_type='pvr' and role_name ='Internal Admin'
END
	IF exists(select * from provider_user_details where user_name=@username)
	Begin
		if not exists(select * from provider_user_details where user_name=@username AND role_id=@roleid)
		BEGIN
		Insert into provider_user_details (user_name, email, status_id, role_id, facility_id,is_firstlogin,password_hash,facility_tax_id,facility_zip_code,last_name,password_reset_date,forgot_password_time) 
		(select top 1 user_name, email, status_id, @roleid, facility_id,is_firstlogin,password_hash,facility_tax_id,facility_zip_code,last_name,password_reset_date,forgot_password_time from provider_user_details where user_name=@username)
		END		
	End 		
	SELECT user_id Id,role_id UserRoleId,is_firstlogin ISFirstLogin,facility_id Facility_ID,facility_tax_id Tax_ID,facility_zip_code Zip from provider_user_details where user_name=@username AND role_id=@roleid
End