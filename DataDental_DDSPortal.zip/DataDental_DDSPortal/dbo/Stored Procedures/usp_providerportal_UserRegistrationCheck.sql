﻿
CREATE procedure [dbo].[usp_providerportal_UserRegistrationCheck] 
(@taxid Varchar(max) ,
@lastname varchar(max)  ,
@zip varchar(max)
 )
AS
Begin
SET NOCOUNT ON 
Declare @verificationMessage varchar(max);

DECLARE @facilityID int =null


If Exists (select fc_tax_id  from facility_sec where fc_tax_id =@taxid )
Begin

	--select @facilityID =fac.fc_id from facility_sec fac
	--LEFT JOIN fcstat_sec fcstatus (NOLOCK)
	--		ON fcstatus.fc_stat_id = (SELECT MAX(fc_stat_id) FROM fcstat_sec (NOLOCK) WHERE facility_id = fac.fc_id)
	--LEFT OUTER join typ_table_sec fctype (NOLOCK)
	--		ON fctype.code = fcstatus.status AND fctype.subsys_code='FC' AND fctype.tab_name='fcstat' 
	--where fac.fc_tax_id = @taxid  and fcstatus.status='AC'


	If Exists(select 1
 FROM facility_sec, fc_assoc_sec,   
         providers_sec,   
         pv_status_sec  ,
		 [address_sec] addr
   WHERE ( fc_assoc_sec.pv_id = providers_sec.pv_id ) and  
         ( providers_sec.pv_id = pv_status_sec.pv_id ) and  
          (facility_sec.fc_id = fc_assoc_sec.fc_id ) and
         ( pv_status_sec.exp_date is null )  and (facility_sec.fc_tax_id = @taxid)
		 and Lower(RTRIM (providers_sec.last_name)) = Lower(@lastname)
		 and addr.sys_rec_id=facility_sec.fc_id and addr.subsys_code ='FC'
		 and addr.zip=@zip  and facility_sec.fc_id IN(SELECT  fac.fc_id from facility_sec fac
			LEFT JOIN fcstat_sec fcstatus (NOLOCK)
				ON fcstatus.fc_stat_id = (SELECT MAX(fc_stat_id) FROM fcstat_sec (NOLOCK) WHERE facility_id = fac.fc_id)
			LEFT OUTER join typ_table_sec fctype (NOLOCK)
				ON fctype.code = fcstatus.status AND fctype.subsys_code='FC' AND fctype.tab_name='fcstat' 
			where fac.fc_tax_id = @taxid  and fcstatus.status='AC'))



	--If Exists (select pro.tax_id from providers_sec pro inner join facility_sec fc on pro.tax_id=fc.fc_tax_id inner join [address_sec] addr on addr.sys_rec_id=fc.fc_id
	--where pro.tax_id=@taxid
	--and Lower(RTRIM (pro.last_name)) = Lower(@lastname)
	--and addr.zip=@zip
	--)
		Begin
		
			If Exists(select *from provider_user_details where facility_tax_id=@taxid and Lower( RTRIM (last_name))=Lower(@lastname) and facility_zip_code=@zip)
			Begin
			      set @verificationMessage ='An account for this facility already exists. If you do not remember your login information, please contact customer support.';
			 End
			Else
			Begin
			      set @verificationMessage ='Success'; 
			End
		End
		Else
		Begin
		 set @verificationMessage ='Unable to verify facility information entered, please contact customer support for further assistance.';
		End
End
Else
Begin
   set @verificationMessage ='Unable to verify facility Tax ID entered';
End
select  @verificationMessage as Message
End

SET NOCOUNT OFF