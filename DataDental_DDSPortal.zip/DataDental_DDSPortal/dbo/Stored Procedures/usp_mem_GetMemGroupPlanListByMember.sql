﻿




-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <17-02-2017>
-- Description:	<This sp gets the List of  Member Group Plan based on member by passing memberId >
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemGroupPlanListByMember] --2411814,65402
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;
		
	SELECT rlmbgrpl.mb_gr_pl_id AS MemGrpPlnId,   
		   rlmbgrpl.member_id,   
		   rlmbgrpl.group_id AS GroupId,   
		   rlmbgrpl.plan_id AS PlanID,          
		   rlmbgrpl.eff_gr_pl AS PlanEffective,   
		   rlmbgrpl.exp_gr_pl AS PlanExpired,   
		   LTRIM(RTRIM(rlmbgrpl.action_code)) AS PlanAction
		           
    FROM rlmbgrpl

   WHERE rlmbgrpl.member_id = @memberId

SET NOCOUNT OFF
END