﻿



-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <18-10-2016>
-- Description:	<This sp gets the Facility details for member by passing memberId,group Id and plan Id>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberPlanAndFacilityByMemberGroup] 
(
@memberId INT,
@MemGroupPlanId INT
)
AS
BEGIN
SET NOCOUNT ON;

	
--Plan Details
	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.ins_opt AS InsOptionType,
		LTRIM(RTRIM((typePl.descr))) +' '+ insOpt.ins_opt_sd AS TypeorOption,
		tblPlan.plan_dsp_name AS PlanName,
		tblPlan.tiered_sw AS Tiered,		
		rlMebGroupPlan.eff_gr_pl AS PlanEffective,
		rlMebGroupPlan.exp_gr_pl AS PlanExpired,
		LTRIM(RTRIM(typeMb.descr)) AS PlanAction,
		rlMebGroupPlan.h_datetime AS ByDate,
		rlMebGroupPlan.h_user AS [By],
		--rlMebGroupPlan.action_code AS PlanAction,
		planRate.rate_short_desc AS Rate,
		(select count(*) from sgp_pend where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id and cancel_datetime is null) AS Pended,
		(select sgp_elig_name from sgp_elig_name where mb_gr_pl_id = rlMebGroupPlan.mb_gr_pl_id) AS EligName,
		rlMebGroupPlan.sub_in_plan AS SubinPlane,
		rlMebRate.eff_rt_date AS RateEffective,
		rlMebRate.exp_rt_date AS RateExpired,
		(typeRT.descr) AS RateAction,
		rlMebRate.h_datetime AS RateCreatedDate,
		rlMebRate.h_user AS RateCreatedBy
		
	from [plan] tblPlan
	INNER JOIN ins_opt insOpt ON insOpt.ins_opt=tblPlan.ins_opt
	LEFT JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	LEFT JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	LEFT JOIN pl_rat planRate ON planRate.rate_code=rlMebRate.rate_code
	LEFT JOIN typ_table typePl ON typePl.subsys_code='PL' AND typePl.tab_name='ins_type' AND typePl.code=tblPlan.ins_type
	LEFT JOIN typ_table typeMb ON typeMb.subsys_code='MB' AND typeMb.tab_name='action_code' AND typeMb.code=rlMebGroupPlan.action_code
	LEFT JOIN typ_table typeRT ON typeRT.subsys_code='MB' AND typeRT.tab_name='action_code' AND typeRT.code=rlMebRate.action_code
	WHERE  rlMebGroupPlan.mb_gr_pl_id=@MemGroupPlanId --tblPlan.plan_id=@planId AND rlMebGroupPlan.member_id=@memberId AND rlMebGroupPlan.group_id=@groupId 
	AND rlMebRate.exp_rt_date IS NULL 

	--Facility Details
	EXEC [usp_mem_GetMemberFacilityByMemberGroupPlanId] @memberId,@MemGroupPlanId	

	--Address Details
	EXEC [usp_mem_GetAddressForMember] @memberId


SET NOCOUNT OFF;
END