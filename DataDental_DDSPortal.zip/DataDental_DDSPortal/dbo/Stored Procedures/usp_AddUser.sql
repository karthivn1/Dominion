﻿CREATE PROC [dbo].[usp_AddUser] 
(
@username AS VARCHAR(MAX),
@firstname AS VARCHAR(MAX),
@lastname AS VARCHAR(MAX),
@middleinitial AS VARCHAR(MAX)= NULL,
@phone AS VARCHAR(MAX)= NULL,
@email AS VARCHAR(MAX),
@emailnotification AS BIT,
@roleid AS INT,
@hashpassword AS VARCHAR(MAX),
@value AS VARCHAR(MAX),
@GroupUserMapping dbo.[GroupUserDetailsMapping] READONLY
)
AS
BEGIN
SET NOCOUNT ON 
BEGIN TRANSACTION [adduser]

BEGIN TRY
DECLARE @userId INT; 
DECLARE @ct DATETIME=GETDATE();
DECLARE @errorGroup VARCHAR(MAX)=NULL;

DECLARE @newGroupInfo AS Table
(
id int identity(1,1),
group_id int null,
email varchar(300) null
)

IF @value = 'ADD'
BEGIN

		IF EXISTS(SELECT user_name FROM group_user_details WHERE user_name =@username)
		BEGIN
			SELECT 'Duplicate User' AS result
		END
		ELSE
	     BEGIN	
		 
			INSERT INTO group_user_details(user_name,first_name,last_name,middle_name,phone,email,email_notification,role_id,temp_password,status_id) 
			VALUES(@username,@firstname,@lastname,@middleinitial,@phone,@email,@emailnotification,@roleid,@hashpassword,4)
			SET @userId=SCOPE_IDENTITY();
		
			INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
			VALUES (@userId,1,1001,0,@ct);

			IF NOT EXISTS(SELECT *
							FROM flatfile_details f
							WHERE f.email=@email)
			BEGIN
				INSERT INTO flatfile_details(last_name,
				group_zip,
				email,
				created_date,
				is_invitecode_processed,
				invitecode_processed_date,
				con_type,
				h_user)
				VALUES(@lastname,null,@email,@ct,1,@ct,IIF(@roleid=7,'P','A'),@username)
			END

			SELECT user_name FROM group_user_details WHERE user_id=@userId

		 END
 END
  ELSE
  IF @value <> 'ADD'
  BEGIN
   IF EXISTS(select user_name from group_user_details where user_name =@username)
   BEGIN
   
    UPDATE group_user_details SET email =@email WHERE user_name =@username
  	
	IF NOT EXISTS(SELECT *
							FROM flatfile_details f
							WHERE f.email=@email)
			BEGIN
				INSERT INTO flatfile_details(last_name,
				group_zip,
				email,
				created_date,
				is_invitecode_processed,
				invitecode_processed_date,
				--con_type,
				h_user)
				SELECT g.last_name,g.group_zip,@email,@ct,1,@ct,g.user_name
				FROM group_user_details g WHERE user_name =@username

			END

	SELECT user_name FROM group_user_details WHERE user_name =@username

	END
  END
  
DECLARE @user VARCHAR(100)
SET @user=(SELECT TOP 1 username FROM @GroupUserMapping)
SET @userId= (SELECT user_id FROM group_user_details WHERE user_name = @username)

		INSERT INTO @newGroupInfo(group_id,email)
			SELECT g.groupid,@email FROM @GroupUserMapping g 
			WHERE g.status='New'
			--EXCEPT
			--SELECT c.sys_rec_id,c.email 
			--	FROM contact_sec c 
			--	WHERE c.subsys_code='GP' AND c.con_type <>'P'

			IF EXISTS(SELECT id FROM @newGroupInfo)
			BEGIN
				
				DECLARE @iCount INT=1;
				DECLARE @RecCount INT=0;

				SELECT @RecCount=COUNT(id) FROM @newGroupInfo
				WHILE(@RecCount>=@iCount)
				BEGIN
				    
					DECLARE @con_type varchar(2)=null;
					DECLARE @group INT;
					SELECT @group=group_id FROM @newGroupInfo n WHERE n.id=@iCount

					IF @roleid=3
					BEGIN
					SELECT code
						INTO #tempCode1
							FROM [typ_table_sec]
							WHERE subsys_code='GP' AND tab_name='contact'
							AND code NOT IN ('A','P','GC')
						EXCEPT
						SELECT c.con_type
							FROM contact_sec c
							JOIN @newGroupInfo n on n.group_id=c.sys_rec_id
							WHERE c.subsys_code='GP' AND n.id=@iCount
							AND c.con_type NOT IN ('A','P','GC')

						SELECT TOP 1 @con_type=code FROM #tempCode1

						IF LEN(@con_type)=0
							SET @errorGroup=@errorGroup + ',' + CAST(@group AS varchar)

						
						--ELSE
						--	INSERT INTO contact_sec(subsys_code,sys_rec_id,con_type,fname,lname,phone1,addr_type,email)
						--	SELECT 'GP',g.groupid,@con_type,@firstname,@lastname,@phone,'L',@email 
						--	FROM @GroupUserMapping g
						--	JOIN @newGroupInfo n ON n.group_id=g.groupid 
						--	WHERE n.id=@iCount
						

				END
				--ELSE IF @roleid=7  -- Producer Role = 7
				--BEGIN
					
				--IF EXISTS(SELECT c.contact_id
				--			FROM contact_sec c
				--			JOIN @newGroupInfo n ON n.group_id=c.sys_rec_id
				--			WHERE c.subsys_code='GP'
				--			AND c.con_type ='P' AND n.id=@iCount)
				--			BEGIN
				--				--SELECT c.contact_id
				--				UPDATE c SET c.fname=@firstname,c.lname=@lastname,c.phone1=@phone,c.email=@email
				--					FROM contact_sec c
				--					JOIN @newGroupInfo n ON n.group_id=c.sys_rec_id
				--					JOIN @GroupUserMapping g ON g.groupid=n.group_id
				--					WHERE c.subsys_code='GP'
				--					AND c.con_type ='P' AND n.id=@iCount

				--			END
				--			ELSE
				--				BEGIN
				--					INSERT INTO contact_sec(subsys_code,sys_rec_id,con_type,fname,lname,phone1,addr_type,email)
				--					SELECT 'GP',g.groupid,'P',@firstname,@lastname,@phone,'L',@email 
				--					FROM @GroupUserMapping g
				--					JOIN @newGroupInfo n ON n.group_id=g.groupid
				--					WHERE n.id=@iCount
				--				END
				--END
				ELSE 
				BEGIN

					IF @roleid<>7
					BEGIN
						IF EXISTS(SELECT c.con_type
								FROM contact_sec c
								JOIN @newGroupInfo n on n.group_id=c.sys_rec_id
								WHERE c.subsys_code='GP'
								AND c.con_type<>'P' AND n.id=@iCount)
																			BEGIN

						SELECT code
							INTO #tempCode
							FROM [typ_table_sec]
							WHERE subsys_code='GP' AND tab_name='contact'
							AND code<>'P'
						EXCEPT
						SELECT c.con_type
							FROM contact_sec c
							JOIN @newGroupInfo n on n.group_id=c.sys_rec_id
							WHERE c.subsys_code='GP'
							AND c.con_type<>'P' AND n.id=@iCount

						SELECT TOP 1 @con_type=code FROM #tempCode

					END
						ELSE
						 SET @con_type='A'

					
						IF LEN(@con_type)=0
								SET @errorGroup=@errorGroup + ',' + CAST(@group AS varchar)

						--INSERT INTO contact_sec(subsys_code,sys_rec_id,con_type,fname,lname,phone1,addr_type,email)
						--SELECT 'GP',g.groupid,@con_type,@firstname,@lastname,@phone,'L',@email 
						--	FROM @GroupUserMapping g
						--	JOIN @newGroupInfo n ON n.group_id=g.groupid
						--	WHERE n.id=@iCount
					END
				END	
				 
					SET @iCount=@iCount+1
				END

			END
			
IF LEN(@errorGroup)>0
	BEGIN
		SET  @errorGroup='Remove Error Groups '+ @errorGroup;
		RAISERROR(@errorGroup ,16,1)
	END

DECLARE @adminCount INT=0;

SELECT @adminCount=COUNT(c.contact_id)
	FROM contact_sec c
	JOIN @GroupUserMapping n on n.groupid=c.sys_rec_id 
	WHERE c.subsys_code='GP' AND n.isremove=0 AND c.email=@email
	AND c.con_type='A'

IF @adminCount=1
	BEGIN
		RAISERROR('Benefits Administrator' ,16,1)
	END
	--ELSE
	--	BEGIN
	--	--SELECT c.con_type
	--	DELETE c
	--			FROM contact_sec c
	--			JOIN @GroupUserMapping n on n.groupid=c.sys_rec_id 
	--			WHERE c.subsys_code='GP' AND n.isremove=0 AND c.email=@email
	--	END

SELECT 'Success' AS result

COMMIT TRANSACTION [adduser]
END TRY
BEGIN CATCH
ROLLBACK TRANSACTION [adduser];
THROW       
END CATCH
SET NOCOUNT OFF
END