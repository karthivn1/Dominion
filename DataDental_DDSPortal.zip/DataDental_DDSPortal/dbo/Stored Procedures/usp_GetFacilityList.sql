﻿CREATE PROCEDURE [dbo].[usp_GetFacilityList]
	@taxID VARCHAR(MAX)
AS
BEGIN
	
	SET NOCOUNT ON;

    SELECT	fc.fc_id AS FacilityID,LTRIM(RTRIM(ad.addr1)) + '   ,   ' + LTRIM(RTRIM(zip)) AS FacilityAddress
		 FROM facility_sec fc
		 INNER JOIN address_sec ad ON fc.fc_id = ad.sys_rec_id AND ad.subsys_code='FC'
		 WHERE fc_tax_id = @taxID

END