﻿CREATE procedure [dbo].[usp_MemberPortal_Claimsdoc_ApiError]
(
 @username varchar(max), 
 @message varchar(max)
)
 AS
 Begin

   Begin Transaction [dds_portal]
	 Begin try
			 Declare @userid int;
			 Declare @message_id int;
			 
			 Begin
			 If exists ( select user_id from member_user_details  where user_name =@username)
			 Begin 

			 set @userid=(select user_id from member_user_details  where user_name =@username)
			 --message_type_id =3 for ApiEror System Generated reference from Message_type--
			 INSERT into member_message(message,message_type_id,created_by,created_date,message_subject,from_address)
			 values(@message,3,@userid,GETDATE(),'Member Portal API Replacement Message','Dominion National')
	         set @message_id=(SELECT SCOPE_IDENTITY());					 
		     update member_message set parentid=@message_id where message_id=@message_id
			
			 Insert into member_message_detail (message_id,message_receiver_id,received_date,is_delete,is_new,is_read,is_reply)
			 (select @message_id as message_id,user_id,GETDATE(),0,1,0,0 from dbo.member_user_details where role_id in (select role_id from role_master where role_name in  ('DDS Admin','DDS User')) )		  
			 
			
			 INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date) VALUES 
			 (@message_id,4,1001,0,CONVERT(date,GETDATE()));

			 select 'Success'
			 
			 End 
			 End
	 commit
	End try

   Begin Catch
   select 'Fail'
    rollback Transaction [adduser]
   End Catch

End