﻿-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <08-02-2017>
-- Description:	<This sp gets the Group status details by passing groupId and EffectiveDate>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetGroupStatusDetails] 
(
@groupId INT,
@effectiveDate DATETIME=NULL
)
AS
BEGIN
SET NOCOUNT ON;
	SELECT DISTINCT tblGroup.group_id AS GroupID,
			 tblGroup.group_name AS GroupName,   
			 LTRIM(RTRIM((tblGroup.group_type))) AS GroupType,   
			 LTRIM(RTRIM((groupStatus.group_status))) AS "Status"
         
		FROM [group] tblGroup 
			INNER JOIN group_status groupStatus ON groupStatus.group_id=tblGroup.group_id
			--LEFT JOIN typ_table typeGr ON typeGr.subsys_code='GP' AND typeGr.tab_name='group_type' AND typeGr.code=tblGroup.group_type
			--LEFT JOIN typ_table typeSt ON typeSt.subsys_code='GP' AND typeSt.tab_name='group_status' AND typeSt.code= groupStatus.group_status
			WHERE tblGroup.group_id=@groupId AND groupStatus.eff_date<=@effectiveDate and (groupStatus.exp_date IS NULL OR groupStatus.exp_date>@effectiveDate)
SET NOCOUNT OFF
END