﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_group_getGroupContact]
@groupId INT,
@FirstName NVARCHAR(10),
@LastName NVARCHAR(15),	
@Email NVARCHAR(250)		
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @result INT=0;
    -- Insert statements for procedure here
IF EXISTS(Select c.contact_id
	From contact_sec c
	Where c.sys_rec_id=@groupId
	AND c.fname=@FirstName
	AND c.lname=@LastName
	AND c.email=@Email
	AND c.subsys_code='GP')
BEGIN

SET @result=1;

END
RETURN @result
END