﻿-- =============================================
-- Author:		<Vetrichelvan Gnanamani>
-- Create date: <11/21/2016>
-- Description:	<To Insert or Update Group Size in Plan Support Premium Disb>
-- =============================================
CREATE PROCEDURE [dbo].[usp_Pln_SavePlanSuppDisbShemeGroupSize]
(
 @premiumId INT,
 @disbursementId INT,
 @groupSizeLb INT = NULL,
 @groupSizeUb INT = NULL,
 @percentage INT = NULL,
 @returnValue INT = NULL OUTPUT
)
AS
BEGIN	
SET NOCOUNT ON;	
BEGIN
	DECLARE @ageGroupNewLb INT
	UPDATE	pl_db_prm SET grp_size_ub = @groupSizeUb ,perc_of_prem= @percentage WHERE dsb_prm_id = @premiumId 
	SET		@premiumId = @premiumId + 1
	SET		@ageGroupNewLb = @groupSizeUb + 1
	
IF		EXISTS(SELECT dsb_prm_id FROM pl_db_prm WHERE dsb_prm_id = @premiumId)
BEGIN	
	UPDATE	pl_db_prm SET grp_size_lb = @ageGroupNewLb ,perc_of_prem= @percentage WHERE  dsb_prm_id = @premiumId
	SELECT	@returnValue = dsb_prm_id  FROM pl_db_prm WHERE dsb_prm_id = @premiumId
	SET		@returnValue=@returnValue;
	RETURN 
END
ELSE
BEGIN
	INSERT INTO pl_db_prm(grp_size_lb,perc_of_prem,dsb_scheme_id)VALUES(@ageGroupNewLb,@percentage,@disbursementId)
	SELECT @returnValue = SCOPE_IDENTITY();		
	SET	   @returnValue = @returnValue;
	RETURN 
END
END
SET NOCOUNT OFF;

END