﻿



-- =============================================
-- Author:		<Harishraj R>
-- Create date: <26-Sep-2016>
-- Description:	<This stored procedure is used to get list  of members for the given search criteria>
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_MemberSearch] --657306,'','','','','',null,null,null,null,null
(
@memberId INT=NULL,
@SSN VARCHAR (11)=NULL,
@srcID VARCHAR(20)=NULL,     
@altId VARCHAR (20)=NULL,   
@lastName VARCHAR (15)=NULL , 
@firstName VARCHAR (15)=NULL,
@idType INT=NULL,
@groupId INT=NULL,
@ocId INT=NULL,
@dob datetime=NULL,
@hireDate datetime=NULL
)
AS
BEGIN
SET NOCOUNT ON
	DECLARE @SqlQuery NVARCHAR(MAX),
	@BoolFlag CHAR(1)=NULL

	SET @BoolFlag='N'
	SET @SqlQuery='SELECT DISTINCT member.member_id AS "MemberID",   
         member.family_id AS "FamilyID",   
         member.alt_id AS "AltID",         
		 memberCode.mbr_code_desc AS "Gender",
         LTRIM(RTRIM(member.first_name)) AS "FirstName",   
         LTRIM(RTRIM(member.middle_init)) AS "MiddleIntial",   
         LTRIM(RTRIM(member.last_name)) AS "LastName",
		 ISNULL(LTRIM(RTRIM(last_name)),'''')+'' ''+ISNULL(LTRIM(RTRIM(middle_init)),'''')+'' ''+ ISNULL(LTRIM(RTRIM(first_name)),'''') AS "SubscriberName",
         member.date_of_birth AS "DOB",
		 convert(int,DATEDIFF(d, member.date_of_birth, getdate())/365.25)  AS "Age", 
         member.new_ssn AS "SSN",   
         member.oed AS "OED",   
         member.dod AS "DOD",   
         CAST(CASE WHEN member.student_flag= ''' +@BoolFlag+ ''' THEN 0 ELSE 1 END AS BIT) AS "Student",   
         CAST(CASE WHEN member.disable_flag= ''' +@BoolFlag+ ''' THEN 0 ELSE 1 END AS BIT) AS "Disabled",   
         member.action_code AS "ActionCode",   
         member.h_datetime AS "DateTime",   
         member.h_msi AS "User MSI",   
         member.h_action AS "User Action",   
         member.h_user AS "User",   
         member.hire_date AS "User Hire Date",   
         member.source_id AS "Source",
		 case 
			   when str_1=''new_ssn'' then cast(member.new_ssn as varchar) 
			   when str_1=''member_id'' then cast(member.member_id as varchar)
			   when str_1=''source_id'' then cast(member.source_id as varchar)
			   else
			   cast(member.alt_id as varchar) 
			end "ExternalID",          
         member.student_exp AS "Student Exp",
		 member.ext_id_type AS "IdType",   
         CAST(CASE WHEN member.paperless= ''' +@BoolFlag+ ''' THEN 0 ELSE 1 END AS BIT) AS "Paperless",
		 dbo.udf_member_getMemberStatus(member.family_id) as "Status"		
    FROM member (NOLOCK) member
	LEFT JOIN mbr_code (NOLOCK) memberCode ON member.member_code=memberCode.mbr_code	
	INNER JOIN typ_table_exp (NOLOCK) ON typ_table_exp.tab_name = ''ext_id_type'' and typ_table_exp.int_1=member.ext_id_type
	INNER JOIN rlmbgrpl (NOLOCK) relMemberGroupPlan	ON member.family_id=relMemberGroupPlan.member_id
	WHERE (1=1)'

	--member.member_code AS "Gender",
	--INNER JOIN mbr_code memberCode ON member.member_code=memberCode.mbr_code
	--LTRIM(RTRIM(member.first_name)) +Char(1)+ member.middle_init +Char(1)+ member.last_name AS SubscriberName,
	--relMemberGroupPlan.group_id AS "GroupID"
	--INNER JOIN rlmbgrpl relMemberGroupPlan
	--ON member.member_id=relMemberGroupPlan.member_id

	IF (@memberId IS NOT NULL AND @memberId !=0)
		SET @SqlQuery=@SqlQuery+' AND member.member_id='+ CAST(@memberId as VARCHAR)
	IF (@lastName IS NOT NULL AND @lastName !='')
		SET @SqlQuery=@SqlQuery+' AND member.last_name LIKE '''+''+@lastName+'%'+''''
	IF (@firstName IS NOT NULL AND @firstName !='')
		SET @SqlQuery=@SqlQuery+' AND member.first_name LIKE '''+''+@firstName+'%'+''''
	IF (@SSN IS NOT NULL AND @SSN !='')
		SET @SqlQuery=@SqlQuery+' AND member.new_ssn='''+@SSN+''''
	IF (@srcID IS NOT NULL AND @srcID !='')
		SET @SqlQuery=@SqlQuery+' AND member.source_id='''+@srcID+''''
	IF (@altId IS NOT NULL AND @altId !='')
		SET @SqlQuery=@SqlQuery+' AND member.alt_id='''+@altId+''''
	IF (@idType IS NOT NULL AND @idType !=0)
		SET @SqlQuery=@SqlQuery+' AND member.ext_id_type='+ CAST(@idType as VARCHAR)	
	IF (@groupId IS NOT NULL AND @groupId !='')
		SET @SqlQuery=@SqlQuery+' AND relMemberGroupPlan.group_id ='+ CAST(@groupId as VARCHAR)
	IF (@ocId IS NOT NULL AND @ocId !='')
		SET @SqlQuery=@SqlQuery+' AND relMemberGroupPlan.group_id IN (SELECT group_id FROM [dbo].[group] WHERE oc_id='+ CAST(@ocId as VARCHAR)+')'
	IF (@dob IS NOT NULL AND @dob !='')
		SET @SqlQuery=@SqlQuery+' AND member.date_of_birth='''+CAST(@dob as VARCHAR)+''''
	IF (@hireDate IS NOT NULL AND @hireDate !='')
		SET @SqlQuery=@SqlQuery+' AND member.hire_date='''+CAST(@hireDate AS VARCHAR)+''''

	print @SqlQuery
	EXECUTE sp_executesql @SqlQuery

SET NOCOUNT OFF
END