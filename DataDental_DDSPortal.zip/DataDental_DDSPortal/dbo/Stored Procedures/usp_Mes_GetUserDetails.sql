﻿CREATE procedure [dbo].[usp_Mes_GetUserDetails]
(
@lastname as Varchar(max)= NULL,
@firstname as Varchar(max)=NULL,
@username as Varchar(max)=NULL,
@email as Varchar(max)=NULL,
@role as int =null)
AS
Begin
SET NOCOUNT ON 


SELECT DISTINCT
userdetails.[user_name] as UserName, 
userdetails.last_name as LastName,
userdetails.first_name as FirstName,
tbl_grp.group_name as GroupName, 
userdetails.email as Email,
tbl_status.status as [Status],
tbl_rolemaster.role_name as RoleName,
userdetails.role_id as RoleId
FROM dbo.group_user_details as userdetails
inner join user_status_master as tbl_status on tbl_status.status_id =userdetails.status_id
inner join role_master  as tbl_rolemaster on   userdetails.role_id  =tbl_rolemaster.role_id 
Left join [group] as tbl_grp on  tbl_grp.group_id = userdetails.group_id
WHERE (userdetails.[user_name]=@username) or (userdetails.last_name = @lastname) or (userdetails.first_name=@firstname)
 or  (userdetails.email =@email) or (userdetails.role_id=@role)




SET NOCOUNT OFF
End