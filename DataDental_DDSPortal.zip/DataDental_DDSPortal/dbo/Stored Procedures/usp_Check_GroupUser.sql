﻿CREATE PROC [dbo].[usp_Check_GroupUser]
(
@UserName varchar(50),
@InviteCode varchar(50),
@LastName varchar(50),
@GroupZip varchar(50),
@Email varchar(50)
)
AS
BEGIN

DECLARE @Errormsg varchar(max)=NULL
IF NOT EXISTS(SELECT invitecode FROM dbo.invitecode_details WHERE invitecode=@InviteCode)
BEGIN
SET @Errormsg = 'Invite code not found. Please try again or contact our Group Service Center at 888.518.5338 for assistance'
END
ELSE 
BEGIN

IF NOT EXISTS(SELECT invitecode FROM dbo.invitecode_details WHERE invitecode=@InviteCode and email=@Email and group_zip=@GroupZip and last_name=@LastName)
BEGIN

SET @Errormsg = 'Group contact not found. Please try again or questions please contact our Group Service Center at ‘888.518.5338’'

END
ELSE
BEGIN

IF EXISTS(SELECT invitecode FROM dbo.group_user_details WHERE user_name=@UserName)
BEGIN
SET @Errormsg = 'Username already exists. Please enter a different user name.';
END

END

IF(@Errormsg IS NULL)
BEGIN
IF EXISTS(SELECT email FROM dbo.group_user_details WHERE email=@Email) 
BEGIN
SET @Errormsg = 'There is an account existing for this email address, please reset password if you have forgotten your password or contact our Group Service Center at ‘888.518.5338’'
END
END 
END

IF(@Errormsg IS NULL)
BEGIN
SET @Errormsg='Success'
END

DECLARE @Err as table
(
 ErrMsg varchar(max)
)
INSERT INTO @Err(ErrMsg)VALUES(@Errormsg)
SELECT * FROM @Err
END