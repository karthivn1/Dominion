﻿
CREATE procedure [dbo].[usp_MemberPortal_ViewGroupDetails]
(@groupid int = 0,
@groupname varchar(max) = null ,
@grouptype varchar(max)=null,
@planid int )
AS
Begin
SET NOCOUNT ON 
if(@groupid ='')
set @groupid = NULL
if(@groupname ='')
set @groupname = NULL

if (@planid IS NOT NULL)
begin

select grp.group_id as Group_Id,grp.group_name as Group_Name ,grp.group_type as Group_Type,pln.plan_id as Plan_Id from [group_sec]  as grp
join rel_gppl_sec reg on reg.group_id=grp.group_id
join [plan_sec] pln on pln.plan_id=reg.plan_id
where (grp.group_id =@groupid or grp.group_name=@groupname )and grp.group_type =@grouptype and pln.plan_id =@planid
end
else
begin


select grp.group_id as Group_Id,grp.group_name as Group_Name ,grp.group_type as Group_Type,pln.plan_id as Plan_Id from [group_sec]  as grp
join rel_gppl_sec reg on reg.group_id=grp.group_id
join [plan_sec] pln on pln.plan_id=reg.plan_id
where 
	((@groupid IS NULL AND (grp.group_id =grp.group_id  or grp.group_id  is null)) 
			OR (@groupid IS NOT NULL AND grp.group_id=@groupid))
		AND ((@groupname IS NULL AND (grp.group_name=grp.group_name or grp.group_name is null)) 
			OR (@groupname IS NOT NULL AND grp.group_name=@groupname))
--(grp.group_id =@groupid or grp.group_name=@groupname )
and grp.group_type =@grouptype 
end
 SET NOCOUNT OFF
End