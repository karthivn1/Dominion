﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <18-10-2016>
-- Description:	<This sp gets the Facility details for member by passing memberId,group Id and plan Id>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberFacilityByMemberGroupPlanId] --5,5
(
@memberId INT,
@MemGroupPlanId INT
)
AS
BEGIN
SET NOCOUNT ON;

SELECT DISTINCT Facilty.fc_id AS FacilityID,
		   Facilty.fc_name AS FacilityName,
		   relPlanFacility.eff_date AS EffDate,
		   relPlanFacility.exp_date AS ExpDate,
		   LTRIM(RTRIM((typeFc.descr))) AS "Action"

	 FROM facility Facilty
	 INNER JOIN rlplfc relPlanFacility ON relPlanFacility.facility_id=Facilty.fc_id
	 INNER JOIN member Member ON Member.member_id=relPlanFacility.member_id
	 INNER JOIN rlmbgrpl relMebGroupPlan ON relMebGroupPlan.mb_gr_pl_id=relPlanFacility.mb_gr_pl_id
	 LEFT JOIN typ_table typeFc ON typeFc.subsys_code='MB' AND typeFc.tab_name='action_code' AND typeFc.code=relPlanFacility.action_code
	 WHERE relMebGroupPlan.mb_gr_pl_id=@MemGroupPlanId AND relPlanFacility.member_id=@memberId AND relPlanFacility.exp_date IS NULL
	 --AND relMebGroupPlan.group_id=@groupId AND relMebGroupPlan.plan_id=@planId 
SET NOCOUNT OFF;
END