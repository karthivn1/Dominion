﻿

CREATE Procedure [dbo].[usp_MemberPortal_ForgotpasswordDetails](
@username varchar(max))
AS
Begin
SET NOCOUNT ON

Declare @userid int;
Declare @DOB Datetime;



		select @userid=user_id, @DOB =date_of_birth from member_user_details where user_name =@username 
		select usd.security_question_id as Security_Question_ID,sqm.question as Security_Question
	    from user_security_detail usd  inner join security_question_master sqm 
		on  sqm.security_question_id =usd.security_question_id   where usd.user_id =@userid



SET NOCOUNT OFF
END