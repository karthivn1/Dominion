﻿CREATE Proc [dbo].[usp_GroupPortal_GetAllPlansByGroupId] 
@groupid int
as
Begin
	Set nocount ON
	select distinct pln.plan_id,pln.plan_name as planname,pln.plan_dsp_name as plan_name,grp.group_id,grp.group_name,grp.group_type from rel_gppl_sec rel
	inner join [plan_sec] pln on pln.plan_id=rel.plan_id
	inner join [group_sec] grp on grp.group_id=rel.group_id
	where rel.group_id=@groupid and rel.exp_date is null

	Set nocount OFF
end