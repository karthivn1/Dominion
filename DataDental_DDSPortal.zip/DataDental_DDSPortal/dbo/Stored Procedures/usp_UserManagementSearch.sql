﻿CREATE procedure [dbo].[usp_UserManagementSearch]
(
@lastname as Varchar(max)= NULL,
@firstname as Varchar(max)=NULL,
@username as Varchar(max)=NULL,
@email as Varchar(max)=NULL,
@role as int =null)
AS
Begin
SET NOCOUNT ON 
if(@lastname ='')
set @lastname = NULL
if(@firstname ='')
set @firstname = NULL
if(@username ='')
set @username = NULL

if(@email ='')
set @email = NULL
if(@role ='')
set @role = NULL
if(@role = 0)
Begin

	if((ISNULL(@lastname,'') ='') and (ISNULL(@firstname,'') ='') and (ISNULL(@username,'') ='') and (ISNULL(@email,'') ='' ))
begin

			select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,tbl_udetails.DOB as DOB,tbl_udetails.GroupName as GroupName,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id
		from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,Rtrim(Isnull(tbl_grp.group_name,'')) +' ('+cast(tbl_grp.group_id as varchar)+')' as GroupName, 
		tbl_status.status as Status, tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id
		 from group_user_details as tbl_userdetails inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
		inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='grp' or tbl_rolemaster.portal_type ='common')
		Left join [group_sec] as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id where status in('Active', 'Pending','Deactivated'))  tbl_udetails
		
       where 1=1 order by LastName asc;

end 
else
begin
		
	   select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,tbl_udetails.DOB as DOB,tbl_udetails.GroupName as GroupName,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id
			from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,Rtrim(Isnull(tbl_grp.group_name,'')) +' ('+cast(tbl_grp.group_id as varchar)+')' as GroupName, 
			tbl_status.status as Status,tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id
			 from group_user_details as tbl_userdetails	inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
			inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='grp' or tbl_rolemaster.portal_type ='common')
			Left join [group_sec] as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id where status in('Active', 'Pending','DeActivated'))  tbl_udetails
			where (lower(tbl_udetails.UserName) like '%'+lower(@username)+'%') or (lower(tbl_udetails.LastName) like '%'+lower(@lastname)+'%') or (lower(tbl_udetails.FirstName) like '%'+lower(@firstname)+'%') or  (lower(tbl_udetails.email) like '%'+lower(@email)+'%') order by LastName asc;
end
end
else 
Begin
			select distinct tbl_udetails.UserName as UserName,tbl_udetails.LastName as LastName,tbl_udetails.FirstName as FirstName,tbl_udetails.DOB as DOB,tbl_udetails.GroupName as GroupName,tbl_udetails.Status as Status,tbl_udetails.Role as Role,tbl_udetails.Role_Id
			from (select tbl_userdetails.user_name as UserName, tbl_userdetails.last_name as LastName,tbl_userdetails.first_name as FirstName,tbl_userdetails.date_of_birth as DOB,Rtrim(Isnull(tbl_grp.group_name,'')) +' ('+cast(tbl_grp.group_id as varchar)+')' as GroupName, 
			tbl_status.status as Status,tbl_rolemaster.role_name as Role,tbl_userdetails.email as email,tbl_userdetails.role_id as Role_Id
			 from group_user_details as tbl_userdetails	inner join user_status_master as tbl_status on tbl_status.status_id =tbl_userdetails.status_id and tbl_status.portal_type='grp'
			inner join role_master  as tbl_rolemaster on   tbl_userdetails.role_id  =tbl_rolemaster.role_id and (tbl_rolemaster.portal_type='grp' or tbl_rolemaster.portal_type ='common')
			Left join [group_sec] as tbl_grp on  tbl_grp.group_id = tbl_userdetails.group_id where status in('Active', 'Pending','DeActivated'))  tbl_udetails
		where 
	--	tbl_udetails.Role_Id= ISNULL(@role,tbl_udetails.Role_Id )
		
			((@role IS NULL AND (tbl_udetails.Role_Id =tbl_udetails.Role_Id  or tbl_udetails.Role_Id  is null)) 
			OR (@role IS NOT NULL AND tbl_udetails.Role_Id =@role))
		AND ((@username IS NULL AND (tbl_udetails.UserName=tbl_udetails.UserName or tbl_udetails.UserName is null)) 
			OR (@username IS NOT NULL AND (lower(tbl_udetails.UserName) like '%'+lower(@username)+'%')))
	    AND ((@lastname IS NULL AND (tbl_udetails.LastName=tbl_udetails.LastName or tbl_udetails.LastName is null)) 
			OR (@lastname IS NOT NULL AND  (lower(tbl_udetails.LastName) like '%'+lower(@lastname)+'%')))
	    AND ((@firstname IS NULL AND (tbl_udetails.FirstName=tbl_udetails.FirstName or tbl_udetails.FirstName is null)) 
			OR (@firstname IS NOT NULL AND (lower(tbl_udetails.FirstName) like '%'+lower(@firstname)+'%')))
 AND ((@email IS NULL AND (tbl_udetails.email=tbl_udetails.email or tbl_udetails.email is null)) 
			OR (@email IS NOT NULL AND (lower(tbl_udetails.email) like '%'+lower(@email)+'%'))) order by LastName asc;
			--where ( Role_Id=@role) or ( (tbl_udetails.UserName=@username) or (tbl_udetails.LastName = @lastname) or (tbl_udetails.FirstName=@firstname) or  (tbl_udetails.email =@email))
End
SET NOCOUNT OFF
End