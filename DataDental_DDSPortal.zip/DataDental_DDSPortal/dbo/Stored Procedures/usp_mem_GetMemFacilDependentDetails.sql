﻿-- =============================================
-- Author:		<Selvakumar K>
-- Create date: <20-Oct-2016>
-- Description:	<This stored procedure is used to get dependent deatils for the given search criteria>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemFacilDependentDetails]  --657306,317,2987564 
(
@MemberId INT=NULL,
@GroupId INT=NULL,
@MemberGroupPlanId INT=NULL
)
AS
BEGIN
SET NOCOUNT ON
BEGIN TRAN 
	BEGIN TRY
DECLARE @dpntmemID INT
DECLARE @dpntfacilityID INT
;with tmp as
	
 (SELECT  rlplfc.rlplfc_id AS DpntFacilityID,             
         rlplfc.member_id AS DpntMemID,
		 member.last_name+member.first_name AS Member,		   
         rlplfc.facility_id AS FacilityID, 
		 facility.fc_name AS FacilityName,    
         rlplfc.eff_date AS EffDate,   
         rlplfc.exp_date AS ExpDate, 
		typ_table.descr 'Action',
		  mbr_code.mbr_code_desc AS Rel,	        
		 case 
		   when str_1='new_ssn' then cast(member.new_ssn as varchar) 
		   when str_1='member_id' then cast(member.member_id as varchar)
		   when str_1='source_id' then cast(member.source_id as varchar)
		   else
		   cast(member.alt_id as varchar) 
		   end 'ExternalID',
		 member.source_id AS SrcID,
		 member.alt_id AS AltID,
		 member.student_exp AS StudentExp ,
		   row_number() over(partition by rlplfc.member_id order by rlplfc.rlplfc_id desc) FacilDetails
    FROM rlplfc LEFT OUTER JOIN facility ON 
		rlplfc.facility_id = facility.fc_id 
		INNER JOIN  member ON rlplfc.member_id = member.member_id 
        INNER JOIN rlmbgrpl  ON  rlplfc.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id 
		INNER JOIN mbr_code ON mbr_code.mbr_code=  member.member_code
		INNER JOIN typ_table ON   typ_table.subsys_code = 'MB' 
		INNER JOIN typ_table_exp ON typ_table_exp.tab_name = 'ext_id_type'  
	  and typ_table_exp.int_1=member.ext_id_type and        
		typ_table.tab_name = 'action_code'  
		WHERE (typ_table.eff_date <= GETDATE() or     
	        typ_table.eff_date is NULL ) and   (typ_table.exp_date > GETDATE() or      
		        typ_table.exp_date is NULL) 
		and  rlmbgrpl.member_id = @MemberId and rlmbgrpl.mb_gr_pl_id=@MemberGroupPlanId
		and rlplfc.member_id<>@MemberId
		 
		 and rlmbgrpl.group_id=@GroupId
		and typ_table.code= rlplfc.action_code)
		select * INTO #DpntTemp from tmp  where FacilDetails=1--This is to avoid history records i.e Dependent may terminated again reinsated. this wont display history
		select * FROM #DpntTemp
--SET @dpntmemID=(SELECT TOP 1 rlplfc.member_id   FROM rlplfc LEFT OUTER JOIN facility ON 
--		rlplfc.facility_id = facility.fc_id 
--		INNER JOIN  member ON rlplfc.member_id = member.member_id 
--        INNER JOIN rlmbgrpl  ON  rlplfc.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id 
--		INNER JOIN mbr_code ON mbr_code.mbr_code=  member.member_code
--		INNER JOIN typ_table ON   typ_table.subsys_code = 'MB' 
--		INNER JOIN typ_table_exp ON typ_table_exp.tab_name = 'ext_id_type'  
--	  and typ_table_exp.int_1=member.ext_id_type and        
--		typ_table.tab_name = 'action_code'  
--		WHERE (typ_table.eff_date <= GETDATE() or     
--	        typ_table.eff_date is NULL ) and   (typ_table.exp_date > GETDATE() or      
--		        typ_table.exp_date is NULL) 
--		and  rlmbgrpl.member_id = @MemberId and rlmbgrpl.mb_gr_pl_id=@MemberGroupPlanId
--		and rlplfc.member_id<>@MemberId and rlmbgrpl.group_id=@GroupId
--		and typ_table.code= rlplfc.action_code order by rlplfc.member_id asc)

SET @dpntmemID=(SELECT TOP 1 DpntMemID FROM #DpntTemp)

--SET @dpntfacilityID=(SELECT TOP 1  rlplfc.rlplfc_id   FROM rlplfc LEFT OUTER JOIN facility ON 
--		rlplfc.facility_id = facility.fc_id 
--		INNER JOIN  member ON rlplfc.member_id = member.member_id 
--        INNER JOIN rlmbgrpl  ON  rlplfc.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id 
--		INNER JOIN mbr_code ON mbr_code.mbr_code=  member.member_code
--		INNER JOIN typ_table ON   typ_table.subsys_code = 'MB' 
--		INNER JOIN typ_table_exp ON typ_table_exp.tab_name = 'ext_id_type'  
--	  and typ_table_exp.int_1=member.ext_id_type and        
--		typ_table.tab_name = 'action_code'  
--		WHERE (typ_table.eff_date <= GETDATE() or     
--	        typ_table.eff_date is NULL ) and   (typ_table.exp_date > GETDATE() or      
--		    typ_table.exp_date is NULL) 
--		and  rlmbgrpl.member_id = @MemberId and rlmbgrpl.mb_gr_pl_id=@MemberGroupPlanId
--		and rlplfc.member_id<>@MemberId and rlmbgrpl.group_id=@GroupId
--		and typ_table.code= rlplfc.action_code  order by rlplfc.member_id asc)

SET @dpntfacilityID=(SELECT TOP 1 DpntFacilityID FROM #DpntTemp)

--EXEC usp_mem_GetMemFacilAddressDetails @dpntmemID,@dpntfacilityID

 DROP TABLE #DpntTemp

       COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
 SET NOCOUNT OFF  
 SET NOCOUNT OFF

END