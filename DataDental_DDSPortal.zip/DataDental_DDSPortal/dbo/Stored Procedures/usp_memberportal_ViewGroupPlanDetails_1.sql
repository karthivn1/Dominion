﻿
CREATE procedure [dbo].[usp_memberportal_ViewGroupPlanDetails] 
(@username varchar(max))
AS
Begin
SET NOCOUNT ON 
Declare @userid int;
Declare @zip varchar(max);
Declare @email varchar(max);
Declare @lname varchar(max);
Declare @memberid int;
--Declare @plan_id int;
Declare @status varchar(max);
Declare @roleid varchar(max);

Declare @roledetails Table
(roleid int);
set @userid= (select user_id from member_user_details where user_name=@username);

insert into @roledetails (roleid) 
select role_id  from member_user_details where  user_id=@userid;
  If exists( select * from @roledetails where roleid=1 )
          Begin

            select @email=email, @lname=last_name, @zip=zip,@roleid =role_id from member_user_details where  user_id=@userid
				select grp.group_id as Group_Id,(RTRIM (grp.group_name) + ' (' + RTRIM (pln.plan_name) + ')')  as Group_Name, grp.group_type , pln.plan_id as Plan_Id,pln.plan_name as Plan_Name,@roleid as Role_ID from contact_sec as contact
				join [address_sec] addr on addr.sys_rec_id=contact.sys_rec_id
				join [group_sec] grp on grp.group_id=addr.sys_rec_id
				join group_status_sec sta on grp.group_id=sta.group_id
				join rel_gppl_sec reg on reg.group_id=grp.group_id
				join [plan_sec] pln on pln.plan_id=reg.plan_id
				where contact.subsys_code='GP' and contact.lname=@lname and contact.addr_type='L'
				--and addr.zip=@zip
				 and sta.group_status='A4' and addr.subsys_code='GP' and contact.email=@email

        End
    else
   begin 
      If exists( select * from @roledetails where roleid in(2,3) )
     Begin
        If exists(select member_id  from member_user_details where user_id =@userid and member_id IS NOT NULL and member_id <> 0)
		  begin
  
		 set @memberid=(select member_id  from member_user_details where user_id =@userid );
		 --set @plan_id=(select plan_id  from member_user_details where user_id =@userid );
	     set @roleid = (select role_id from member_user_details where  user_id=@userid);
		 select  grp.group_id as Group_Id,grp.group_name as Group_Name ,grp.group_type as Group_Type,pln.plan_id as Plan_Id, @roleid as Role_ID from [group_sec]  as grp
		join rlmbgrpl_sec grpl on grpl.group_id = grp.group_id
		join member_sec mbr on grpl.member_id = mbr.member_id
		--join .rel_gppl reg on reg.group_id=grp.group_id
		join [plan_sec] pln on pln.plan_id=grpl.plan_id
		where (mbr.member_id =@memberid )

		End
 else
		 Begin
 
		 set @status ='DDS User with no previous groupid';
 
		  DECLARE @Err as table
		(
		 Error_Msg varchar(max)
		)

		INSERT INTO @Err(Error_Msg)VALUES(@status)
		SELECT * FROM @Err
		 End
End

 SET NOCOUNT OFF
End
End