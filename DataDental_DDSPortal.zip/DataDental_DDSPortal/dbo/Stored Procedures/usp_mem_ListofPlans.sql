﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <25-01-2017>
-- Description:	<This SP is used to returns list of Plans >
-- =============================================

CREATE PROCEDURE [dbo].[usp_mem_ListofPlans]    (
@memberId INT=NULL,
@activeplan INT=NULL,
@groupId INT=NULL,
@newEffectiveDate Datetime =NULL 
)
AS
BEGIN
SET NOCOUNT ON;

	--From Plan List
	SELECT CONVERT(varchar(10),tblPlan.plan_id)+'/'+tblPlan.plan_dsp_name AS FromPlnIDorName,
		rlMebRate.rate_code AS FromRC,
		tblPlan.plan_id AS FromPlanId,
		tblPlan.ins_type AS InsType,
		rlMebGroupPlan.mb_gr_pl_id AS MemberGroupPlanId

	from [plan] tblPlan
	 LEFT OUTER JOIN rlmbgrpl rlMebGroupPlan ON rlMebGroupPlan.plan_id=tblPlan.plan_id
	 LEFT OUTER JOIN rlmbrt rlMebRate ON rlMebRate.mb_gr_pl_id=rlMebGroupPlan.mb_gr_pl_id
	 LEFT OUTER JOIN typ_table typeMa ON typeMa.subsys_code='MB' AND typeMa.tab_name='action_code' AND typeMa.code=rlMebGroupPlan.action_code
	 
	WHERE rlMebGroupPlan.group_id=@activeplan AND rlMebGroupPlan.member_id=@memberId
	  AND rlMebRate.exp_rt_date IS NULL  AND rlMebGroupPlan.exp_gr_pl IS NULL 
	  group by tblPlan.plan_id ,tblPlan.plan_dsp_name ,rlMebRate.rate_code,tblPlan.ins_type,rlMebGroupPlan.mb_gr_pl_id

	--To Plan List
	SELECT DISTINCT tblPlan.plan_id AS PlanId,
	 CONVERT(varchar(10),tblPlan.plan_id)+' '+LTRIM(RTRIM((tblPlan.plan_dsp_name)))+' ('+LTRIM(RTRIM((typePl.descr)))+'/'+InsOption.ins_opt_qual+')' AS PlanName,	
	 tblPlan.ins_type AS InsType	  

	from [plan] tblPlan
	INNER JOIN rel_gppl RelGroupPlan ON tblPlan.plan_id=RelGroupPlan.plan_id
	INNER JOIN ins_opt InsOption ON tblPlan.ins_opt=InsOption.ins_opt
	LEFT JOIN typ_table typePl ON typePl.subsys_code='PL' AND typePl.tab_name='ins_type' AND typePl.code=tblPlan.ins_type
	INNER JOIN group_cap_rate GroupRateCode ON GroupRateCode.rel_gppl_id=RelGroupPlan.rel_gppl_id
	WHERE RelGroupPlan.group_id=@groupId AND ((RelGroupPlan.eff_date <= @newEffectiveDate AND ( RelGroupPlan.exp_date > @newEffectiveDate OR RelGroupPlan.exp_date is null) )
		 OR ( RelGroupPlan.eff_date > @newEffectiveDate AND (RelGroupPlan.exp_date > RelGroupPlan.eff_date OR RelGroupPlan.exp_date is null)))AND GroupRateCode.exp_date IS NULL	  
	 
	SET NOCOUNT OFF
END