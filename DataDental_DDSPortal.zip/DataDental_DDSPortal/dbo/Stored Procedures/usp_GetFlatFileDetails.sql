﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetFlatFileDetails]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	
IF OBJECT_ID('tempdb..#tempFile') IS NOT NULL
    DROP TABLE #tempFile

--Sync load group contact from DD to Portal flatfile_details table

EXEC usp_Group_InsertFlatFileDetails


SELECT TOP 100 detail_id,
			last_name,
			group_zip,
			email,
			created_date,
			is_invitecode_processed,
			invitecode_processed_date,
			con_type
			INTO #tempFile
			FROM flatfile_details f (NOLOCK)
			WHERE ISNULL(f.is_invitecode_processed,0)=0 
			AND invitecode_processed_date IS NULL

--SELECT *
UPDATE f SET f.is_invitecode_processed=1,f.invitecode_processed_date=null
	FROM #tempFile t
	JOIN flatfile_details f ON f.detail_id=t.detail_id

SELECT detail_id AS Id,
	last_name AS LastName,
	group_zip AS GroupZip,
	email AS Email,
	created_date AS CreatedDate, 
	is_invitecode_processed AS IsProcessed,
	invitecode_processed_date AS ProcessedDate,
	con_type AS ContactType
	FROM #tempFile

END