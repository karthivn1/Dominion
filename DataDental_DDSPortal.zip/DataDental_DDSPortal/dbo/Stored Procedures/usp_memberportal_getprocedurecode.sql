﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_getprocedurecode]
	-- Add the parameters for the stored procedure here
	(
	@proceduretype int
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
   SET NOCOUNT ON;
   DECLARE @BasicCare int
   SET @BasicCare =1

   IF (@proceduretype <> @BasicCare)
   BEGIN
			SELECT d_proc_code ProcedureCode,d_proc_sd ProcedureCodeDesc
			FROM plx_dent_proc prod
			INNER JOIN plx_dent_subcat subcat ON subcat.d_subcat_id= prod.d_subcat_id
			INNER JOIN plx_dent_cat cat ON subcat.d_cat_id= cat.d_cat_id
			WHERE LTRIM(RTRIM( cat.d_cat_sd  )) in (select  category_sd FROM [member_cost_calc_proc_type_category_mapping] 
			WHERE portal_category_number= @proceduretype)
	END
	ELSE
	BEGIN
		select d_proc_code ProcedureCode,d_proc_sd ProcedureCodeDesc from plx_dent_proc where d_proc_code in (
		'D2140','D2150','D2160','D2161','D2330','D2331','D2332','D2335','D2391','D2392','D2393','D2394','D2940','D2951','D3110','D3120')
	END
   
   SET NOCOUNT OFF;
END