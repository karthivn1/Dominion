﻿



-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <04-10-2016>
-- Description:	<This sp gets the Member Details by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetPlanDetailWithRateLists] --64304,2720
( 
@groupId INT,
@planId INT
)
AS
BEGIN
SET NOCOUNT ON;

	SELECT DISTINCT tblPlan.plan_id AS PlanID,
		tblPlan.plan_dsp_name AS PlanName
		,LTRIM(RTRIM((typePl.descr))) +' '+insOpt.ins_opt_sd AS "Option"
		,rlGroupPlan.eff_date AS EffDate
		,rlGroupPlan.exp_date AS ExpDate

	from [plan] tblPlan
	LEFT JOIN rel_gppl rlGroupPlan ON rlGroupPlan.plan_id=tblPlan.plan_id
	INNER JOIN ins_opt insOpt ON insOpt.ins_opt=tblPlan.ins_opt
	LEFT JOIN typ_table typePl ON typePl.subsys_code='PL' AND typePl.tab_name='ins_type' AND typePl.code=tblPlan.ins_type
	WHERE tblPlan.plan_id=@planId AND rlGroupPlan.group_id=@groupId
	

SELECT  DISTINCT group_cap_rate.plan_id ,
        rel_gppl.eff_date ,
		rel_gppl.exp_date ,
        group_cap_rate.rate_code AS RateCod,
		group_cap_rate.method,
		group_cap_rate.age_lb AS AgeLB,
		group_cap_rate.age_ub AS AgeUB,  
		group_cap_rate.prm_amt AS Premium,
		group_cap_rate.eff_date AS EffDate,
		group_cap_rate.exp_date AS ExpDate,
		pl_rat.rate_short_desc AS RateCodeDescription,  
		pl_rat.rate_allow_subs AS AllowSub,
		pl_rat.rate_num_depend AS Dep,
		pl_rat.rate_sequence ,
		pl_rat.spouse AS Spouse,     
		pl_rat.num_facil AS Facility,
		rel_gppl.wait_period ,
		rel_gppl.premium_cycle ,
		pl.plan_dsp_name ,     
		pl.ins_type ,
		pl.ins_opt ,
		ins_opt.ins_opt_sd ,
		pl_rat.pm_pm AS PmPm
		
		FROM  group_cap_rate    
		INNER JOIN pl_rat ON group_cap_rate.rate_code = pl_rat.rate_code
		INNER JOIN rel_gppl ON rel_gppl.rel_gppl_id = group_cap_rate.rel_gppl_id
		INNER JOIN [plan] pl ON rel_gppl.plan_id = pl.plan_id
		INNER JOIN ins_opt ON ins_opt.ins_opt = pl.ins_opt
		WHERE rel_gppl.group_id = @groupId AND rel_gppl.plan_id = @planId AND group_cap_rate.exp_date IS NULL  order by  pl_rat.rate_num_depend asc
		
		--((group_cap_rate.eff_date <= GETDATE()  AND ( group_cap_rate.exp_date is null  or(group_cap_rate.exp_date > group_cap_rate.eff_date))) 
		--or(group_cap_rate.eff_date >= GETDATE() and (group_cap_rate.exp_date is null or (group_cap_rate.exp_date > group_cap_rate.eff_date))))  

SET NOCOUNT OFF
END