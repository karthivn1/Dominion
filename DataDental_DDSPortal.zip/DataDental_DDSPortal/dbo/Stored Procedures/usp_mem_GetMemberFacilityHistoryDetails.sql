﻿

-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <18-10-2016>
-- Description:	<This sp gets the Facility details for member by passing memberId,group Id and plan Id>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberFacilityHistoryDetails]
(
@memberId INT
)
AS
BEGIN
SET NOCOUNT ON;

	DECLARE @facilityId INT

	--List of Facility
	SELECT DISTINCT  facility.fc_id AS FacilityID,
	       facility.fc_type AS [Type],
		   facility.fc_name AS FacilityName,
		   CAST(CASE WHEN facility.phone_elig= 'N' THEN 0 ELSE 1 END AS BIT) AS PhoneElig,
		   facility.fc_source ,
		   typeFcStatus.descr AS "Status",
		   fcstat.eff_date AS EffectiveDate,
		   facility.fc_opr_tory AS Operatories ,
		   address.addr1 +' '+ address.addr2  AS "Address",
		   address.city AS City,
		   address.country AS Country,
		   address.county AS County,
		   address.state ,     
		   address.zip AS ZipCode,
		   facility.emergency_phone AS EmergPhone,
		   facility.emg_phone_ext AS EmergPhoneExt,
		   CAST(CASE WHEN facility.fax_elig= 'N' THEN 0 ELSE 1 END AS BIT) AS FaxElig,  
		   rlplfc.eff_date AS PlanFacEffectiveDate,
		   rlplfc.exp_date AS PlanFacExpireDate,
		   contact.phone1 AS Phone,
		   contact.ext1 AS PhoneExt,
		   facility.np_id AS NPID  
	FROM   facility 
	INNER JOIN rlplfc ON  facility.fc_id = rlplfc.facility_id
	INNER JOIN fcstat ON  facility.fc_id = fcstat.facility_id AND (fcstat.eff_date <= GETDATE() AND (fcstat.exp_date > GETDATE() OR ( fcstat.exp_date is NULL)) )
	LEFT JOIN  [address] ON facility.fc_id = address.sys_rec_id
	LEFT JOIN  contact ON  facility.fc_id = contact.sys_rec_id
	LEFT JOIN typ_table typeFcStatus ON typeFcStatus.subsys_code='FC' AND typeFcStatus.tab_name='fcstat' AND typeFcStatus.code=fcstat.status
	WHERE rlplfc.member_id = @memberId AND  address.subsys_code = 'FC' AND  address.addr_type = 'L'		   
		  AND  ((contact.subsys_code = 'FC') AND (contact.con_type = 'OF'))
	ORDER BY rlplfc.eff_date DESC

	--Facility Details
	SET @facilityId=(SELECT TOP 1  facility.fc_id FROM facility 
						INNER JOIN rlplfc ON  facility.fc_id = rlplfc.facility_id
						INNER JOIN fcstat ON  facility.fc_id = fcstat.facility_id AND  (fcstat.eff_date <= GETDATE() AND (fcstat.exp_date > GETDATE() OR ( fcstat.exp_date is NULL)) )
						LEFT JOIN  [address] ON facility.fc_id = address.sys_rec_id
						LEFT JOIN  contact ON  facility.fc_id = contact.sys_rec_id
						WHERE rlplfc.member_id = @memberId AND  address.subsys_code = 'FC' AND  address.addr_type = 'L'								 
								AND  ((contact.subsys_code = 'FC') AND (contact.con_type = 'OF'))
						ORDER BY rlplfc.eff_date DESC)
						

	--Facility Details
	--SELECT DISTINCT Facilty.fc_id AS FacilityID,
	--	   Facilty.fc_name AS FacilityName,
	--	   relPlanFacility.eff_date AS EffDate,
	--	   relPlanFacility.exp_date AS ExpDate		   

	-- FROM facility Facilty
	-- INNER JOIN rlplfc relPlanFacility ON relPlanFacility.facility_id=Facilty.fc_id
	-- WHERE Facilty.fc_id=@facilityId AND relPlanFacility.member_id=@memberId AND relPlanFacility.exp_date IS NULL

	--Facility Auxilary Details
	SELECT DISTINCT RTRIM(LTRIM(fcstaff.staff_code)) AS StaffCode,
			RTRIM(LTRIM(typ.descr)) AS AuxStaffType,
			fcstaff.number_of_type AS AuxNumber,
			fcstaff.fc_id AS FacilityId,
			RTRIM(LTRIM(fcstaff.staff_type)) AS StaffType,
			RTRIM(LTRIM(typ.subsys_code)) AS SubSystemCode 
	FROM fc_staff AS fcstaff 
	LEFT OUTER JOIN typ_table typ ON typ.tab_name = 'fc_staff_ax' AND fcstaff.staff_code = typ.code 
	WHERE fcstaff.fc_id = @facilityId AND  fcstaff.staff_type = 'A'

SET NOCOUNT OFF;
END