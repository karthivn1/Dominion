﻿


-- =============================================
-- Author:		<Harishraj.R>
-- Create date: <03-11-2016>
-- Description:	<This sp gets the Member Request ID Details by passing memberId>
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberRequestIDDetails] --657306,175027
(
@memberId INT,
@groupId INT
)
AS
BEGIN
SET NOCOUNT ON;
	--DECLARE @groupId INT

		--Member Subscriber & dependent with group details
		SELECT DISTINCT member.member_id ,
				member.family_id ,   
				member.first_name AS FName,     
				member.middle_init AS MInitial,    
				member.last_name AS LastName ,    
				member.member_ssn AS SubExtID,
				[group].group_id AS GrpID,
				[group].group_type AS GrpType,
                LTRIM(RTRIM((typeGr.descr))) AS GroupTypeDesr,  
                [group].group_name AS GrpName,
				typMailTo.action AS MailIdAction,
                typMailTo.descr AS MailTo,
	            typReqIDCardType.descr AS RequestType,
				adr.addr_type AS AddrType,
	            typAddr.descr AS AddrTypeDesr,
				rlmbgrpl.exp_gr_pl
        FROM  [group]   
        INNER JOIN rlmbgrpl ON [group].group_id = rlmbgrpl.group_id 
		INNER JOIN member   ON  member.member_id = rlmbgrpl.member_id AND member.family_id = rlmbgrpl.member_id
		LEFT JOIN typ_table typeGr ON typeGr.subsys_code='GP' AND typeGr.tab_name='group_type' AND typeGr.code=[group].group_type
		LEFT JOIN typ_table typReqIDCardType ON  typReqIDCardType.subsys_code = 'MB' AND typReqIDCardType.tab_name = 'req_id_card'
		LEFT JOIN typ_table typMailTo ON  typMailTo.subsys_code = 'GP' AND typMailTo.tab_name = 'mail_id_card' AND typMailTo.code=[group].mail_id_card
		LEFT JOIN address adr ON  adr.subsys_code = 'GP' AND adr.sys_rec_id = member.member_id
		LEFT JOIN typ_table typAddr ON typAddr.subsys_code='MB' AND typAddr.tab_name='address' AND typAddr.code=adr.addr_type		       
        WHERE member.member_id = @memberId AND rlmbgrpl.group_id = @groupId  AND  rlmbgrpl.exp_gr_pl is null
		
		UNION ALL

		SELECT DISTINCT member.member_id ,
				member.family_id ,   
				member.first_name AS FName,     
				member.middle_init AS MInitial,    
				member.last_name AS LastName ,    
				member.member_ssn AS SubExtID,
				[group].group_id AS GrpID,
				[group].group_type AS GrpType,
                LTRIM(RTRIM((typeGr.descr))) AS GroupTypeDesr,  
                [group].group_name AS GrpName,
				typMailTo.action AS MailIdAction,
                typMailTo.descr AS MailTo,
	            typReqIDCardType.descr AS RequestType,
				adr.addr_type AS AddrType,
	            typAddr.descr AS AddrTypeDesr,
				rlmbgrpl.exp_gr_pl
        FROM  [group]   
        INNER JOIN rlmbgrpl ON [group].group_id = rlmbgrpl.group_id 
		INNER JOIN member   ON  member.member_id = rlmbgrpl.member_id AND member.family_id = rlmbgrpl.member_id
		LEFT JOIN typ_table typeGr ON typeGr.subsys_code='GP' AND typeGr.tab_name='group_type' AND typeGr.code=[group].group_type
		LEFT JOIN typ_table typReqIDCardType ON  typReqIDCardType.subsys_code = 'MB' AND typReqIDCardType.tab_name = 'req_id_card'
		LEFT JOIN typ_table typMailTo ON  typMailTo.subsys_code = 'GP' AND typMailTo.tab_name = 'mail_id_card' AND typMailTo.code=[group].mail_id_card
		LEFT JOIN address adr ON  adr.subsys_code = 'GP' AND adr.sys_rec_id = member.member_id
		LEFT JOIN typ_table typAddr ON typAddr.subsys_code='MB' AND typAddr.tab_name='address' AND typAddr.code=adr.addr_type		       
        WHERE member.member_id = @memberId AND rlmbgrpl.group_id <> @groupId  AND  rlmbgrpl.exp_gr_pl is null


		--SET @groupId=(SELECT TOP 1 [group].group_id 
		--					FROM  [group]   
		--					INNER JOIN rlmbgrpl ON [group].group_id = rlmbgrpl.group_id 
		--					INNER JOIN member   ON  member.member_id = rlmbgrpl.member_id AND member.family_id = rlmbgrpl.member_id
		--					WHERE member.member_id =@memberId AND rlmbgrpl.exp_gr_pl is null)

		--List of plan to request ID
		SELECT  rlmbgrpl.mb_gr_pl_id AS 'ContractId',  
                rlmbgrpl.member_id AS 'MemberId',      
                rlmbgrpl.plan_id AS 'PlanId',      
                rlmbgrpl.eff_gr_pl AS 'EffDate' , 
                rlmbgrpl.exp_gr_pl AS 'ExpDate',
				[plan].ins_type AS 'InsType',
                typInsTyp.descr AS 'InsTypeDesc',      
                [plan].plan_dsp_name AS 'PlanName',    
                ins_opt.ins_opt_sd AS 'InsOpt', 
                ins_opt.ins_opt_qual  AS 'InsTypeQual' 
        FROM [plan]          
        INNER JOIN rlmbgrpl ON [plan].plan_id = rlmbgrpl.plan_id 
        INNER JOIN ins_opt ON [plan].ins_opt = ins_opt.ins_opt
		LEFT JOIN typ_table typInsTyp ON  typInsTyp.subsys_code = 'PL' AND typInsTyp.tab_name = 'ins_type' AND typInsTyp.code=[plan].ins_type

        WHERE rlmbgrpl.member_id = @memberId AND rlmbgrpl.group_id = @groupId AND rlmbgrpl.exp_gr_pl IS NULL		

SET NOCOUNT OFF;
END