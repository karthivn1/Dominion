﻿
-- =============================================
-- Author:		<Mari Selvam Sornaraj>
-- Create date: <12-16-2016>
-- Description:	<This sp gets the Search Producer in Member Screen>
-- =============================================
-- exec [usp_mem_ProducerSearch] 311,'DH','VA','01/01/2017','','Bradford','','','',1345,'',''
CREATE PROCEDURE [dbo].[usp_mem_ProducerSearch]
(
@planid INT,
@groupId int,
@licenseType varchar(3),
@licensIssuingstate varchar(3),
@effectiveDate datetime,
@companyName varchar(50),
@firstName varchar(20),
@lastName varchar(50),
@taxID varchar(11),
@altID varchar(20),
@producerID int,
@Status varchar(2),
@producerType varchar(2)
)
AS
BEGIN
SET NOCOUNT ON;
Declare @Sql nvarchar(max)



set @Sql= 'SELECT DISTINCT  pd.producer_id as ProducerID,           
pd.producer_name as CompanyName,           
pd.last_name as ProducerLastname,    
pd.first_name as ProducerFirstName,           
pdstat.producer_type as ProducerType,           
pdstat.status as ProducerStatus,    
pd.alt_id as AltID,           
pdstat.eff_date as EffDate,           
pdstat.exp_date as ExpDate,    
pd.tax_id as TaxID,           
pd.vendor_id as VendorID,
pdl_d.license_number as LicenseNo,
rlpdpl.comm_scheme_id as SchemeID,
(select rel_gppl_id from rel_gppl where plan_id=' +  convert(varchar(20),@planid) + ' and group_id=' +  convert(varchar(20),@groupId) + ') as Relgroupid 
FROM        
pd ,         
pdstat ,                  
rlpdpl ,     
pdl_d     WHERE ( pdstat.producer_id = pd.producer_id ) and  
( pdstat.producer_id = rlpdpl.producer_id ) and      
( rlpdpl.producer_id = pdl_d.producer_id ) and    
( ( pdstat.status = ''AC'' ) and          
( pdl_d.license_type = ''' + @licenseType + ''' ) and   
( pdstat.eff_date <= ''' + convert(varchar(20),@effectiveDate) + ''' ) and          
( rlpdpl.eff_date <= ''' + convert(varchar(20),@effectiveDate) + ''' ) and          
(pdstat.exp_date is NULL or    ( pdstat.exp_date > ''' + convert(varchar(20),@effectiveDate) + ''' ) ) and          
(pdstat.exp_date is NULL or          ( rlpdpl.exp_date > ''' + convert(varchar(20),@effectiveDate) + ''' ) ) and    
( pdl_d.issuing_state = '''+ @licensIssuingstate +''' ) and          ( pdl_d.eff_date <= ''' + convert(varchar(20),@effectiveDate) + ''' ) and    						    
(pdl_d.exp_date is NULL or      
( pdl_d.exp_date > ''' + convert(varchar(20),@effectiveDate) + ''' ) ) and    
( rlpdpl.plan_id =' +  convert(varchar(20),@planid) + ') )'  

	IF @companyName <> ''
      set @Sql = @Sql + ' AND lower(pd.producer_name) =  lower(''' +@companyName+''') '

   	IF @firstName <> ''
      set @Sql = @Sql + ' AND lower(pd.first_name) =  lower(''' + @firstName+''') '

   	IF @lastName <> ''
      set @Sql = @Sql + ' AND lower(pd.last_name) =  lower(''' +@lastName+''') '

   	IF @taxID <> ''
      set @Sql = @Sql + ' AND lower(pd.tax_id) =  lower(''' +@taxID+''') '

   	IF @altID <> ''
       set @Sql = @Sql + ' AND lower(pd.alt_id) =  lower(''' +@altID+''') '

   	IF @Status <> ''
       set @Sql = @Sql + ' AND lower(fcstat.status) =  lower(''' +@Status+''') '

	IF @producerType <> ''
       set @Sql = @Sql + ' AND lower(pdstat.producer_type) =  lower(''' +@producerType+''') '

     IF @producerID <> 0
       set @Sql = @Sql + ' AND pd.producer_id =  ' + convert(varchar(20), @producerID) +'  '

exec(@Sql)

SET NOCOUNT OFF
END