﻿


-- =============================================
-- Author:		V.M.HEMANANTH
-- Create date: 17/04/2017
-- Description:	TO GET MEMBER CLAIM DATAS FOR MEMBER CLAIM HISTROY TAB
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberClaimDatas]
	-- Add the parameters for the stored procedure here
	(@memberId INT,
	 @groupId INT,
	 @planId INT,
	 @incVoidSVC INT)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	 SELECT claim_h.claim_id AS 'ClaimID',
	 claim_h.claim_no AS 'ClaimNo', 
         claim_h.type AS 'Type', 
		 claim_h.speciality_type AS 'Spc', 
		 claim_h.claim_status AS 'ClaimStatus',
		 claim_d.d_proc_code AS 'ProcCode', 
	     claim_d.tooth_no , 
		 claim_d.surface, 
		 claim_d.patient_resp AS 'PatientRes', 
		 claim_d.plan_resp AS 'PlanRes', 
		 claim_d.date_to_pay, 
		 claim_d.status AS 'SvcStatus', 
		 claim_d.cob_amt AS 'CobAmount', 
         claim_d.max_allowed, 
		 claim_d.perc_covered AS 'PercentCoverd', 
		 claim_d.ded_applied, 
		 claim_d.co_ins AS 'CoIns', 
		 claim_d.provider_resp AS 'ProviderRes', 
		 claim_d.date_processed AS 'DateProc', 
         member.first_name AS 'Patient', 
		 (select mbr_code_desc from mbr_code where member.member_code = mbr_code.mbr_code) AS 'Relation', 
         facility.fc_name AS 'Facility', 
		 facility.vendor_id AS 'VD',
		 provider.provider_name AS 'Provider', 
		 claim_d.svc_beg AS 'SVCDate', 
         year(claim_d.svc_beg),
         claim_d.rollover_applied AS 'RoApplied', 
		 claim_d.reversal_switch 
FROM claim_d, claim_h, member, rlplfc, facility, provider, rlmbgrpl WHERE 
( claim_h.fc_id = facility.fc_id) and ( claim_h.prv_id = provider.provider_id) 
and ( claim_d.claim_id = claim_h.claim_id ) and ( member.member_id = rlplfc.member_id )
 and ( claim_h.rlplfc_id = rlplfc.rlplfc_id ) and ( rlmbgrpl.mb_gr_pl_id = claim_h.mbgrpl_id ) 
 and ( ( rlmbgrpl.member_id = @memberId) AND ( rlmbgrpl.group_id = @groupId ) AND ( rlmbgrpl.plan_id = @planId) 
 AND ( claim_d.reversal_switch = 0 or claim_d.reversal_switch =@incVoidSVC ) AND ( claim_d.status in ('Open', 'Denied', 'Processed') ) ) 

END