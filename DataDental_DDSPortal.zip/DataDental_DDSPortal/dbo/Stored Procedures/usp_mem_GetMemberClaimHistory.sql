﻿
-- =============================================
-- Author:		V.M.HEMANANTH
-- Create date: 04/13/2017
-- Description:	To get the Member Claim History...
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_GetMemberClaimHistory]
	-- Add the parameters for the stored procedure here
	 (@ssn VARCHAR(50))
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    
	  SELECT DISTINCT  member_a.member_code AS 'Gender',         
                       member_a.member_id AS 'MemberID',
					   pl.plan_dsp_name AS 'PlanName',       
					   member_a.middle_init AS 'MiddleInitial',
					    member_a.last_name AS 'LastName',      
	                   member_a.member_ssn AS 'SSN',
					     rlmbgrpl.group_id AS 'GroupID',  
		               rlmbgrpl.plan_id AS 'PlanID',
					    gr.group_name AS 'GroupName',     
					   member_a.first_name AS 'FirstName',  
					   gr.group_oed  AS 'OED'
					   FROM  member member_a ,  [plan] pl, rlmbgrpl , [group] gr   
				       WHERE ( rlmbgrpl.plan_id = pl.plan_id ) and 
				       ( rlmbgrpl.member_id = member_a.member_id ) and          
					   ( gr.group_id = rlmbgrpl.group_id ) and (member_a.member_ssn = @ssn)  


            DECLARE @memId INT,@grpId INT,@plnId INT;  

			SELECT DISTINCT TOP (1)                                
					   @memId = member_a.family_id,					  
					 @grpId = rlmbgrpl.group_id ,  
		             @plnId  =  rlmbgrpl.plan_id 					    
					   FROM  member member_a ,  [plan] pl, rlmbgrpl , [group] gr   
				       WHERE ( rlmbgrpl.plan_id = pl.plan_id ) and 
				       ( rlmbgrpl.member_id = member_a.member_id ) and          
					   ( gr.group_id = rlmbgrpl.group_id ) and (member_a.member_ssn = @ssn)  


		   EXEC [usp_mem_GetMemberClaimDetails] @memId,@grpId,@plnId
END