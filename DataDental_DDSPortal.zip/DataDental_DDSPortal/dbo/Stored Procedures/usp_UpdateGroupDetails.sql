﻿CREATE PROC [dbo].[usp_UpdateGroupDetails]
(
@GroupID INT,
@PlanID INT,
@IsEmailNotifications BIT,
@IsPaperlessStatements BIT,
@Address1 VARCHAR(MAX),
@Address2 VARCHAR(MAX),
@City VARCHAR(MAX),
@StateCode VARCHAR(MAX),
@Zip VARCHAR(MAX)
)
AS
BEGIN
	Declare @address_id int
	Select @address_id=address_id from [address] where sys_rec_id=@GroupID and subsys_code='GP' and addr_type='L'
	Update [address] set addr1=@Address1, addr2=@Address2,city=@City,[state]=@StateCode,zip=@Zip where address_id=@address_id
	SELECT 'Success'

END