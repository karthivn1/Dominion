﻿CREATE PROC [dbo].[usp_GroupPortal_UpdateGroupDetails]
(
@Username varchar(20),
@GroupID INT,
@PlanID INT,
@IsEmailNotifications BIT,
@IsPaperlessStatements BIT,
@Address1 VARCHAR(MAX),
@Address2 VARCHAR(MAX),
@City VARCHAR(MAX),
@StateCode VARCHAR(MAX),
@Zip VARCHAR(MAX)
)
AS
BEGIN
Update group_user_details set email_notification=@IsEmailNotifications,paperless=@IsPaperlessStatements where user_name=@Username
SELECT 'Success'
END