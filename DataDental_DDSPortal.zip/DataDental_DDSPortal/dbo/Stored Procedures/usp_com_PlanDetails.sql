﻿CREATE PROCEDURE [dbo].[usp_com_PlanDetails] 
(
@PlanId INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

	SELECT
		 plan_id as PlanID,plan_name as PlanName,ins_type as PlanType
		 from 
		[plan_sec]  
	WHERE  plan_id =@PlanId 

SET NOCOUNT OFF 
END