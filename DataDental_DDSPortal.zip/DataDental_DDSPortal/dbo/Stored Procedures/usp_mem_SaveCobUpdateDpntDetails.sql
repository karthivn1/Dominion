﻿



-- ============================================= 
-- Author:     
-- Create date: <14-12-2016> 
-- Description:   
-- ============================================= 
CREATE PROCEDURE [dbo].[usp_mem_SaveCobUpdateDpntDetails] 
(
@memberId INT=NULL, 
@newMbrGroupPlanId INT=NULL, 
@effDate DATETIME=NULL,
@actionCode VARCHAR(100)=NULL, 
@hUser VARCHAR(100)=NULL, 
@facilId INT=NULL, 
@dpntMemberId INT=NULL, 
@activityMasterId INT=NULL, 
@subsystemCode VARCHAR(2)=NULL, 
@reasonCode VARCHAR(2)=NULL, 
@memberGroupPlanId INT=NULL, 
@dpntmemberGroupPlanId INT=NULL
) 
AS 
  BEGIN      
      SET nocount ON; 

      --BEGIN TRAN 

      --BEGIN try 
          DECLARE @hmsi INT 
          DECLARE @count INT 

          IF ( @actionCode = 'COBRA Active' ) 
            BEGIN 
                IF ( @memberGroupPlanId = @dpntmemberGroupPlanId ) 
                  BEGIN 
                      IF ( @dpntMemberId > 0 ) 
                        BEGIN
							
							SELECT @hmsi = msi + 1 
							FROM   sysdatetime  
                            
                            
                            INSERT INTO rlplfc 
                                        (mb_gr_pl_id, 
                                         member_id, 
                                         facility_id, 
                                         eff_date, 
                                         action_code, 
                                         h_datetime, 
                                         h_msi, 
                                         h_action, 
                                         h_user) 
                            SELECT @newMbrGroupPlanId, 
                                   member_id, 
                                   @facilId, 
                                   @effDate, 
                                   'CC', 
                                   Getdate(), 
                                   @hmsi, 
                                   'CC', 
                                   @hUser 
                            FROM   rlplfc 
                            WHERE  mb_gr_pl_id = @dpntmemberGroupPlanId 
                                   AND exp_date IS NOT NULL 
                                   AND member_id = @dpntMemberId 

                            UPDATE sysdatetime 
                            SET    msi = msi + 1 

                            --UPDATE rlplfc 
                            --SET    exp_date = @effDate, 
                            --       h_action = 'CT' 
                            --WHERE  mb_gr_pl_id = @memberGroupPlanId 
                            --       AND exp_date IS NULL 

                        --    SET @count=(SELECT Count(*) 
                        --                FROM   rlplfc 
                        --                WHERE  mb_gr_pl_id = @newMbrGroupPlanId 
                        --                       AND member_id = @dpntMemberId) 

                        --    IF ( @count = 0 ) 
                        --      BEGIN 
                        --          SELECT @hmsi = msi + 1 
                        --          FROM   sysdatetime 

                        --          INSERT INTO rlplfc 
                        --                      (mb_gr_pl_id, 
                        --                       member_id, 
                        --                       facility_id, 
                        --                       eff_date, 
                        --                       action_code, 
                        --                       h_datetime, 
                        --                       h_msi, 
                        --                       h_action, 
                        --                       h_user) 
                        --         VALUES      ( @newMbrGroupPlanId, 
                        --                        @dpntMemberId, 
                        --                        @facilId, 
                        --@effDate, 
                        --                        'CC', 
                        --                        Getdate(), 
                        --                        @hmsi, 
                        --                        'CC', 
                        --                        @hUser) 

                        --          UPDATE sysdatetime 
                        --          SET    msi = msi + 1 
                        --      END 
                        END 
                  END 
                ELSE
				                   
				  SELECT @hmsi = msi + 1 
				  FROM   sysdatetime

				  INSERT INTO rlplfc 
                              (mb_gr_pl_id, 
                               member_id, 
                               facility_id, 
                               eff_date, 
                               action_code, 
                               h_datetime, 
                               h_msi, 
                               h_action, 
                               h_user) 
                  SELECT @newMbrGroupPlanId, 
                         member_id, 
                         @facilId, 
                         @effDate, 
                         'CC', 
                         Getdate(), 
                         @hmsi, 
                         'CC', 
                         @hUser 
                  FROM   rlplfc 
                  WHERE  mb_gr_pl_id = @memberGroupPlanId                         
                         AND exp_date IS NULL
						 AND member_id = @dpntMemberId 
				  
				  UPDATE sysdatetime 
					SET    msi = msi + 1
				  
				  --UPDATE rlplfc 
      --            SET    exp_date = @effDate,                         
      --                   action_code = 'CT', 
      --                   h_datetime = Getdate() 
      --            WHERE  mb_gr_pl_id = @memberGroupPlanId
						-- AND exp_date IS NULL
            END 
          ELSE IF @actionCode = 'Active' 
            BEGIN 
                IF ( @memberGroupPlanId = @dpntmemberGroupPlanId ) 
                  BEGIN 
                      IF ( @dpntMemberId > 0 ) 
                        BEGIN
							SELECT @hmsi = msi + 1 
							FROM   sysdatetime
                                                       
                            INSERT INTO rlplfc 
                                        (mb_gr_pl_id, 
                                         member_id, 
                                         facility_id, 
                                         eff_date, 
                                         action_code, 
                                         h_datetime, 
                                         h_msi, 
                                         h_action, 
                                         h_user) 
                            SELECT @newMbrGroupPlanId, 
                                   member_id, 
                                   @facilId, 
                                   @effDate, 
                                   'CA', 
                                   Getdate(), 
                                   @hmsi, 
                                   'CA', 
                                   @hUser 
                            FROM   rlplfc 
                            WHERE  mb_gr_pl_id = @memberGroupPlanId 
                                   AND exp_date IS NOT NULL 
                                   AND member_id = @dpntMemberId 

                        UPDATE sysdatetime 
                            SET    msi = msi + 1 

                            --UPDATE rlplfc 
                            --SET    exp_date = @effDate, 
                            --       h_action = 'ST' 
                            --WHERE  mb_gr_pl_id = @memberGroupPlanId 
                            --       AND exp_date IS NULL 

             --               SET @count=(SELECT Count(*) 
             --FROM   rlplfc 
             --                           WHERE  mb_gr_pl_id = @newMbrGroupPlanId 
             --                                  AND member_id = @dpntMemberId) 

             --               IF ( @count = 0 ) 
             --                 BEGIN 
             --                     SELECT @hmsi = msi + 1 
             --                     FROM   sysdatetime 

             --                     INSERT INTO rlplfc 
             --                                 (mb_gr_pl_id, 
             --                                  member_id, 
											  -- facility_id, 
             --                                  eff_date, 
             --                                  action_code, 
             --                                  h_datetime, 
             --                                  h_msi, 
             --                                  h_action, 
             --                                  h_user) 
             --                     VALUES      ( @newMbrGroupPlanId, 
             --                                   @dpntMemberId, 
             --                                   @facilId, 
             --                                   @effDate, 
             --                                   'CA', 
             --                                   Getdate(), 
             --                                   @hmsi, 
             --                                   'CA', 
             --                                   @hUser) 

             --                     UPDATE sysdatetime 
             --                     SET    msi = msi + 1 
             --                 END 
                        END 
                  END 
                ELSE

				  SELECT @hmsi = msi + 1 
				  FROM   sysdatetime
                  
                  INSERT INTO rlplfc 
                              (mb_gr_pl_id, 
                               member_id, 
                               facility_id, 
                               eff_date, 
                               action_code, 
                               h_datetime, 
                               h_msi, 
                               h_action, 
                               h_user) 
                  SELECT @newMbrGroupPlanId, 
                         member_id, 
                         @facilId, 
                         @effDate, 
                         'CA', 
                         Getdate(), 
                         @hmsi, 
                         'CA', 
                         @hUser 
                  FROM   rlplfc 
                  WHERE  mb_gr_pl_id = @memberGroupPlanId                          
                         AND exp_date IS NULL
						 AND member_id = @dpntMemberId 

                UPDATE sysdatetime 
                SET    msi = msi + 1

				--UPDATE rlplfc 
    --            SET    exp_date = @effDate, 
    --                    h_action = 'ST' 
    --            WHERE  mb_gr_pl_id = @memberGroupPlanId 
    --                    AND exp_date IS NULL
            END 
          ELSE IF @actionCode='Terminated'
            BEGIN 
                IF ( @memberGroupPlanId = @dpntmemberGroupPlanId ) 
                  BEGIN 
                      IF ( @dpntMemberId > 0 ) 
                       BEGIN
							SELECT @hmsi = msi + 1 
							FROM   sysdatetime
                            
                            
                            INSERT INTO rlplfc 
                                        (mb_gr_pl_id, 
                                         member_id, 
                                         facility_id, 
                                         eff_date, 
                                         action_code, 
                                         h_datetime, 
                                         h_msi, 
                                         h_action, 
                                         h_user) 
         SELECT @newMbrGroupPlanId, 
                                   member_id, 
                                   @facilId, 
                                   @effDate, 
                                   'CP', 
                                   Getdate(), 
                                   @hmsi, 
                                   'CP', 
                                   @hUser 
                            FROM   rlplfc 
							WHERE  mb_gr_pl_id = @memberGroupPlanId 
                                   AND exp_date IS NOT NULL 
                                   AND member_id = @dpntMemberId 

                            UPDATE sysdatetime 
                            SET    msi = msi + 1 

                            --UPDATE rlplfc 
                            --SET    exp_date = @effDate, 
                            --       h_action = 'ST' 
                            --WHERE  mb_gr_pl_id = @memberGroupPlanId 
                            --       AND exp_date IS NULL 

                            --SET @count=(SELECT Count(*) 
                            --            FROM   rlplfc 
                            --            WHERE  mb_gr_pl_id = @newMbrGroupPlanId 
                            --                   AND member_id = @dpntMemberId) 

                            --IF ( @count = 0 ) 
                            --  BEGIN 
                            --      SELECT @hmsi = msi + 1 
                            --      FROM   sysdatetime 

                            --      INSERT INTO rlplfc 
                            --                  (mb_gr_pl_id, 
                            --                   member_id, 
                            --                   facility_id, 
                            --                   eff_date, 
                            --                   action_code, 
                            --                   h_datetime, 
                            --                   h_msi, 
                            --                   h_action, 
                            --                   h_user) 
                            --      VALUES      ( @newMbrGroupPlanId, 
                            --                    @dpntMemberId, 
                            --                    @facilId, 
                            --                    @effDate, 
                            --                    'CP', 
                            --                    Getdate(), 
                            --                    @hmsi, 
                            --                    'CP', 
                            --                    @hUser) 

                            --      UPDATE sysdatetime 
                            --      SET    msi = msi + 1 
                            --  END 
                        END 
                  END 
                ELSE

				  SELECT @hmsi = msi + 1 
				  FROM   sysdatetime
                  
                  INSERT INTO rlplfc 
                              (mb_gr_pl_id, 
                               member_id, 
                               facility_id, 
                               eff_date, 
                               action_code, 
                               h_datetime, 
                               h_msi, 
                               h_action, 
                               h_user) 
                  SELECT @newMbrGroupPlanId, 
                         member_id, 
                         facility_id, 
                         @effDate, 
                         'CP', 
                         Getdate(), 
                         @hmsi, 
                         'CP', 
                         @hUser 
                  FROM   rlplfc 
                  WHERE  mb_gr_pl_id = @memberGroupPlanId
						 AND exp_date IS NULL
						 AND member_id = @dpntMemberId 

				  UPDATE sysdatetime 
				  SET    msi = msi + 1

				  --UPDATE rlplfc 
      --            SET    exp_date = @effDate, 
      --                  h_action = 'ST' 
      --            WHERE  mb_gr_pl_id = @memberGroupPlanId 
      --                  AND exp_date IS NULL
            END 

           
		 IF @activityMasterId > 0 
         BEGIN 
            EXEC usp_SaveActivity @subsystemCode,@memberId,@reasonCode,@activityMasterId,@hUser 
         END

      --  COMMIT TRAN 
      --END try 

      --BEGIN catch		  
      --    ROLLBACK TRAN

      --    DECLARE @erMessage  NVARCHAR(2048), 
      --            @erSeverity INT, 
      --            @erState    INT 

      --    SELECT @erMessage = Error_message(), 
      --           @erSeverity = Error_severity(), 
      --           @erState = Error_state() 

      --    RAISERROR (@erMessage,@erSeverity,@erState ) 
      --END catch 

SET NOCOUNT OFF 
END