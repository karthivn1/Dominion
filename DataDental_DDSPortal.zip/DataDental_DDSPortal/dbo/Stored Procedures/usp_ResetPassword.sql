﻿CREATE PROCEDURE [dbo].[usp_ResetPassword]
(
@userName varchar(max),
@hashpassword varchar(max)
)
AS
BEGIN
SET NOCOUNT ON;
Declare  @Errormsg varchar(max)=NuLL;
Declare  @Pwdresetdate varchar(max) = NuLL;
declare @userId int;
 Declare @temp varchar(max) = NuLL;
 set @userId=(select  user_id as UserID from group_user_details  where user_name=@userName);
 
IF NOT Exists(select user_id as UserID, user_name as UserName from group_user_details  where user_name =@userName)

Begin

 set @Errormsg= 'Username is invalid.';
End
else
Begin

If Exists( select  user_id as UserID from group_user_details  where user_name = @userName  )
Begin

 set @Errormsg= 'Password has been reset. Temporary password has been emailed to the user';
   update group_user_details set temp_password=@hashpassword,status_id=4,forgot_password_time =convert(date,getdate()) where user_id=@userId 
 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,1,1001,0,convert(date,getdate()));
End
End

 DECLARE @Err as table
(
 ErrMsg varchar(max)
)
INSERT INTO @Err(ErrMsg)VALUES(@Errormsg)
SELECT * FROM @Err

SET NOCOUNT OFF
END