﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--DECLARE @fileName NVARCHAR(100)=NULL
--exec usp_GetPlanFileName 24175,273,0,@fileName out
--SELECT @fileName
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetPlanFileName]
@GroupId INT,
@PlanId INT,
@MemberId INT,
@FileName nvarchar(100) OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets FROM
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


IF OBJECT_ID('tempdb..#tmpPlan') IS NOT NULL
    DROP TABLE #tmpPlan


IF OBJECT_ID('tempdb..#tmpGroup') IS NOT NULL
    DROP TABLE #tmpGroup

IF OBJECT_ID('tempdb..#tmpParent') IS NOT NULL
    DROP TABLE #tmpParent

DECLARE @EnrolTerr nvarchar(2)=NULL;
SET @FileName =''

SELECT *
	INTO #tmpPlan
	FROM plan_sec p
	WHERE p.plan_id=@PlanId

SELECT *
	INTO #tmpGroup
	FROM group_sec g
	WHERE g.group_id=@GroupId


SELECT Parent.*
	INTO #tmpParent
	FROM #tmpGroup g
	JOIN group_sec Parent ON Parent.group_id=g.group_parent
	
--special code for plan 168 - no new VA DOB at this time 11/05/09
--no enrollment in va for plan 168 as of 1/20/11

IF @PlanId=168
BEGIN
	SET @FileName=CAST(@PlanId AS nvarchar)+'.pdf'
	RETURN	
END


EXEC usp_GetPrefixPlanFileName @GroupId,@PlanId,@MemberId,@EnrolTerr OUT

--Exclude for subs with vision only card

---Special for SG MD eff 10/01/2012 - they get the "MD" version

IF EXISTS(SELECT r.mb_gr_pl_id
FROM rlmbgrpl_sec r WHERE r.group_id=@GroupId AND r.member_id=@MemberId AND r.plan_id in(309,320,310,329))
BEGIN
	IF EXISTS(SELECT t.group_id
	FROM #tmpGroup t WHERE t.group_type='SG')
	BEGIN 
		IF @EnrolTerr='MD'
		BEGIN
			SET @FileName=@EnrolTerr+CAST(@PlanId AS nvarchar)+'.pdf'
			RETURN
		END

	END

END


--Updated 07/15/10 for Teethkeepers conversion  - PA
IF EXISTS(SELECT t.group_id
FROM #tmpParent t WHERE CHARINDEX('TEETHKEEPERS',UPPER(t.group_name))>0)
BEGIN
	IF EXISTS(SELECT t.plan_id
	FROM #tmpPlan t WHERE LEFT(t.plan_name,1)<>'7' AND t.ins_opt='HMO' AND CHARINDEX('000X',UPPER(t.plan_dsp_name))=0)
	BEGIN
		IF @EnrolTerr='PA'
		BEGIN
			SET @FileName='603x06TK.pdf'
			RETURN
		END
	END

END

---Updated 7/15/10 for VA and DC version of 600 series HMO plans

IF EXISTS(SELECT t.plan_id
FROM #tmpPlan t WHERE LEFT(t.plan_name,1)<>'7' AND t.ins_opt='HMO' AND CHARINDEX('000X',UPPER(t.plan_dsp_name))=0)
BEGIN
	IF @EnrolTerr IN ('VA','DC')
	BEGIN
		SET @FileName=@EnrolTerr+CAST(@PlanId AS nvarchar)+'.pdf'
		RETURN
	END
END

SET @FileName=CAST(@PlanId AS nvarchar)+'.pdf'

RETURN 
    
END