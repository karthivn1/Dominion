﻿CREATE PROCEDURE [dbo].[usp_GetGroupSummarySubscriberDetails]
(
@GroupID INT,
@PlanID INT,
@CoverageTier VARCHAR(MAX)
) 
AS 
BEGIN 
SET NOCOUNT ON 

--SELECT rlmbgrpl_sec.group_id GroupID,rlmbgrpl_sec.plan_id PlanID,rlmbgrpl_sec.member_id MemberID,member_sec.first_name FirstName,member_sec.last_name LastName, member_sec.date_of_birth DOB FROM member_sec
--inner join rlplfc_sec on  rlplfc_sec.member_id=member_sec.member_id
--inner join rlmbgrpl_sec on rlmbgrpl_sec.mb_gr_pl_id=rlplfc_sec.mb_gr_pl_id
--inner join rlmbrt_sec on rlmbrt_sec.mb_gr_pl_id=rlmbgrpl_sec.mb_gr_pl_id
--inner join pl_rat_sec on rlmbrt_sec.rate_code =pl_rat_sec.rate_code WHERE rlmbgrpl_sec.plan_id=@PlanID AND rlmbgrpl_sec.group_id=@GroupID AND
--member_sec.member_id = member_sec.family_id AND rlmbrt_sec.rate_code='F9' AND pl_rat_sec.rate_text=@CoverageTier
--AND (( rlmbrt_sec.exp_rt_date is null ) or  ( rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))) )

SELECT distinct rlmbgrpl_sec.group_id GroupID,rlmbgrpl_sec.plan_id PlanID,rlmbgrpl_sec.member_id MemberID,RTRIM(member_sec.first_name) FirstName,RTRIM(member_sec.last_name) LastName, convert(nvarchar(MAX), member_sec.date_of_birth, 101) DOB 
FROM member_sec
inner join rlplfc_sec on  rlplfc_sec.member_id=member_sec.member_id
inner join rlmbgrpl_sec on rlmbgrpl_sec.mb_gr_pl_id=rlplfc_sec.mb_gr_pl_id
inner join rlmbrt_sec on rlmbrt_sec.mb_gr_pl_id=rlmbgrpl_sec.mb_gr_pl_id
inner join pl_rat_sec on rlmbrt_sec.rate_code =pl_rat_sec.rate_code
 WHERE rlmbgrpl_sec.plan_id=@PlanID AND rlmbgrpl_sec.group_id=@GroupID
 AND
member_sec.member_id = member_sec.family_id 
--AND rlmbrt_sec.rate_code='F9' 
AND pl_rat_sec.rate_text=@CoverageTier
AND (( rlmbrt_sec.exp_rt_date is null ) or  ( rlmbrt_sec.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))) )


SET NOCOUNT OFF 
END