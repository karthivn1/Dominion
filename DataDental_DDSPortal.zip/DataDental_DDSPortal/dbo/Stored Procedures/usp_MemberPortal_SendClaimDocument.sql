﻿CREATE PROC [dbo].[usp_MemberPortal_SendClaimDocument]
(
@CreatedBy varchar(max),
@MessageDetails dbo.MessageDetails readonly
)
AS
BEGIN
DECLARE @ISDELETED BIT=(SELECT is_delete FROM @MessageDetails)
DECLARE @ISREAD BIT=(SELECT is_read FROM @MessageDetails)
declare @userId varchar(20)
select @userId= user_id from member_user_details where user_name=@CreatedBy
IF (@ISDELETED=0 AND @ISREAD=0)
BEGIN
DECLARE @MessageID INT
INSERT INTO member_message(message,message_subject,parentid,message_type_id,created_by,created_date,from_address)
SELECT message,message_subject,parentid,message_type_id,@userId,GETDATE(),from_address from @MessageDetails

SET @MessageID=SCOPE_IDENTITY()

INSERT INTO member_message_detail(message_id,message_receiver_id,received_date,is_read,is_new,is_delete,is_reply)
SELECT @MessageID,@userId,GETDATE(),is_read,is_new,is_delete,is_reply from @MessageDetails

INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
VALUES (@MessageID,1,1001,0,CONVERT(date,GETDATE()));

SELECT * FROM message
END
ELSE
BEGIN
IF (@ISREAD=0)
BEGIN
UPDATE md SET md.is_delete=@ISDELETED FROM member_message_detail md JOIN @MessageDetails mudt ON
md.message_id=mudt.parentid
END
END

IF (@ISREAD=1)
BEGIN

UPDATE md SET md.is_read=@ISREAD,md.is_new=0 FROM member_message_detail md JOIN @MessageDetails mudt ON
md.message_id=mudt.parentid

END

END