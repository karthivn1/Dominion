﻿-- =============================================
-- Author:		chandu
-- Create date: <30-August-2016>
-- Description:	<This sp is used to get list of plans for the plan search criteria>
-- =============================================
CREATE PROCEDURE [dbo].[usp_PlanSearch]
(
@planName varchar(50) = NULL,
@planId INT = NULL,
@extensionName varchar(50) = NULL,
@displayName varchar(50) = NULL,
@basePlan varchar(5) = NULL,
@baseId INT = NULL,
@baseName varchar(50) = NULL,
@insuranceType varchar(20) = NULL,
@insuranceOption varchar(20) = NULL,
@idCardMessage varchar(20) = NULL,
@tieredBenefits SMALLINT = NULL,
@rollOver SMALLINT = NULL,
@qualifier varchar(5) =NULL,
@activeStates int = NULL
)
AS
BEGIN	
	SET NOCOUNT ON;	
	SELECT plan_a.[plan_id] AS PlanId    
      ,plan_a.[plan_name] AS PlanName
      ,plan_a.[plan_ext] AS ExtensionName
	  ,plan_a.[plan_dsp_name] AS DisplayName
	  ,plan_a.[base_plan] AS BasePlan
	  ,plan_a.[plan_ext_id] AS BaseId
	  --,plan_a.[plan_name] AS BaseName
	  ,plan_b.[plan_name] AS BaseName
      ,plan_a.[ins_type] AS InsuranceType
      ,plan_a.[ins_opt]	 AS InsuranceOption
	  ,InsuranceOption.ins_opt_qual AS Qualifier  
  FROM [dbo].[plan] plan_a (NOLOCK)
  INNER JOIN [dbo].[ins_opt] InsuranceOption (NOLOCK)
  ON InsuranceOption.ins_opt = plan_a.ins_opt
  LEFT OUTER JOIN [dbo].[plan] plan_b (NOLOCK)
  ON plan_b.plan_id = plan_a.plan_ext_id
  cross apply (select count(*) rowcnt from plx_state where status = 'A' and plx_state.exp_date is Null and plx_state.plan_id = plan_a.plan_id) plx_state
  WHERE plan_a.plan_id = ISNULL(@planId,plan_a.plan_id)

 --AND ((plan_a.plan_dsp_name IS NULL) OR  (plan_a.plan_dsp_name = ISNULL(@displayName,plan_a.plan_dsp_name)))
  AND ((plan_a.plan_dsp_name IS NULL) OR  (LOWER(plan_a.plan_dsp_name) = ISNULL(LOWER(@displayName),LOWER(plan_a.plan_dsp_name))) OR (@displayName is not null and LOWER(plan_a.plan_dsp_name) like LOWER(@displayName)+'%'))

-- AND ((plan_a.plan_ext IS NULL AND @extensionName IS NULL) OR (plan_a.plan_ext = ISNULL(@extensionName,plan_a.plan_ext)))
 AND ((plan_a.plan_ext IS NULL AND @extensionName IS NULL) OR (LOWER(plan_a.plan_ext) = ISNULL(LOWER(@extensionName),LOWER(plan_a.plan_ext))) OR (@extensionName is not null and LOWER(plan_a.plan_ext) like LOWER(@extensionName)+'%'))

 --AND ((plan_a.plan_name IS NULL AND @planName IS NULL) OR (plan_a.plan_name	= ISNULL(@planName,plan_a.plan_name)))
 AND ((plan_a.plan_name IS NULL AND @planName IS NULL) OR (LOWER(plan_a.plan_name) = ISNULL(LOWER(@planName),LOWER(plan_a.plan_name))) OR (@planName is not null and LOWER(plan_a.plan_name) like LOWER(@planName)+'%'))

 --AND ((plan_a.base_plan IS NULL) OR (plan_a.base_plan =  ISNULL(@baseName,plan_a.base_plan)))
  AND ((plan_a.base_plan IS NULL) OR (plan_a.base_plan =  ISNULL(@basePlan,plan_a.base_plan)) )

 AND ((plan_a.plan_ext_id IS NULL AND @baseId IS NULL) OR (plan_a.plan_ext_id = ISNULL(@baseId,plan_a.plan_ext_id)))

 --AND ((plan_a.plan_ext_id=0) OR (plan_a.plan_ext_id IS NULL AND @baseName IS NULL) OR (plan_b.plan_name = ISNULL(@baseName,plan_b.plan_name)))
  AND ((plan_b.plan_name IS NULL AND @baseName IS NULL) OR (LOWER(plan_b.plan_name) = ISNULL(LOWER(@baseName),LOWER(plan_b.plan_name))) OR (@baseName is not null and LOWER(plan_b.plan_name) like LOWER(@baseName)+'%'))

 AND ((plan_a.ins_type IS NULL) OR (plan_a.ins_type = ISNULL(@insuranceType,plan_a.ins_type)))
 AND ((plan_a.ins_opt IS NULL) OR (plan_a.ins_opt = ISNULL(@insuranceOption,plan_a.ins_opt)))
 AND ((plan_a.id_card_msg IS NULL AND @idCardMessage IS NULL) OR (plan_a.id_card_msg = ISNULL(@idCardMessage,plan_a.id_card_msg)))
 AND ((plan_a.tiered_sw IS NULL) OR (plan_a.tiered_sw = ISNULL(@tieredBenefits,plan_a.tiered_sw)))
 AND ((plan_a.rollover_sw IS NULL) OR (plan_a.rollover_sw = ISNULL(@rollOver,plan_a.rollover_sw)))
 AND ((InsuranceOption.ins_opt_qual IS NULL) OR (InsuranceOption.ins_opt_qual = ISNULL(@qualifier, InsuranceOption.ins_opt_qual)))
 AND (plx_state.rowcnt) = ISNULL(@activeStates,plx_state.rowcnt)
 
SET NOCOUNT OFF 
END