﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetImsDocTableColumns]
	-- Add the parameters for the stored procedure here
@DocType INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here

	SELECT k.key_no AS KeyNumber,k.[key_name] AS KeyName
		FROM lkp_doctype l
		JOIN lkp_dockeys k ON k.doc_type_Id=l.Id  
		WHERE l.doc_no=@DocType
		AND k.key_no in(171, 172, 702, 753, 754, 710, 1063, 1064, 785,
		179, 180, 728, 732, 731,
		1147, 1148, 1159)
		

END