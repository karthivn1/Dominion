﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_GetUserInfoForMailJob 24,'member_user_details'
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetUserInfoForMailJob]
@ref_id INT,
@ref_object nVarchar(100)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
DECLARE @errorMsg NVARCHAR(100)='';

    -- Insert statements for procedure here

IF OBJECT_ID(@ref_object) IS NOT NULL
BEGIN
	DECLARE @ParmDefinition NVARCHAR(500);
	DECLARE @sqlStr NVARCHAR(1000)='';

	SET @sqlStr='Select s.user_name AS UserName,s.last_name AS FirstName,s.email AS Email,u.status AS User_Status 
				 From '+ @ref_object +' s 
				 JOIN user_status_master u ON s.status_id =u.status_id
				 WHERE s.[user_id]=@ref_id'

	SET @ParmDefinition = N'@ref_id int';

	EXECUTE sp_executesql @sqlStr,@ParmDefinition,@ref_id=@ref_id

END	
ELSE
BEGIN
	SET @errorMsg='Object Not Found'+ @ref_object
	RAISERROR (@errorMsg,1,16)
	RETURN
 END
END