﻿-- =============================================
-- Author:		<Sankar M V>
-- Create date: <04-Jan-2017>
-- Description:	<This stored procedure is used to get Subscriber list for the given search criteria>
-- =============================================
CREATE PROCEDURE [dbo].[usp_sub_SubscriberSearch]
(	 
		 @LastName varchar(50) = NULL,   
         @MemberId int = NULL, 	
		 @DOB datetime = NULL,
		 @EffectiveDate datetime = NULL,
		 @GroupId int =NULL,
		 @PlanId int = NULL
)
AS
BEGIN
SET NOCOUNT ON
		SELECT DISTINCT 
			 member.member_id AS MemberId, 
			 member.last_name AS LastName,  		 
			 member.first_name AS FirstName,   
			 member.date_of_birth AS DOB,   
			 pl_rat.rate_short_desc AS 'CoverageTier',
			 pln.plan_name AS PlanName,
			 pln.plan_id AS PlanId,
			 rlmbrt.eff_rt_date AS EffectiveDate,
			 rlmbrt.exp_rt_date AS TermDate,
			 grp.group_id AS GroupId,
			CAST(RTRIM(fac.fc_name) AS VARCHAR(100)) + ' - '  + CAST(fac.fc_id AS VARCHAR(100))   AS Facility
	    FROM [dbo].member_sec member
			 INNER JOIN [dbo].rlmbgrpl_sec rlmbgrpl ON  rlmbgrpl.member_id = member.member_id
			 INNER JOIN dbo.[group_sec] grp ON grp.group_id = rlmbgrpl.group_id
			 INNER JOIN [dbo].rlmbrt_sec rlmbrt ON rlmbrt.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id
			 INNER JOIN  [dbo].[plan_sec] pln ON pln.plan_id = rlmbgrpl.plan_id
			 INNER JOIN [dbo].pl_rat_sec pl_rat ON rlmbrt.rate_code = pl_rat.rate_code
			 INNER JOIN [dbo].[rlplfc_sec] rlplfc ON rlplfc.mb_gr_pl_id = rlmbgrpl.mb_gr_pl_id
			 INNER JOIN [dbo].[facility_sec] fac ON fac.fc_id = rlplfc.facility_id 
        WHERE  
		grp.group_id = @GroupId AND pln.plan_id = @PlanId
		AND  member.member_id = ISNULL(@MemberId,member.member_id) 	
		AND ((@LastName IS NULL AND (member.last_name=member.last_name or member.last_name is null)) 
			OR (@LastName IS NOT NULL AND  member.last_name=@LastName))
	    AND ((@DOB IS NULL AND (member.date_of_birth=member.date_of_birth or member.date_of_birth is null)) 
			OR (@DOB IS NOT NULL AND  member.date_of_birth=@DOB))
	    AND ((@EffectiveDate IS NULL AND (rlmbrt.eff_rt_date=rlmbrt.eff_rt_date or rlmbrt.eff_rt_date is null)) 
			OR (@EffectiveDate IS NOT NULL AND rlmbrt.eff_rt_date=@EffectiveDate))
		AND rlplfc.exp_date is NULL
	    AND (rlmbrt.exp_rt_date IS NULL OR rlmbrt.exp_rt_date>=DATEADD(m, -3, GETDATE()))

SET NOCOUNT OFF
END