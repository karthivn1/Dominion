﻿CREATE PROCEDURE [dbo].[usp_AuthorizeNetProfileReport]
(
@fromDate DATETIME,
@toDate DATETIME
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @AuthorizeNetProfile TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(MAX),
Token VARCHAR(MAX),
Date VARCHAR(MAX)
)

INSERT INTO @AuthorizeNetProfile(GroupID ,Token ,Date)

SELECT CONVERT(varchar(MAX), group_id),customer_profile+','+payment_profile,	
CONVERT(nvarchar(MAX),created_date, 101)+' '+CONVERT(nvarchar(MAX),FORMAT(CAST(created_date AS DATETIME),'hh:mm:ss tt')) from authorize_net_profile WHERE created_date BETWEEN @fromDate AND @toDate

SELECT * FROM @AuthorizeNetProfile

SET NOCOUNT OFF 
END