﻿CREATE PROCEDURE [dbo].[usp_GetEditDependentDetails] 
(
@GroupID INT,
@PlanID INT,
@MemberID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @DependentDetails TABLE
(
id INT IDENTITY(1,1),
GroupID VARCHAR(MAX),
PlanID VARCHAR(MAX),
MemberID VARCHAR(MAX),
FirstName VARCHAR(MAX),
LastName VARCHAR(MAX),
MiddleInitial VARCHAR(MAX),
DOB VARCHAR(50),
Gender VARCHAR(50),
MemberType VARCHAR(50)
)

DECLARE @GroupDetails TABLE
(
id INT IDENTITY(1,1),
PlanID INT NULL,
PlanName VARCHAR(MAX),
PlanType VARCHAR(MAX),
RenewalDate VARCHAR(50),
EmailNotifications VARCHAR(50),
PaperlessNotifications VARCHAR(50),
GroupID VARCHAR(50),
GroupName VARCHAR(MAX),
Address VARCHAR(MAX),
Phone VARCHAR(MAX),
Email VARCHAR(MAX)
)


INSERT INTO @DependentDetails(GroupID,PlanID,MemberID,FirstName,LastName,MiddleInitial,DOB,Gender,MemberType)

SELECT @GroupID,@PlanID,mem.member_id,RTRIM(mem.first_name),RTRIM(mem.last_name),RTRIM(mem.middle_init),
convert(nvarchar(MAX),  mem.date_of_birth, 101),
RTRIM(mbrcode.gender),RTRIM(mbrcode.mbr_code_desc)
FROM member_sec mem LEFT JOIN mbr_code_sec mbrcode ON mem.member_code=mbrcode.mbr_code
WHERE mem.member_id=@MemberID 

INSERT INTO @GroupDetails(PlanID,PlanName,PlanType,RenewalDate,EmailNotifications,PaperlessNotifications,GroupID,GroupName,Address,Phone,Email)

SELECT tbl_plan.plan_id,RTRIM(tbl_plan.plan_name),RTRIM(tbl_plan.ins_type) as plan_type,
convert(nvarchar(MAX),grp.next_renew_date, 101),
'YES',
'NO',
grp.group_id,RTRIM(grp.group_name),RTRIM(ISNULL(tbl_address.addr1,'')) + + RTRIM(ISNULL(tbl_address.addr2,'')) + +RTRIM(ISNULL(tbl_address.city,'')) + ' '+RTRIM(ISNULL(tbl_address.country,'')) +' , '+RTRIM(ISNULL(tbl_address.[state],'')) +' '+RTRIM(ISNULL(tbl_address.zip,'')) as addresss,
RTRIM(tbl_contact.phone1),RTRIM(tbl_contact.email)
FROM group_sec grp 
JOIN rel_gppl_sec rgroupplan ON rgroupplan.group_id =grp.group_id
JOIN  plan_sec tbl_plan ON tbl_plan.plan_id =rgroupplan.plan_id 
LEFT JOIN address_sec tbl_address  ON grp.group_id = tbl_address.sys_rec_id AND tbl_address.subsys_code = 'GP'AND tbl_address.addr_type ='L'
LEFT JOIN contact_sec tbl_contact  ON grp.group_id = tbl_contact.sys_rec_id AND  tbl_contact.subsys_code='GP'  
JOIN group_status_sec tbl_status ON tbl_status.group_id = grp.group_id
--JOIN group_rules tbl_group_rules ON tbl_group_rules.group_id=grp.group_id 
JOIN typ_table_sec typ on typ.code = tbl_plan.ins_type AND typ.subsys_code='PL' AND typ.tab_name='ins_type'
WHERE grp.group_id =@GroupID AND tbl_plan.plan_id =@PlanID 


SELECT * FROM @DependentDetails

SELECT * FROM @GroupDetails

SELECT * FROM @GroupDetails

SET NOCOUNT OFF 
END