﻿

-- =============================================
-- Author:		V.M.HEMANANTH
-- Create date:  02/JAN/2017
-- Description:	 TO SAVE THE MEMBER AND RETURN THE MEMBER ID 
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_SaveMember]
	-- Add the parameters for the stored procedure here
	(@family_id           INT,
	 @alt_id              VARCHAR (20) =NULL, 
	 @member_code         INT, 
	 @first_name          VARCHAR (15), 
	 @middle_init         VARCHAR (1), 
	 @last_name           VARCHAR (15), 
	 @date_of_birth       DATE =NULL,
	 @member_ssn          VARCHAR (11), 
	 @oed                 DATE =NULL,
	 @student_flag        VARCHAR (1),       
	 @disable_flag        VARCHAR (1),
	 @action_code         VARCHAR (2),
	 @h_datetime          DATE =NULL,  
	 @h_action            VARCHAR (2), 
	 @h_user              VARCHAR (10), 
	 @hire_date           DATE =NULL,
	 @new_ssn             VARCHAR (11), 
	 @source_id           VARCHAR (20),
	 @ext_id_type         VARCHAR (2),
	 @paperless           VARCHAR (1),
	 @student_exp       DATE =NULL,
	 @addr_type          VARCHAR (15) = NULL,
	 @addr1              VARCHAR (30) = NULL,
	 @addr2              VARCHAR (30) = NULL,
	 @city               VARCHAR (15) = NULL,
	 @country            VARCHAR (30) = NULL,
	 @county             VARCHAR (30) = NULL,
	 @state              VARCHAR (30) = NULL,
	 @zip                VARCHAR (15) = NULL,
	 @home_phone         VARCHAR (30) = NULL,
     @home_ext           VARCHAR (30) = NULL,
     @work_phone         VARCHAR (30) = NULL,
     @work_ext           VARCHAR (30) = NULL,
     @fax                VARCHAR (30) = NULL,
     @email              VARCHAR (30) = NULL,
	 @newMemberId         INT = NULL OUTPUT)
AS
BEGIN
   DECLARE @hmsi INT;
    DECLARE @addressid INT;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	BEGIN TRAN 
		BEGIN TRY 
    -- Insert statements for procedure here

	SELECT @hmsi = msi +1 FROM sysdatetime;

	 IF(@family_id is null or @family_id = 0)
	    BEGIN
		    --INSERT THE NEW SUBSCRIBER 
	        INSERT INTO member (family_id, 
                                alt_id,
                                member_code,
                                first_name, 
                                middle_init,
                                last_name, 
                                date_of_birth, 
                                member_ssn, 
                                oed, 
                                student_flag, 
                                disable_flag,
                                action_code,
                                h_datetime, 
                                h_msi, 
                                h_action, 
                                h_user, 
                                hire_date,
                                new_ssn, 
                                source_id, 
                                ext_id_type,
                                paperless )
                        VALUES ( @family_id, 
	        					  @alt_id,
	        					  @member_code,
	        					  @first_name, 
	        					  @middle_init,
	        					  @last_name, 
	        					  @date_of_birth, 
	        					  @member_ssn, 
	        					  @oed, 
	        					  @student_flag, 
	        					  @disable_flag,
	        					  @action_code,
	        					  @h_datetime, 
	        					  @hmsi, 
	        					  @h_action, 
	        					  @h_user, 
	        					  @hire_date,
	        					  @new_ssn, 
	        					  @source_id, 
	        					  @ext_id_type,
	        					  @paperless) 
	        
	        					  SET @newMemberId = SCOPE_IDENTITY()

								  Update member set family_id = @newMemberId Where member_id = @newMemberId 

					INSERT INTO address ( subsys_code, 
					          sys_rec_id, 
					          addr_type, 
					          addr1,
							  addr2,
							  city, 
					          country, 
					          county, 
					          state,
					          zip ) 
					          VALUES 
					        ( 'MB',
					          @newMemberId, 
					          @addr_type,
					          @addr1,
							  @addr2,
					          @city, 
					          @country, 
					          @county, 
					          @state,
					          @zip ) 

							SET @addressid = SCOPE_IDENTITY();

     INSERT INTO mbr_phone ( address_id,
	                         home_phone,
							 home_ext,
							 work_phone,
							 work_ext,
							 fax,
							 email) 
	                VALUES ( @addressid,
					         @home_phone,
							 @home_ext,
							 @work_phone,
							 @work_ext,
							 @fax,
							 @email)  

							 
        END
     ELSE
	    BEGIN
		  --INSERT THE NEW DEPENDENT
		  INSERT INTO member (family_id, 
                                alt_id,
                                member_code,
                                first_name, 
                                middle_init,
                                last_name, 
                                date_of_birth, 
                                member_ssn, 
                                oed, 
                                student_flag, 
                                disable_flag,
                                action_code,
                                h_datetime, 
                                h_msi, 
                                h_action, 
                                h_user, 
                                hire_date,
                                new_ssn, 
                                source_id, 
                                ext_id_type,
                                paperless,
								student_exp )
                        VALUES ( @family_id, 
	        					  @alt_id,
	        					  @member_code,
	        					  @first_name, 
	        					  @middle_init,
	        					  @last_name, 
	        					  @date_of_birth, 
	        					  @member_ssn, 
	        					  @oed, 
	        					  @student_flag, 
	        					  @disable_flag,
	        					  @action_code,
	        					  @h_datetime, 
	        					  @hmsi, 
	        					  @h_action, 
	        					  @h_user, 
	        					  @hire_date,
	        					  @new_ssn, 
	        					  @source_id, 
	        					  @ext_id_type,
	        					  @paperless,
								  @student_exp) 
	        
	        					SET @newMemberId = SCOPE_IDENTITY()

					Update member set member_ssn = @newMemberId Where member_id = @newMemberId and ext_id_type =  (select int_1 from typ_table_exp  where subsys_code ='MB' and tab_name = 'ext_id_type' and str_1 = 'member_id') 
		END
		 

		 update sysdatetime set msi = @hmsi

	     Select @newMemberId



	COMMIT TRAN 
	END TRY 

	BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState ) 

	END CATCH 
END