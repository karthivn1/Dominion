﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:5.18.6.	Business Rule: The procedure code dropdown should not list any values until a Procedure Type is selected. The values should be populated corresponding on the Procedure Type selected.
--5.18.7.	Once the user make the appropriate procedure type and code selections, system should check if the member’s plan is a PPO or a HMO to compute the Dentist Fee from the Wsmplantext.txt file. The Plan ID that is member is enrolled and currently under selection should be used to find the Plan Type.
--5.18.8.	When the plan type is HMO, system must match up the portal category, procedure code and procedure short description selected with the records in the CostCalcFeeSched.txt and display the co-pay amount as the fee for the procedure with the most current effective date.
-- exec usp_memberportal_getcostcalculator_details 19711,315,'HMO','','',2,'D1110'
-- exec usp_memberportal_getcostcalculator_details 19711,287,'PPO','','',2,'D0120'
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_getcostcalculator_details]
	-- Add the parameters for the stored procedure here
	(
	@zipcode varchar(10), 
	@planid int ,
	@plantype varchar(5),
	@DentalPracticeID int,
	@DentistName varchar(50),
	@proceduretype int ,
	@procedurecode varchar(5)	
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Declare @averagefee decimal = NULL,
	@dentistsfee decimal = NULL,
	@youpay decimal = NULL,
	@yousave decimal = NULL,
	@percentile int,
	@ProcedureDescription As VARCHAR(500)

	--5.18.7.	Once the user make the appropriate procedure type and code selections, system should check if the member’s plan is a PPO or a HMO to compute the Dentist Fee from the Wsmplantext.txt file. The Plan ID that is member is enrolled and currently under selection should be used to find the Plan Type.
	DECLARE @PlanTypeDetails AS VARCHAR(15),
			@CopayAmount DECIMAL,
			@FeeSchedAmount Decimal,
			@PercentageCover DECIMAL(6,2)

	Select @PlanTypeDetails =RTRIM(LTRIM(ISNULL(PlanType,''))) from tbl_CostCalc_Plan where PlanID = @planid

	IF(@PlanTypeDetails = 'HMO' OR @PlanTypeDetails='DHMO')
		BEGIN

			--5.18.8 When the plan type is HMO, system must match up the portal category, 
			--       procedure code and procedure short description selected with the records in the CostCalcFeeSched.txt 
			--       and display the co-pay amount as the fee for the procedure with the most current effective date

			IF EXISTS(SELECT 1 FROM [tbl_CostCalc_FeeSched] (NOLOCK) WHERE ProcCode= @procedurecode AND CategoryNum = @proceduretype AND  PlanID=@planid  AND  PlanType='HMO')
			BEGIN
				SELECT TOP 1 @CopayAmount =  ISNULL(CoPayAmount,0)  FROM [tbl_CostCalc_FeeSched] (NOLOCK)
				WHERE ProcCode= @procedurecode AND CategoryNum = @proceduretype AND  PlanID=@planid  AND  PlanType='HMO' ORDER BY EffectiveDate DESC

				SET @dentistsfee = @CopayAmount;
			END

		END
	ELSE IF (@PlanTypeDetails = 'PPO')
		BEGIN

		--5.18.9. When the plan type is PPO, fee schedule amount and calculates the member’s cost share based on the plan coverage amount for that procedure
		--5.18.10.For PPO (Access Plan), system follows the following logic.
			--1)  From the CostCalcFeeSched.txt, the fee schedule amount is retrieved for the plan ID and the procedure code.
			--2)  The covperc.txt has the procedure code, plan ID and percentage cover
			--3)  If the covered percentage from covperc.txt is 100, the dentists fee is same as what is on the CostCalcFeeSched.txt, else if it is 80 or a 50, 
			--	  then it would be the covered percentage * fee schedule amount.

				IF EXISTS(SELECT 1 FROM [tbl_CostCalc_FeeSched] (NOLOCK) WHERE ProcCode= @procedurecode AND PlanID=@planid AND PlanType='PPO')
				BEGIN
					SELECT @FeeSchedAmount =  ISNULL(FeeSchedAmount,0)  FROM [tbl_CostCalc_FeeSched] (NOLOCK)
					WHERE ProcCode= @procedurecode AND PlanID=@planid AND PlanType='PPO'

					SELECT @PercentageCover= PercentCover FROM tbl_CostCalc_CoverPercent (NOLOCK) 
					WHERE ProcCode=@procedurecode AND PlanID=@planid
		
					IF(@PercentageCover !=100.00)
						BEGIN
							SET @dentistsfee = (@FeeSchedAmount * @PercentageCover)/100;
						END
					ELSE
						SET @dentistsfee = @FeeSchedAmount
				END
				
		END

	SET @percentile = 80
	
	-- Get the fee schedule amount for the member procedure code
	SELECT @averagefee = isnull(fee_sched_d.amount,0)  FROM fee_sched_h fee_sched_h
	INNER JOIN  fee_sched_d  fee_sched_d on fee_sched_h.fee_sched_id = fee_sched_d.fee_sched_id
	INNER JOIN  fee_source  fee_source on fee_sched_h.fee_sched_id = fee_source.fee_sched_id
	WHERE 
		fee_sched_h.fee_sched_id = fee_sched_d.fee_sched_id AND
		fee_sched_h.fee_sched_id = fee_source.fee_sched_id AND
		fee_sched_h.exp_date IS NULL AND
		fee_source.exp_date IS NULL AND
		fee_sched_h.eff_date <= GetDate() AND-- ****** Need to check this 
		fee_sched_d.d_proc_code = @procedurecode AND --proc_code 
		fee_source.zip_code_3 = LEFT( @zipcode,3) AND --  First 3 digit member zip code
		fee_source.percentile = @percentile 
	ORDER BY fee_sched_h.eff_date DESC 

	--ProcedureDescription



	SELECT @ProcedureDescription = d_proc_sd 
	FROM plx_dent_proc prod
	WHERE d_proc_code = @procedurecode
	--INNER JOIN plx_dent_subcat subcat ON subcat.d_subcat_id= prod.d_subcat_id
	--INNER JOIN plx_dent_cat cat ON subcat.d_cat_id= cat.d_cat_id
	--WHERE LTRIM(RTRIM( cat.d_cat_sd  )) in (select  category_sd FROM [member_cost_calc_proc_type_category_mapping] 
	--WHERE portal_category_number= @proceduretype) and d_proc_code = @procedurecode




	--Bug 1609: Non Covered Procedure should still display an Average Fee, Should have 'N/A' under Dentist's Fee, 'Not Coverd' under You Pay and 'N/A' under You Save.	

	--Updated 5.18.12c/d/e:  sections in member portal BRD based on current ANDA portal logic
	--						 When Average Fee is 0.00 or NULL (Blank), Dentist Fee should be “N/A”, You pay should be  “Not Covered” & You save should be “N/A”. 
	--						 For all other values, system must calculate Dentist Fee based on existing logic in BRD.
    --						 If Dentist Fee is 0.00, then You pay =Dentist Fee (i.e 0.00) and  You save =Average Fee

	--Difference between the averages cost of procedure and ‘You pay’ value

	IF(@dentistsfee IS NOT NULL AND @averagefee IS NOT NULL )
		SET @yousave = isnull(@averagefee,0) - isnull( @dentistsfee,0) ;

	IF(@averagefee IS NULL OR @averagefee=0)
	BEGIN
		SET @dentistsfee= NULL;
		SET @yousave= NULL;
	END


    
	SELECT 
	 ISNULL('$'+CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),@averagefee)),'N/A')  AverageFee, 	

	CASE @dentistsfee 
		WHEN 0 THEN '$0.00' 
		ELSE ISNULL('$'+CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),@dentistsfee)),'N/A')  --N/A
	END DentistFee,
	

	CASE @dentistsfee 
		WHEN 0 THEN '$0.00'	
		ELSE   ISNULL('$'+CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),@dentistsfee)),'Not Covered') --Not Covered
	END YouPay,

	
	CASE @yousave 
		WHEN 0 THEN '$0.00' 
		ELSE ISNULL('$'+ CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),@yousave)),'N/A') --N/A
	end  YouSave,	

	ISNULL(@percentile,0) Percentile,@ProcedureDescription ProcedureDescription

END