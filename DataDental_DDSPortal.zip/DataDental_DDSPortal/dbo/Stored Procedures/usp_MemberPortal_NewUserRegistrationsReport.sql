﻿CREATE PROCEDURE [dbo].[usp_MemberPortal_NewUserRegistrationsReport]
(
@fromDate DATETIME,
@toDate DATETIME
)
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @NewUserList TABLE
(
id INT IDENTITY(1,1),
LastName VARCHAR(MAX),
FirstName VARCHAR(max),
Email VARCHAR(max),
Type VARCHAR(max),
Status VARCHAR(max),
RegistrationDate DATETIME NULL,
GroupID int,
MemberID int
)

INSERT INTO @NewUserList(LastName ,FirstName ,Email ,Type ,Status,RegistrationDate,GroupID,MemberID)

select gud.last_name COLLATE database_default ,gud.first_name COLLATE database_default,gud.email COLLATE database_default,rm.role_name COLLATE database_default, usm.status COLLATE database_default,gud.created_date,gud.group_id,null   from group_user_details gud 
JOIN user_status_master usm ON gud.status_id=usm.status_id 
JOIN role_master rm on gud.role_id =rm.role_id
WHERE gud.created_date BETWEEN @fromDate AND @toDate
and gud.status_id in (1,2) and gud.role_id in(1)
union

select gud.last_name COLLATE database_default,gud.first_name COLLATE database_default ,gud.email COLLATE database_default,rm.role_name COLLATE database_default,
usm.status COLLATE database_default,gud.created_date ,gud.group_id ,gud.member_id  from member_user_details gud 
JOIN user_status_master usm ON gud.status_id=usm.status_id 
JOIN role_master rm on gud.role_id =rm.role_id
WHERE gud.created_date BETWEEN @fromDate AND @toDate
and gud.status_id in (1,2) and gud.role_id in (4,5)

SELECT * FROM @NewUserList

SET NOCOUNT OFF 
END