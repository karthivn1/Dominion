﻿CREATE PROCEDURE [dbo].[usp_ForgotPassword_updateuserdetailsandBatch]
(
@userName varchar(max),
@hashpassword varchar(max)
)
AS
BEGIN
SET NOCOUNT ON;
Declare  @Errormsg varchar(max)=NuLL;
Declare  @Pwdresetdate varchar(max) = NuLL;
Declare @statusId int=null;
declare @userId int;
declare @email varchar(100);
declare @charlen int;
 Declare @temp varchar(max) = NuLL;

 select  @userId=[user_id],@email=email 
	from group_user_details  
	where UPPER(user_name)=UPPER(@userName)

 select @statusId=status_id 
	from user_status_master 
	where status='Pending' and portal_type='grp'

 if(LEN(@email)>0)
 begin
	set @charlen=(select CHARINDEX('@',@email))
	set @email = (select LEFT(@email, 1)+'****'+SUBSTRING(@email,@charlen-1,LEN(@email)))
 end

IF NOT Exists(select user_id as UserID, user_name as UserName from group_user_details  where user_id=@userId)
Begin
 set @Errormsg= 'Username is invalid.';
End
else
Begin

If Exists( select  user_id as UserID, user_name as UserName, password_hash as Password,status_id as Status,
					is_firstlogin as ISFirstLogin,temp_password as TempPassword 
					from group_user_details  
					where UPPER(user_name)=UPPER(@userName)
					and status_id =@statusId 
					and temp_password IS NOT NULL )
Begin


Select @Pwdresetdate= ISNULL(CONVERT(VARCHAR(MAX),forgot_password_time,101),'')
	From group_user_details
	WHERE UPPER(user_name)=UPPER(@userName)
	AND forgot_password_time IS NOT NULL

--set @Pwdresetdate=(select convert(varchar(max),(select ISNULL(forgot_password_time,' ')
--		from group_user_details  
--		where user_name = @userName 
--		and forgot_password_time  is not NULL),101 ));
 
 --set @temp=(select Len(@Pwdresetdate))
 --if (@temp IS NULL)
 --Begin
 --set @temp=' '
 --End
 --else
 --set @temp=@Pwdresetdate
 --print @temp

 set @Errormsg= 'A new password was requested for this account on ' + @Pwdresetdate +'. We sent out an email .Please wait before trying again. Please check your email and your spam folders for instructions.';
 update group_user_details set forgot_password_time =convert(date,getdate()) where user_id=@userId 
 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,2,1001,0,getdate());
End

else
Begin

If Exists(select  user_id as UserID, user_name as UserName, password_hash as Password,status_id as Status,
	is_firstlogin as ISFirstLogin,temp_password as TempPassword 
	from group_user_details  
	where UPPER(user_name)=UPPER(@userName) and status_id =1)
Begin
  set @Errormsg= 'Activate-'+@email;

 update group_user_details set temp_password=@hashpassword,status_id=@statusId,forgot_password_time =convert(date,getdate()) where user_id=@userId 
 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,2,1001,0,getdate())
End
End
End

If (@Errormsg IS NULL)
Begin
 set @Errormsg= 'Your account is locked, Please contact our Group Service Center at ‘888.518.5338’or email dds_techsupport@dominionnational.com to have your account unlocked’';
 insert into batch_process_details (ref_id,event_id,status,retry,created_date)values (@userId,16,1001,0,getdate())
End
 DECLARE @Err as table
(
 ErrMsg varchar(max)
)
INSERT INTO @Err(ErrMsg)VALUES(@Errormsg)
SELECT * FROM @Err

SET NOCOUNT OFF
END