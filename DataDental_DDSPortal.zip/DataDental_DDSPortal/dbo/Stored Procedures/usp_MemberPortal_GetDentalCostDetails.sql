﻿CREATE PROCEDURE [dbo].[usp_MemberPortal_GetDentalCostDetails] 
(
@GroupID INT,
@PlanID INT,
@MemberID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @CostCalculatorDetails TABLE
(
id INT IDENTITY(1,1),
ZipCode VARCHAR(50),
DentalPracticeID VARCHAR(MAX),
DentistName VARCHAR(MAX)
)


INSERT INTO @CostCalculatorDetails(ZipCode,DentalPracticeID,DentistName)

SELECT top 1 addr.zip, fc.fc_id, fc.fc_name 
from rlmbgrpl_sec rel 
Left join rlplfc_sec rlfc on rlfc.mb_gr_pl_id=rel.mb_gr_pl_id
Left join facility_sec fc on fc.fc_id=rlfc.facility_id
inner join [address_sec] addr on addr.sys_rec_id=rel.member_id and addr.subsys_code='MB'
WHERE rlfc.exp_date is null and rel.member_id=@MemberID and rel.group_id=@GroupID and rel.plan_id=@PlanID

SELECT * FROM @CostCalculatorDetails

SELECT CategoryNum PortalCategoryNumber,CategoryName PortalCategory from tbl_CostCalc_Category

SET NOCOUNT OFF 
END