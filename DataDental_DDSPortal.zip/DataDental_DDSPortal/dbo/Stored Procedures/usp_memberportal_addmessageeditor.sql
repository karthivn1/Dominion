﻿
-- =============================================
-- Author:		<Rajthilak.S, 597994>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_memberportal_addmessageeditor 'test','Hi','All Users',0,null,null,'LDKerr'
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_addmessageeditor] 
	-- Add the parameters for the stored procedure here
	(
@subject as Varchar(max),
@body as Varchar(max),
@toEmail as Varchar(25),
@memberid as int,
@state as Varchar(50) = NULL,
@plan as Varchar(50) = NULL,
@createdby Varchar(20) 
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Begin try
		BEGIN TRAN 
		  DECLARE @messageid int
		  Declare @userId int
		  DECLARE @statusid int
		  SELECT @userId =  user_id from member_user_details where user_name =@createdby
		  select @statusid =status_id from user_status_master where [status] ='Deactivated'
		  Insert into [member_message] ([message],message_subject,message_type_id,from_address,created_by,created_date)
		  values (@body,@subject,1,'Admin',@userId,GETDATE())
		  SET @messageid =@@IDENTITY;
		  update [member_message] SET parentid = @messageid where message_id = @messageid 

		  DECLARE @ListofIDs TABLE(Id INT IDENTITY(1, 1),UserID VARCHAR(100), role_id int);

				    IF @toEmail = 'Individual User'
						BEGIN
				  			INSERT INTO @ListofIDs(UserID)
		      		        select [user_id] from member_user_details where member_id= @memberid;
					    END
		           ElSE IF @toEmail = 'DDS Users'
						BEGIN
							INSERT INTO @ListofIDs(UserID,role_id) SELECT [user_id],role_id from member_user_details  where role_id in (SELECT role_id from role_master where (role_name ='DDS' OR role_name='DDS Admin')) and status_id <> @statusid
							
						END
					ELSE IF @toEmail = 'All Users'
						BEGIN
							INSERT INTO @ListofIDs(UserID,role_id) SELECT [user_id],role_id from member_user_details where status_id <> @statusid
							
						END
				    ELSE IF @toEmail = 'All Members'
						BEGIN
							INSERT INTO @ListofIDs(UserID,role_id) SELECT [user_id],role_id from member_user_details where role_id in (SELECT role_id from role_master where (role_name ='Member SG' OR role_name='Member EG')) and status_id <> @statusid
						END
				    ELSE IF @toEmail = 'All SG Members'
						BEGIN
							INSERT INTO @ListofIDs(UserID,role_id) SELECT [user_id],role_id from member_user_details where role_id = (SELECT role_id from role_master where role_name ='Member SG') and status_id <> @statusid
						END
					ELSE IF @toEmail = 'All EG Members'
						BEGIN
							INSERT INTO @ListofIDs(UserID,role_id) SELECT [user_id],role_id from member_user_details where role_id = (SELECT role_id from role_master where role_name ='Member EG') and status_id <> @statusid
						END
					 IF @state <>'' 
						BEGIN
							 Delete from @ListofIDs where role_id<>2 and role_id<>3 and UserID not in (
							 SELECT [user_id] from member_user_details usr inner join member_sec mbr on usr.member_id=mbr.member_id
							 inner join address_sec addr on mbr.member_id=addr.sys_rec_id
							 where addr.subsys_code='MB' and addr.state=@state
							)

						END
				     IF @plan <>'' 
						BEGIN
						     Delete from @ListofIDs where role_id<>2 and role_id<>3 and UserID not in(
							 SELECT [user_id] from member_user_details usr inner join member_sec mbr on usr.member_id=mbr.member_id
							 inner join rlmbgrpl_sec rel on rel.member_id=mbr.member_id
							 inner join [plan_sec] pln on pln.plan_id=rel.plan_id
							 where pln.ins_opt=@plan)
						END

				Declare @eventId int
				DECLARE @userIds int
				select @eventId = event_id from event_master where event_category='MessageEditor' and event_module='MP'

				

				IF EXISTS(SELECT UserID from  @ListofIDs)
				BEGIN
					Insert into [member_message_detail] (message_id,message_receiver_id,received_date,is_read,is_new,is_delete,is_reply)
					SELECT @messageid,UserID,GETDATE(),0,1,0,0 from  @ListofIDs 
				END


			 --   DECLARE message_cursor CURSOR FOR   
				--SELECT UserID from  @ListofIDs

				--OPEN message_cursor  
				--FETCH NEXT FROM message_cursor INTO @userIds  

				--WHILE @@FETCH_STATUS = 0  
				--BEGIN  
				--	Insert into [member_message_detail] (message_id,message_receiver_id,received_date,is_read,is_new,is_delete,is_reply) values
				--	(@messageid,@userIds,GETDATE(),0,1,0,0)

				
					
				--	FETCH NEXT FROM message_cursor INTO @userIds  
				--END  
				--CLOSE message_cursor  
				--DEALLOCATE message_cursor  

					insert into batch_process_details (ref_id,event_id,status,retry,created_date) values
					(@messageid,@eventId,1001,0,convert(date,getdate()));
				Select @messageid;

		COMMIT 
   end try
   Begin Catch
		ROLLBACK
   End catch
END