﻿CREATE procedure [dbo].[usp_memberportal_securityquestionlist](
@SecurityDetails SecurityDetails Readonly
)
AS
begin
Begin Transaction[securityanswer]
SET NOCOUNT ON

 Begin try
 
 select * into #tempsecurityanswer from @SecurityDetails

 if exists(select * from  #tempsecurityanswer)
 begin
  insert into user_security_detail (security_question_id,answer,question_order,user_id,created_date)  select security_question_id ,answer ,question_order ,user_id,getdate()as created_date  from #tempsecurityanswer 
    select  @@RowCount
 end
 update member_user_details set is_firstlogin=0 where user_id in (
 select user_id  from #tempsecurityanswer )

commit Transaction [securityanswer]
   End try
Begin Catch
rollback Transaction [securityanswer]
End Catch


SET NOCOUNT OFF
end