﻿-- =============================================
-- Author:		<Selvakumar.K>
-- Create date: <04-01-2017>
-- Description:	<This SP is used to Save the Activated Susbcriber Details >
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_ActivateSubscriber]
(
@memberId INT=NULL,
@memberGroupPlanId INT=NULL,
@groupId INT=NULL,
@planId INT=NULL,
@effDate DATETIME=NULL,
@actionCode VARCHAR(100)=NULL,
@hUser VARCHAR(100)=NULL,
@SiP INT=NULL,
@rateCode VARCHAR(100)=NULL, 
@groupType VARCHAR(100)=NULL,
@NewMemberGroupPlanId	int output 
 
)
AS
BEGIN
SET NOCOUNT ON;
    BEGIN TRAN 
	BEGIN TRY
--DECLARE @mem_grp_pln_id INT
DECLARE @hmsi INT

 --UPDATE rlplfc SET exp_date=@effDate where member_id=@dpntMemberId and mb_gr_pl_id=@memberGroupPlanId and exp_date IS NULL

 UPDATE rlmbrt SET exp_rt_date=@effDate where  mb_gr_pl_id=@memberGroupPlanId and exp_rt_date IS NULL
 
 
 UPDATE group_status SET exp_date=@effDate WHERE group_id=@groupId
  SELECT @hmsi=msi+1 from sysdatetime  
 
 INSERT INTO group_status ( group_id , group_status , reason_code , eff_date ,
 h_datetime , h_action , h_user ) VALUES (@groupId , 'A4' , 'DF' , @effDate , getdate() , 'A4' , @hUser ) 
 UPDATE sysdatetime set msi=msi+1 
 

   

 SELECT @hmsi=msi+1 from sysdatetime  
 INSERT INTO rlmbgrpl ( member_id, group_id, plan_id, eff_gr_pl, action_code, h_datetime, h_msi, h_action, h_user, sub_in_plan)
 VALUES(@memberId,@groupId,@planId,@effDate,'GA',GETDATE(),@hmsi,'GA',@hUser,@SiP)
  SET @NewMemberGroupPlanId=SCOPE_IDENTITY()
 
 UPDATE sysdatetime set msi=msi+1 
 SELECT @hmsi=msi+1 from sysdatetime

  INSERT INTO rlmbrt ( mb_gr_pl_id, rate_code, eff_rt_date, action_code, h_datetime, h_msi, h_action, h_user )VALUES
  (@NewMemberGroupPlanId,@rateCode,@effDate,'GA',GETDATE(),@hmsi,'GA',@hUser)
  UPDATE sysdatetime set msi=msi+1 
   --SELECT @hmsi=msi+1 from sysdatetime

   --INSERT INTO rlplfc ( mb_gr_pl_id, member_id, facility_id, eff_date, action_code, h_datetime, h_msi, h_action, h_user )
   --VALUES ( @memberGroupPlanId, @dpntMemberId, @facilId, @effDate, 'GA', getdate(), @hmsi, 'GA',@hUser)
    -- UPDATE sysdatetime set msi=msi+1 
 
 COMMIT TRAN 
	END TRY


BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState )
	END CATCH
 

	SET NOCOUNT OFF
END