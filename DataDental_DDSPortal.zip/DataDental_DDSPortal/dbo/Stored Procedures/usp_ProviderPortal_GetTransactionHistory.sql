﻿CREATE PROCEDURE [dbo].[usp_ProviderPortal_GetTransactionHistory]
(
@memberid INT,
@lastname VARCHAR(MAX),
@dob DATETIME,
@facilityid int
) 
AS 
BEGIN 
SET NOCOUNT ON 

DECLARE @TransactionHistory TABLE
(
id INT IDENTITY(1,1),
Claim VARCHAR(MAX),
FullName VARCHAR(MAX),
DOB VARCHAR(MAX),
Type VARCHAR(MAX),
Status VARCHAR(MAX),
Dentist VARCHAR(MAX),
ServiceDate VARCHAR(MAX),
PaidDate VARCHAR(MAX),
CheckValue VARCHAR(MAX),
EOPID VARCHAR(MAX)
)

INSERT INTO @TransactionHistory(Claim,FullName,DOB,Type,Status,Dentist,ServiceDate,PaidDate,CheckValue,EOPID)

select distinct clm.claim_no, mbr.first_name + mbr.last_name as name ,mbr.date_of_birth,clm.[type],clm.claim_status,fc_name as Dentist,
clm.svc_date_beg,clm.received_date,eoph.check_id,eop.eop_id from 
claim_h  clm 
inner join rlmbgrpl rl on rl.mb_gr_pl_id = clm.mbgrpl_id
inner join member mbr on mbr.member_id= rl.member_id
inner join eop_d eop on eop.claim_id = clm.claim_id
inner join eop_h eoph on eoph.eop_id = eop.eop_id
inner join [plan] pln on pln.plan_id = rl.plan_id
inner join rlplfc on rlplfc.mb_gr_pl_id = mbr.member_id
inner join facility_sec fc on rlplfc.facility_id = fc.fc_id
where ((mbr.member_id = @memberid ) OR (mbr.last_name = @lastname AND date_of_birth = @dob)) AND rlplfc.facility_id = @facilityid
order by svc_date_beg desc 


select * from @TransactionHistory

SET NOCOUNT OFF 
END