﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_member_imsDocUpdated]
	-- Add the parameters for the stored procedure here
@family_id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
IF EXISTS (Select m.Id
		From member_ims_history m
		Where m.family_id=@family_id
		AND Convert(date,m.updated_on)=convert(date,getdate()))
		BEGIN
			RETURN 1
		END

RETURN 0

END