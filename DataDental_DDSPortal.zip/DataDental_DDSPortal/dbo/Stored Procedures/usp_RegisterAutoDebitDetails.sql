﻿CREATE proc [dbo].[usp_RegisterAutoDebitDetails](
@groupid int,
@isautodebit bit,
@username varchar(max)
)
as
begin

declare @userId varchar(20)
select @userId= user_id from group_user_details where user_name=@username

insert into autodebit_details(group_id,autodebit,modified_date,modified_by)
values(@groupid,@isautodebit,GETDATE(),@userId)

SELECT 'Success'

end