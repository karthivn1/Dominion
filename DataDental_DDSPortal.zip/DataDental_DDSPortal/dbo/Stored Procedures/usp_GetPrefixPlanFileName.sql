﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--DECLARE @fileName NVARCHAR(100)=NULL
--exec usp_GetPrefixPlanFileName 1,322,470022,@fileName out
--SELECT @fileName
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetPrefixPlanFileName]
@GroupId INT,
@PlanId INT,
@MemberId INT,
@fileName NVARCHAR(100) OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;


IF OBJECT_ID('tempdb..#tempGroup') IS NOT NULL
    DROP TABLE #tempGroup

IF OBJECT_ID('tempdb..#tempPlan') IS NOT NULL
    DROP TABLE #tempPlan

SET @fileName='';
DECLARE @memberState NVARCHAR(2)='';

--drop table #tempGroup

Select *
	INTO #tempGroup
	From group_sec g
	Where g.group_id=@GroupId

Select *
	INTO #tempPlan
	From plan_sec p
	Where p.plan_id=@PlanId


Select @memberState=
    a.state
	From [address_sec] a
	WHere a.sys_rec_id=@MemberId AND a.subsys_code='MB'

Select TOP 1 
	@fileName=CASE t.enrol_territory 
		WHEN 34 THEN 'DC' 
		WHEN 36 THEN 'DE' 
		ELSE '' 
    END 
	From #tempGroup t

IF LEN(@fileName)>0  
 	RETURN 

IF @MemberId=1371821 
BEGIN
 IF EXISTS( Select member_id From que_detail_sec Where member_id=@MemberId)
	SET @fileName='DE'
	RETURN 
END

--IF EXISTS( Select member_id From que_detail_sec Where member_id=@MemberId)
--BEGIN
--	SET @fileName='DE'
--	RETURN 
--END

IF EXISTS(Select group_id From #tempGroup t Where t.group_parent=63982)
BEGIN
 SET @fileName='DC'
 RETURN 
END

---//708-AON s/b DE for the time being per Roxanne 01/18/13

IF EXISTS(Select plan_id FROM #tempPlan t Where t.plan_id=2002)
BEGIN
 SET @fileName='DE'
 RETURN 
END

--////Guardian not in our 5 states

IF EXISTS(Select group_id 
	From #tempGroup t 
	Where t.group_parent=60467
	AND t.enrol_territory=27)
BEGIN
 SET @fileName=@memberState
 RETURN 
END

--//If Federal Dental PPO Access Plus PPO 
--///Per Roxanne and Compliance - change this to "DE" effective 09/26/11 

IF EXISTS(Select group_id 
	From #tempGroup t 
	Where t.group_parent in (33970,33971,26939,26940,34296,34295))
BEGIN
 SET @fileName='DE'
 RETURN 
END

IF EXISTS(Select group_id 
	From #tempGroup t 
	Where t.group_parent in (34115))
BEGIN
 SET @fileName='VA'
 RETURN 
END

Select 
	@fileName=
	CASE t.enrol_territory 
		WHEN 1 THEN 'DE' 
		WHEN 2 THEN 'MD' 
		WHEN 3 THEN 'NJ' 
		WHEN 4 THEN 'PA' 
		WHEN 5 THEN 'VA' 
		WHEN 6 THEN 'VA' 
		WHEN 7 THEN 'VA' 
		WHEN 8 THEN 'VA' 
		WHEN 9 THEN 'DC' 
		WHEN 11 THEN 'DC' 
		WHEN 12 THEN 'PA' 
		WHEN 13 THEN 'IL' 
		WHEN 14 THEN 'GA' 
		WHEN 15 THEN 'NC' 
		WHEN 16 THEN 'NY'
	ELSE '' 
	END
	From #tempGroup t

IF LEN(@fileName)>0  
BEGIN
 	RETURN 
END	

IF EXISTS(Select group_id 
	From #tempGroup t 
	Where t.enrol_territory=10)
BEGIN
	IF @memberState IN('DE','MD','PA','VA','DC')
	 SET @fileName=@memberState
	ELSE  
	SET @fileName='DC'
END
RETURN
END