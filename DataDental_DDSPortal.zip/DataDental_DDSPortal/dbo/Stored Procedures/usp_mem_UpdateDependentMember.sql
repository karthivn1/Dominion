﻿

-- =============================================
-- Author:		Harishraj.R
-- Create date:  22/02/2017
-- Description:	 TO Update THE Dependent MEMBER by MEMBER ID 
-- =============================================
CREATE PROCEDURE [dbo].[usp_mem_UpdateDependentMember]
	-- Add the parameters for the stored procedure here
	(@memberId           INT,
	 @alt_id              VARCHAR (20) =NULL, 
	 @member_code         INT, 
	 @first_name          VARCHAR (15), 
	 @middle_init         VARCHAR (1), 
	 @last_name           VARCHAR (15), 
	 @date_of_birth       DATE =NULL,
	 @member_ssn          VARCHAR (11),
	 @student_flag        VARCHAR (1),       
	 @disable_flag        VARCHAR (1),
	 @action_code         VARCHAR (2),
	 @h_datetime          DATE =NULL,  
	 @h_action            VARCHAR (2), 
	 @h_user              VARCHAR (10), 
	 @hire_date           DATE =NULL,
	 @new_ssn             VARCHAR (11), 
	 @source_id           VARCHAR (20),
	 @student_exp		  DATE = NULL)
AS
BEGIN
    
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;	
	 
		--Update THE DEPENDENT	    
	UPDATE member SET alt_id=@alt_id , member_code=@member_code , first_name=@first_name , middle_init=@middle_init,last_name=@last_name,date_of_birth=@date_of_birth, 
				member_ssn=@member_ssn,student_flag=@student_flag,disable_flag=@disable_flag,action_code=@action_code,h_datetime=@h_datetime,h_action=@h_action, 
				h_user=@h_user,hire_date=@hire_date,new_ssn=@new_ssn,source_id=@source_id,student_exp=@student_exp
			WHERE member_id=@memberId	    

	
END