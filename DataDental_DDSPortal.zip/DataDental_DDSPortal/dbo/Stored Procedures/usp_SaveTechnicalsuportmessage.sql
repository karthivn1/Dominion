﻿CREATE procedure [dbo].[usp_SaveTechnicalsuportmessage]
(@username varchar(max),
 @message varchar(max)
)
 AS
 Declare @userid int;
 Begin
 If exists ( select user_id from group_user_details  where user_name =@username)
 Begin 
 set @userid=(select user_id from group_user_details  where user_name =@username)
 INSERT into group_technical_support values(@userid,@message,CONVERT(date,GETDATE()))
 INSERT INTO batch_process_details (ref_id,event_id,status,retry,created_date)
 VALUES (@userid,1,1001,0,CONVERT(date,GETDATE()));
 select 1
 End 
 End