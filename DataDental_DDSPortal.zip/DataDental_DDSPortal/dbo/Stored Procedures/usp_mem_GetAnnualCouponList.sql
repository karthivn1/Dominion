﻿
-- =============================================
-- Author:		<Mari Slevam Sornaraj>
-- Create date: <22-12-2016>
-- Description:	<This stored procedure is used to get list  of annual coupon>
-- =============================================
--exec [usp_mem_GetAnnualCouponList]
CREATE PROCEDURE [dbo].[usp_mem_GetAnnualCouponList]

AS
BEGIN
SET NOCOUNT ON
	
	SELECT annual_proc_parm.annual_proc_prm_id as 'AnnualProcID',   
         annual_proc_parm.no_of_days as 'NoOfDaysBefore',   
         annual_proc_parm.term_group as 'Terminate',   
         annual_proc_parm.term_as_of,   
         annual_proc_parm.letter_id as 'LetterID',   
         annual_proc_parm.h_user ,   
         annual_proc_parm.h_datetime ,   
         0  as 'NoOfGroup', ''  as 'RenewDate' ,
		 ltr_def.descr as 'Letter',
		 case when  annual_proc_parm.term_group=1 then 'Yes' else 'No' end as 'TerminateGroup'
    FROM annual_proc_parm  
	left join ltr_def on ltr_def.letter_id = annual_proc_parm.letter_id and ltr_def.subsys_code = 'MB'  
ORDER BY annual_proc_parm.no_of_days DESC   

SET NOCOUNT OFF
END