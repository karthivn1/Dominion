﻿




-- =============================================
-- Author:		V.M.Hemananth
-- Create date: 28/12/2016
-- Description:	This sp is used to Save the New Member Details.
-- =============================================
 CREATE PROCEDURE [dbo].[usp_mem_SaveMemberDetails]
	-- Add the parameters for the stored procedure here
	(@family_id          INT = NULL,
	 @member_id          INT,
	 @group_id           INT = NULL, 
	 @plan_id            INT,
	 @eff_gr_pl          DATE,
	 @sub_in_plan        VARCHAR (15),
	 @action_code        CHAR (2),
	 @rate_code          VARCHAR (15),
	 @eff_rt_date        DATE,
	 @eff_rlfc_date      DATE,	
	 @facilityid         INT = NULL,
	 @h_datetime         DATE,
	 @h_action           VARCHAR (15),
	 @h_user             VARCHAR (30),
	 @first_name          VARCHAR (30) = NULL,
	 @last_name           VARCHAR (30) = NULL,
	 @alt_id             VARCHAR (30) = NULL,	
	 @firstbillingdate   DATE = NULL,                 
	 @IsDependent        BIT = 0)
AS
BEGIN
 DECLARE @newMemberId INT,@hmsi INT,@mbgrplid INT , @rlfcid INT,@addressid INT , @grouptype VARCHAR(30) , @groupParent VARCHAR(30) ;
 --DECLARE @hmsi INT;
 --DECLARE @mbgrplid INT;
 --DECLARE @rlfcid INT;
 --DECLARE @addressid INT;

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	 
	SET NOCOUNT ON;
	BEGIN TRAN 
		BEGIN TRY 
    -- Insert statements for procedure here
	
	 SELECT @hmsi = msi +1 FROM sysdatetime;

		--SELECT @hmsi = h_msi FROM member WHERE member_id = @member_id;
	 IF @IsDependent = 'FALSE'
	    BEGIN 
		    SELECT @grouptype = group_type, @groupParent = group_parent FROM [group] where group_id = @group_id;

			IF @grouptype = 'MS'
			   BEGIN			        
                   Declare @SGID int, @CURRENTDATE DATETIME , @grpStatus VARCHAR(10);

				   SELECT @grpStatus = group_status FROM group_status WHERE group_id = @group_id AND exp_date IS NULL

			       SET @CURRENTDATE = GETDATE();

			       EXEC [mb_add_sg] @last_name,@first_name, @alt_id ,@eff_gr_pl, @plan_id ,@group_id, @grpStatus, @h_user, @CURRENTDATE, @firstbillingdate, @SWP_Ret_Value = @SGID output
			       
			       SET @group_id = @SGID

				   SELECT @grouptype = group_type, @groupParent = group_parent FROM [group] where group_id = @group_id;
			   END

			IF @grouptype = 'SG'
				 BEGIN
				    DECLARE @CURRENTDATETIME DATETIME;
				    SET @CURRENTDATETIME = GETDATE();
				    EXEC [mb_add_group_plan] @eff_gr_pl , @plan_id,@groupParent,@group_id,@h_user, @CURRENTDATETIME;
			     END
             ELSE
			    BEGIN
					SELECT @hmsi = h_msi FROM member where member_id = @family_id;
                END

			INSERT INTO rlmbgrpl ( member_id, 
								   group_id, 
								   plan_id, 
								   eff_gr_pl, 
								   action_code, 
								   h_datetime, 
								   h_msi, 
								   h_action, 
								   h_user, 
								   sub_in_plan ) 
								   VALUES( @family_id, 
								   @group_id,
								   @plan_id,
								   @eff_gr_pl, 
								   @action_code,
								   @h_datetime , 
								   @hmsi,
								   @h_action ,
								   @h_user,
								   @sub_in_plan) 

			SET @mbgrplid = SCOPE_IDENTITY();

			INSERT INTO rlmbrt ( mb_gr_pl_id, 
		                      rate_code, 
							  eff_rt_date, 
							  action_code, 
							  h_datetime, 
							  h_msi, 
							  h_action, 
							  h_user ) 
							  VALUES ( @mbgrplid,
							  @rate_code,
							  @eff_rt_date,
							  @action_code, 
							  @h_datetime ,
							  @hmsi,
							  @h_action ,
							  @h_user ) 

         END 
	ELSE
		BEGIN
		      select @mbgrplid = mb_gr_pl_id from rlmbgrpl where member_id = @family_id and plan_id = @plan_id
		END
		  
              
	 EXEC [mb_add_cat] @mbgrplid, @member_id

	 IF @IsDependent = 'TRUE'
	 BEGIN
		IF(@rate_code !='pm')
		BEGIN
			DECLARE @rlmbrtID Int;
		  	SELECT Top 1 @rlmbrtID = rlmbrt_id  FROM rlmbrt where mb_gr_pl_id = @mbgrplid and exp_rt_date is Null
		  
			UPDATE rlmbrt SET exp_rt_date = @eff_rt_date, 
		  		        action_code = 'DA', h_datetime = GETDATE(), 
		  				h_msi = @hmsi, h_action =  @h_action, 
		  				h_user = @h_user WHERE rlmbrt_id = @rlmbrtID			  

			INSERT INTO rlmbrt ( mb_gr_pl_id, 
						rate_code, 
						eff_rt_date, 
						action_code, 
						h_datetime, 
						h_msi, 
						h_action, 
						h_user ) 
						VALUES ( @mbgrplid,
						@rate_code,
						@eff_rt_date,
						@action_code, 
						@h_datetime ,
						@hmsi,
						@h_action ,
						@h_user ) 

			SET @hmsi = @hmsi + 1;
		END
	 END	 

 --   IF @IsDependent = 'TRUE'
	--BEGIN
 --   SET @hmsi = @hmsi + 1; 
	--END

	INSERT INTO rlplfc ( mb_gr_pl_id, 
	    					  member_id,
	    					  eff_date, 
	    					  action_code, 
							  facility_id,
	    					  h_datetime, 
	    					  h_msi, 
	    					  h_action, 
	    					  h_user ) 
	    					  VALUES ( @mbgrplid,
	   					      @member_id ,
	    					  @eff_rlfc_date, 
	    					  @action_code ,
							  @facilityid,
	    					  @h_datetime ,
	    					  @hmsi ,
	    					  @h_action ,
	    					  @h_user ) 	

	SET @rlfcid = SCOPE_IDENTITY();


    Insert into tiered_benefit_mbr (rlplfc_id ) Select Distinct  @rlfcid From [plan] p, rlplfc f, rlmbgrpl m  Where f.mb_gr_pl_id = m.mb_gr_pl_id and m.plan_id = p.plan_id and p.tiered_sw = 1  and f.rlplfc_id = @rlfcid;

	update sysdatetime set msi = @hmsi

	select @hmsi;  
   


	COMMIT TRAN 
	END TRY 

	BEGIN CATCH 
		ROLLBACK TRAN 
		DECLARE @erMessage  NVARCHAR(2048), 
		@erSeverity INT, 
		@erState    INT 
		SELECT @erMessage = ERROR_MESSAGE(),
		@erSeverity = ERROR_SEVERITY(),
		@erState = ERROR_STATE() 
		RAISERROR (@erMessage,@erSeverity,@erState ) 

	END CATCH 
END