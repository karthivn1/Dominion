﻿CREATE PROCEDURE [dbo].[usp_memberportal_firstloginsecuritycheck]
(
@username INT
)
AS
BEGIN
SET NOCOUNT ON;



If Exists (select user_id from member_user_details where user_name=@username and is_firstlogin=1 and status_id=1 and password is NOT NULL and role_id in (4,5) )
begin
select user_id from member_user_details where user_name=@username
end

SET NOCOUNT OFF
END