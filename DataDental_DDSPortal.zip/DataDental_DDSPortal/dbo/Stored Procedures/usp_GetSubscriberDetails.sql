﻿CREATE PROCEDURE [dbo].[usp_GetSubscriberDetails] 
(
@GroupID INT,
@PlanID INT
) 
AS 
BEGIN 
SET NOCOUNT ON 

SELECT rlmbgrpl.group_id GroupID,rlmbgrpl.plan_id PlanID,rlmbgrpl.member_id MemberID,RTRIM(member.first_name) FirstName,RTRIM(member.last_name) LastName,RTRIM(member.first_name)+' '+RTRIM(member.last_name) FullName, member.date_of_birth DOB FROM member_sec member
inner join rlplfc_sec rlplfc on  rlplfc.member_id=member.member_id
inner join rlmbgrpl_sec rlmbgrpl on rlmbgrpl.mb_gr_pl_id=rlplfc.mb_gr_pl_id
inner join rlmbrt_sec rlmbrt on rlmbrt.mb_gr_pl_id=rlmbgrpl.mb_gr_pl_id
inner join pl_rat_sec pl_rat on rlmbrt.rate_code =pl_rat.rate_code WHERE rlmbgrpl.plan_id=@PlanID AND rlmbgrpl.group_id=@GroupID AND
member.member_id = member.family_id AND rlmbrt.rate_code='F9'
AND (( rlmbrt.exp_rt_date is null ) or  ( rlmbrt.exp_rt_date = DATEADD(month,-3,cast(getdate() as date))) )

SET NOCOUNT OFF 
END