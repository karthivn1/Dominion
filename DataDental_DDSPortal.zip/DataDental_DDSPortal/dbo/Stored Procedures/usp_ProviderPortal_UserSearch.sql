﻿-- =============================================
-- Author:		<Manikandan,Palanisamy>
-- Create date: <06/20/2017>
-- Description:	<Get the user lookup details for the matching search criteria>
-- =============================================
CREATE PROCEDURE [dbo].[usp_ProviderPortal_UserSearch] 
	(
	@userID INT = NULL,
	@userName VARCHAR(20) = NULL,
	@userEmail VARCHAR(300) = NULL,
	@facilityId INT = NULL
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT LTRIM(RTRIM(pud.[user_id])) AS UserID,
	       LTRIM(RTRIM(pud.[user_name])) AS UserName,
		   LTRIM(RTRIM(pud.facility_id)) AS FacilityID,
		   LTRIM(RTRIM(pud.status_id)) AS [Status],
		   LTRIM(RTRIM(pud.failed_login_attempt)) AS Failed,
		   LTRIM(RTRIM(pud.email)) AS Email,
		   LTRIM(RTRIM(pud.temp_password_unhashed)) AS TemporaryPassword,
		   LTRIM(RTRIM(pud.facility_tax_id)) AS TaxID,
		   LTRIM(RTRIM(pud.last_name)) AS LastName,
		   LTRIM(RTRIM(pud.password_reset_date)) AS PWDUpdated,
		   LTRIM(RTRIM(pud.last_action_date)) AS LastAction,
		   LTRIM(RTRIM(pud.created_date)) AS Created,
		   LTRIM(RTRIM(pud.updated_date)) AS Updated, 
		   LTRIM(RTRIM(pud.password_hash)) AS [Password]
	 FROM provider_user_details pud
	  LEFT OUTER JOIN facility_sec fc ON pud.facility_id = fc.fc_id
	  --LEFT OUTER JOIN user_status_master usm ON pud.status_id = usm.status_id
	  WHERE pud.[user_name] = ISNULL(@userName,pud.[user_name]) AND
			pud.[user_id] = ISNULL(@userID,pud.[user_id]) AND
	        pud.email = ISNULL(@userEmail,pud.email) AND
			pud.facility_id = ISNULL(@facilityId, pud.facility_id)

END