﻿CREATE PROCEDURE [dbo].[usp_MemberPortal_UpdateIMSDocument]
(
@docid int
)
as 
Begin
SET NOCOUNT ON

Update member_ims_doc set isNew=0 where doc_id=@docid 
select 'success'

SET NOCOUNT OFF
End