﻿

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_memberportal_validate_memberuser]
	-- Add the parameters for the stored procedure here
	(
	@username varchar(15), 
	@lastname varchar(15),
	@dateofbirth varchar(15) ,
	@zip varchar(10),
	@email varchar(250)	
	)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @ErrorCode varchar(10) =null
IF NOT EXISTS(select member_id from member_sec mbr inner join address_sec addr on mbr.member_id=addr.sys_rec_id where addr.subsys_code='MB'and mbr.last_name=@lastname and mbr.date_of_birth=@dateofbirth and addr.zip=@zip)
	BEGIN
		SET @ErrorCode = '0'
	END
ELSE 
	BEGIN
		IF EXISTS(SELECT member_id FROM member_user_details WHERE last_name=@lastname and date_of_birth=@dateofbirth and zip=@zip)
			BEGIN
				SET @ErrorCode = '1'
			END
ELSE
	BEGIN
		IF EXISTS(SELECT user_name FROM dbo.member_user_details WHERE user_name=@username)
			BEGIN
				SET @ErrorCode = '2';
			END
	END
IF(@ErrorCode IS NULL)
	BEGIN
		IF EXISTS(SELECT email FROM dbo.member_user_details WHERE email=@email) 
			BEGIN
				SET @ErrorCode = '3'
			END
	END 
END
IF(@ErrorCode IS NULL)
	BEGIN
		declare @NoofMembers int
		select @NoofMembers= count(*) from member_sec mbr inner join address_sec addr on mbr.member_id=addr.sys_rec_id 
		where addr.subsys_code='MB' and addr.addr_type='L' 
		and mbr.last_name=@lastname and mbr.date_of_birth=@dateofbirth and addr.zip=@zip
		if(@NoofMembers>1)
			BEGIN
				SET @ErrorCode = '4'
			END
	END 

IF(@ErrorCode IS NULL)
BEGIN
SET @ErrorCode='6'
END

DECLARE @Err as table
(
 ErrMsg varchar(max)
)
INSERT INTO @Err(ErrMsg)VALUES(@ErrorCode)
SELECT * FROM @Err
    
END