﻿CREATE TABLE [dbo].[tmpsecurity] (
    [user_id] INT      NULL,
    [sqset]   CHAR (1) NULL
);

