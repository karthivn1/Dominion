﻿CREATE TABLE [dbo].[member_cost_calc_proc_type] (
    [portal_category_number] INT           NOT NULL,
    [portal_category]        VARCHAR (250) NULL
);

