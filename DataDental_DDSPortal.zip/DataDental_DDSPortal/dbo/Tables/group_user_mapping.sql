﻿CREATE TABLE [dbo].[group_user_mapping] (
    [group_user_id] INT IDENTITY (1, 1) NOT NULL,
    [user_id]       INT NULL,
    [group_id]      INT NULL,
    [status]        BIT NULL,
    CONSTRAINT [PK_group_user_mapping] PRIMARY KEY CLUSTERED ([group_user_id] ASC)
);

