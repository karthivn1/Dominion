﻿CREATE TABLE [dbo].[invitecode_details] (
    [code_id]      INT           IDENTITY (1, 1) NOT NULL,
    [invitecode]   VARCHAR (15)  NOT NULL,
    [group_zip]    VARCHAR (10)  NOT NULL,
    [email]        VARCHAR (250) NOT NULL,
    [last_name]    VARCHAR (20)  NOT NULL,
    [created_date] DATETIME      NULL,
    [con_type]     VARCHAR (2)   NULL,
    CONSTRAINT [PK_invitecode_details] PRIMARY KEY CLUSTERED ([code_id] ASC)
);

