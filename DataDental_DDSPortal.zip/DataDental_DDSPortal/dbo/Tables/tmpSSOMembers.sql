﻿CREATE TABLE [dbo].[tmpSSOMembers] (
    [user_id]   INT           NOT NULL,
    [member_id] INT           NOT NULL,
    [email]     VARCHAR (300) NULL
);

