﻿CREATE TABLE [dbo].[fcstat] (
    [fc_stat_id]  INT      NOT NULL,
    [facility_id] INT      NULL,
    [status]      CHAR (2) NULL,
    [eff_date]    DATE     NULL,
    [exp_date]    DATE     NULL
);

