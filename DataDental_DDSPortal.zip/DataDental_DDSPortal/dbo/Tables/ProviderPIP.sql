﻿CREATE TABLE [dbo].[ProviderPIP] (
    [fc_id]       CHAR (6)     NULL,
    [pv_id]       CHAR (6)     NULL,
    [np_id]       CHAR (10)    NOT NULL,
    [first_name]  VARCHAR (15) NULL,
    [middle_init] CHAR (1)     NULL,
    [last_name]   VARCHAR (15) NULL,
    [degree]      VARCHAR (3)  NULL,
    [License]     CHAR (18)    NOT NULL,
    [State]       CHAR (2)     NOT NULL,
    [school]      CHAR (50)    NULL,
    [discipline]  CHAR (2)     NULL
);

