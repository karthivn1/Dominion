﻿CREATE TABLE [dbo].[prv_recredential] (
    [provider_id]          INT  NOT NULL,
    [recredentialing_date] DATE NULL,
    [status]               INT  NOT NULL
);

