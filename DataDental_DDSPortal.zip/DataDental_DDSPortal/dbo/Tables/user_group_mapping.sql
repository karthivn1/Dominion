﻿CREATE TABLE [dbo].[user_group_mapping] (
    [user_group_id] INT IDENTITY (1, 1) NOT NULL,
    [user_id]       INT NOT NULL,
    [group_id]      INT NOT NULL,
    CONSTRAINT [PK_Table_1] PRIMARY KEY CLUSTERED ([user_group_id] ASC)
);

