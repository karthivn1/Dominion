﻿CREATE TABLE [dbo].[al_batches] (
    [credit_id]       INT             NOT NULL,
    [batch_no]        CHAR (18)       NULL,
    [batch_seq]       SMALLINT        NULL,
    [group_id]        INT             NULL,
    [recv_date]       DATE            NULL,
    [deposit_date]    DATE            NULL,
    [amount]          DECIMAL (16, 2) NULL,
    [deposit_account] CHAR (30)       NULL,
    [open_batch]      CHAR (1)        NULL,
    [a_m_alloc_flag]  CHAR (1)        NULL,
    [source]          CHAR (1)        NULL,
    [check_no]        INT             NULL,
    [al_userid]       CHAR (20)       NULL,
    [timestamp]       DATETIME        NULL,
    CONSTRAINT [al_batch_pk] PRIMARY KEY CLUSTERED ([credit_id] ASC)
);

