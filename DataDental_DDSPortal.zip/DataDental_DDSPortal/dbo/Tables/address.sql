﻿CREATE TABLE [dbo].[address] (
    [address_id]  INT       IDENTITY (1, 1) NOT NULL,
    [subsys_code] CHAR (2)  NULL,
    [sys_rec_id]  INT       NULL,
    [addr_type]   CHAR (2)  NULL,
    [addr1]       CHAR (30) NULL,
    [addr2]       CHAR (30) NULL,
    [city]        CHAR (30) DEFAULT ('') NOT NULL,
    [country]     CHAR (3)  NULL,
    [county]      CHAR (20) NULL,
    [state]       CHAR (2)  NULL,
    [zip]         CHAR (10) NULL,
    [mail]        CHAR (1)  NULL,
    [history_rec] INT       NULL,
    [geo_x]       INT       NULL,
    [geo_y]       INT       NULL
);

