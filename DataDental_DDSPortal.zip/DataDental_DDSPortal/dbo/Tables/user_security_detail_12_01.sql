﻿CREATE TABLE [dbo].[user_security_detail_12_01] (
    [security_detail_id]   INT            IDENTITY (1, 1) NOT NULL,
    [security_question_id] INT            NOT NULL,
    [answer]               VARCHAR (1000) NOT NULL,
    [question_order]       INT            NULL,
    [user_id]              INT            NOT NULL,
    [created_date]         DATETIME       NULL,
    [created_by]           INT            NULL,
    [modified_date]        DATETIME       NULL,
    [modified_by]          INT            NULL
);

