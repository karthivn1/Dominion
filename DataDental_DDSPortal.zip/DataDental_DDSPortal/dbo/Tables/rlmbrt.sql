﻿CREATE TABLE [dbo].[rlmbrt] (
    [rlmbrt_id]   INT           NOT NULL,
    [mb_gr_pl_id] INT           NULL,
    [rate_code]   CHAR (2)      NULL,
    [eff_rt_date] DATE          NULL,
    [exp_rt_date] DATE          NULL,
    [action_code] CHAR (2)      NOT NULL,
    [h_datetime]  DATETIME2 (7) NOT NULL,
    [h_msi]       INT           NOT NULL,
    [h_action]    CHAR (2)      NOT NULL,
    [h_user]      CHAR (10)     NOT NULL
);

