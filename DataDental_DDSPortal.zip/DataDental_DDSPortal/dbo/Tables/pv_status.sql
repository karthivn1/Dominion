﻿CREATE TABLE [dbo].[pv_status] (
    [pv_st_id]  INT      NOT NULL,
    [pv_id]     INT      NULL,
    [pv_status] CHAR (2) NULL,
    [eff_date]  DATE     NOT NULL,
    [exp_date]  DATE     NULL
);

