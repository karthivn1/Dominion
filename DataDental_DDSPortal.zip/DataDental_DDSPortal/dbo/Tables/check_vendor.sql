﻿CREATE TABLE [dbo].[check_vendor] (
    [check_id]     INT             NOT NULL,
    [batch_id]     INT             NULL,
    [check_nbr]    INT             NULL,
    [bank_acct]    CHAR (30)       NULL,
    [bank_info_id] INT             NOT NULL,
    [check_date]   DATE            NOT NULL,
    [amount]       NUMERIC (16, 2) NOT NULL,
    [entity_name]  CHAR (50)       NOT NULL,
    [check_memo]   CHAR (50)       NULL,
    [status]       CHAR (2)        NOT NULL,
    [tran_type]    CHAR (2)        NOT NULL,
    [user_id]      CHAR (15)       NULL,
    [timestamp]    DATETIME2 (7)   NULL,
    [recon_date]   DATE            NULL,
    [recon_user]   CHAR (15)       NULL,
    [sys_rec_id]   INT             NOT NULL,
    [tran_create]  CHAR (2)        NULL,
    [subsys_code]  CHAR (2)        NOT NULL,
    [reconciled]   CHAR (1)        NOT NULL,
    [reason_code]  CHAR (2)        NULL,
    [oc_id]        INT             NOT NULL
);

