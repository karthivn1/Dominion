﻿CREATE TABLE [dbo].[lkp_doctype] (
    [Id]       INT           IDENTITY (1, 1) NOT NULL,
    [doc_no]   INT           NULL,
    [doc_type] NVARCHAR (50) NULL,
    CONSTRAINT [PK_lkp_doctype] PRIMARY KEY CLUSTERED ([Id] ASC)
);

