﻿CREATE TABLE [dbo].[app_keysettings] (
    [appkey_id]    INT           IDENTITY (1, 1) NOT NULL,
    [appkey_name]  NVARCHAR (50) NOT NULL,
    [appkey_value] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_app_keysettings] PRIMARY KEY CLUSTERED ([appkey_id] ASC)
);

