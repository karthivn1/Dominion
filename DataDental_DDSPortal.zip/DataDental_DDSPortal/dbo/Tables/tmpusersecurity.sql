﻿CREATE TABLE [dbo].[tmpusersecurity] (
    [user_id]   INT IDENTITY (1, 1) NOT NULL,
    [member_id] INT NOT NULL
);

