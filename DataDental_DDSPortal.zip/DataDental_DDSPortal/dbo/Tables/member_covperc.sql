﻿CREATE TABLE [dbo].[member_covperc] (
    [procedure_code] VARCHAR (25) NOT NULL,
    [plan_id]        INT          NOT NULL,
    [percent_cover]  FLOAT (53)   NOT NULL
);

