﻿CREATE TABLE [dbo].[group_rules] (
    [group_rules_id] INT       IDENTITY (1, 1) NOT NULL,
    [group_id]       INT       NULL,
    [plan_id]        INT       NULL,
    [rule_id]        INT       NULL,
    [eff_date]       DATE      NULL,
    [exp_date]       DATE      NULL,
    [h_datetime]     DATETIME  NULL,
    [h_msi]          INT       NULL,
    [h_action]       CHAR (2)  NULL,
    [h_user]         CHAR (10) NULL,
    [rel_gppl_id]    INT       NULL,
    CONSTRAINT [group_rules_pk] PRIMARY KEY CLUSTERED ([group_rules_id] ASC)
);

