﻿CREATE TABLE [dbo].[group_status] (
    [group_status_id] INT       IDENTITY (1, 1) NOT NULL,
    [group_id]        INT       NOT NULL,
    [group_status]    CHAR (2)  NOT NULL,
    [reason_code]     CHAR (2)  NULL,
    [icomm_flag]      CHAR (1)  NULL,
    [eff_date]        DATE      NULL,
    [exp_date]        DATE      NULL,
    [h_datetime]      DATETIME  NULL,
    [h_action]        CHAR (2)  NULL,
    [h_user]          CHAR (15) NULL,
    CONSTRAINT [group_status_pk] PRIMARY KEY CLUSTERED ([group_status_id] ASC)
);

