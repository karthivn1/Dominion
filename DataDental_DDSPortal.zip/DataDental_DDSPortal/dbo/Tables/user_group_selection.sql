﻿CREATE TABLE [dbo].[user_group_selection] (
    [user_group_selection_id] INT      IDENTITY (1, 1) NOT NULL,
    [user_id]                 INT      NOT NULL,
    [group_id]                INT      NOT NULL,
    [created_date]            DATETIME NULL,
    CONSTRAINT [PK_user_group_selection] PRIMARY KEY CLUSTERED ([user_group_selection_id] ASC)
);

