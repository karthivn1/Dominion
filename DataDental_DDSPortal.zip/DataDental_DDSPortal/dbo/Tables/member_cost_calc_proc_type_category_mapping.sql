﻿CREATE TABLE [dbo].[member_cost_calc_proc_type_category_mapping] (
    [portal_category_number] INT           NULL,
    [category_sd]            VARCHAR (250) NULL
);

