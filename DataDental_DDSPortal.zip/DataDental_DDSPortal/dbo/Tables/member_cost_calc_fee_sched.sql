﻿CREATE TABLE [dbo].[member_cost_calc_fee_sched] (
    [procedure_code]            VARCHAR (25)  NOT NULL,
    [procedure_code_short_desc] VARCHAR (MAX) NOT NULL,
    [portal_category_number]    INT           NOT NULL,
    [portal_category]           VARCHAR (500) NOT NULL,
    [plan_type]                 VARCHAR (25)  NOT NULL,
    [copay_amount]              FLOAT (53)    NOT NULL,
    [effective_date]            DATE          NULL,
    [expiration_date]           DATE          NULL
);

