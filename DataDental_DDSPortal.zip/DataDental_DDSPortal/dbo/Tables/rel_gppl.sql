﻿CREATE TABLE [dbo].[rel_gppl] (
    [rel_gppl_id]       INT           NOT NULL,
    [group_id]          INT           NULL,
    [plan_id]           INT           NULL,
    [eff_date]          DATE          NULL,
    [exp_date]          DATE          NULL,
    [wait_period]       SMALLINT      NULL,
    [premium_cycle]     CHAR (2)      NULL,
    [h_datetime]        DATETIME2 (7) NULL,
    [h_msi]             INT           NULL,
    [h_action]          CHAR (2)      NULL,
    [h_user]            CHAR (10)     NULL,
    [elig_opt]          INT           NOT NULL,
    [elig_opt_dtl_bill] INT           NOT NULL,
    [elig_opt_dtl_cap]  INT           NOT NULL,
    [nnm_date]          DATE          NULL,
    [rollover_sw]       SMALLINT      NOT NULL,
    [rollover_eff_date] DATE          NULL,
    [age_as_of]         SMALLINT      NOT NULL
);

