﻿CREATE TABLE [dbo].[template_master] (
    [template_id]   INT           IDENTITY (1, 1) NOT NULL,
    [template_name] VARCHAR (20)  NOT NULL,
    [template_desc] VARCHAR (500) NULL,
    [created_by]    INT           NULL,
    [created_date]  DATETIME      NULL,
    [modified_by]   INT           NULL,
    [modified_date] DATETIME      NULL,
    CONSTRAINT [PK_template_master] PRIMARY KEY CLUSTERED ([template_id] ASC)
);

