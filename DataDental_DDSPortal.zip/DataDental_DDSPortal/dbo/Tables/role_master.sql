﻿CREATE TABLE [dbo].[role_master] (
    [role_id]       INT          NOT NULL,
    [role_name]     VARCHAR (20) NOT NULL,
    [isactive]      BIT          NOT NULL,
    [portal_type]   VARCHAR (10) NOT NULL,
    [isInternal]    BIT          NULL,
    [created_by]    INT          NULL,
    [created_date]  DATETIME     NULL,
    [modified_by]   BIT          NULL,
    [modified_date] DATETIME     NULL,
    CONSTRAINT [PK_role_master] PRIMARY KEY CLUSTERED ([role_id] ASC, [portal_type] ASC)
);

