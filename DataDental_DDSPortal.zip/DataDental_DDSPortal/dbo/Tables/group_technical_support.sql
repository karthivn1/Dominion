﻿CREATE TABLE [dbo].[group_technical_support] (
    [support_id]   INT           IDENTITY (1, 1) NOT NULL,
    [user_id]      INT           NOT NULL,
    [query]        VARCHAR (MAX) NOT NULL,
    [created_date] DATETIME      NOT NULL,
    CONSTRAINT [PK__group_te__B9BE370F6FAAD6E8] PRIMARY KEY CLUSTERED ([support_id] ASC)
);

