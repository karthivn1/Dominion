﻿CREATE TABLE [dbo].[user_status_master] (
    [status_id]     INT          NOT NULL,
    [status]        VARCHAR (15) NOT NULL,
    [isactive]      BIT          NOT NULL,
    [created_by]    INT          NULL,
    [created_date]  DATETIME     NULL,
    [modified_by]   INT          NULL,
    [modified_date] DATETIME     NULL,
    [portal_type]   VARCHAR (3)  NOT NULL,
    CONSTRAINT [PK_user_status_master] PRIMARY KEY CLUSTERED ([status_id] ASC, [portal_type] ASC)
);

