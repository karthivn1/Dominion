﻿CREATE TABLE [dbo].[group_ims_doc] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [doc_id]     INT           NULL,
    [doc_type]   NVARCHAR (50) NULL,
    [doc_date]   DATE          NULL,
    [group_id]   INT           NULL,
    [isNew]      BIT           NULL,
    [InsertedOn] DATETIME      NULL
);

