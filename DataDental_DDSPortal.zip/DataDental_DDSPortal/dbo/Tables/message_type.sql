﻿CREATE TABLE [dbo].[message_type] (
    [message_type_id] INT          IDENTITY (1, 1) NOT NULL,
    [message_type]    VARCHAR (25) NULL,
    [isactive]        BIT          NULL,
    [created_by]      INT          NULL,
    [created_date]    DATETIME     NULL,
    CONSTRAINT [PK_message_type] PRIMARY KEY CLUSTERED ([message_type_id] ASC)
);

