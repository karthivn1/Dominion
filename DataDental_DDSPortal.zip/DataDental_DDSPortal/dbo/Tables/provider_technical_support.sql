﻿CREATE TABLE [dbo].[provider_technical_support] (
    [support_id]   INT           IDENTITY (1, 1) NOT NULL,
    [user_id]      INT           NOT NULL,
    [query]        VARCHAR (MAX) NOT NULL,
    [created_date] DATETIME      NOT NULL
);

