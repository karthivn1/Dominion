﻿CREATE TABLE [dbo].[tbl_CostCalc_FeeSched] (
    [ProcCode]       CHAR (6)       NULL,
    [ProcDesc]       VARCHAR (60)   NULL,
    [CategoryNum]    SMALLINT       NULL,
    [CategoryName]   VARCHAR (60)   NULL,
    [PlanType]       VARCHAR (60)   NULL,
    [PlanID]         INT            NULL,
    [CoPayAmount]    DECIMAL (8, 2) NULL,
    [FeeSchedAmount] DECIMAL (8, 2) NULL,
    [EffectiveDate]  DATETIME       NULL,
    [ExpirationDate] DATETIME       NULL,
    [Dummy]          VARCHAR (50)   NULL
);

