﻿CREATE TABLE [dbo].[state] (
    [code]      CHAR (2)  NULL,
    [sname]     CHAR (15) NULL,
    [audit_rec] INT       NULL,
    [standard]  CHAR (1)  NULL
);

