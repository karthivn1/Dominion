﻿CREATE TABLE [dbo].[fc_hours] (
    [fc_hours_id] INT      NOT NULL,
    [fc_id]       CHAR (6) NULL,
    [day]         SMALLINT NULL,
    [am_start]    CHAR (5) NULL,
    [am_s_label]  CHAR (2) NULL,
    [am_end]      CHAR (5) NULL,
    [am_e_label]  CHAR (2) NULL,
    [pm_start]    CHAR (5) NULL,
    [pm_s_label]  CHAR (2) NULL,
    [pm_end]      CHAR (5) NULL,
    [pm_e_label]  CHAR (2) NULL
);

