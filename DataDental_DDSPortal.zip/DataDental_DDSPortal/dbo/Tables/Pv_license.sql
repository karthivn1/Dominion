﻿CREATE TABLE [dbo].[Pv_license] (
    [pv_licid] INT       NOT NULL,
    [pv_id]    INT       NULL,
    [license]  CHAR (18) NULL,
    [state]    CHAR (2)  NULL,
    [eff_date] DATE      NULL,
    [exp_date] DATE      NULL
);

