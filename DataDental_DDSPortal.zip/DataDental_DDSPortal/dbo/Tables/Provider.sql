﻿CREATE TABLE [dbo].[Provider] (
    [fac_id]      NVARCHAR (6)  NULL,
    [pv_id]       NVARCHAR (6)  NULL,
    [pv_npi]      NVARCHAR (10) NULL,
    [first_name]  NVARCHAR (15) NULL,
    [middle_name] NVARCHAR (1)  NULL,
    [last_name]   NVARCHAR (15) NULL,
    [suffix]      NVARCHAR (10) NULL,
    [pv_license]  NVARCHAR (9)  NULL,
    [lic_state]   NVARCHAR (2)  NULL,
    [pv_school]   NVARCHAR (50) NULL,
    [discipline]  NVARCHAR (2)  NULL
);

