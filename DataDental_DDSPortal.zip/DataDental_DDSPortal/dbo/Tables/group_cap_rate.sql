﻿CREATE TABLE [dbo].[group_cap_rate] (
    [group_cap_rate]   INT            NOT NULL,
    [rel_gppl_id]      INT            NULL,
    [group_id]         INT            NOT NULL,
    [plan_id]          INT            NOT NULL,
    [rate_code]        CHAR (2)       NULL,
    [method]           INT            NULL,
    [age_lb]           INT            NOT NULL,
    [age_ub]           INT            NULL,
    [prm_amt]          NUMERIC (8, 2) NULL,
    [cap_dol_pct]      CHAR (1)       NULL,
    [cap_dol]          NUMERIC (8, 2) NULL,
    [cap_pct]          NUMERIC (6, 2) NULL,
    [eff_date]         DATE           NULL,
    [exp_date]         DATE           NULL,
    [h_datetime]       DATETIME2 (7)  NULL,
    [h_user]           CHAR (10)      NULL,
    [prem_waive_after] INT            NOT NULL
);

