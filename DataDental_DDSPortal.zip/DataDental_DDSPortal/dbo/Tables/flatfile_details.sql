﻿CREATE TABLE [dbo].[flatfile_details] (
    [detail_id]                 INT           IDENTITY (1, 1) NOT NULL,
    [last_name]                 VARCHAR (20)  NULL,
    [group_zip]                 VARCHAR (10)  NULL,
    [email]                     VARCHAR (250) NULL,
    [created_date]              DATETIME      NOT NULL,
    [is_invitecode_processed]   BIT           NULL,
    [invitecode_processed_date] DATETIME      NULL,
    [con_type]                  VARCHAR (2)   NULL,
    [h_user]                    VARCHAR (20)  NULL,
    CONSTRAINT [PK_flatfile_details] PRIMARY KEY CLUSTERED ([detail_id] ASC)
);

