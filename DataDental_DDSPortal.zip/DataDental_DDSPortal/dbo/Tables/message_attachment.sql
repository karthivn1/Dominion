﻿CREATE TABLE [dbo].[message_attachment] (
    [attachment_id]       INT             IDENTITY (1, 1) NOT NULL,
    [message_id]          INT             NOT NULL,
    [attachment_filename] VARCHAR (300)   NULL,
    [attachment_file]     VARBINARY (MAX) NULL,
    CONSTRAINT [PK_message_attachment] PRIMARY KEY CLUSTERED ([attachment_id] ASC)
);

