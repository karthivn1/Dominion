﻿CREATE TABLE [dbo].[clm_process_codes] (
    [clm_proc_code_id] INT           NOT NULL,
    [process_code]     CHAR (10)     NOT NULL,
    [code_type]        SMALLINT      NOT NULL,
    [descr]            VARCHAR (254) NOT NULL,
    [deny]             SMALLINT      NOT NULL,
    [secure]           SMALLINT      NOT NULL,
    [eff_date]         CHAR (10)     NULL,
    [exp_date]         CHAR (10)     NULL,
    [h_datetime]       VARCHAR (19)  NULL,
    [h_msi]            INT           NOT NULL,
    [h_action]         CHAR (2)      NOT NULL,
    [h_user]           CHAR (15)     NOT NULL,
    [eob_switch]       SMALLINT      NOT NULL,
    [eop_switch]       SMALLINT      NOT NULL,
    [user_switch]      SMALLINT      NOT NULL,
    [stc]              SMALLINT      NOT NULL
);

