﻿CREATE TABLE [dbo].[authorize_net_profile] (
    [profile_id]       INT           IDENTITY (1, 1) NOT NULL,
    [group_id]         INT           NOT NULL,
    [customer_profile] VARCHAR (15)  NULL,
    [payment_profile]  VARCHAR (500) NULL,
    [created_date]     DATETIME      NULL,
    [modified_date]    DATETIME      NULL,
    CONSTRAINT [PK_authorizenet_profile] PRIMARY KEY CLUSTERED ([profile_id] ASC)
);

