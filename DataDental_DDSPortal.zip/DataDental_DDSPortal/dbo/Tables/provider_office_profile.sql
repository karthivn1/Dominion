﻿CREATE TABLE [dbo].[provider_office_profile] (
    [office_profile_id] INT            IDENTITY (1, 1) NOT NULL,
    [facility_id]       INT            NULL,
    [category]          VARCHAR (3)    NULL,
    [req_value]         NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_office_updated_rec] PRIMARY KEY CLUSTERED ([office_profile_id] ASC)
);

