﻿CREATE TABLE [dbo].[mbr_phone] (
    [mbr_phone_id] INT           IDENTITY (1, 1) NOT NULL,
    [address_id]   INT           NOT NULL,
    [home_phone]   CHAR (10)     NULL,
    [home_ext]     CHAR (5)      NULL,
    [work_phone]   CHAR (10)     NULL,
    [work_ext]     CHAR (5)      NULL,
    [fax]          CHAR (14)     DEFAULT ('') NOT NULL,
    [email]        VARCHAR (250) DEFAULT ('') NOT NULL
);

