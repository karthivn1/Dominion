﻿CREATE TABLE [dbo].[tmpSecurityquestions] (
    [userid] INT          NOT NULL,
    [isSQ]   VARCHAR (10) NULL
);

