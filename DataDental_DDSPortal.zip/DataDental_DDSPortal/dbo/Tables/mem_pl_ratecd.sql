﻿CREATE TABLE [dbo].[mem_pl_ratecd] (
    [mb_gr_pl_id]    INT      NOT NULL,
    [member_id]      INT      NULL,
    [group_id]       INT      NOT NULL,
    [plan_id]        INT      NOT NULL,
    [eff_gr_pl]      DATE     NOT NULL,
    [exp_gr_pl]      DATE     NULL,
    [rate_code]      CHAR (2) NULL,
    [eff_rt_date]    DATE     NULL,
    [exp_rt_date]    DATE     NULL,
    [action_code]    CHAR (2) NOT NULL,
    [rt_action_code] CHAR (2) NULL,
    [rlmbrt_id]      INT      NULL
);

