﻿CREATE TABLE [dbo].[Facility] (
    [fc_id]           CHAR (6)      NULL,
    [fc_tax_id]       CHAR (9)      NOT NULL,
    [np_id]           CHAR (10)     NOT NULL,
    [cont_hmo]        INT           NULL,
    [cont_ppo]        INT           NULL,
    [cont_s]          INT           NULL,
    [fc_name]         CHAR (50)     NOT NULL,
    [addr1]           CHAR (30)     NULL,
    [addr2]           CHAR (30)     NULL,
    [city]            CHAR (30)     NOT NULL,
    [state]           CHAR (2)      NULL,
    [zip]             CHAR (10)     NULL,
    [phone1]          CHAR (14)     NULL,
    [fax]             CHAR (14)     NULL,
    [email]           VARCHAR (250) NOT NULL,
    [fc_opr_tory]     INT           NULL,
    [lname]           CHAR (15)     NULL,
    [fname]           CHAR (10)     NULL,
    [fc_license]      CHAR (18)     NOT NULL,
    [emergency_phone] CHAR (14)     NULL,
    [hndacs]          CHAR (1)      NULL
);

