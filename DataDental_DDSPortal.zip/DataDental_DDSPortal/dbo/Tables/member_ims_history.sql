﻿CREATE TABLE [dbo].[member_ims_history] (
    [Id]         INT      IDENTITY (1, 1) NOT NULL,
    [family_id]  INT      NULL,
    [updated_on] DATETIME NULL
);

