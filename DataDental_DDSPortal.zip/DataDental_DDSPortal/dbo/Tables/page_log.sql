﻿CREATE TABLE [dbo].[page_log] (
    [log_id]       INT           IDENTITY (1, 1) NOT NULL,
    [page_id]      INT           NULL,
    [user_id]      INT           NULL,
    [visited_date] DATETIME      NULL,
    [device_type]  VARCHAR (MAX) NULL,
    [portal_type]  VARCHAR (MAX) NULL,
    CONSTRAINT [PK__page_log__9E2397E0B44E995F] PRIMARY KEY CLUSTERED ([log_id] ASC)
);

