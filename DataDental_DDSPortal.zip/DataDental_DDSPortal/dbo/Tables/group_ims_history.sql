﻿CREATE TABLE [dbo].[group_ims_history] (
    [Id]         INT      IDENTITY (1, 1) NOT NULL,
    [group_id]   INT      NULL,
    [updated_on] DATETIME NULL
);

