﻿CREATE TABLE [dbo].[pl_rat] (
    [rate_code_id]    INT        NOT NULL,
    [rate_code]       CHAR (2)   NOT NULL,
    [rate_short_desc] CHAR (30)  NOT NULL,
    [rate_text]       CHAR (255) NULL,
    [rate_allow_subs] CHAR (1)   NOT NULL,
    [rate_num_depend] SMALLINT   NULL,
    [rate_sequence]   SMALLINT   NOT NULL,
    [spouse]          CHAR (1)   NULL,
    [num_facil]       SMALLINT   NULL,
    [pm_pm]           CHAR (1)   NULL,
    [ortho]           CHAR (1)   NULL,
    [standard]        CHAR (1)   NULL
);

