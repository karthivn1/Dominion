﻿CREATE TABLE [dbo].[stg_staff_provider_mapping] (
    [id]        INT             IDENTITY (1, 1) NOT NULL,
    [user_name] NVARCHAR (300)  NULL,
    [category]  NVARCHAR (1000) NULL
);

