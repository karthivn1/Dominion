﻿CREATE TABLE [dbo].[fc_staff] (
    [fc_id]          CHAR (6) NULL,
    [staff_code]     CHAR (2) NULL,
    [staff_type]     CHAR (1) NULL,
    [number_of_type] SMALLINT NULL
);

