﻿CREATE TABLE [dbo].[user_role_mapping] (
    [user_role_id] INT IDENTITY (1, 1) NOT NULL,
    [user_id]      INT NULL,
    [role_id]      INT NULL,
    CONSTRAINT [PK_user_role_mapping] PRIMARY KEY CLUSTERED ([user_role_id] ASC)
);

