﻿CREATE TABLE [dbo].[net_facility] (
    [net_fc_id]  INT           NOT NULL,
    [net_id]     INT           NOT NULL,
    [fc_id]      INT           NOT NULL,
    [con_type]   CHAR (3)      NOT NULL,
    [all_plans]  CHAR (1)      NULL,
    [ovr_ride]   CHAR (1)      NULL,
    [eff_date]   DATE          NOT NULL,
    [exp_date]   DATE          NULL,
    [h_user]     CHAR (15)     NULL,
    [h_datetime] DATETIME2 (7) NULL
);

