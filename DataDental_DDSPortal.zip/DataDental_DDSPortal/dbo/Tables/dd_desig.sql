﻿CREATE TABLE [dbo].[dd_desig] (
    [dd_desig_id] INT           NOT NULL,
    [subsys_code] CHAR (2)      NOT NULL,
    [sys_rec_id]  INT           NOT NULL,
    [desig_id]    INT           NOT NULL,
    [eff_date]    DATE          NOT NULL,
    [exp_date]    DATE          NULL,
    [h_user]      CHAR (10)     NOT NULL,
    [h_datetime]  DATETIME2 (0) NOT NULL,
    [reserved]    CHAR (1)      DEFAULT ('Y') NOT NULL,
    CONSTRAINT [dd_desg_pk] PRIMARY KEY CLUSTERED ([dd_desig_id] ASC)
);

