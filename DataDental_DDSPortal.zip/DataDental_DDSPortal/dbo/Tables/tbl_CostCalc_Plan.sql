﻿CREATE TABLE [dbo].[tbl_CostCalc_Plan] (
    [PlanID]   INT          NOT NULL,
    [PlanType] VARCHAR (60) NOT NULL,
    PRIMARY KEY CLUSTERED ([PlanID] ASC)
);

