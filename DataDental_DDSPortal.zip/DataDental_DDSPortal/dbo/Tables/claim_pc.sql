﻿CREATE TABLE [dbo].[claim_pc] (
    [claim_pc_id]     INT           NOT NULL,
    [claim_id]        INT           NOT NULL,
    [process_code_id] INT           NOT NULL,
    [claim_d_id]      INT           NULL,
    [deassigned_at]   DATETIME2 (7) NULL,
    [deassigned_by]   CHAR (15)     NULL,
    [h_datetime]      DATETIME2 (7) NOT NULL,
    [h_msi]           INT           NOT NULL,
    [h_action]        CHAR (2)      NOT NULL,
    [h_user]          CHAR (15)     NOT NULL
);

