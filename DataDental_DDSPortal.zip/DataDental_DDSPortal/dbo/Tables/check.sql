﻿CREATE TABLE [dbo].[check] (
    [eop_id]      INT             NULL,
    [check_nbr]   INT             NULL,
    [check_id]    INT             NULL,
    [entity_name] CHAR (50)       NULL,
    [amount]      NUMERIC (16, 2) NULL,
    [check_date]  DATE            NULL
);

