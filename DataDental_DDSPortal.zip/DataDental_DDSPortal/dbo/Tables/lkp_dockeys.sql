﻿CREATE TABLE [dbo].[lkp_dockeys] (
    [Id]          INT           IDENTITY (1, 1) NOT NULL,
    [doc_type_Id] INT           NULL,
    [key_no]      INT           NULL,
    [key_name]    NVARCHAR (50) NULL,
    CONSTRAINT [PK_lkp_docKeys] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_lkp_docKeys_lkp_doctype] FOREIGN KEY ([doc_type_Id]) REFERENCES [dbo].[lkp_doctype] ([Id])
);

