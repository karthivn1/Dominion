﻿CREATE TABLE [dbo].[event_template_mapping] (
    [event_template_id] INT      IDENTITY (1, 1) NOT NULL,
    [event_id]          INT      NOT NULL,
    [template_id]       INT      NOT NULL,
    [created_by]        INT      NULL,
    [created_date]      DATETIME NULL,
    [modified_by]       INT      NULL,
    [modified_date]     DATETIME NULL,
    CONSTRAINT [PK_event_template_mapping] PRIMARY KEY CLUSTERED ([event_template_id] ASC)
);

