﻿CREATE TABLE [dbo].[bm] (
    [aa]        INT       NOT NULL,
    [sys_id]    INT       NOT NULL,
    [a]         DATE      NULL,
    [value]     CHAR (50) NOT NULL,
    [b]         DATE      NULL,
    [bb]        INT       NOT NULL,
    [parm_name] CHAR (18) NOT NULL,
    [name]      CHAR (50) NOT NULL,
    [c]         DATE      NULL
);

