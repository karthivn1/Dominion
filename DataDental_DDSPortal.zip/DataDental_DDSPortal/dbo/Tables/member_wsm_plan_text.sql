﻿CREATE TABLE [dbo].[member_wsm_plan_text] (
    [plan_id]   INT          NOT NULL,
    [plan_type] VARCHAR (15) NULL
);

