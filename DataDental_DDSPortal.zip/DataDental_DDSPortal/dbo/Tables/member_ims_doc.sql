﻿CREATE TABLE [dbo].[member_ims_doc] (
    [Id]         INT           IDENTITY (1, 1) NOT NULL,
    [doc_id]     INT           NULL,
    [doc_type]   NVARCHAR (50) NULL,
    [doc_date]   DATE          NULL,
    [member_id]  INT           NULL,
    [firstname]  NVARCHAR (50) NULL,
    [lastname]   NVARCHAR (50) NULL,
    [isNew]      BIT           NULL,
    [InsertedOn] DATETIME      NULL
);

