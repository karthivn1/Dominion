﻿CREATE TABLE [dbo].[typ_table] (
    [typ_table_id] INT       IDENTITY (1, 1) NOT NULL,
    [subsys_code]  CHAR (2)  NULL,
    [tab_name]     CHAR (18) NULL,
    [code]         CHAR (2)  NULL,
    [descr]        CHAR (35) NULL,
    [eff_date]     DATE      NULL,
    [exp_date]     DATE      NULL,
    [audit_rec]    INT       NULL,
    [stc]          CHAR (1)  NULL,
    [action]       CHAR (2)  NULL
);

