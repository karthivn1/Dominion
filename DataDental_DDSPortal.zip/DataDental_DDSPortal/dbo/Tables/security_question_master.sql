﻿CREATE TABLE [dbo].[security_question_master] (
    [security_question_id] INT            IDENTITY (1, 1) NOT NULL,
    [question]             VARCHAR (1000) NOT NULL,
    [isactive]             BIT            NOT NULL,
    [created_date]         DATETIME       NULL,
    [created_by]           INT            NULL,
    [modified_date]        DATETIME       NULL,
    [modified_by]          INT            NULL,
    CONSTRAINT [PK_security_question_master] PRIMARY KEY CLUSTERED ([security_question_id] ASC)
);

