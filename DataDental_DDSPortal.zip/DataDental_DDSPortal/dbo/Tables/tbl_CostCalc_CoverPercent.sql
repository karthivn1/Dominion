﻿CREATE TABLE [dbo].[tbl_CostCalc_CoverPercent] (
    [ProcCode]     CHAR (6)       NULL,
    [PlanID]       INT            NULL,
    [PercentCover] DECIMAL (6, 2) NULL
);

