﻿CREATE TABLE [dbo].[page_master] (
    [page_id]   INT           IDENTITY (1, 1) NOT NULL,
    [page_name] VARCHAR (300) NULL,
    CONSTRAINT [PK__page_mas__637F305A96A923A3] PRIMARY KEY CLUSTERED ([page_id] ASC)
);

