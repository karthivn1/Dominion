﻿CREATE TABLE [dbo].[rlmbgrpl] (
    [mb_gr_pl_id] INT           NOT NULL,
    [member_id]   INT           NULL,
    [group_id]    INT           NOT NULL,
    [plan_id]     INT           NOT NULL,
    [sign_flag]   CHAR (1)      NULL,
    [cobra_flag]  CHAR (1)      NULL,
    [rec_date]    DATE          NULL,
    [eff_gr_pl]   DATE          NOT NULL,
    [exp_gr_pl]   DATE          NULL,
    [action_code] CHAR (2)      NOT NULL,
    [h_datetime]  DATETIME2 (7) NOT NULL,
    [h_msi]       INT           NOT NULL,
    [h_action]    CHAR (2)      NOT NULL,
    [h_user]      CHAR (10)     NOT NULL,
    [sub_in_plan] SMALLINT      NOT NULL
);

