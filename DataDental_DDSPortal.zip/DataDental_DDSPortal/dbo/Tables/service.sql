﻿CREATE TABLE [dbo].[service] (
    [claim_id]      INT             NOT NULL,
    [claim_d_id]    INT             NOT NULL,
    [status]        VARCHAR (10)    NULL,
    [d_proc_code]   CHAR (5)        NOT NULL,
    [tooth_no]      CHAR (2)        NULL,
    [surface]       CHAR (5)        NULL,
    [svc_beg]       CHAR (10)       NULL,
    [submitted_amt] NUMERIC (16, 2) NOT NULL,
    [allowed]       NUMERIC (16, 2) NOT NULL,
    [ded_applied]   NUMERIC (16, 2) NOT NULL,
    [patient_resp]  NUMERIC (16, 2) NOT NULL,
    [plan_resp]     NUMERIC (16, 2) NOT NULL,
    [perc_covered]  VARCHAR (4)     NULL,
    [prod_code1]    INT             NULL,
    [prod_code2]    INT             NULL,
    [prod_code3]    INT             NULL,
    [prod_code4]    INT             NULL,
    [prod_code5]    INT             NULL
);

