﻿CREATE TABLE [dbo].[dd_desig_det] (
    [desig_det_id] INT           NOT NULL,
    [dd_desig_id]  INT           NOT NULL,
    [desig_value]  VARCHAR (255) NOT NULL,
    [eff_date]     DATE          NOT NULL,
    [exp_date]     DATE          NULL,
    [h_user]       CHAR (10)     NOT NULL,
    [h_datetime]   DATETIME      NOT NULL,
    CONSTRAINT [dd_desig_det_pk] PRIMARY KEY CLUSTERED ([desig_det_id] ASC)
);

