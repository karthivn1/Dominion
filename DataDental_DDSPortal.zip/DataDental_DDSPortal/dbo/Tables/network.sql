﻿CREATE TABLE [dbo].[network] (
    [net_id]     INT            NOT NULL,
    [alt_id]     CHAR (20)      NULL,
    [name]       CHAR (45)      NULL,
    [descr]      VARCHAR (255)  NULL,
    [state]      CHAR (2)       NULL,
    [ins_type]   CHAR (2)       NULL,
    [con_type]   CHAR (3)       NULL,
    [net_type]   CHAR (2)       NULL,
    [eff_date]   DATE           NOT NULL,
    [exp_date]   DATE           NULL,
    [barrier_c]  DECIMAL (6, 2) NULL,
    [h_datetime] DATETIME       NULL,
    [h_user]     CHAR (15)      NULL,
    CONSTRAINT [network_pk] PRIMARY KEY CLUSTERED ([net_id] ASC)
);

