﻿CREATE TABLE [dbo].[tbl_CostCalc_Category] (
    [CategoryNum]  SMALLINT     NOT NULL,
    [CategoryName] VARCHAR (60) NOT NULL,
    PRIMARY KEY CLUSTERED ([CategoryNum] ASC)
);

