﻿CREATE TABLE [dbo].[Void] (
    [d_type]      VARCHAR (1)  NOT NULL,
    [eop_id]      INT          NULL,
    [claim_id]    INT          NOT NULL,
    [claim_date]  CHAR (10)    NULL,
    [last_name]   CHAR (15)    NOT NULL,
    [first_name]  CHAR (15)    NOT NULL,
    [claim_no]    NUMERIC (16) NOT NULL,
    [member_id]   INT          NOT NULL,
    [document_no] CHAR (15)    NOT NULL
);

