﻿CREATE TABLE [dbo].[batch_process_details] (
    [batch_id]       INT           IDENTITY (1, 1) NOT NULL,
    [ref_id]         INT           NOT NULL,
    [event_id]       INT           NOT NULL,
    [status]         INT           NOT NULL,
    [retry]          INT           NOT NULL,
    [error]          VARCHAR (MAX) NULL,
    [completed_time] DATETIME      NULL,
    [created_date]   DATETIME      NULL,
    CONSTRAINT [PK_batch_process_details] PRIMARY KEY CLUSTERED ([batch_id] ASC)
);

