﻿CREATE TABLE [dbo].[message] (
    [message_id]      INT            IDENTITY (1, 1) NOT NULL,
    [message]         VARCHAR (MAX)  NULL,
    [message_subject] VARCHAR (1500) NULL,
    [parentid]        INT            NULL,
    [message_type_id] INT            NULL,
    [created_by]      INT            NULL,
    [created_date]    DATETIME       NULL,
    [from_address]    VARCHAR (300)  NULL,
    CONSTRAINT [PK_message] PRIMARY KEY CLUSTERED ([message_id] ASC)
);

