﻿CREATE TABLE [dbo].[event_master] (
    [event_id]       INT           IDENTITY (1, 1) NOT NULL,
    [event_category] VARCHAR (25)  NOT NULL,
    [event_module]   VARCHAR (25)  NOT NULL,
    [event_type]     VARCHAR (25)  NULL,
    [event_name]     VARCHAR (50)  NOT NULL,
    [event_desc]     VARCHAR (500) NULL,
    [created_by]     INT           NULL,
    [created_date]   DATETIME      NULL,
    [modified_by]    INT           NULL,
    [modified_date]  DATETIME      NULL,
    [ref_object]     NVARCHAR (50) NULL,
    CONSTRAINT [PK_event_master] PRIMARY KEY CLUSTERED ([event_id] ASC)
);

