﻿CREATE TABLE [dbo].[duebalance] (
    [group_id]  INT             NOT NULL,
    [amnt_due]  DECIMAL (16, 2) NOT NULL,
    [amnt_crdt] DECIMAL (16, 2) NOT NULL
);

