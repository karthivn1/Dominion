﻿CREATE TABLE [dbo].[Fc_assoc] (
    [fc_assoc_id] INT      NOT NULL,
    [fc_id]       INT      NULL,
    [pv_id]       INT      NULL,
    [assoc_type]  CHAR (1) NULL,
    [eff_date]    DATE     NULL,
    [exp_date]    DATE     NULL
);

