﻿CREATE TABLE [dbo].[api_process_details] (
    [process_id]     INT            IDENTITY (1, 1) NOT NULL,
    [api_type]       NVARCHAR (20)  NULL,
    [trace_number]   INT            NULL,
    [request]        NVARCHAR (MAX) NULL,
    [response]       NVARCHAR (MAX) NULL,
    [is_error]       BIT            NULL,
    [completed_time] DATETIME       NULL,
    [created_date]   DATETIME       NULL,
    [group_id]       INT            NULL,
    [dls_batch_id]   INT            NULL,
    [error_message]  NVARCHAR (MAX) NULL,
    CONSTRAINT [PK_api_process_details] PRIMARY KEY CLUSTERED ([process_id] ASC)
);

