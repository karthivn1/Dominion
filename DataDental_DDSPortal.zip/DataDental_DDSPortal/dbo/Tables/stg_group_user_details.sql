﻿CREATE TABLE [dbo].[stg_group_user_details] (
    [UserPointer]            BIGINT        NULL,
    [UserName]               VARCHAR (20)  NULL,
    [UserType]               SMALLINT      NULL,
    [UserStatus]             SMALLINT      NULL,
    [LastName]               VARCHAR (50)  NULL,
    [FirstName]              VARCHAR (15)  NULL,
    [MiddleInitial]          VARCHAR (20)  NULL,
    [Phone]                  VARCHAR (20)  NULL,
    [EmailNotification]      SMALLINT      NULL,
    [family_id]              VARCHAR (50)  NULL,
    [plan_id]                VARCHAR (4)   NULL,
    [group_id]               VARCHAR (50)  NULL,
    [CreationDate]           DATETIME      NULL,
    [CreatedBy]              VARCHAR (10)  NULL,
    [LastUpdateDate]         VARCHAR (50)  NULL,
    [LastUpdatedBy]          VARCHAR (50)  NULL,
    [LastPasswordUpdateDate] DATETIME      NULL,
    [Email]                  VARCHAR (300) NULL
);

