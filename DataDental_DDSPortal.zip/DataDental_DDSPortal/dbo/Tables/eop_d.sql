﻿CREATE TABLE [dbo].[eop_d] (
    [eop_d_id]      INT       NOT NULL,
    [eop_master_id] INT       NOT NULL,
    [claim_id]      INT       NOT NULL,
    [claim_d_id]    INT       NOT NULL,
    [entity_oc_id]  INT       NOT NULL,
    [group_id]      INT       NOT NULL,
    [group_oc_id]   INT       NOT NULL,
    [format]        CHAR (30) NOT NULL,
    [pay_method]    SMALLINT  NOT NULL,
    [eop_id]        INT       NOT NULL
);

