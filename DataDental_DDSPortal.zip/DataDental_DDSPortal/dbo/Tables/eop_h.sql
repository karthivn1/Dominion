﻿CREATE TABLE [dbo].[eop_h] (
    [eop_id]          INT           NOT NULL,
    [eop_master_id]   INT           NOT NULL,
    [eop_blob_id]     INT           NOT NULL,
    [created_on]      DATETIME2 (7) NOT NULL,
    [reprinted]       DATETIME2 (7) NULL,
    [reprint_counter] INT           NOT NULL,
    [pay_method]      INT           NOT NULL,
    [check_id]        INT           NOT NULL,
    [bal_forward]     SMALLINT      NOT NULL,
    [void_switch]     SMALLINT      NOT NULL
);

