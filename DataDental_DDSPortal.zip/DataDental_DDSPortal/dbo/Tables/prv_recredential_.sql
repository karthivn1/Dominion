﻿CREATE TABLE [dbo].[prv_recredential_] (
    [provider_id]          INT          NOT NULL,
    [recredentialing_date] DATE         NULL,
    [status]               VARCHAR (18) NOT NULL
);

