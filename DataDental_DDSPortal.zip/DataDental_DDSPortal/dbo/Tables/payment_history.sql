﻿CREATE TABLE [dbo].[payment_history] (
    [paymenthistory_id] INT             IDENTITY (1, 1) NOT NULL,
    [transaction_id]    NVARCHAR (100)  NULL,
    [group_id]          INT             NULL,
    [payment_date]      DATETIME        NULL,
    [amountpaid]        DECIMAL (16, 2) NULL,
    [payment_method]    VARCHAR (150)   NULL
);

