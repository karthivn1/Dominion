﻿CREATE TABLE [dbo].[fc_language] (
    [fc_id]     CHAR (6) NULL,
    [lang_code] CHAR (2) NULL,
    [doctor]    CHAR (1) NULL,
    [staff]     CHAR (1) NULL
);

