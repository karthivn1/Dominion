﻿CREATE TABLE [dbo].[autodebit_details] (
    [autodebit_id]  INT      IDENTITY (1, 1) NOT NULL,
    [group_id]      INT      NULL,
    [autodebit]     BIT      NULL,
    [modified_date] DATETIME NULL,
    [modified_by]   INT      NULL,
    CONSTRAINT [PK_autodebit_details] PRIMARY KEY CLUSTERED ([autodebit_id] ASC)
);

