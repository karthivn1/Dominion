﻿CREATE TABLE [dbo].[provider_user_details_bak] (
    [user_id]                INT           IDENTITY (1, 1) NOT NULL,
    [user_name]              VARCHAR (20)  NOT NULL,
    [password_hash]          VARCHAR (300) NULL,
    [temp_password]          VARCHAR (300) NULL,
    [last_password]          VARCHAR (300) NULL,
    [email]                  VARCHAR (300) NULL,
    [status_id]              INT           NULL,
    [password_reset_date]    DATETIME      NULL,
    [facility_id]            INT           NULL,
    [facility_tax_id]        NVARCHAR (25) NULL,
    [facility_zip_code]      VARCHAR (10)  NULL,
    [last_name]              VARCHAR (25)  NULL,
    [failed_login_attempt]   INT           NULL,
    [created_date]           DATETIME      NULL,
    [created_by]             INT           NULL,
    [role_id]                INT           NULL,
    [is_firstlogin]          BIT           NULL,
    [forgot_password_time]   DATETIME      NULL,
    [last_action_date]       DATETIME      NULL,
    [updated_date]           DATETIME      NULL,
    [temp_password_unhashed] VARCHAR (50)  NULL
);

