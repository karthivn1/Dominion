﻿CREATE TABLE [dbo].[group_renewal] (
    [group_renewal_id] INT           IDENTITY (1, 1) NOT NULL,
    [group_id]         INT           NOT NULL,
    [renewal_period]   SMALLINT      NULL,
    [renewal_date]     DATE          NULL,
    [renewal_memo]     VARCHAR (255) NULL,
    [renewal_datetime] DATETIME      NULL,
    [renewal_userid]   CHAR (15)     NULL,
    [voided_flag]      CHAR (1)      NULL,
    [voided_datetime]  DATETIME      NULL,
    [voided_userid]    CHAR (15)     NULL,
    [icomm_flag]       CHAR (1)      NULL,
    [icomm_datetime]   DATETIME      NULL,
    [icomm_userid]     CHAR (15)     NULL,
    [ivoid_flag]       CHAR (1)      NULL
);

