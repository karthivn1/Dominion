﻿CREATE TABLE [dbo].[member_message_attachment] (
    [attachment_id]       INT             IDENTITY (1, 1) NOT NULL,
    [message_id]          INT             NOT NULL,
    [attachment_filename] VARCHAR (350)   NULL,
    [attachment_file]     VARBINARY (MAX) NULL,
    CONSTRAINT [PK_member_message_attachment] PRIMARY KEY CLUSTERED ([attachment_id] ASC)
);

