﻿CREATE TABLE [dbo].[lkp_status] (
    [status_id] INT        IDENTITY (1001, 1) NOT NULL,
    [status]    NCHAR (10) NULL,
    CONSTRAINT [PK_lkp_status] PRIMARY KEY CLUSTERED ([status_id] ASC)
);

