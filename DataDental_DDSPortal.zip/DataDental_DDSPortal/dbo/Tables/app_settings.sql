﻿CREATE TABLE [dbo].[app_settings] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [Key]         NVARCHAR (50)  NULL,
    [Value]       NVARCHAR (MAX) NULL,
    [Desc]        NVARCHAR (50)  NULL,
    [Environment] NCHAR (10)     NULL,
    [InsertedOn]  DATETIME       NULL,
    [UpdatedOn]   DATETIME       NULL,
    [status]      BIT            NULL,
    CONSTRAINT [PK_app_settings] PRIMARY KEY CLUSTERED ([Id] ASC)
);

