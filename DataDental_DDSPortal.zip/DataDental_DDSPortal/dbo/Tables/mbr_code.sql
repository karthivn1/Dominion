﻿CREATE TABLE [dbo].[mbr_code] (
    [mbr_code]      CHAR (3)  NULL,
    [mbr_code_desc] CHAR (30) NULL,
    [h_datetime]    DATETIME  NULL,
    [h_msi]         INT       NULL,
    [h_action]      CHAR (2)  NULL,
    [h_user]        CHAR (10) NULL,
    [gender]        SMALLINT  DEFAULT ((0)) NOT NULL,
    [relation]      SMALLINT  DEFAULT ((0)) NOT NULL
);

