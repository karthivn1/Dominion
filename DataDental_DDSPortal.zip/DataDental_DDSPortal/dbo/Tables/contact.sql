﻿CREATE TABLE [dbo].[contact] (
    [contact_id]   INT           IDENTITY (1, 1) NOT NULL,
    [subsys_code]  CHAR (2)      NULL,
    [sys_rec_id]   INT           NULL,
    [con_type]     CHAR (2)      NULL,
    [fname]        CHAR (10)     NULL,
    [lname]        CHAR (15)     NULL,
    [title]        CHAR (25)     NULL,
    [phone1]       CHAR (14)     NULL,
    [phone1_cntry] CHAR (3)      NULL,
    [ext1]         CHAR (5)      NULL,
    [phone2]       CHAR (14)     NULL,
    [phone2_cntry] CHAR (3)      NULL,
    [ext2]         CHAR (5)      NULL,
    [fax]          CHAR (14)     NULL,
    [fax_cntry]    CHAR (3)      NULL,
    [history_rec]  INT           NULL,
    [addr_type]    CHAR (2)      NULL,
    [email]        VARCHAR (250) DEFAULT ('') NOT NULL
);

