﻿CREATE TABLE [dbo].[fc_disc] (
    [code]  CHAR (2)  NULL,
    [descr] CHAR (35) NULL
);

