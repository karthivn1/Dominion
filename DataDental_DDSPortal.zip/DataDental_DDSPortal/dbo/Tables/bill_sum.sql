﻿CREATE TABLE [dbo].[bill_sum] (
    [group_id]        INT             NULL,
    [invoice_num]     INT             NOT NULL,
    [bil_gen_date]    DATETIME        NULL,
    [bil_from_date]   DATE            NULL,
    [bil_to_date]     DATE            NULL,
    [tot_prems]       DECIMAL (16, 2) NULL,
    [tot_fees]        DECIMAL (16, 2) NULL,
    [tot_adj]         DECIMAL (16, 2) NULL,
    [subs_added]      INT             NULL,
    [subs_termed]     INT             NULL,
    [bal_forward]     DECIMAL (16, 2) NULL,
    [reversal_id]     INT             NULL,
    [rev_date]        DATETIME        NULL,
    [rev_user]        CHAR (20)       NULL,
    [due_date]        DATE            NULL,
    [bill_status]     CHAR (2)        NULL,
    [old_bil_to_date] DATE            NULL,
    [bil_dt_reset_sw] CHAR (1)        DEFAULT ('N') NULL
);

