﻿CREATE TABLE [dbo].[message_detail] (
    [message_details_id]  INT      IDENTITY (1, 1) NOT NULL,
    [message_id]          INT      NULL,
    [message_receiver_id] INT      NULL,
    [received_date]       DATETIME NULL,
    [is_read]             BIT      NULL,
    [is_new]              BIT      NULL,
    [is_delete]           BIT      NULL,
    [is_reply]            BIT      NULL,
    CONSTRAINT [PK_message_detail] PRIMARY KEY CLUSTERED ([message_details_id] ASC)
);

