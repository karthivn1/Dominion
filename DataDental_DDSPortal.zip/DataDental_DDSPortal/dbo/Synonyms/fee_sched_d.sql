﻿CREATE SYNONYM [dbo].[fee_sched_d] FOR [dds_prod_1031].[dbo].[fee_sched_d];

