﻿CREATE SYNONYM [dbo].[plx_dent_cat] FOR [dds_prod_1031].[dbo].[plx_dent_cat];

