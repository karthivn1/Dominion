﻿CREATE SYNONYM [dbo].[facility_sec] FOR [dds_prod_1031].[dbo].[facility];

