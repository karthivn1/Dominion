﻿CREATE SYNONYM [dbo].[state_sec] FOR [dds_prod_1031].[dbo].[state];

