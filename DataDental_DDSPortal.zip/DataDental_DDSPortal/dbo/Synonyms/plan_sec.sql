﻿CREATE SYNONYM [dbo].[plan_sec] FOR [dds_prod_1031].[dbo].[plan];

