﻿CREATE SYNONYM [dbo].[role_master_sec] FOR [dds_prod_1031].[dbo].[role_master];

