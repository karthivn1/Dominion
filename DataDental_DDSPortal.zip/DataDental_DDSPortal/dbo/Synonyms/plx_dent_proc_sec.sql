﻿CREATE SYNONYM [dbo].[plx_dent_proc_sec] FOR [dds_prod_1031].[dbo].[plx_dent_proc];

