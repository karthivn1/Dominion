﻿CREATE SYNONYM [dbo].[rlmbgrpl_sec] FOR [dds_prod_1031].[dbo].[rlmbgrpl];

