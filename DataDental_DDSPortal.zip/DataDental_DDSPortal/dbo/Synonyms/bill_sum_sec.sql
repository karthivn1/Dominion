﻿CREATE SYNONYM [dbo].[bill_sum_sec] FOR [dds_prod_1031].[dbo].[bill_sum];

