﻿CREATE SYNONYM [dbo].[mbr_code_sec] FOR [dds_prod_1031].[dbo].[mbr_code];

