﻿CREATE SYNONYM [dbo].[plx_dent_proc] FOR [dds_prod_1031].[dbo].[plx_dent_proc];

