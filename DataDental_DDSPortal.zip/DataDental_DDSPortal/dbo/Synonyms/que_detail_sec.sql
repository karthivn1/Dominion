﻿CREATE SYNONYM [dbo].[que_detail_sec] FOR [dds_prod_1031].[dbo].[que_detail];

