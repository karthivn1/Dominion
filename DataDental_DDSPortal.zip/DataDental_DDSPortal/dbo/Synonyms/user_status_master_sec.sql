﻿CREATE SYNONYM [dbo].[user_status_master_sec] FOR [dds_prod_1031].[dbo].[user_status_master];

