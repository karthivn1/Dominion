﻿CREATE SYNONYM [dbo].[fc_assoc_sec] FOR [dds_prod_1031].[dbo].[fc_assoc];

