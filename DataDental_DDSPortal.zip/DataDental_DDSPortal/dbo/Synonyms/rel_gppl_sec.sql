﻿CREATE SYNONYM [dbo].[rel_gppl_sec] FOR [dds_prod_1031].[dbo].[rel_gppl];

