﻿CREATE SYNONYM [dbo].[pl_rat_sec] FOR [dds_prod_1031].[dbo].[pl_rat];

