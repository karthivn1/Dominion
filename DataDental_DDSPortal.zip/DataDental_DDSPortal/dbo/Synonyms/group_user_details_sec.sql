﻿CREATE SYNONYM [dbo].[group_user_details_sec] FOR [dds_prod_1031].[dbo].[group_user_details];

