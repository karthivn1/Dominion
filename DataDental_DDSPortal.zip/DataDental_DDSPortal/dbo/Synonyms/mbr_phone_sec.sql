﻿CREATE SYNONYM [dbo].[mbr_phone_sec] FOR [dds_prod_1031].[dbo].[mbr_phone];

