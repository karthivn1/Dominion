﻿CREATE SYNONYM [dbo].[contact_sec] FOR [dds_prod_1031].[dbo].[contact];

