﻿CREATE SYNONYM [dbo].[rlmbrt_sec] FOR [dds_prod_1031].[dbo].[rlmbrt];

