﻿CREATE SYNONYM [dbo].[member_sec] FOR [dds_prod_1031].[dbo].[member];

