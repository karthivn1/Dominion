﻿CREATE SYNONYM [dbo].[typ_table_sec] FOR [dds_prod_1031].[dbo].[typ_table];

