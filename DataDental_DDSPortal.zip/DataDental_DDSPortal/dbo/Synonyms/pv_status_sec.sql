﻿CREATE SYNONYM [dbo].[pv_status_sec] FOR [dds_prod_1031].[dbo].[pv_status];

