﻿CREATE SYNONYM [dbo].[group_rules_sec] FOR [dds_prod_1031].[dbo].[group_rules];

