﻿CREATE SYNONYM [dbo].[al_batches_sec] FOR [dds_prod_1031].[dbo].[al_batches];

