﻿CREATE SYNONYM [dbo].[rlplfc_sec] FOR [dds_prod_1031].[dbo].[rlplfc];

