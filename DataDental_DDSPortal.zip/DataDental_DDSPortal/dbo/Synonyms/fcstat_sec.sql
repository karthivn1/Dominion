﻿CREATE SYNONYM [dbo].[fcstat_sec] FOR [dds_prod_1031].[dbo].[fcstat];

