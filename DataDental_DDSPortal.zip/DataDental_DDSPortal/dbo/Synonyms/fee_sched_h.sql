﻿CREATE SYNONYM [dbo].[fee_sched_h] FOR [dds_prod_1031].[dbo].[fee_sched_h];

