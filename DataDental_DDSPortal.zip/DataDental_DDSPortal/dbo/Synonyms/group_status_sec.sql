﻿CREATE SYNONYM [dbo].[group_status_sec] FOR [dds_prod_1031].[dbo].[group_status];

