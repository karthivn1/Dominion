﻿CREATE SYNONYM [dbo].[group_sec] FOR [dds_prod_1031].[dbo].[group];

