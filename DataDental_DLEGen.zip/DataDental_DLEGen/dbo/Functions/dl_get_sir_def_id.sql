﻿CREATE FUNCTION [dbo].[dl_get_sir_def_id]
    (
      @a_sir_def_name CHAR(18)
    )
RETURNS INT
AS
    BEGIN
/*
-- This function was converted on Fri Aug 19 04:59:59 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10

00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @i_sir_def_id INT;

        DECLARE @i_sir_def_id_1 INT;
        

        SELECT  @i_sir_def_id = sir_def_id
        FROM    dbo.dl_sir_def (NOLOCK)
        WHERE   sir_def_name = @a_sir_def_name
                AND sir_def_type = 'S';

       IF (ISNULL(@i_sir_def_id,'')<>'')

					SET @i_sir_def_id_1 = @i_sir_def_id;

                    RETURN @i_sir_def_id;
          END;