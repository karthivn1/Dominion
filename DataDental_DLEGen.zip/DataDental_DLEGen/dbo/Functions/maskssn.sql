﻿CREATE FUNCTION dbo.maskssn
(
    @ssn VARCHAR(11)
)
RETURNS varchar(50) -- or whatever length you need
AS
BEGIN
	DECLARE @CharAt5 VARCHAR(100);
	DECLARE @MaskedSSN VARCHAR(50);
	DECLARE @aux VARCHAR(50);
	DECLARE @aux2 VARCHAR(50);

	SET @ssn = REPLACE(@ssn, '-', '');
	SET @CharAt5 = substring(@ssn, 5, 1);
	SET @aux2=reverse(substring(@ssn, len(@ssn)-3, 4));
	SET @aux=substring(reverse(substring(@ssn, 1, 4)), 1, 2) + reverse(substring(reverse(substring(@ssn, 1, 4)) + reverse(substring(@ssn, len(@ssn)-3, 4)), 2, 5)) + substring(@aux2, len(@aux2)-1, 2);

	SET @aux2= substring (@aux,1, 3) + '-' + substring(@aux,4,len(@aux));
	SET @MaskedSSN=substring (@aux2,1, 6) + '-' + substring(@aux2,7,len(@aux2));
	SET @MaskedSSN = substring  (@MaskedSSN,1, 8 ) + @CharAt5 + substring(@MaskedSSN,10,len(@MaskedSSN));

	RETURN @MaskedSSN;

END