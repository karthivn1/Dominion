﻿CREATE FUNCTION [dbo].[udf_getGlobalVar] (@VarName VARCHAR(255))
RETURNS VARCHAR(255)
AS
BEGIN
  DECLARE @VarValue VARCHAR(255)

  SELECT @VarValue = VarValue FROM GlobalVar WHERE VarName = @VarName
  RETURN @VarValue 
END