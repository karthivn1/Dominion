﻿CREATE FUNCTION [dbo].[udf_dl_GetUserAccess]
(
	@SysId INT,
	@OptType VARCHAR(3),
	@UserName varchar(15)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
	DECLARE @UserAccess NVARCHAR(MAX)
	DECLARE @UserId INT
	SELECT @UserId=usersl_id FROM stc_user WHERE user_id=@UserName
	


	--SELECT @UserAccess = STUFF(( 
	
	--SELECT  distinct ', ' +b.sys_access_type
	--	FROM stc_user_access a, stc_sys_opt b
	--	WHERE b.sys_id = @SysId AND 
	--		b.sys_opt_type = @OptType AND
	--		a.sys_opt_id = b.sys_opt_id AND
	--		(a.usersl_id IN (SELECT group_id FROM stc_user_group WHERE usersl_id = @UserId AND (
	--								eff_date <= GETDATE() AND 	(exp_date > GETDATE() OR exp_date IS NULL)
	--							)) 
	--			OR a.usersl_id = @UserId) 
	--		AND (a.eff_date <= GETDATE() AND (a.exp_date > GETDATE() OR a.exp_date IS NULL))
	--		 FOR XML PATH(''), TYPE).
 --              value('.','NVARCHAR(MAX)'),1,2,'') 
	
				SELECT @UserAccess = COALESCE(@UserAccess + ',', '') + sys_access_type from


				(SELECT  distinct b.sys_access_type
		FROM stc_user_access a, stc_sys_opt b
		WHERE b.sys_id = @SysId AND 
			b.sys_opt_type = @OptType AND
			a.sys_opt_id = b.sys_opt_id AND
			(a.usersl_id IN (SELECT group_id FROM stc_user_group WHERE usersl_id = @UserId AND (
									eff_date <= GETDATE() AND 	(exp_date > GETDATE() OR exp_date IS NULL)
								)) 
				OR a.usersl_id = @UserId) 
			AND (a.eff_date <= GETDATE() AND (a.exp_date > GETDATE() OR a.exp_date IS NULL))) as test
	
	RETURN @UserAccess
END