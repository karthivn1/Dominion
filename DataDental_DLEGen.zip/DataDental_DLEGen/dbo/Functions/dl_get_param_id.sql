﻿CREATE FUNCTION [dbo].[dl_get_param_id]
    (
      @a_batch_id INT ,
      @a_sp_id INT ,
      @a_param_name VARCHAR(18)
    )
RETURNS INT
AS
    BEGIN
/*
-- This function was converted on Fri Aug 19 04:59:59 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10

00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_sp_id INT;
        DECLARE @i_sp_param_id INT;

		DECLARE @i_sp_param_id_F INT

		SET @i_sp_param_id_F = 0

        IF @a_sp_id IS NULL
            OR @a_sp_id <= 0
            RETURN -1;

        SELECT  @i_sp_param_id = sp_param_id
        FROM    dbo.dl_sp_param (NOLOCK)
        WHERE   sp_id = @a_sp_id
                AND param_name = @a_param_name;
			
			IF (ISNULL(@i_sp_param_id,'')<>'')
			SET @i_sp_param_id_F = @i_sp_param_id;
			     
        RETURN @i_sp_param_id_F;

    END;