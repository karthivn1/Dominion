﻿CREATE FUNCTION [dbo].[fn_GetGroupModAccess] 
(   
    @groupId int,
	@modname varchar(50),
	@subsyscode varchar(50)
)

RETURNS  int
AS
BEGIN
	Declare @modAccessId Int, @access Int
	
	SELECT @access = modacc.access, @modAccessId = modacc_id FROM mod_acc modacc inner join mod_def  moddef on moddef.mod_id = modacc.mod_id 
	WHERE modacc.usersl_id = @groupId and  modacc.type = 'GP'
	and moddef.menu_opt = @modname AND moddef.subsys_code = @subsyscode 
	and (modacc.eff_date <= GetDate() AND (modacc.exp_date > GetDate() OR modacc.exp_date is NULL));
	
    if (@@ROWCOUNT = 0)
		begin
		   return 0
		end
    else 
		begin
			if(@access = 1)
				Begin
					return @modAccessId
			
				End
			Else
				Begin
					return 0
				End
		end
	return 0
END