﻿CREATE FUNCTION [dbo].[is_pattern_arg]
    (
      @str1 VARCHAR(255) ,
      @options CHAR(4000)
    )
RETURNS INT
AS
    BEGIN
/*
-- This function was converted on Fri Aug 19 04:58:58 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10
00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        RETURN 1;
    END;