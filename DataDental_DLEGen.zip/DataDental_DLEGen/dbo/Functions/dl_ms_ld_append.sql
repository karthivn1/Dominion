﻿CREATE FUNCTION [dbo].[dl_ms_ld_append] ( @i_file_idx INT )
RETURNS CHAR(2)
AS
    BEGIN
/*
-- This function was converted on Fri Aug 19 02:29:29 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10
00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_idx_mod INT;
        DECLARE @i_idx_div INT;
        DECLARE @f_pre CHAR(1);
        DECLARE @s_pre CHAR(1);

--  set debug file to "/tmp/dl_ms_ld_append.trc";
--  trace on;

        SET @i_idx_mod = @i_file_idx % 26;	
        SET @i_idx_div = CONVERT(DECIMAL, ( @i_file_idx - 1 )) / 26;

        IF @i_idx_mod >= 1
            AND @i_idx_mod <= 10
            IF @i_idx_mod = 1
                SET @s_pre = 'a';
            ELSE
                IF @i_idx_mod = 2
                    SET @s_pre = 'b';
                ELSE
                    IF @i_idx_mod = 3
                        SET @s_pre = 'c';
                    ELSE
                        IF @i_idx_mod = 4
                            SET @s_pre = 'd';
                        ELSE
                            IF @i_idx_mod = 5
                                SET @s_pre = 'e';
                            ELSE
                                IF @i_idx_mod = 6
                                    SET @s_pre = 'f';
                                ELSE
                                    IF @i_idx_mod = 7
                                        SET @s_pre = 'g';
                                    ELSE
                                        IF @i_idx_mod = 8
                                            SET @s_pre = 'h';
                                        ELSE
                                            IF @i_idx_mod = 9
                                                SET @s_pre = 'i';
                                            ELSE
                                                IF @i_idx_mod = 10
                                                    SET @s_pre = 'j';
		    
                                                ELSE
                                                    IF @i_idx_mod >= 11
                                                        AND @i_idx_mod <= 20
                                                        IF @i_idx_mod = 11
                                                            SET @s_pre = 'k';
                                                        ELSE
                                                            IF @i_idx_mod = 12
                                                              SET @s_pre = 'l';
                                                            ELSE
                                                              IF @i_idx_mod = 13
                                                              SET @s_pre = 'm';
                                                              ELSE
                                                              IF @i_idx_mod = 14
                                                              SET @s_pre = 'n';
                                                              ELSE
                                                              IF @i_idx_mod = 15
                                                              SET @s_pre = 'o';
                                                              ELSE
                                                              IF @i_idx_mod = 16
                                                              SET @s_pre = 'p';
                                                              ELSE
                                                              IF @i_idx_mod = 17
                                                              SET @s_pre = 'q';
                                                              ELSE
                                                              IF @i_idx_mod = 18
                                                              SET @s_pre = 'r';
                                                              ELSE
                                                              IF @i_idx_mod = 19
                                                              SET @s_pre = 's';
                                                              ELSE
                                                              IF @i_idx_mod = 20
                                                              SET @s_pre = 't';
      
                                                              ELSE
                                                              IF @i_idx_mod = 21
                                                              SET @s_pre = 'u';
                                                              ELSE
                                                              IF @i_idx_mod = 22
                                                              SET @s_pre = 'v';
                                                              ELSE
                                                              IF @i_idx_mod = 23
                                                              SET @s_pre = 'w';
                                                              ELSE
                                                              IF @i_idx_mod = 24
                                                              SET @s_pre = 'x';
                                                              ELSE
                                                              IF @i_idx_mod = 25
                                                              SET @s_pre = 'y';
                                                              ELSE
                                                              IF @i_idx_mod = 0
                                                              SET @s_pre = 'z';
    

        IF @i_idx_div >= 0.00
            AND @i_idx_div <= 9.00
            IF @i_idx_div = 0.00
                SET @f_pre = 'a';
            ELSE
                IF @i_idx_div = 1
                    SET @f_pre = 'b';
                ELSE
                    IF @i_idx_div = 2
                        SET @f_pre = 'c';
                    ELSE
                        IF @i_idx_div = 3
                            SET @f_pre = 'd';
                        ELSE
                            IF @i_idx_div = 4
                                SET @f_pre = 'e';
                            ELSE
                                IF @i_idx_div = 5
                                    SET @f_pre = 'f';
                                ELSE
                                    IF @i_idx_div = 6
                                        SET @f_pre = 'g';
                                    ELSE
                                        IF @i_idx_div = 7
                                            SET @f_pre = 'h';
                                        ELSE
                                            IF @i_idx_div = 8
                                                SET @f_pre = 'i';
                                            ELSE
                                                IF @i_idx_div = 9
                                                    SET @f_pre = 'j';
		    
                                                ELSE
                                                    IF @i_idx_div >= 10
                                                        AND @i_idx_div <= 19
                                                        IF @i_idx_div = 10
                                                            SET @f_pre = 'k';
                                                        ELSE
                                                            IF @i_idx_div = 11
                                                              SET @f_pre = 'l';
                                                            ELSE
                                                              IF @i_idx_div = 12
                                                              SET @f_pre = 'm';
                                                              ELSE
                                                              IF @i_idx_div = 13
                                                              SET @f_pre = 'n';
                                                              ELSE
                                                              IF @i_idx_div = 14
                                                              SET @f_pre = 'o';
                                                              ELSE
                                                              IF @i_idx_div = 15
                                                              SET @f_pre = 'p';
                                                              ELSE
                                                              IF @i_idx_div = 16
                                                              SET @f_pre = 'q';
                                                              ELSE
                                                              IF @i_idx_div = 17
                                                              SET @f_pre = 'r';
                                                              ELSE
                                                              IF @i_idx_div = 18
                                                              SET @f_pre = 's';
                                                              ELSE
                                                              IF @i_idx_div = 19
                                                              SET @f_pre = 't';
		    
                                                              ELSE
                                                              IF @i_idx_div = 20
                                                              SET @f_pre = 'u';
                                                              ELSE
                                                              IF @i_idx_div = 21
                                                              SET @f_pre = 'v';
                                                              ELSE
                                                              IF @i_idx_div = 22
                                                              SET @f_pre = 'w';
                                                              ELSE
                                                              IF @i_idx_div = 23
                                                              SET @f_pre = 'x';
                                                              ELSE
                                                              IF @i_idx_div = 24
                                                              SET @f_pre = 'y';
                                                              ELSE
                                                              IF @i_idx_div = 25
                                                              SET @f_pre = 'z';
		    
		    
        RETURN @f_pre +@s_pre;

 -- trace off;
    END;