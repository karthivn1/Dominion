﻿create FUNCTION [dbo].[dl_grp_alt_id_to_grp_id](
@t_group_alt_id INT)   
RETURNS int

BEGIN

DECLARE @i_group_id integer;

SET @i_group_id = null;

    SELECT @i_group_id = group_id
    FROM [group]
    WHERE alt_id = @t_group_alt_id

RETURN @i_group_id;

END;