﻿CREATE FUNCTION [dbo].[dl_get_param_value]
    (
      @a_batch_id INT ,
      @a_sp_id INT ,
      @a_sp_param_name VARCHAR(18)
    )
RETURNS VARCHAR(128)
AS
    BEGIN
/*
-- This function was converted on Fri Aug 19 04:59:59 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10

00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_descr VARCHAR(64);

        DECLARE @s_param_value VARCHAR(128);
        DECLARE @i_sp_param_id INT;
		DECLARE @s_param_value_1 VARCHAR(128);

        SET @i_sp_param_id = dbo.dl_get_param_id(@a_batch_id, @a_sp_id,
                                                 @a_sp_param_name);
	
        SELECT  @s_param_value = param_value
        FROM    dbo.dl_cfg_bat_param (NOLOCK)
        WHERE   config_bat_id = @a_batch_id
                AND sp_param_id = @i_sp_param_id;
				
				IF (ISNULL(@s_param_value,'')<>'')

					SET @s_param_value_1 = @s_param_value;

                              
        RETURN @s_param_value_1;

    END;