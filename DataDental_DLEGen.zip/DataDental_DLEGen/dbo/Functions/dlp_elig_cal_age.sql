﻿CREATE FUNCTION [dbo].[dlp_elig_cal_age]
    (
      @a_date_of_birth DATE ,
      @a_from_date DATE
    )
RETURNS INT
AS
    BEGIN
/*
-- This function was converted on Fri Aug 19 03:31:31 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10
00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_dob_month INT;
        DECLARE @i_month INT;
        DECLARE @i_age INT;

--	set debug file to "/tmp/age.trc";
--	trace on;

        IF @a_date_of_birth IS NULL
            OR @a_from_date IS NULL
            RETURN 0;
	

        SET @i_dob_month = MONTH(@a_date_of_birth);
        SET @i_month = MONTH(@a_from_date);
        SET @i_age = YEAR(@a_from_date) - YEAR(@a_date_of_birth);

        IF @i_dob_month > @i_month
            SET @i_age = @i_age - 1;
	

        IF @i_dob_month = @i_month
            IF DATEPART(DAY, @a_date_of_birth) > DATEPART(DAY, @a_from_date)
                SET @i_age = @i_age - 1;
		
	

        IF @i_age < 0
            SET @i_age = 0;
	
	
        RETURN @i_age;

--	trace off;

    END;