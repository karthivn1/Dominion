﻿CREATE FUNCTION [dbo].[dl_dlp_status]
    (
      @a_batch_id INT ,
      @a_sir_tab_id INT ,
      @a_sp_id INT ,
      @a_action_type CHAR(2)
    )
RETURNS INT
AS
    BEGIN

/*
-- This function was converted on Fri Aug 19 04:59:59 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 10


00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_tab_id INT;
        DECLARE @c_status CHAR(1);

        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);
        DECLARE @i_common_header_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @SWV_error INT;

--set debug file to "./dl_dlp_status.trc";
--trace on;

        SELECT  @i_common_header_id = common_h_id
        FROM    dbo.stc_common_header (NOLOCK)
        WHERE   tab_name = 'dl_sp';
 
                        IF NOT EXISTS ( SELECT  *
                                        FROM    dbo.stc_common_detail (NOLOCK)
                                        WHERE   common_header_id = @i_common_header_id
                                                AND code = @a_action_type )
                            RETURN -1;
	

-- Assumption: no duplicate stored procedures in a batch

                        IF @a_sp_id IS NULL
                            OR @a_sp_id < 0
                            RETURN -1;
	

	-- "S" for Success, "F" for Failure
                        SELECT  @c_status = cfg_bat_det_stat
                        FROM    dbo.dl_cfg_bat_det bs ( NOLOCK )
                        WHERE   bs.config_bat_id = @a_batch_id
                                AND bs.sir_def = @a_sir_tab_id
                                AND bs.sp_id = @a_sp_id;

                        
						
                                                    IF ( @c_status IS NULL
                                                         OR @c_status = ''
                                                       )
                                                        RETURN -1;
                                                    ELSE
                                                        IF @c_status != 'S'
                                                            RETURN -1;
															ELSE
                                                    RETURN 1;
						
              RETURN 0;
    END;