﻿CREATE PROCEDURE [dbo].[setserialid] @NewID INT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @serialid VARBINARY(8000);
        SET NOCOUNT ON;
        SET @serialid = CAST(0 AS VARBINARY(8000));
        EXECUTE SWPCrtGlVar 'serialid';
        EXECUTE SWPAddGlVar 'serialid', @serialid;
        SET @serialid = CAST(@NewID AS VARBINARY(8000));
        EXECUTE SWPAddGlVar 'serialid', @serialid;
        SET NOCOUNT OFF;
    END;