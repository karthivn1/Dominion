﻿CREATE PROCEDURE [dbo].[dlp_up_pend]
    @a_batch_id INT ,
    @a_mb_gr_pl_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(100) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:53:53 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1



000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @ls_user CHAR(15);

        DECLARE @n_count INT;
        DECLARE @n_mb_gr_pl_id INT;
        DECLARE @n_group_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_sub_in_plan INT;
        DECLARE @n_eff_gr_pl DATE;
        DECLARE @n_exp_gr_pl DATE;
        DECLARE @s_dls_mb_id INT;
        DECLARE @s_dls_sub_id INT;
        DECLARE @s_dls_group_id INT;
        DECLARE @s_dls_plan_id INT;
        DECLARE @s_dls_pend_action smallint;
        DECLARE @s_pend_date date;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par0 DATE;

        SET NOCOUNT ON;
        SET @s_dls_mb_id = 0;
        SET @s_dls_sub_id = 0;
        SET @s_dls_group_id = 0;
        SET @s_dls_plan_id = 0;
        SET @s_dls_pend_action = 0;
        SET @s_pend_date = NULL;
        SET @ls_user = CONCAT('dl', @a_batch_id);

		 select @s_dls_sub_id =VarValue from GlobalVar(NOLOCK) where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 3
		 select @s_dls_group_id =VarValue from GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
		 select @s_dls_plan_id =VarValue from GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3
		 select @s_dls_pend_action =VarValue from GlobalVar(NOLOCK) where VarName = 's_dls_pend_action' and  BatchId = @a_batch_id AND Module_Id = 3
		 select @s_pend_date =VarValue from GlobalVar(NOLOCK) where VarName = 's_pend_date' and  BatchId = @a_batch_id AND Module_Id = 3

        IF @a_mb_gr_pl_id IS NULL
            OR @a_mb_gr_pl_id = 0 -- we need to look up values
            BEGIN
              
                SET @SWV_func_DLP_MBGRPL_INFO_par0 = @s_pend_date
                EXECUTE dbo.dlp_mbgrpl_info @s_dls_group_id, @s_dls_plan_id,
                    @s_dls_sub_id, @SWV_func_DLP_MBGRPL_INFO_par0, 'N',
                    @n_count OUTPUT, @a_mb_gr_pl_id OUTPUT, @n_group_id OUTPUT,
                    @n_plan_id OUTPUT, @n_sub_in_plan OUTPUT,
                    @n_eff_gr_pl OUTPUT, @n_exp_gr_pl OUTPUT;
                IF @n_count > 1
                    BEGIN
                        SET @SWP_Ret_Value = 2;
                        SET @SWP_Ret_Value1 = 'Multiple sub-grp-plan records found';
                        RETURN;
                    END;
                ELSE
                    IF @n_count = 0
                        BEGIN
                            SET @SWP_Ret_Value = 0;
                            SET @SWP_Ret_Value1 = 'No record for sub-grp-plan found';
                            RETURN;
                        END;
            END;

        -- may be called multiple times only perform once
 -- may be called multiple times only perform once
        IF @s_dls_pend_action = 1
            BEGIN
                INSERT  INTO dbo.sgp_pend
         ( mb_gr_pl_id ,
                          eff_date ,
                          insert_datetime ,
                          inserted_by
                        )
                VALUES  ( @a_mb_gr_pl_id ,
                          CONVERT(DATE, CONVERT(VARCHAR, @s_pend_date)) ,
                          GETDATE() ,
                          @ls_user
                        );
	
                SET @s_dls_pend_action = 0;
                
            END;
        ELSE
            BEGIN
            
                IF @s_dls_pend_action = 2
                    BEGIN
                        UPDATE  dbo.sgp_pend
                        SET     cancel_datetime = GETDATE() ,
                                canceled_by = @ls_user
               WHERE   mb_gr_pl_id = @a_mb_gr_pl_id
                                AND cancel_datetime IS NULL;
                        SET @s_dls_pend_action = 0;
                        EXECUTE SWPAddGlVar 's_dls_pend_action',
                            @s_dls_pend_action;
                    END;
            END;
        SET @SWP_Ret_Value = 1;
        SET @SWP_Ret_Value1 = 'Pend updated';
        RETURN;
        SET NOCOUNT OFF;
    END;