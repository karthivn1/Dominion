﻿CREATE PROCEDURE [dbo].[dlp_bu_dep_elig_mb]
    @n_count INT ,
    @n_error_no_input INT ,
    @as_action_code_input CHAR(2) ,
    @n_member_id INT ,
    @t_src_id CHAR(20) ,
    @a_batch_id INT ,
    @t_sir_id INT ,
    @t_plan_eff_date DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(2) = NULL OUTPUT
    
 	--as_action_code

/*
This method is called by dlp_bu_eligibility() and dlp_bu_dep_elig().

Sample usage:

let n_error_no, as_action_code = dlp_bu_dep_elig_mb(n_count, n_error_no, as_action_code, n_member_id, t_src_id, a_batch_id, t_sir_id, t_plan_eff_date);
*/

		--n_error_no
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:21:21 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @as_action_code CHAR(2);

        SET NOCOUNT ON;
        SET @n_error_no = @n_error_no_input;
        SET @as_action_code = @as_action_code_input;


	
	--When n_mb_count is 2 it means there was a match using fuzzy logic.
	--Therefore, some component of this member's information has changed
	--and needs to be updated into the database.
	
	

	--Check if the source ID has changed.  If it has,
	--set the action code to "MU" for member update.
	--
	--Note that member.source_id can never be null (but it can be 20 spaces).
	--It is char(20).
	
        IF ( @n_count = 2 )
            BEGIN
                EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id, @t_sir_id,
                    'MU', @t_plan_eff_date;
                SET @as_action_code = 'MU';
            END;
        ELSE
            IF ( @n_count = 1 )
                BEGIN
				IF ( (@t_src_id IS NULL
                       -- OR @t_src_id = ''
						)
                       )
                        SET @t_src_id = ''; --  20131026$$ks - make empty string instead of space(20)
	
                    BEGIN
                        DECLARE @the_count INT;

                        SET @the_count = 0;
                        SELECT  @the_count = COUNT(*)
                        FROM    dbo.member (NOLOCK)
                        WHERE   member_id = @n_member_id
                                AND source_id != @t_src_id;
                        IF ( @the_count > 0 )
                            BEGIN
                                EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                    @t_sir_id, 'MU', @t_plan_eff_date;
                                SET @as_action_code = 'MU';
                            END;
		
                    END;
                END;
            ELSE
                RAISERROR('IllegalArgumentException:  dlp_bu_dep_elig_mb():  n_count was not 1 nor 2.',16,1);


        SET @SWP_Ret_Value = @n_error_no;
        SET @SWP_Ret_Value1 = @as_action_code;
        RETURN;
        SET NOCOUNT OFF;

    END;