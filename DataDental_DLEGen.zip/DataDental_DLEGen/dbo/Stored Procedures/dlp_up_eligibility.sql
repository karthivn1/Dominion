﻿CREATE PROCEDURE [dbo].[dlp_up_eligibility]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:46:46 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @do_trace BIT;

        DECLARE @t_temp_action_code CHAR(2);

        DECLARE @li_1000_count INT;
        DECLARE @li_tt_prcs_cnt INT;
        DECLARE @li_family_nbr INT;
        DECLARE @li_prcs_gd_cnt INT;
        DECLARE @li_prcs_bad_cnt INT;
        DECLARE @li_dep_sir_id INT;
        DECLARE @ls_rate_code CHAR(2);
        DECLARE @s_next_family CHAR(1);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @n_error_text CHAR(64);
		DECLARE @error_no int
        DECLARE @n_isam_error INT;
        DECLARE @n_error_no INT;
        DECLARE @n_fatal INT;
--define i_sp_id						integer;

        DECLARE @i_pre_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @t_del_sir INT;
        DECLARE @tot_msi INT;

DECLARE @t_sub_sir_id  integer;
DECLARE @t_action_date date;

DECLARE @n_msi    integer;
DECLARE @msi_num  integer;
DECLARE @msi_num1 integer;
DECLARE @msi_num2 integer;
DECLARE @msi_num3 integer;
DECLARE @msi_upper integer;

DECLARE @n_add_to_cl_fc	char(1);
DECLARE @n_new_mb_w_fc_id char(1);
DECLARE @n_report_only char(1);

DECLARE @t_sir_id        integer;
DECLARE @t_tl_sir_id     integer;
DECLARE @t_tl_sub_sir_id integer;
DECLARE @t_subscriber    char(2);
DECLARE @t_alt_id        char(20);
DECLARE @t_sub_ssn       char(11);
DECLARE @t_ssn           char(11);
DECLARE @t_sub_alt_id    char(20);
DECLARE @t_sub_in_plan	smallint;	--Subscriber in plan.
DECLARE @t_member_id     integer;
DECLARE @t_sub_id        integer;
DECLARE @t_group_id      integer;
DECLARE @t_member_code   char(2);
DECLARE @t_plan_id       integer;
DECLARE @t_facility_id   integer;
DECLARE @t_def_key char(2);
DECLARE @t_type          char(2);
DECLARE @t_last_name     char(15);
DECLARE @t_first_name    char(15);
DECLARE @t_middle_init   char(1);
DECLARE @t_date_of_birth date;
DECLARE @t_plan_eff_date date;
DECLARE @t_fac_eff_date  date;
DECLARE @t_plan_term_date date;
DECLARE @t_student_flag  char(1);
DECLARE @t_disable_flag  char(1);
DECLARE @t_cobra_flag    char(1);
DECLARE @t_action_code char(2);
DECLARE @t_rate_code  char(2);
DECLARE @t_address1   char(30);
DECLARE @t_address2   char(30);
DECLARE @t_city       char(30);
DECLARE @t_state      char(2);
DECLARE @t_zip        char(5);
DECLARE @t_zipx       char(4);
DECLARE @t_home_phone char(10);
DECLARE @t_home_ext   char(4);
DECLARE @t_work_phone char(10);
DECLARE @t_work_ext   char(4);
DECLARE @t_status     char(1);
DECLARE @n_datetime   datetime2(2);
DECLARE @t_new_ssn    char(11);
DECLARE @t_subnew_ssn char(11);
DECLARE @t_src_id  char(20);
DECLARE @t_subsrc_id  char(20);
DECLARE @t_ext_id_col char(20);
DECLARE @t_def_ext_id_type integer;
DECLARE @t_def_ext_id_col char(20);
DECLARE @t_email varchar(250)
DECLARE @t_paperless CHAR(1)

        DECLARE @true VARCHAR(5);
        DECLARE @false VARCHAR(5);
        
        DECLARE @i_sp_id INT;
        DECLARE @SWV_dl_get_sp_id INT;
        --DECLARE @cSubSir CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;
        DECLARE @v_Null INT;
		DECLARE @process_cnt INT;
		DECLARE @n_succ_count INT

        SET NOCOUNT ON;
		 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 4 AND BatchId = @a_batch_id )
		 BEGIN
	
				INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id])
				SELECT N'msi_upper',							N'', @a_batch_id, 4
				UNION ALL SELECT N'n_datetime',					N'', @a_batch_id, 4
				UNION ALL SELECT N'n_msi',						N'', @a_batch_id, 4
				UNION ALL SELECT N't_action_code',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_action_date',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_address1',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_address2',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_alt_id',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_city',						N'', @a_batch_id, 4
				UNION ALL SELECT N't_cobra_flag',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_date_of_birth',			N'', @a_batch_id, 4
				UNION ALL SELECT N't_def_ext_id_col',			N'', @a_batch_id, 4
				UNION ALL SELECT N't_def_ext_id_type',			N'', @a_batch_id, 4
				UNION ALL SELECT N't_def_key',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_disable_flag',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_email',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_ext_id_col',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_fac_eff_date',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_facility_id',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_first_name',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_group_id',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_home_ext',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_home_phone',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_last_name',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_member_code',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_member_id',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_middle_init',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_new_ssn',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_plan_eff_date',			N'', @a_batch_id, 4
				UNION ALL SELECT N't_plan_id',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_plan_term_date',			N'', @a_batch_id, 4
				UNION ALL SELECT N't_rate_code',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_src_id',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_ssn',						N'', @a_batch_id, 4
				UNION ALL SELECT N't_state',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_status',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_student_flag',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_sub_alt_id',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_sub_id',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_sub_in_plan',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_sub_ssn',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_subnew_ssn',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_subscriber',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_subsrc_id',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_tl_sir_id',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_tl_sub_sir_id',			N'', @a_batch_id, 4
				UNION ALL SELECT N't_type',						N'', @a_batch_id, 4
				UNION ALL SELECT N't_work_ext',					N'', @a_batch_id, 4
				UNION ALL SELECT N't_work_phone',				N'', @a_batch_id, 4
				UNION ALL SELECT N't_zip',						N'', @a_batch_id, 4
				UNION ALL SELECT N't_zipx',						N'', @a_batch_id, 4
				UNION ALL SELECT N't_paperless',				N'', @a_batch_id, 4

										
		END
        SET @true = 't';
        
        SET @false = 'f';
     
        SET @t_sub_sir_id = 0;
        
        --SET @t_action_date =NULL;
  
        SET @n_msi =0;
 
        SET @msi_num =0;
        
        SET @msi_num1 =0;
       
 --SET @msi_num2 =0;
 
       -- SET @msi_num3 =0;
        
        SET @msi_upper =0;
        
        SET @n_add_to_cl_fc ='';
       
        SET @n_new_mb_w_fc_id ='';
        
        SET @n_report_only ='';
        
        SET @t_sir_id =0;
       
        SET @t_tl_sir_id =0;
       
        SET @t_tl_sub_sir_id =0;
       
        SET @t_subscriber ='';
       
        SET @t_alt_id ='';
       
        SET @t_sub_ssn ='';
       
        SET @t_ssn ='';
       
        SET @t_sub_alt_id ='';
        
        SET @t_sub_in_plan =NULL;
        
        SET @t_member_id =0;
       
     SET @t_sub_id =0;
        
        SET @t_group_id =0;
        
        SET @t_member_code ='';
        
        SET @t_plan_id =0;
       
        SET @t_facility_id =0;
        
        SET @t_def_key ='';
        
        SET @t_type ='';
       
        SET @t_last_name ='';
       
        SET @t_first_name ='';
       
        SET @t_middle_init ='';
       
        SET @t_date_of_birth =NULL;
       
        SET @t_plan_eff_date =NULL;
       
        SET @t_fac_eff_date =NULL;
        
        SET @t_plan_term_date =NULL;
        
        SET @t_student_flag ='';
      
        SET @t_disable_flag ='';
        
        SET @t_cobra_flag ='';
        
        SET @t_action_code ='';
        
        SET @t_rate_code ='';
        
        SET @t_address1 ='';
       
        SET @t_address2 ='';
        
        SET @t_city ='';
        
        SET @t_state ='';
   
        SET @t_zip ='';
       
        SET @t_zipx ='';
       
        SET @t_home_phone ='';
        
        SET @t_home_ext ='';
        
        SET @t_work_phone ='';
       
        SET @t_work_ext ='';
        
        SET @t_status ='';
    
        SET @n_datetime =NULL;
      
        SET @t_new_ssn ='';
       
        SET @t_subnew_ssn ='';
       
        SET @t_src_id ='';
        
        SET @t_subsrc_id ='';
        
        SET @t_ext_id_col ='';
        
        SET @t_def_ext_id_type = 1;

		--SET @process_cnt = 0;

         UPDATE GlobalVar SET VarValue = @t_def_ext_id_type  where VarName = 't_def_ext_id_type' and  BatchId = @a_batch_id AND Module_Id = 4

        SET @t_def_ext_id_col ='';
        
        SET @i_sp_id =0;

		IF  EXISTS (SELECT 'X' FROM dbo.dls_elig (NOLOCK)--Fix
								  WHERE dls_batch_id = @a_batch_id --AND dls_source='A'
					)
		BEGIN
			SELECT @process_cnt = COUNT(*) FROM dbo.dls_elig (NOLOCK)--Fix
								  WHERE dls_batch_id = @a_batch_id AND dls_status='P'

		END
        
        IF EXISTS ( SELECT  *
                    FROM    tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#hold_dls_action')
                            AND xtype = 'U' )
            DROP TABLE #hold_dls_action;
        CREATE TABLE #hold_dls_action
            (
              action_code_id INT IDENTITY ,
              batch_id INT ,
              dls_sir_id INT ,
              action_code CHAR(2) ,
              action_date DATE ,
              process_status CHAR(1)
            ); 
			
			CREATE NONCLUSTERED INDEX NIX_hold_dls_action ON #hold_dls_action ([dls_sir_id])

        BEGIN TRY
            
            SET @do_trace = 1;
            IF ( @do_trace = 1 )
                BEGIN--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/dlp_up_eligibility_" || a_batch_id || ".trc";

	--TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;

            BEGIN
                DECLARE @currentDateAndTime DATETIME;
                DECLARE @userSessionId INT;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "dlp_up_eligibility():  Entered.";
                        SET @v_Null = 0;
                    END;
	
                SET @currentDateAndTime = GETDATE();
        SET @userSessionId = @@spid;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "a_batch_id = " || a_batch_id;

		--TRACE statement has no equivalent in MSSQL
--trace "a_start_time = " || a_start_time;
                        SET @v_Null = 0;
 END;
	
END;
             
            
            EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, 'up_eligibility'
        
     SET @i_sp_id = @SWV_dl_get_sp_id ;
           
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
				BEGIN
				SET @error_no = 0
    RAISERROR('Invalid SP name',16,1);
				END

  EXECUTE @i_pre_sp_id = dbo.dl_get_sp_id @a_batch_id,
                'bu_eligibility';
            IF @i_pre_sp_id IS NULL
                OR @i_pre_sp_id <= 0
				BEGIN
				SET @error_no = 0
                RAISERROR('Invalid Preprocess Procedure Name',16,1);
				END

            SET @i_sir_def_id = dbo.dl_get_sir_def_id('elig');
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
				BEGIN
				SET @error_no = 0
                RAISERROR('Invalid DSIR table name',16,1);
				END

            SET @n_add_to_cl_fc = dbo.dl_get_param_value(@a_batch_id,
                                                              @i_pre_sp_id,
                                                              'Add Closed FC');
           
            SET @n_report_only = dbo.dl_get_param_value(@a_batch_id,
                                                             @i_sp_id,
                                                             'Report Only');
            
            SET @n_new_mb_w_fc_id = dbo.dl_get_param_value(@a_batch_id,
                                                              @i_pre_sp_id,
                                                              'New Member w/ FC') ;
            
            IF ( @n_report_only IS NULL
                 OR @n_report_only = ''
               )
                OR LEN(@n_report_only) <= 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT('Batch ', @a_batch_id,
                                                 ' is only for report purpose');
                    RETURN;
                END;
            ELSE
                BEGIN
                    
                    IF @n_report_only NOT IN ( 'Y', 'N' )
                        BEGIN
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = CONCAT('Batch ', @a_batch_id,
                                                         ' is not for update');
                            RETURN;
                        END;
                    ELSE
                        BEGIN
                            
                            IF @n_report_only = 'Y'
                                BEGIN
                                    SET @SWP_Ret_Value = -1;
                                    SET @SWP_Ret_Value1 = CONCAT('Batch ',
                                                              @a_batch_id,
                                                              ' is only for reporting.');
                                    RETURN;
                                END;
                        END;
                END;

            
            EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
                @n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @n_error_text OUTPUT;
            IF @n_error_no <= 0
                BEGIN
                    SET @n_error_text = CAST(-746 AS VARCHAR) + ':'
                      + @n_error_text;
                    RAISERROR(@n_error_text,16,1);
                END;

            SET @n_in_transaction = 'N';
            SET @li_1000_count = 0;
    SET @li_tt_prcs_cnt = 0;
	
      SET @li_prcs_gd_cnt = 0;
            SET @li_prcs_bad_cnt = 0;
            BEGIN
                BEGIN TRY
                    DELETE  FROM #hold_dls_action;
                END TRY
                BEGIN CATCH
                    SET @n_error_no = ERROR_NUMBER();
                    SET @n_isam_error = ERROR_LINE();
                    SET @n_error_text = ERROR_MESSAGE();
			DELETE  FROM #hold_dls_action;
          DROP TABLE #hold_dls_action;
                END CATCH;
            END;
			
            DECLARE @cSubSir TABLE
                (
     id INT IDENTITY ,
                  dls_sub_sir_id INT
    );
					
            INSERT  INTO @cSubSir
         ( dls_sub_sir_id
                    )
                    SELECT  dls_sub_sir_id
                    FROM    dbo.dls_elig (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'P'
                            AND member_flag = '00';

            DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

			--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @cSubSir;
            		
            /*
			SET @cSubSir = CURSOR  FOR SELECT dls_sub_sir_id  FROM dbo.dls_elig (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'P'
      AND member_flag = '00';
            OPEN @cSubSir;
            FETCH NEXT FROM @cSubSir INTO @t_sub_sir_id;
            WHILE @@FETCH_STATUS = 0
			*/
			--while @@FETCH_STATUS = 0

            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
                    BEGIN

                        SELECT  @t_sub_sir_id = dls_sub_sir_id
                        FROM    @cSubSir
                        WHERE   id = @cur_i;

                        --DECLARE #SWV_cursor_var1 CURSOR;
                       -- DECLARE #SWV_cursor_var2 CURSOR;
                        --DECLARE #SWV_cursor_var3 CURSOR;
                        --DECLARE #cDate CURSOR;
                       -- DECLARE #SWV_cursor_var4 CURSOR;
                        --DECLARE #SWV_cursor_var5 CURSOR;
                        
                        BEGIN TRY

						IF OBJECT_ID('tempdb..#SWV_cursor_var1') IS NOT NULL
						DROP TABLE #SWV_cursor_var1

						 CREATE TABLE #SWV_cursor_var1 
                            (
                              id INT IDENTITY ,
                              dls_sir_id INT
                            );

                            INSERT  INTO #SWV_cursor_var1 (dls_sir_id)
                                    SELECT  dls_sir_id
                        FROM    dbo.dls_elig (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sub_sir_id = @t_sub_sir_id;

			   /*SET #SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id  FROM dbo.dls_elig (NOLOCK)
               WHERE dls_batch_id = @a_batch_id
               AND dls_sub_sir_id = @t_sub_sir_id;
                            OPEN #SWV_cursor_var1;
                            FETCH NEXT FROM #SWV_cursor_var1 INTO @t_del_sir;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @cur2_cnt INT ,
     @cur2_i INT;

                            SET @cur2_i = 1;

			--Get the no. of records for the cursor
                            SELECT  @cur2_cnt = COUNT(1)
                            FROM    #SWV_cursor_var1;
            
			--while @@FETCH_STATUS = 0
                            WHILE ( @cur2_i <= @cur2_cnt )
                                BEGIN

                                    SELECT  @t_del_sir = dls_sir_id
                                    FROM    #SWV_cursor_var1
                                    WHERE   id = @cur2_i;

                                    EXECUTE dbo.dl_clean_curr_err @a_batch_id,
  @t_del_sir, @i_sp_id,
                                        @n_error_no OUTPUT,
                                        @n_error_text OUTPUT;
                                    --FETCH NEXT FROM #SWV_cursor_var1 INTO @t_del_sir;
                                    SET @cur2_i = @cur2_i + 1;
                   END;
                            --CLOSE #SWV_cursor_var1;

SET @s_next_family = 'N';
                           
                            IF ( @t_sub_sir_id IS NULL )
                                BEGIN
								SET @error_no = 500
                                    RAISERROR('No record found (sub_sir_id) for batch',16,1);
                  SET @SWP_Ret_Value = @n_error_no;
                           SET @SWP_Ret_Value1 = @n_error_text;
                                    RETURN;
                                END;
	
                            DELETE  FROM #hold_dls_action
                            WHERE   1 = 1;
                            SET IDENTITY_INSERT #hold_dls_action ON;
                            INSERT  INTO #hold_dls_action (action_code_id,batch_id ,dls_sir_id ,action_code ,action_date ,process_status)
                                    SELECT  action_code_id,batch_id,dls_sir_id,action_code,action_date,process_status
                                    FROM    dbo.dl_action (NOLOCK)
                                    WHERE   batch_id = @a_batch_id
                                            AND process_status = 'N'
                                            AND dls_sir_id IN (
                                            SELECT  dls_sir_id
                                            FROM    dbo.dls_elig (NOLOCK)
                                            WHERE   dls_batch_id = @a_batch_id
                                                    AND dls_sub_sir_id = @t_sub_sir_id );
                            SET IDENTITY_INSERT #hold_dls_action OFF;
/* 20130214$$ks - we need to rethink the way these msi numbers are counted 
	we use up more numbers than needed */

                            SELECT  @msi_num = COUNT(*)
                            FROM    #hold_dls_action
                            WHERE   NOT ( action_code LIKE 'G[1-7]' ESCAPE '\'
                                          OR action_code = 'GX'
                                          OR action_code = 'PC'
                                        )
                                    AND process_status != 'Y';
                
                            SELECT  @msi_num1 = COUNT(*)
                            FROM    #hold_dls_action
                            WHERE   action_code IN ( 'RC', 'FX' )
                                    AND process_status != 'Y';
                            
                            IF @msi_num1 IS NULL
                                BEGIN
                                    SET @msi_num1 =0;
                                    
                                END;
	
                            SET @msi_num2 =0;
                            
							IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
							DROP TABLE #SWV_cursor_var2

							CREATE TABLE #SWV_cursor_var2 
                            (
                              id INT IDENTITY ,
                              action_code CHAR(2)
                            );

                            INSERT  INTO #SWV_cursor_var2
                                    ( action_code
                                    )
                       SELECT  COUNT(DISTINCT action_code)
                                    FROM    #hold_dls_action
                                    WHERE   action_code = 'GX'
                                            AND process_status != 'Y';
                            /*
							SET #SWV_cursor_var2 = CURSOR FOR SELECT COUNT(DISTINCT action_code)  FROM #hold_dls_action
             WHERE action_code = 'GX' AND process_status != 'Y';
                        OPEN #SWV_cursor_var2;
                FETCH NEXT FROM #SWV_cursor_var2 INTO @msi_num2;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @cur3_cnt INT ,
     @cur3_i INT;

                  SET @cur3_i = 1;

			--Get the no. of records for the cursor
                            SELECT  @cur3_cnt = COUNT(1)
                            FROM    #SWV_cursor_var2;
            
			--while @@FETCH_STATUS = 0
                            WHILE ( @cur3_i <= @cur3_cnt )
                                BEGIN
                                    SELECT  @msi_num2 = action_code
                              FROM    #SWV_cursor_var2
                                    WHERE   id = @cur3_i;

                                    GOTO SWL_Label8;
                                    --FETCH NEXT FROM #SWV_cursor_var2 INTO @msi_num2;
                                    SET @cur3_i = @cur3_i + 1;
                                END;
                            SWL_Label8:

                            --CLOSE #SWV_cursor_var2;
                            /*SET #SWV_cursor_var3 = CURSOR  FOR SELECT COUNT(DISTINCT action_code)  FROM #hold_dls_action
               WHERE action_code = 'PC' AND process_status != 'Y';
                            OPEN #SWV_cursor_var3;
                            FETCH NEXT FROM #SWV_cursor_var3 INTO @msi_num3;
                            WHILE @@FETCH_STATUS = 0*/

							IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
							DROP TABLE #SWV_cursor_var3

							  CREATE TABLE #SWV_cursor_var3 
                            (
                              id INT IDENTITY ,
                              action_code CHAR(2)
                            );
                            INSERT  INTO #SWV_cursor_var3
                                    ( action_code
                                    )
                                    SELECT  COUNT(DISTINCT action_code)
                                    FROM    #hold_dls_action
                                    WHERE   action_code = 'PC'
                                            AND process_status != 'Y';

                            DECLARE @cur4_cnt INT ,
                                @cur4_i INT;

                            SET @cur4_i = 1;

			--Get the no. of records for the cursor
                            SELECT  @cur4_cnt = COUNT(1)
                            FROM    #SWV_cursor_var3;
            
			--while @@FETCH_STATUS = 0
                            WHILE ( @cur4_i <= @cur4_cnt )
                                BEGIN
                                    SELECT  @msi_num3 = action_code
    FROM    #SWV_cursor_var3
                                    WHERE   id = @cur4_i; 
                                    GOTO SWL_Label9;
                                   -- FETCH NEXT FROM #SWV_cursor_var3 INTO @msi_num3;
                                    SET @cur4_i = @cur4_i + 1;
                                END;
                            SWL_Label9:
                            -- CLOSE #SWV_cursor_var3;
                           
                            IF @msi_num3 IS NULL
                                BEGIN
                                    SET @msi_num3 =0;
                                   
                                END;
                            ELSE
                                BEGIN
                                   
                                    IF @msi_num3 > 0
                                        BEGIN
                                          
                                            SET @msi_num3 = @msi_num3 + 1;
         
                                        END;
                                END;
	
                            
					IF @msi_num2 IS NULL
                            BEGIN
                      SET @msi_num2 =0;
                                  
				 END;
	
                     SELECT  @li_family_nbr = COUNT(DISTINCT dls_sir_id)
                            FROM    #hold_dls_action;
 
                            
 SET @tot_msi = @msi_num + @msi_num1
                                + @msi_num2 
                                + @msi_num3 

                            UPDATE  dbo.sysdatetime
                            SET     msi = msi + @tot_msi;

                            SELECT  @msi_upper = msi ,
                                    @n_datetime = datetime_id 
                            FROM    dbo.sysdatetime;

							UPDATE GlobalVar SET VarValue = @msi_upper  where VarName = 'msi_upper' and  BatchId = @a_batch_id AND Module_Id = 4
                            UPDATE GlobalVar SET VarValue = @n_datetime  where VarName = 'n_datetime' and  BatchId = @a_batch_id AND Module_Id = 4

                            SET @n_msi = @msi_upper - @tot_msi ;

                            UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                             
                            SELECT  @t_def_ext_id_type = int_1 ,
                                    @t_def_ext_id_col = str_1
                            FROM    dbo.typ_table_exp t ( NOLOCK ) ,
                                    dbo.dds_default m ( NOLOCK )
                            WHERE   m.ext_id_type = t.int_1
                                    AND t.subsys_code = 'MB'
                                    AND t.tab_name = 'ext_id_type'; 
                            
							UPDATE GlobalVar SET VarValue = @t_def_ext_id_type  where VarName = 't_def_ext_id_type' and  BatchId = @a_batch_id AND Module_Id = 4

							UPDATE GlobalVar SET VarValue = @t_def_ext_id_col  where VarName = 't_def_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 4

							IF OBJECT_ID('tempdb..#cDate') IS NOT NULL
							DROP TABLE #cDate

							CREATE TABLE #cDate 
                            (
                              id INT IDENTITY ,
                              action_date DATE
                            );	

                            INSERT  INTO #cDate
                                    ( action_date
                                    )
                                    SELECT DISTINCT
                                            action_date
                                    FROM    #hold_dls_action;

                           /* SET #cDate = CURSOR  FOR SELECT DISTINCT action_date 
               FROM #hold_dls_action
               ORDER BY action_date;
                            OPEN #cDate;
                            FETCH NEXT FROM #cDate INTO @t_action_date;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @cur5_cnt INT ,
                                @cur5_i INT;

                            SET @cur5_i = 1;

			--Get the no. of records for the cursor
                            SELECT  @cur5_cnt = COUNT(1)
                            FROM    #cDate;
            
			--while @@FETCH_STATUS = 0
                            WHILE ( @cur5_i <= @cur5_cnt )
                                BEGIN
                                    SELECT  @t_action_date = action_date
                                    FROM    #cDate
                                    WHERE   id = @cur5_i;

									UPDATE GlobalVar SET VarValue = @t_action_date  where VarName = 't_action_date' and  BatchId = @a_batch_id AND Module_Id = 4

                                    IF (@t_action_date) IS NULL 
                                        BEGIN
										SET @error_no = 501
                                            RAISERROR('No action found for subscriber',16,1);
                                            SET @SWP_Ret_Value = @n_error_no;
                                            SET @SWP_Ret_Value1 = @n_error_text;
             RETURN;
 END;
		
                
                                    SET @n_in_transaction = 'Y';

									IF OBJECT_ID('tempdb..#SWV_cursor_var4') IS NOT NULL
									DROP TABLE #SWV_cursor_var4

									CREATE TABLE #SWV_cursor_var4 
                (
                              id INT IDENTITY ,
                              dls_sir_id INT ,
                   action_code CHAR(2)
                            );

               INSERT  INTO #SWV_cursor_var4
            ( dls_sir_id ,
                                 action_code
                                            )
                                            SELECT  dls_sir_id ,
                 action_code
                                          FROM    #hold_dls_action
                                            WHERE   action_date = @t_action_date
                                            ORDER BY dls_sir_id;

		/* process each member for given action */
                                    /*SET #SWV_cursor_var4 = CURSOR  FOR SELECT dls_sir_id, action_code 
                  FROM #hold_dls_action
                  WHERE action_date = CONVERT(DATE,CONVERT(VARCHAR,@t_action_date))
                  ORDER BY dls_sir_id;
                                    OPEN #SWV_cursor_var4;
                                    FETCH NEXT FROM #SWV_cursor_var4 INTO @t_sir_id,
                                        @t_temp_action_code;
                                    WHILE @@FETCH_STATUS = 0 */

                                    DECLARE @cur6_cnt INT ,
                                        @cur6_i INT;

                                    SET @cur6_i = 1;

			--Get the no. of records for the cursor
                                    SELECT  @cur6_cnt = COUNT(1)
                                    FROM    #SWV_cursor_var4;
            
			--while @@FETCH_STATUS = 0
                                    WHILE ( @cur6_i <= @cur6_cnt )
                                        BEGIN 
                                            SELECT  @t_sir_id = dls_sir_id ,
                                                    @t_temp_action_code = action_code
                                            FROM    #SWV_cursor_var4
                                            WHERE   id = @cur6_i;

                                            IF @t_temp_action_code != 'GI'
                                                BEGIN
                        -- CH001 : Conversion issue
                                                    SELECT  @t_tl_sir_id = dls_sir_id,
                                                            @t_tl_sub_sir_id = dls_sub_sir_id,
                                                            @t_subscriber = member_flag,
                                                            @t_alt_id = alt_id ,
                                                            @t_ssn = ssn,
                                                            @t_sub_ssn = sub_ssn ,
                                                            @t_sub_alt_id = sub_alt_id ,
                                                            @t_sub_in_plan = sub_in_plan ,
                                                            @t_member_id = dls_member_id ,
                                                            @t_sub_id = dls_sub_id ,
                                                            @t_group_id = dls_group_id ,
                                                            @t_member_code = member_code ,
                                                            @t_plan_id = dls_plan_id ,
                                                            @t_facility_id = facility_id ,
                                                            @t_type = [type] ,
                                                            @t_def_key = def_key ,
                                                           @t_last_name = last_name ,
                                                            @t_first_name = first_name ,
													  @t_middle_init = middle_init ,
											@t_date_of_birth = date_of_birth ,
															 @t_student_flag = student_flag ,
															@t_disable_flag = disable_flag ,
															  @t_cobra_flag = cobra_flag ,
                                                            @t_action_code = dls_action_code ,
                                                            @t_rate_code = rate_code ,
                                                            @t_plan_eff_date = plan_eff_date ,
													@t_plan_term_date = plan_term_date ,
                                                     @t_fac_eff_date = facility_eff_date ,
                                                            @t_status = dls_status ,
															@t_address1 = address1 ,
                                                            @t_address2 = address2 ,
                                                            @t_city = city ,
                                                            @t_state = [state] ,
                                                            @t_zip = zip ,
                                                            @t_zipx = zipx ,
                                                            @t_home_phone = home_phone ,
                                                            @t_home_ext = home_ext ,
                                                            @t_work_phone = work_phone ,
                                                            @t_work_ext = work_ext ,
                                                            @t_new_ssn = new_ssn ,
                                                            @t_subnew_ssn = subnew_ssn ,
                                                            @t_src_id = source_id ,
                                                            @t_subsrc_id = subsource_id ,
                                                            @t_ext_id_col = ext_id_col,
															@t_email = email,
															@t_paperless=paperless
                                                    FROM    dbo.dls_elig (NOLOCK)
                                                    WHERE   dls_batch_id = @a_batch_id
                                                            AND dls_sir_id = @t_sir_id;
                                                   
                                                    UPDATE GlobalVar SET VarValue = @t_tl_sir_id  where VarName = 't_tl_sir_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_tl_sub_sir_id  where VarName = 't_tl_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_subscriber  where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_alt_id  where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_ssn  where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_sub_ssn  where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_sub_alt_id  where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_sub_in_plan  where VarName = 't_sub_in_plan' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_member_id  where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_sub_id  where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_group_id  where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_member_code  where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_plan_id  where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_facility_id  where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_type  where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_def_key  where VarName = 't_def_key' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_last_name  where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_first_name  where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_middle_init  where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_date_of_birth  where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_student_flag  where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_disable_flag  where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_cobra_flag  where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_action_code  where VarName = 't_action_code' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_rate_code  where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_plan_eff_date  where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_plan_term_date  where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_fac_eff_date  where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_status  where VarName = 't_status' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_address1  where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_address2  where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_city  where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_state  where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_zip  where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_zipx  where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_home_phone  where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_home_ext  where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_work_phone  where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_work_ext  where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_new_ssn  where VarName = 't_new_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_subnew_ssn  where VarName = 't_subnew_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_src_id  where VarName = 't_src_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_subsrc_id  where VarName = 't_subsrc_id' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_ext_id_col  where VarName = 't_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_email  where VarName = 't_email' and  BatchId = @a_batch_id AND Module_Id = 4
													UPDATE GlobalVar SET VarValue = @t_paperless where VarName = 't_paperless' and BatchId = @a_batch_id AND Module_Id = 4

                                                    IF ( @t_sub_in_plan IS NOT NULL )
BEGIN
                         
                                                            IF ( @t_sub_in_plan < 0
                                                              OR @t_sub_in_plan > 1
                                                              )
                                                              BEGIN
                                                              SET @t_sub_in_plan = 1;
                                                            UPDATE GlobalVar SET VarValue = @t_sub_in_plan  where VarName = 't_sub_in_plan' and  BatchId = @a_batch_id AND Module_Id = 4
          END;	--The default is one.
         END;
     ELSE
                                 BEGIN
                                        SET @t_sub_in_plan = 1 ;
                                                           UPDATE GlobalVar SET VarValue = @t_sub_in_plan  where VarName = 't_sub_in_plan' and  BatchId = @a_batch_id AND Module_Id = 4
                                                        END;
				
                                                    SET @t_action_code = @t_temp_action_code;
													UPDATE GlobalVar SET VarValue = @t_action_code  where VarName = 't_action_code' and  BatchId = @a_batch_id AND Module_Id = 4

                                                    IF @t_action_code = 'RC'
				/* 20130214$$ks - RC == Rate Change 
				 * this errors if there are no dependents - may be unnecessary
				 */
                                                        BEGIN
                                                            SET @li_dep_sir_id = NULL;

															IF OBJECT_ID('tempdb..#SWV_cursor_var5') IS NOT NULL
																DROP TABLE #SWV_cursor_var5

															CREATE TABLE #SWV_cursor_var5
																(
																  id INT IDENTITY ,
																  dls_sir_id INT
																);	

																INSERT INTO #SWV_cursor_var5
                                                              (
                                                              dls_sir_id
                                                              )
                                                              SELECT
                                                              dls_sir_id
                                                              FROM
                                                              #hold_dls_action
                                                              WHERE
                                                              dls_sir_id <> @t_tl_sir_id
                                                              AND action_date = @t_action_date;
                                                            
															/*SET #SWV_cursor_var5 = CURSOR  FOR SELECT dls_sir_id  FROM #hold_dls_action
                           WHERE dls_sir_id <> @t_tl_sir_id AND action_date = CONVERT(DATE,CONVERT(VARCHAR,@t_action_date));
                                                            OPEN #SWV_cursor_var5;
                                                            FETCH NEXT FROM #SWV_cursor_var5 INTO @li_dep_sir_id;
                                                            WHILE @@FETCH_STATUS = 0
															*/
                                                            DECLARE @cur7_cnt INT ,
                                                              @cur7_i INT;

                                                            SET @cur7_i = 1;

			--Get the no. of records for the cursor
                                                            SELECT
                                                              @cur7_cnt = COUNT(1)
                                                            FROM
                                                              #SWV_cursor_var5;
            
			--while @@FETCH_STATUS = 0
                                    WHILE ( @cur7_i <= @cur7_cnt )
           BEGIN
                                                              SELECT
                                                              @li_dep_sir_id = dls_sir_id
                                                              FROM
                                                              #SWV_cursor_var5
                                                              WHERE
                                          id = @cur7_i;

                                     GOTO SWL_Label12;
                                  --FETCH NEXT FROM #SWV_cursor_var5 INTO @li_dep_sir_id;
                      SET @cur7_i = @cur7_i
 + 1;
                                                              END;
                                                            SWL_Label12:
                                                            --CLOSE #SWV_cursor_var5;
                                                            IF @li_dep_sir_id IS NULL
															BEGIN
															SET @error_no = 552
                                                              RAISERROR('Null dependant sir_id, action RC ',16,1);
															  END
					
					/*  Get subs rate code */
                                                            SET @ls_rate_code = NULL;
                                                            SELECT
                                                              @ls_rate_code = rate_code
                                                            FROM
                                                              dbo.dls_elig (NOLOCK)
                                                            WHERE
                                                              dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @li_dep_sir_id;
                                                           
                                                            SET @t_rate_code = @ls_rate_code;

                                                        END;


                                                    EXECUTE  @n_fatal = dbo.dlp_rlmbgrpl @a_batch_id;
													

                                                    IF @n_fatal < 0
        BEGIN
                                                             
                                                            IF @n_fatal IN (-244, -245, -246 )
                                                              SET @n_fatal = -1000;
                                                            ELSE
                                                              IF @n_fatal IN (
                                                              -200 )
                                                              SET @n_fatal = -100;
						
					
                                                            
                                                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                                              @i_sp_id,
                                                              @i_sir_def_id,
                                                              @t_tl_sir_id,
                                                              @n_fatal;
                                                            SET @s_next_family = 'Y';
															
                                                        END;
                                                END;
			
                                            SET @li_1000_count = @li_1000_count
                                                + 1;
			--  LET n_in_transaction = "Y";
			
                                            IF @li_1000_count % 100 = 0
                                                BEGIN
                 SET @li_prcs_bad_cnt = @li_tt_prcs_cnt- @li_prcs_gd_cnt;
													
          UPDATE  dbo.dl_bat_statistics
                             SET     tot_record = @li_tt_prcs_cnt ,
                                                            tot_success_rec = @li_prcs_gd_cnt ,
															tot_fail_rec = @li_prcs_bad_cnt
                                                    WHERE   bat_statistics_id = @i_statistics_id;
                                                END;
			
			-- 	LET n_in_transaction = "N";
        IF @s_next_family = 'Y'
				-- rollback work;
                GOTO SWL_Label11;
			
        UPDATE  dbo.dl_action
                                            SET     process_status = 'Y'
          WHERE   batch_id = @a_batch_id
											 AND dls_sir_id = @t_tl_sir_id
                                                    AND action_date = @t_action_date;
                                            --FETCH NEXT FROM #SWV_cursor_var4 INTO @t_sir_id,
                                            SET @cur6_i = @cur6_i + 1;

                                        END;
                                    SWL_Label11:
                                    --CLOSE #SWV_cursor_var4;
                                    IF @s_next_family = 'Y'
                                        GOTO SWL_Label10;
		
                                    UPDATE  dbo.dl_action
                                    SET     process_status = 'Y'
                                    WHERE   batch_id = @a_batch_id
                                            AND action_date = @t_action_date
                                      AND dls_sir_id IN ( SELECT
                                                              dls_sir_id
                                                              FROM
                                                              #hold_dls_action );
                                     
                                    SET @n_in_transaction = 'N';
                                    --FETCH NEXT FROM #cDate INTO @t_action_date;
                                    SET @cur5_i = @cur5_i + 1;
                                END;
                            SWL_Label10:
                            --CLOSE #cDate;
                            SET @li_tt_prcs_cnt = @li_tt_prcs_cnt+ @li_family_nbr;
							
                            IF @s_next_family = 'Y'
                                GOTO SWL_Label7;
	
                            SET @li_prcs_gd_cnt = @li_prcs_gd_cnt+ @li_family_nbr;
                            
                            SET @n_in_transaction = 'Y';
	--20130419$$cs
	-- 20130418$$ks - should specify where dls_status = "P",
	-- later on phone said <> "E".
	-- Either of the above have identical meanings if the code
	-- functions properly in step 3 (pre-processing).
	
                            UPDATE  dbo.dls_elig
                            SET     dls_status = 'U'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @t_sub_sir_id
                                    AND dls_status != 'E';
                             
                            SET @n_in_transaction = 'N';
                        END TRY
                        BEGIN CATCH
                            SET @n_error_no = ERROR_NUMBER();
                            SET @n_isam_error = ERROR_LINE();
                            SET @n_error_text = ERROR_MESSAGE();
                            IF @n_in_transaction = 'Y'

                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sub_sir_id, @error_no;
                        END CATCH;
                    END;
                    SWL_Label7:
                    --FETCH NEXT FROM @cSubSir INTO @t_sub_sir_id;
                    SET @cur_i = @cur_i + 1;
                END;
            -- CLOSE @cSubSir;
            SET @SWV_func_DL_UPD_STATISTICS_par0 = @li_tt_prcs_cnt- @li_prcs_gd_cnt;
			
          EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @li_tt_prcs_cnt,
                @li_prcs_gd_cnt, @SWV_func_DL_UPD_STATISTICS_par0
    
            IF @SWV_dl_upd_statistics <> 1
			BEGIN
				   SET @SWP_Ret_Value = -1;
                   SET @SWP_Ret_Value1 = CONCAT(@li_tt_prcs_cnt,' Failed to update statistics');
				   IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 4 AND BatchId = @a_batch_id )
					BEGIN
						DELETE FROM GlobalVar WHERE Module_Id = 4 AND BatchId = @a_batch_id
					END
                    RETURN;
                END;

				IF  EXISTS (SELECT 'X' FROM dbo.dls_elig (NOLOCK)--Fix
								  WHERE dls_batch_id = @a_batch_id --AND dls_source='A'
							)
				  BEGIN

						SELECT @n_succ_count = COUNT(*) 
						FROM dbo.dls_elig (NOLOCK)
						WHERE dls_batch_id = @a_batch_id 
						AND dls_status='U' 

						 UPDATE  dbo.dl_bat_statistics --Fix
						 SET     tot_record = @process_cnt ,
								 tot_success_rec = @n_succ_count,
								 tot_fail_rec = CAST(@process_cnt AS INT) - CAST(@n_succ_count AS INT)
						 WHERE   bat_statistics_id = @i_statistics_id; 
					END

            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
         WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

            SET @n_in_transaction = 'N';

            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @a_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Final Process for Batch ',
                                         @a_batch_id, ' is completed');
				IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 4 AND BatchId = @a_batch_id )
				BEGIN
					DELETE FROM GlobalVar WHERE Module_Id = 4 AND BatchId = @a_batch_id
				END
            RETURN;
            IF ( @do_trace = 1 )
                BEGIN--TRACE statement has no equivalent in MSSQL
--trace off;
                    SET @v_Null = 0;
                END;
        END TRY
        BEGIN CATCH
		    IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 4 AND BatchId = @a_batch_id )
			BEGIN
				DELETE FROM GlobalVar WHERE Module_Id = 4 AND BatchId = @a_batch_id
			END
						SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            IF @n_in_transaction = 'Y'
                 
        
            SET @SWP_Ret_Value = @n_error_no;
            SET @SWP_Ret_Value1 = @n_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;