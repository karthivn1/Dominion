﻿CREATE PROCEDURE [dbo].[usp_truncate_tables]
AS
BEGIN

DECLARE @query NVARCHAR(MAX)=N''

SELECT @query+=N'TRUNCATE TABLE [dbo].'+ table_name+CHAR(10)
FROM dle_gen_tables (nolock)

EXEC (@query)

END