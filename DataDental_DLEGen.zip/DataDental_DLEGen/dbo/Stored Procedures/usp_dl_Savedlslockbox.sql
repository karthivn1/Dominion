﻿--drop proc usp_dl_Savedlslockbox
CREATE PROCEDURE [dbo].[usp_dl_Savedlslockbox] (@dlsLockbox dbo.DlsLockbox READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_lockbox 
				 SET dls_batch_id = dlb.dls_batch_id
					  ,dls_lockbox.dls_status = CASE WHEN dlb.dls_status='E' OR dlb.dls_status='P' THEN 'V'
								ELSE dls_lockbox.dls_status END
					  --,dls_source = dlb.dls_source
					  ,invoice_no = dlb.invoice_no
					  ,invoice_date = dlb.invoice_date
					  ,invoice_amt = dlb.invoice_amt
					  ,check_no = dlb.check_no
					  ,paid_amt = dlb.paid_amt
					  ,group_id = dlb.group_id
					  ,group_alt_id = dlb.group_alt_id
					  --,dls_group_id = dlb.dls_group_id
					  --,dls_deposit_acct = dlb.dls_deposit_acct
					  --,dls_alloc_flag = dlb.dls_alloc_flag
					  ,pay_token = dlb.pay_token
				from @dlsLockbox dlb
				WHERE dls_lockbox.dls_sir_id = dlb.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END