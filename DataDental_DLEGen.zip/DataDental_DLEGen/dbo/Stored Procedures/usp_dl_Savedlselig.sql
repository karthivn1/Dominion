﻿--drop proc [usp_dl_Savedlselig] 
CREATE PROCEDURE [dbo].[usp_dl_Savedlselig] (@dlsElig dbo.DlsElig READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_elig 
				SET dls_batch_id = del.dls_batch_id
					  --,dls_sub_sir_id = del.dls_sub_sir_id
					  ,member_flag = del.member_flag
					  ,alt_id = del.alt_id
					  ,ssn = del.ssn
					  ,sub_ssn = del.sub_ssn
					  ,sub_alt_id = del.sub_alt_id
					  ,member_code = del.member_code
					  ,last_name = del.last_name
					  ,first_name = del.first_name
					  ,middle_init = del.middle_init
					  ,date_of_birth = del.date_of_birth
					  ,student_flag = del.student_flag
					  ,disable_flag = del.disable_flag
					  ,cobra_flag = del.cobra_flag
					  ,address1 = del.address1
					  ,address2 = del.address2
					  ,city = del.city
					  ,state = del.state
					  ,zip = del.zip
					  ,zipx = del.zipx
					  ,home_phone = del.home_phone
					  ,home_ext = del.home_ext
					  ,work_phone = del.work_phone
					  ,work_ext = del.work_ext
					  ,rate_code = del.rate_code
					  ,plan_eff_date = del.plan_eff_date
					  ,plan_term_date = del.plan_term_date
					  ,facility_eff_date = del.facility_eff_date
					  --,dls_group_id = del.dls_group_id
					  --,dls_plan_id = del.dls_plan_id
					  ,facility_id = del.facility_id
					  ,def_key = del.def_key
					  ,type = del.type
					  --,dls_member_id = del.dls_member_id
					  --,dls_sub_id = del.dls_sub_id
					  --,dls_action_code = del.dls_action_code
					  ,dls_elig.dls_status = CASE WHEN del.dls_status='E' OR del.dls_status='P' THEN 'V'
												  ELSE dls_elig.dls_status END
					  --,dls_source = del.dls_source
					  ,new_ssn = del.new_ssn
					  ,source_id = del.source_id
					  ,subnew_ssn = del.subnew_ssn
					  ,subsource_id = del.subsource_id
					  ,ext_id_col = del.ext_id_col
					  ,paperless = del.paperless
					  ,email = del.email
					  ,sub_in_plan = del.sub_in_plan
					  ,pend_yn = del.pend_yn
					  ,pend_date = del.pend_date
					  ,eligibility_id = del.eligibility_id
					  --,dls_pend_action = del.dls_pend_action
					  ,member_id = del.member_id
					  ,group_id = del.group_id
					  ,plan_id = del.plan_id
				from @dlsElig del
				WHERE dls_elig.dls_sir_id = del.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END