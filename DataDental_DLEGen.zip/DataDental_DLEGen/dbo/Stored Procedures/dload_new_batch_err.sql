﻿CREATE PROCEDURE [dbo].[dload_new_batch_err]
    @ConfigID INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:00:00 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1



000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @DT DATETIME2(0);
        DECLARE @TD DATE;
        DECLARE @i_isam_error INT;
        DECLARE @BatchID INT;
        DECLARE @ConfigName VARCHAR(50);
        DECLARE @eClaimID INT;
        DECLARE @DetID INT;
        DECLARE @SirID INT;
        DECLARE @ALTID CHAR(20);
        DECLARE @DocNo CHAR(15);
        DECLARE @PatID CHAR(20);
        DECLARE @SubID CHAR(20);
        DECLARE @GRPID CHAR(20);
        DECLARE @PlanID CHAR(20);
        DECLARE @InsType CHAR(1);
        DECLARE @PCPID CHAR(20);
        DECLARE @FCID CHAR(20);
        DECLARE @PVID CHAR(20);
        DECLARE @ReceivedDate CHAR(8);
        DECLARE @RecDate CHAR(10);
        DECLARE @PreAuth CHAR(1);
        DECLARE @Emerg CHAR(1);
        DECLARE @PaySw CHAR(1);
        DECLARE @PVLicState CHAR(2);
        DECLARE @PVFName CHAR(20);
        DECLARE @PVMI CHAR(1);
        DECLARE @PVLName CHAR(30);
        DECLARE @PVTaxID CHAR(9);
        DECLARE @PVAddr1 CHAR(30); 
        DECLARE @PVAddr2 CHAR(30); 
        DECLARE @PVCity CHAR(20);
        DECLARE @PVCountry CHAR(3);
        DECLARE @PVState CHAR(2); 
        DECLARE @PVZIP CHAR(10);
        DECLARE @ClaimType CHAR(2);
        DECLARE @SpecType CHAR(2);
        DECLARE @SvcDate CHAR(10);
        DECLARE @SvcDt CHAR(8);
        DECLARE @CDT CHAR(5);
        DECLARE @Tooth CHAR(2);
        DECLARE @Surf CHAR(5);
        DECLARE @QD CHAR(5);
        DECLARE @COB CHAR(20);
        DECLARE @SUBM CHAR(20);
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY

            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  eclaim_id INT ,
                  alt_id CHAR ,
                  document_no CHAR ,
                  preauth_switch CHAR ,
                  emergency_switch CHAR ,
                  pv_f_name CHAR ,
                  pv_mi CHAR ,
                  pv_l_name CHAR ,
                  pv_tax_id CHAR ,
                  pv_addr1 CHAR ,
                  pv_addr2 CHAR ,
                  pv_city CHAR ,
                  pv_state CHAR ,
                  pv_zip CHAR ,
                  pv_country CHAR ,
                  pv_lic_state CHAR ,
                  pv_id CHAR ,
                  pay_prv_switch CHAR ,
                  contr_fc_id CHAR ,
                  patient_id CHAR ,
                  pcp_id CHAR ,
                  subscriber_id CHAR ,
                  group_id CHAR ,
                  plan_id CHAR ,
                  ins_type CHAR ,
                  received_date CHAR ,
                  hmo_claim_type CHAR ,
                  speciality_type CHAR
                );

            DECLARE @SWV_cursor_var2 TABLE
                (
                  id INT IDENTITY ,
                  eclaim_d_id INT ,
                  svc_date CHAR ,
                  d_proc_code CHAR ,
                  tooth_no CHAR ,
                  surface CHAR ,
                  quad CHAR ,
                  cob_amt CHAR ,
                  submitted_amt CHAR
                );

            SET LOCK_TIMEOUT 30000;
            BEGIN TRAN;
            SET @DT = GETDATE(); 
            SET @TD = CONVERT(DATE, @DT); 

/*  Create Batch Header Record */

            INSERT  INTO dbo.dl_config_bat
                    ( config_id ,
                      config_bat_status ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @ConfigID ,
                      'N' ,
                      ORIGINAL_LOGIN() ,
                      CAST(@DT AS VARCHAR(22))
                    );
	 
            SELECT  @BatchID = dbo.getserialid();

/* Create Detail Records */
            INSERT  INTO dbo.dl_cfg_bat_det
                    ( config_bat_id ,
                      sp_id ,
                      cfg_bat_det_toler ,
                      cfg_bat_det_stat ,
                      created_by ,
                      created_time ,
                      sir_def
                    )
                    SELECT  @BatchID ,
                            sp_id ,
                            tolerance ,
                            'N' ,
                            ORIGINAL_LOGIN() ,
                            @DT ,
                            ( SELECT    sir_def_id
                              FROM      dbo.dl_sp_sir (NOLOCK)
                              WHERE     dbo.dl_config_job_det.sp_id = dbo.dl_sp_sir.sp_id
                            )
                    FROM    dbo.dl_config_job_det (NOLOCK)
                    WHERE   dbo.dl_config_job_det.config_id = @ConfigID;
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   config_bat_id = @BatchID
                    AND sp_id = ( SELECT    sp_id
                                  FROM      dbo.dl_sp (NOLOCK)
                                  WHERE     sp_name = 'ld_utilization'
                                );

/* Create Parameter Records */

            INSERT  INTO dbo.dl_cfg_bat_param
                    ( config_bat_id ,
                      sp_param_id ,
                      param_value ,
                      created_by ,
                      created_time
                    )
                    SELECT  @BatchID ,
                            sp_param_id ,
                            config_param_value ,
                            ORIGINAL_LOGIN(),
                            @DT
                    FROM    dbo.dl_config_param (NOLOCK)
                    WHERE   dbo.dl_config_param.config_id = @ConfigID; 
            UPDATE  dbo.dl_cfg_bat_param
            SET     param_value = @TD
            WHERE   config_bat_id = @BatchID
                    AND param_value = '$today$';
            COMMIT; 
            BEGIN TRAN; 
            SELECT  @ConfigName = config_name
            FROM    dbo.dl_config (NOLOCK)
            WHERE   config_id = @ConfigID; 
            IF @@rowcount = 0
                SELECT  @ConfigName = NULL;

            INSERT  INTO @SWV_cursor_var1
                    ( eclaim_id ,
                      alt_id ,
                      document_no ,
                      preauth_switch ,
                      emergency_switch ,
                      pv_f_name ,
                      pv_mi ,
                      pv_l_name ,
                      pv_tax_id ,
                      pv_addr1 ,
                      pv_addr2 ,
                      pv_city ,
                      pv_state ,
                      pv_zip ,
                      pv_country ,
                      pv_lic_state ,
                      pv_id ,
                      pay_prv_switch ,
                      contr_fc_id ,
                      patient_id ,
                      pcp_id ,
                      subscriber_id ,
                      group_id ,
                      plan_id ,
                      ins_type ,
                      received_date ,
                      hmo_claim_type ,
                      speciality_type
				    )
     SELECT  eclaim_id ,
                            alt_id ,
                            document_no ,
                            preauth_switch ,
                            emergency_switch ,
                            pv_f_name ,
                            pv_mi ,
                            pv_l_name ,
                            pv_tax_id ,
                            pv_addr1 ,
                            pv_addr2 ,
                            pv_city ,
                            pv_state ,
                            pv_zip ,
                            pv_country ,
                            pv_lic_state ,
                            pv_id ,
                            pay_prv_switch ,
                            contr_fc_id ,
                            patient_id ,
                            pcp_id ,
                            subscriber_id ,
                            group_id ,
                            plan_id ,
                            ins_type ,
                            received_date ,
                            hmo_claim_type ,
                            speciality_type
                    FROM    dbo.eclaim_h (NOLOCK)
                    WHERE   config_name = @ConfigName
                            AND status = 1  -- Ready
                            AND dds_claim_id = 0;

           /* SET @SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_id, alt_id, document_no, preauth_switch, emergency_switch,
		  pv_f_name, pv_mi, pv_l_name, pv_tax_id, pv_addr1, pv_addr2,
		  pv_city, pv_state, pv_zip, pv_country,
		  pv_lic_state, pv_id, pay_prv_switch, contr_fc_id, patient_id, pcp_id,
		 subscriber_id, group_id, plan_id, ins_type, received_date,
		 hmo_claim_type, speciality_type
		
      FROM dbo.eclaim_h (NOLOCK) WHERE config_name = @ConfigName AND status = 1  -- Ready
      AND dds_claim_id = 0;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID, @ALTID, @DocNo,
                @PreAuth, @Emerg, @PVFName, @PVMI, @PVLName, @PVTaxID,
                @PVAddr1, @PVAddr2, @PVCity, @PVState, @PVZIP, @PVCountry,
                @PVLicState, @PVID, @PaySw, @FCID, @PatID, @PCPID, @SubID,
                @GRPID, @PlanID, @InsType, @RecDate, @ClaimType, @SpecType;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN

                    SELECT  @eClaimID = eclaim_id ,
                            @ALTID = alt_id ,
                            @DocNo = document_no ,
                            @PreAuth = preauth_switch ,
                            @Emerg = emergency_switch ,
                            @PVFName = pv_f_name ,
                            @PVMI = pv_mi ,
                            @PVLName = pv_l_name ,
                            @PVTaxID = pv_tax_id ,
                            @PVAddr1 = pv_addr1 ,
                            @PVAddr2 = pv_addr2 ,
                            @PVCity = pv_city ,
                            @PVState = pv_state ,
                            @PVZIP = pv_zip ,
                            @PVCountry = pv_country ,
                            @PVLicState = pv_lic_state ,
                            @PVID = pv_id ,
                            @PaySw = pay_prv_switch ,
                            @FCID = contr_fc_id ,
                            @PatID = patient_id ,
                            @PCPID = pcp_id ,
                            @SubID = subscriber_id ,
                            @GRPID = group_id ,
                            @PlanID = plan_id ,
                            @InsType = ins_type ,
          @RecDate = received_date ,
                            @ClaimType = hmo_claim_type ,
                            @SpecType = speciality_type
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur_i;

                    IF SUBSTRING(@RecDate, 3, 1) = '/'
                        SET @ReceivedDate = SUBSTRING(@RecDate, 1, 2)
                            + SUBSTRING(@RecDate, 4, 2) + SUBSTRING(@RecDate,
                                                              7, 4); 
                    ELSE
                        SET @ReceivedDate = @RecDate; 
                    INSERT  INTO @SWV_cursor_var2
                            ( eclaim_d_id ,
                              svc_date ,
                              d_proc_code ,
                              tooth_no ,
                              surface ,
                              quad ,
                              cob_amt ,
                              submitted_amt
		                    )
                            SELECT  eclaim_d_id ,
                                    svc_date ,
                                    d_proc_code ,
                                    tooth_no ,
                                    surface ,
                                    quad ,
                                    cob_amt ,
                                    submitted_amt
                            FROM    dbo.eclaim_d (NOLOCK)
                            WHERE   eclaim_id = @eClaimID
                                    AND error_code != 'IGNORE';

               /* SET @SWV_cursor_var2 = CURSOR  FOR SELECT eclaim_d_id, svc_date, d_proc_code, tooth_no, surface,
			     quad, cob_amt, submitted_amt
			  
         FROM dbo.eclaim_d (NOLOCK) WHERE eclaim_id = @eClaimID AND error_code !=
         'IGNORE';
                OPEN @SWV_cursor_var2;
                FETCH NEXT FROM @SWV_cursor_var2 INTO @DetID, @SvcDate, @CDT,
                    @Tooth, @Surf, @QD, @COB, @SUBM;
                WHILE @@FETCH_STATUS = 0
				*/
                    DECLARE @cur2_cnt INT ,
                        @cur2_i INT;

                    SET @cur2_i = 1;

					--Get the no. of records for the cursor
                    SELECT  @cur2_cnt = COUNT(1)
                    FROM    @SWV_cursor_var2;
					
					--while @@FETCH_STATUS = 0
                    WHILE ( @cur2_i <= @cur2_cnt )
                        BEGIN
                            SELECT  @DetID = eclaim_d_id ,
                                    @SvcDate = svc_date ,
                                    @CDT = d_proc_code ,
                                    @Tooth = tooth_no ,
                                    @Surf = surface ,
                                    @QD = quad ,
                                    @COB = cob_amt ,
                                    @SUBM = submitted_amt
                            FROM    @SWV_cursor_var2
                            WHERE   id = @cur2_i;

                            IF SUBSTRING(@SvcDate, 3, 1) = '/'
                                SET @SvcDt = SUBSTRING(@SvcDate, 1, 2)
                                    + SUBSTRING(@SvcDate, 4, 2)
                                    + SUBSTRING(@SvcDate, 7, 4); 
                            ELSE
                                SET @SvcDt = @SvcDate; 
			 
                            INSERT  INTO dbo.dls_utilization
                                    ( dls_batch_id ,
                                      dls_status ,
                                      dls_source ,
                                      alt_id ,
                                      document_no ,
                                      patient_id ,
                                      subscriber_id ,
                                      group_id ,
                                      plan_id ,
                                      ins_type ,
       pcp_id ,
                                      fc_id ,
                                      prv_id ,
                                      received_date ,
                                      preauth_switch ,
                                      emergency_switch ,
                                      pay_prv_switch ,
                                      pv_state ,
                                      first_name ,
                                      middle_init ,
                                      last_name ,
                                      tax_id ,
                                      addr1 ,
                                      addr2 ,
                                      city ,
                                      country ,
                                      state ,
                                      zip ,
                                      type ,
                                      speciality_type ,
                                      svc_beg ,
                                      d_proc_code ,
                                      tooth_no ,
                                      surface ,
                                      quad ,
                                      cob_amt ,
                                      submitted_amt
                                    )
                            VALUES  ( @BatchID ,
                                      'L' ,
                                      'F' ,
                                      @ALTID ,
                                      @DocNo ,
                                      @PatID ,
                                      @SubID ,
                                      @GRPID ,
                                      @PlanID ,
                                      @InsType ,
                                      @PCPID ,
                                      @FCID ,
                                      @PVID ,
                                      @ReceivedDate ,
                                      @PreAuth ,
                                      @Emerg ,
                                      @PaySw ,
                                      @PVLicState ,
                                      @PVFName ,
                                      @PVMI ,
                                      @PVLName ,
                                      @PVTaxID ,
                                      @PVAddr1 ,
                                      @PVAddr2 ,
                                      @PVCity ,
                                      @PVCountry ,
                                      @PVState ,
                                      @PVZIP ,
                                      @ClaimType ,
                                      @SpecType ,
                                      @SvcDt ,
                                      @CDT ,
                                      @Tooth ,
                                      @Surf ,
                                      @QD ,
                                      @COB ,
                                      @SUBM
                                    );
			
                            SELECT  @SirID = dbo.getserialid();
                            UPDATE  dbo.eclaim_d
                            SET     dls_sir_id = @SirID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_d_id = @DetID;
                        /*FETCH NEXT FROM @SWV_cursor_var2 INTO @DetID, @SvcDate,
                            @CDT, @Tooth, @Surf, @QD, @COB, @SUBM */
                            SET @cur2_i = @cur2_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var2;
                    UPDATE  dbo.eclaim_h
                    SET     dls_batch_id = @BatchID ,
                            status = 2 ,
   h_user = ORIGINAL_LOGIN() ,
                            h_datetime = GETDATE()
                    WHERE   eclaim_id = @eClaimID;
                    COMMIT; 
                    BEGIN TRAN;
                    /*FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID, @ALTID,
                        @DocNo, @PreAuth, @Emerg, @PVFName, @PVMI, @PVLName,
                        @PVTaxID, @PVAddr1, @PVAddr2, @PVCity, @PVState,
                        @PVZIP, @PVCountry, @PVLicState, @PVID, @PaySw, @FCID,
                        @PatID, @PCPID, @SubID, @GRPID, @PlanID, @InsType,
                        @RecDate, @ClaimType, @SpecType; */
                    SET @cur_i = @cur_i + 1;
                END;
            --CLOSE @SWV_cursor_var1;
            COMMIT; 
            SET @SWP_Ret_Value = @BatchID;
            SET @SWP_Ret_Value1 = 'Process Complete';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

----------------------------------------------------------------------

--set debug file to 'dloadbatch.trc';
--trace on;
    END;