﻿CREATE PROCEDURE [dbo].[dlp_sg_cal_rate]
    @a_batch_id INT ,
    @a_sub_sir_id INT ,
    @a_sub_id INT
    
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text VARCHAR(64);
	
	
        DECLARE @i_dep_cnt INT;
        DECLARE @i_spouse INT;
        DECLARE @d_plan_eff_date DATE;
        DECLARE @d_plan_term_date DATE;
        DECLARE @i_sir_id INT;
        DECLARE @s_member_code CHAR(2);
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_old_rate_code CHAR(2);
        DECLARE @n_temp_rate CHAR(2);
        DECLARE @i_num_dependent INT;
        DECLARE @i_num_facility INT;
        DECLARE @s_allow_spouse CHAR(1);
        DECLARE @i_group_id INT;
        DECLARE @i_plan_id INT;
        DECLARE @n_member_id INT;
        DECLARE @n_member_code CHAR(2);
        DECLARE @n_sub_id INT;
        DECLARE @n_sub_group_id INT;
        DECLARE @n_sub_msg_id INT;
        DECLARE @n_sub_plan_id INT;
        DECLARE @n_sub_facility_id INT;
        DECLARE @n_sub_plan_eff DATE;
        DECLARE @s_action_code CHAR(2);
        DECLARE @i_mb_gr_pl_id INT;
        DECLARE @d_action_date DATE;
        DECLARE @i_dls_sir_id INT;
        DECLARE @d_eff_rt_date DATE;
        DECLARE @tmp_rate CHAR(2);
        DECLARE @s_sub_action_code CHAR(2);
        DECLARE @n_sub_rate_code CHAR(2);
        DECLARE @n_fatal INT;
        DECLARE @d_min_action_date DATE;
        DECLARE @sg_sp_id int;
        DECLARE @sg_sir_def_id int;
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;
        --DECLARE @cRCSir CURSOR;
	--set explain on;
	/*
	XXX:  Low priority coding fix.
	dlp_sg_cal_rate:  No exceptions raised:  returns -1.
	Looks mis-coded.  For example:  RAISE EXCEPTION -746, 601, "Missing Sub's active group/plan record";
	but there is no catch clause to log the error, it would simply return -1.
	*/
        SET NOCOUNT ON;
        SET @sg_sp_id = 0 ;
       
        SET @sg_sir_def_id = 0 ;

		select @sg_sp_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='sg_sp_id'
		select @sg_sir_def_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='sg_sir_def_id'
        
        IF EXISTS ( SELECT  *
                    FROM    tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#dls_sg_action_eff')
                            AND xtype = 'U' )
            DROP TABLE #dls_sg_action_eff;
        CREATE TABLE #dls_sg_action_eff
            (
              dls_sir_id INT ,
              action_code CHAR(2) ,
              action_date DATE
            );
        BEGIN TRY
            SELECT  @s_sub_action_code = dls_action_code ,
                    @n_sub_id = dls_subscriber_id ,
                    @n_sub_group_id = dls_group_id ,
                    @n_sub_plan_id = dls_plan_id ,
                    @n_sub_facility_id = dls_facility_id ,
                    @n_sub_plan_eff = mb_gppl_eff_date ,
                    @n_sub_rate_code = rate_code ,
                    @n_sub_msg_id = dls_msg_id
            FROM    dbo.dls_sg_member (NOLOCK)
            WHERE   dls_batch_id = @a_batch_id
                    AND dls_sir_id = @a_sub_sir_id;
            
            IF @s_sub_action_code = 'ST'
                RETURN 1;
	
            BEGIN
                BEGIN TRY
                    DELETE  FROM #dls_sg_action_eff;
                    CREATE INDEX dls_sg_act_eff_1 ON #dls_sg_action_eff 
                    (dls_sir_id);
                    CREATE INDEX dls_sg_act_eff_2 ON #dls_sg_action_eff 
                    (action_code);
                END TRY
                BEGIN CATCH
                    SET @n_error_no = ERROR_NUMBER();
                    SET @n_isam_error = ERROR_LINE();
                    SET @n_error_text = ERROR_MESSAGE();
                    DROP TABLE #dls_sg_action_eff;
                    DELETE  FROM #dls_sg_action_eff;
                END CATCH;
            END;
            SET @i_spouse = 0;
            SET @i_dep_cnt = 0;
            SET @n_old_rate_code = NULL;
            INSERT  INTO #dls_sg_action_eff
                    ( dls_sir_id ,
                      action_code ,
                      action_date
                    )
                    SELECT  dls_sir_id ,
                            action_code ,
                            action_date
                    FROM    dbo.dl_action (NOLOCK)
                    WHERE   batch_id = @a_batch_id
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_sg_member (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @a_sub_sir_id );
            IF NOT EXISTS ( SELECT  *
                            FROM    #dls_sg_action_eff
                            WHERE   action_code IN ( 'DA', 'MT', 'PA', 'PC',
                                                     'RC', 'RI', 'SA' ) )
                RETURN 1;
	
            IF @s_sub_action_code LIKE 'G[1-7]' ESCAPE '\'
                OR @s_sub_action_code IN ( 'FA', 'FC', 'FX', 'NC', 'CA', 'MU' )
                BEGIN
                    SELECT  @d_min_action_date = MIN(action_date)
                    FROM    #dls_sg_action_eff;
                    
                    SELECT  @i_mb_gr_pl_id = mb_gr_pl_id
                    FROM    dbo.rlmbgrpl (NOLOCK)
                    WHERE   member_id = @n_sub_id
                            AND group_id = @n_sub_group_id
                            AND plan_id = @n_sub_plan_id
                            AND eff_gr_pl <= @n_sub_plan_eff
                            AND ( exp_gr_pl > @n_sub_plan_eff
                                  OR exp_gr_pl IS NULL
                                );
                   
                    IF @i_mb_gr_pl_id IS NULL
                        RAISERROR('Missing Sub''s active group/plan record',16,1);
		DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 rate_code CHAR(2), 
						 eff_rt_date DATE
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								rate_code, eff_rt_date
                                )
								SELECT rate_code, eff_rt_date
		
         FROM dbo.rlmbrt (NOLOCK)
         WHERE mb_gr_pl_id = @i_mb_gr_pl_id
         AND exp_rt_date IS NULL
         ORDER BY eff_rt_date DESC;

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;

		/*
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT rate_code, eff_rt_date
		
         FROM dbo.rlmbrt (NOLOCK)
         WHERE mb_gr_pl_id = @i_mb_gr_pl_id
         AND exp_rt_date IS NULL
         ORDER BY eff_rt_date DESC;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @n_old_rate_code,
                        @d_eff_rt_date;
                    WHILE @@FETCH_STATUS = 0
					*/
                       WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT @n_old_rate_code=rate_code,
			@d_eff_rt_date=eff_rt_date
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;
                            GOTO SWL_Label5;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @n_old_rate_code,
                            --    @d_eff_rt_date;
							SET @cur1_i = @cur1_i + 1;
                        END;
          SWL_Label5:
                    --CLOSE @SWV_cursor_var1;
                    IF ( @n_old_rate_code IS NULL
                         OR @n_old_rate_code = ''
                       )
                        RAISERROR('Missing Sub''s active rate code',16,1);
		
                    IF @d_min_action_date < @d_eff_rt_date
                        SET @d_min_action_date = @d_eff_rt_date;

						DECLARE @SWV_cursor_var2 TABLE
                        (
                         id INT IDENTITY ,
						 member_id INT, 
						 member_code CHAR(3)
                        );
                          INSERT  INTO @SWV_cursor_var2
                                ( 
								member_id, member_code
                                )
								SELECT DISTINCT m.member_id, m.member_code
		
         FROM dbo.rlplfc rf (NOLOCK),
		 dbo.member m (NOLOCK)
         WHERE rf.mb_gr_pl_id = @i_mb_gr_pl_id
         AND m.member_id = rf.member_id
         AND m.member_id != @n_sub_id
         AND ((rf.eff_date <= @d_min_action_date
         AND (rf.exp_date >  @d_min_action_date OR rf.exp_date IS NULL))
         OR (rf.eff_date > @d_min_action_date AND
		(rf.exp_date > @d_min_action_date OR rf.exp_date IS NULL)));

	  DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
                        FROM  @SWV_cursor_var2;

						/*
		
                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT DISTINCT m.member_id, m.member_code
		
         FROM dbo.rlplfc rf (NOLOCK),
		 dbo.member m (NOLOCK)
         WHERE rf.mb_gr_pl_id = @i_mb_gr_pl_id
         AND m.member_id = rf.member_id
         AND m.member_id != @n_sub_id
         AND ((rf.eff_date <= @d_min_action_date
         AND (rf.exp_date >  @d_min_action_date OR rf.exp_date IS NULL))
         OR (rf.eff_date > @d_min_action_date AND
		(rf.exp_date > @d_min_action_date OR rf.exp_date IS NULL)));
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @n_member_id,
                        @n_member_code;
                    WHILE @@FETCH_STATUS = 0
					*/

                       WHILE ( @cur2_i <= @cur2_cnt )
            BEGIN
			SELECT @n_member_id= member_id,
                        @n_member_code= member_code
					FROM @SWV_cursor_var2
            WHERE   id = @cur2_i;

                            IF @n_member_code IN ( '30', '40' )
                                BEGIN
                                    SET @i_spouse = @i_spouse + 1;
                                    SET @i_dep_cnt = @i_dep_cnt + 1;
                                END;
			
                            IF @n_member_code IN ( '50', '70' )
                                SET @i_dep_cnt = @i_dep_cnt + 1;
                            --FETCH NEXT FROM @SWV_cursor_var2 INTO @n_member_id,
                            --    @n_member_code;
							SET @cur2_i = @cur2_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var2;
                END;
	
            SET @n_rate_code = NULL;


			DECLARE @SWV_cursor_var3 TABLE
                        (
                         id INT IDENTITY ,
						 action_date DATE
                        );
                          INSERT  INTO @SWV_cursor_var3
                                ( 
								action_date
                                )
								SELECT DISTINCT action_date
	
      FROM #dls_sg_action_eff
      ORDER BY action_date

	  DECLARE @cur3_cnt INT ,
                            @cur3_i INT;

                        SET @cur3_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur3_cnt = COUNT(1)
                        FROM  @SWV_cursor_var3;
			/*
            SET @cRCSir = CURSOR  FOR SELECT DISTINCT action_date
	
      FROM #dls_sg_action_eff
      ORDER BY action_date;
            OPEN @cRCSir;
            FETCH NEXT FROM @cRCSir INTO @d_action_date;
            WHILE @@FETCH_STATUS = 0
			*/
                 WHILE ( @cur3_i <= @cur3_cnt )
            BEGIN
			SELECT @d_action_date= action_date
					FROM @SWV_cursor_var3
            WHERE   id = @cur3_i;

                    BEGIN
                        --DECLARE @SWV_cursor_var3 CURSOR;
                        --DECLARE @SWV_cursor_var4 CURSOR;
                        --DECLARE @SWV_cursor_var5 CURSOR;
                        BEGIN TRY

						DECLARE @SWV_cursor_var4 TABLE
                        (
                         id INT IDENTITY ,
						 dls_sir_id INT, 
						 action_code CHAR(2)
                        );
                          INSERT  INTO @SWV_cursor_var4
                                ( 
								dls_sir_id, action_code
                                )
								SELECT dls_sir_id, action_code
		
               FROM #dls_sg_action_eff
               WHERE action_date = @d_action_date;

	  DECLARE @cur4_cnt INT ,
                            @cur4_i INT;

                        SET @cur4_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur4_cnt = COUNT(1)
                        FROM  @SWV_cursor_var4;

						/*
                            SET @SWV_cursor_var3 = CURSOR  FOR SELECT dls_sir_id, action_code
		
               FROM #dls_sg_action_eff
               WHERE action_date = @d_action_date;
                            OPEN @SWV_cursor_var3;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @i_dls_sir_id,
                                @s_action_code;
                            WHILE @@FETCH_STATUS = 0
							*/

                                WHILE ( @cur4_i <= @cur4_cnt )
            BEGIN
			SELECT @i_dls_sir_id= dls_sir_id,
			@s_action_code= action_code
					FROM @SWV_cursor_var4
            WHERE   id = @cur4_i;
                                    IF @s_action_code LIKE 'G[1-7]' ESCAPE '\'
                                        OR @s_action_code IN ( 'FA', 'FC',
                                                              'NC', 'CA' )
                                        GOTO SWL_Label6;
			
                                    SELECT  @s_member_code = member_code
                                    FROM    dbo.dls_sg_member (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @i_dls_sir_id;
                                    
                                    IF @s_member_code IN ( '30', '40' )
                                        BEGIN
                                            IF @s_action_code IN ( 'DA', 'PA',
                                                              'PC', 'RC', 'RI',
                                                              'SA' )
                                                BEGIN
                                                    SET @i_spouse = @i_spouse
                                                        + 1;
                                                    SET @i_dep_cnt = @i_dep_cnt
                 + 1;
                                  END;
				
                                            IF @s_action_code = 'MT'
                                                BEGIN
                                                    SET @i_spouse = @i_spouse
                                                        - 1;
                                                    SET @i_dep_cnt = @i_dep_cnt
                                                        - 1;
                                                END;
                                        END;
			
                                    IF @s_member_code IN ( '50', '70' )
                                        BEGIN
             IF @s_action_code IN ( 'DA', 'PA',
                  'PC', 'RC', 'RI',
                                                  'SA' )
                                                SET @i_dep_cnt = @i_dep_cnt
                                                    + 1;
				
                                            IF @s_action_code = 'MT'
                                                SET @i_dep_cnt = @i_dep_cnt
                                                    - 1;
                                        END;
                                    SWL_Label6:
                                    --FETCH NEXT FROM @SWV_cursor_var3 INTO @i_dls_sir_id,
                                    --    @s_action_code;
									SET @cur4_i = @cur4_i + 1;
                                END;
                            --CLOSE @SWV_cursor_var3;
                            IF @i_spouse > 0
                                BEGIN

								DECLARE @SWV_cursor_var5 TABLE
                        (
                         id INT IDENTITY ,
						 rate_code CHAR(2), 
						 rate_num_depend SMALLINT,
				         num_facil SMALLINT, 
				         spouse CHAR
                        );
                          INSERT  INTO @SWV_cursor_var5
                                ( 
								rate_code, rate_num_depend,
				num_facil, spouse
                                )
								SELECT pr.rate_code, pr.rate_num_depend,
				pr.num_facil, pr.spouse
			
                  FROM dbo.pl_rat pr (NOLOCK),
				  dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_msg_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.spouse = 'Y' AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
			--(gcr.exp_date >= d_action_date or gcr.exp_date is null)
			(gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY rate_num_depend;

	  DECLARE @cur5_cnt INT ,
                            @cur5_i INT;

                        SET @cur5_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur5_cnt = COUNT(1)
                        FROM  @SWV_cursor_var5;
								/*
                                    SET @SWV_cursor_var4 = CURSOR  FOR SELECT pr.rate_code, pr.rate_num_depend,
				pr.num_facil, pr.spouse
			
                  FROM dbo.pl_rat pr (NOLOCK),
				  dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_msg_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.spouse = 'Y' AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
			--(gcr.exp_date >= d_action_date or gcr.exp_date is null)
			(gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY rate_num_depend;
                                    OPEN @SWV_cursor_var4;
                                    FETCH NEXT FROM @SWV_cursor_var4 INTO @n_rate_code,
                                        @i_num_dependent, @i_num_facility,
                                        @s_allow_spouse;
                                    WHILE @@FETCH_STATUS = 0
									*/
									WHILE ( @cur5_i <= @cur5_cnt )
            BEGIN
			SELECT @n_rate_code=rate_code,
                   @i_num_dependent=rate_num_depend, 
				   @i_num_facility=num_facil,
                   @s_allow_spouse=spouse
				FROM @SWV_cursor_var5
            WHERE   id = @cur5_i;
			
                                            GOTO SWL_Label7;
                                            --FETCH NEXT FROM @SWV_cursor_var4 INTO @n_rate_code,
                                            --    @i_num_dependent,
                         --    @i_num_facility,
                                            --    @s_allow_spouse;
											SET @cur5_i = @cur5_i + 1;
                                   END;
                                    SWL_Label7:
                                    --CLOSE @SWV_cursor_var4;
                                END;
                            ELSE
                                BEGIN

								DECLARE @SWV_cursor_var6 TABLE
                        (
                         id INT IDENTITY ,
						 rate_code CHAR(2), 
						 rate_num_depend SMALLINT,
				         num_facil SMALLINT, 
				         spouse CHAR
                        );
                          INSERT  INTO @SWV_cursor_var6
                                ( 
								rate_code, rate_num_depend,
				num_facil, spouse
                                )
								SELECT pr.rate_code, pr.rate_num_depend,
				pr.num_facil, pr.spouse
			
                  FROM dbo.pl_rat pr (NOLOCK),
				  dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_msg_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
			--(gcr.exp_date >= d_action_date or gcr.exp_date is null)
			(gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY spouse,rate_num_depend;

	  DECLARE @cur6_cnt INT ,
                            @cur6_i INT;

                        SET @cur6_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur6_cnt = COUNT(1)
                        FROM  @SWV_cursor_var6;

								/*
                                    SET @SWV_cursor_var5 = CURSOR  FOR SELECT pr.rate_code, pr.rate_num_depend,
				pr.num_facil, pr.spouse
			
                  FROM dbo.pl_rat pr (NOLOCK),
				  dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_msg_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
			--(gcr.exp_date >= d_action_date or gcr.exp_date is null)
			(gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY spouse,rate_num_depend;
                                    OPEN @SWV_cursor_var5;
                                    FETCH NEXT FROM @SWV_cursor_var5 INTO @n_rate_code,
                                        @i_num_dependent, @i_num_facility,
                                        @s_allow_spouse;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                        WHILE ( @cur6_i <= @cur6_cnt )
            BEGIN
			SELECT @n_rate_code=rate_code,
                   @i_num_dependent=rate_num_depend, 
				   @i_num_facility=num_facil,
                   @s_allow_spouse=spouse
				FROM @SWV_cursor_var6
            WHERE   id = @cur6_i;
                                            GOTO SWL_Label8;
                                            --FETCH NEXT FROM @SWV_cursor_var5 INTO @n_rate_code,
                                            --    @i_num_dependent,
                                            --    @i_num_facility,
                                            --    @s_allow_spouse;
											SET @cur6_i = @cur6_i + 1;
                                        END;
                                    SWL_Label8:
                                    --CLOSE @SWV_cursor_var5;
                                END;
		
                            IF ( @n_rate_code IS NULL
                                 OR @n_rate_code = ''
                               )
                                RETURN -141;
		
                            IF ( @n_old_rate_code IS NULL
                        OR @n_old_rate_code = ''
                               )
                                BEGIN
                                    IF @s_sub_action_code = 'SA'
                                        IF ( ( @n_sub_rate_code IS NULL
                                               OR @n_sub_rate_code = ''
                                             )
                                             OR @n_sub_rate_code != @n_rate_code
                                           )
                                            BEGIN
                                                ;
                                                EXECUTE @n_error_no = dbo.usp_dl_log_error @a_batch_id,
                                                    @sg_sp_id, @sg_sir_def_id,
                                                    @a_sub_sir_id, 603;

                                                UPDATE  dbo.dls_sg_member
                                                SET     rate_code = @n_rate_code
                                                WHERE   dls_batch_id = @a_batch_id
                                                        AND dls_sub_sir_id = @a_sub_sir_id;
                                            END;
				
			
                                    SET @n_old_rate_code = @n_sub_rate_code;
                                END;
                            ELSE
                                IF @n_rate_code != @n_old_rate_code
                                    BEGIN
                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                            @a_sub_sir_id, 'RC',
                                            @d_action_date;
                                        SET @n_old_rate_code = @n_rate_code;
                                        UPDATE  dbo.dls_sg_member
                                        SET     rate_code = @n_rate_code
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND dls_sir_id IN (
                                                SELECT  dls_sir_id
                                                FROM    #dls_sg_action_eff
                                                WHERE   action_date = @d_action_date
                                                        AND dls_sir_id != @a_sub_sir_id );
                            END;
			
		
                            IF @i_num_facility = 1
                                UPDATE  dbo.dls_sg_member
                                SET     facility_id = @n_sub_facility_id
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_action_code != 'MT'
                                        AND dls_sir_id IN (
                                        SELECT  dls_sir_id
                                        FROM    #dls_sg_action_eff
                                        WHERE   action_date = @d_action_date );
                        END TRY
                        BEGIN CATCH
                            SET @n_error_no = ERROR_NUMBER();
                            SET @n_isam_error = ERROR_LINE();
                            SET @n_error_text = ERROR_MESSAGE();
                           
                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @sg_sp_id, @sg_sir_def_id, @a_sub_sir_id,
                                @n_isam_error;
                            IF @n_fatal <> 1
                                RETURN -1;
                        END CATCH;
                    END;
                    --FETCH NEXT FROM @cRCSir INTO @d_action_date;
					SET @cur3_i = @cur3_i + 1;
                END;
            --CLOSE @cRCSir;
            IF ( @n_rate_code IS NOT NULL
                 AND @n_rate_code <> ''
               )
                IF @s_sub_action_code != 'SA'
                    UPDATE  dbo.dls_sg_member
                    SET     rate_code = @n_rate_code
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @a_sub_sir_id;
		
	
--trace off;
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;

	--set debug file to "/tmp/dlp_sg_cal_rate.trc"; 
	--trace on; 
    END;