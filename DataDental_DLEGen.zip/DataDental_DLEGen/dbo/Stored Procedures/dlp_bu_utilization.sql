﻿CREATE PROCEDURE [dbo].[dlp_bu_utilization]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
	

------------------------------------------------------------------------------
--
--            Procedure:   dlp_bu_utilization
--
--            Created:     02/01/1999
--            Author:      Kim Nguyen, Gene Albers
--
-- Purpose:  This SP performs before update pre-processing on DataDental
--           Electronic Claims for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE         AUTHOR       DETAILS
--   08/12/1999   G.Albers     Added 2 new error conditions that can be logged.
--                               Error #0 is unknown DB error,
--                               Error #10 is multiple recs returned for query
--                               Exception handling modified for changes.
--
--  03/27/2000   Ameeta		check for Serial id's instead of alt id.
--				AR# 4216 rewrite PV/FC logic
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 11:34:34 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


















000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).

*/


        DECLARE @s_proc_name CHAR(14);
        DECLARE @s_sir_def_name CHAR(14);

        DECLARE @config_cnt INT;
        DECLARE @i_process_count INT;
        DECLARE @i_succ_count INT;
        DECLARE @i_init_count INT;
        DECLARE @i_error_count INT;
        DECLARE @i_error_no INT;
        DECLARE @i_error INT;
        DECLARE @i_fatal INT;
        DECLARE @s_error_text VARCHAR(64);
        DECLARE @s_err_rtn_text VARCHAR(64);
        DECLARE @i_isam_error INT;
        DECLARE @i_plan_error INT;
        DECLARE @i_addr_error INT;
        DECLARE @i_config_id INT;

        DECLARE @s_batch_status CHAR(1);
        DECLARE @s_alt_id CHAR(20);
        DECLARE @s_patient_id CHAR(20);
        DECLARE @s_subscriber_id CHAR(20);
        DECLARE @s_group_id CHAR(20);
        DECLARE @s_plan_id CHAR(20);
        DECLARE @s_ins_type CHAR(1);
        DECLARE @s_pcp_id CHAR(20);
        DECLARE @s_fc_id CHAR(20);
        DECLARE @s_prv_id CHAR(20);
        DECLARE @s_returned_date CHAR(10);
        DECLARE @s_received_date CHAR(10);
        DECLARE @s_preauth_switch CHAR(9);
        DECLARE @s_pv_state CHAR(2);
        DECLARE @s_tax_id CHAR(9);
        DECLARE @s_addr1 CHAR(30);
        DECLARE @s_city CHAR(20);
        DECLARE @s_county CHAR(20);
        DECLARE @s_state CHAR(2);
        DECLARE @s_zip CHAR(10);
        DECLARE @s_type CHAR(2);
        DECLARE @s_spcl_type CHAR(2);
        DECLARE @s_svc_beg CHAR(10);
        DECLARE @s_d_proc_code CHAR(5);
        DECLARE @s_tooth_no CHAR(2);
        DECLARE @s_surface CHAR(5);
        DECLARE @s_quad CHAR(5);
        DECLARE @s_cob_amt CHAR(20);
        DECLARE @s_submitted_amt CHAR(20);
        DECLARE @c_prev_err CHAR(1);
        DECLARE @SWV_usp_dl_log_error INT;

        DECLARE @s_add_provider CHAR(1);
        DECLARE @s_code_type CHAR(1);
        DECLARE @s_ins_opt CHAR(4);
        DECLARE @s_relates_to CHAR(2);
        DECLARE @t_city CHAR(20);
        DECLARE @t_county CHAR(20);
        DECLARE @t_state CHAR(2);

        DECLARE @i_member_id INT;
        DECLARE @i_sub_mem_id INT;
        DECLARE @i_family_id INT;
        DECLARE @i_group_id INT;
        DECLARE @i_plan_id INT;
        DECLARE @i_rlplfc_id INT;
        DECLARE @i_mb_gr_pl_id INT;
        DECLARE @i_act_fc_id INT;
        DECLARE @i_pcp_fc_id INT;
        DECLARE @i_prv_id INT;
        DECLARE @i_cfg_bat_det_id INT;
  DECLARE @i_statistics_id INT;

        DECLARE @d_eff_date DATE;
        DECLARE @d_received_date DATE;
        DECLARE @d_returned_date DATE;
        DECLARE @d_svc_beg DATE;

        DECLARE @dc_sub_amt DECIMAL(16, 2);
        DECLARE @dc_cob_amt DECIMAL(16, 2);

        DECLARE @i_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @SWV_dl_get_sp_id INT;
        DECLARE @SWV_dl_get_sir_def_id INT;
        --DECLARE @cUtilSIR CURSOR;
		DECLARE @cUtilSIR TABLE
                                (
                                id INT IDENTITY ,
								dls_sir_id INT,    
								alt_id CHAR(20),          
								patient_id CHAR(20),     
								subscriber_id CHAR(20),
								group_id CHAR(20),     
								plan_id CHAR(20),         
								ins_type CHAR(2),       
								pcp_id CHAR(20),
								fc_id CHAR(20),         
								prv_id CHAR(20), 		
								returned_date CHAR(10),  
								received_date CHAR(10),
								preauth_switch CHAR(2),
								pv_state CHAR(2),        
								tax_id CHAR(10), 	
								addr1 CHAR(30),
								city CHAR(20),            
								county CHAR(3),        
								state CHAR(2),          
								zip CHAR(10),
								type CHAR(2),  	       
								speciality_type CHAR(2), 
								svc_beg CHAR(10),        
								d_proc_code CHAR(5),
								tooth_no CHAR(2),      
								surface CHAR(5),         
								quad CHAR(5),           
								cob_amt CHAR(20),
								submitted_amt CHAR(20)
								)

        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @v_Null INT;


-----exception handling------------------------------------------
        SET NOCOUNT ON;
        SET @i_sir_id = 0 ;
        
        SET @i_sp_id = 0;
       
        SET @i_sir_def_id = 0 ;
        
        BEGIN TRY
             

--SET DEBUG FILE TO '/tmp/dlp_bu_utilization.trc';
--TRACE ON;

            
-----Initialize stored procedure variables-----------------------------------
            SET @s_proc_name = 'bu_utilization';
            SET @s_sir_def_name = 'utilization';
            SELECT  @i_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
          
            EXECUTE @SWV_dl_get_sp_id= dbo.dl_get_sp_id @a_batch_id, @s_proc_name
                
            SET @i_sp_id = @SWV_dl_get_sp_id;
            
            IF @i_sp_id = -1
			BEGIN
				SET @i_error=0
                RAISERROR('Can not retrieve valid Store Procedure ID',16,1);
			END

            EXECUTE @SWV_dl_get_sir_def_id = dbo.dl_get_sir_def_id @s_sir_def_name
                
            SET @i_sir_def_id = @SWV_dl_get_sir_def_id ;
            
            IF @i_sir_def_id = -1
			BEGIN
				SET @i_error=5
                RAISERROR('Can not retrieve valid SIR TABLE Definition ID',16,1);
			END


-----Prepare for keeping stats on preprocessing------------------------------
          
            EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
                @i_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_text OUTPUT;
            IF @i_error_no <= 0
			BEGIN
				SET @i_error=0
                RAISERROR('(Internal) error when creating statistics',16,1);
			END


-- remove any previously logged actions from prior pre-process runs
            IF @a_sir_id > 0
	-- for when running single row at a time
                BEGIN
        IF EXISTS ( SELECT  *
                                FROM    dbo.dl_action (NOLOCK)
                         WHERE   batch_id = @a_batch_id
                                        AND process_status = 'N'
                                        AND dls_sir_id = @a_sir_id )
 DELETE  FROM dbo.dl_action
                        WHERE   batch_id = @a_batch_id
                          AND process_status = 'N'
                                AND dls_sir_id = @a_sir_id;
                END;
            ELSE
                IF EXISTS ( SELECT  *
                            FROM    dbo.dl_action (NOLOCK)
                            WHERE   batch_id = @a_batch_id
                                    AND process_status = 'N'
                                    AND dls_sir_id IN (
                                    SELECT  dls_sir_id
                                    FROM    dbo.dls_utilization (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_status = 'V' ) )
                    DELETE  FROM dbo.dl_action
                    WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_utilization (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
	



-- check if there were errors logged for prev runs
            IF EXISTS ( SELECT  *
                        FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @a_batch_id
                                AND sp_id = @i_sp_id )
                SET @c_prev_err = 'T';
            ELSE
                SET @c_prev_err = 'F';



-- get initial count of rows that have passed pre-processing --
            SELECT  @i_init_count = COUNT(*)
            FROM    dbo.dls_utilization (NOLOCK)
            WHERE   dls_batch_id = @a_batch_id
                    AND dls_status = 'P';
            SET @i_process_count = 0;
            SET @i_succ_count = 0;
       -- single row passed in

	-----exception handling w/in FOREACH---------------------------------

	/*------- catch all other errors -------*/
            SET @d_eff_date = CONVERT(DATE, GETDATE());

-----Begin processing, one row at a time-------------------------------------


		--- problems retrieving data from dB----
		

	--business rules handling
	

	--error multiple records returned from a subquery
	

		-- known multiple return error for member id
		

      ------------------------------------------------------------------------
	---------perform initial checks---------------------------------------
	INSERT INTO @cUtilSIR (
			dls_sir_id,    
			alt_id,          
			patient_id,     
			subscriber_id,
	        group_id,      
			plan_id,         
			ins_type,       
			pcp_id,
	        fc_id,         
			prv_id, 		
			returned_date,  
			received_date,
	        preauth_switch,
			pv_state,        
			tax_id, 	
			addr1,
	        city,            
			county,        
			state,          
			zip,
			type,  	       
			speciality_type, 
			svc_beg,        
			d_proc_code,
			tooth_no,      
			surface,         
			quad,           
			cob_amt,
			submitted_amt
			)
			SELECT  dls_sir_id,    
			alt_id,          
			patient_id,     
			subscriber_id,
	        group_id,      
			plan_id,         
			ins_type,       
			pcp_id,
	        fc_id,         
			prv_id, 
			--returned_date,		
			--received_date,
			CASE WHEN ISNULL(returned_date,'') = '' THEN returned_date
				 WHEN returned_date LIKE '%/%' THEN returned_date
				 ELSE STUFF(STUFF(returned_date,3,0,'/'),6,0,'/') END,  
			CASE WHEN ISNULL(received_date,'') = '' THEN received_date 
				 WHEN received_date like '%/%' THEN received_date
				 ELSE STUFF(STUFF(received_date,3,0,'/'),6,0,'/') END,
	        preauth_switch,pv_state,        
			tax_id, 	
			addr1,
	        city,            
			county,  
			state,    
			zip,
			type,  	       
			speciality_type, 
			--svc_beg,
			CASE WHEN ISNULL(svc_beg,'') = '' then svc_beg 
				 WHEN svc_beg LIKE '%/%' then svc_beg 
				 ELSE STUFF(STUFF(svc_beg,3,0,'/'),6,0,'/') 
				 END,        
			d_proc_code,
			tooth_no,      surface,         quad,           cob_amt,
		submitted_amt
	      FROM    dbo.dls_utilization (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND   dls_status   = 'V'
      AND ((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) -- allows process for
      OR   (@a_sir_id = 0 AND dls_sir_id > 0))
           /* SET @cUtilSIR = CURSOR  FOR SELECT  dls_sir_id,    alt_id,          patient_id,     subscriber_id,
	        group_id,      plan_id,         ins_type,       pcp_id,
	        fc_id,         prv_id, 		returned_date,  received_date,
	        preauth_switch,pv_state,        tax_id, 	addr1,
	        city,            county,        state,          zip,
		type,  	       speciality_type, svc_beg,        d_proc_code,
		tooth_no,      surface,         quad,           cob_amt,
		submitted_amt
	
      FROM    dbo.dls_utilization (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND   dls_status   = 'V'
      AND ((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) -- allows process for
      OR   (@a_sir_id = 0 AND dls_sir_id > 0));
            OPEN @cUtilSIR;
            FETCH NEXT FROM @cUtilSIR INTO @i_sir_id, @s_alt_id, @s_patient_id,
                @s_subscriber_id, @s_group_id, @s_plan_id, @s_ins_type,
                @s_pcp_id, @s_fc_id, @s_prv_id, @s_returned_date,
                @s_received_date, @s_preauth_switch, @s_pv_state, @s_tax_id,
                @s_addr1, @s_city, @s_county, @s_state, @s_zip, @s_type,
                @s_spcl_type, @s_svc_beg, @s_d_proc_code, @s_tooth_no,
                @s_surface, @s_quad, @s_cob_amt, @s_submitted_amt;
            WHILE @@FETCH_STATUS = 0
			*/
				 DECLARE @cur_cnt INT ,
                                @cur_i INT;

                            SET @cur_i = 1;

				--Get the no. of records for the cursor
                            SELECT  @cur_cnt = COUNT(1)
                            FROM    @cUtilSIR;

                            WHILE ( @cur_i <= @cur_cnt )
                BEGIN
				select  @i_sir_id = dls_sir_id, @s_alt_id = alt_id, @s_patient_id = patient_id,
                @s_subscriber_id = subscriber_id, @s_group_id = group_id, @s_plan_id = plan_id, @s_ins_type = ins_type,
                @s_pcp_id = pcp_id, @s_fc_id = fc_id, @s_prv_id = prv_id, @s_returned_date = returned_date,
                @s_received_date = received_date, @s_preauth_switch = preauth_switch, @s_pv_state = pv_state, @s_tax_id = tax_id,
                @s_addr1 = addr1, @s_city = city, @s_county = county, @s_state = state, @s_zip = zip, @s_type = type,
                @s_spcl_type = speciality_type, @s_svc_beg = svc_beg, @s_d_proc_code = d_proc_code, @s_tooth_no = tooth_no,
                @s_surface = surface, @s_quad = quad, @s_cob_amt = cob_amt, @s_submitted_amt = submitted_amt from @cUtilSIR where id = @cur_i
                    BEGIN
                        DECLARE @SWV_RaiseMsg VARCHAR(400);

		-- sets status to Error if condition deemed fatal --
		


		-- fatal error
		 	-- reset error no
                        BEGIN TRY
                            

	-- if this proc and batch had prev stored errors, then
	-- call sub-proc to see if it was this row, and if so,
	-- move to err history table
                            IF @c_prev_err = 'T'
                                BEGIN
                                    
                                    EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                        @i_sir_id, @i_sp_id,
                                        @i_error_no OUTPUT,
                                        @s_err_rtn_text OUTPUT;
                                END;
	

	-- initialize variables for each record check----------------
                            SET @d_svc_beg = NULL;
          SET @s_add_provider = 'F';
                            SET @i_error = 0;
  SET @i_rlplfc_id = NULL;
                            SET @i_mb_gr_pl_id = NULL;
                            SET @i_act_fc_id = NULL;
                            SET @i_prv_id = NULL;
                            SET @s_relates_to = NULL;
                  SET @s_code_type = NULL;
                            SET @dc_cob_amt = NULL;
                            SET @dc_sub_amt = NULL;
                            SET @i_process_count = @i_process_count + 1;

      --alt_id required, must be unique----------------------------------------
                            IF ( ( @s_alt_id IS NULL
                                   OR @s_alt_id = ''
                                 )
                                 OR LEN(@s_alt_id) = 0
                               )
							   BEGIN
							   SET @i_error=20
                                RAISERROR('Missing Alt ID',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
							END
                            ELSE
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.claim_h (NOLOCK)
                                            WHERE   alt_id = @s_alt_id )
										BEGIN
										SET @i_error=30
                                    RAISERROR('Duplicate Alt ID found in target database',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END
		
	

	--patient_id required
                            IF ( ( @s_patient_id IS NULL
                                   OR @s_patient_id = ''
                                 )
                                 OR LEN(@s_patient_id) = 0
                               )
							   BEGIN
							   SET @i_error=40
                                RAISERROR('Missing Patient ID',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
							END
                            ELSE
                                BEGIN
                                    SET @i_error = 50; 	--  non numeric Patient ID
                                    SET @i_member_id = @s_patient_id;

									SELECT  @i_member_id = member_id ,
                                            @i_family_id = family_id
                                    FROM    dbo.member (NOLOCK)
                                    WHERE   member_id = @s_patient_id;
									
									IF	@@ROWCOUNT = 0								
									SELECT @i_member_id = NULL,
										@i_family_id = NULL

                                    SET @i_error = 0; 	-- reset error no
																	

                                    IF (@i_member_id IS NULL
                                        OR @i_family_id IS NULL)
										BEGIN
										SET @i_error=60
                                        RAISERROR('Patient ID not found in member table',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
                                END;
	

	--subscriber_id
                            IF ( ( @s_subscriber_id IS NULL
                      OR @s_subscriber_id = ''
                                 )
                                 OR LEN(@s_subscriber_id) = 0
                          )
						  BEGIN
							SET @i_error=70
                                RAISERROR('Subscriber ID is missing from client file',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
							END
                            ELSE
                                BEGIN
                                    SET @i_error = 55; 	-- non numeric subscriber id
                                    SET @i_sub_mem_id = @s_subscriber_id;
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.member (NOLOCK)
                                                    WHERE   family_id = @s_subscriber_id
                                                            AND member_id = family_id )
										BEGIN
										SET @i_error=80
                                        RAISERROR('Invalid Subscriber ID ',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
                                    ELSE
                                        BEGIN
      SELECT  @i_sub_mem_id = member_id
                   FROM    dbo.member (NOLOCK)
                                            WHERE   family_id = @s_subscriber_id
                                                    AND member_id = family_id;
                                           
			-- ensure subscriber id matches family id for patient
     IF ( @i_sub_mem_id != @i_family_id )
											BEGIN
												SET @i_error=82
                                               RAISERROR('Subscriber ID not valid for member id',0,1);
											   EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
                                        END;
                                END;
   	

	--group_id
        IF ( ( @s_group_id IS NULL
                  OR @s_group_id = ''
                                 )
                                 OR LEN(@s_group_id) = 0
                               )
							   BEGIN
							   SET @i_error=90
                                RAISERROR('Missing Group ID',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END
                            ELSE
                                BEGIN
                  SET @i_error = 100;	--Non Numeric group ID
                               SET @i_group_id = @s_group_id;
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.[group] (NOLOCK)
                         WHERE   group_id = @s_group_id )
                                        BEGIN
                                            SET @i_error = 0;	--reset error
											SET @i_error=110
                                            RAISERROR('Group ID is invalid ',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
                                        END;
                                END;
	

	--type (claim type)
                            IF ( @s_type IS NOT NULL
                                 AND @s_type <> ''
                               )
                                AND LEN(@s_type) > 0
                                IF NOT EXISTS ( SELECT  *
                                                FROM    dbo.typ_table (NOLOCK)
                                                WHERE   subsys_code = 'CL'
                                                        AND tab_name = 'spcl_type'
                                                        AND code = @s_type )
														BEGIN
														SET @i_error=450
                                    RAISERROR('Invalid Type ',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
		
									END

	--svc_beg
                            IF ( @s_svc_beg IS NULL
                                 OR @s_svc_beg = ''
                               )
                                OR LEN(@s_svc_beg) = 0
                                BEGIN
                                    IF @s_preauth_switch = 'N'
									BEGIN
										SET @i_error=520
                                        RAISERROR('Service begin date is required if preauth switch is N',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
		
                                    SET @d_svc_beg = CONVERT(DATE, GETDATE());
                                END;
                            ELSE
       BEGIN
                                    SET @i_error = 530;
                                    IF SUBSTRING(@s_svc_beg, 3, 1) = '/'
                                        SET @d_svc_beg = CONVERT(DATETIME2(0), CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                                                              1, 2)) + '-'
                                            + CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                                                              4, 2)) + '-'
                                            + CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                                                              7, 4)));
                                    ELSE
                                        IF SUBSTRING(@s_svc_beg, 5, 1) = '-'
          SET @d_svc_beg = CONVERT(DATETIME2(0), CONVERT(CHAR, SUBSTRING(@s_svc_beg,
  6, 2)) + '-'
   + CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                                                              9, 2)) + '-'
         + CONVERT(CHAR, SUBSTRING(@s_svc_beg,
        1, 4)));
                                        ELSE
                                            SET @d_svc_beg = CONVERT(DATETIME2(0), CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                                                              1, 2)) + '-'
                                                + CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                                                              3, 2)) + '-'
              + CONVERT(CHAR, SUBSTRING(@s_svc_beg,
                            5, 4)));
		
                                    SET @i_error = 0;
                                END;
	

	--get plan_id
                            SET @i_plan_id = NULL;
                            IF ( @s_plan_id IS NULL
                                 OR @s_plan_id = ''
                               )
                                OR LEN(@s_plan_id) = 0

	  -- Given subscriber_id, group_id, ins_type and type, find plan_id
	  -- A member can have more than one plan id within the same group
	  -- If multiple plan records then give the user option to enter plan_id
                                BEGIN
                                    EXECUTE dbo.dlp_ut_get_plan_id @i_family_id,
                                        @i_group_id, @s_ins_type, @s_type,
                                        @d_svc_beg, @i_plan_error OUTPUT,
                                        @i_plan_id OUTPUT;
                                    IF @i_plan_error = -1
									BEGIN
									set @i_error = @i_plan_id 
                                        RAISERROR('Error',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
                                END;
                            ELSE
                                BEGIN
                                    SET @i_error = 160;      -- Multiple Plan records
		/* 20140202$$ks - eClaim puts plan_id in plan_id field, dlp_ld_ut puts display_name
		 */
                                    SELECT  @config_cnt = COUNT(*)
                                    FROM    dbo.dl_config (NOLOCK)
                                    WHERE   config_id = @i_config_id
                                            AND UPPER(config_name) LIKE 'ECLAIM%';

                                    IF @config_cnt > 0
                                        BEGIN
                                            SELECT  @i_plan_id = plan_id
                                            FROM    dbo.[plan] (NOLOCK)
                                            WHERE   plan_id = @s_plan_id;
                                           
                                        END;
										ELSE
                                        BEGIN
                                            SELECT  @i_plan_id = plan_id
                                            FROM    dbo.[plan] (NOLOCK)
                                            WHERE   plan_dsp_name = @s_plan_id;
                                          
                                        END;
		
                                    SET @i_error = 0;	-- reset errror no

                                    IF @i_plan_id IS NULL
                                        BEGIN
                                            EXECUTE dbo.dlp_ut_get_plan_id @i_family_id,
                                                @i_group_id, @s_ins_type,
												  @s_type, @d_svc_beg,
													  @i_plan_error OUTPUT,
												 @i_plan_id OUTPUT;
											IF @i_plan_error = -1
											BEGIN
											 SET @i_error = @i_plan_id
                                                RAISERROR('Error',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
                            END;
                         END;
	

	-- get mbgrpl_id
		

                            SELECT  @i_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl (NOLOCK)
                            WHERE   plan_id = @i_plan_id
                                    AND member_id = @i_family_id
                   AND group_id = @i_group_id
                           AND eff_gr_pl <= @d_svc_beg
                                    AND ( exp_gr_pl > @d_svc_beg
                                          OR exp_gr_pl IS NULL
                                        );
                            
                            IF @i_mb_gr_pl_id IS NULL
							BEGIN
							SET @i_error=235
							RAISERROR('Can not retrieve mbgrpl id using plan, member & group ids',                  0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
						END
	

	-- get ins opt	
	
                            SET @s_ins_opt = NULL;
                            SELECT  @s_ins_opt = ins_opt
                            FROM    dbo.[plan] (NOLOCK)
                            WHERE   plan_id = @i_plan_id;
                         
                            IF ( @s_ins_opt IS NULL
                                 OR @s_ins_opt = ''
                               )
                                OR LEN(@s_ins_opt) = 0
								BEGIN
								SET @i_error=190
                                RAISERROR('Can not retrieve insurance option from plan using plan id',                  0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END
	

	-- type and speciality type ----------------------------------------
                            IF @s_ins_opt = 'FFS'
                                BEGIN
                                    IF ( @s_type IS NOT NULL
                                         AND @s_type <> ''
                                       )
                                        AND LEN(@s_type) > 0
										BEGIN
										SET @i_error=460
                                        RAISERROR('Type should be blank for a FFS plan',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
		
                                    IF ( @s_spcl_type IS NOT NULL
              AND @s_spcl_type <> ''
                                       )
                           AND LEN(@s_spcl_type) > 0
										BEGIN
										SET @i_error=480
--RAISERROR('Speciality Type should be blank for a FFS plan',16,1);
										EXECUTE @i_fatal = usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @i_sir_id,@i_error; --CH001
										IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
                                END;
                            ELSE
                                IF ( @s_spcl_type IS NOT NULL
                                     AND @s_spcl_type <> ''
                                   )
                                    AND LEN(@s_spcl_type) > 0
                                    IF @s_type NOT IN ( 'SR', 'SC', 'ER', 'ON',
                                                        'EC', 'UT' )
														BEGIN
														SET @i_error=510
														EXECUTE @SWV_usp_dl_log_error = usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @i_sir_id,@i_error; --CH001
                                        --RAISERROR('Should not be a Speciality Type for this type of claim',16,                     1);
										END
                                    ELSE
                                        IF @s_spcl_type NOT IN (
                                            SELECT  code
                                            FROM    dbo.typ_table (NOLOCK)
                                            WHERE   subsys_code LIKE 'CL'
                                                    AND tab_name LIKE 'specialist' )
													BEGIN
													SET @i_error=500
                                            RAISERROR('Invalid Speciality Type ',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
		      
		   
		 -- spcl type not null
	   -- ins opt is HMO

	--pcp_id
                            SET @i_pcp_fc_id = NULL;
							
                            IF ( @s_pcp_id IS NOT NULL
                                 AND @s_pcp_id <> ''
                               )
							AND LEN(@s_pcp_id) > 0
                                BEGIN
              SET @i_error = 200;	-- non numeric PCP id
                                    SET @i_pcp_fc_id = @s_pcp_id;
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.facility (NOLOCK)
                                                    WHERE   fc_id = @s_pcp_id )
                                        BEGIN
                                            SET @i_error = 0;
											SET @i_error = 210;
                                            RAISERROR('Unknown PCP Facility ID',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
                                        END;
		
                                    IF @s_ins_opt = 'FFS'
									BEGIN
									SET @i_error = 880;
                                        RAISERROR('PCP Facility ID should be blank for FFS plan',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
                                END;
	

	--actual facitlity id
                            IF ( @s_fc_id IS NOT NULL
                                 AND @s_fc_id <> ''
                               )
                          AND LEN(@s_fc_id) <> 0
                                BEGIN
           SET @i_error = 250;	-- non numeric fc id
                                    SET @i_act_fc_id = @s_fc_id;
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.facility (NOLOCK)
                                                    WHERE   fc_id = @i_act_fc_id )
                                        BEGIN
                                            SET @i_error = 0;
											SET @i_error = 220;
                                            RAISERROR('Unknown Facility ID where services performed',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    IF @s_ins_opt = 'HMO'
                                        AND @s_type = 'UT'
										BEGIN
										SET @i_error = 800;
                                        RAISERROR('Facility ID where services performed is required',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
		
                                    IF @s_ins_opt = 'FFS'
                                        AND ( ( @s_prv_id IS NULL
                                                OR @s_prv_id = ''
                                              )
                                              OR LEN(@s_prv_id) = 0
                                            )
                                        AND ( ( @s_tax_id IS NULL
                                                OR @s_tax_id = ''
                                              )
                                              OR LEN(@s_tax_id) = 0
                                            )
											BEGIN
											SET @i_error = 810;
                                        RAISERROR('Facility or Provider ID is required.',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
                                END;
	

	-- retrieve the rlplfc id
	  -- must be an HMO or other, not FFS

                            IF @i_pcp_fc_id IS NOT NULL
                                BEGIN
                                    SELECT  @i_rlplfc_id = rlplfc_id
                                    FROM    dbo.rlplfc (NOLOCK)
                                    WHERE   facility_id = @i_pcp_fc_id
       AND member_id = @i_member_id
                        AND mb_gr_pl_id = @i_mb_gr_pl_id
  AND eff_date <= @d_svc_beg
                     AND ( exp_date > @d_svc_beg
OR exp_date IS NULL
                                                );
                                   
                                    IF @i_rlplfc_id IS NULL
									BEGIN
										SET @i_error = 240;
                                        RAISERROR('Can not retrieve rlplfc id using fac, member & mbgrpl ids',                     0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
                                END;
                            ELSE
                                IF @s_ins_opt NOT LIKE 'FFS'
                         BEGIN
                                        SELECT  @i_rlplfc_id = rlplfc_id
                                        FROM    dbo.rlplfc (NOLOCK)
                                        WHERE   facility_id > 0
                                                AND member_id = @i_member_id
                                                AND mb_gr_pl_id = @i_mb_gr_pl_id
                                                AND eff_date <= @d_svc_beg
                                                AND ( exp_date > @d_svc_beg
                                                      OR exp_date IS NULL
                                                    );
                                      
                                        IF @i_rlplfc_id IS NULL
										BEGIN
										SET @i_error = 260;
                                            RAISERROR('Can not retrieve rlplfc id for a non FFS plan',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
                                    END;
       ELSE                   -- the fc id is NULL in rlplfc for FFS plans
                                    BEGIN
                    SELECT  @i_rlplfc_id = rlplfc_id
                                        FROM    dbo.rlplfc (NOLOCK)
                                        WHERE   facility_id IS NULL
                                                AND member_id = @i_member_id
                                                AND mb_gr_pl_id = @i_mb_gr_pl_id
                                                AND eff_date <= @d_svc_beg
                                                AND ( exp_date > @d_svc_beg
                                                      OR exp_date IS NULL
                                                    );
                                       
                                        IF @i_rlplfc_id IS NULL
										BEGIN
										SET @i_error = 270;
                                            RAISERROR('Can not retrieve rlplfc id for an FFS plan',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
                                    END;
	

	-- get prv id,  add new provider action if necessary
   IF ( @s_prv_id IS NULL
                                 OR @s_prv_id = ''
                  )
       OR LEN(@s_prv_id) = 0
                                IF ( (@s_tax_id IS NULL
                    OR @s_tax_id = '')
                                   )
                                    OR ( LEN(@s_tax_id) != 9 )
                                    BEGIN
                                        IF @s_ins_opt = 'HMO'
                                            AND @s_type IN ( 'SR', 'SC', 'ER',
                                                             'ON', 'EC' )
															BEGIN
															SET @i_error = 230;
                                            RAISERROR('Missing Provider ID and missing/invalid Tax ID',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
			
                                        IF @s_ins_opt = 'FFS'
                                            AND ( ( @s_fc_id IS NULL
                                                    OR @s_fc_id = ''
                                                  )
                                                  OR LEN(@s_fc_id) = 0
                              )
												BEGIN
												SET @i_error = 810;
                                            RAISERROR('Provider or Facility ID is required',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
                                    END;
                                ELSE
			-- check if tax id exists in providers table
                     BEGIN
                                        SELECT  @i_prv_id = pv_id
                                   FROM    dbo.providers (NOLOCK)
                                        WHERE   tax_id = @s_tax_id;
                                       
                                        IF @i_prv_id IS NULL
                                            SET @s_add_provider = 'T';
                                    END;
		
                            ELSE
                                BEGIN
                               SET @i_error = 890;  --non numeric provider id
                                    SET @i_prv_id = @s_prv_id;
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.providers (NOLOCK)
                                                    WHERE   pv_id = @s_prv_id )
			--LET s_add_provider = "T";
								BEGIN
								SET @i_error = 830;
                                        RAISERROR('Invalid Provider Id',0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END
                                END;
	

	-- was not an existing provider, must log action to add provider
                            IF @s_add_provider = 'T'
               BEGIN
                                    IF ( (@s_tax_id IS NULL
                                         OR @s_tax_id = '')
                                    )
                                        OR ( LEN(@s_tax_id) != 9 )
										BEGIN
										SET @i_error = 239;
                    RAISERROR('Adding provider to target db, provider''s tax id is required',                     0,1);
										EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
				

		-- verify address, city, state, and zip are valid
                                    EXECUTE dbo.dlp_ut_ck_addr @a_batch_id,
                                        @s_addr1, @s_city, @s_county, @s_state,
                                        @s_zip, @i_sir_id,@i_addr_error OUTPUT,
                                        @t_city OUTPUT, @t_county OUTPUT,
                                        @t_state OUTPUT;

		-- if 1, correct any city or state values
		  -- fatal error in supt proc
                                    IF @i_addr_error = 1
                                        BEGIN
                                            SET @s_city = @t_city;
                                            SET @s_state = @t_state;
                                            SET @s_county = @t_county;
                                        END;
                                    ELSE
                                        IF @i_addr_error = -1
                                            BEGIN
                                                 
                                                GOTO SWL_Label2;
                                            END;
                                        ELSE   
										BEGIN                     -- unkown db error in supt proc
										SET @i_error = @i_plan_id
                                            RAISERROR('Error',16,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
											
		

		-- LOG AN ACTION  TO ADD A PROVIDER
                                EXECUTE @i_error_no = dbo.dl_log_action @a_batch_id,
                                        @i_sir_id, 'PA', @d_eff_date;
                                END;
	

	-- returned_date
                            IF ( @s_returned_date IS NOT NULL
                                 AND @s_returned_date <> ''
                               )
                                AND LEN(@s_returned_date) > 0
                                BEGIN
                                    SET @i_error = 360;
                              SET @d_returned_date = CAST( @s_returned_date AS DATE);
                                    SET @i_error = 0;
                         END;
	

	-- received_date
                            IF ( @s_received_date IS NULL
                                 OR @s_received_date = ''
                               )
                              OR LEN(@s_received_date) < 1
								BEGIN
								SET @i_error = 350;
                                RAISERROR('Received date is required, default is afterload param value',                  0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END
                            ELSE
                    BEGIN
     SET @i_error = 370;
 SET @d_received_date = CAST (@s_received_date AS DATE);
                                    SET @i_error = 0;
                END;
	

	--pv_state
          IF ( @s_pv_state IS NOT NULL
                                 AND @s_pv_state <> ''
                               )
                                AND LEN(@s_pv_state) > 0
                                IF NOT EXISTS ( SELECT  *
                                                FROM    dbo.state (NOLOCK)
                                                WHERE   code = @s_pv_state )
												BEGIN
												SET @i_error = 440;
                                    RAISERROR('Invalid Provider Stat ',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
		
	

	--d_proc_code
                            IF ( @s_d_proc_code IS NULL
                                 OR @s_d_proc_code = ''
                               )
                                OR LEN(@s_d_proc_code) = 0
								BEGIN
								SET @i_error = 540;
                                RAISERROR('Dental Procedure Code is required',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END
                            ELSE
                                IF NOT EXISTS ( SELECT  *
                                                FROM    dbo.plx_dent_proc (NOLOCK)
                                                WHERE   d_proc_code = @s_d_proc_code )
											BEGIN
											SET @i_error = 550;
                                    RAISERROR('Invalid Dental Procedure Code',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
									END
                                ELSE
                                    BEGIN
                    SELECT  @s_relates_to = relates_to ,
                                                @s_code_type = code_type
                                        FROM    dbo.plx_dent_proc (NOLOCK)
                                        WHERE   d_proc_code = @s_d_proc_code;
                                     
                                        IF @s_ins_type <> @s_code_type
                                            BEGIN
												SET @i_error = 555;
                                                SET @SWV_RaiseMsg = 'Insurance Type and Dental ProcedureCode '
                                                    + 'Type do not match ';
                                                RAISERROR(@SWV_RaiseMsg,0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
                                            END;
			
                                        IF @s_relates_to NOT IN ( 'P', 'Q',
                              'T', 'S' )
                                            BEGIN
												SET @i_error = 560;
    SET @SWV_RaiseMsg = 'Can not retrieve relates to value from tgt dB '
                                                    + 'using D Proc Code';
                                                RAISERROR(@SWV_RaiseMsg,0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
                                            END;
                                    END;
		
	



	-- tooth_no, quad, surface
                            IF @s_ins_type = @s_code_type
                                IF @s_relates_to = 'P'
                                    BEGIN
                                        IF ( ( ( @s_tooth_no IS NOT NULL
                                                 AND @s_tooth_no <> ''
         )
                                               AND LEN(@s_tooth_no) > 0
                                             )
                                             OR ( ( @s_surface IS NOT NULL
              AND @s_surface <> ''
                                                  )
                                                  AND LEN(@s_surface) > 0
                                                )
                                             OR ( ( @s_quad IS NOT NULL
                                                    AND @s_quad <> ''
                                                  )
                                                  AND LEN(@s_quad) > 0
                                                )
                                           )
										   BEGIN
										   SET @i_error = 570;
                                            RAISERROR('Tooth No, Surface and Quadrant should be blank',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
										END
                                    END;
                                ELSE
                                IF @s_relates_to = 'Q'
                                        BEGIN
                                            IF ( @s_quad IS NULL
                                                 OR @s_quad = ''
                                               )
                                                OR LEN(@s_quad) = 0
												BEGIN
												SET @i_error = 580;
                                                RAISERROR('Quadrant is required',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
												END
                                            ELSE
                                                IF @s_quad NOT IN (
                                                    SELECT  code
                                                    FROM  dbo.typ_table (NOLOCK)
                                                    WHERE   subsys_code LIKE 'CL'
AND tab_name LIKE 'quad' )
															BEGIN
															SET @i_error = 592;
                  RAISERROR('Invalid Quad',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
													END
				
			
                                            IF ( ( ( @s_tooth_no IS NOT NULL
                                                     AND @s_tooth_no <> ''
                                                   )
                                                   AND LEN(@s_tooth_no) > 0
                                                 )
                                                 OR ( ( @s_surface IS NOT NULL
                                                        AND @s_surface <> ''
                                                      )
                                                      AND LEN(@s_surface) > 0
                                                    )
                                               )
											   BEGIN
											   SET @i_error = 572;
                                                RAISERROR('Tooth No and Surface should be blank',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
											END
                                        END;
                                    ELSE
                                        IF @s_relates_to = 'T'
                                            BEGIN
                                                IF ( @s_tooth_no IS NULL
                                                     OR @s_tooth_no = ''
                                                   )
                                                    OR LEN(@s_tooth_no) = 0
													BEGIN
													SET @i_error = 598;
                                                    RAISERROR('Tooth No. is required',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
													END
                                                ELSE
                                                    IF @s_tooth_no NOT IN (
                                                        SELECT
														code
                                                        FROM  dbo.typ_table (NOLOCK)
                                                        WHERE subsys_code LIKE 'CL'
                                           AND tab_name LIKE 'tooth' )
															  BEGIN
															  SET @i_error = 590;
                                                        RAISERROR('Invalid Tooth No.',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
														END
			
                  IF ( ( ( @s_surface IS NOT NULL
                   AND @s_surface <> ''
                                                       )
                                                       AND LEN(@s_surface) > 0
                                                     )
                                                     OR ( ( @s_quad IS NOT NULL
   AND @s_quad <> ''
                                                          )
                                                          AND LEN(@s_quad) > 0
                                                        )
                                                   )
												   BEGIN
												   SET @i_error = 574;
                                                    RAISERROR('Surface and Quadrant should be blank',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
												END
                                            END;
                                        ELSE
                                           IF @s_relates_to = 'S'
                                                BEGIN
                                                    IF ( ( ( @s_tooth_no IS NULL
                                                             OR @s_tooth_no = ''
                                                           )
                                                           OR LEN(@s_tooth_no) = 0
                                                         )
                                                         OR ( ( @s_surface IS NULL
                                                              OR @s_surface = ''
                                                              )
                                                              OR LEN(@s_surface) = 0
                                                            )
                                                       )
													   BEGIN
													   SET @i_error = 599;
                                                        RAISERROR('Tooth No. and Surface are required',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
													END
                                                    ELSE
                                      BEGIN
                                                            IF @s_tooth_no NOT IN (
                                   SELECT
                                                              code
                                                              FROM
                                                              dbo.typ_table (NOLOCK)
                                                              WHERE
                                                              subsys_code LIKE 'CL'
                                                              AND tab_name LIKE 'tooth' )
															  BEGIN
															  SET @i_error = 590;
                                                              RAISERROR('Invalid Tooth No.',0,1);
															  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
															  END
				

				-- verifies valid surface types, --
				-- non-repeating, alpha order    --
                                                            EXECUTE dbo.dlp_ut_ver_surface @a_batch_id,
                                                              @s_surface,
                            @i_error OUTPUT,
  @s_surface OUTPUT;

				-- error occurred in sub-proc, work rolled back
     IF @i_error = -1
                                                              GOTO SWL_Label2;
                                                        END;
			
                                                    IF ( ( @s_quad IS NOT NULL
                                              AND @s_quad <> ''
            )
                                                         AND LEN(@s_quad) > 0
                                                       )
													   BEGIN
													   SET @i_error = 576;
                                                        RAISERROR('Quadrant should be blank',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
														END
                                                END;
	 -- code_type = ins_type


	--cob_amt
                            SET @i_error = 710; -- invalid cob amount -- warning
                            SET @dc_cob_amt = @s_cob_amt;
                            SET @i_error = 0;
                            IF ( @dc_cob_amt IS NOT NULL )
                                AND ( @dc_cob_amt < 0.00 )
								BEGIN
								SET @i_error = 700;
                                RAISERROR('COB amount cannot be less than 0.00 ',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
								END

	--submitted_amt
                            SET @i_error = 720;  -- invalid submitted amount
                            SET @dc_sub_amt = @s_submitted_amt;
                            SET @i_error = 0;
	
	---	RAISE EXCEPTION -746, 730, "Submitted amount is 0.00";
                            IF ( @dc_sub_amt = 0.00 )
                                BEGIN
                                    SET @v_Null = 0;
                                END;
                            ELSE
               IF ( @dc_sub_amt < 0.00 )
			   BEGIN
			   SET @i_error = 740;
                   RAISERROR('Submitted amount must be greater than 0.00 ',0,1);
				   EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error;

									-- sets status to Error if condition deemed fatal --
									IF @i_fatal <> 1 
									BEGIN
										UPDATE dls_utilization
										SET   dls_status = 'E'
										WHERE dls_sir_id = @i_sir_id

										goto SWL_Label2
									END ;
				END


	/* update dls_status */
                            UPDATE  dbo.dls_utilization
                            SET     dls_status = 'P' ,
  dls_rlplfc_id = @i_rlplfc_id ,
                                    dls_mb_gr_pl_id = @i_mb_gr_pl_id ,
        dls_fc_id = @i_act_fc_id ,
     dls_prv_id = @i_prv_id ,
                          dls_relates_to = @s_relates_to ,
                                    city = @s_city ,
                                    state = @s_state ,
        county = @s_county ,
                                    surface = @s_surface
                            --WHERE CURRENT OF @cUtilSIR;
							WHERE dls_sir_id = @i_sir_id 

                            SET @i_succ_count = @i_succ_count + 1;

	/* update stats every 100 rows evaluated */
                            IF @i_process_count % 100 = 0

	   -----update the stats----------
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @i_process_count ,
                                        tot_success_rec = @i_succ_count ,
                                        tot_fail_rec = ( @i_process_count
                                                         - @i_succ_count )
                                WHERE   bat_statistics_id = @i_statistics_id;
      
                             
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_text = ERROR_MESSAGE();
                            IF @i_error_no IN ( -244, -245, -246 )
                                BEGIN
                            
                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @i_sir_id, 1000;
                                    
                                    GOTO SWL_Label2;
                                END;

		-- known error conditions, including any conversion errors
                            ELSE
			-- fatal error
                                BEGIN
                                   
                                    EXECUTE @SWV_usp_dl_log_error = usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @i_sir_id,@i_error; --CH001

   IF @SWV_usp_dl_log_error != 1
                                        BEGIN
                                            UPDATE  dbo.dls_utilization
                                            SET     dls_status = 'E'
                                           --WHERE CURRENT OF @cUtilSIR;
                                             WHERE dls_sir_id = @i_sir_id;
                                            SET @i_error = 0; 	-- reset error no
										GOTO SWL_Label2;
                                        END;
										ELSE
										  UPDATE  dbo.dls_utilization
                            SET     dls_status = 'P' ,
                                    dls_rlplfc_id = @i_rlplfc_id ,
                                    dls_mb_gr_pl_id = @i_mb_gr_pl_id ,
                                    dls_fc_id = @i_act_fc_id ,
                                    dls_prv_id = @i_prv_id ,
                                    dls_relates_to = @s_relates_to ,
                                    city = @s_city ,
                                    state = @s_state ,
                                    county = @s_county ,
                                    surface = @s_surface
                            --WHERE CURRENT OF @cUtilSIR;
							WHERE dls_sir_id = @i_sir_id 

                            SET @i_succ_count = @i_succ_count + 1;							

                                END;
                        END CATCH;
                    END;
                    SWL_Label2:
                    /* FETCH NEXT FROM @cUtilSIR INTO @i_sir_id, @s_alt_id,
           @s_patient_id, @s_subscriber_id, @s_group_id,
                        @s_plan_id, @s_ins_type, @s_pcp_id, @s_fc_id,
                        @s_prv_id, @s_returned_date, @s_received_date,
                        @s_preauth_switch, @s_pv_state, @s_tax_id, @s_addr1,
                        @s_city, @s_county, @s_state, @s_zip, @s_type,
                        @s_spcl_type, @s_svc_beg, @s_d_proc_code, @s_tooth_no,
                 @s_surface, @s_quad, @s_cob_amt, @s_submitted_amt; 
						*/
						set @cur_i = @cur_i + 1
                END;
            --CLOSE @cUtilSIR;

---------------perform final err count, update stats-----------------------
            SELECT  @i_succ_count = COUNT(*)
            FROM    dbo.dls_utilization (NOLOCK)
            WHERE   dls_batch_id = @a_batch_id
AND dls_status = 'P';
            SET @i_succ_count = @i_succ_count - @i_init_count;
            SET @i_error_count = @i_process_count - @i_succ_count;

/* update statistics */
            EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
                @i_succ_count, @i_error_count;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
                                                 ' Failed to update statistics');
                    RETURN;
                END;

            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

--TRACE OFF;

            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
                                         ' records are processed for Batch ',
                                         @a_batch_id);
            RETURN;
        END TRY
     BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_text);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;



-----------------------------------------------------------------

    END;