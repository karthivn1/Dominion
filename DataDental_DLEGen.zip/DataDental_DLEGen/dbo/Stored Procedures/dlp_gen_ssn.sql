﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_gen_ssn]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value CHAR(11) = NULL OUTPUT
    
	

/*	dlp_gen_ssn() 
	Return:			11 character SSN in the format of "A99-99-9999"
					Null if any error.
	Parameter:
		a_alt_id		Member alt_id.
					Must be unique within a group if a non-zero group_id is passed. 
					Or msut be nique within DataDental if a zero or null group_id is passed.

		a_group_id	group_id.
					If null, 0 is used.  User must garantees that its uniqueness within
					DataDental.
*/
AS
    BEGIN
        DECLARE @n_ssn CHAR(9);
        DECLARE @n_sub_ssn CHAR(9);
        DECLARE @n_tmp_alt_id CHAR(20);
        DECLARE @prefix CHAR(1);
        DECLARE @n_group_id INT;

        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_text CHAR(64);

        DECLARE @n_count INT;
        DECLARE @n_max_count INT;
        DECLARE @SWV_ForCnt INT;

        SET NOCOUNT ON;
        BEGIN TRY
            
            SET @i_error_no = -1;
            SET @n_count = 0;
            SET @n_max_count = 10;
            WHILE ( @i_error_no < 0 )
                BEGIN
                    BEGIN TRY
                        SET @n_count = @n_count + 1;
                        IF @n_count > @n_max_count
                            BEGIN
                                SET @SWP_Ret_Value = NULL;
                                RETURN;
                            END;
	
 
 -- need to lock dls_ssn prior to incrementing/updating 
 -- otherwise we can get duplicate ssns

                        UPDATE  dbo.dls_ssn
                        SET     ssn = ssn
                        WHERE   1 = 1;
                        SELECT  @n_ssn = MAX(ssn)
                        FROM    dbo.dls_ssn (NOLOCK);
                        
                        IF ( @n_ssn IS NULL
                             OR @n_ssn = ''
                           )
                            OR SUBSTRING(@n_ssn, 1, 1) = '7'
                            SET @n_ssn = 'A00000001';
                        ELSE
                            BEGIN
                                SET @n_sub_ssn = '1' + SUBSTRING(@n_ssn, 2, 8);
                                SET @n_sub_ssn = @n_sub_ssn + 1;
                                IF SUBSTRING(@n_sub_ssn, 2, 8) = '00000000'
                                    BEGIN
                                        SET @SWV_ForCnt = 1;
                                        WHILE @SWV_ForCnt <= 26
                                            BEGIN
                                                IF @SWV_ForCnt = 1
                                                    SET @prefix = 'A';
                                                IF @SWV_ForCnt = 2
                                                    SET @prefix = 'B';
                                                IF @SWV_ForCnt = 3
                                                    SET @prefix = 'C';
                                                IF @SWV_ForCnt = 4
                                                    SET @prefix = 'D';
                                                IF @SWV_ForCnt = 5
                                                    SET @prefix = 'E';
                                                IF @SWV_ForCnt = 6
                                                    SET @prefix = 'F';
                                                IF @SWV_ForCnt = 7
                           SET @prefix = 'G';
                                                IF @SWV_ForCnt = 8
                                                    SET @prefix = 'H';
                                                IF @SWV_ForCnt = 9
                                                    SET @prefix = 'I';
                                                IF @SWV_ForCnt = 10
                                                    SET @prefix = 'J';
                                                IF @SWV_ForCnt = 11
                                                    SET @prefix = 'K';
                                                IF @SWV_ForCnt = 12
                                                    SET @prefix = 'L';
                                                IF @SWV_ForCnt = 13
                                                    SET @prefix = 'M';
                                                IF @SWV_ForCnt = 14
                                                    SET @prefix = 'N';
                                                IF @SWV_ForCnt = 15
                                                    SET @prefix = 'O';
                                                IF @SWV_ForCnt = 16
                                                    SET @prefix = 'P';
                                                IF @SWV_ForCnt = 17
                                                    SET @prefix = 'Q';
                                                IF @SWV_ForCnt = 18
                                                    SET @prefix = 'R';
                                                IF @SWV_ForCnt = 19
                                                    SET @prefix = 'S';
                                                IF @SWV_ForCnt = 20
                                                    SET @prefix = 'T';
                                                IF @SWV_ForCnt = 21
                                                    SET @prefix = 'U';
                                                IF @SWV_ForCnt = 22
                                                    SET @prefix = 'V';
                                                IF @SWV_ForCnt = 23
                                                    SET @prefix = 'W';
                                                IF @SWV_ForCnt = 24
                                                    SET @prefix = 'X';
                                                IF @SWV_ForCnt = 25
                                                    SET @prefix = 'Y';
                                                IF @SWV_ForCnt = 26
                                                    SET @prefix = 'Z';
                                                IF @prefix > SUBSTRING(@n_ssn,
                                                              1, 1)
                                                    GOTO SWL_Label2;
                                                SET @SWV_ForCnt = @SWV_ForCnt
                                                    + 1;
                                            END;
                                        SWL_Label2:
                                        SET @n_ssn = @prefix + '00000001';
                                    END;
                                ELSE
                                    SET @n_ssn = STUFF(@n_ssn, 2, 8,
                                                       SUBSTRING(@n_sub_ssn, 2,
                                                              8));
                            END;
	
                        UPDATE  dbo.dls_ssn
                        SET     ssn = @n_ssn ,
                                created_by = @a_batch_id ,
                                created_time = @a_start_time
                        WHERE   1 = 1;
                        SET @i_error_no = 1;
                    END TRY
                    BEGIN CATCH
                        SET @i_error_no = ERROR_NUMBER();
                        SET @i_isam_error = ERROR_LINE();
                        SET @s_error_text = ERROR_MESSAGE();
                        IF @i_error_no != -239
                            RAISERROR('Database Error',16,1);
                    END CATCH;
                END;
            SET @SWP_Ret_Value = SUBSTRING(@n_ssn, 1, 3) + '-'
                + SUBSTRING(@n_ssn, 4, 2) + '-' + SUBSTRING(@n_ssn, 6, 4);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

--trace off;


--set debug file to "/tmp/dlp_gen_ssn.trc";
--trace on;

    END;