﻿CREATE PROCEDURE [dbo].[dlp_rein_sg_group]
    @ad_action_date DATE ,
    @ai_group_id INT ,
    @as_h_user CHAR(15) ,
    @ad_h_datetime DATETIME ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 11:59:59 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1



000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;   
        DECLARE @i_isam_error INT;  
        DECLARE @s_error_text VARCHAR(64);  
        DECLARE @EffDate DATE;
        DECLARE @BilToDate DATE;
        DECLARE @iStatusID INT;
        DECLARE @GroupType CHAR(2);

        DECLARE @rec_count INT;

/*--------------------------------------------------------------------
   Handle WARNING & NON FATAL ERROR:
---------------------------------------------------------------------*/
        SET NOCOUNT ON;
        BEGIN TRY
            
            BEGIN
                BEGIN TRY
                    SELECT  @GroupType = group_type
                    FROM    dbo.[group] (NOLOCK)
                    WHERE   group_id = @ai_group_id;
                   
                    IF @GroupType != 'SG'
                        BEGIN
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Invalid group type - this program can only reinstate Single groups';
                            RETURN;
                        END;
	
                    SELECT  @iStatusID = group_status_id ,
                            @EffDate = eff_date
                    FROM    dbo.group_status (NOLOCK)
                    WHERE   group_id = @ai_group_id
                            AND group_status = 'T1'
                            AND exp_date IS NULL;

							
                  
                    IF @EffDate IS NULL
                        BEGIN
                            SELECT  @EffDate = eff_date
                            FROM    dbo.group_status (NOLOCK)
                            WHERE   group_id = @ai_group_id
                                    AND group_status = 'A4'
                                    AND exp_date IS NULL;
                       
                            IF @EffDate IS NULL
							BEGIN
                                RAISERROR('Need new Error -  SG is not terminated not active',16,1);
								RETURN
							END
		
                            IF @ad_action_date < @EffDate
							BEGIN
                                RAISERROR('Need new Error -SG is not effective for requied date',16,1);
								RETURN
							END
		
                            SET @SWP_Ret_Value = 1;
                            SET @SWP_Ret_Value1 = '';
                            RETURN;
                        END; -- already active
                    ELSE
                        BEGIN
                            IF @ad_action_date < @EffDate
                                SET @ad_action_date = @EffDate;
		
                            UPDATE  dbo.group_status
                            SET     exp_date = @ad_action_date ,
                                    h_datetime = @ad_h_datetime ,
                                    h_action = 'UP' ,
                                    h_user = @as_h_user
                            WHERE   group_status_id = @iStatusID;
                            INSERT  INTO dbo.group_status
                                    ( group_id ,
                                      group_status ,
                                      eff_date ,
                                      h_datetime ,
                                      h_action ,
                                      h_user
                                    )
                      VALUES  ( @ai_group_id ,
                                      'A4' ,
                                      @ad_action_date ,
                                      @ad_h_datetime ,
                                      'SA' ,
                                      @as_h_user
                                    );
		
                            SELECT  @BilToDate = MAX(bil_to_date)
                            FROM    dbo.bill_sum (NOLOCK)
                            WHERE   group_id = @ai_group_id
                                    AND reversal_id IS NULL;
                           
                            IF @ad_action_date < @BilToDate --$$ks is it right to reset to earlier date??
                                UPDATE  dbo.bill_sum
                                SET     bil_to_date = @ad_action_date ,
                                        old_bil_to_date = @BilToDate ,
                                        bil_dt_reset_sw = 'Y'
                                WHERE   group_id = @ai_group_id
                                        AND reversal_id IS NULL
                                        AND bil_to_date = @BilToDate;
                        END;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
					RAISERROR('Failed to reinstate Group Status.',16,1);
					RETURN
                END CATCH;
            END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = @i_error_no;
            SET @SWP_Ret_Value1 = @s_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;