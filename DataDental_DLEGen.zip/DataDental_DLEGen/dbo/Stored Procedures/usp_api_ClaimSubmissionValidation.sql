﻿
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_ClaimSubmissionValidation 189379,'',2445,'',15,'','','','703-55-6677','','','','','','',0,'','',56,'','','',0
-- =============================================
CREATE PROC [dbo].[usp_api_ClaimSubmissionValidation] 
@GroupID INT,@GroupAltID Char(20),@PlanID INT,@PlanName Char(20),@FCID INT,@FCAltID Char(40),@FCNPID Char(10),
@SubID INT,@SubSSN Char(11),@SubSourceID char(20),@SubAltID char(20),
@PatID INT,@PatSSN Char(11),@patSourceID char(20),@PatAltID char(20),
@PCPID INT,@PCPNPID Char(10),@PCPAltID Char(40),
@PvID INT,@PvNPID Char(10),@PvAltID Char(40),@PVTaxID Char(40),@DepSW bit
AS
BEGIN
DECLARE @gID INT=0;
DECLARE @pID INT=0; 
DECLARE @fID INT=0; 
DECLARE @pcID INT=0; 
DECLARE @planOption Varchar(10)=''
DECLARE @planInsType char(2)='';
DECLARE @pvState Varchar(2)=null;

	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempErrorTable') IS NOT NULL
    DROP TABLE #tempErrorTable
IF OBJECT_ID('tempdb..#tempMGP') IS NOT NULL
    DROP TABLE #tempMGP
IF OBJECT_ID('tempdb..#tempPatient') IS NOT NULL
    DROP TABLE #tempPatient
IF OBJECT_ID('tempdb..#tempProviders') IS NOT NULL
    DROP TABLE #tempProviders
IF OBJECT_ID('tempdb..#tempProviderAdd') IS NOT NULL
    DROP TABLE #tempProviderAdd

Create table #tempErrorTable(ID int identity(1,1),ErrorName varchar(50),ErrorDesc varchar(1000))	
CREATE TABLE #tempMGP(mb_gr_pl_id INT,member_id INT null,eff_gr_pl date null,exp_gr_pl date null,SubStatus Varchar(50) null)
Create Table #tempPatient(rlplfc_id INT,mb_gr_pl_id INT,member_id INT null,eff_date date null,exp_date date null,DepStatus Varchar(50) null) 
--Create Table #tempClaim(ClaimID INT,claim_status nVarchar(50)) 
Create Table #tempProviders(PvID int,pvstat Char(5),PvLName char(20),PvFName char(20),PVMI Char(2),PvTaxID char(10))
Create Table #tempProviderAdd(PvID int,PvAddr1 char(30) null,PvAddr2 char(30) null,city Char(30) null,country Char(3) null,county Char(20) null,state Char(3) null,zip char(10) null)
            	
BEGIN TRY

--Validate Group
IF @GroupID>0
BEGIN

			IF NOT EXISTS(SELECT 
				g.group_id
		        FROM [group] g(nolock), group_status gs(nolock)
				WHERE g.group_id=@GroupID  and g.group_id = gs.group_id )
				BEGIN
				  INSERT INTO #tempErrorTable Values ('Group','Group could not be found with the given criteria ');
				  RAISERROR ('User Validation Faild',16,1);
				END

				 SELECT @gID=g.group_id FROM [group] g(nolock), group_status gs(nolock)
				 WHERE g.group_id=@GroupID and g.group_id = gs.group_id

			END
			ELSE IF LEN(@GroupAltID)>0
			BEGIN

			IF NOT EXISTS (SELECT 
				g.group_id FROM [group] g(nolock), group_status gs(nolock)
				WHERE g.alt_id=@GroupAltID AND g.group_id = gs.group_id)
				 BEGIN
					 INSERT INTO #tempErrorTable Values ('Group','Group could not be found with the given criteria ');
					 RAISERROR ('User Validation Faild',16,1);
				 END
				  SELECT @gID=g.group_id FROM [group] g(nolock), group_status gs(nolock)
				  WHERE g.alt_id=@GroupAltID AND g.group_id = gs.group_id
			END

   ---need to get the groupID 
   --PRINT CAST(@gID AS NVARCHAR)
 --validatePlan

 IF @PlanID>0
BEGIN

IF NOT EXISTS( Select 
   plan_id From [plan](nolock)
	Where plan_id =@PlanID)
	BEGIN
	   INSERT INTO #tempErrorTable Values ('Plan','Plan could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	END
		   SELECT @pID=plan_id,@planOption=IIF(ins_opt='FFS','PPO',ins_opt),@planInsType=ins_type From [plan](nolock) Where plan_id =@PlanID

END
ELSE IF LEN(@PlanName)>0
BEGIN
   IF NOT EXISTS( Select 
    plan_id From [plan]
	Where plan_dsp_name =@PlanName AND plan_id>0)
	BEGIN
	   INSERT INTO #tempErrorTable Values ('Plan','Plan could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	END
	   Select @pID=plan_id,@planOption=IIF(ins_opt='FFS','PPO',ins_opt),@planInsType=ins_type From [plan] Where plan_dsp_name =@PlanName AND plan_id>0
END
 --needs to take the plan_id>0 and check the options FFS-->PPO
 --select *from [plan]
 
--PRINT 'PlanID' + CAST(@pID AS NVARCHAR) + 'Plan Option' + CAST( @planOption AS NVARCHAR) + 'Plan Ins_type' + CAST(@planInsType AS NVARCHAR)

 --validatePCP needs to be use the planid for geting plan option
 ---if plan option ffs then return do not excute the below

IF @planOption<>'PPO'
BEGIN

  IF @PCPID>0
BEGIN
IF NOT EXISTS(Select fc_id
     FROM facility Where fc_id =@PCPID)
	 BEGIN
	   INSERT INTO #tempErrorTable Values ('PCP','Facility could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	  END
  
  Select @pcID=fc_id FROM facility Where fc_id =@PCPID
END
ELSE IF LEN(@PCPAltID)>0
BEGIN

IF NOT EXISTS(Select fc_id
     FROM facility Where alt_id =@PCPAltID)
	 BEGIN
	   INSERT INTO #tempErrorTable Values ('PCP','Facility could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	END
  Select @pcID=fc_id FROM facility Where alt_id =@PCPAltID
END
ELSE IF LEN(@PCPNPID)>0
BEGIN
IF NOT EXISTS(Select fc_id
     FROM facility Where np_id =@PCPNPID)
	 BEGIN
	   INSERT INTO #tempErrorTable Values ('PCP','Facility could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	   END
	 Select @pcID=fc_id FROM facility Where np_id =@PCPNPID
END
ELSE
BEGIN
	INSERT INTO #tempErrorTable Values ('PCP','No Facility Identifier');
	RAISERROR ('User Validation Faild',16,1);
END

END

--get Fc_ID information

--PRINT  CAST(@pcID AS NVARCHAR)
--validateSub

IF @SubID>0
BEGIN

IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl Where group_id =@gID
		        and plan_id =@pID and member_id = @SubID)
				BEGIN
				---add
					Insert Into #tempMGP
						Select mb_gr_pl_id,member_id,eff_gr_pl,exp_gr_pl,null 
						FROM rlmbgrpl Where group_id =@gID
						and plan_id =@pID and member_id = @SubID
						order by mb_gr_pl_id
				END
				--ELSE 
				-- INSERT INTO #tempErrorTable Values ('Sub','Subscriber not found for criteria provided. ')
				 
END
ELSE IF len(@SubSSN)>0
BEGIN
   IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN
						order by r.mb_gr_pl_id

				END
				--ELSE
				-- INSERT INTO #tempErrorTable Values ('Sub','Subscriber not found for criteria provided. ')
END
ELSE IF len(@SubSourceID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID
						order by r.mb_gr_pl_id
				END
				--ELSE
				-- INSERT INTO #tempErrorTable Values ('Sub','Subscriber not found for criteria provided. ')

END

ELSE IF len(@SubAltID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID
						order by r.mb_gr_pl_id
				END
				--ELSE exp_gr_pl
				-- INSERT INTO #tempErrorTable Values ('Sub','Subscriber not found for criteria provided. ')

END

IF EXISTS(Select mb_gr_pl_id from #tempMGP)
BEGIN 
  IF EXISTS(Select t.mb_gr_pl_id from #tempMGP t 
			JOIN #tempMGP S ON S.member_id<>t.member_id)
  BEGIN
	 INSERT INTO #tempErrorTable Values ('Sub','Multiple Subscribers returned for criteria provided. ');
	 RAISERROR ('User Validation Faild',16,1);
	END

	--Select *
	Update t set t.SubStatus='Future'
		From #tempMGP t Where t.eff_gr_pl> CONVERT (DATE, GETDATE()) 
		AND t.exp_gr_pl is null 

	--Select *
	Update t set t.SubStatus='Active'
		From #tempMGP t Where t.eff_gr_pl between '1753/01/01' and CONVERT (DATE, GETDATE())
		AND t.exp_gr_pl is null 
 -- Select *
	Update t set t.SubStatus='Term'
		From #tempMGP t Where t.exp_gr_pl is not null 	

END
ELSE
BEGIN
 INSERT INTO #tempErrorTable Values ('Sub','Subscriber not found for criteria provided. ');
 RAISERROR ('User Validation Faild',16,1);
END
 ---get the sub address with type L 
 --Select a.sys_rec_id,a.addr1,a.addr2,a.city,a.state,a.zip from [address] a
 --join #tempMGP t on t.member_id=a.sys_rec_id
 --where subsys_code='MB' AND addr_type='L'

 --validatePatient

IF @DepSW=1
BEGIN
 IF @PatID>0
 BEGIN

 IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.member_id=@PatID AND r.rlplfc_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.member_id=@PatID AND r.rlplfc_id>0
						 order by r.rlplfc_id
				   END

 END
 ELSE IF len(@PatSSN)>0
 BEGIN
   IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.new_ssn=@PatSSN AND r.rlplfc_id>0 AND r.member_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.new_ssn=@PatSSN AND r.rlplfc_id>0 AND r.member_id>0
						 order by r.rlplfc_id
				   END

 END
 
 ELSE IF len(@PatAltID)>0
 BEGIN
   IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.alt_id=@PatAltID AND r.rlplfc_id>0 AND r.member_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.alt_id=@PatAltID AND r.rlplfc_id>0 AND r.member_id>0
						 order by r.rlplfc_id
				   END

 END
 ELSE IF len(@patSourceID)>0
 BEGIN
   IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.source_id=@patSourceID AND r.rlplfc_id>0 AND r.member_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.source_id=@patSourceID AND r.rlplfc_id>0 AND r.member_id>0
						 order by r.rlplfc_id
				  END

 END
END
	ELSE
	BEGIN
		IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 AND t.member_id=r.member_id
				 Where r.rlplfc_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id AND t.member_id=r.member_id
						 Where r.rlplfc_id>0
						 order by r.rlplfc_id
				   END

	END

 IF NOT EXISTS(Select rlplfc_id from #tempPatient)
 BEGIN
	 INSERT INTO #tempErrorTable Values ('Patient','Cannot find Patient''s PlanFC record ');
	 RAISERROR ('User Validation Faild',16,1);
 END

 IF EXISTS(Select t.rlplfc_id from #tempPatient t 
			JOIN #tempPatient s ON s.member_id<>t.member_id)
 BEGIN
	 INSERT INTO #tempErrorTable Values ('Patient','Multiple members (rlplfc) returned for criteria provided');
	 RAISERROR ('User Validation Faild',16,1);
 END

 ---get the patient id
 --Check the dep status

 --Select *
	Update t set t.DepStatus='Future'
		From #tempPatient t Where t.eff_date> CONVERT (DATE, GETDATE()) 
		AND t.exp_date is null 

	--Select *
	Update t set t.DepStatus='Active'
		From #tempPatient t Where t.eff_date between '1753/01/01' and CONVERT (DATE, GETDATE())
		AND t.exp_date is null 
 -- Select *
	Update t set t.DepStatus='Term'
		From #tempPatient t Where t.exp_date is not null 	


	Declare @gotFC bit=0;
 ---if still facility id=0 then get Facility 
 if @FCID = 0 AND LEN(@FCAltID)=0 AND LEN(@FCNPID) =0
  BEGIN
    SET @gotFC=0
   END
ELSE
BEGIN
  IF @FCID>0
BEGIN
IF NOT EXISTS(Select fc_id
     FROM facility Where fc_id =@FCID)
	 BEGIN
	   INSERT INTO #tempErrorTable Values ('Facility','Facility could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	  END
  
  Select @fID=fc_id FROM facility Where fc_id =@FCID
END
ELSE IF LEN(@FCAltID)>0
BEGIN

IF NOT EXISTS(Select fc_id
     FROM facility Where alt_id =@FCAltID)
	 BEGIN
	   INSERT INTO #tempErrorTable Values ('Facility','Facility could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	END
  Select @fID=fc_id FROM facility Where alt_id =@FCAltID
END
ELSE IF LEN(@FCNPID)>0
BEGIN
IF NOT EXISTS(Select fc_id
     FROM facility Where np_id =@FCNPID)
	 BEGIN
	   INSERT INTO #tempErrorTable Values ('Facility','Facility could not be found with the given options. ');
	   RAISERROR ('User Validation Faild',16,1);
	   END
	 Select @fID=fc_id FROM facility Where np_id =@FCNPID
END
 SET @gotFC=1
END

--get Fc_ID information
--PRINT @fID

-----validateProvider
DECLARE @PvFound bit=0;

 if @PvID = 0 AND LEN(@PvNPID)=0 AND LEN(@PvAltID) =0 AND len(@PVTaxID)=0
  BEGIN
    SET @PvFound=0
   END
ELSE
IF @PvID>0
BEGIN
IF EXISTS(Select pv_id, 
            	 alt_id,  
            	 np_id,  
            	 tax_id,  
            	 tin, 
            	 first_name,   
            	 middle_init,  
            	 last_name, 
            	 discipline, 
            	 prim_fc,  
            	 vendor_id, 
            	 pay_patient From providers Where pv_id = @PvID AND pv_id>0)
				 BEGIN
					INSERT INTO #tempProviders
					 Select  pv_id,pvstat,last_name,first_name,middle_init,tax_id
					 From providers Where pv_id = @PvID AND pv_id>0
					 --select *From providers
				   
				 END
				 ELSE
				 BEGIN
					INSERT INTO #tempErrorTable Values ('Provider','Provider ID does not exist in Database. ');
	               RAISERROR ('User Validation Faild',16,1);
				 END

END

ELSE IF len(@PvNPID)>0
BEGIN
IF EXISTS(Select pv_id, 
            	 alt_id,  
            	 np_id,  
            	 tax_id,  
            	 tin, 
            	 first_name,   
            	 middle_init,  
            	 last_name, 
            	 discipline, 
            	 prim_fc,  
            	 vendor_id, 
            	 pay_patient From providers Where np_id = @PvNPID)
				 BEGIN
					 INSERT INTO #tempProviders
					 Select  pv_id,pvstat,last_name,first_name,middle_init,tax_id
					 From providers Where np_id = @PvNPID
	              ---provider not found flag needs to be set
				 END

END

ELSE IF len(@PvAltID)>0
BEGIN
IF EXISTS(Select pv_id, 
            	 alt_id,  
            	 np_id,  
            	 tax_id,  
            	 tin, 
            	 first_name,   
            	 middle_init,  
            	 last_name, 
            	 discipline, 
            	 prim_fc,  
            	 vendor_id, 
            	 pay_patient From providers Where alt_id = @PvAltID)
				 BEGIN
				   INSERT INTO #tempProviders
					 Select  pv_id,pvstat,last_name,first_name,middle_init,tax_id
					 From providers Where alt_id = @PvAltID
				   ---provider not found flag needs to be set
				 END

END

ELSE IF len(@PVTaxID)>0
BEGIN
IF EXISTS(Select pv_id, 
  	 alt_id,  
            	 np_id,  
            	 tax_id,  
            	 tin, 
 	 first_name,   
            	 middle_init,  
            	 last_name, 
            	 discipline, 
            	 prim_fc,  
            	 vendor_id, 
            	 pay_patient From providers Where tax_id = @PVTaxID)
				 BEGIN
				   INSERT INTO #tempProviders
					 Select  pv_id,pvstat,last_name,first_name,middle_init,tax_id
					 From providers Where tax_id = @PVTaxID
				   ---provider not found flag needs to be set
				 END
END
IF EXISTS(Select *From #tempProviders where pvid>0)
BEGIN

SET @PvFound=1

 ---get the provider address with type L 
INSERT INTO #tempProviderAdd
 Select a.sys_rec_id,a.addr1,a.addr2,a.city,a.country,a.county,a.state,a.zip from #tempProviders t
 join  [address] a on t.PvID=a.sys_rec_id
 where subsys_code='PV' AND addr_type='L'
 --@pvState

SELECT @pvState=t.[state]
	From #tempProviderAdd t

END

IF(@gotFC=0 AND @PvFound=0)
BEGIN
--Neither Facility or Provider information submitted
  INSERT INTO #tempErrorTable Values ('Facility','Neither Facility or Provider information submitted ');
  RAISERROR ('User Validation Faild',16,1);
END
---if provoider info found then load the address and pVstate

--needs to be check whethere provider/fc given by checking flag

---if trans type Update then load the claim info with all subcriber all info

DECLARE @finalPvID int=0;

Select @finalPvID=PV.PvID 
	From #tempProviders PV



---Provider info

--Select *
--	From #tempProviders PV

--Select PA.*
--	From #tempProviders PV
--	JOIN #tempProviderAdd PA ON PA.PvID=PV.PvID
--	Where PA.PvID>0

Select t.ErrorName AS ErrorType,t.ErrorDesc AS ErrorMsg From #tempErrorTable t

--Member group info
Select @gID as GroupID,@pID As PlanID,@fID as FCID,@pcID as PCPID,@planInsType as PlanInsType,@planOption as PlanOption,@PvFound as PvFound,
	@finalPvID as PVID,t.member_id as SubID,tp.member_id as PatientID,@pvState AS PvState
	From #tempMGP t
	JOIN #tempPatient tp on t.mb_gr_pl_id=tp.mb_gr_pl_id

END TRY
BEGIN CATCH
IF ERROR_MESSAGE()='User Validation Faild'
BEGIN

  Select t.ErrorName AS ErrorType,t.ErrorDesc AS ErrorMsg From #tempErrorTable t
END
ELSE 
 THROW; 
END CATCH

END