﻿CREATE PROCEDURE [dbo].[SWPAddGlVar]
    @name VARCHAR(255) ,
    @value VARBINARY(8000)
    
AS
    UPDATE  ##SwtGlVar
    SET     value = @value
    WHERE   spid = @@spid
            AND name = @name;