﻿CREATE PROCEDURE [dbo].[dlp_bu_pv_assoc]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    


	/*error variable*/
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
	
	
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);

	
	
	
        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @s_batch_status CHAR(1);

	
	
	/* 20120925$$ks - added np_id and expanded fc alt id 
	 * (prim_fc and fc_assoc_fc_id to 25 chars) 
	 * and pv_license to 18 char
	 * 20130804$$ks - incr prim_fc and fc_assoc_fc_id to 40 chars
	 */
	

        DECLARE @curr_pvstat_id INT;
        DECLARE @curr_pvstat CHAR(2);
        DECLARE @curr_pvstat_eff DATE;
        DECLARE @curr_pvstat_exp DATE;
        DECLARE @curr_assoc_id INT;
        DECLARE @curr_assoc_eff DATE;
        DECLARE @curr_assoc_exp DATE;
        DECLARE @tape_assoc_fcid INT;
        DECLARE @tape_assoc_eff DATE;
        DECLARE @tape_assoc_exp DATE;

	DECLARE @pvfc_sir_def_name char(18);
	DECLARE @pvfc_proc_name char(18);
	DECLARE @pv_sp_id integer;
	DECLARE @pv_sir_def_id integer;
	DECLARE @pv_config_id integer;
	DECLARE @x_def_eff_date char(10);
	DECLARE @y_def_eff_date date;
	DECLARE @x_def_exp_date char(10);
	DECLARE @y_def_exp_date date;
	DECLARE @x_has_term_date char(1);
	DECLARE @p_sir_id integer;
	DECLARE @p_alt_id char(20);
	DECLARE @p_pv_tax_id char(9);
	DECLARE @p_pv_np_id char(10);
	DECLARE @p_pv_license char(18);
	DECLARE @p_pv_lic_state char(2);
	DECLARE @p_tin char(1);
	DECLARE @p_pv_first_name char(20);
	DECLARE @p_pv_middle_init char(1);
	DECLARE @p_pv_last_name char(30);
	DECLARE @p_discipline char(2);
	DECLARE @p_mal_car char(30);
	DECLARE @p_mal_pol_no char(15);
	DECLARE @p_mal_prac char(10);
	DECLARE @p_mal_amt char(18);
	DECLARE @p_mal_amt_i char(18);
	DECLARE @p_mal_comnt char(50);
	DECLARE @p_dea_no char(15);
	DECLARE @p_dea_cert_dt char(10);
	DECLARE @p_dea_exp_dt char(10);
	DECLARE @p_cds_no char(15);
	DECLARE @p_cds_cert_dt char(10);
	DECLARE @p_cds_exp_dt char(10);
	DECLARE @p_cpr_cert_dt char(10);
	DECLARE @p_cpr_exp_dt char(10);
	DECLARE @p_prim_fc char(40);
	DECLARE @p_school char(50);
	DECLARE @p_grd_date char(10);
	DECLARE @p_degree char(4);
	DECLARE @p_ada_mbr char(1);
	DECLARE @p_district_no char(15);
	DECLARE @p_pv_dob char(10);
	DECLARE @p_print_dir char(1);
	DECLARE @p_race char(2);
	DECLARE @p_gender char(1);
	DECLARE @p_num_yr_prac char(3);
	DECLARE @p_peer_rv char(1);
	DECLARE @p_vendor_id char(20);
	DECLARE @p_pv_stat_eff_date char(10);
	DECLARE @p_fc_assoc_fc_id char(40);
	DECLARE @p_fc_assoc_type char(1);
	DECLARE @p_fc_assoc_eff char(10);
	DECLARE @p_fc_assoc_exp char(10);
	DECLARE @p_pv_lic_eff char(10);
	DECLARE @p_pv_lic_exp char(10);
	DECLARE @p_pv_addr_type char(2);
	DECLARE @p_pv_addr_1 char(30);
	DECLARE @p_pv_addr_2 char(30);
	DECLARE @p_pv_addr_zip char(10);
	DECLARE @p_pv_addr_city char(30);
	DECLARE @p_pv_addr_state char(2);
	DECLARE @p_pv_addr_county char(20);
	DECLARE @p_pv_addr_country char(3);
	DECLARE @p_pv_addr_mail char(1);
	DECLARE @p_pv_con_type char(2);
	DECLARE @p_pv_con_lname char(15);
	DECLARE @p_pv_con_fname char(10);
	DECLARE @p_pv_con_title char(25);
	DECLARE @p_pv_con_phone1 char(10);
	DECLARE @p_pv_con_ext1 char(10);
	DECLARE @p_pv_con_phone2 char(10);
	DECLARE @p_pv_con_ext2 char(10);
	DECLARE @p_pv_con_fax char(10);

	DECLARE @as_action_code char(2);
	DECLARE @as_pv_stat_eff date;
	DECLARE @as_fcassoc_eff date;
	DECLARE @as_fcassoc_exp date;
	DECLARE @i_pv_id integer;
	DECLARE @pvlic_cnt integer;
	DECLARE @i_mal_prac date;
	DECLARE @i_mal_amt decimal(16,2);
	DECLARE @i_mal_amt_i decimal(16,2);
	DECLARE @i_dea_cert_dt date;
	DECLARE @i_dea_exp_dt date;
	DECLARE @i_cds_cert_dt date;
	DECLARE @i_cds_exp_dt date;
	DECLARE @i_grd_date date;
	DECLARE @i_cpr_cert_dt date;
	DECLARE @i_cpr_exp_dt date;
	DECLARE @i_pv_dob date;
	DECLARE @i_num_yr_prac integer;
	DECLARE @i_fcstat_eff_date date;
	DECLARE @i_pv_stat_eff_date date;
	DECLARE @i_fc_id integer;
	DECLARE @i_fc_assoc_cnt integer;
	DECLARE @i_fc_assoc_eff date;
	DECLARE @i_pv_lic_eff date;
	DECLARE @i_fc_assoc_exp date;
	DECLARE @i_pv_lic_exp date;
	DECLARE @i_zip integer;
	DECLARE @i_zip_id integer;
	DECLARE @i_city char(30);
	DECLARE @i_state char(2);
	DECLARE @i_county char(20);
	DECLARE @i_phone_err char(1);
	DECLARE @i_phone1 integer;
	DECLARE @i_ext1 integer;
	DECLARE @i_phone2 integer;
	DECLARE @i_ext2 integer;
	DECLARE @i_fax integer;
	DECLARE @n_process_count integer;
	DECLARE @n_error_count integer;
	DECLARE @n_succ_count integer;

        DECLARE @d_valid_error INT;
        DECLARE @d_error_descr VARCHAR(64);
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        
        DECLARE @SWV_dl_get_sp_id INT;
        DECLARE @SWV_dl_get_sir_def_id INT;
        DECLARE @SWV_dl_get_param_value VARCHAR(128);
       -- DECLARE @cSIR CURSOR;
        DECLARE @SWV_func_DLP_PV_MISSING_par0 DATE;
        DECLARE @SWV_dl_upd_statistics INT;
		DECLARE @created_by CHAR(15)

        SET NOCOUNT ON;
		 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 7 AND BatchId = @a_batch_id )
		 BEGIN
	
				INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id])
				SELECT N'n_process_count',					N'', @a_batch_id, 7
				UNION ALL SELECT N'n_succ_count',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_ada_mbr,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_alt_id,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_cds_cert_dt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_cds_exp_dt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_cds_no,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_cpr_cert_dt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_cpr_exp_dt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_dea_cert_dt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_dea_exp_dt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_dea_no,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_degree,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_discipline,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_district_no,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_fc_assoc_eff,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_fc_assoc_exp,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_fc_assoc_fc_id,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_fc_assoc_type,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_gender,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_grd_date,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_mal_amt,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_mal_amt_i,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_mal_car,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_mal_comnt,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_mal_pol_no,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_mal_prac,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_num_yr_prac,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_peer_rv,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_prim_fc,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_print_dir,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_1,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_2,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_city,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_country,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_county,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_mail,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_state,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_type,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_addr_zip,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_con_ext1,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_con_fname,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_con_lname,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_con_phone1,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_con_title,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_dob,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_first_name,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_last_name,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_lic_eff,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_lic_exp,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_lic_state,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_license,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_middle_init,',		N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_stat_eff_date,',	N'', @a_batch_id, 7
				UNION ALL SELECT N'p_pv_tax_id,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'p_race,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_school,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_sir_id,',				N'', @a_batch_id, 7
				UNION ALL SELECT N'p_tin,',					N'', @a_batch_id, 7
				UNION ALL SELECT N'p_vendor_id,',			N'', @a_batch_id, 7
				UNION ALL SELECT N'pvfc_proc_name',			N'', @a_batch_id, 7
				UNION ALL SELECT N'y_def_exp_date',			N'', @a_batch_id, 7

										
		END
        SET @pvfc_sir_def_name ='';
        
        SET @pvfc_proc_name ='';
       
        SET @pv_sp_id =0;
        
        SET @pv_sir_def_id =0;
       
        SET @pv_config_id =0;
       
        SET @x_def_eff_date ='';
     
        SET @y_def_eff_date = NULL;
      
        SET @x_def_exp_date ='';
       
        SET @y_def_exp_date = NULL;
       
        SET @x_has_term_date ='';
        
        SET @p_sir_id =0;
       
        SET @p_alt_id ='';
        
        SET @p_pv_tax_id ='';
       
        SET @p_pv_np_id ='';
       
        SET @p_pv_license ='';
       
        SET @p_pv_lic_state ='';
       
        SET @p_tin ='';
        
        SET @p_pv_first_name ='';
       
        SET @p_pv_middle_init ='';
      
        SET @p_pv_last_name ='';
      
        SET @p_discipline ='';
        
        SET @p_mal_car ='';
       
        SET @p_mal_pol_no ='';
      
        SET @p_mal_prac ='';
      
        SET @p_mal_amt ='';
       
        SET @p_mal_amt_i ='';
       
        SET @p_mal_comnt ='';
       
        SET @p_dea_no ='';
        
        SET @p_dea_cert_dt ='';
       
        SET @p_dea_exp_dt ='';
       
        SET @p_cds_no ='';
       
        SET @p_cds_cert_dt ='';
       
        SET @p_cds_exp_dt ='';
       
        SET @p_cpr_cert_dt ='';
       
        SET @p_cpr_exp_dt ='';
       
        SET @p_prim_fc ='';
       
        SET @p_school ='';
       
        SET @p_grd_date ='';
  
        SET @p_degree ='';
       
        SET @p_ada_mbr ='';
     
        SET @p_district_no ='';
     
        SET @p_pv_dob ='';
       
        SET @p_print_dir ='';
        
        SET @p_race ='';
      
        SET @p_gender ='';
       
        SET @p_num_yr_prac ='';
      
        SET @p_peer_rv ='';
       
        SET @p_vendor_id ='';
      
        SET @p_pv_stat_eff_date ='';
       
        SET @p_fc_assoc_fc_id ='';
      
        SET @p_fc_assoc_type ='';
       
        SET @p_fc_assoc_eff ='';
       
        SET @p_fc_assoc_exp ='';
 
        SET @p_pv_lic_eff ='';
    
SET @p_pv_lic_exp ='';
      
        SET @p_pv_addr_type ='';
      
        SET @p_pv_addr_1 ='';
      
        SET @p_pv_addr_2 ='';
       
        SET @p_pv_addr_zip ='';
       
        SET @p_pv_addr_city ='';
      
        SET @p_pv_addr_state ='';
     
        SET @p_pv_addr_county ='';
      
        SET @p_pv_addr_country ='';
       
        SET @p_pv_addr_mail ='';
      
        SET @p_pv_con_type ='';
       
        SET @p_pv_con_lname ='';
      
        SET @p_pv_con_fname ='';
 
        SET @p_pv_con_title ='';
       
        SET @p_pv_con_phone1 ='';
      
        SET @p_pv_con_ext1 ='';
       
        SET @p_pv_con_phone2 ='';
    
        SET @p_pv_con_ext2 ='';
      
        SET @p_pv_con_fax ='';
       
        SET @as_action_code ='';
      
        SET @as_pv_stat_eff = NULL;
  
        SET @as_fcassoc_eff = NULL;
     
        SET @as_fcassoc_exp = NULL;
    
        SET @i_pv_id =0;
    
        SET @pvlic_cnt =0;
      
        SET @i_mal_prac = NULL;
     
        SET @i_mal_amt =0;
   
        SET @i_mal_amt_i =0;
      
        SET @i_dea_cert_dt = NULL;
      
        SET @i_dea_exp_dt = NULL;
 
        SET @i_cds_cert_dt = NULL;
      
        SET @i_cds_exp_dt = NULL;
     
        SET @i_grd_date = NULL;
    
        SET @i_cpr_cert_dt = NULL;
     
        SET @i_cpr_exp_dt = NULL;
    
        SET @i_pv_dob = NULL;
     
        SET @i_num_yr_prac =0;
      
        SET @i_fcstat_eff_date = NULL;
      
        SET @i_pv_stat_eff_date = NULL;
      
        SET @i_fc_id =0;
   
        SET @i_fc_assoc_cnt =0;
      
        SET @i_fc_assoc_eff = NULL;
      
        SET @i_pv_lic_eff = NULL;
       
        SET @i_fc_assoc_exp = NULL;
       
        SET @i_pv_lic_exp = NULL;
      
        SET @i_zip =0;
       
        SET @i_zip_id =0;
       
        SET @i_city ='';
     
        SET @i_state ='';
        
        SET @i_county ='';
        
        SET @i_phone_err ='';
        
        SET @i_phone1 =0;
       
        SET @i_ext1 =0;
       
        SET @i_phone2 =0;
        
        SET @i_ext2 =0;
        
        SET @i_fax =0;
       
        SET @n_process_count =0;
        
        SET @n_error_count =0;
        
        SET @n_succ_count =0;
		UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
		UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7
        
        BEGIN TRY
            
            SET @pvfc_proc_name = 'bu_pv_assoc';

			UPDATE dbo.GlobalVar set VarValue = @pvfc_proc_name WHERE VarName = 'pvfc_proc_name' and  BatchId = @a_batch_id AND Module_Id = 7
         
            SET @pvfc_sir_def_name = 'pv_assoc';
           
            EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, @pvfc_proc_name
               
            SET @pv_sp_id = @SWV_dl_get_sp_id;
            
            IF @pv_sp_id IS NULL
                OR @pv_sp_id <= 0
				BEGIN
					SET	@a_error_no = 1
					RAISERROR('Invalid SP Name',16,1);
				END
	
           
            EXECUTE @SWV_dl_get_sir_def_id = dbo.dl_get_sir_def_id @pvfc_sir_def_name
            SET @pv_sir_def_id = @SWV_dl_get_sir_def_id ;
            
            IF @pv_sir_def_id IS NULL
                OR @pv_sir_def_id <= 0
				BEGIN
					SET	@a_error_no = 2
					RAISERROR('Invalid SIR TABLE Definition',16,1);
				END
	
            
            EXECUTE @SWV_dl_get_param_value = dbo.dl_get_param_value @a_batch_id, @pv_sp_id,
                'Default Eff Date';
            SET @x_def_eff_date = @SWV_dl_get_param_value ;
            
            EXECUTE @SWV_dl_get_param_value = dbo.dl_get_param_value @a_batch_id, @pv_sp_id,
                'Default Exp Date';
            SET @x_def_exp_date = @SWV_dl_get_param_value ;
           
     EXECUTE @SWV_dl_get_param_value = dbo.dl_get_param_value @a_batch_id, @pv_sp_id,
                'Has Term Date Flag';
            SET @x_has_term_date = @SWV_dl_get_param_value ;
            
            IF ( @x_def_eff_date IS NULL
        OR @x_def_eff_date = ''
)
OR LEN(@x_def_eff_date) = 0
				BEGIN
					SET	@a_error_no = 3
					RAISERROR('Missing Default Effective Date',16,1);
				END
            ELSE
				BEGIN
              
                    SET @y_def_eff_date = cast(@x_def_eff_date as date);
                  
                      
                    IF DATEPART(DAY,
                                CONVERT(DATE, CONVERT(VARCHAR, @y_def_eff_date))) <> 1
							BEGIN
								SET	@a_error_no = 4
								RAISERROR('Default Effective Date is not first of the month',16,1);
						END
                END;
	
            IF ( @x_def_exp_date IS NULL
                 OR @x_def_exp_date = ''
               )
                OR LEN(@x_def_exp_date) = 0
				BEGIN
					SET	@a_error_no = 5
					RAISERROR('Missing Default Expiration Date',16,1);
				END
            ELSE
                BEGIN
                   
                    SET @y_def_exp_date = @x_def_exp_date;
                   
                    IF DATEPART(DAY,
                                CONVERT(DATE, CONVERT(VARCHAR, @y_def_exp_date))) <> 1
								BEGIN
								SET @a_error_no = 6
								RAISERROR('Default Expiration Date is not first of the month',16,1);
						END
                END;
	
		UPDATE dbo.GlobalVar set VarValue = @y_def_exp_date WHERE VarName = 'y_def_exp_date' and  BatchId = @a_batch_id AND Module_Id = 7
          
            IF ( @x_has_term_date IS NULL
                 OR @x_has_term_date = ''
               )
                OR LEN(@x_has_term_date) = 0
				BEGIN
					SET	@a_error_no = 7
					RAISERROR('Missing Has Term Date Flag',16,1);
				END
            ELSE
                BEGIN
                  
                    IF @x_has_term_date NOT IN ( 'Y', 'N' )
						BEGIN
							SET	@a_error_no = 8
                        RAISERROR('Invalid Value for Has Term Date flag',16,1);
						END
                END;
	
            SELECT  @pv_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
            
           
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @pv_sp_id;
					
					SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
           
            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      --ORIGINAL_LOGIN() ,
					  @created_by,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
           
            --SET @n_process_count =0;
           
            --SET @n_succ_count =0;

			UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
			UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7
           
            IF @a_sir_id > 0
                BEGIN
                    UPDATE  dbo.dls_pv_assoc
                    SET     dls_status = 'V'
                    WHERE   dls_batch_id = @a_batch_id
 AND dls_sir_id = @a_sir_id;
                    DELETE  FROM dbo.dl_action
                    WHERE   batch_id = @a_batch_id
                   AND process_status = 'N'
                            AND dls_sir_id = @a_sir_id;
                    
                    EXECUTE dbo.dl_clean_curr_err @a_batch_id, @a_sir_id,
          @pv_sp_id, @n_error_no OUTPUT, @n_error_text OUTPUT;
 END;
        ELSE
                BEGIN
                    DELETE  FROM dbo.dl_action
                    WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_pv_assoc (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
     DELETE  FROM dbo.dl_log_error
                    WHERE   config_bat_id = @a_batch_id 
		-- AND sp_id = pv_sp_id
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_pv_assoc (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
                END;
	
           /*
		    SET @cSIR = CURSOR  FOR SELECT  dls_sir_id, alt_id, pv_tax_id, pv_license, pv_lic_state, tin,
		pv_first_name, pv_middle_init, pv_last_name, discipline,
		mal_car, mal_pol_no, mal_prac, mal_amt, mal_amt_i, mal_comnt,
		dea_no, dea_cert_dt, dea_exp_dt, cds_no, cds_cert_dt,
		cds_exp_dt, cpr_cert_dt, cpr_exp_dt, prim_fc, school, grd_date,
		degree, ada_mbr, district_no, pv_dob, print_dir, race, gender,
		num_yr_prac, peer_rv, vendor, pv_stat_eff_date,
		fc_assoc_fc_id, fc_assoc_type, fc_assoc_eff_date,
		fc_assoc_exp_date, pv_lic_eff_date, pv_lic_exp_date,
		pv_addr_type, pv_addr_1, pv_addr_2, pv_addr_zip, pv_addr_city,
		pv_addr_state, pv_addr_county, pv_addr_country, pv_addr_mail,
--		pv_con_type,
		pv_con_lname, pv_con_fname, pv_con_title,
		pv_con_phone1, pv_con_ext1, pv_con_phone2, pv_con_ext2,
		pv_con_fax, pv_np_id
	
      FROM dbo.dls_pv_assoc (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'V';
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @p_sir_id, @p_alt_id, @p_pv_tax_id,
  @p_pv_license, @p_pv_lic_state, @p_tin, @p_pv_first_name,
                @p_pv_middle_init, @p_pv_last_name, @p_discipline, @p_mal_car,
                @p_mal_pol_no, @p_mal_prac, @p_mal_amt, @p_mal_amt_i,
                @p_mal_comnt, @p_dea_no, @p_dea_cert_dt, @p_dea_exp_dt,
        @p_cds_no, @p_cds_cert_dt, @p_cds_exp_dt, @p_cpr_cert_dt,
                @p_cpr_exp_dt, @p_prim_fc, @p_school, @p_grd_date, @p_degree,
                @p_ada_mbr, @p_district_no, @p_pv_dob, @p_print_dir, @p_race,
                @p_gender, @p_num_yr_prac, @p_peer_rv, @p_vendor_id,
                @p_pv_stat_eff_date, @p_fc_assoc_fc_id, @p_fc_assoc_type,
                @p_fc_assoc_eff, @p_fc_assoc_exp, @p_pv_lic_eff, @p_pv_lic_exp,
                @p_pv_addr_type, @p_pv_addr_1, @p_pv_addr_2, @p_pv_addr_zip,
                @p_pv_addr_city, @p_pv_addr_state, @p_pv_addr_county,
                @p_pv_addr_country, @p_pv_addr_mail,
--		p_pv_con_type,
                @p_pv_con_lname, @p_pv_con_fname, @p_pv_con_title,
                @p_pv_con_phone1, @p_pv_con_ext1, @p_pv_con_phone2,
                @p_pv_con_ext2, @p_pv_con_fax, @p_pv_np_id;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                   alt_id CHAR (20), 
				   pv_tax_id CHAR (9), 
				   pv_license CHAR (18), 
				   pv_lic_state CHAR (2), 
				   tin CHAR (1), 
				   pv_first_name CHAR (20), 
				   pv_middle_init CHAR (1), 
				   pv_last_name CHAR (30), 
				   discipline CHAR (2), 
				   mal_car CHAR (30), 
				   mal_pol_no CHAR (15), 
				   mal_prac CHAR (10), 
				   mal_amt CHAR (20), 
				   mal_amt_i CHAR (20), 
				   mal_comnt CHAR (50), 
				   dea_no CHAR (15), 
				   dea_cert_dt CHAR (10), 
				   dea_exp_dt CHAR (10), 
				   cds_no CHAR (15), 
				   cds_cert_dt CHAR (10), 
				   cds_exp_dt CHAR (10), 
				   cpr_cert_dt CHAR (10), 
				   cpr_exp_dt CHAR (10), 
				   prim_fc CHAR (40), 
				   school CHAR (50), 
				   grd_date CHAR (10), 
				   degree CHAR (4), 
				   ada_mbr CHAR (1), 
				   district_no CHAR (15), 
				   pv_dob CHAR (10), 
				   print_dir CHAR (1), 
				   race CHAR (2), 
				   gender CHAR (1), 
				   num_yr_prac CHAR (11), 
				   peer_rv CHAR (1),
				   vendor CHAR(40), 
				   pv_stat_eff_date CHAR (10), 
				   fc_assoc_fc_id CHAR (40), 
				   fc_assoc_type CHAR (1), 
				  fc_assoc_eff_date CHAR (10), 
				   fc_assoc_exp_date CHAR (10), 
				   pv_lic_eff_date CHAR (10), 
				   pv_lic_exp_date CHAR (10), 
				   pv_addr_type CHAR (2), 
				   pv_addr_1 CHAR (30), 
				   pv_addr_2 CHAR (30), 
				   pv_addr_zip CHAR (10), 
				   pv_addr_city CHAR (30), 
				   pv_addr_state CHAR (2), 
				   pv_addr_county CHAR (20), 
				   pv_addr_country CHAR (3), 
				   pv_addr_mail CHAR (1), 
				   pv_con_lname CHAR (15), 
				   pv_con_fname CHAR (10), 
				   pv_con_title CHAR (25), 
				   pv_con_phone1 CHAR (14), 
				   pv_con_ext1 CHAR (5), 
				   pv_con_phone2 CHAR (14), 
				   pv_con_ext2 CHAR (5), 
				   pv_con_fax CHAR(14),
				   pv_np_id CHAR(10)
				     );

            INSERT  INTO @SWV_cursor_var1
                    ( dls_sir_id ,
                      alt_id ,
                      pv_tax_id ,
                      pv_license ,
                      pv_lic_state ,
                      tin ,
                      pv_first_name ,
                      pv_middle_init ,
                      pv_last_name ,
                      discipline ,
                      mal_car ,
                      mal_pol_no ,
                      mal_prac ,
                      mal_amt ,
                      mal_amt_i ,
                      mal_comnt ,
                      dea_no ,
      dea_cert_dt ,
                      dea_exp_dt ,
                      cds_no ,
                      cds_cert_dt ,
                      cds_exp_dt ,
                      cpr_cert_dt ,
                      cpr_exp_dt ,
                      prim_fc ,
                      school ,
                      grd_date ,
                      degree ,
                      ada_mbr ,
                      district_no ,
                      pv_dob ,
                      print_dir ,
                      race ,
                    gender ,
                      num_yr_prac ,
                      peer_rv ,
                      vendor ,
                      pv_stat_eff_date ,
                      fc_assoc_fc_id ,
                      fc_assoc_type ,
  fc_assoc_eff_date ,
                      fc_assoc_exp_date ,
                      pv_lic_eff_date ,
                      pv_lic_exp_date ,
                      pv_addr_type ,
                      pv_addr_1 ,
                      pv_addr_2 ,
                      pv_addr_zip ,
                      pv_addr_city ,
                      pv_addr_state ,
                      pv_addr_county ,
                      pv_addr_country ,
                      pv_addr_mail ,
                      pv_con_lname ,
                      pv_con_fname ,
                      pv_con_title ,
                      pv_con_phone1 ,
                      pv_con_ext1 ,
                      pv_con_phone2 ,
                      pv_con_ext2 ,
                      pv_con_fax ,
                      pv_np_id
                    )
                    SELECT  dls_sir_id ,
                            alt_id ,
   pv_tax_id ,
                            pv_license ,
                            pv_lic_state ,
                   tin ,
                          pv_first_name ,
                            pv_middle_init ,
                            pv_last_name ,
                            discipline ,
                            mal_car ,
          mal_pol_no ,
                mal_prac ,
                            mal_amt ,
                            mal_amt_i ,
                            mal_comnt ,
                            dea_no ,
                            dea_cert_dt ,
                            dea_exp_dt ,
     cds_no ,
                            cds_cert_dt ,
       cds_exp_dt ,
                            cpr_cert_dt ,
                            cpr_exp_dt ,
                         prim_fc ,
                            school ,
                            grd_date ,
                            degree ,
                            ada_mbr ,
                            district_no ,
                            pv_dob ,
                            print_dir ,
                            race ,
                            gender ,
                            num_yr_prac ,
                            peer_rv ,
                            vendor ,
                            pv_stat_eff_date ,
                            fc_assoc_fc_id ,
                            fc_assoc_type ,
                            fc_assoc_eff_date ,
                            fc_assoc_exp_date ,
                            pv_lic_eff_date ,
                            pv_lic_exp_date ,
                            pv_addr_type ,
                            pv_addr_1 ,
                            pv_addr_2 ,
                            pv_addr_zip ,
                            pv_addr_city ,
                            pv_addr_state ,
                            pv_addr_county ,
                            pv_addr_country ,
                            pv_addr_mail ,
                            pv_con_lname ,
                            pv_con_fname ,
                            pv_con_title ,
                            pv_con_phone1 ,
                            pv_con_ext1 ,
                            pv_con_phone2 ,
                            pv_con_ext2 ,
                            pv_con_fax ,
                            pv_np_id
                    FROM    dbo.dls_pv_assoc (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'V';


            DECLARE @cur1_cnt INT ,
                @cur1_i INT;

            SET @cur1_i = 1;

				--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;

            WHILE ( @cur1_i <= @cur1_cnt )
                BEGIN
                    SELECT  @p_sir_id = dls_sir_id  ,
                            @p_alt_id = alt_id,
                            @p_pv_tax_id = pv_tax_id ,
                            @p_pv_license = pv_license ,
                            @p_pv_lic_state = pv_lic_state ,
                            @p_tin = tin ,
                            @p_pv_first_name = pv_first_name ,
                            @p_pv_middle_init = pv_middle_init ,
                            @p_pv_last_name = pv_last_name ,
                            @p_discipline = discipline ,
                            @p_mal_car = mal_car ,
                            @p_mal_pol_no = mal_pol_no ,
                            @p_mal_prac = mal_prac ,
                            @p_mal_amt = mal_amt ,
                            @p_mal_amt_i = mal_amt_i ,
                            @p_mal_comnt = mal_comnt ,
                            @p_dea_no = dea_no ,
                            @p_dea_cert_dt = dea_cert_dt ,
                            @p_dea_exp_dt = dea_exp_dt ,
                            @p_cds_no = cds_no ,
                            @p_cds_cert_dt = cds_cert_dt ,
                            @p_cds_exp_dt = cds_exp_dt ,
                       @p_cpr_cert_dt = cpr_cert_dt ,
                            @p_cpr_exp_dt = cpr_exp_dt ,
							 @p_prim_fc = prim_fc ,
							@p_school = school ,
							 @p_grd_date = grd_date ,
                     @p_degree = degree ,
                            @p_ada_mbr = ada_mbr ,
                            @p_district_no = district_no ,
                            @p_pv_dob = pv_dob ,
						 @p_print_dir = print_dir ,
                            @p_race = race ,
     @p_gender = gender ,
							 @p_num_yr_prac = num_yr_prac ,
							@p_peer_rv = peer_rv ,
                            @p_vendor_id = vendor ,
                            @p_pv_stat_eff_date = pv_stat_eff_date ,
                            @p_fc_assoc_fc_id = fc_assoc_fc_id ,
                            @p_fc_assoc_type = fc_assoc_type ,
                            @p_fc_assoc_eff = fc_assoc_eff_date ,
                            @p_fc_assoc_exp = fc_assoc_exp_date ,
                            @p_pv_lic_eff = pv_lic_eff_date ,
                            @p_pv_lic_exp = pv_lic_exp_date ,
                            @p_pv_addr_type = pv_addr_type ,
                            @p_pv_addr_1 = pv_addr_1 ,
                            @p_pv_addr_2 = pv_addr_2 ,
                            @p_pv_addr_zip = pv_addr_zip ,
                            @p_pv_addr_city = pv_addr_city ,
                            @p_pv_addr_state = pv_addr_state ,
                            @p_pv_addr_county = pv_addr_county ,
                            @p_pv_addr_country = pv_addr_country ,
                            @p_pv_addr_mail = pv_addr_mail ,
                            @p_pv_con_lname = pv_con_lname ,
                            @p_pv_con_fname = pv_con_fname ,
                            @p_pv_con_title = pv_con_title ,
                            @p_pv_con_phone1 = pv_con_phone1 ,
                            @p_pv_con_ext1 = pv_con_ext1 ,
                            @p_pv_con_phone2 = pv_con_phone2 ,
                            @p_pv_con_ext2 = pv_con_ext2 ,
                            @p_pv_con_fax = pv_con_fax ,
                            @p_pv_np_id = pv_np_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur1_i;

					UPDATE dbo.GlobalVar set VarValue = @p_sir_id WHERE VarName = 'p_sir_id,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_alt_id WHERE VarName = 'p_alt_id,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_tax_id WHERE VarName = 'p_pv_tax_id,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_license WHERE VarName = 'p_pv_license,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_lic_state WHERE VarName = 'p_pv_lic_state,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_tin WHERE VarName = 'p_tin,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_first_name WHERE VarName = 'p_pv_first_name,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_middle_init WHERE VarName = 'p_pv_middle_init,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_last_name WHERE VarName = 'p_pv_last_name,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_discipline WHERE VarName = 'p_discipline,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_mal_car WHERE VarName = 'p_mal_car,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_mal_pol_no WHERE VarName = 'p_mal_pol_no,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_mal_prac WHERE VarName = 'p_mal_prac,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_mal_amt WHERE VarName = 'p_mal_amt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_mal_amt_i WHERE VarName = 'p_mal_amt_i,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_mal_comnt WHERE VarName = 'p_mal_comnt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_dea_no WHERE VarName = 'p_dea_no,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_dea_cert_dt WHERE VarName = 'p_dea_cert_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_dea_exp_dt WHERE VarName = 'p_dea_exp_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_cds_no WHERE VarName = 'p_cds_no,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_cds_cert_dt WHERE VarName = 'p_cds_cert_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_cds_exp_dt WHERE VarName = 'p_cds_exp_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_cpr_cert_dt WHERE VarName = 'p_cpr_cert_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_cpr_exp_dt WHERE VarName = 'p_cpr_exp_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_prim_fc WHERE VarName = 'p_prim_fc,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_school WHERE VarName = 'p_school,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_grd_date WHERE VarName = 'p_grd_date,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_degree WHERE VarName = 'p_degree,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_ada_mbr WHERE VarName = 'p_ada_mbr,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_district_no WHERE VarName = 'p_district_no,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_dob WHERE VarName = 'p_pv_dob,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_print_dir WHERE VarName = 'p_print_dir,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_race WHERE VarName = 'p_race,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_gender WHERE VarName = 'p_gender,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_num_yr_prac WHERE VarName = 'p_num_yr_prac,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_peer_rv WHERE VarName = 'p_peer_rv,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_vendor_id WHERE VarName = 'p_vendor_id,' and  BatchId = @a_batch_id AND Module_Id = 7
					--UPDATE dbo.GlobalVar set VarValue = @p_pv_stat_eff_date WHERE VarName = 'p_pv_stat_eff_date,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@p_pv_stat_eff_date,'') <>'' then STUFF(STUFF(@p_pv_stat_eff_date,3,0,'/'),6,0,'/') ELSE @p_pv_stat_eff_date END WHERE VarName = 'p_pv_stat_eff_date,' and  BatchId = @a_batch_id AND Module_Id = 7


					UPDATE dbo.GlobalVar set VarValue = @p_fc_assoc_fc_id WHERE VarName = 'p_fc_assoc_fc_id,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_fc_assoc_type WHERE VarName = 'p_fc_assoc_type,' and  BatchId = @a_batch_id AND Module_Id = 7
					--UPDATE dbo.GlobalVar set VarValue = @p_fc_assoc_eff WHERE VarName = 'p_fc_assoc_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue =  CASE WHEN ISNULL(@p_fc_assoc_eff,'') <>'' then STUFF(STUFF(@p_fc_assoc_eff,3,0,'/'),6,0,'/') ELSE @p_fc_assoc_eff END WHERE VarName = 'p_fc_assoc_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
					--UPDATE dbo.GlobalVar set VarValue = @p_fc_assoc_exp WHERE VarName = 'p_fc_assoc_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@p_fc_assoc_exp,'') <>'' then STUFF(STUFF(@p_fc_assoc_exp,3,0,'/'),6,0,'/') ELSE @p_fc_assoc_exp END  WHERE VarName = 'p_fc_assoc_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
					--UPDATE dbo.GlobalVar set VarValue = @p_pv_lic_eff WHERE VarName = 'p_pv_lic_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@p_pv_lic_eff,'') <>'' then STUFF(STUFF(@p_pv_lic_eff,3,0,'/'),6,0,'/') ELSE @p_pv_lic_eff END WHERE VarName = 'p_pv_lic_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
					--UPDATE dbo.GlobalVar set VarValue = @p_pv_lic_exp WHERE VarName = 'p_pv_lic_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@p_pv_lic_exp,'') <>'' then STUFF(STUFF(@p_pv_lic_exp,3,0,'/'),6,0,'/') ELSE @p_pv_lic_exp END WHERE VarName = 'p_pv_lic_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_type WHERE VarName = 'p_pv_addr_type,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_1 WHERE VarName = 'p_pv_addr_1,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_2 WHERE VarName = 'p_pv_addr_2,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_zip WHERE VarName = 'p_pv_addr_zip,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_city WHERE VarName = 'p_pv_addr_city,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_state WHERE VarName = 'p_pv_addr_state,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_county WHERE VarName = 'p_pv_addr_county,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_country WHERE VarName = 'p_pv_addr_country,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_addr_mail WHERE VarName = 'p_pv_addr_mail,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_con_lname WHERE VarName = 'p_pv_con_lname,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_con_fname WHERE VarName = 'p_pv_con_fname,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_con_title WHERE VarName = 'p_pv_con_title,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_con_phone1 WHERE VarName = 'p_pv_con_phone1,' and  BatchId = @a_batch_id AND Module_Id = 7
					UPDATE dbo.GlobalVar set VarValue = @p_pv_con_ext1 WHERE VarName = 'p_pv_con_ext1,' and  BatchId = @a_batch_id AND Module_Id = 7

					SELECT @p_pv_stat_eff_date	=VarValue FROM GlobalVar(NOLOCK) WHERE VarName = 'p_pv_stat_eff_date,' and  BatchId = @a_batch_id AND Module_Id = 7
					SELECT @p_fc_assoc_eff		=VarValue FROM GlobalVar(NOLOCK) WHERE VarName = 'p_fc_assoc_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
					SELECT @p_fc_assoc_exp		=VarValue FROM GlobalVar(NOLOCK) WHERE VarName = 'p_fc_assoc_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
					SELECT @p_pv_lic_eff	    =VarValue FROM GlobalVar(NOLOCK) WHERE VarName = 'p_pv_lic_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
					SELECT @p_pv_lic_exp	    =VarValue FROM GlobalVar(NOLOCK) WHERE VarName = 'p_pv_lic_exp,' and  BatchId = @a_batch_id AND Module_Id = 7

                    BEGIN						
                        --DECLARE @SWV_cursor_var1 CURSOR;
                       -- DECLARE #SWV_cursor_var2 CURSOR;
                        BEGIN TRY
                 
                            SET @s_error = 'N';
                            SET @as_action_code = NULL;
                            
                            SET @i_pv_id = NULL;
                            
                            SET @i_fc_id = NULL;
                            
                            SET @as_pv_stat_eff = NULL;
                           
                               
                            SET @as_fcassoc_eff = NULL;
                           
                            SET @as_fcassoc_exp = NULL;
                            
                            SET @curr_pvstat_id = NULL;
                            SET @curr_pvstat = NULL;
                            SET @curr_pvstat_eff = NULL;
                            SET @curr_pvstat_exp = NULL;
                            SET @curr_assoc_id = NULL;
                            SET @curr_assoc_eff = NULL;
                            SET @curr_assoc_exp = NULL;
                            SET @tape_assoc_eff = NULL;
                            SET @tape_assoc_exp = NULL;
                            EXECUTE dbo.dlp_valid_pv @a_batch_id,
                                @d_valid_error OUTPUT, @d_error_descr OUTPUT,
                                @i_pv_id OUTPUT, @i_fc_id OUTPUT,
                                @as_pv_stat_eff OUTPUT, @as_fcassoc_eff OUTPUT,
                                @as_fcassoc_exp OUTPUT;
                            IF @d_valid_error < 0
                                BEGIN
                                    IF @d_valid_error <> 50000
                                        SET @d_error_descr = CAST(@d_valid_error AS VARCHAR)
                                            + ':' + @d_error_descr;
                                    RAISERROR(@d_error_descr,16,1);
         END;
                            ELSE
                              IF @d_valid_error = 0
                                    SET @s_error = 'Y';


	/*-- ACTION CODE:
		PA - Provider and FCPV Association Add
		PR - FCPV Association Reinstate
	--*/
                            SET @curr_pvstat = NULL;
                            /*
							SET @SWV_cursor_var1 = CURSOR  FOR SELECT pv_st_id, pv_status, eff_date, exp_date
		
               FROM dbo.pv_status (NOLOCK)
               WHERE pv_id = @i_pv_id
         ORDER BY pv_st_id DESC;
                            OPEN @SWV_cursor_var1;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @curr_pvstat_id,
                                @curr_pvstat, @curr_pvstat_eff,
                                @curr_pvstat_exp;
                            WHILE @@FETCH_STATUS = 0
							*/

							IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
							DROP TABLE #SWV_cursor_var2
                    CREATE TABLE #SWV_cursor_var2
                                (
                                  id INT IDENTITY ,
                                  pv_st_id INT ,
                                  pv_status CHAR(2) ,
                                  eff_date DATE ,
                                  exp_date DATE
                                );

                            INSERT  INTO #SWV_cursor_var2
                                    ( pv_st_id ,
                                      pv_status ,
										eff_date ,
                                      exp_date
                                    )
                                    SELECT  pv_st_id ,
                                            pv_status ,
                                            eff_date ,
                                            exp_date
                                    FROM    dbo.pv_status (NOLOCK)
                                    WHERE   pv_id = @i_pv_id
                                    ORDER BY pv_st_id DESC;


                            DECLARE @cur2_cnt INT ,
                                @cur2_i INT;

                            SET @cur2_i = 1;

				--Get the no. of records for the cursor
                  SELECT  @cur2_cnt = COUNT(1)
                            FROM    #SWV_cursor_var2;

                            WHILE ( @cur2_i <= @cur2_cnt )
                                BEGIN
                                    SELECT  @curr_pvstat_id = pv_st_id ,
                                            @curr_pvstat = pv_status ,
                                            @curr_pvstat_eff = eff_date ,
                                            @curr_pvstat_exp = exp_date
                                    FROM    #SWV_cursor_var2
                                    WHERE   id = @cur2_i;

                                    GOTO SWL_Label3;
                                    /*
									FETCH NEXT FROM @SWV_cursor_var1 INTO @curr_pvstat_id,
                                        @curr_pvstat, @curr_pvstat_eff,
                                        @curr_pvstat_exp;
										*/
                                    SET @cur2_i = @cur2_i + 1;
                                END;
                            SWL_Label3:
                            --CLOSE @SWV_cursor_var1;
                            IF ( @curr_pvstat IS NULL
                                 OR @curr_pvstat = ''
                               )
                                BEGIN
                                    SET @as_action_code = 'PA' ;
                                   
                                    
                                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                        @p_sir_id, @as_action_code,
                                        @as_pv_stat_eff;
                                END;
                            ELSE
              BEGIN
                                   
                         IF CONVERT(DATE, CONVERT(VARCHAR, @as_pv_stat_eff)) < @curr_pvstat_eff
									BEGIN
										 SET	@a_error_no = 300
    RAISERROR('Tape Provider Effective Date is before DataDental status eff date',16,1);
										END
                                    ELSE
                                        BEGIN
                                          
                                            IF CONVERT(DATE, CONVERT(VARCHAR, @as_pv_stat_eff)) < @curr_pvstat_exp
											BEGIN
												SET	@a_error_no = 305
       RAISERROR('Tape Provider Status Effective Date is before DataDental status exp date',16,1);
											END
                                            ELSE
                                                IF @curr_pvstat <> 'AC'
                                                    BEGIN
                                                        SET @as_action_code = 'PR';
                                                      
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                            @p_sir_id,
                                                            @as_action_code,
                                                            @as_pv_stat_eff;
                                                    END;
				
                                        END;
                                END;
		


	/*-- ACTION CODE:
		AA - Facility Provider Association Add
		AR - Facility Provider Association Reinstate
		AT - Facility Provider Association Terminate
		     (Existing or Missing)
		NC - No Change (no Facility Provider Association date change)
	--*/
                           
                            IF ( @as_action_code IS NULL
                                 OR @as_action_code = ''
                               )
                                BEGIN
                                    
                                    SET @tape_assoc_eff = CAST(@p_fc_assoc_eff AS DATE);
                                  
                                    SET @tape_assoc_exp = CAST(@p_fc_assoc_exp AS DATE);
									SET @curr_assoc_id = NULL;
                                    SET @curr_assoc_eff = NULL;
                                    SET @curr_assoc_exp = NULL;
                                   ;
                                    IF @i_fc_id IS NULL
                                        IF @tape_assoc_exp IS NOT NULL
										BEGIN
											SET	@a_error_no = 310
                                            RAISERROR('Missing Tape FCPV Association Eff Date while Exp Date is given',16,1);
										END
                                        ELSE
                                            BEGIN
                                                SET @as_action_code = 'NC' ;
                                              
                                                
                                                EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                     @p_sir_id, @as_action_code,
                                                    @as_fcassoc_eff;
                                            END;
			
                                    ELSE
                                        BEGIN
                                            /*
											SET #SWV_cursor_var2 = CURSOR  FOR SELECT fc_assoc_id, eff_date, exp_date
			
                     FROM dbo.fc_assoc (NOLOCK)
                     WHERE fc_id = @i_fc_id
                     AND pv_id = @i_pv_id
                     ORDER BY fc_assoc_id DESC;
                                            OPEN #SWV_cursor_var2;
                                            FETCH NEXT FROM #SWV_cursor_var2 INTO @curr_assoc_id,
                                                @curr_assoc_eff,
                                                @curr_assoc_exp;
                                            WHILE @@FETCH_STATUS = 0
											*/

												IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
											DROP TABLE #SWV_cursor_var3

                                            CREATE TABLE #SWV_cursor_var3
                                                (
                                   id INT IDENTITY ,
                                                  fc_assoc_id INT ,
                                        eff_date DATE ,
                                                  exp_date DATE
                                                );

                                   INSERT  INTO #SWV_cursor_var3
                                                    ( fc_assoc_id ,
                                                      eff_date ,
                                                      exp_date
                                                    )
                                                    SELECT  fc_assoc_id ,
                                                            eff_date ,
                                                            exp_date
                                                    FROM    dbo.fc_assoc (NOLOCK)
                                                    WHERE   fc_id = @i_fc_id
                                                            AND pv_id = @i_pv_id
                                                    ORDER BY fc_assoc_id DESC;


                                            DECLARE @cur3_cnt INT ,
                                                @cur3_i INT;

                                            SET @cur3_i = 1;

				--Get the no. of records for the cursor
                                            SELECT  @cur3_cnt = COUNT(1)
                                            FROM    #SWV_cursor_var3;

                                            WHILE ( @cur3_i <= @cur3_cnt )
                                                BEGIN
                                                    SELECT  @curr_assoc_id = fc_assoc_id ,
                                                            @curr_assoc_eff = eff_date ,
                                 @curr_assoc_exp = exp_date
     FROM    #SWV_cursor_var3
                                                    WHERE   id = @cur3_i;
                                                    GOTO SWL_Label4;
                                                    /*
													FETCH NEXT FROM #SWV_cursor_var2 INTO @curr_assoc_id,
                                             @curr_assoc_eff,
                                                        @curr_assoc_exp;
														*/
                                                    SET @cur3_i = @cur3_i + 1;
                                                END;
                                            SWL_Label4:
                                           -- CLOSE #SWV_cursor_var2;
                                            IF @curr_assoc_id IS NULL
                                                BEGIN
                             SET @as_action_code = 'AA';
                                                    
                                                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                        @p_sir_id,
                                                        @as_action_code,
                                                        @as_fcassoc_eff;
                                                END;
                                            ELSE
                                                IF @tape_assoc_eff < @curr_assoc_eff
												BEGIN
													SET	@a_error_no = 320
                                                    RAISERROR('Tape FCPV Association Eff Date is before DataDental FCPV Eff Date',16,1);
												END
                                                ELSE
                                       IF @tape_assoc_exp IS NULL
                                                        AND @curr_assoc_exp IS NULL
                                                  BEGIN
                                            SET @as_action_code = 'NC';
                           
                                                            EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                      @p_sir_id,
                                                              @as_action_code,
                                                              @as_fcassoc_eff;
                                                        END;
                                                    ELSE
                                                        IF @tape_assoc_exp IS NOT NULL
                                                            AND @curr_assoc_exp IS NULL
                                                            BEGIN
                                                              SET @as_action_code = 'AT';
    
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @p_sir_id,
                                                              @as_action_code,
                                                              @as_fcassoc_exp;
                                              END;
                                                        ELSE
                                                            IF @tape_assoc_exp IS NULL
                                                              AND @curr_assoc_exp IS NOT NULL
                                                              BEGIN
                                                              SET @as_action_code = 'AR' ;
                                                           
                                                              IF @curr_assoc_exp > CONVERT(DATE, CONVERT(VARCHAR, @as_fcassoc_eff))
                                                              BEGIN
                              
                EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @p_sir_id,
                                                              @as_action_code,
                                                              @curr_assoc_exp;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                             
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @p_sir_id,
                                                              @as_action_code,
                                                              @as_fcassoc_eff;
                                                              END;
                                            END;
                                                            ELSE
                                                              IF @tape_assoc_exp IS NOT NULL
                                                              AND @curr_assoc_exp IS NOT NULL
                                                              IF @tape_assoc_eff < @curr_assoc_eff
															  BEGIN
																SET	@a_error_no = 330
																RAISERROR('Tape FCPV Association Eff Date cannot reinstate a terminated record',16,1);
															  END
                                                              ELSE
                                            IF @tape_assoc_eff = @curr_assoc_eff
                                                   BEGIN
                                        SET @as_action_code = 'NC';
    
                                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                      @p_sir_id,
                                                              @as_action_code,
                                                              @as_fcassoc_eff;
                    END;
                                ELSE
                                                              BEGIN
                                                              SET @as_action_code = 'AR';
                                                             
                                                              IF @curr_assoc_exp > CONVERT(DATE, CONVERT(VARCHAR, @as_fcassoc_eff))
                                                              BEGIN
                                                              
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @p_sir_id,
                                                              @as_action_code,
                                                              @curr_assoc_exp;
                                                              END;
                                                              ELSE
                                        BEGIN
                                                              
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @p_sir_id,
                                                              @as_action_code,
															  @as_fcassoc_eff;
                                                              END;
                   END;
                 ELSE
                                                     BEGIN
                                                              SET @as_action_code = 'NC';
                  
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @p_sir_id,
                                                              @as_action_code,
                                                              @as_fcassoc_eff;
                                                              END;
                                        END;
                                END;
		
                            IF @s_error = 'Y'
                                BEGIN
                                    
									SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7

                                    SET @n_process_count = @n_process_count+ 1;

									UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
                                   
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'E' ,
                                            dls_facility_id = @i_fc_id ,
                                            dls_provider_id = @i_pv_id ,
                                            dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
                            ELSE
                                BEGIN
                                   SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
									SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7

             SET @n_process_count = @n_process_count+ 1;
                                   
                                    SET @n_succ_count = @n_succ_count + 1;

									UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
									UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7
                                   
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'P' ,
                                      dls_facility_id = @i_fc_id ,
                                  dls_provider_id = @i_pv_id ,
									 dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
		
						SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
					SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7

                            IF @n_process_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
									tot_fail_rec = CAST(@n_process_count AS INT)
                                        - CAST(@n_succ_count AS INT)
                                WHERE   bat_statistics_id = @i_statistics_id;
		
                           
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
		
                           
                        
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @pv_sp_id, @pv_sir_def_id, @p_sir_id, @a_error_no;
							IF @i_fatal <> 1
                                SET @s_error = 'Y';

								 IF @s_error = 'Y'
                                BEGIN
                                    
									SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7

                                    SET @n_process_count = @n_process_count+ 1;

									UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
                                   
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'E' ,
                                            dls_facility_id = @i_fc_id ,
                                            dls_provider_id = @i_pv_id ,
                                            dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
                            ELSE
                                BEGIN
                                   SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
									SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7

                                    SET @n_process_count = @n_process_count+ 1;
                                   
                                    SET @n_succ_count = @n_succ_count + 1;

									
								UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
								UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7
                                   
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'P' ,
                                      dls_facility_id = @i_fc_id ,
                                            dls_provider_id = @i_pv_id ,
									 dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
		
 END CATCH;
          END;
                   /*
				    FETCH NEXT FROM @cSIR INTO @p_sir_id, @p_alt_id,
                        @p_pv_tax_id, @p_pv_license, @p_pv_lic_state, @p_tin,
                        @p_pv_first_name, @p_pv_middle_init, @p_pv_last_name,
                        @p_discipline, @p_mal_car, @p_mal_pol_no, @p_mal_prac,
                        @p_mal_amt, @p_mal_amt_i, @p_mal_comnt, @p_dea_no,
                        @p_dea_cert_dt, @p_dea_exp_dt, @p_cds_no,
                        @p_cds_cert_dt, @p_cds_exp_dt, @p_cpr_cert_dt,
                        @p_cpr_exp_dt, @p_prim_fc, @p_school, @p_grd_date,
                        @p_degree, @p_ada_mbr, @p_district_no, @p_pv_dob,
                        @p_print_dir, @p_race, @p_gender, @p_num_yr_prac,
     @p_peer_rv, @p_vendor_id, @p_pv_stat_eff_date,
    @p_fc_assoc_fc_id, @p_fc_assoc_type, @p_fc_assoc_eff,
                        @p_fc_assoc_exp, @p_pv_lic_eff, @p_pv_lic_exp,
                        @p_pv_addr_type, @p_pv_addr_1, @p_pv_addr_2,
                        @p_pv_addr_zip, @p_pv_addr_city, @p_pv_addr_state,
                        @p_pv_addr_county, @p_pv_addr_country, @p_pv_addr_mail,
--		p_pv_con_type,
                        @p_pv_con_lname, @p_pv_con_fname, @p_pv_con_title,
    @p_pv_con_phone1, @p_pv_con_ext1, @p_pv_con_phone2,
                        @p_pv_con_ext2, @p_pv_con_fax, @p_pv_np_id;
						*/
                    SET @cur1_i = @cur1_i + 1;
                END;
          --  CLOSE @cSIR;
            IF @a_sir_id = 0
                BEGIN
                  
                    IF @x_has_term_date = 'N'
                        BEGIN
                           
                            SET @SWV_func_DLP_PV_MISSING_par0 = CONVERT(DATE, CONVERT(VARCHAR, @y_def_exp_date));
                            EXECUTE @i_error_no = dbo.dlp_pv_missing @a_batch_id,
                                @SWV_func_DLP_PV_MISSING_par0;
                            IF @i_error_no < 0
							BEGIN
								SET	@a_error_no = 9
                                RAISERROR('Error in Search Missing Records',16,1);
							END
					END;
                END;
	
            SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
			SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7

            SET @n_error_count = CAST(@n_process_count AS INT) - CAST(@n_succ_count AS INT);
            
	  ---------modified for conversion issue against CH001
            EXECUTE @SWV_dl_upd_statistics = dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @n_error_count;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                                   + @n_error_count ),
                                                 ' Failed to update statistics');
					IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 7 AND BatchId = @a_batch_id )
					BEGIN
						DELETE FROM GlobalVar WHERE Module_Id = 7 AND BatchId = @a_batch_id
					END
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish Pre-Processing for Batch ',
                                         @a_batch_id);
					IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 7 AND BatchId = @a_batch_id )
					BEGIN
						DELETE FROM GlobalVar WHERE Module_Id = 7 AND BatchId = @a_batch_id
					END
            RETURN;
        END TRY
        BEGIN CATCH
			IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 7 AND BatchId = @a_batch_id )
			BEGIN
				DELETE FROM GlobalVar WHERE Module_Id = 7 AND BatchId = @a_batch_id
			END
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
			SET @s_error_descr = ERROR_MESSAGE();
			SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



	--set debug file to "/tmp/dlp_bu_pv_assoc.trc";
	--trace on;

    END;