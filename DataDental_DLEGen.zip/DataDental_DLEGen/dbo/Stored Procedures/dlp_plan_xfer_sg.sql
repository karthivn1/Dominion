﻿CREATE PROCEDURE [dbo].[dlp_plan_xfer_sg]
    @d_member_id INT ,
    @def_group_id INT ,
    @def_msg_group_id INT ,
    @def_plan_id INT ,
    @d_tape_eff_date DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(2) = NULL OUTPUT
    
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @mb_dental_count INT;
        DECLARE @mb_vision_count INT;
        DECLARE @mb_pl_ins_type CHAR(2);
        DECLARE @i_group_id INT;
        DECLARE @i_plan_id INT;
        DECLARE @dd_dental_count INT;
        DECLARE @dd_vision_count INT;
        DECLARE @dd_pl_ins_type CHAR(2);
        --DECLARE @SWV_cursor_var1 CURSOR;
        SET NOCOUNT ON;
        SET @mb_dental_count = 0;
        SET @mb_vision_count = 0;
        SET @dd_dental_count = 0;
        SET @dd_vision_count = 0;


		DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 group_id INT,   
						 plan_id INT  
						 
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								group_id,   plan_id
                                )
								SELECT group_id, plan_id

   FROM dbo.rlmbgrpl (NOLOCK)
   WHERE member_id = @d_member_id
   AND group_id = @def_group_id
   AND exp_gr_pl IS NULL

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;
		/*
        SET @SWV_cursor_var1 = CURSOR  FOR SELECT group_id, plan_id

   FROM dbo.rlmbgrpl (NOLOCK)
   WHERE member_id = @d_member_id
   AND group_id = @def_group_id
   AND exp_gr_pl IS NULL;
        OPEN @SWV_cursor_var1;
        FETCH NEXT FROM @SWV_cursor_var1 INTO @i_group_id, @i_plan_id;
        WHILE @@FETCH_STATUS = 0
		*/
            WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @i_group_id= group_id, 
					@i_plan_id=plan_id
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;

                SELECT  @mb_pl_ins_type = ins_type
                FROM    dbo.[plan] (NOLOCK)
                WHERE   plan_id = @i_plan_id;
                
                IF @mb_pl_ins_type = 'D'
                    SET @mb_dental_count = @mb_dental_count + 1;
                ELSE
                    SET @mb_vision_count = @mb_vision_count + 1;
                --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_group_id, @i_plan_id;
				SET @cur1_i = @cur1_i + 1;
            END;
        --CLOSE @SWV_cursor_var1;
        SELECT  @dd_dental_count = dental_cnt ,
                @dd_vision_count = vision_cnt
        FROM    dbo.[group] (NOLOCK)
        WHERE   group_id = @def_msg_group_id;
        
        IF @dd_dental_count IS NULL
            SET @dd_dental_count = 1;

        IF @dd_vision_count IS NULL
            SET @dd_vision_count = 1;

        SELECT  @dd_pl_ins_type = ins_type
        FROM    dbo.[plan] (NOLOCK)
        WHERE   plan_id = @def_plan_id;
       
        IF @dd_pl_ins_type = 'D'
	   -- one plan type allowed, do Plan Change
	    -- multiple active records.  Terminate which?
	
		--return 1, "SR";   -- safe to add another plan 
		--ameeta changed "SR" action_code to "PA"
		   -- safe to add another plan 
            IF @mb_dental_count = 1
                AND @dd_dental_count = 1
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = 'PC';
                    RETURN;
                END;
            ELSE
                IF @mb_dental_count > 1
                    AND @mb_dental_count = @dd_dental_count
                    BEGIN
                        SET @SWP_Ret_Value = -1;
                        SET @SWP_Ret_Value1 = '';
 RETURN;
                    END;
                ELSE
                    IF ( @mb_dental_count + 1 ) <= @dd_dental_count
                        BEGIN
                            SET @SWP_Ret_Value = 1;
                            SET @SWP_Ret_Value1 = 'PA';
                            RETURN;
                        END;
                    ELSE
                        BEGIN
                            SET @SWP_Ret_Value = 0;
                            SET @SWP_Ret_Value1 = '';
                          RETURN;
                        END;     -- invalid count to add another record
	
        ELSE
            IF @mb_vision_count = 1
                AND @dd_vision_count = 1
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = 'PC';
                    RETURN;
                END;
            ELSE
                IF @mb_vision_count > 1
                    AND @mb_vision_count = @dd_vision_count
                    BEGIN
                        SET @SWP_Ret_Value = -1;
                        SET @SWP_Ret_Value1 = '';
                        RETURN;
                    END;
                ELSE
                    IF ( @mb_vision_count + 1 ) <= @dd_vision_count
                        BEGIN
                            SET @SWP_Ret_Value = 1;
                            SET @SWP_Ret_Value1 = 'PA';
                            RETURN;
                        END;
                    ELSE
                        BEGIN
                            SET @SWP_Ret_Value = 0;
                            SET @SWP_Ret_Value1 = '';
                            RETURN;
                        END;     -- invalid count to add another record
	
        SET NOCOUNT OFF;
    END;