﻿CREATE PROCEDURE [dbo].[dl_upd_statistics]
    @a_statistics_id INT ,
    @a_tot_rec INT ,
    @a_succ_rec INT ,
    @a_fail_rec INT
    
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/

        DECLARE @dt_current TIME(2);
        DECLARE @s_current CHAR(10);
        DECLARE @s_current1 CHAR(22);
        DECLARE @n_syscmd CHAR(1024);

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_desc VARCHAR(64);

        SET NOCOUNT ON;
        BEGIN TRY
            SELECT  @dt_current = GETDATE();

  --LET s_current = dt_current;
            --SET @s_current1 = CONVERT(VARCHAR, CONVERT(DATE, GETDATE())) + ' '
            --    + CONVERT(VARCHAR, @dt_current);

			SET @s_current1=FORMAT(GETDATE() , 'yyyy-MM-dd HH:mm:ss:ff');

            UPDATE  dbo.dl_bat_statistics
            SET     finish_time = @s_current1 ,
                    tot_record = @a_tot_rec ,
                    tot_success_rec = @a_succ_rec ,
                    tot_fail_rec = @a_fail_rec
            WHERE   bat_statistics_id = @a_statistics_id;
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_desc = ERROR_MESSAGE();
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



	--set debug file to "dl_current.trc";
	--trace on;

	--LET s_current1 = today || " " || extend(current, hour to fraction(2));

    END;