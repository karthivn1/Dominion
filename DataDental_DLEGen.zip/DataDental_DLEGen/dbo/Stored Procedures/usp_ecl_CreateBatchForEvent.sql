﻿-- =============================================
-- Author:		Karthikeyan
-- Create date: Jan 03 2017
-- Description:	Create a new batch for the event raised
-- =============================================
CREATE PROCEDURE [dbo].[usp_ecl_CreateBatchForEvent] 
	-- Add the parameters for the stored procedure here
	@eventType varchar(200),
	@batchParam varchar(100)=NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @EVENTID INT
	DECLARE @SUBMITTEDSTATUS INT
	DECLARE @INPROGRESSSTATUS INT
	SET @SUBMITTEDSTATUS =1
	SET @INPROGRESSSTATUS =3
	SELECT
		@EVENTID = event_id
	FROM dbo.[batch_event_master]
	WHERE event_type =  @eventType

	IF NOT EXISTS (SELECT 1 FROM [batch_process_details] WHERE event_id =  @EVENTID AND [status]= @INPROGRESSSTATUS)
	BEGIN
		INSERT INTO [batch_process_details] (event_id ,  status , created_date,batch_param) values (@EVENTID,@SUBMITTEDSTATUS,getdate(),@batchParam)
	END
    -- Insert statements for procedure here
	
END