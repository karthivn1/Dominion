﻿CREATE PROCEDURE [dbo].[eclaim_upd_status]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    


-- Modified 08/11/04 by JMK @ Dominion
-- eclaim modification D:5.3.02
-- 1. Changed trace file name
-- 2. Added "IGNORE" error code to initial
--    UPDATE eclaim_h SQL
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:33:33 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @Stat INT;
        DECLARE @ErrorCode CHAR(10);

        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;
        -- DECLARE @SWV_cursor_var1 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY

            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  error_code CHAR(10) ,
                  status_to_assign INT
                );
            
--set debug file to 'ec_upd_status.trc';
--trace on;

            SET @ErrorCode = '';
            SET @Stat = 0;
            
            UPDATE  dbo.eclaim_h
            SET     status = 1 ,
                    h_user = ORIGINAL_LOGIN() ,
                    h_datetime = GETDATE()
            WHERE   status = 0
                    AND ( ( error_code IS NULL
                            OR error_code = ''
                          )
                          OR error_code = ''
                        )
                    AND NOT EXISTS ( SELECT *
                                     FROM   dbo.eclaim_d (NOLOCK)
                                     WHERE  dbo.eclaim_d.eclaim_id = dbo.eclaim_h.eclaim_id
                                            AND error_code != 'OK'
                                            AND error_code != 'IGNORE' );
            
            INSERT  INTO @SWV_cursor_var1
                    ( error_code ,
                      status_to_assign
                    )
                    SELECT  error_code ,
                            status_to_assign
                    FROM    dbo.eclaim_matrix (NOLOCK)
                    WHERE   status_to_assign IS NOT NULL
                            AND status_to_assign > 0
                            AND level = 0;
			/*SET @SWV_cursor_var1 = CURSOR  FOR SELECT error_code, status_to_assign
      FROM dbo.eclaim_matrix (NOLOCK)
      WHERE status_to_assign IS NOT NULL
      AND status_to_assign > 0
      AND level = 0;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @ErrorCode, @Stat;
            WHILE @@FETCH_STATUS = 0 */
            DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
                    SELECT  @ErrorCode = error_code ,
                            @Stat = status_to_assign
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur_i;
                    UPDATE  dbo.eclaim_h
                    SET     status = @Stat ,
                            h_user = ORIGINAL_LOGIN()  ,
                            h_datetime = GETDATE()
                    WHERE   status = 0
                            AND error_code = @ErrorCode;
                    
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @ErrorCode, @Stat;
                    SET @cur_i = @cur_i + 1;
                END;
       -- CLOSE @SWV_cursor_var1;
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = 'Process Complete';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

----------------------------------------------------------------------
    END;