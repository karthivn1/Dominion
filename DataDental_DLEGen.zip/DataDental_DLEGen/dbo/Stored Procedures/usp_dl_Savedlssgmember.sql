﻿--drop proc usp_dl_Savedlssgmember
CREATE PROCEDURE [dbo].[usp_dl_Savedlssgmember] (@dlssgMember dbo.DlssgMember READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_sg_member 
					SET dls_batch_id = dsm.dls_batch_id
						  --,dls_sub_sir_id = dsm.dls_sub_sir_id
						  ,member_flag = dsm.member_flag
						  ,alt_id = dsm.alt_id
						  ,ssn = dsm.ssn
						  ,sub_ssn = dsm.sub_ssn
						  ,sub_alt_id = dsm.sub_alt_id
						  ,member_code = dsm.member_code
						  ,last_name = dsm.last_name
						  ,first_name = dsm.first_name
						  ,middle_init = dsm.middle_init
						  ,nameprefix = dsm.nameprefix
						  ,namesuffix = dsm.namesuffix
						  ,date_of_birth = dsm.date_of_birth
						  ,student_flag = dsm.student_flag
						  ,disable_flag = dsm.disable_flag
						  ,cobra_flag = dsm.cobra_flag
						  ,msg_alt_id = dsm.msg_alt_id
						  ,plan_dsp_name = dsm.plan_dsp_name
						  ,fc_alt_id = dsm.fc_alt_id
						  ,rate_code = dsm.rate_code
						  ,mb_gppl_eff_date = dsm.mb_gppl_eff_date
						  ,mb_fc_eff_date = dsm.mb_fc_eff_date
						  ,mb_term_date = dsm.mb_term_date
						  ,bank_account = dsm.bank_account
						  ,account_type = dsm.account_type
						  ,transit_route_nbr = dsm.transit_route_nbr
						  ,process_code = dsm.process_code
						  ,transaction_code = dsm.transaction_code
						  ,return_code = dsm.return_code
						  ,return_descr = dsm.return_descr
						  ,address1 = dsm.address1
						  ,address2 = dsm.address2
						  ,city = dsm.city
						  ,state = dsm.state
						  ,zip = dsm.zip
						  ,zipx = dsm.zipx
						  ,home_phone = dsm.home_phone
						  ,home_ext = dsm.home_ext
						  ,work_phone = dsm.work_phone
						  ,work_ext = dsm.work_ext
						  ,email = dsm.email
						  ,prod_alt_id = dsm.prod_alt_id
						  ,comm_scheme_id = dsm.comm_scheme_id
						  ,pd_type = dsm.pd_type
						  ,license_number = dsm.license_number
						  ,selling_period = dsm.selling_period
						  ,pdcomm_eff_date = dsm.pdcomm_eff_date
						  ,new_ssn = dsm.new_ssn
						  ,source_id = dsm.source_id
						  ,subnew_ssn = dsm.subnew_ssn
						  ,subsource_id = dsm.subsource_id
						  ,ext_id_col = dsm.ext_id_col
						  --,dls_member_id = dsm.dls_member_id
						  --,dls_subscriber_id = dsm.dls_subscriber_id
						  --,dls_msg_id = dsm.dls_msg_id
						  --,dls_group_id = dsm.dls_group_id
						  --,dls_plan_id = dsm.dls_plan_id
						  --,dls_facility_id = dsm.dls_facility_id
						  --,dls_producer_id = dsm.dls_producer_id
						  --,dls_action_code = dsm.dls_action_code
						  ,dls_sg_member.dls_status = CASE WHEN dsm.dls_status='E' OR dsm.dls_status='P' THEN 'V'
								ELSE dls_sg_member.dls_status END
						  --,dls_source = dsm.dls_source
						  ,msg_group_id = dsm.msg_group_id
						  ,plan_id = dsm.plan_id
						  ,facility_id = dsm.facility_id
						  ,producer_id = dsm.producer_id
						  ,sub_in_plan = dsm.sub_in_plan
						  ,pend_yn = dsm.pend_yn
						  ,pend_date = dsm.pend_date
						  ,eligibility_id = dsm.eligibility_id
						  --,dls_pend_action = dsm.dls_pend_action
				from @dlssgMember dsm
				WHERE dls_sg_member.dls_sir_id = dsm.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END