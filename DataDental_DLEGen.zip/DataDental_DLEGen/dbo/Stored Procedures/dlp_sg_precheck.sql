﻿CREATE PROCEDURE [dbo].[dlp_sg_precheck] @a_batch_id INT
    

/*error variable*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;

        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @n_error_count INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @d_int_test INT;

        DECLARE @dds_date_of_birth DATE;
        DECLARE @d_mb_age INT;
 -- 20131004$$ks make var global 
        DECLARE @d_date_of_birth DATE;

DECLARE @sg_sp_id integer;
DECLARE @sg_sir_def_id integer;
DECLARE @sg_sir_def_name varchar(14);
DECLARE @sg_proc_name varchar(14);
DECLARE @sg_config_id integer;
DECLARE @from_api smallint;
DECLARE @n_has_facility_id char(1);
DECLARE @n_multiple_plans char(1);
DECLARE @n_allow_pl_change char(1);
DECLARE @n_multiple_fc char(1);
DECLARE @n_allow_fc_change char(1);
DECLARE @n_def_eff_date char(10);
DECLARE @n_def_exp_date char(10);
DECLARE @n_has_term_date char(1);
DECLARE @d_def_eff_date date;
DECLARE @d_def_exp_date date;
DECLARE @s_dls_sir_id integer;
DECLARE @s_dls_sub_sir_id integer;
DECLARE @s_member_flag char(2);
DECLARE @s_alt_id char(20);
DECLARE @s_ssn char(11);
DECLARE @s_sub_ssn char(11);
DECLARE @s_sub_alt_id char(20);
DECLARE @s_member_code char(3);
DECLARE @s_last_name char(15);
DECLARE @s_first_name char(15);
DECLARE @s_middle_init char(1);
DECLARE @s_name_prefix char(5);
DECLARE @s_name_suffix char(5);
DECLARE @s_date_of_birth char(10);
DECLARE @s_student_flag char(1);
DECLARE @s_disable_flag char(1);
DECLARE @s_cobra_flag char(1);
DECLARE @s_msg_group_id integer ;
DECLARE @s_plan_id integer;
DECLARE @s_facility_id integer;
DECLARE @s_rate_code char(2);
DECLARE @s_mb_gppl_eff_date char(10);
DECLARE @s_mb_fc_eff_date char(10);
DECLARE @s_mb_term_date char(10);
DECLARE @s_bank_account char(25);
DECLARE @s_account_type char(2);
DECLARE @s_trans_rt_nbr char(9);
DECLARE @s_transaction_code char(2);
DECLARE @s_address1 char(30);
DECLARE @s_address2 char(30);
DECLARE @s_city char(30);
DECLARE @s_state char(2);
DECLARE @s_zip char(5);
DECLARE @s_zipx char(4);
DECLARE @s_home_phone char(10);
DECLARE @s_home_ext char(5);
DECLARE @s_work_phone char(10);
DECLARE @s_work_ext char(5);
DECLARE @s_email char(250);
DECLARE @s_producer_id integer;
DECLARE @s_comm_scheme_id char(5);
DECLARE @s_pd_type char(2);
DECLARE @s_license_number char(9);
DECLARE @s_selling_period char(1);
DECLARE @s_pdcomm_eff_date char(10);
DECLARE @t_new_ssn char(11);
DECLARE @t_src_id char(20);
DECLARE @t_subnew_ssn char(11);
DECLARE @t_subsrc_id char(20);
DECLARE @t_ext_id_col char(20);
DECLARE @n_ffs_plan integer;
DECLARE @s_msg_group_alt_id char(20);
DECLARE @s_plan_dsp_name char(30);
DECLARE @s_facility_alt_id char(20);
DECLARE @s_producer_alt_id char(20);
DECLARE @a_error INT

        
        DECLARE @s_has_micr VARCHAR(50);
        SET NOCOUNT ON;
        SET @sg_sp_id = 0;
		        
        SET @sg_sir_def_id = 0;
        
        SET @sg_sir_def_name = '';
        
        SET @sg_proc_name = '';
        
        SET @sg_config_id = 0;
        
        SET @from_api = 0;
        
        SET @n_has_facility_id = '';
        
        SET @n_multiple_plans = '';
 
      SET @n_allow_pl_change = '';
        
        SET @n_multiple_fc = '';
        
        SET @n_allow_fc_change = '';
        
        SET @n_def_eff_date = '';
        
        SET @n_def_exp_date = '';
        
        SET @n_has_term_date = '';
        
        SET @d_def_eff_date =NULL;
        
        SET @d_def_exp_date =NULL;
        
        SET @s_dls_sir_id = 0;
  
        SET @s_dls_sub_sir_id = 0;
        
        SET @s_member_flag = '';
        
        SET @s_alt_id = '';
        
        SET @s_ssn = '';
        
        SET @s_sub_ssn = '';
        
        SET @s_sub_alt_id = '';
        
        SET @s_member_code = '';
        
        SET @s_last_name = '';
        
        SET @s_first_name = '';
        
        SET @s_middle_init = '';
        
        SET @s_name_prefix = '';
        
        SET @s_name_suffix = '';
        
        SET @s_date_of_birth = '';
        
        SET @s_student_flag = '';
       
        SET @s_disable_flag = '';
       
        SET @s_cobra_flag = '';
        
        SET @s_msg_group_id = 0;
        
        SET @s_plan_id = 0;
        
        SET @s_facility_id = 0;
        
        SET @s_rate_code = '';
        
        SET @s_mb_gppl_eff_date = '';
        
        SET @s_mb_fc_eff_date = '';
        
        SET @s_mb_term_date = '';
        
        SET @s_bank_account = '';
       
        SET @s_account_type = '';
       
        SET @s_trans_rt_nbr = '';
        
        SET @s_transaction_code = '';
        
        SET @s_address1 = '';
        
        SET @s_address2 = '';
        
        SET @s_city = '';
        
        SET @s_state = '';
       
        SET @s_zip = '';
       
        SET @s_zipx = '';
        
        SET @s_home_phone = '';
       
        SET @s_home_ext = '';
       
        SET @s_work_phone = '';
        
        SET @s_work_ext = '';
        
        SET @s_email = '';
        
        SET @s_producer_id = 0;
        
        SET @s_comm_scheme_id = '';
       
        SET @s_pd_type = '';
       
        SET @s_license_number = '';
        
        SET @s_selling_period = '';
        
        SET @s_pdcomm_eff_date = '';
    
        SET @t_new_ssn = '';
    
        SET @t_src_id = '';
        
        SET @t_subnew_ssn = '';
       
        SET @t_subsrc_id = '';
        
        SET @t_ext_id_col = '';
        
        SET @n_ffs_plan = 0;
      
        SET @s_msg_group_alt_id = '';
      
		SET @s_plan_dsp_name = '';
       
        SET @s_facility_alt_id = '';
        
        SET @s_producer_alt_id = '';
       
        SET @s_has_micr = 'N' ;
        
		select @s_alt_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_ssn = VarValue from GlobalVar(NOLOCK) where VarName = 's_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_sub_ssn = VarValue from GlobalVar(NOLOCK) where VarName = 's_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_sub_alt_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_member_code = VarValue from GlobalVar(NOLOCK) where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_member_flag = VarValue from GlobalVar(NOLOCK) where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_date_of_birth = VarValue from GlobalVar(NOLOCK) where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 1
		select @from_api = VarValue from GlobalVar(NOLOCK) where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_bank_account = VarValue from GlobalVar(NOLOCK) where VarName = 's_bank_account' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_account_type = VarValue from GlobalVar(NOLOCK) where VarName = 's_account_type' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_trans_rt_nbr = VarValue from GlobalVar(NOLOCK) where VarName = 's_trans_rt_nbr' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_transaction_code = VarValue from GlobalVar(NOLOCK) where VarName = 's_transaction_code' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_plan_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_student_flag = VarValue from GlobalVar(NOLOCK) where VarName = 's_student_flag' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_disable_flag = VarValue from GlobalVar(NOLOCK) where VarName = 's_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_cobra_flag = VarValue from GlobalVar(NOLOCK) where VarName = 's_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_mb_gppl_eff_date = VarValue from GlobalVar(NOLOCK) where VarName = 's_mb_gppl_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_mb_fc_eff_date = VarValue from GlobalVar(NOLOCK) where VarName = 's_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_mb_term_date = VarValue from GlobalVar(NOLOCK) where VarName = 's_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_first_name = VarValue from GlobalVar(NOLOCK) where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_last_name = VarValue from GlobalVar(NOLOCK) where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_date_of_birth = VarValue from GlobalVar(NOLOCK) where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_msg_group_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_msg_group_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @sg_sp_id = VarValue from GlobalVar(NOLOCK) where VarName = 'sg_sp_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @sg_sir_def_id = VarValue from GlobalVar(NOLOCK) where VarName = 'sg_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_dls_sir_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 1
		 
		 IF ISNULL(@s_mb_gppl_eff_date ,'')<>''
		 SET @s_mb_gppl_eff_date = CAST(@s_mb_gppl_eff_date   AS DATE)

		 IF ISNULL(@s_mb_fc_eff_date ,'')<>''
		 SET @s_mb_fc_eff_date = CAST(@s_mb_fc_eff_date   AS DATE)

		 IF ISNULL(@s_mb_term_date ,'')<>''
		 SET @s_mb_term_date = CAST(@s_mb_term_date   AS DATE)

		 IF ISNULL(@s_date_of_birth ,'')<>''
		 SET @s_date_of_birth = CAST(@s_date_of_birth   AS DATE)
		 

		BEGIN TRY
            
            SET @s_error = 'N';
            
            IF ( @s_member_flag IS NULL
                 OR @s_member_flag = ''
               )
                OR LEN(@s_member_flag) = 0
				BEGIN
					SET @a_error= 1
					RAISERROR('Member Flag Is Missing',16,1);
				RETURN
				END
            ELSE
                BEGIN
                  
                    IF LEN(@s_member_flag) <> 2
					BEGIN
						SET @a_error= 2
                        RAISERROR('Invalid Member Flag Length',16,1);
					RETURN
				END
                END;
	
           
            IF ( @s_date_of_birth IS NULL
                 OR @s_date_of_birth = ''
               )
                OR LEN(@s_date_of_birth) = 0
				BEGIN
				SET @a_error= 28
                RAISERROR('Member Birthday Is Missing',16,1);
				RETURN
				END
            ELSE
                BEGIN
                    SET @a_error_no = 29;
                   
                    SET @d_date_of_birth = CAST(@s_date_of_birth AS DATE);
                    IF @d_date_of_birth >= CONVERT(DATE, GETDATE())
					BEGIN
						SET @a_error= 30
                        RAISERROR('Member Birthday Is on or after today',16,1);
						RETURN
				END
                    ELSE
                        SET @d_mb_age = YEAR(CONVERT(DATE, GETDATE()))
                            - YEAR(@d_date_of_birth);
                END;
	
	-- Single Group member lookup currently based on Alt ID 
	-- Have a parameter to decide look up basis
           
            IF ( ( ( @s_alt_id IS NULL
                     OR @s_alt_id = ''
                   )
                   OR LEN(@s_alt_id) = 0
                 )
                 AND @from_api = 0
               )
			   BEGIN
			   SET @a_error= 3
                RAISERROR('Member ALT ID Is Missing',16,1);
				RETURN
				END
            ELSE
                IF EXISTS ( SELECT  *
                            FROM    dbo.dls_sg_member (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND alt_id = @s_alt_id
                                    AND dls_source = 'F'
                                    AND sub_ssn <> @s_sub_ssn )
									BEGIN
									SET @a_error= 4
                    RAISERROR('Member ALT ID Is Not Unique in tape',16,1);
					RETURN
				END
		
	
            
            IF ( @s_ssn IS NULL
                 OR @s_ssn = ''
               )
                OR LEN(@s_ssn) = 0
				BEGIN
				SET @a_error= 6
                RAISERROR('Member SSN Is Missing',16,1);
				RETURN
				END
            ELSE
   BEGIN
           
                    IF LEN(@s_ssn) <> 11
					BEGIN
					SET @a_error= 7
                        RAISERROR('Invalid Member SSN Length',16,1);
					RETURN
				END
		
                    SET @a_error_no = 8;
                    
                    SET @d_int_test = SUBSTRING(@s_ssn, 2, 2);
                    
                    IF SUBSTRING(@s_ssn, 4, 1) <> '-'
					BEGIN
						SET @a_error= 9
                        RAISERROR('4th digit of Member SSN is not ''-''',16,1);
						RETURN
				END
		
SET @a_error_no = 10;
                    
                    SET @d_int_test = SUBSTRING(@s_ssn, 5, 2);
                    
                    IF SUBSTRING(@s_ssn, 7, 1) <> '-'
					BEGIN
					SET @a_error= 11
                        RAISERROR('7th digit of Member SSN is not ''-''',16,1);
					RETURN
				END
		
                    SET @a_error_no = 12;
                    
                    SET @d_int_test = SUBSTRING(@s_ssn, 8, 4);
                END;
	
            
            IF ( @s_sub_ssn IS NULL
                 OR @s_sub_ssn = ''
               )
                OR LEN(@s_sub_ssn) = 0
				BEGIN
				SET @a_error= 13
                RAISERROR('Subscriber SSN Is Missing',16,1);
				RETURN
				END
            ELSE
                BEGIN
                    
                    IF LEN(@s_sub_ssn) <> 11
					BEGIN
						SET @a_error= 14
                        RAISERROR('Invalid Subscriber SSN Length',16,1);
						RETURN
				END
		
                    SET @a_error_no = 15;
                    
                    SET @d_int_test = SUBSTRING(@s_sub_ssn, 2, 2);
                    
                    IF SUBSTRING(@s_sub_ssn, 4, 1) <> '-'
					BEGIN
					SET @a_error= 16
                        RAISERROR('4th digit of Subscriber SSN is not ''-''',16,1);
						RETURN
				END
		
                    SET @a_error_no = 17;
                    
                    SET @d_int_test = SUBSTRING(@s_sub_ssn, 5, 2);
                    
                    IF SUBSTRING(@s_sub_ssn, 7, 1) <> '-'
					BEGIN
					SET @a_error= 18
                        RAISERROR('7th digit of Subscriber SSN is not ''-''',16,1);
						RETURN
				END
		
                    SET @a_error_no = 19;
                    
                    SET @d_int_test = SUBSTRING(@s_sub_ssn, 8, 4);
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.dls_sg_member (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND member_flag = '00'
                                            AND member_code IN ( '10', '20' )
                                            AND ssn = @s_sub_ssn )
											BEGIN
											SET @a_error= 20
                        RAISERROR('Cannot find a subscriber SIR record based on Subscriber SSN',            16,1);
						RETURN
				END
                END;
	
            
            IF ( @s_member_code IS NULL
                 OR @s_member_code = ''
               )
                OR LEN(@s_member_code) = 0
				BEGIN
				SET @a_error= 23
                RAISERROR('Member Code Is Missing',16,1);
				RETURN
				END
            ELSE
                BEGIN
                   
                    IF @s_member_code NOT IN ( '10', '20', '30', '40', '50',
                                               '70' )
											   BEGIN
											   SET @a_error= 24
                        RAISERROR('Invalid Member Code',16,1);
						RETURN
				END
		
                    
                    IF @s_member_code IN ( '10', '20' )
                        BEGIN
                            
                            IF @s_member_flag <> '00'
							BEGIN
							SET @a_error= 25
                                RAISERROR('Member Code does not match up with Member Flag',16,1);
							RETURN
				END
     END;
                    ELSE
                       BEGIN
                            
                            IF @s_member_flag = '00'
							BEGIN
							SET @a_error= 25
                                RAISERROR('Member Code does not match up with Member Flag',16,1);
								RETURN
				END
                        END;
                END;
	
            
            IF ( ( ( @s_sub_alt_id IS NULL
                     OR @s_sub_alt_id = ''
                   )
                   OR LEN(@s_sub_alt_id) = 0
                 )
                 AND @from_api = 0
               )
			   BEGIN
			   SET @a_error= 21
                RAISERROR('Subscriber ALT ID Is Missing',16,1);
				RETURN
				END
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.dls_sg_member (NOLOCK)
                                WHERE   dls_batch_id = @a_batch_id
                                        AND member_flag = '00'
                                        AND member_code IN ( '10', '20' )
                                        AND alt_id = @s_sub_alt_id )
										BEGIN
										SET @a_error= 22
                    RAISERROR('Cannot find a subscriber SIR record based on Subscriber ALT ID',         16,1);
					RETURN
				END		
	
            
            IF ( @s_last_name IS NULL
                 OR @s_last_name = ''
               )
                OR LEN(@s_last_name) = 0
				BEGIN
				SET @a_error= 26
                RAISERROR('Member Last Name Is Missing',16,1);
				RETURN
				END
	
            
            IF ( @s_first_name IS NULL
                 OR @s_first_name = ''
            )
                OR LEN(@s_first_name) = 0
				BEGIN
				SET @a_error= 27
                RAISERROR('Member First Name Is Missing',16,1);
				RETURN
				END
	
            
            IF ( @s_student_flag IS NOT NULL
                 AND @s_student_flag <> ''
               )
                OR LEN(@s_student_flag) > 0
                BEGIN
                    
                    IF @s_student_flag NOT IN ( 'Y', 'N' )
					BEGIN
						SET @a_error= 31
                        RAISERROR('Invalid Student Flag value',16,1);
						RETURN
				END
                END;
	
            
            IF ( @s_disable_flag IS NOT NULL
                 AND @s_disable_flag <> ''
               )
                OR LEN(@s_disable_flag) > 0
                BEGIN
                    
                    IF @s_disable_flag NOT IN ( 'Y', 'N' )
					BEGIN
						SET @a_error= 32
                        RAISERROR('Invalid Disable Flag value',16,1);
						RETURN
				END
                END;
	
            
            IF ( @s_cobra_flag IS NOT NULL
                 AND @s_cobra_flag <> ''
               )
                OR LEN(@s_cobra_flag) > 0
                BEGIN
                    
                    IF @s_cobra_flag NOT IN ( 'A', 'P', 'Y', 'N' )
					BEGIN
					SET @a_error= 33
                        RAISERROR('Invalid Cobra Flag value',16,1);
						RETURN
				END
                END;
	
            
            IF @s_msg_group_id IS NULL
                OR @s_msg_group_id = 0
				BEGIN
				SET @a_error= 34
                RAISERROR('Tape Master Single Group ID is missing',16,1);
				RETURN
				END
	
/* 20131027$$ks -- this is no longer true
 * if exists (select * from dls_sg_member where dls_batch_id =
 * a_batch_id and alt_id = s_alt_id and msg_group_id <>
 * s_msg_group_id) then
 * 	RAISE EXCEPTION -746, 39, "Same member found in tape for a different Master Single Group";
 * end if
 */
	
            
            IF @s_plan_id IS NULL
                OR @s_plan_id = 0
				BEGIN
				SET @a_error= 42
                RAISERROR('Tape Plan ID is missing',16,1);
				RETURN
				END
	
            
            IF ( @s_mb_gppl_eff_date IS NULL
                 OR @s_mb_gppl_eff_date = ''
      )
                OR LEN(@s_mb_gppl_eff_date) = 0
				BEGIN
				SET @a_error= 52
                RAISERROR('Tape Member Group Plan Rate Eff Date is missing',16,1);
				RETURN
				END
            ELSE
                BEGIN
                    SET @a_error_no = 53;
                    
                    IF DATEPART(DAY, @s_mb_gppl_eff_date) <> 1
					BEGIN
					SET @a_error= 54
                        RAISERROR('Member Group Plan Rate Effective Date is not first of the month',            16,1);
						RETURN
				END
                END;
	
            
            IF ( @s_mb_fc_eff_date IS NULL
                 OR @s_mb_fc_eff_date = ''
               )
                OR LEN(@s_mb_fc_eff_date) = 0
				BEGIN
				SET @a_error= 62
                RAISERROR('Tape Member Facility Eff Date is missing',16,1);
				RETURN
				END
            ELSE
                BEGIN
                    SET @a_error_no = 63;
                    
                    IF DATEPART(DAY, @s_mb_fc_eff_date) <> 1
					BEGIN
					SET @a_error= 64
                        RAISERROR('Member Facility Effective Date is not first of the month',16,            1);
						RETURN
				END
                END;
	
            
            IF @s_mb_fc_eff_date < @s_mb_gppl_eff_date
			BEGIN
			SET @a_error= 75
                RAISERROR('Member Facility Effective Date is before Group Plan Rate Effective Date',16,1);
				RETURN
				END
		
           
            IF ( @s_mb_term_date IS NOT NULL
                 AND @s_mb_term_date <> ''
               )
                OR LEN(@s_mb_term_date) > 0
                BEGIN
                    SET @a_error_no = 76;
                    
                    IF DATEPART(DAY, @s_mb_term_date) <> 1
					BEGIN
					SET @a_error= 77
                        RAISERROR('Member Term Date is not first of the month',16,1);
						RETURN
				END
		
		
                    
                    IF @s_mb_term_date < @s_mb_gppl_eff_date
					BEGIN
						SET @a_error= 78
                        RAISERROR('Member Term Date is before Group Plan Rate Eff Date',16,1);
						RETURN
				END
		
                    
                    IF @s_mb_term_date < @s_mb_fc_eff_date
					BEGIN
						SET @a_error= 79
                        RAISERROR('Member Term Date is before Facility Eff Date',16,1);
						RETURN
				END
                END;
	
              IF @s_member_flag = '00'
	/* if d_bill_type is "AH" and new subscriber or micr info provided then validate */
                BEGIN
                    SET @s_has_micr = 'N';
                    
                    IF ( ( ( @s_bank_account IS NOT NULL
                             AND @s_bank_account <> ''
                           )
                           AND LEN(RTRIM(LTRIM(@s_bank_account))) > 0
                         )
           OR ( ( @s_account_type IS NOT NULL
                                AND @s_account_type <> ''
                              )
                              AND LEN(RTRIM(LTRIM(@s_account_type))) > 0
                            )
                         OR ( ( @s_trans_rt_nbr IS NOT NULL
                                AND @s_trans_rt_nbr <> ''
                              )
                              AND LEN(RTRIM(LTRIM(@s_trans_rt_nbr))) > 0
                            )
                         OR ( ( @s_transaction_code IS NOT NULL
                                AND @s_transaction_code <> ''
                              )
                              AND LEN(RTRIM(LTRIM(@s_transaction_code))) > 0
                            )
                       )
                        BEGIN
                            SET @s_has_micr = 'Y';
                           
                        END;
                    ELSE
                        BEGIN
                            SET @s_has_micr = 'N';
       
                        END;
		
        
                IF ( @s_has_micr = 'Y' )
                        BEGIN
                           
                            IF ( @s_bank_account IS NULL
                                 OR @s_bank_account = ''
  )
                                OR LEN(@s_bank_account) = 0
								BEGIN
								SET @a_error= 82
                                RAISERROR('Missing Bank Account info for ACH Billing Type',16,1);
								RETURN
				END
                            ELSE
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.dls_sg_member (NOLOCK)
                                            WHERE   dls_batch_id = @a_batch_id
                                                    AND alt_id = @s_sub_alt_id
                                                    AND bank_account <> @s_bank_account )
													BEGIN
													SET @a_error= 83
                                    RAISERROR('Different Bank Account found for the same family on the Tape',               16,1);
									RETURN
				END				
			
                            
                            IF ( ( @s_account_type IS NULL
                                   OR @s_account_type = ''
                                 )
                                 OR LEN(@s_account_type) = 0
                               )
							   BEGIN
							   SET @a_error= 85
                                RAISERROR('Missing Account Type info for ACH Billing Type',16,1);
								RETURN
				END
                            ELSE
                                IF NOT EXISTS ( SELECT  *
                                                FROM    dbo.typ_table (NOLOCK)
                                                WHERE   subsys_code = 'MB'
                                                        AND tab_name = 'ach_acc_type'
                                                        AND code = @s_account_type )
														BEGIN
														SET @a_error= 86
                                    RAISERROR('Invalid Account Type found',16,1);
									RETURN
				END
				
			
                            
                            IF ( @s_trans_rt_nbr IS NULL
                                 OR @s_trans_rt_nbr = ''
                               )
                                OR LEN(@s_trans_rt_nbr) = 0
								BEGIN
								SET @a_error= 87
                                RAISERROR('Missing Transit Route Number for ACH Billing Type',16,1);
								RETURN
				END
			
                           
                            IF ( @s_transaction_code IS NULL
                                 OR @s_transaction_code = ''
                               )
                                AND LEN(@s_transaction_code) = 0
								BEGIN
								SET @a_error= 88
                                RAISERROR('Missing Transaction Code info for ACH Billing Type',16,1);
								RETURN
				END
                            ELSE
                                IF NOT EXISTS ( SELECT  *
                                                FROM    dbo.typ_table (NOLOCK)
                                                WHERE   subsys_code = 'MB'
                                                        AND tab_name = 'ach_tran_code'
                                                        AND code = @s_transaction_code )
														BEGIN
														SET @a_error= 89
                                    RAISERROR('Invalid Transaction Code found',16,1);
									RETURN
				END
				
                        END;
                END;

            IF EXISTS ( SELECT  *
                        FROM    dbo.dls_sg_member (NOLOCK)
                        WHERE   dls_batch_id = @a_batch_id
                                AND member_flag = '00'
                                AND ssn = @s_sub_ssn
                                AND alt_id <> @s_sub_alt_id )
								BEGIN
								SET @a_error= 180
        RAISERROR('Different ALT ID found by Subscriber SSN',16,1);
				RETURN
				END
	
            IF EXISTS ( SELECT  *
      FROM    dbo.dls_sg_member (NOLOCK)
  WHERE   dls_batch_id = @a_batch_id
                                AND member_flag = '00'
                                AND ssn = @s_ssn
                                AND alt_id <> @s_alt_id
                                AND msg_group_id <> @s_msg_group_id )
								BEGIN
								SET @a_error= 181
                RAISERROR('One subscriber in multiple MSG with different ALT ID',16,1);
				RETURN
				END
	
            IF EXISTS ( SELECT  *
                        FROM    dbo.dls_sg_member (NOLOCK)
                        WHERE   dls_batch_id = @a_batch_id
                                AND member_flag = '00'
                                AND ssn = @s_ssn
                                AND alt_id <> @s_alt_id
                                AND plan_id <> @s_plan_id )
								BEGIN
								SET @a_error= 182
                RAISERROR('One subscriber in multiple plans with different ALT ID',16,         1);
				RETURN
				END
	
	
	
--trace off;
            IF @s_error = 'Y'
                RETURN -1;
            ELSE
                RETURN 1;
        END TRY
        BEGIN CATCH
           SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();

			IF ERROR_NUMBER() =50000
			EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @sg_sp_id,@sg_sir_def_id, @s_dls_sir_id, @a_error;

            RETURN -1; 
        END CATCH;
        SET NOCOUNT OFF;

--set debug file to "/tmp/dlp_valid_sg.trc";
--trace on;
    END;