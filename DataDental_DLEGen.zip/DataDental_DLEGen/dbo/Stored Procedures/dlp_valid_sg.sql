﻿CREATE PROCEDURE [dbo].[dlp_valid_sg]
    @a_batch_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(2) = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT ,
    @SWP_Ret_Value4 INT = NULL OUTPUT ,
    @SWP_Ret_Value5 INT = NULL OUTPUT ,
    @SWP_Ret_Value6 INT = NULL OUTPUT ,
    @SWP_Ret_Value7 INT = NULL OUTPUT ,
    @SWP_Ret_Value8 INT = NULL OUTPUT ,
    @SWP_Ret_Value9 DATE = NULL OUTPUT ,
    @SWP_Ret_Value10 DATE = NULL OUTPUT ,
    @SWP_Ret_Value11 DATE = NULL OUTPUT ,
    @SWP_Ret_Value12 CHAR(2) = NULL OUTPUT
    

/* 20121005$$ks - split up valid_sg so that subscriber is processed by dlp_valid_sg
 * 	and dependents are processed by dlp_valid_sgdep
 * /

/ *error variable*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/		DECLARE @s_has_micr CHAR(1);
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;

        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);

        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @n_error_count INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @d_int_test INT;
        DECLARE @mb_count INT;
        DECLARE @sub_count INT;
        DECLARE @dep_count INT;
        DECLARE @gp_count INT;
        DECLARE @n_g1 INT;
        DECLARE @n_g2 INT;
        DECLARE @n_g4 INT;
 -- 20131004$$ks make global
        DECLARE @has_producer CHAR(1);
        DECLARE @ls_mid_month CHAR(1);
        DECLARE @i_elig_opt SMALLINT;


        DECLARE @dds_last_name VARCHAR(15);
        DECLARE @dds_first_name VARCHAR(15);
        DECLARE @dds_middle_init CHAR(1);
        DECLARE @dds_name_prefix CHAR(5);
        DECLARE @dds_name_suffix CHAR(5);
        DECLARE @dds_date_of_birth DATE;
        DECLARE @d_last_name VARCHAR(15);
        DECLARE @d_first_name VARCHAR(15);
        DECLARE @d_date_of_birth DATE;

        DECLARE @d_msg_id INT;
        DECLARE @d_bill_type CHAR(2);
        DECLARE @d_gp_state CHAR(2);
        DECLARE @d_mbgrpl_id INT;
        DECLARE @d_ins_opt CHAR(3);
        DECLARE @d_ins_type CHAR(2);
        DECLARE @d_net_id INT;
        DECLARE @d_netfc_id INT;
        DECLARE @d_ovr_ride CHAR(1);
        DECLARE @d_netfc_eff DATE;
        DECLARE @d_netfc_exp DATE;
        DECLARE @d_np_id INT;
        DECLARE @d_np_eff DATE;
        DECLARE @d_np_exp DATE;
        DECLARE @d_zip_id INT;
        DECLARE @d_city CHAR(30);
        DECLARE @d_state CHAR(2);
        DECLARE @d_county CHAR(30);
        DECLARE @d_mb_age INT;
        DECLARE @d_fc_state CHAR(2);
        DECLARE @d_comm_scheme_id INT;
        DECLARE @fcpl_nnm_date DATE;
        DECLARE @fcpl_eff_date DATE;
        DECLARE @fcpl_exp_date DATE;
        DECLARE @as_sub_id INT;
        DECLARE @as_mb_id INT;
        DECLARE @as_msg_id INT;
        DECLARE @as_gp_id INT;
        DECLARE @as_pl_id INT;
        DECLARE @as_fc_id INT;
        DECLARE @as_gpplrt_eff DATE;
        DECLARE @as_fc_eff DATE;
        DECLARE @as_term_date DATE;
        DECLARE @as_pd_id INT;
        DECLARE @as_pdcomm_eff DATE;
        DECLARE @as_action_code CHAR(2);
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_eff_rt_date DATE;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @temp_action_code CHAR(2);
        DECLARE @t_member_id INT;
        DECLARE @t_alt_id CHAR(20);
        DECLARE @sg_sp_id INT;
		DECLARE @sg_sir_def_id INT;
		DECLARE @sg_sir_def_name varchar(14) ;
		DECLARE @sg_proc_name varchar(14) ;
		DECLARE @sg_config_id INT;
		DECLARE @n_has_facility_id char(1) ;
		DECLARE @n_multiple_plans char(1) ;
		DECLARE @n_allow_pl_change char(1) ;
		DECLARE @n_multiple_fc char(1) ;
		DECLARE @n_allow_fc_change char(1) ;
		DECLARE @n_def_eff_date char(10) ;
		DECLARE @n_def_exp_date char(10) ;
		DECLARE @n_has_term_date char(1) ;
		DECLARE @d_def_eff_date date ;
		DECLARE @d_def_exp_date date ;
		DECLARE @s_dls_sir_id INT;
		DECLARE @s_dls_sub_sir_id INT;
		DECLARE @s_member_flag char(2) ;
		DECLARE @s_alt_id char(20) ;
		DECLARE @s_ssn char(11) ;
		DECLARE @s_sub_ssn char(11) ;
		DECLARE @s_sub_alt_id char(20) ;
		DECLARE @s_member_code char(3) ;
		DECLARE @s_last_name char(15) ;
		DECLARE @s_first_name char(15) ;
		DECLARE @s_middle_init char(1) ;
		DECLARE @s_name_prefix char(5) ;
		DECLARE @s_name_suffix char(5) ;
		DECLARE @s_date_of_birth char(10) ;
		DECLARE @s_student_flag char(1) ;
		DECLARE @s_disable_flag char(1) ;
		DECLARE @s_cobra_flag char(1) ;
		DECLARE @s_msg_group_id INT ;
		DECLARE @s_plan_id INT;
		DECLARE @s_facility_id INT;
		DECLARE @s_rate_code char(2) ;
		DECLARE @s_mb_gppl_eff_date char(10) ;
		DECLARE @s_mb_fc_eff_date char(10) ;
		DECLARE @s_mb_term_date char(10) ;
		DECLARE @s_bank_account char(25) ;
		DECLARE @s_account_type char(2) ;
		DECLARE @s_trans_rt_nbr char(9) ;
		DECLARE @s_transaction_code char(2) ;
		DECLARE @s_address1 char(30) ;
		DECLARE @s_address2 char(30) ;
		DECLARE @s_city char(30) ;
		DECLARE @s_state char(2) ;
		DECLARE @s_zip char(5) ;
		DECLARE @s_zipx char(4) ;
		DECLARE @s_home_phone char(10) ;
		DECLARE @s_home_ext char(5) ;
		DECLARE @s_work_phone char(10) ;
		DECLARE @s_work_ext char(5) ;
		DECLARE @s_email char(250) ;
		DECLARE @s_producer_id INT;
		DECLARE @s_comm_scheme_id char(5) ;
		DECLARE @s_pd_type char(2) ;
		DECLARE @s_license_number char(9) ;
		DECLARE @s_selling_period char(1) ;
		DECLARE @s_pdcomm_eff_date char(10) ;
		DECLARE @t_new_ssn char(11) ;
		DECLARE @t_src_id char(20) ;
		DECLARE @t_subnew_ssn char(11) ;
		DECLARE @t_subsrc_id char(20) ;
		DECLARE @t_ext_id_col char(20) ;
		DECLARE @n_ffs_plan INT;
		DECLARE @s_msg_group_alt_id char(20) ;
		DECLARE @s_plan_dsp_name char(30) ;
		DECLARE @s_facility_alt_id char(20) ;
		DECLARE @s_producer_alt_id char(20) ;
		DECLARE @from_api smallint ;
		DECLARE @api_mbr_id INT;
		DECLARE @api_sub_id INT;
		DECLARE @api_plan_id INT;
		DECLARE @api_fc_id INT;
		DECLARE @api_msg_id INT;
		DECLARE @api_grp_id INT;

        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;
        --DECLARE @SWV_cursor_var3 CURSOR;
        --DECLARE @SWV_cursor_var4 CURSOR;
        --DECLARE @SWV_cursor_var5 CURSOR;
        --DECLARE @SWV_cursor_var6 CURSOR;
        --DECLARE @SWV_cursor_var7 CURSOR;
        --DECLARE @SWV_cursor_var8 CURSOR;
        --DECLARE @SWV_cursor_var9 CURSOR;
		
        SET NOCOUNT ON;
        SET @sg_sp_id = 0 ;
    
        SET @sg_sir_def_id = 0 ;
     
        SET @sg_sir_def_name = '' ;
     
        SET @sg_proc_name = '' ;
    
        SET @sg_config_id = 0 ;
    
        SET @s_has_micr = 'N' ;
   
        SET @n_has_facility_id = '' ;

        SET @n_multiple_plans = '' ;
  
        SET @n_allow_pl_change = '' ;
     
        SET @n_multiple_fc = '' ;
      
        SET @n_allow_fc_change = '' ;
     
        SET @n_def_eff_date = '' ;
    
        SET @n_def_exp_date = '' ;

        SET @n_has_term_date = '' ;
     
        SET @d_def_eff_date = NULL ;
    
        SET @d_def_exp_date = NULL ;

        SET @s_dls_sir_id = 0 ;
     
        SET @s_dls_sub_sir_id = 0 ;
       
        SET @s_member_flag = '' ;
      
        SET @s_alt_id = '' ;
       
        SET @s_ssn = '' ;
   
        SET @s_sub_ssn = '' ;

        SET @s_sub_alt_id = '' ;
  
        SET @s_member_code = '' ;
 
        SET @s_last_name = '' ;

        SET @s_first_name = '' ;
 
        SET @s_middle_init = '' ;
   
        SET @s_name_prefix = '' ;

        SET @s_name_suffix = '' ;
 
        SET @s_date_of_birth = '' ;

        SET @s_student_flag = '' ;
     
        SET @s_disable_flag = '' ;
   
        SET @s_cobra_flag = '' ;
    
        SET @s_msg_group_id = 0 ;
     
        SET @s_plan_id = 0 ;
    
        SET @s_facility_id = 0 ;
  
        SET @s_rate_code = '' ;
  
        SET @s_mb_gppl_eff_date = '' ;
   
        SET @s_mb_fc_eff_date = '' ;
  
        SET @s_mb_term_date = '' ;
   
        SET @s_bank_account = '' ;

        SET @s_account_type = '' ;

        SET @s_trans_rt_nbr = '' ;

        SET @s_transaction_code = '' ;

        SET @s_address1 = '' ;

        SET @s_address2 = '' ;

        SET @s_city = '' ;

        SET @s_state = '' ;

        SET @s_zip = '' ;

        SET @s_zipx = '' ;
   
        SET @s_home_phone = '' ;

        SET @s_home_ext = '' ;
 
        SET @s_work_phone = '' ;
   
        SET @s_work_ext = '' ;

        SET @s_email = '' ;

        SET @s_producer_id = 0 ;

        SET @s_comm_scheme_id = '' ;
  
        SET @s_pd_type = '' ;

        SET @s_license_number = '' ;

        SET @s_selling_period = '' ;

        SET @s_pdcomm_eff_date = '' ;
  
        SET @t_new_ssn = '' ;

        SET @t_src_id = '' ;
    
        SET @t_subnew_ssn = '' ;

        SET @t_subsrc_id = '' ;

        SET @t_ext_id_col = '' ;
  
        SET @n_ffs_plan = 0 ;

        SET @s_msg_group_alt_id = '' ;
      
        SET @s_plan_dsp_name = '' ;

        SET @s_facility_alt_id = '' ;

        SET @s_producer_alt_id = '' ;

        SET @from_api = 0 ;
     
        SET @api_mbr_id = 0 ;

        SET @api_sub_id = 0 ;

        SET @api_plan_id = 0 ;
    
        SET @api_fc_id = 0 ;

        SET @api_msg_id = 0 ;

        SET @api_grp_id = 0 ;
    
        BEGIN TRY
           
            SET @s_error = 'N';
            SET @mb_count = 0;
            SET @sub_count = 0;
            SET @dep_count = 0;
            SET @a_error_no = 0;
            SET @as_sub_id = NULL;
            SET @as_mb_id = NULL;
            SET @as_msg_id = NULL;
            SET @as_gp_id = NULL;
            SET @as_pl_id = NULL;
            SET @as_fc_id = NULL;
            SET @as_gpplrt_eff = NULL;
            SET @as_fc_eff = NULL;
            SET @as_term_date = NULL;
            SET @as_pd_id = NULL;
            SET @as_pdcomm_eff = NULL;
            SET @as_action_code = NULL;
            SET @temp_action_code = NULL;
            SET @s_has_micr = NULL ;
            
            SET @has_producer = NULL;
            SET @n_g1 = 0;
            SET @n_g2 = 0;
            SET @n_g4 = 0;

/* 20131004$$ks Removed code already tested in dlp_sg_precheck
 */

                  select @api_fc_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='api_fc_id'
                  select @api_grp_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='api_grp_id'
                  select @api_mbr_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='api_mbr_id'
                  select @api_msg_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='api_msg_id'
                  select @api_plan_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='api_plan_id'
                  select @api_sub_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='api_sub_id'
                  select @from_api = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='from_api'
                  select @s_account_type = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_account_type'
                  select @s_address1 = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_address1'
                  select @s_address2 = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_address2'
                  select @s_alt_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_alt_id'
                  select @s_bank_account = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_bank_account'
                  select @s_city = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_city'
                  select @s_cobra_flag = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_cobra_flag'
                  select @s_comm_scheme_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_comm_scheme_id'
                  select @s_date_of_birth = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_date_of_birth'
                  select @s_disable_flag = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_disable_flag'
                  select @s_dls_sir_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_dls_sir_id'
                  select @s_email = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_email'
                  select @s_facility_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_facility_id'
                  select @s_first_name = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_first_name'
                  select @s_home_ext = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_home_ext'
                  select @s_home_phone = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_home_phone'
                  select @s_last_name = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_last_name'
                  select @s_license_number = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_license_number'
                  select @s_mb_fc_eff_date = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_mb_fc_eff_date'
                  select @s_mb_gppl_eff_date = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_mb_gppl_eff_date'
                  select @s_mb_term_date = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_mb_term_date'
                  select @s_member_code = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_member_code'
                  select @s_member_flag = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_member_flag'
                  select @s_msg_group_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_msg_group_id'
                  select @s_pd_type = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_pd_type'
                  select @s_pdcomm_eff_date = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_pdcomm_eff_date'
                  select @s_plan_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_plan_id'
                  select @s_producer_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_producer_id'
                  select @s_rate_code = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_rate_code'
                  select @s_selling_period = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_selling_period'
                  select @s_ssn = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_ssn'
                  select @s_state = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_state'
                  select @s_student_flag = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_student_flag'
                  select @s_sub_alt_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_sub_alt_id'
                  select @s_sub_ssn = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_sub_ssn'
                  select @s_trans_rt_nbr = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_trans_rt_nbr'
                  select @s_transaction_code = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_transaction_code'
                  select @s_work_ext = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_work_ext'
                  select @s_work_phone = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_work_phone'
                  select @s_zip = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='s_zip'
                  select @sg_sir_def_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='sg_sir_def_id'
                  select @sg_sp_id = VarValue from GlobalVar (nolock) where  BatchId = @a_batch_id AND Module_Id = 1 and VarName='sg_sp_id'
			
			
            
            IF ( @s_member_flag != '00' )
                BEGIN
                    SET @s_error_descr = 'Member Flag must be 00 to be processed by valid_sg';
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_error_descr;
                    SET @SWP_Ret_Value2 = @as_action_code;
                    SET @SWP_Ret_Value3 = @as_sub_id;
                    SET @SWP_Ret_Value4 = @as_mb_id;
                    SET @SWP_Ret_Value5 = @as_msg_id;
                    SET @SWP_Ret_Value6 = @as_gp_id;
                    SET @SWP_Ret_Value7 = @as_pl_id;
                    SET @SWP_Ret_Value8 = @as_fc_id;
                    SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                    SET @SWP_Ret_Value10 = @as_fc_eff;
                    SET @SWP_Ret_Value11 = @as_term_date;
                    
                    SET @SWP_Ret_Value12 = @s_rate_code;
                    RETURN;
                END;
	
            
            SET @d_date_of_birth = CAST(@s_date_of_birth AS DATE);
            SET @d_mb_age = YEAR(CONVERT(DATE, GETDATE())) - YEAR(@d_date_of_birth);
            
            IF @from_api = 1
                BEGIN
   
                    SET @as_sub_id = @api_sub_id;
                    
                    SET @as_mb_id = @api_mbr_id;

                    IF @as_sub_id = 0
                        SET @sub_count = 0;
                    ELSE
                        SET @sub_count = 1;
		
                    IF @as_mb_id = 0
                        SET @mb_count = 0;
                    ELSE
                        SET @mb_count = 1;
                END;
	
	/* 20131004$$ks CODE MOVED FROM BELOW
	 * Before looking for member lets verify that 
	 * dates, msg, plan and facility (if needed) are valid
	 */
            
         
            IF ( @s_mb_gppl_eff_date IS NULL
                 OR @s_mb_gppl_eff_date = ''
               )
                OR LEN(@s_mb_gppl_eff_date) = 0
				BEGIN
				SET @a_error_no = 52
                RAISERROR('Tape Member Group Plan Rate Eff Date is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				
				END
            ELSE
                BEGIN
                    SET @a_error_no = 53;
                    
                    SET @as_gpplrt_eff = CAST(@s_mb_gppl_eff_date AS DATE);
                END;
	
            
            IF ( @s_mb_fc_eff_date IS NULL
                 OR @s_mb_fc_eff_date = ''
               )
                OR LEN(@s_mb_fc_eff_date) = 0
				BEGIN
				SET @a_error_no = 62
                RAISERROR('Tape Member Facility Eff Date is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
            ELSE
                BEGIN
                    SET @a_error_no = 63;
                    
                    SET @as_fc_eff = CAST(@s_mb_fc_eff_date AS DATE);
                END;
	
            
            IF ( @s_mb_term_date IS NOT NULL
                 AND @s_mb_term_date <> ''
               )
                OR LEN(@s_mb_term_date) > 0
                BEGIN
                    SET @a_error_no = 76;
                    
                    SET @as_term_date = CAST(@s_mb_term_date AS DATE);
                END;
	
            
            IF @from_api = 1
                BEGIN
                    
                    SET @s_msg_group_id = @api_msg_id ;
    
				IF @api_grp_id > 0
				BEGIN
                            
                            IF @api_msg_id = @api_grp_id
                                BEGIN
                                    SET @api_grp_id = 0 ;
                                 
                                END;
                            ELSE
                                IF EXISTS ( SELECT  group_id
                                            FROM    dbo.[group] (NOLOCK)
                                            WHERE   group_type = 'SG'
                                                    AND group_parent = @api_msg_id
                                                    AND group_id = @api_grp_id )
                                    BEGIN
                                        
                                        SET @as_gp_id = @api_grp_id;
                                    END;
				
                        END;
                END;
	
          
            IF @s_msg_group_id IS NULL
                OR @s_msg_group_id = 0
				BEGIN
				SET @a_error_no = 34
                RAISERROR('Tape Master Single Group ID is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
            ELSE
	-- the code below validates the msg and set as_msg_id and d_bill_type
                BEGIN
                   
              SELECT  @as_msg_id = group_id ,
                            @d_bill_type = bill_type
                    FROM    dbo.[group] (NOLOCK)
                    WHERE   group_id = @s_msg_group_id
                            AND group_type = 'MS';
														                   
                    IF @as_msg_id IS NULL
					BEGIN
					SET @a_error_no = 36
                        RAISERROR('Missing Master Single Group by Group ID',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.group_status (NOLOCK)
                                    WHERE   group_id = @as_msg_id
                                            AND group_status = 'A4'
                                            AND exp_date IS NULL )
											BEGIN
										SET @a_error_no = 37	
                        RAISERROR('Master Single Group is not active',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.address (NOLOCK)
                                    WHERE   subsys_code = 'GP'
                                            AND sys_rec_id = @as_msg_id
                                            AND addr_type = 'L' )
											BEGIN
											SET @a_error_no = 38
                        RAISERROR('Missing MSG Location Address record',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
                END;
	/* 20131003$$ks This is no longer an error 
	 * if exists (select * from dls_sg_member where dls_batch_id =
	 *  a_batch_id and alt_id = s_alt_id and msg_group_id <> s_msg_group_id) then
	 * RAISE EXCEPTION -746, 39, "Same member found in tape for a different MSG";
	 * end if
	 */
	
            
            IF @from_api = 1
                BEGIN
      
				SET @s_plan_id = @api_plan_id ;
                    
                END;
	
          
            IF @s_plan_id IS NULL
                OR @s_plan_id = 0
				BEGIN
				SET @a_error_no = 42
                RAISERROR('Tape Plan ID is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
            ELSE
	-- the logic below validates the plan_id and 
	-- sets as_pl_id, d_ins_opt, d_ins_type, ls_mid_month, i_elig_opt
                BEGIN
                    SET @a_error_no = 43;
                    SELECT  @as_pl_id = plan_id ,
                            @d_ins_opt = ins_opt ,
                            @d_ins_type = ins_type
                    FROM    dbo.[plan] (NOLOCK)
                    WHERE   plan_id = @s_plan_id;
                   
                    IF @as_pl_id IS NULL
					BEGIN
					SET @a_error_no = 44
          RAISERROR('Missing Plan record by Plan ID on the tape',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
					
                    IF NOT EXISTS ( SELECT  *
					FROM    dbo.rel_gppl (NOLOCK)
                                    WHERE   group_id = @as_msg_id
                                            AND plan_id = @as_pl_id
                                            AND exp_date IS NULL )
										BEGIN
										SET @a_error_no = 45
                        RAISERROR('Missing active MSG and Plan relationship',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    SET @ls_mid_month = 'N';

					DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 elig_opt INT
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								elig_opt
                                )
								SELECT b.elig_opt 
         FROM dbo.rel_gppl b (NOLOCK)
         WHERE b.group_id = @as_msg_id
         AND b.plan_id = @as_pl_id AND exp_date IS NULL;

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;


					/*
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT b.elig_opt 
         FROM dbo.rel_gppl b (NOLOCK)
         WHERE b.group_id = @as_msg_id
         AND b.plan_id = @as_pl_id AND exp_date IS NULL;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_elig_opt;
                    WHILE @@FETCH_STATUS = 0
					*/
                        WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @i_elig_opt=elig_opt
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;

                            IF @i_elig_opt = 0
                                BEGIN
                                    SET @ls_mid_month = 'N';
                                    GOTO SWL_Label6;
                                END;
                            ELSE
                                BEGIN
                                    SET @ls_mid_month = 'Y';
                                    GOTO SWL_Label6;
                                END;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_elig_opt;
							SET @cur1_i = @cur1_i + 1;
                        END;
                    SWL_Label6:
                    --CLOSE @SWV_cursor_var1;
                END;
	
           
            IF @from_api = 1
                BEGIN
                    
  SET @s_facility_id = @api_fc_id ;
                   
                END;
	
            IF ( @d_ins_opt IS NOT NULL
                 AND @d_ins_opt <> ''
               )
                AND @d_ins_opt IN ( 'HMO', 'RFS' )
                BEGIN
                   
                    SET @as_fc_id = @s_facility_id;
                END;
	
                        
            IF @ls_mid_month = 'N'
                AND ( DATEPART(DAY, @s_mb_gppl_eff_date) != 1
                      OR DATEPART(DAY, @s_mb_fc_eff_date) != 1
                    )
					BEGIN
					SET @a_error_no = 134
                RAISERROR('Group/plan does not allow mid month dates',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
            IF EXISTS ( SELECT  *
                        FROM    dbo.group_status (NOLOCK)
                        WHERE   group_id = @as_msg_id
                                AND group_status = 'A4'
                                AND eff_date > @as_gpplrt_eff
                                AND exp_date IS NULL )
								BEGIN
								SET @a_error_no = 61
                RAISERROR('Tape Mbr Grp Pl Rt EffDt before MSG group status effdate',16,         1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
            IF ( @as_fc_id IS NOT NULL
          AND @as_fc_id > 0
            )
                BEGIN
                    IF EXISTS ( SELECT  *
                                FROM    dbo.fcstat (NOLOCK)
                                WHERE   facility_id = @as_fc_id
             AND status = 'AC'
                                        AND eff_date > @as_fc_eff
                                        AND exp_date IS NULL )
										BEGIN
										SET @a_error_no = 65
                        RAISERROR('Tape Mbr FC EffDate is before DDS FC status eff date',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    IF EXISTS ( SELECT  *
                                FROM    dbo.fcstat (NOLOCK)
                                WHERE   facility_id = @as_fc_id
                                        AND status = 'TR'
                                        AND eff_date <= @as_fc_eff
                                        AND ( exp_date IS NULL
                                              OR @as_fc_eff < exp_date
                                            ) )
											BEGIN
											SET @a_error_no = 66
                        RAISERROR('Tape Mbr FC Effective Date is in Terminate Status',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
                END;
	
                            DECLARE @SWV_cursor_var2 TABLE
                        (
                         id INT IDENTITY ,
						rate_code CHAR(2)
       );
                          INSERT  INTO @SWV_cursor_var2
                                ( 
								rate_code
                                )
								SELECT rate_code  FROM dbo.group_cap_rate (NOLOCK)
      WHERE group_id = @as_msg_id
      AND plan_id = @as_pl_id
      AND eff_date <= CAST(@s_mb_gppl_eff_date AS DATE)
      AND (exp_date IS NULL OR exp_date > CAST(@s_mb_gppl_eff_date AS DATE));

	  DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
                        FROM  @SWV_cursor_var2;

	/*
          SET @SWV_cursor_var2 = CURSOR  FOR SELECT rate_code  FROM dbo.group_cap_rate (NOLOCK)
   WHERE group_id = @as_msg_id
      AND plan_id = @as_pl_id
      AND eff_date <= @s_mb_gppl_eff_date AS DATE)
      AND (exp_date IS NULL OR exp_date > @s_mb_gppl_eff_date AS DATE));
            OPEN @SWV_cursor_var2;
            FETCH NEXT FROM @SWV_cursor_var2 INTO @n_rate_code;
            WHILE @@FETCH_STATUS = 0
			*/
                WHILE ( @cur2_i <= @cur2_cnt )
            BEGIN
			SELECT  @n_rate_code=rate_code
					FROM @SWV_cursor_var2
            WHERE   id = @cur2_i;

                    GOTO SWL_Label7;
                    --FETCH NEXT FROM @SWV_cursor_var2 INTO @n_rate_code;
					SET @cur2_i = @cur2_i + 1;
                END;
            SWL_Label7:
            --CLOSE @SWV_cursor_var2;
            IF ( @n_rate_code IS NULL
                 OR @n_rate_code = ''
               )
			   BEGIN
			   SET @a_error_no = 237
                RAISERROR('Sub has no active rate code',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
            IF EXISTS ( SELECT  *
                        FROM    dbo.rel_gppl (NOLOCK)
                        WHERE   group_id = @as_msg_id
                                AND plan_id = @as_pl_id
                                AND eff_date > @as_gpplrt_eff
                                AND exp_date IS NULL )
								BEGIN
								SET @a_error_no = 57
                RAISERROR('Tape Mbr Group Plan Rate EffDate before group plan effdate',         0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
/* 20131003$$ks - END of MOVED CODE
 * at this point we should have the 
 * correct as_msg_id, as_pl_id 
 * and valid group plan and fc effective dates
 */
          
            IF @api_sub_id = 0
                OR @api_mbr_id = 0
                OR @from_api = 0 --allow DL to verify this is new Sub
                BEGIN
     
 IF ( @s_alt_id <> @s_sub_alt_id )
					BEGIN
					SET @a_error_no = 151
                        RAISERROR('SIR Alt ID and SUB Alt ID do not match',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    SET @dep_count = 0;

					DECLARE @SWV_cursor_var3 TABLE
                        (
                        id INT IDENTITY ,
						member_id INT, 
						family_id INT, 
						last_name CHAR(15),
						first_name CHAR(15), 
						middle_init CHAR, 
						date_of_birth DATE
                        );
                          INSERT  INTO @SWV_cursor_var3
                                ( 
								member_id, family_id, last_name, first_name, middle_init, date_of_birth
                                )
								SELECT member_id, family_id, last_name, first_name, middle_init, date_of_birth
			
         FROM dbo.member (NOLOCK)
         WHERE alt_id = @s_alt_id AND member_id = family_id;

	  DECLARE @cur3_cnt INT ,
                            @cur3_i INT;

                        SET @cur3_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur3_cnt = COUNT(1)
                        FROM  @SWV_cursor_var3;

					/*
                    SET @SWV_cursor_var3 = CURSOR  FOR SELECT member_id, family_id, last_name, first_name, middle_init, date_of_birth
			
         FROM dbo.member (NOLOCK)
         WHERE alt_id = @s_alt_id AND member_id = family_id;
                    OPEN @SWV_cursor_var3;
                    FETCH NEXT FROM @SWV_cursor_var3 INTO @as_mb_id,
                        @as_sub_id, @dds_last_name, @dds_first_name,
                        @dds_middle_init, @dds_date_of_birth;
                    WHILE @@FETCH_STATUS = 0
					*/

                        WHILE ( @cur3_i <= @cur3_cnt )
         BEGIN
			SELECT  @as_mb_id= member_id,
                    @as_sub_id= family_id,
					@dds_last_name= last_name, 
					@dds_first_name= first_name,
                    @dds_middle_init= middle_init, 
					@dds_date_of_birth= date_of_birth
					FROM @SWV_cursor_var3
            WHERE   id = @cur3_i;

                            SET @mb_count = @mb_count + 1;
                            SET @sub_count = @sub_count + 1;
                            --FETCH NEXT FROM @SWV_cursor_var3 INTO @as_mb_id,
                            --    @as_sub_id, @dds_last_name, @dds_first_name,
                            --    @dds_middle_init, @dds_date_of_birth;
							SET @cur3_i = @cur3_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var3;
					
                    IF @mb_count = 1
                        BEGIN
                          
                            IF @dds_last_name <> @s_last_name
							BEGIN
							SET @a_error_no = 150
                                RAISERROR('Last Name mismatch for existing member',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
							IF @i_fatal <> 1 
							SET @s_error = 'Y';
							END
			
				                           
                            IF @dds_first_name <> @s_first_name
							BEGIN
							SET @a_error_no = 151
                                RAISERROR('First Name mismatch for existing member',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
			
                            IF @d_date_of_birth != '01/01/1900'
                                AND @d_date_of_birth <> @dds_date_of_birth
								BEGIN
								SET @a_error_no = 152
                                RAISERROR('Date of Birth mismatch for existing member',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
				--let n_g1 = 1; DOB is part of validation should not change at this time
                        END;
		
                    IF @mb_count > 1
                        BEGIN
                            SET @a_error_no = 5;
   SET @mb_count = 0;
                            SET @dep_count = 0;

						DECLARE @SWV_cursor_var4 TABLE
                        (
                         id INT IDENTITY ,
						 member_id INT, 
						 family_id INT
                     );
                          INSERT INTO @SWV_cursor_var4
             ( 
								member_id, family_id
                                )
								SELECT member_id, family_id 
            FROM dbo.member (NOLOCK)
            WHERE alt_id = @s_alt_id
            AND member_id = family_id
            AND last_name = @s_last_name
            AND first_name = @s_first_name
            AND ((date_of_birth = @d_date_of_birth
    AND @d_date_of_birth != '01/01/1900' AND date_of_birth != '01/01/1900')
            OR (@d_date_of_birth = '01/01/1900' OR date_of_birth = '01/01/1900'))

	  DECLARE @cur4_cnt INT ,
                            @cur4_i INT;

                        SET @cur4_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur4_cnt = COUNT(1)
                        FROM  @SWV_cursor_var4;

							/*
                            SET @SWV_cursor_var4 = CURSOR  FOR SELECT member_id, family_id 
            FROM dbo.member (NOLOCK)
            WHERE alt_id = @s_alt_id
            AND member_id = family_id
            AND last_name = @s_last_name
            AND first_name = @s_first_name
            AND ((date_of_birth = @d_date_of_birth
            AND @d_date_of_birth != '01/01/1900' AND date_of_birth != '01/01/1900')
            OR (@d_date_of_birth = '01/01/1900' OR date_of_birth = '01/01/1900'));
                   OPEN @SWV_cursor_var4;
                            FETCH NEXT FROM @SWV_cursor_var4 INTO @as_mb_id,
                                @as_sub_id;
                            WHILE @@FETCH_STATUS = 0
							*/
                                WHILE ( @cur4_i <= @cur4_cnt )
            BEGIN
			SELECT @as_mb_id= member_id,
                   @as_sub_id= family_id
					FROM @SWV_cursor_var4
            WHERE   id = @cur4_i;

                                    SET @mb_count = @mb_count + 1;
                                    SET @sub_count = @sub_count + 1;
                                    --FETCH NEXT FROM @SWV_cursor_var4 INTO @as_mb_id,
                                    --    @as_sub_id;
									SET @cur4_i = @cur4_i + 1;
                                END;
                            --CLOSE @SWV_cursor_var4;
                      END;
		
                    IF ( @mb_count > 1 )
					BEGIN
					SET @a_error_no = 604
                        RAISERROR('Found more than one member in the database matching Alt, First + Last + DOB',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
                END;
	 -- not from_api - get member IDs
           
            SET @d_last_name = @s_last_name;
            
            SET @d_first_name = @s_first_name;
            IF @mb_count = 1
                SET @as_action_code = 'MU';
            ELSE
                IF @mb_count = 0
                    BEGIN
                        IF ( @as_term_date IS NOT NULL )
						BEGIN
						SET @a_error_no = 76
                            RAISERROR('Member Term Date should be blank if new member',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
	/* if d_bill_type is "AH" and new sub or micr info provided then validate 
	 * /
	/ * 20131004$$ks - s_has_micr is set in dlp_sg_precheck
	*/
                        
                        IF ( @s_has_micr = 'N' )
						BEGIN
						SET @a_error_no = 81
                            RAISERROR('MICR information provided is not complete',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                        
                        IF ( ( @s_rate_code IS NULL
                               OR @s_rate_code = ''
                             )
                             OR LEN(@s_rate_code) = 0
                           )
                            BEGIN
                                SET @s_rate_code = @n_rate_code ;
                               UPDATE dbo.GlobalVar set VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1
                            END; -- use ratecode from msg
		
                        SET @as_action_code = 'SA';
		/* 20131003$$ks - Member does not exist return with pertinent info 
		 */
         IF @s_error = 'Y'
             BEGIN
                                SET @SWP_Ret_Value = 0;
                                SET @SWP_Ret_Value1 = NULL;
                                SET @SWP_Ret_Value2 = @as_action_code;
                                SET @SWP_Ret_Value3 = @as_sub_id;
                                SET @SWP_Ret_Value4 = @as_mb_id;
                                SET @SWP_Ret_Value5 = @as_msg_id;
             SET @SWP_Ret_Value6 = @as_gp_id;
                   SET @SWP_Ret_Value7 = @as_pl_id;
                                SET @SWP_Ret_Value8 = @as_fc_id;
                                SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                                SET @SWP_Ret_Value10 = @as_fc_eff;
                                SET @SWP_Ret_Value11 = @as_term_date;
  
           SET @SWP_Ret_Value12 = @s_rate_code;
 RETURN;
                            END;
                        ELSE
                            BEGIN
                                SET @SWP_Ret_Value = 1;
                                SET @SWP_Ret_Value1 = NULL;
                                SET @SWP_Ret_Value2 = @as_action_code;
                                SET @SWP_Ret_Value3 = @as_sub_id;
                                SET @SWP_Ret_Value4 = @as_mb_id;
                                SET @SWP_Ret_Value5 = @as_msg_id;
                                SET @SWP_Ret_Value6 = @as_gp_id;
                                SET @SWP_Ret_Value7 = @as_pl_id;
                                SET @SWP_Ret_Value8 = @as_fc_id;
                                SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                                SET @SWP_Ret_Value10 = @as_fc_eff;
                                SET @SWP_Ret_Value11 = @as_term_date;
                                
                                SET @SWP_Ret_Value12 = @s_rate_code;
                                RETURN;
                            END;
                    END;	 
	-- 20131003$$ks - moved MSG validation to top of logic
	-- if existing member then SG group needs to be found 

	/* 20131003$$ks - New healthcare reform requirements
	 *	1. Subscriber can be in multiple MSGs but should only have 1 SG per MSG.
	 * 2. SG may have been terminated and if so can be Reinstated
	 * 3. Should be able to add new dependents to current SG if SG Active (Sub is active)_
	 * 4. Adding plan to terminated SG needs to reactivate the SG 
	 */

	/* 20121004$$ks - added date to rlmbgrpl SELECT statement because the member could have 
	 * moved to a different group via the GUI 
	 */
	/* 20131005$$ks - stop using alt_id New members already returned to calling proc as SA DA
	 *		we know our as_sub_id will use it in the following tests
	 */
            SET @a_error_no = 40;
            
            IF @from_api <> 1
                OR @as_gp_id IS NULL
                OR @as_gp_id = 0 -- need to validate SG further 
                BEGIN
                    SET @as_gp_id = 0;
                    SET @gp_count = 0;
		/* Does SG exist for sub within the given MSG? */

				DECLARE @SWV_cursor_var5 TABLE
                        (
                         id INT IDENTITY ,
						 group_id INT
                        );
                          INSERT  INTO @SWV_cursor_var5
                                ( 
								group_id 
                                )
								SELECT DISTINCT r.group_id  FROM
         dbo.rlmbgrpl r
         WHERE r.member_id = @as_sub_id
         AND r.eff_gr_pl <= CAST(@s_mb_gppl_eff_date AS DATE)
         AND (r.exp_gr_pl IS NULL OR r.exp_gr_pl > CAST(@s_mb_gppl_eff_date AS DATE))
         AND r.group_id IN(SELECT group_id
         FROM dbo.[group] (NOLOCK)
         WHERE group_parent = @as_msg_id
         AND group_type = 'SG');

	  DECLARE @cur5_cnt INT ,
  @cur5_i INT;

                        SET @cur5_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur5_cnt = COUNT(1)
                        FROM  @SWV_cursor_var5;

		/*
                    SET @SWV_cursor_var5 = CURSOR  FOR SELECT DISTINCT r.group_id  FROM
         dbo.rlmbgrpl r
         WHERE r.member_id = @as_sub_id
         AND r.eff_gr_pl <= @s_mb_gppl_eff_date AS DATE)
         AND (r.exp_gr_pl IS NULL OR r.exp_gr_pl > @s_mb_gppl_eff_date AS DATE))
         AND r.group_id IN(SELECT group_id
         FROM dbo.[group] (NOLOCK)
         WHERE group_parent = @as_msg_id
         AND group_type = 'SG');
                    OPEN @SWV_cursor_var5;
                    FETCH NEXT FROM @SWV_cursor_var5 INTO @as_gp_id;
                    WHILE @@FETCH_STATUS = 0
					*/

            WHILE ( @cur5_i <= @cur5_cnt )
            BEGIN
			SELECT  @as_gp_id=group_id
					FROM @SWV_cursor_var5
            WHERE   id = @cur5_i;

                SET @gp_count = @gp_count + 1;
                            --FETCH NEXT FROM @SWV_cursor_var5 INTO @as_gp_id;
							SET @cur5_i = @cur5_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var5;
                    IF ( @gp_count > 1 )
			-- multiple active Single groups with same MSG
			BEGIN
				SET @a_error_no = 35
                        RAISERROR('Multiple SG recs found for Sub in Master Single Group',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    IF @as_gp_id = 0
		/* 20131005$$ks - See if sub was terminated but SG Group exists
		 */
                        BEGIN
                            SET @gp_count = 0;

							DECLARE @SWV_cursor_var6 TABLE
                        (
                         id INT IDENTITY ,
						 group_id INT
                        );
                          INSERT  INTO @SWV_cursor_var6
                                ( 
								group_id 
                                )
								SELECT DISTINCT r.group_id 
            FROM dbo.rlmbgrpl r (NOLOCK)
        WHERE r.member_id = @as_sub_id
            AND exp_gr_pl IS NOT NULL
            AND r.group_id IN(SELECT group_id FROM dbo.[group] (NOLOCK)
            WHERE group_parent = @as_msg_id
            AND group_type = 'SG');

	  DECLARE @cur6_cnt INT ,
                            @cur6_i INT;

                        SET @cur6_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur6_cnt = COUNT(1)
                        FROM  @SWV_cursor_var6;

							/*
                            SET @SWV_cursor_var6 = CURSOR  FOR SELECT DISTINCT r.group_id 
            FROM dbo.rlmbgrpl r (NOLOCK)
        WHERE r.member_id = @as_sub_id
            AND exp_gr_pl IS NOT NULL
            AND r.group_id IN(SELECT group_id FROM dbo.[group] (NOLOCK)
            WHERE group_parent = @as_msg_id
            AND group_type = 'SG');
                            OPEN @SWV_cursor_var6;
                            FETCH NEXT FROM @SWV_cursor_var6 INTO @as_gp_id;
                            WHILE @@FETCH_STATUS = 0
							*/
                               WHILE ( @cur6_i <= @cur6_cnt )
            BEGIN
			SELECT  @as_gp_id=group_id
					FROM @SWV_cursor_var6
            WHERE   id = @cur6_i;

                                    SET @gp_count = @gp_count + 1;
                                    --FETCH NEXT FROM @SWV_cursor_var6 INTO @as_gp_id;
									SET @cur6_i = @cur6_i + 1;

                                END;
                            --CLOSE @SWV_cursor_var6;
                            IF ( @gp_count > 1 )
			/* 20131005$$ks Get most recent SG group_id for MSG 
			 */
                                BEGIN
                                    SELECT  @as_gp_id = group_id
                       FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @as_sub_id
           AND mb_gr_pl_id = ( SELECT
                 MAX(r2.mb_gr_pl_id)
           FROM
                        dbo.rlmbgrpl r2 ( NOLOCK ) ,
                                                              dbo.[group] g ( NOLOCK )
                                                              WHERE
                                                              r2.member_id = @as_sub_id
                                                            AND ( ( r2.exp_gr_pl IS NULL )
                                                              OR ( ( r2.exp_gr_pl IS NOT NULL )
                                                              AND ( r2.eff_gr_pl != r2.exp_gr_pl )
                                                              )
                                                            )
       AND r2.group_id = g.group_id
          AND g.group_parent = @as_msg_id
       AND g.group_type = 'SG'
                                                              );
                                    
                                    IF @as_gp_id IS NULL
                                        SET @as_gp_id = 0;
                                END;
                        END;
                END;
		/* 20131003$$ks - This means that we need to add the new Group-plan relationship 
		 */
	
	/* 20131003$$ks - moved plan and mid-month validation to top of logic
	 * Note: at this point we should know as_sub_id, as_pl_id, as_gpplrt_eff, as_fc_eff
	 *
	 * Note: we need the mbgrplID in order to get the current ratecode but the rate codes
	 *			for different plans can be different so it does not make sense to look for any
	 *			ratecode since we may have some plans being tiered S,C,F1,F2, etc while others 
	 *			are related to number of dependents K0,K1,K2, etc.
	 */
            SET @d_mbgrpl_id = 0;
            IF @as_gp_id != 0 
	  /* 20131003$$ks - remove date relationship 
		* and just get most recent rlmbgrpl record for 
		* sub-group-plan unless eff_gr_pl = exp_gr_pl
		*/
                BEGIN


				DECLARE @SWV_cursor_var7 TABLE
                        (
                         id INT IDENTITY ,
						 mb_gr_pl_id INT ,
						 eff_gr_pl DATE, 
						 exp_gr_pl DATE
                        );
                          INSERT  INTO @SWV_cursor_var7
                                ( 
								mb_gr_pl_id ,eff_gr_pl, exp_gr_pl 
                                )
								SELECT mb_gr_pl_id ,eff_gr_pl, exp_gr_pl 
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @as_sub_id AND group_id = @as_gp_id AND plan_id = @as_pl_id
         AND (exp_gr_pl IS NULL OR (exp_gr_pl IS NOT NULL AND eff_gr_pl != exp_gr_pl))
         ORDER BY 2 DESC,3;
		 
	  DECLARE @cur7_cnt INT ,
                            @cur7_i INT;

                        SET @cur7_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur7_cnt = COUNT(1)
                        FROM  @SWV_cursor_var7;

				/*
                    SET @SWV_cursor_var7 = CURSOR  FOR SELECT mb_gr_pl_id ,eff_gr_pl, exp_gr_pl 
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @as_sub_id AND group_id = @as_gp_id AND plan_id = @as_pl_id
         AND (exp_gr_pl IS NULL OR (exp_gr_pl IS NOT NULL AND eff_gr_pl != exp_gr_pl))
         ORDER BY 2 DESC,3;
                    OPEN @SWV_cursor_var7;
                    FETCH NEXT FROM @SWV_cursor_var7 INTO @d_mbgrpl_id,
                 @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
					*/

     WHILE ( @cur7_i <= @cur7_cnt )
            BEGIN
			SELECT @d_mbgrpl_id=mb_gr_pl_id,
   @d_eff_gr_pl=eff_gr_pl, 
				   @d_exp_gr_pl=exp_gr_pl
					FROM @SWV_cursor_var7
            WHERE   id = @cur7_i;

                            GOTO SWL_Label8;
                            --FETCH NEXT FROM @SWV_cursor_var7 INTO @d_mbgrpl_id,
                   --    @d_eff_gr_pl, @d_exp_gr_pl;
							SET @cur7_i = @cur7_i + 1;
                        END;
                    SWL_Label8:
                    --CLOSE @SWV_cursor_var7;
                END;
	/* 20131003$$ks - don't look for other mbgrplID records as they are irrelavent
	*/
	 -- as_gp_id not = 0
            IF ( @d_mbgrpl_id IS NULL
                 OR @d_mbgrpl_id = 0
               )
                BEGIN
                    SET @s_rate_code = @n_rate_code ;
                    UPDATE dbo.GlobalVar set VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1
         SET @as_action_code = 'PA';  
/* 20131114$$ks - GR checks if group reinstate already occurred so lets include 
 *		 when ever there is a plan add or plan change
 *		if as_gp_id > 0 and exists (select * from group_status where group_id = as_gp_id
 *		 and group_status = "T1" and eff_date <= as_gpplrt_eff and exp_date is null) then
 */
		 -- need to reinstate group
                    
                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                        @s_dls_sir_id, 'GR', @as_gpplrt_eff; -- new action to add new SG for MSG 
--		end if
			
                    IF @s_error = 'Y'
                        BEGIN
                            SET @SWP_Ret_Value = 0;
                            SET @SWP_Ret_Value1 = NULL;
                            SET @SWP_Ret_Value2 = @as_action_code;
                            SET @SWP_Ret_Value3 = @as_sub_id;
                            SET @SWP_Ret_Value4 = @as_mb_id;
                            SET @SWP_Ret_Value5 = @as_msg_id;
                            SET @SWP_Ret_Value6 = @as_gp_id;
                            SET @SWP_Ret_Value7 = @as_pl_id;
                            SET @SWP_Ret_Value8 = @as_fc_id;
                            SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                            SET @SWP_Ret_Value10 = @as_fc_eff;
                            SET @SWP_Ret_Value11 = @as_term_date;
                            
                            SET @SWP_Ret_Value12 = @s_rate_code;
                            RETURN;
     END;
                    ELSE
                        BEGIN
                            IF @as_gp_id IS NULL
                                OR @as_gp_id = 0
                                BEGIN
                                   
                                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                        @s_dls_sir_id, 'GA', @as_gpplrt_eff;
                                END; -- new action to add new SG for MSG 
                            ELSE
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.group_status (NOLOCK)
                                            WHERE   group_id = @as_gp_id
                                                    AND group_status = 'T1'
                                                    AND eff_date >= @as_gpplrt_eff
                                                    AND exp_date IS NULL )
				 -- need to reinstate group
                                    BEGIN
                                        
                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                            @s_dls_sir_id, 'GR',
                                        @as_gpplrt_eff;
                                    END; -- new action to add new SG for MSG 
				 
			
                            SET @SWP_Ret_Value = 1;
                            SET @SWP_Ret_Value1 = NULL;
                            SET @SWP_Ret_Value2 = @as_action_code;
                          SET @SWP_Ret_Value3 = @as_sub_id;
                            SET @SWP_Ret_Value4 = @as_mb_id;
                            SET @SWP_Ret_Value5 = @as_msg_id;
                            SET @SWP_Ret_Value6 = @as_gp_id;
            SET @SWP_Ret_Value7 = @as_pl_id;
                   SET @SWP_Ret_Value8 = @as_fc_id;
                 SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                            SET @SWP_Ret_Value10 = @as_fc_eff;
               SET @SWP_Ret_Value11 = @as_term_date;
                            
                            SET @SWP_Ret_Value12 = @s_rate_code;
                            RETURN;
                        END;
                END;
	
	-- From here down action is currently MU
	-- we have as_gp_id, as_pl_id and valid dates
            
            IF ( @s_rate_code IS NULL
                 OR @s_rate_code = ''
               )
                OR LEN(@s_rate_code) = 0
		-- get current rate_code for sub-grp-plan
                IF ( @d_mbgrpl_id IS NOT NULL
                    AND @d_mbgrpl_id > 0
                   )
                    BEGIN
                        
   IF ( @from_api = 1 )
                        AND ( @d_eff_gr_pl < @as_gpplrt_eff )
                            SET @as_gpplrt_eff = @d_eff_gr_pl;
			DECLARE @SWV_cursor_var8 TABLE
                        (
                         id INT IDENTITY ,
						 rate_code CHAR(2), 
						 eff_rt_date DATE
                        );
                          INSERT  INTO @SWV_cursor_var8
                                ( 
								rate_code, eff_rt_date  
                                )
								SELECT rate_code, eff_rt_date 
            FROM dbo.rlmbrt (NOLOCK)
            WHERE mb_gr_pl_id = @d_mbgrpl_id AND exp_rt_date IS NULL
            ORDER BY 2 DESC;

	  DECLARE @cur8_cnt INT ,
                            @cur8_i INT;

                        SET @cur8_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur8_cnt = COUNT(1)
                        FROM  @SWV_cursor_var8;


			/*
                        SET @SWV_cursor_var8 = CURSOR  FOR SELECT rate_code, eff_rt_date 
            FROM dbo.rlmbrt (NOLOCK)
            WHERE mb_gr_pl_id = @d_mbgrpl_id AND exp_rt_date IS NULL
            ORDER BY 2 DESC;
    OPEN @SWV_cursor_var8;
                        FETCH NEXT FROM @SWV_cursor_var8 INTO @n_rate_code,
                            @n_eff_rt_date;
                        WHILE @@FETCH_STATUS = 0
						*/
                            WHILE ( @cur8_i <= @cur8_cnt )
            BEGIN
			SELECT  @n_rate_code=rate_code,
                    @n_eff_rt_date=eff_rt_date
					FROM @SWV_cursor_var8
            WHERE   id = @cur8_i;

                                GOTO SWL_Label9;
                                --FETCH NEXT FROM @SWV_cursor_var8 INTO @n_rate_code,
                                --    @n_eff_rt_date;
								SET @cur8_i = @cur8_i + 1;
                            END;
                        SWL_Label9:
                        --CLOSE @SWV_cursor_var8;
                        IF ( @n_rate_code IS NULL
                             OR @n_rate_code = ''
                           )
                            OR @n_eff_rt_date IS NULL
							BEGIN
							SET @a_error_no = 237
                            RAISERROR('Sub has no active rate code',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
			
           SET @s_rate_code = @n_rate_code ;
             UPDATE dbo.GlobalVar set VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1           
                    END;
                ELSE -- 20130930$$ks - put in a valid rate from master SG
                    BEGIN

					DECLARE @SWV_cursor_var9 TABLE
                        (
                         id INT IDENTITY ,
						 rate_code CHAR(2) 
						 
                        );
                          INSERT  INTO @SWV_cursor_var9
                                ( 
								rate_code  
                                )
								SELECT rate_code FROM dbo.group_cap_rate (NOLOCK)
            WHERE group_id = @as_msg_id
            AND plan_id = @as_pl_id
            AND eff_date <= CAST(@s_mb_gppl_eff_date AS DATE)
   AND (exp_date IS NULL OR exp_date > CAST(@s_mb_gppl_eff_date AS DATE));

	  DECLARE @cur9_cnt INT ,
      @cur9_i INT;

                        SET @cur9_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur9_cnt = COUNT(1)
                        FROM  @SWV_cursor_var9;

					/*
                        SET @SWV_cursor_var9 = CURSOR  FOR SELECT rate_code FROM dbo.group_cap_rate (NOLOCK)
            WHERE group_id = @as_msg_id
            AND plan_id = @as_pl_id
            AND eff_date <= @s_mb_gppl_eff_date AS DATE)
            AND (exp_date IS NULL OR exp_date > @s_mb_gppl_eff_date AS DATE));
                        OPEN @SWV_cursor_var9;
                        FETCH NEXT FROM @SWV_cursor_var9 INTO @n_rate_code;
     WHILE @@FETCH_STATUS = 0
						*/
                            WHILE ( @cur9_i <= @cur9_cnt )
            BEGIN
			SELECT  @n_rate_code=rate_code
					FROM @SWV_cursor_var9
            WHERE   id = @cur9_i;

                                GOTO SWL_Label10;
                                --FETCH NEXT FROM @SWV_cursor_var9 INTO @n_rate_code;
								SET @cur9_i = @cur9_i + 1;
                            END;
                        SWL_Label10:
                        --CLOSE @SWV_cursor_var9;
                        IF ( @n_rate_code IS NULL
                             OR @n_rate_code = ''
                           )
						   BEGIN
						   SET @a_error_no = 237
                            RAISERROR('Sub has no active rate code',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
                        ELSE
                            BEGIN
                                SET @s_rate_code = @n_rate_code ;
                                UPDATE dbo.GlobalVar set VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1
                            END;
                    END;
		
	
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.group_cap_rate (NOLOCK)
                            WHERE   group_id = @as_msg_id
                                    AND plan_id = @as_pl_id
                                    AND rate_code = @s_rate_code
                                    AND exp_date IS NULL )
									BEGIN
									SET @a_error_no = 51
                RAISERROR('Missing active Group Cap Rate by MSG, Plan, Rate Code',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	

	/* 20131003$$ks moved validation of as_gpplrt_eff to top of logic
	 * /
	/ * 20131003$$ks -- if I got the mb_gr_pl_id above then I also got newest 
	 * eff and exp dates.  No need to look up again.
		
	if (d_mbgrpl_id is not null and d_mbgrpl_id > 0) then
		if (d_eff_gr_pl > as_gpplrt_eff) then
			RAISE EXCEPTION -746, 55, "Tape Mbr Grp Plan Rate EffDate before current effdate";
		end if
	end if
	if exists (select * from rel_gppl where group_id = as_gp_id
	 and plan_id = as_pl_id and eff_date > as_gpplrt_eff and exp_date is null) then
		RAISE EXCEPTION -746, 56, "Tape Mbr Group Plan Rate EffDate before group plan effdate";
	end if
	if exists (select * from group_cap_rate where group_id = as_gp_id 
	 and plan_id = as_pl_id and rate_code = s_rate_code 
	 and eff_date > as_gpplrt_eff and exp_date is null) then
		RAISE EXCEPTION -746, 58, "Tape Mbr Grp Plan Rate EffDate before grp cap rate effdate";
	end if
	/ * 20120514$$ks - have to test for ratecode being present on SIR file too
	 */
            
            IF ( ( @s_rate_code IS NOT NULL
                   AND @s_rate_code <> ''
                 )
                 AND @s_rate_code != ''
               )
                AND NOT EXISTS ( SELECT *
                                 FROM   dbo.group_cap_rate (NOLOCK)
                                 WHERE  group_id = @as_msg_id
                                        AND plan_id = @as_pl_id
                 AND rate_code = @s_rate_code
                                        AND eff_date <= @as_gpplrt_eff
             AND ( exp_date IS NULL
        OR exp_date > @as_gpplrt_eff
                                            ) )
											BEGIN
											SET @a_error_no = 59
                RAISERROR('Tape Mbr Grp Plan Rate EffDate before group cap rate eff date',         0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
      IF EXISTS ( SELECT  *
                        FROM    dbo.group_status (NOLOCK)
                        WHERE   group_id = @as_gp_id
                                AND ( group_status = 'A4'
                                      OR group_status = 'T1'
                                    )  -- 20131003$$ks -- added T1 
                                AND eff_date > @as_gpplrt_eff
                                AND exp_date IS NULL )
								BEGIN
								SET @a_error_no = 60
                RAISERROR('Tape Mbr Grp Pl Rate EffDate before group status effdate',16,         1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
            IF EXISTS ( SELECT  *
                        FROM    dbo.group_status (NOLOCK)
                        WHERE   group_id = @as_msg_id
                                AND group_status = 'A4'
                                AND eff_date > @as_gpplrt_eff
                                AND exp_date IS NULL )
								BEGIN
								SET @a_error_no = 61
                RAISERROR('Tape Mbr Grp Pl Rt EffDt before MSG group status effdate',16,         1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
	
   IF @as_term_date IS NOT NULL
                BEGIN
                    IF @ls_mid_month = 'N'
                        AND DATEPART(DAY, @as_term_date) != 1
						BEGIN
						SET @a_error_no = 135
                        RAISERROR('Member Term Date must be 1st of month',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    IF ( @d_mbgrpl_id IS NULL
                         OR @d_mbgrpl_id = 0
                       )
                        OR EXISTS ( SELECT  *
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   mb_gr_pl_id = @d_mbgrpl_id
                                            AND ( @as_term_date < eff_gr_pl
                                                  OR exp_gr_pl < @as_term_date
                                                ) )
												BEGIN
												SET @a_error_no = 80
                        RAISERROR('Subscriber Term Date is not valid in current status',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    IF ( @d_mbgrpl_id IS NULL
                         OR @d_mbgrpl_id = 0
                       )
                        OR EXISTS ( SELECT  *
                                    FROM    dbo.rlplfc (NOLOCK)
                                    WHERE   mb_gr_pl_id = @d_mbgrpl_id
                                            AND facility_id = @as_fc_id
                                            AND ( @as_term_date < eff_date
                                                  OR exp_date < @as_term_date
                                                ) )
												BEGIN
												SET @a_error_no = 81
                        RAISERROR('Member Term Date is not valid in current status',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
				IF @i_fatal <> 1 
				SET @s_error = 'Y';
				END
		
                    SET @as_action_code = 'ST';
                END;
	
	

--trace off;
        IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = @as_action_code;
                    SET @SWP_Ret_Value3 = @as_sub_id;
                    SET @SWP_Ret_Value4 = @as_mb_id;
   SET @SWP_Ret_Value5 = @as_msg_id;
                    SET @SWP_Ret_Value6 = @as_gp_id;
                    SET @SWP_Ret_Value7 = @as_pl_id;
					SET @SWP_Ret_Value8 = @as_fc_id;
                    SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                    SET @SWP_Ret_Value10 = @as_fc_eff;
                    SET @SWP_Ret_Value11 = @as_term_date;
                    
                    SET @SWP_Ret_Value12 = @s_rate_code;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
       SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = @as_action_code;
					SET @SWP_Ret_Value3 = @as_sub_id;
                    SET @SWP_Ret_Value4 = @as_mb_id;
                    SET @SWP_Ret_Value5 = @as_msg_id;
                    SET @SWP_Ret_Value6 = @as_gp_id;
                    SET @SWP_Ret_Value7 = @as_pl_id;
                    SET @SWP_Ret_Value8 = @as_fc_id;
					SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                    SET @SWP_Ret_Value10 = @as_fc_eff;
                    SET @SWP_Ret_Value11 = @as_term_date;
                    
                    SET @SWP_Ret_Value12 = @s_rate_code;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = 0;
            --SET @SWP_Ret_Value1 = @s_error_descr;
			SET @SWP_Ret_Value1 = NULL
            SET @SWP_Ret_Value2 = @as_action_code;
            SET @SWP_Ret_Value3 = @as_sub_id;
            SET @SWP_Ret_Value4 = @as_mb_id;
            SET @SWP_Ret_Value5 = @as_msg_id;
            SET @SWP_Ret_Value6 = @as_gp_id;
            SET @SWP_Ret_Value7 = @as_pl_id;
            SET @SWP_Ret_Value8 = @as_fc_id;
            SET @SWP_Ret_Value9 = @as_gpplrt_eff;
            SET @SWP_Ret_Value10 = @as_fc_eff;
            SET @SWP_Ret_Value11 = @as_term_date;
            
            SET @SWP_Ret_Value12 = @s_rate_code;
			IF ERROR_NUMBER() =50000
				EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @sg_sp_id,@sg_sir_def_id, @s_dls_sir_id, @a_error_no;
							
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


--set debug file to "/tmp/dlp_valid_sg.trc";
--trace on;

    END;