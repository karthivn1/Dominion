﻿--drop proc usp_dl_Savedlspvassoc
CREATE PROCEDURE [dbo].[usp_dl_Savedlspvassoc] (@dlspvAssoc dbo.DlspvAssoc READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_pv_assoc 
					SET dls_batch_id = dpa.dls_batch_id
					  ,alt_id = dpa.alt_id
					  ,pv_tax_id = dpa.pv_tax_id
					  ,pv_license = dpa.pv_license
					  ,pv_lic_state = dpa.pv_lic_state
					  ,tin = dpa.tin
					  ,pv_first_name = dpa.pv_first_name
					  ,pv_middle_init = dpa.pv_middle_init
					  ,pv_last_name = dpa.pv_last_name
					  ,discipline = dpa.discipline
					  ,mal_car = dpa.mal_car
					  ,mal_pol_no = dpa.mal_pol_no
					  ,mal_prac = dpa.mal_prac
					  ,mal_amt = dpa.mal_amt
					  ,mal_amt_i = dpa.mal_amt_i
					  ,mal_comnt = dpa.mal_comnt
					  ,dea_no = dpa.dea_no
					  ,dea_cert_dt = dpa.dea_cert_dt
					  ,dea_exp_dt = dpa.dea_exp_dt
					  ,cds_no = dpa.cds_no
					  ,cds_cert_dt = dpa.cds_cert_dt
					  ,cds_exp_dt = dpa.cds_exp_dt
					  ,cpr_cert_dt = dpa.cpr_cert_dt
					  ,cpr_exp_dt = dpa.cpr_exp_dt
					  ,prim_fc = dpa.prim_fc
					  ,school = dpa.school
					  ,grd_date = dpa.grd_date
					  ,degree = dpa.degree
					  ,ada_mbr = dpa.ada_mbr
					  ,district_no = dpa.district_no
					  ,pv_dob = dpa.pv_dob
					  ,print_dir = dpa.print_dir
					  ,race = dpa.race
					  ,gender = dpa.gender
					  ,num_yr_prac = dpa.num_yr_prac
					  ,peer_rv = dpa.peer_rv
					  ,vendor = dpa.vendor
					  ,pv_stat_eff_date = dpa.pv_stat_eff_date
					  ,fc_assoc_fc_id = dpa.fc_assoc_fc_id
					  ,fc_assoc_type = dpa.fc_assoc_type
					  ,fc_assoc_eff_date = dpa.fc_assoc_eff_date
					  ,fc_assoc_exp_date = dpa.fc_assoc_exp_date
					  ,pv_lic_eff_date = dpa.pv_lic_eff_date
					  ,pv_lic_exp_date = dpa.pv_lic_exp_date
					  ,pv_addr_type = dpa.pv_addr_type
					  ,pv_addr_1 = dpa.pv_addr_1
					  ,pv_addr_2 = dpa.pv_addr_2
					  ,pv_addr_zip = dpa.pv_addr_zip
					  ,pv_addr_city = dpa.pv_addr_city
					  ,pv_addr_state = dpa.pv_addr_state
					  ,pv_addr_county = dpa.pv_addr_county
					  ,pv_addr_country = dpa.pv_addr_country
					  ,pv_addr_mail = dpa.pv_addr_mail
					  ,pv_con_type = dpa.pv_con_type
					  ,pv_con_lname = dpa.pv_con_lname
					  ,pv_con_fname = dpa.pv_con_fname
					  ,pv_con_title = dpa.pv_con_title
					  ,pv_con_phone1 = dpa.pv_con_phone1
					  ,pv_con_ext1 = dpa.pv_con_ext1
					  ,pv_con_phone2 = dpa.pv_con_phone2
					  ,pv_con_ext2 = dpa.pv_con_ext2
					  ,pv_con_fax = dpa.pv_con_fax
					  --,dls_facility_id = dpa.dls_facility_id
					  --,dls_provider_id = dpa.dls_provider_id
					  --,dls_action_code = dpa.dls_action_code
					  ,dls_pv_assoc.dls_status = CASE WHEN dpa.dls_status='E' OR dpa.dls_status='P' THEN 'V'
							ELSE dls_pv_assoc.dls_status END
					  --,dls_source = dpa.dls_source
					  ,pv_np_id = dpa.pv_np_id
				from @dlspvAssoc dpa
				WHERE dls_pv_assoc.dls_sir_id = dpa.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END