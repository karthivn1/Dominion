﻿CREATE PROCEDURE [dbo].[dlp_chk_dep_fuzzy]
    @a_subscriber CHAR(2) ,
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_family_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:08:08 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @a_error_no INT;
	

        DECLARE @s_found_error CHAR(1);
        DECLARE @i_member_id INT;
        DECLARE @i_family_id INT;
        DECLARE @i_count INT;
        DECLARE @li_count INT;
        DECLARE @li_matchcount INT;

        DECLARE @s_last_name CHAR(15);
        DECLARE @s_first_name CHAR(15);
        DECLARE @d_date_of_birth DATE;
        DECLARE @s_middle_init CHAR(1);
        DECLARE @s_member_code CHAR(2);
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @t_sir_id INT;
        DECLARE @t_sub_sir_id INT;
        DECLARE @t_subscriber CHAR(2);
        DECLARE @t_alt_id CHAR(20);
        DECLARE @t_ssn CHAR(11);
        DECLARE @t_sub_ssn CHAR(11);
        DECLARE @t_sub_alt_id CHAR(20);
        DECLARE @t_member_code CHAR(2);
        DECLARE @t_last_name CHAR(15);
        DECLARE @t_first_name CHAR(15);
        DECLARE @t_middle_init CHAR(1);
        DECLARE @t_date_of_birth DATE;
        DECLARE @t_group_id INT;
        DECLARE @t_sub_id INT;
        DECLARE @t_member_id INT;
        DECLARE @i_config_id INT;
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;
        --DECLARE @SWV_cursor_var3 CURSOR;
        --DECLARE @SWV_cursor_var4 CURSOR;


        SET NOCOUNT ON;
        SET @i_sp_id = 0        
        SET @i_sir_def_id = 0         
        SET @t_sir_id = 0         
        SET @t_sub_sir_id = 0         
        SET @t_subscriber = ''         
        SET @t_alt_id = ''         
        SET @t_ssn = ''         
        SET @t_sub_ssn = ''        
        SET @t_sub_alt_id = ''        
        SET @t_member_code = ''         
        SET @t_last_name = ''        
        SET @t_first_name = ''         
        SET @t_middle_init = ''        
        SET @t_date_of_birth = NULL         
        SET @t_group_id = 0        
        SET @t_sub_id = 0         
        SET @t_member_id = 0         
        SET @i_config_id = 0 
        
        IF EXISTS ( SELECT  *
                    FROM    tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#tmp_dependent')
                            AND xtype = 'U' )
            DROP TABLE #tmp_dependent;
        CREATE TABLE #tmp_dependent
            (
              member_id INT ,
              family_id INT ,
              match_count INT
            );
        BEGIN TRY
            SET @s_found_error = 'N';
            SET @i_member_id = NULL;
            SET @i_family_id = NULL;
            SET @i_count = 0;
            BEGIN
                BEGIN TRY
                    DELETE  FROM #tmp_dependent;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_descr = ERROR_MESSAGE();
            
                    DELETE  FROM #tmp_dependent;
                    DROP TABLE #tmp_dependent;
                END CATCH;
            END;

--ameeta 06/21/00 added lines below to search for member 
-- by ssn, last name, first name, middle initt, DOB
            SET @li_count = 0;    -- Search for member matching following

			DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  member_id INT ,
                  family_id INT
                );

            INSERT  INTO @SWV_cursor_var1
                    ( member_id, family_id
					)
                    SELECT member_id, family_id
					FROM dbo.member (NOLOCK)
					WHERE member_id != family_id AND
					member_ssn = @t_ssn AND
					last_name = @t_last_name AND
					first_name = @t_first_name AND
					(((@t_middle_init IS NOT NULL AND  @t_middle_init <> '') AND middle_init IS NOT NULL AND middle_init = @t_middle_init) OR
					((@t_middle_init IS NULL OR  @t_middle_init = '') OR middle_init IS NULL)) AND
					((date_of_birth = @t_date_of_birth AND @t_date_of_birth != '01/01/1900'
					AND date_of_birth != '01/01/1900') OR
					(@t_date_of_birth = '01/01/1900' OR date_of_birth = '01/01/1900'));

            DECLARE @cur1_cnt INT ,
                @cur1_i INT;

            SET @cur1_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;

            WHILE ( @cur1_i <= @cur1_cnt )
                BEGIN

                    SELECT  @i_member_id = member_id ,
                            @i_family_id = family_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur1_i;

			/*
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT member_id, family_id
        
      FROM dbo.member (NOLOCK)
      WHERE member_id != family_id AND
      member_ssn = @t_ssn AND
      last_name = @t_last_name AND
      first_name = @t_first_name AND
             (((@t_middle_init IS NOT NULL AND  @t_middle_init <> '') AND middle_init IS NOT NULL AND middle_init = @t_middle_init) OR
               ((@t_middle_init IS NULL OR  @t_middle_init = '') OR middle_init IS NULL)) AND
             ((date_of_birth = CONVERT(DATE,CONVERT(VARCHAR,@t_date_of_birth)) AND CONVERT(DATE,CONVERT(VARCHAR,@t_date_of_birth)) != '01/01/1900'
      AND date_of_birth != '01/01/1900') OR
             (CONVERT(DATE,CONVERT(VARCHAR,@t_date_of_birth)) = '01/01/1900' OR date_of_birth = '01/01/1900'));
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_member_id, @i_family_id;
            WHILE @@FETCH_STATUS = 0
			*/
                
                    SET @li_count = @li_count + 1;

                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_member_id,
                    --    @i_family_id;
					SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @SWV_cursor_var1;
            IF @li_count = 1
                AND @i_member_id IS NOT NULL
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = @i_member_id;
                    SET @SWP_Ret_Value2 = @i_family_id;
                    RETURN;
                END;
            ELSE
                IF @li_count > 1
				BEGIN
                    RAISERROR('Duplicate dependent records in database',16,1);
					RETURN 
					END
                ELSE  -- li_count = 0

	-- Incorporate group ids in current batch configuration into lookup.
                    BEGIN
                        SET @li_count = 0;

						DECLARE @SWV_cursor_var2 TABLE
                            (
                              id INT IDENTITY ,
                              member_id INT ,
                              family_id INT
                            );

                        INSERT  INTO @SWV_cursor_var2
                                ( member_id ,
                                  family_id
					            )
                                SELECT a.member_id, a.family_id		  
								FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
								WHERE a.member_id != a.family_id
								AND a.family_id = @a_family_id
								AND a.member_ssn = @t_ssn
								AND a.family_id = b.member_id
								AND b.group_id IN(SELECT group_id
								FROM dbo.dlsp_eg_group_plan (NOLOCK)
								WHERE config_id = @i_config_id);
					

                        DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;

					--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
                        FROM    @SWV_cursor_var2;

                        WHILE ( @cur2_i <= @cur2_cnt )
                            BEGIN

                                SELECT  @i_member_id = member_id ,
                                        @i_family_id = family_id
                                FROM    @SWV_cursor_var2
                                WHERE   id = @cur2_i;

						/*
                        SET @SWV_cursor_var2 = CURSOR  FOR SELECT a.member_id, a.family_id
		  
         FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
         WHERE a.member_id != a.family_id
         AND a.family_id = @a_family_id
         AND a.member_ssn = @t_ssn
         AND a.family_id = b.member_id
         AND b.group_id IN(SELECT group_id
         FROM dbo.dlsp_eg_group_plan (NOLOCK)
         WHERE config_id = @i_config_id);
                        OPEN @SWV_cursor_var2;
                        FETCH NEXT FROM @SWV_cursor_var2 INTO @i_member_id,
                            @i_family_id;
                        WHILE @@FETCH_STATUS = 0
						*/
                            
                                SET @li_count = @li_count + 1;
                                --FETCH NEXT FROM @SWV_cursor_var2 INTO @i_member_id,
                                --    @i_family_id;
								SET @cur2_i = @cur2_i + 1;
                            END;
                        --CLOSE @SWV_cursor_var2;
                        IF @li_count = 1
                            AND @i_member_id IS NOT NULL
                            BEGIN
                                SET @SWP_Ret_Value = 1;
                                SET @SWP_Ret_Value1 = @i_member_id;
                                SET @SWP_Ret_Value2 = @i_family_id;
                                RETURN;
                            END;
	
                        SET @li_count = 0;
	-- Select records that match 3 of the following 5
	-- 1. Last Name, 2. First Name, 3. MI, 4.DOB, 5.Member Code
			-- IF li_matchcount >= 3 THEN

			DECLARE @SWV_cursor_var3 TABLE
                            (
                              id INT IDENTITY ,
                              member_id INT ,
                              family_id INT ,
                              last_name CHAR(15) ,
                              first_name CHAR(15) ,
                              middle_init CHAR ,
                              date_of_birth DATE ,
                              member_code CHAR(3)
                            );

                        INSERT  INTO @SWV_cursor_var3
                                ( member_id ,
                                  family_id ,
                                  last_name ,
                                  first_name ,
                                  middle_init ,
                                  date_of_birth ,
                                  member_code 
					            )
                                SELECT DISTINCT a.member_id, a.family_id, a.last_name, a.first_name,
								a.middle_init, a.date_of_birth, member_code		  
								FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
								WHERE a.member_id != a.family_id
								AND a.family_id = @a_family_id
								AND a.family_id = b.member_id
								AND b.group_id IN(SELECT group_id
								FROM dbo.dlsp_eg_group_plan (NOLOCK)
								WHERE config_id = @i_config_id)
								AND (last_name = @t_last_name OR first_name = @t_first_name)
								AND (((@t_middle_init IS NOT NULL AND  @t_middle_init <> '') AND middle_init = @t_middle_init)
								OR (date_of_birth = @t_date_of_birth AND @t_date_of_birth != '01/01/1900')
								OR (member_code = @t_member_code));
					

                        DECLARE @cur3_cnt INT ,
                            @cur3_i INT;

                        SET @cur3_i = 1;

					--Get the no. of records for the cursor
                        SELECT  @cur3_cnt = COUNT(1)
                        FROM    @SWV_cursor_var3;

                        WHILE ( @cur3_i <= @cur3_cnt )
                            BEGIN
							
                                SELECT  @i_member_id = member_id ,
                                        @i_family_id = family_id ,
                                        @s_last_name = last_name ,
                                        @s_first_name = first_name ,
										@s_middle_init = middle_init ,
                                        @d_date_of_birth = date_of_birth ,
                                        @s_member_code = member_code
                                FROM    @SWV_cursor_var3
                                WHERE   id = @cur3_i;

			/*

                        SET @SWV_cursor_var3 = CURSOR  FOR SELECT DISTINCT a.member_id, a.family_id, a.last_name, a.first_name,
		       a.middle_init, a.date_of_birth, member_code
		  
         FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
         WHERE a.member_id != a.family_id
         AND a.family_id = @a_family_id
         AND a.family_id = b.member_id
         AND b.group_id IN(SELECT group_id
         FROM dbo.dlsp_eg_group_plan (NOLOCK)
         WHERE config_id = @i_config_id)
         AND (last_name = @t_last_name OR first_name = @t_first_name)
         AND (((@t_middle_init IS NOT NULL AND  @t_middle_init <> '') AND middle_init = @t_middle_init)
         OR (date_of_birth = CONVERT(DATE,CONVERT(VARCHAR,@t_date_of_birth)) AND CONVERT(DATE,CONVERT(VARCHAR,@t_date_of_birth)) != '01/01/1900')
         OR (member_code = @t_member_code));
                        OPEN @SWV_cursor_var3;
                        FETCH NEXT FROM @SWV_cursor_var3 INTO @i_member_id,
                            @i_family_id, @s_last_name, @s_first_name,
                            @s_middle_init, @d_date_of_birth, @s_member_code;
                        WHILE @@FETCH_STATUS = 0
						*/
                            
                                SET @li_matchcount = 0;
                                
                                IF @s_last_name = @t_last_name
                                    SET @li_matchcount = @li_matchcount + 1;		
                                
                                IF @s_first_name = @t_first_name
                                    SET @li_matchcount = @li_matchcount + 1;		
                               
                                IF @s_middle_init = @t_middle_init
                                    SET @li_matchcount = @li_matchcount + 1		
                                
                              IF @d_date_of_birth = @t_date_of_birth
                                    SET @li_matchcount = @li_matchcount + 1;		
                               
                                IF @s_member_code = @t_member_code
                                    SET @li_matchcount = @li_matchcount + 1;
		
                                IF @li_matchcount >= 3
                                    BEGIN
                                       
                                        IF ( @s_last_name = @t_last_name
                                             AND @s_first_name = @t_first_name
                                             AND @s_middle_init = @t_middle_init
                                           )
                                            OR ( @s_last_name = @t_last_name
                                                 AND @s_first_name = @t_first_name
                                                 AND @d_date_of_birth = @t_date_of_birth
                                               )
                                            OR ( @s_last_name = @t_last_name
                                                 AND @s_first_name = @t_first_name
                                                 AND @s_member_code = @t_member_code
                                               )
                                            OR ( @s_last_name = @t_last_name
                                                 AND @s_middle_init = @t_middle_init
                                                 AND @d_date_of_birth = @t_date_of_birth
                                               )
                                            OR ( @s_last_name = @t_last_name
                                                 AND @d_date_of_birth = @t_date_of_birth
                                                 AND @s_member_code = @t_member_code
                                               )
                                            OR ( @s_first_name = @t_first_name
                                                 AND @s_middle_init = @t_middle_init
                                                 AND @d_date_of_birth = @t_date_of_birth
                                               )
                                            OR ( @s_first_name = @t_first_name
                                                 AND @s_middle_init = @t_middle_init
                                                 AND @s_member_code = @t_member_code
                                               )
                                            OR ( @s_first_name = @t_first_name
                                                 AND @d_date_of_birth = @t_date_of_birth
                                                 AND @s_member_code = @t_member_code
                                               )
				-- Insert this record in the temporary table.
                                            BEGIN
												INSERT  INTO #tmp_dependent
                                                        ( member_id ,
                                                          family_id ,
                                                          match_count
                                                        )
                                                VALUES  ( @i_member_id ,
                                                          @i_family_id ,
                                                          @li_matchcount
                                                        );
				
                                                SET @li_count = @li_count + 1;
                                            END;
                                    END;
                                --FETCH NEXT FROM @SWV_cursor_var3 INTO @i_member_id,
                                --    @i_family_id, @s_last_name, @s_first_name,
                                --    @s_middle_init, @d_date_of_birth,
                                --    @s_member_code;
								SET @cur3_i = @cur3_i + 1;
                            END;
                        --CLOSE @SWV_cursor_var3;
                        IF @li_count > 0
                            BEGIN
                                SELECT  @li_matchcount = MAX(match_count)
                                FROM    #tmp_dependent; 
                                
                                SET @li_count = 0;

								DECLARE @SWV_cursor_var4 TABLE
                                    (
                                      id INT IDENTITY ,
                                      member_id INT ,
                                      family_id INT
                                    );

                                INSERT  INTO @SWV_cursor_var4
                                        ( member_id ,
                                          family_id
					                    )
                   SELECT a.member_id, a.family_id		  	
										FROM #tmp_dependent a
										WHERE a.match_count = @li_matchcount;

                                DECLARE @cur4_cnt INT ,
                                    @cur4_i INT;

                                SET @cur4_i = 1;

					--Get the no. of records for the cursor
                                SELECT  @cur4_cnt = COUNT(1)
                                FROM    @SWV_cursor_var4;

                                WHILE ( @cur4_i <= @cur4_cnt )
                                    BEGIN
                                        SELECT  @i_member_id = member_id ,
                                                @i_family_id = family_id
                                        FROM    @SWV_cursor_var4
                                        WHERE   id = @cur4_i;
								/*
                                SET @SWV_cursor_var4 = CURSOR  FOR SELECT a.member_id, a.family_id
		  	
            FROM #tmp_dependent a
            WHERE a.match_count = @li_matchcount;
                                OPEN @SWV_cursor_var4;
                                FETCH NEXT FROM @SWV_cursor_var4 INTO @i_member_id,
                                    @i_family_id;
                                WHILE @@FETCH_STATUS = 0
								*/
                                        SET @li_count = @li_count + 1;


                                        --FETCH NEXT FROM @SWV_cursor_var4 INTO @i_member_id,
                                        --    @i_family_id;
										SET @cur4_i = @cur4_i + 1;
                                    END;
                                --CLOSE @SWV_cursor_var4;
                                IF @li_count > 1
								BEGIN
                                    RAISERROR('More than one match returned by fuzzy logic',16,1);
									RETURN
									END
                            END;
                  END;
     
            IF @s_found_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = NULL;
                    RETURN;
                END;
            ELSE
                IF @i_member_id IS NOT NULL
                    BEGIN
                        SET @SWP_Ret_Value = 2;
                        SET @SWP_Ret_Value1 = @i_member_id;
                        SET @SWP_Ret_Value2 = @i_family_id;
                        RETURN;
                    END;
                ELSE
                    BEGIN
                        SET @SWP_Ret_Value = 0;
                        SET @SWP_Ret_Value1 = @i_member_id;
                        SET @SWP_Ret_Value2 = @i_family_id;
                        RETURN;
                    END;
		
	           DROP TABLE #tmp_dependent;
        END TRY
        BEGIN CATCH
	
            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
                @i_sir_def_id, @t_sir_id, 355;
            SET @SWP_Ret_Value = -1;
    SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
			 SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;