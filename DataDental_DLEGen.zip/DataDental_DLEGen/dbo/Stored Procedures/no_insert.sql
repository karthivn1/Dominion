﻿CREATE PROCEDURE [dbo].[no_insert]
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        SET NOCOUNT ON;
        RAISERROR('Invalid insert has been attempted, see your systems administrator ',16,1);
        SET NOCOUNT OFF;

    END;