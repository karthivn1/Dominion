﻿CREATE PROCEDURE [dbo].[dlp_bu_actlog]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
	

----------------------------------------------------------------------------------
--	Procedure: 	dlp_bu_actlog
--
--	Created:	03/01/2001
--	Author:		Ameeta Mahendra
--
--	Purpose:	This SP performs Pre-processing 
-----------------------------------------------------------------------------

	/*error variable*/
	
	--	LET i_fatal = dl_log_error(a_batch_id, i_sp_id, i_sir_def_id,
	--		i_sir_id, a_error_no);
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(14);
        DECLARE @s_proc_name CHAR(14);
        DECLARE @a_error_no INT;
        DECLARE @c_found_error CHAR(1);

        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);

        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;

        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @i_error_count INT;
        DECLARE @i_process_count INT;
        DECLARE @i_succ_count INT;

        DECLARE @i_config_id INT;

        DECLARE @s_batch_status CHAR(1);

        DECLARE @i_sir_id INT;
        DECLARE @s_subsys_code CHAR(2);
        DECLARE @i_sysrec_id INT;
        DECLARE @s_sysrec_id CHAR(20);
        DECLARE @s_reason_code CHAR(2);
        DECLARE @i_act_mast_id INT;


        DECLARE @i_ref_id INT;
        DECLARE @n_system_cmd CHAR(1024);
        DECLARE @cSIR CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;

        SET NOCOUNT ON;
        BEGIN TRY
             
            SET LOCK_TIMEOUT -1;
            SET @s_proc_name = 'bu_actlog';
            SET @s_sir_def_name = 'actlog';
            SELECT  @i_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat
            WHERE   config_bat_id = @a_batch_id;
            IF @@rowcount = 0
                SELECT  @i_config_id = NULL ,
                        @s_batch_status = NULL;
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_actlog';
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
                RAISERROR('Invalid SP Name',16,1);
	
            SET @i_sir_def_id = dbo.dl_get_sir_def_id('actlog');
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
                RAISERROR('Invalid SIR TABLE Definition',16,1);
	
            EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
                @n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_descr OUTPUT;
            IF @n_error_no <= 0
                RAISERROR('(Internal) error when creating statistics',16,1);
	
            SET @i_process_count = 0;
            SET @i_succ_count = 0;


--------Begin processing one row at a time -----------------------------
            SET @cSIR = CURSOR  FOR SELECT dls_sir_id, subsys_code, sysrec_id, reason_code
		
      FROM dbo.dls_actlog (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND
			(dls_status = 'L' OR dls_status = 'V') AND
			((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) OR
			 (@a_sir_id = 0 AND dls_sir_id > 0));
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @i_sir_id, @s_subsys_code, @s_sysrec_id,
        @s_reason_code;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    BEGIN
                        DECLARE @SWV_dl_log_error INT;
                        BEGIN TRY
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.dl_log_error (NOLOCK)
                                        WHERE   config_bat_id = @a_batch_id
                                                AND sp_id = @i_sp_id )
                                EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                    @i_sir_id, @i_sp_id, @n_error_no OUTPUT,
                                    @n_error_text OUTPUT;
		
                            
                            SET @c_found_error = 'N';
                            SET @i_process_count = @i_process_count + 1;
                            IF ( @s_subsys_code IS NULL
                                 OR @s_subsys_code = ''
                               )
                                RAISERROR('Subsys Code cannot be null.',16,1);
		
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.typ_table (NOLOCK)
                                            WHERE   tab_name = 'subsys_code'
                                                    AND code = @s_subsys_code )
                                RAISERROR('Invalid Sub-system code.',16,1);
		
                            IF ( @s_sysrec_id IS NULL
                                 OR @s_sysrec_id = ''
                               )
                                RAISERROR('sysrec_id Value cannot be null.',16,1);
		
                            SET @i_error_no = 35;	--non numeric sysrec_id
                            SET @i_sysrec_id = @s_sysrec_id;
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.dls_actlog (NOLOCK)
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND subsys_code = @s_subsys_code
                                                AND sysrec_id = @s_sysrec_id
                                                AND reason_code = @s_reason_code
                                                AND dls_sir_id != @i_sir_id )
                                RAISERROR('Subsys code, sysrec_id, reason has to be unique',16,1);
		
                            IF @s_subsys_code = 'MB'
                                AND NOT EXISTS ( SELECT *
                                                 FROM   dbo.member (NOLOCK)
                                                 WHERE  member_id = @s_sysrec_id )
                                RAISERROR('Invalid record ID',16,1);
		
                            IF @s_subsys_code = 'GP'
                                AND NOT EXISTS ( SELECT *
                                                 FROM   dbo.[group] (NOLOCK)
                                                 WHERE  group_id = @s_sysrec_id )
                                RAISERROR('Invalid record ID',16,1);
		
                            IF @s_subsys_code = 'PD'
                                AND NOT EXISTS ( SELECT *
                                                 FROM   dbo.pd (NOLOCK)
                                                 WHERE  producer_id = @s_sysrec_id )
                                RAISERROR('Invalid record ID',16,1);
		
                            IF @s_subsys_code = 'FC'
                                AND NOT EXISTS ( SELECT *
                                                 FROM   dbo.facility (NOLOCK)
                                                 WHERE  fc_id = @s_sysrec_id )
                                RAISERROR('Invalid record ID',16,1);
		
                            IF @s_subsys_code = 'PV'
                                AND NOT EXISTS ( SELECT *
             FROM   dbo.providers (NOLOCK)
                                                 WHERE  pv_id = @s_sysrec_id )
                                RAISERROR('Invalid record ID',16,1);
		
                            IF @s_subsys_code = 'CL'
                                AND NOT EXISTS ( SELECT *
                                                 FROM   dbo.claim_h (NOLOCK)
                                                 WHERE  claim_id = @s_sysrec_id )
                                RAISERROR('Invalid record ID',16,1);
		
                            IF ( @s_reason_code IS NULL
                                 OR @s_reason_code = ''
                               )
                                RAISERROR('Reason Code cannot be null.',16,1);
		
                            SET @i_act_mast_id = NULL;
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.mod_def a ( NOLOCK ) ,
                                                    dbo.act_mast b ( NOLOCK ) ,
                                                    dbo.reas_mast c ( NOLOCK )
                                            WHERE   a.mod_id = b.mod_id
                                                    AND b.act_mast_id = c.act_mast_id
                                                    AND ( a.menu_opt = 'ext_actlog'
                                                          OR a.menu_opt = 'ext_in_actlog'
                                                        )
                                                    AND a.subsys_code = @s_subsys_code
                                                    AND reason_code = @s_reason_code )
                                RAISERROR('Invalid Reason Code',16,1);
                            ELSE
                                BEGIN
                                    SELECT  @i_act_mast_id = b.act_mast_id
                                    FROM    dbo.mod_def a ( NOLOCK ) ,
                                            dbo.act_mast b ( NOLOCK ) ,
                                            dbo.reas_mast c ( NOLOCK )
                                    WHERE   a.mod_id = b.mod_id
                                            AND b.act_mast_id = c.act_mast_id
                                            AND ( a.menu_opt = 'ext_actlog'
                                                  OR a.menu_opt = 'ext_in_actlog'
                                                )
                                            AND a.subsys_code = @s_subsys_code
                                            AND reason_code = @s_reason_code;
                                    IF @@rowcount = 0
                                        SELECT  @i_act_mast_id = NULL;
                                END;
		
                            IF @c_found_error = 'Y'
                                UPDATE  dbo.dls_actlog
                                SET     dls_status = 'E' ,
                                        dls_act_mast_id = @i_act_mast_id
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @i_sir_id;
                            ELSE
                                BEGIN
                                    UPDATE  dbo.dls_actlog
                                    SET     dls_status = 'P' ,
                                            dls_act_mast_id = @i_act_mast_id
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @i_sir_id;
                                    SET @i_succ_count = @i_succ_count + 1;
                                END;
		
                            
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
  SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
				
                            IF @i_error_no IN ( -244, -245, -246 )
                                BEGIN
                                    
                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @i_sir_id,
                                        1000;
                                    
                                END;
                            ELSE
                                BEGIN
                                    EXECUTE dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @i_sir_id,
                                        @i_error_no, @SWV_dl_log_error OUTPUT;
                                    IF @SWV_dl_log_error != 1
                                        SET @c_found_error = 'Y';
                                END;
                        END CATCH;
                    END;
                    FETCH NEXT FROM @cSIR INTO @i_sir_id, @s_subsys_code,
                        @s_sysrec_id, @s_reason_code;
                END;
            CLOSE @cSIR;
            SET @SWV_func_DL_UPD_STATISTICS_par0 = @i_process_count
                - @i_succ_count;
            EXECUTE dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
                @i_succ_count, @SWV_func_DL_UPD_STATISTICS_par0,
                @SWV_dl_upd_statistics OUTPUT;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @i_succ_count
                                                   + @i_error_count ),
                                                 ' Failed to update statistics');
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished preprocess for Batch ',
                                         @a_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



---set debug file to "/tmp/dlp_bu_actlog.trc";
---trace on;
	--set explain on;

    END;