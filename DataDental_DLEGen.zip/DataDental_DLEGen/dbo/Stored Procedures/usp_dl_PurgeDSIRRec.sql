﻿-- =============================================
-- Author:		Uthayan.S
-- Create date: 20 Dec 2016
-- Description:	Purge DSIR records using configuration Id
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_PurgeDSIRRec] 
	-- Add the parameters for the stored procedure here
	@ConfigId int,
	@FromBatchId int,
	@ToBatchId int,
	@TotalRows int output
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;		
		DECLARE @dsirTableName varchar(50)
		DECLARE @DSIRquery Nvarchar(max)				
		DECLARE @ParmDefinition nvarchar(500)

		--SET @sirDef = (select distinct(dl_cfg_bat_det.sir_def)
		--from dl_cfg_bat_det
		--where dl_cfg_bat_det.config_bat_id = 218)

		--SET @dsirTableName=(select 'dls_'+ RTRIM(sir_def_name) 
		--from dl_sir_def
		--where dl_sir_def.sir_def_id = 9)

		SET @dsirTableName=(SELECT 'dls_'+ RTRIM(sir_def_name) 
		FROM dl_sir_def D
		INNER JOIN dl_config C ON C.module_id = D.module_id
		WHERE C.config_id = @ConfigId)

		SET @ParmDefinition = N'@id int,@fromId int,@toId int';

		SET @DSIRquery = N'DELETE FROM '+@dsirTableName+' WHERE dls_batch_id in (SELECT config_bat_id FROM dl_config_bat where config_id=@id and config_bat_status in (''N'',''P'',''S'') AND config_bat_id BETWEEN @fromId AND @toId)'		

		EXECUTE sp_executesql @DSIRquery, @ParmDefinition,@id=@ConfigId,@fromId=@FromBatchId,@toId=@ToBatchId
			SET @TotalRows = @@ROWCOUNT
		DELETE FROM dl_action WHERE batch_id in (SELECT config_bat_id FROM dl_config_bat where config_id=@ConfigId and config_bat_status in ('N','P','S') AND config_bat_id BETWEEN @FromBatchId AND @ToBatchId)
			SET @TotalRows = @TotalRows + @@ROWCOUNT
		DELETE FROM dl_log_error WHERE config_bat_id in (SELECT config_bat_id FROM dl_config_bat where config_id=@ConfigId and config_bat_status in ('N','P','S') AND config_bat_id BETWEEN @FromBatchId AND @ToBatchId)
			SET @TotalRows = @TotalRows + @@ROWCOUNT
		DELETE FROM dl_log_error_h WHERE config_bat_id in (SELECT config_bat_id FROM dl_config_bat where config_id=@ConfigId and config_bat_status in ('N','P','S') AND config_bat_id BETWEEN @FromBatchId AND @ToBatchId)
			SET @TotalRows = @TotalRows + @@ROWCOUNT
		UPDATE dl_config_bat set config_bat_status='P' WHERE config_id=@ConfigId AND config_bat_status in ('N','P','S') AND config_bat_id BETWEEN @FromBatchId AND @ToBatchId
		--SELECT * FROM dl_config_bat WHERE config_bat_id in (SELECT config_bat_id FROM dl_config_bat where config_id=@ConfigId and config_bat_status in ('N','P','S') AND config_bat_id BETWEEN @FromBatchId AND @ToBatchId)
			SET @TotalRows = @TotalRows + @@ROWCOUNT

	SELECT @TotalRows
END