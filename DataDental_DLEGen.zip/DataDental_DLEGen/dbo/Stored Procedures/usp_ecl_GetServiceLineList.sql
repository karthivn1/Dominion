﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_ecl_GetServiceLineList]
@EclaimId int
AS
BEGIN
	 SELECT eclaim_d_id				AS  EclaimDetailId,
		eclaim_id					AS  EclaimId,
       rtrim(ltrim(svc_date)) 		AS  ServiceDate,
       rtrim(ltrim(d_proc_code))	AS  CDT,
       rtrim(ltrim(tooth_no)) 		AS  ToothNo,
       rtrim(ltrim(surface)) 		AS  SurfaceCode,
       rtrim(ltrim(quad)) 			AS  QuadrantCode,
       rtrim(ltrim(cob_amt)) 		AS  CobAmount,
       rtrim(ltrim(submitted_amt))	AS  SubmittedAmount,
       rtrim(ltrim(h_user)) 		AS  HUser,
       h_datetime 					AS  HDatetime,
       rtrim(ltrim(error_code))		AS  ErrorCode,
       dls_sir_id 					AS  SIRId
  FROM eclaim_d where eclaim_id=@EclaimId
END