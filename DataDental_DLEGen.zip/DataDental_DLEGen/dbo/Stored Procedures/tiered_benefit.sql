﻿CREATE  PROCEDURE [dbo].[tiered_benefit]
    @d_mbgrpl_id INT ,
    @d_rlplfc_id INT ,
    @CarryOver_sw CHAR(1) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:36:36 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_text VARCHAR(64);
        DECLARE @debug INT;

        DECLARE @MemberID INT;
        DECLARE @li_rlplfc_id INT;
        DECLARE @CarryOver INT;
        DECLARE @Adj INT;
        DECLARE @NewCover INT;
        DECLARE @CMonth INT;
        DECLARE @rlplEff DATE;
        DECLARE @Planid INT;
        DECLARE @TieredSw CHAR(1);
        DECLARE @EffDate DATE;
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @v_Null INT;

        SET NOCOUNT ON;
        BEGIN TRY
            SET @debug = 0;
            IF @debug = 1
                BEGIN--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/mb_tier_bene.trc";

	--TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;

            SELECT  @Planid = plan_id
            FROM    dbo.rlmbgrpl (NOLOCK)
            WHERE   mb_gr_pl_id = @d_mbgrpl_id;
            IF @@rowcount = 0
                SELECT  @Planid = NULL;
            SELECT  @TieredSw = tiered_sw
            FROM    dbo.[plan] (NOLOCK)
            WHERE   plan_id = @Planid;
            IF @@rowcount = 0
                SELECT  @TieredSw = NULL;
            IF @TieredSw = 0
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = 'Plan not tiered';
                    RETURN;
                END;


-- For SA , PA, DA add a new entry in the tiered_benefit_mbr
            IF @CarryOver_sw = 'N'
                INSERT  INTO dbo.tiered_benefit_mbr
                        ( rlplfc_id ,
                          carry_over ,
                          adjustment ,
                          h_user ,
                          h_datetime
                        )
                VALUES  ( @d_rlplfc_id ,
                          0 ,
                          0 ,
                          ORIGINAL_LOGIN(),
                          GETDATE()
                        );
 
            ELSE
                BEGIN
                    SELECT  @MemberID = member_id ,
                            @EffDate = eff_date
                    FROM    dbo.rlplfc (NOLOCK)
                    WHERE   rlplfc_id = @d_rlplfc_id;
                    IF @@rowcount = 0
                        SELECT  @MemberID = NULL ,
                                @EffDate = NULL;
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT rlplfc_id, eff_date, MONTH(eff_date)
		
         FROM dbo.rlplfc (NOLOCK)
         WHERE member_id  = @MemberID AND
         exp_date = @EffDate AND
         rlplfc_id <> @d_rlplfc_id
         ORDER BY eff_date DESC;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @li_rlplfc_id,
                        @rlplEff, @CMonth;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label2;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @li_rlplfc_id,
                                @rlplEff, @CMonth;
                        END;
                    SWL_Label2:
                    CLOSE @SWV_cursor_var1;
                    IF @li_rlplfc_id = 0
                        SET @NewCover = 0;
                    ELSE
        BEGIN
                            SELECT  @CarryOver = carry_over ,
                                    @Adj = adjustment
                            FROM    dbo.tiered_benefit_mbr (NOLOCK)
                            WHERE   rlplfc_id = @li_rlplfc_id; 
                            IF @@rowcount = 0
                                SELECT  @CarryOver = NULL ,
                                        @Adj = NULL;
                            SET @NewCover = @CMonth + @CarryOver + @Adj;
                        END;
	
                    INSERT  INTO dbo.tiered_benefit_mbr
                            ( rlplfc_id ,
                              carry_over ,
                              adjustment ,
                              h_user ,
                              h_datetime
                            )
                    VALUES  ( @d_rlplfc_id ,
                              @NewCover ,
                              0 ,
                              ORIGINAL_LOGIN() ,
                              GETDATE()
                            );  
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = @i_error_no;
            SET @SWP_Ret_Value1 = @s_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


    END;