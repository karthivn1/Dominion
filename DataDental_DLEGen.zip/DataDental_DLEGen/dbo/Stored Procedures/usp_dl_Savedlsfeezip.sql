﻿
CREATE PROCEDURE [dbo].[usp_dl_Savedlsfeezip] (@dlsfeeZip dbo.DlsFeeZip READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_fee_zip 
				 SET dls_batch_id = dfz.dls_batch_id
					  ,dls_fee_zip.dls_status = CASE WHEN dfz.dls_status='E' OR dfz.dls_status='P' THEN 'V'
				ELSE dls_fee_zip.dls_status END
					  --,dls_source = dfz.dls_source
					  ,zip_code_3 = dfz.zip_code_3
					  ,zip_code	  =	dfz.zip_code
				from @dlsfeeZip dfz
				WHERE dls_fee_zip.dls_sir_id = dfz.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END