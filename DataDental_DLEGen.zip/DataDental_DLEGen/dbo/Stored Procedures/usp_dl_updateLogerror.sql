﻿-- =============================================
-- Author:		Uthayan.S
-- Create date: 07 SEP 2017
-- Description:	Update dl_log_error corrected status from DSIR screen
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_updateLogerror]
	-- Add the parameters for the stored procedure here
	@dlslogerror dbo.Dllogerror READONLY
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
		SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dl_log_error 
				 SET corrected = dal.corrected
					 ,corrected_by = dal.corrected_by
					 ,corrected_time = FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:ff')				 
				from @dlslogerror dal
				WHERE dl_log_error.log_error_id = dal.log_error_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END