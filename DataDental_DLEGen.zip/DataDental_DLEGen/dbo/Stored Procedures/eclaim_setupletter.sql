﻿CREATE PROCEDURE [dbo].[eclaim_setupletter]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:33:33 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1




000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @ProcessCnt INT;
        DECLARE @UpdateCnt INT;
        DECLARE @DT DATETIME2(0);
        DECLARE @TD DATE;
        DECLARE @eClaimID INT;
        DECLARE @STAT INT;
        DECLARE @MatrixID INT;
        --DECLARE @SWV_cursor_var1 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY

            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  eclaim_id INT ,
                  status INT ,
                  matrix_id INT
                );
            
--set debug file to 'lettersetup.trc';
--trace on;

            SET @DT = GETDATE(); 
            SET @TD = CONVERT(DATE, @DT); 

-- Create a temp table t_eclaim_h with an extra field named link.
            SET @ProcessCnt = 0;
            SET @UpdateCnt = 0;
            
            INSERT  INTO @SWV_cursor_var1
                    ( eclaim_id ,
                      status ,
                      matrix_id
                    )
                    SELECT  e.eclaim_id ,
                            e.status ,
                            m.matrix_id
                    FROM    dbo.eclaim_h e ( NOLOCK ) ,
                            dbo.eclaim_matrix m ( NOLOCK )
                    WHERE   e.error_code = m.error_code
                            AND e.status IN ( 4, 5 );
           /* SET @SWV_cursor_var1 = CURSOR  FOR SELECT e.eclaim_id, e.status, m.matrix_id
	  
      FROM dbo.eclaim_h e (NOLOCK), dbo.eclaim_matrix m (NOLOCK)
      WHERE e.error_code = m.error_code
      AND e.status IN(4,5);
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID, @STAT, @MatrixID;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN

                    SELECT  @eClaimID = eclaim_id ,
                            @STAT = status ,
                            @MatrixID = matrix_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur_i;
                    INSERT  INTO dbo.eclaim_letters
                            ( eclaim_id ,
                              eclaim_matrix_id ,
                              h_user ,
                              h_datetime ,
                              run_date
                            )
                    VALUES  ( @eClaimID ,
                              @MatrixID ,
                              ORIGINAL_LOGIN(),
                              GETDATE() ,
                              CONVERT(DATE, GETDATE())
                            );
	
                    IF @STAT = 5 -- pend for letter
                        UPDATE  dbo.eclaim_h
                        SET     status = 6 ,
                                h_user = 'LetterSync' ,
                                h_datetime = GETDATE()
                        WHERE   eclaim_id = @eClaimID;
                    ELSE
                 UPDATE  dbo.eclaim_h
                       SET     status = 10 ,
                                h_user = 'LetterSync' ,
                                h_datetime = GETDATE()
                        WHERE   eclaim_id = @eClaimID;
	                    
                    SET @UpdateCnt = @UpdateCnt + 1; 
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID, @STAT, @MatrixID;
                    SET @cur_i = @cur_i + 1;
                END;
            -- CLOSE @SWV_cursor_var1;
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('eClaims Letter table updated;  Processed: ',
                                         @ProcessCnt, ' Updated: ', @UpdateCnt);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


----------------------------------------------------------------------
    END;