﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC [usp_api_EligibilitySubmissionValidation] 211,'',2,'',0,'226-52-6437','','TL22652643900',0,0,'','','',0,'','','','','','','','','','','','SGupdateImplBL'
-- =============================================
CREATE PROC [dbo].[usp_api_EligibilitySubmissionValidation] 
@GroupID INT,@GroupAltID Char(20),@PlanID INT,@PlanName Char(20),
@SubID INT,@SubSSN Char(11),@SubSourceID char(20),@SubAltID char(20),@DepSW bit,
@PatID INT,@PatSSN Char(11),@patSourceID char(20),@PatAltID char(20),
@PCPID INT,@PCPNPID Char(10),@PCPAltID Char(40),
@NewGroupID INT,@NewGroupAltID Char(20),@NewPlanID INT,@NewPlanName Char(20),
@NewPCPID INT,@NewPCPNPID Char(10),@NewPCPAltID Char(40),
@ProdID INT=0,@ProdAltID Char(20)=null,@AsOfDate DATE,@moduleName nVarchar(50)
AS
BEGIN
DECLARE @gID INT=0;
DECLARE @pID INT=0; 
DECLARE @sID INT=0; 
DECLARE @pcID INT=0; 
DECLARE @depID INT=0; 

DECLARE @mastorGID INT=0;
DECLARE @prdID INT=0;
DECLARE @ProdType char(2)=null;


DECLARE @planOption nVarchar(10)=null
DECLARE @planInsType char(2)=null;
DECLARE @groupType char(2)=null;
DECLARE @groupBillType char(2)=null;
DECLARE @ErrorMsg nVarchar(50)='';
DECLARE @DepStatus INT=0;
DECLARE @SubStatus INT=0;

DECLARE @NewgID INT=0;
DECLARE @NewpID INT=0; 
DECLARE @NewpcID INT=0;


	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempErrorTable') IS NOT NULL
    DROP TABLE #tempErrorTable
IF OBJECT_ID('tempdb..#tempMGP') IS NOT NULL
    DROP TABLE #tempMGP
IF OBJECT_ID('tempdb..#tempPatient') IS NOT NULL
    DROP TABLE #tempPatient
IF OBJECT_ID('tempdb..#tempParentGroup') IS NOT NULL
    DROP TABLE #tempParentGroup

IF OBJECT_ID('tempdb..#tempSubStatus') IS NOT NULL
    DROP TABLE #tempSubStatus

IF OBJECT_ID('tempdb..#tempDepStatus') IS NOT NULL
    DROP TABLE #tempDepStatus

--IF OBJECT_ID('tempdb..#tempProviders') IS NOT NULL
--    DROP TABLE #tempProviders
--IF OBJECT_ID('tempdb..#tempProviderAdd') IS NOT NULL
--    DROP TABLE #tempProviderAdd

Create table #tempErrorTable(ID int identity(1,1),ErrorName nvarchar(50),ErrorDesc nvarchar(1000))	
CREATE TABLE #tempMGP(mb_gr_pl_id INT,member_id INT null,eff_gr_pl date null,exp_gr_pl date null,SubStatus int null)
Create Table #tempPatient(rlplfc_id INT,mb_gr_pl_id INT,member_id INT null,eff_date date null,exp_date date null,DepStatus int null) 
Create Table #tempParentGroup(group_id INT,alt_id Char(20),group_type Char(2),bill_type Char(2))
--Create Table #tempClaim(ClaimID INT,claim_status nVarchar(50)) 
--Create Table #tempProviders(PvID int,pvstat Char(5),PvLName char(20),PvFName char(20),PVMI Char(2),PvTaxID char(10))
--Create Table #tempProviderAdd(PvID int,PvAddr1 char(30) null,PvAddr2 char(30) null,city Char(30) null,country Char(3) null,county Char(20) null,state Char(3) null,zip char(10) null)
            	
BEGIN TRY

IF @AsOfDate='1900-01-01'
BEGIN
SET @AsOfDate=GETDATE()
END

--Validate Group
EXEC @gID=usp_api_ValidateGroup @GroupID,@GroupAltID,@ErrorMsg OUT

IF Len(@ErrorMsg)>0
BEGIN
	  INSERT INTO #tempErrorTable Values ('Group',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END
   ---need to get the groupID 
   PRINT @gID

Select @groupType=g.group_type,@groupBillType=g.bill_type From [group] g Where g.group_id=@gID

IF @moduleName='SGupdateImplBL'
BEGIN
 IF @groupType='SG'
 BEGIN
  Select @mastorGID=g.group_parent From [group] g Where g.group_id=@gID
 END
 ELSE IF @groupType='MS'
 BEGIN
   Select @mastorGID=g.group_id From [group] g Where g.group_id=@gID
 END
 ELSE
 BEGIN
       INSERT INTO #tempErrorTable Values ('Group','Group has to be Single Group or Master Single Group.');
	   THROW 51000,'User Validation Faild',1
 END

 INSERT INTO #tempParentGroup 
	  Select  
			g.group_id,  
			g.alt_id,  
			g.group_type,  
			g.bill_type
			FROM [group] g, group_status gs 
			WHERE g.group_id = gs.group_id and gs.exp_date is null and g.group_id =@mastorGID


IF NOT EXISTS(Select group_id from #tempParentGroup)
	BEGIN
	  INSERT INTO #tempErrorTable Values ('Group','Unable to find Master Single Group for the provided SG ');
	   THROW 51000,'User Validation Faild',1
	END

END


 --validatePlan
EXEC @pID=usp_api_ValidatePlan @PlanID,@PlanName,@planOption out,@planInsType out,@ErrorMsg out

IF Len(@ErrorMsg)>0
BEGIN
	  INSERT INTO #tempErrorTable Values ('Plan',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END

 --needs to take the plan_id>0 and check the options FFS-->PPO
 --select *from [plan]
 
--PRINT 'PlanID' + @pID + 'Plan Option' + @planOption + 'Plan Ins_type' + @planInsType

--validateSub

IF @groupType='MS'
BEGIN

IF @SubID>0
BEGIN

IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				JOIN [group] g on g.group_id=r.group_id
		        and r.plan_id =@pID and r.member_id = @SubID AND g.group_parent=@gID)
				BEGIN
				---add
					Insert Into #tempMGP
						Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null 
						FROM rlmbgrpl r
						JOIN [group] g on g.group_id=r.group_id
						and r.plan_id =@pID and r.member_id = @SubID AND g.group_parent=@gID
						order by mb_gr_pl_id
				END
				 
END
ELSE IF len(@SubSSN)>0
BEGIN
   IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				JOIN [group] g on g.group_id=r.group_id
				Join member m on m.member_id=r.member_id 
				Where g.group_parent =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN)
				BEGIN

				INSERT INTO #tempMGP
						SELECT r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null 
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						JOIN [group] g on g.group_id=r.group_id
						AND r.plan_id =@pID AND g.group_parent=@gID AND  m.new_ssn=@SubSSN 
						AND r.member_id>0 
						order by mb_gr_pl_id

				END
			
END
ELSE IF len(@SubSourceID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				JOIN [group] g on g.group_id=r.group_id
				Join member m on m.member_id=r.member_id 
				Where g.group_parent =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID)
				BEGIN

				INSERT INTO #tempMGP
						SELECT r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null 
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						JOIN [group] g on g.group_id=r.group_id
						AND r.plan_id =@pID AND g.group_parent=@gID AND m.source_id=@SubSourceID
						AND r.member_id>0 
						order by mb_gr_pl_id

				END
			
END

ELSE IF len(@SubAltID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				JOIN [group] g on g.group_id=r.group_id
				Join member m on m.member_id=r.member_id 
				Where g.group_parent =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID)
				BEGIN
				  INSERT INTO #tempMGP
						SELECT r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null 
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						JOIN [group] g on g.group_id=r.group_id
						AND r.plan_id =@pID AND g.group_parent=@gID AND m.alt_id=@SubAltID
						AND r.member_id>0 
						order by mb_gr_pl_id
				END
			
END

END
ELSE
BEGIN

 IF @SubID>0
BEGIN

IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl Where group_id =@gID
		        and plan_id =@pID and member_id = @SubID)
				BEGIN
				---add
					Insert Into #tempMGP
						Select mb_gr_pl_id,member_id,eff_gr_pl,exp_gr_pl,null 
						FROM rlmbgrpl Where group_id =@gID
						and plan_id =@pID and member_id = @SubID
						order by mb_gr_pl_id
				END
				 
END
ELSE IF len(@SubSSN)>0
BEGIN
   IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN
						order by r.mb_gr_pl_id

				END
			
END
ELSE IF len(@SubSourceID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID
						order by r.mb_gr_pl_id
				END
			
END

ELSE IF len(@SubAltID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID
						order by r.mb_gr_pl_id
				END
			
END

END
IF EXISTS(Select mb_gr_pl_id from #tempMGP)
BEGIN 
  IF EXISTS(Select t.mb_gr_pl_id from #tempMGP t 
			JOIN #tempMGP s	ON s.member_id<>t.member_id)
  BEGIN
	 INSERT INTO #tempErrorTable Values ('Sub','Multiple Subscribers returned for criteria provided. ');
	 THROW 51000,'User Validation Faild',1
	END

SELECT TOP 1 *
	INTO #tempSubStatus
	FROM #tempMGP t
	ORDER BY t.mb_gr_pl_id DESC

	--Active = 1001,
 --           New,
 --           Future,
 --           Term

	--Select *

IF EXISTS(SELECT *
	FROM #tempSubStatus t WHERE  t.exp_gr_pl is null)
	BEGIN
				IF EXISTS(SELECT *
			FROM #tempSubStatus t WHERE t.eff_gr_pl> @AsOfDate AND t.exp_gr_pl is null)
			BEGIN
				SET @SubStatus=1003
			END
			ELSE 
			BEGIN
				SET @SubStatus=1001
			END
	END
	ELSE
	BEGIN
		SET @SubStatus=1004	
	END

		Update t set t.SubStatus=@SubStatus
		From #tempSubStatus t

	--Update t set t.SubStatus=1003
	--	From #tempSubStatus t Where t.eff_gr_pl> @AsOfDate
	--	AND t.exp_gr_pl is null 

	----Select *
	--Update t set t.SubStatus=1001
	--	From #tempSubStatus t Where t.eff_gr_pl between '1753/01/01' and @AsOfDate
	--	AND t.exp_gr_pl is null 
 ---- Select *
	--Update t set t.SubStatus=1004
	--	From #tempSubStatus t Where t.exp_gr_pl is not null 	

 Select @sID=t.member_id 
		From #tempSubStatus t

  --IF EXISTS(Select t.SubStatus From #tempMGP t 
		--	WHERE t.SubStatus=1001)
		--	BEGIN
  --          Select @SubStatus=t.SubStatus,@sID=t.member_id 
		--		   From #tempMGP t WHERE t.SubStatus=1001
  --          END
		--	ELSE IF EXISTS(Select t.SubStatus From #tempMGP t 
		--	WHERE t.SubStatus=1003)
		--	BEGIN
		--	   Select @SubStatus=t.SubStatus,@sID=t.member_id 
		--		   From #tempMGP t WHERE t.SubStatus=1003
		--	END
		--	ELSE IF EXISTS(Select t.SubStatus From #tempMGP t 
		--	WHERE t.SubStatus=1004)
		--	BEGIN
		--		Select @SubStatus=t.SubStatus,@sID=t.member_id 
		--		   From #tempMGP t WHERE t.SubStatus=1004
		--	END

---Validate dep

IF @DepSW=0
BEGIN
 IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Where r.member_id=t.member_id AND r.rlplfc_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Where r.member_id=t.member_id AND r.rlplfc_id>0
						 order by r.rlplfc_id
				   END

END
ELSE
BEGIN
 --validatePatient
 IF @PatID>0
 BEGIN
 
 IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.member_id=@PatID AND r.rlplfc_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.member_id=@PatID AND r.rlplfc_id>0
						 order by r.rlplfc_id
				   END

 END
 ELSE IF len(@PatSSN)>0
 BEGIN
   IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.new_ssn=@PatSSN AND r.rlplfc_id>0 AND r.member_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.new_ssn=@PatSSN AND r.rlplfc_id>0 AND r.member_id>0
						 order by r.rlplfc_id
				   END

 END
 
 ELSE IF len(@PatAltID)>0
 BEGIN
   IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.alt_id=@PatAltID AND r.rlplfc_id>0 AND r.member_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
       			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.alt_id=@PatAltID AND r.rlplfc_id>0 AND r.member_id>0
						 order by r.rlplfc_id
				   END

 END
 ELSE IF len(@patSourceID)>0
 BEGIN
   IF EXISTS (Select r.rlplfc_id
            	 FROM rlplfc r
				 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
				 Join member m on m.member_id=r.member_id
				 Where m.source_id=@patSourceID AND r.rlplfc_id>0 AND r.member_id>0)
				   BEGIN 
				     INSERT INTO #tempPatient
					 Select r.rlplfc_id,r.mb_gr_pl_id,r.member_id,r.eff_date,r.exp_date,null
            			 FROM rlplfc r
						 Join #tempMGP t on t.mb_gr_pl_id=r.mb_gr_pl_id
						 Join member m on m.member_id=r.member_id
						 Where m.source_id=@patSourceID AND r.rlplfc_id>0 AND r.member_id>0
						 order by r.rlplfc_id
				   END

 END

END

 IF EXISTS(Select t.rlplfc_id from #tempPatient t 
			JOIN #tempPatient s ON s.member_id<>t.member_id)
 BEGIN
	 INSERT INTO #tempErrorTable Values ('Patient','Multiple members (rlplfc) returned for criteria provided');
	 THROW 51000,'User Validation Faild',1
 END


 IF EXISTS(Select rlplfc_id from #tempPatient)
 BEGIN

 --Check the dep status

 SELECT TOP 1 *
	INTO #tempDepStatus
	FROM #tempPatient t
	ORDER BY t.rlplfc_id DESC


IF EXISTS(SELECT *
	FROM #tempDepStatus t WHERE  t.exp_date is null)
	BEGIN
				IF EXISTS(SELECT *
			FROM #tempDepStatus t WHERE t.eff_date> @AsOfDate AND t.exp_date is null)
			BEGIN
				SET @DepStatus=1003
			END
			ELSE 
			BEGIN
				SET @DepStatus=1001
			END
	END
	ELSE
	BEGIN
		SET @DepStatus=1004	
	END

		Update t set t.DepStatus=@DepStatus
		From #tempDepStatus t


 ----Select *
	--Update t set t.DepStatus=1003
	--	From #tempDepStatus t Where t.eff_date> @AsOfDate
	--	AND t.exp_date is null 

	----Select *
	--Update t set t.DepStatus=1001
	--	From #tempDepStatus t Where t.eff_date between '1753/01/01' and @AsOfDate
	--	AND t.exp_date is null 
 ---- Select *
	--Update t set t.DepStatus=1004
	--	From #tempDepStatus t Where t.exp_date is not null 	

Select @depID=t.member_id 
		 From #tempDepStatus t

--IF EXISTS(Select t.DepStatus From #tempPatient t 
--			WHERE t.DepStatus=1001)
--			BEGIN
--            Select @DepStatus=t.DepStatus,@depID=t.member_id 
--				   From #tempPatient t WHERE t.DepStatus=1001
--            END
--			ELSE IF EXISTS(Select t.DepStatus From #tempPatient t 
--			WHERE t.DepStatus=1003)
--			BEGIN
--			    Select @DepStatus=t.DepStatus,@depID=t.member_id 
--				   From #tempPatient t WHERE t.DepStatus=1003
--			END
--			ELSE IF EXISTS(Select t.DepStatus From #tempPatient t 
--			WHERE t.DepStatus=1004)
--			BEGIN
--				 Select @DepStatus=t.DepStatus,@depID=t.member_id 
--				   From #tempPatient t WHERE t.DepStatus=1004
--			END

--Select @DepStatus= t.DepStatus,@depID=t.member_id From #tempPatient t

 END
 ELSE
 BEGIN

 ---if dep info not present set depstatus as new
     SET @DepStatus=1002
 END
 ---get the patient id

END
ELSE 
BEGIN

SET @SubStatus=1002

END


IF @planOption<>'PPO'
BEGIN

EXEC @pcID=usp_api_ValidatePCP @PCPID,@PCPNPID,@PCPAltID,@ErrorMsg out

IF Len(@ErrorMsg)>0
BEGIN
	  INSERT INTO #tempErrorTable Values ('PCP',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END

END

--get Fc_ID information

PRINT @pcID

--Validate new Group
IF @NewGroupID>0 OR LEN(@NewGroupAltID)>0
BEGIN

EXEC @NewgID=usp_api_ValidateGroup @NewGroupID,@NewGroupAltID,@ErrorMsg OUT

IF Len(@ErrorMsg)>0
BEGIN
	  INSERT INTO #tempErrorTable Values ('New Group',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END
   ---need to get the groupID 
   PRINT @NewgID
END


 --validate New Plan
IF @NewPlanID>0 OR LEN(@NewPlanName)>0
BEGIN
DECLARE @NewplanOption nVarchar(10)=''
DECLARE @NewplanInsType char(2)='';

EXEC @NewpID=usp_api_ValidatePlan @NewPlanID,@NewPlanName,@NewplanOption out,@NewplanInsType out,@ErrorMsg out

IF Len(@ErrorMsg)>0
BEGIN
	  INSERT INTO #tempErrorTable Values ('New Plan',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END

--PRINT 'New PlanID' + @NewpID 

END

---Validate New PCP
IF @NewPCPID>0 OR LEN(@NewPCPNPID)>0 OR LEN(@NewPCPAltID)>0
BEGIN
EXEC @NewpcID=usp_api_ValidatePCP @NewPCPID,@NewPCPNPID,@NewPCPAltID,@ErrorMsg out

IF Len(@ErrorMsg)>0
BEGIN
	  INSERT INTO #tempErrorTable Values ('New PCP',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END

END

IF @moduleName='SGupdateImplBL'
BEGIN
	 --validate Producer
	EXEC @prdID=usp_api_Producer @ProdID,@ProdAltID out,@ProdType out,@ErrorMsg out

	IF Len(@ErrorMsg)>0
	BEGIN
		  INSERT INTO #tempErrorTable Values ('Producer',@ErrorMsg);
		   THROW 51000,'User Validation Faild',1
	END

END


Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempErrorTable t

DECLARE @ParentAlt varchar(20)=null;
DECLARE @ParentSSN varchar(11)=null;
DECLARE @ChildAlt varchar(20)=null;
DECLARE @ChildSSN varchar(11)=null;
DECLARE @ChildNewSSN varchar(11)=null;



IF(@sID>0)
BEGIN

Select @ParentAlt=ISNULL(m.alt_id,''),@ParentSSN=ISNULL(m.new_ssn,'')
	From member m
	Where member_id=@sID

Select @ChildAlt=ISNULL(m.alt_id,''),@ChildSSN=ISNULL(m.member_ssn,''),@ChildNewSSN=ISNULL(m.new_ssn,'')
	From member m
	JOIN #tempPatient t on t.member_id= m.member_id
	
END



IF(@sID=0)
BEGIN

Select @sID AS SUBID,@depID AS DepID,@gID AS GroupID,@groupType AS GroupType,@groupBillType AS GroupBillType,@pID AS PlanID,@planInsType AS PlanInsType,@planOption AS PlanOption,
@DepStatus AS DepStatus,@SubStatus AS SubStatus,IIF(@planOption='HMO',@PCPID,@pcID) AS subPCPID
--@pcID as subPCPID 

--added for SG defect

---get member info 

END
ELSE
BEGIN

--Added for fcid fix
Select @pcID=r.facility_id
	From rlplfc r
	JOIN #tempPatient tp on tp.rlplfc_id=r.rlplfc_id
	Where 1=1
	AND r.member_id=@sID


Select @sID AS SUBID,@depID AS DepID,@gID AS GroupID,@groupType AS GroupType,@groupBillType AS GroupBillType,@pID AS PlanID,@planInsType AS PlanInsType,@planOption AS PlanOption,
@DepStatus AS DepStatus,@SubStatus AS SubStatus,@pcID as subPCPID,tp.mb_gr_pl_id as MbGrPlID,tp.eff_date as SubEffDate,tp.exp_date as SubExpDate,
@ParentAlt AS ParentAltID,@ParentSSN AS ParentSSN,@ChildAlt AS SubAltID,@ChildSSN AS SubSSN,@ChildNewSSN AS NewSSN
	From #tempMGP t
	Left JOIN #tempPatient tp on t.mb_gr_pl_id=tp.mb_gr_pl_id

--Select @sID AS SUBID,@depID AS DepID,@gID AS GroupID,@groupType AS GroupType,@pID AS PlanID,@planInsType AS PlanInsType,@planOption AS PlanOption,
--@DepStatus AS DepStatus,@SubStatus AS SubStatus,tp.rlplfc_id as subPCPID,tp.mb_gr_pl_id as MbGrPlID,tp.eff_date as SubEffDate,tp.exp_date as SubExpDate
--	From #tempMGP t
--	Left JOIN #tempPatient tp on t.mb_gr_pl_id=tp.mb_gr_pl_id

END
---get member info 
Select 
	RTRIM(m.member_id) as MemberID,
	RTRIM(m.family_id) as FamilyID,
	RTRIM(ISNULL(m.alt_id,'')) as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	RTRIM(m.first_name) as FirstName,
	RTRIM(m.middle_init) as MiddleInitial,
	RTRIM(m.last_name) as LastName,
	RTRIM(m.date_of_birth) as DOB,
	RTRIM(m.member_ssn) as SSN,
	RTRIM(m.oed) as OED,
	RTRIM(m.dod) as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	RTRIM(m.student_flag) AS Student_flag,
	RTRIM(m.action_code) as ActionCode,
	RTRIM(m.h_datetime),
	RTRIM(m.h_msi) as UserMSI,
	RTRIM(m.h_action) as UserAction,
	RTRIM(m.h_user) as [User],
	RTRIM(m.hire_date) as Hire,
	RTRIM(m.member_ssn) as SSN,
	RTRIM(m.new_ssn) as NewSSN,
	RTRIM(m.source_id) as SrcID,
	RTRIM(m.ext_id_type) as ExtIdType,
	RTRIM(m.student_exp) as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
	m.paperless AS PaperlessText
	From member m
	Where m.member_id=@sID

--get member addr
Select 
	a.addr_type AS [Type],
	RTRIM(ISNULL(a.addr1,'')) AS Addr1,
	RTRIM(ISNULL(a.addr2,'')) AS Addr2,
	RTRIM(a.city) AS City,
	RTRIM(a.country) AS Country,
	RTRIM(a.county) AS County,
	RTRIM(a.[state]) AS [State],
	RTRIM(LEFT(a.zip,5)) AS Zip,
	RTRIM(p.home_phone) AS Home,
	RTRIM(p.home_ext) AS HomeX,
	RTRIM(p.work_phone) AS Work,
	RTRIM(p.work_ext) AS WorkX,
	RTRIM(p.fax) AS Fax,
	RTRIM(p.email) AS Email
		From [address] a 
		join mbr_phone p on p.address_id=a.address_id
		Where a.subsys_code='MB' AND a.addr_type='L'
		AND a.sys_rec_id=@sID 
		AND a.sys_rec_id>0 

---load master and producer for single group submission
IF @moduleName='SGupdateImplBL'
BEGIN

IF EXISTS(Select *From #tempParentGroup)
BEGIN

Select RTRIM(group_id) as GroupID,RTRIM(alt_id) as GroupAltID,RTRIM(group_type) as GroupType,RTRIM(bill_type) as GroupBillType,RTRIM(@prdID) as ProducerID,
       RTRIM(@ProdAltID) as ProducerAltID,RTRIM(@ProdType) AS ProducerTypeID from #tempParentGroup tp

END

END

--Member group info
--Select @gID as GroupID,@pID As PlanID,@fID as FCID,@pcID as PCPID,@planInsType as PlanInsType,@planOption as PlanOption,@PvFound as PvFound,
--	@finalPvID as PVID,t.member_id as SubID,tp.member_id as PatientID
--	From #tempMGP t
--	JOIN #tempPatient tp on t.mb_gr_pl_id=tp.mb_gr_pl_id

END TRY
BEGIN CATCH
IF ERROR_MESSAGE()='User Validation Faild'
BEGIN
  Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempErrorTable t
END
ELSE 
 THROW; 
END CATCH

END