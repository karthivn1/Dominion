﻿CREATE PROCEDURE [dbo].[dlp_up_fac_net]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    



	/*error variable*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/

        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(18);
        DECLARE @s_proc_name CHAR(18);
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);

        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_config_id INT;
        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT; 
        DECLARE @s_batch_status CHAR(1);

        DECLARE @n_def_eff_date CHAR(10);
        DECLARE @d_def_eff_date DATE;
        DECLARE @n_def_exp_date CHAR(10);
        DECLARE @d_def_exp_date DATE;
        DECLARE @n_has_term_date CHAR(1);
        DECLARE @n_net_id INT;

        DECLARE @t_sir_id INT;
	/* 20130804$$ks - increase alt_id for facility 
	 *	Chaned name of variables for t_ to fc_ for vars that changed size*/
        DECLARE @fc_alt_id CHAR(40);
        DECLARE @t_fc_type CHAR(2);
        DECLARE @t_fc_name CHAR(50);
        DECLARE @t_fc_status CHAR(2);
        DECLARE @t_fc_stat_eff_date CHAR(10);
        DECLARE @t_fc_stat_exp_date CHAR(10);
        DECLARE @t_fc_state CHAR(2);
        DECLARE @t_fc_license CHAR(9);
        DECLARE @t_fc_lrenew_dt CHAR(10);
	/* 20130804$$ks - since vendor alt_id can be fc alt_id must expand this field too */
        DECLARE @fc_vendor_id CHAR(40);
        DECLARE @t_fc_tax_id CHAR(9);
        DECLARE @t_tin CHAR(1);
        DECLARE @t_fc_area CHAR(11);
        DECLARE @t_fc_rep CHAR(20);
        DECLARE @t_fc_source CHAR(2);
        DECLARE @t_phone_elig CHAR(1);
        DECLARE @t_fax_elig CHAR(1);
        DECLARE @t_print_dir CHAR(1);
        DECLARE @t_fc_mst_con_dt CHAR(10);
        DECLARE @t_emergency_phone CHAR(14);
        DECLARE @t_em_phone_ext CHAR(5);
        DECLARE @t_emg_contact_type CHAR(2);
        DECLARE @t_legal_entity CHAR(2);
        DECLARE @t_fc_tax_name CHAR(50);
        DECLARE @t_pnrx CHAR(1);
        DECLARE @t_no2 CHAR(1);
        DECLARE @t_hndacs CHAR(1);
        DECLARE @t_fc_capacity CHAR(11);
        DECLARE @t_fc_warn CHAR(9);
        DECLARE @t_fc_no_new CHAR(9);
        DECLARE @t_fc_max_enrl CHAR(11);
        DECLARE @t_fc_opr_tory CHAR(11);
        DECLARE @fc_parent_id CHAR(40);
        DECLARE @t_barrier_c CHAR(10);
        DECLARE @t_fc_cur_enrl CHAR(11);
        DECLARE @t_next_cap_date CHAR(10);
        DECLARE @t_net_id CHAR(20);
        DECLARE @t_contract_type CHAR(3);
        DECLARE @t_net_fc_eff_date CHAR(10);
        DECLARE @t_ovr_ride CHAR(1);
        DECLARE @t_net_fc_exp_date CHAR(10);
        DECLARE @t_addr_type CHAR(2);
        DECLARE @t_addr1 CHAR(30);
        DECLARE @t_addr2 CHAR(30);
        DECLARE @t_zip CHAR(10);
        DECLARE @t_city CHAR(30);
        DECLARE @t_state CHAR(2);
        DECLARE @t_county CHAR(20);
        DECLARE @t_country CHAR(3);
        DECLARE @t_mail CHAR(1);
        DECLARE @t_con_type CHAR(2);
        DECLARE @t_con_lname CHAR(15);
        DECLARE @t_con_fname CHAR(10);
        DECLARE @t_title CHAR(25);
        DECLARE @t_phone1 CHAR(14);
        DECLARE @t_ext1 CHAR(5);
        DECLARE @t_phone2 CHAR(14);
        DECLARE @t_ext2 CHAR(5);
        DECLARE @t_fax CHAR(14);
        DECLARE @t_dds_fc_id INT;
        DECLARE @t_dds_net_id INT;
        DECLARE @t_action_code CHAR(2);

        DECLARE @i_fc_id INT;
        DECLARE @as_action_code CHAR(2);
        DECLARE @as_fc_stat_eff DATE;
        DECLARE @as_fc_net_eff DATE;
        DECLARE @as_fc_net_exp DATE;
  DECLARE @d_fc_stat_eff_date DATE;
        DECLARE @d_fc_lrenew_dt DATE;
        DECLARE @d_fc_area INT;
        DECLARE @d_fc_rep INT;
        DECLARE @d_fc_mst_con_dt DATE;
        DECLARE @d_fc_capacity INT;
        DECLARE @d_fc_warn DECIMAL(5, 2);
        DECLARE @d_fc_no_new DECIMAL(5, 2);
        DECLARE @d_fc_max_enrl INT;
        DECLARE @d_fc_opr_tory INT;
        DECLARE @d_barrier_c DECIMAL(6, 2);
        DECLARE @d_fc_cur_enrl INT;
        DECLARE @d_next_cap_date DATE;
        DECLARE @d_net_id INT;
        DECLARE @d_net_fc_eff_date DATE;
        DECLARE @d_net_fc_exp_date DATE;
        DECLARE @d_zip INT;
        DECLARE @d_phone_err CHAR(1);
        DECLARE @d_phone1 INT;
        DECLARE @d_ext1 INT;
        DECLARE @d_phone2 INT;
        DECLARE @d_ext2 INT;
        DECLARE @d_fax INT;

        DECLARE @t_action_date DATE;
        DECLARE @curr_fc_id INT;
        DECLARE @curr_fcstat_id INT;
        DECLARE @curr_vendor_id INT;
        DECLARE @curr_datetime DATETIME;
        DECLARE @curr_fcstat CHAR(2);
        DECLARE @curr_fcstat_eff DATE;
        DECLARE @curr_fcstat_exp DATE;
        DECLARE @curr_fcnet_id INT;
        DECLARE @curr_fcnet_net INT;
        DECLARE @curr_fcnet_eff DATE;
        DECLARE @curr_fcnet_exp DATE;
        DECLARE @tape_fcnet_eff DATE;
        DECLARE @tape_fcnet_exp DATE;

        DECLARE @ls_user CHAR(20);
        DECLARE @d_valid_error INT;
        DECLARE @d_error_descr VARCHAR(64);
        DECLARE @n_error_no INT; 
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @n_process_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @n_in_transaction CHAR(1);
        --DECLARE @cSIR CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @v_Null INT;
		DECLARE @created_by CHAR(15)


        SET NOCOUNT ON;
        BEGIN TRY

            SET @s_proc_name = 'up_fac_net';
            SET @s_sir_def_name = 'fac_net';
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, @s_proc_name;
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
				BEGIN
				SET @a_error_no=0
                RAISERROR('Invalid SP Name',16,1);
				END
	
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
				BEGIN
				SET @a_error_no=0
                RAISERROR('Invalid SIR TABLE Definition',16,1);
			END
	
            SELECT  @i_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
           
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;

					SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
           
            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                     -- ORIGINAL_LOGIN() ,
					 @created_by,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
           
            SET @n_process_count = 0;
 SET @n_succ_count = 0;
            SET @n_in_transaction = 'N';
            SET @ls_user = CONCAT('dl', @a_batch_id);


/*
	DELETE FROM dl_action 
	WHERE batch_id = a_batch_id AND process_status = "N" 
	AND dls_sir_id not in (SELECT dls_sir_id FROM dls_fac_net 
		WHERE dls_batch_id = a_batch_id and dls_status = "P"); 

	DELETE FROM dl_log_error 
	WHERE config_bat_id = a_batch_id AND sp_id = i_sp_id
	AND dls_sir_id in (SELECT dls_sir_id FROM dls_fac_net 
		WHERE dls_batch_id = a_batch_id and dls_status = "P"); 
*/


            /*
			SET @cSIR = CURSOR  FOR SELECT	dls_sir_id, alt_id, fc_type, fc_name, fc_stat_eff_date,
		fc_state, fc_license, fc_lrenew_dt, vendor_id, fc_tax_id,
		tin, fc_area, fc_rep, fc_source, phone_elig, fax_elig,
		print_dir, fc_mst_con_dt, emergency_phone, em_phone_ext,
		emg_contact_type, legal_entity, fc_tax_name, pnrx, no2,
		hndacs, fc_capacity, fc_warn, fc_no_new, fc_max_enrl,
		fc_opr_tory, parent_id, barrier_c, fc_cur_enrl, next_cap_date,
		net_id, contract_type, net_fc_eff_date, ovr_ride,
		net_fc_exp_date, addr_type, addr1, addr2, zip, city, state,
		county, country, mail, con_type, con_lname, con_fname,
		title, phone1, ext1, phone2, ext2, fax,
		dls_facility_id, dls_network_id, dls_action_code
	
      FROM dbo.dls_fac_net (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'P';
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @fc_alt_id, @t_fc_type,
                @t_fc_name, @t_fc_stat_eff_date, @t_fc_state, @t_fc_license,
                @t_fc_lrenew_dt, @fc_vendor_id, @t_fc_tax_id, @t_tin,
                @t_fc_area, @t_fc_rep, @t_fc_source, @t_phone_elig,
                @t_fax_elig, @t_print_dir, @t_fc_mst_con_dt,
                @t_emergency_phone, @t_em_phone_ext, @t_emg_contact_type,
                @t_legal_entity, @t_fc_tax_name, @t_pnrx, @t_no2, @t_hndacs,
                @t_fc_capacity, @t_fc_warn, @t_fc_no_new, @t_fc_max_enrl,
                @t_fc_opr_tory, @fc_parent_id, @t_barrier_c, @t_fc_cur_enrl,
                @t_next_cap_date, @t_net_id, @t_contract_type,
                @t_net_fc_eff_date, @t_ovr_ride, @t_net_fc_exp_date,
                @t_addr_type, @t_addr1, @t_addr2, @t_zip, @t_city, @t_state,
                @t_county, @t_country, @t_mail, @t_con_type, @t_con_lname,
                @t_con_fname, @t_title, @t_phone1, @t_ext1, @t_phone2, @t_ext2,
                @t_fax, @t_dds_fc_id, @t_dds_net_id, @t_action_code;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                  alt_id  char(40),
					fc_type  char(2),
					fc_name  char(50),
					fc_stat_eff_date  char(10),
					fc_state  char(2),
					fc_license  char(18),
					fc_lrenew_dt  char(10),
					vendor_id  char(40),
					fc_tax_id  char(9),
					tin  char(1),
					fc_area  char(11),
					fc_rep  char(20),
					fc_source  char(2),
					phone_elig  char(1),
					fax_elig  char(1),
					print_dir  char(1),
					fc_mst_con_dt  char(10),
					emergency_phone  char(14),
					em_phone_ext  char(5),
					emg_contact_type  char(2),
					legal_entity  char(2),
					fc_tax_name  char(50),
					pnrx  char(1),
					no2  char(1),
					hndacs  char(1),
					fc_capacity  char(11),
					fc_warn  char(9),
					fc_no_new  char(9),
					fc_max_enrl  char(11),
					fc_opr_tory  char(11),
					parent_id  char(40),
					barrier_c  char(10),
					fc_cur_enrl  char(11),
					next_cap_date  char(10),
					net_id  char(20),
					contract_type  char(3),
					net_fc_eff_date  char(10),
					ovr_ride  char(1),
					net_fc_exp_date  char(10),
					addr_type  char(2),
					addr1  char(30),
					addr2  char(30),
					zip  char(10),
					city  char(30),
					state  char(2),
					county  char(20),
					country  char(3),
					mail  char(1),
					con_type  char(2),
					con_lname  char(15),
					con_fname  char(10),
					title  char(25),
					phone1  char(14),
					ext1  char(5),
					phone2  char(14),
					ext2  char(5),
					fax  char(14),
					dls_facility_id  int,
					dls_network_id  int,
					dls_action_code char(2)
               );

            INSERT  INTO @SWV_cursor_var1
                    ( dls_sir_id ,
                      alt_id ,
                      fc_type ,
                      fc_name ,
                      fc_stat_eff_date ,
                      fc_state ,
                      fc_license ,
                      fc_lrenew_dt ,
                      vendor_id ,
                      fc_tax_id ,
                      tin ,
                      fc_area ,
                      fc_rep ,
                      fc_source ,
                      phone_elig ,
                      fax_elig ,
                      print_dir ,
                      fc_mst_con_dt ,
                      emergency_phone ,
                      em_phone_ext ,
                      emg_contact_type ,
                      legal_entity ,
                      fc_tax_name ,
                      pnrx ,
                      no2 ,
                      hndacs ,
                      fc_capacity ,
                      fc_warn ,
                      fc_no_new ,
                      fc_max_enrl ,
                      fc_opr_tory ,
                      parent_id ,
                      barrier_c ,
                      fc_cur_enrl ,
                      next_cap_date ,
                      net_id ,
                      contract_type ,
                      net_fc_eff_date ,
                      ovr_ride ,
                      net_fc_exp_date ,
                      addr_type ,
                      addr1 ,
                      addr2 ,
                      zip ,
                      city ,
                      state ,
                      county ,
                      country ,
                      mail ,
                      con_type ,
                      con_lname ,
                      con_fname ,
                      title ,
                      phone1 ,
                      ext1 ,
                      phone2 ,
                      ext2 ,
                      fax ,
                      dls_facility_id ,
                      dls_network_id ,
                      dls_action_code
                    )
                    SELECT  dls_sir_id ,
                            alt_id ,
                            fc_type ,
                            fc_name ,
                            fc_stat_eff_date ,
                            fc_state ,
                            fc_license ,
                            fc_lrenew_dt ,
                            vendor_id ,
                            fc_tax_id ,
                            tin ,
                            fc_area ,
                            fc_rep ,
                            fc_source ,
                            phone_elig ,
                            fax_elig ,
           print_dir ,
                            fc_mst_con_dt ,
                            emergency_phone ,
                            em_phone_ext ,
                            emg_contact_type ,
                            legal_entity ,
                            fc_tax_name ,
                            pnrx ,
                            no2 ,
                            hndacs ,
                            fc_capacity ,
                            fc_warn ,
                            fc_no_new ,
                            fc_max_enrl ,
    fc_opr_tory ,
                            parent_id ,
                            barrier_c ,
                            fc_cur_enrl ,
                            next_cap_date ,
                            net_id ,
                            contract_type ,
                            net_fc_eff_date ,
                            ovr_ride ,
                            net_fc_exp_date ,
                            addr_type ,
                            addr1 ,
        addr2 ,
                            zip ,
      city ,
                            state ,
                            county ,
                            country ,
                            mail ,
                            con_type ,
                            con_lname ,
                            con_fname ,
                            title ,
                            phone1 ,
                            ext1 ,
                            phone2 ,
                            ext2 ,
                            fax ,
                            dls_facility_id ,
                            dls_network_id ,
                            dls_action_code
                    FROM    dbo.dls_fac_net (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'P';


            DECLARE @cur1_cnt INT ,
                @cur1_i INT;

            SET @cur1_i = 1;

				--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;

            WHILE ( @cur1_i <= @cur1_cnt )
                BEGIN
                    BEGIN
					
                        SELECT  @t_sir_id = dls_sir_id ,
                                @fc_alt_id = alt_id ,
                                @t_fc_type = fc_type ,
                                @t_fc_name = fc_name ,
                                @t_fc_stat_eff_date = CASE WHEN ISNULL(fc_stat_eff_date ,'') <>'' then STUFF(STUFF(fc_stat_eff_date ,3,0,'/'),6,0,'/') ELSE fc_stat_eff_date  END,
                                @t_fc_state = fc_state ,
                                @t_fc_license = fc_license ,
                                @t_fc_lrenew_dt = fc_lrenew_dt ,
                                @fc_vendor_id = vendor_id ,
                                @t_fc_tax_id = fc_tax_id ,
                                @t_tin = tin ,
                                @t_fc_area = fc_area ,
                                @t_fc_rep = fc_rep ,
                                @t_fc_source = fc_source ,
                                @t_phone_elig = phone_elig ,
                                @t_fax_elig = fax_elig ,
                                @t_print_dir = print_dir ,
                                @t_fc_mst_con_dt = fc_mst_con_dt ,
                                @t_emergency_phone = emergency_phone ,
                                @t_em_phone_ext = em_phone_ext ,
                                @t_emg_contact_type = emg_contact_type ,
                                @t_legal_entity = legal_entity ,
                                @t_fc_tax_name = fc_tax_name ,
                                @t_pnrx = pnrx ,
                                @t_no2 = no2 ,
                                @t_hndacs = hndacs ,
                                @t_fc_capacity = fc_capacity ,
                                @t_fc_warn = fc_warn ,
								@t_fc_no_new = fc_no_new ,
                                @t_fc_max_enrl = fc_max_enrl ,
                                @t_fc_opr_tory = fc_opr_tory ,
                                @fc_parent_id = parent_id ,
                                @t_barrier_c = barrier_c ,
								@t_fc_cur_enrl = fc_cur_enrl ,
                                @t_next_cap_date = CASE WHEN ISNULL(next_cap_date,'') <>'' then STUFF(STUFF(next_cap_date,3,0,'/'),6,0,'/') ELSE next_cap_date END  ,
                                @t_net_id = net_id ,
                                @t_contract_type = contract_type ,
                                @t_net_fc_eff_date = CASE WHEN ISNULL(net_fc_eff_date,'') <>'' then STUFF(STUFF(net_fc_eff_date,3,0,'/'),6,0,'/') ELSE net_fc_eff_date END  ,
                                @t_ovr_ride = ovr_ride ,
                                @t_net_fc_exp_date = CASE WHEN ISNULL(net_fc_exp_date,'') <>'' then STUFF(STUFF(net_fc_exp_date,3,0,'/'),6,0,'/') ELSE net_fc_exp_date END ,
              @t_addr_type = addr_type ,
                                @t_addr1 = addr1 ,
                                @t_addr2 = addr2 ,
                                @t_zip = zip ,
                                @t_city = city ,
                                @t_state = state ,
                                @t_county = county ,
								@t_country = country ,
								@t_mail = mail ,
                                @t_con_type = con_type ,
                                @t_con_lname = con_lname ,
                                @t_con_fname = con_fname ,
                                @t_title = title ,
                                @t_phone1 = phone1 ,
                                @t_ext1 = ext1 ,
                                @t_phone2 = phone2 ,
                                @t_ext2 = ext2 ,
                                @t_fax = fax ,
                                @t_dds_fc_id = dls_facility_id ,
                                @t_dds_net_id = dls_network_id ,
                                @t_action_code = dls_action_code
                        FROM    @SWV_cursor_var1
                        WHERE   id = @cur1_i;

                       -- DECLARE @SWV_cursor_var1 CURSOR;
                       -- DECLARE @SWV_cursor_var2 CURSOR;
                        --DECLARE @SWV_cursor_var3 CURSOR;
                       -- DECLARE @SWV_cursor_var4 CURSOR;
                        BEGIN TRY
                            IF @n_in_transaction = 'N'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'Y';
                                END;
		
                            SET @s_error = 'N';
                            SELECT  @curr_datetime = GETDATE()
                            FROM    dbo.sysdatetime;
                            IF ( @t_action_code IS NULL
                                 OR @t_action_code = ''
                               )
                                OR LEN(@t_action_code) = 0
								BEGIN
								SET @a_error_no=400
                                RAISERROR('Action Code is missing',16,1);
								END
                            ELSE
                                IF @t_action_code NOT IN ( 'FA', 'FR', 'NA',
                                                           'NR', 'NT', 'NC' )
														   BEGIN
														   SET @a_error_no=410
                                    RAISERROR('Invalid Action Code found',16,1);
									END
                            SET @a_error_no = 420;
                            SELECT  @t_action_date = action_date
                            FROM    dbo.dl_action (NOLOCK)
                            WHERE   batch_id = @a_batch_id
                                    AND dls_sir_id = @t_sir_id
                                    AND action_code = @t_action_code
                                    AND process_status = 'N';
                           
                            IF @t_action_code = 'FA'
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.facility
                                  WHERE   alt_id = @fc_alt_id )
								  BEGIN
								    SET @a_error_no=500
                                    RAISERROR('Facility record found in DataDental for Action Code FA',16,                     1);
									END
                                ELSE 
			
			-- CREATE NEW FACILITY RECORD
                                    BEGIN
                                        SET @a_error_no = 510;

										IF @t_fc_warn =''
										SET @t_fc_warn=Null

										IF @t_fc_no_new =''
										SET @t_fc_no_new=Null

										IF @t_barrier_c =''
										SET @t_barrier_c=Null


                                        INSERT  INTO dbo.facility
                                                ( alt_id,
												fc_type ,
                                             fc_name ,
                                                  fc_state ,
                                                  fc_license ,
													tin ,
                                                  fc_tax_id ,
                                                  fc_tax_name ,
                                                  fc_warn ,
                                                  fc_no_new ,
                                                  fc_lrenew_dt ,
                                                  fc_source ,
                                                  fc_area ,
                                                  no2 ,
                                                  pnrx ,
												hndacs ,
                                                  fc_rep ,
                                                  fc_mst_con_dt ,
                                                  fc_opr_tory ,
                                                  fc_max_enrl ,
                                                  emergency_phone ,
                                                  emg_phone_ext ,
                                                  emg_contact_type ,
                                                  legal_entity ,
                                                  phone_elig ,
                                                  fax_elig ,
                                                  print_dir ,
                                                  fc_cur_enrl ,
                                                  next_cap_date ,
                                                  fc_capacity ,
                                                  vendor_id ,
                                                  h_user ,
                                                  h_datetime ,
                                                  h_action ,
                                                  barrier_c
                                                )
                                        VALUES  (@fc_alt_id,
												 @t_fc_type ,
                                                  @t_fc_name ,
                                                  @t_fc_state ,
                                                  @t_fc_license ,
                                                  @t_tin ,
                                                  @t_fc_tax_id ,
                                                  @t_fc_tax_name ,
                                                  @t_fc_warn ,
                                                  @t_fc_no_new ,
                                                  @t_fc_lrenew_dt ,
                                                  @t_fc_source ,
                                                  @t_fc_area ,
                                                  @t_no2 ,
                                                  @t_pnrx ,
                                                  @t_hndacs ,
                                                  @t_fc_rep ,
                                                  @t_fc_mst_con_dt ,
                                                  @t_fc_opr_tory ,
                                                  @t_fc_max_enrl ,
                                                  @t_emergency_phone ,
												@t_em_phone_ext ,
                                                  @t_emg_contact_type ,
                                                  @t_legal_entity ,
                                                  @t_phone_elig ,
                                                  @t_fax_elig ,
                                                  @t_print_dir ,
                                                  @t_fc_cur_enrl ,
												 @t_next_cap_date ,
                                                  @t_fc_capacity ,
  NULL ,
  @ls_user ,
    @curr_datetime ,
																		NULL ,
                                                  @t_barrier_c
                                                );
				
                                        SELECT  @curr_fc_id = fc_id
                                        FROM    dbo.facility (NOLOCK)
                                        WHERE   alt_id = @fc_alt_id;
                                      
                       IF @curr_fc_id IS NULL
										BEGIN
										SET @a_error_no=510
                                            RAISERROR('Facility Insertion Error',16,1);
										END
				
                                        SET @a_error_no = 520;
									INSERT  INTO dbo.fcstat
                                                ( facility_id ,
                                                  status ,
                                                  eff_date ,
                                                  exp_date
                                                )
                                        VALUES  ( @curr_fc_id ,
                                                  'AC' ,
                                                  @t_action_date ,
                                                  NULL
                                                );
				
                                        SET @a_error_no = 530; 
/* 
 *	20130804$$ks - vendor should be looked up first by t_vendor_id
 *	if t_vendor_id is null THEN look up by fc.alt_id
 */
                                        IF ( @fc_vendor_id IS NOT NULL
                                             AND @fc_vendor_id <> ''
                                           )
                                            AND @fc_vendor_id > 0
                                            BEGIN
                                                SELECT  @curr_vendor_id = vendor_id
                                                FROM    dbo.vendor (NOLOCK)
                                                WHERE   alt_id = @fc_vendor_id;
                                               
                                            END;
                                        ELSE
                                            BEGIN
                                                SELECT  @curr_vendor_id = vendor_id
                                                FROM    dbo.vendor (NOLOCK)
                                                WHERE   alt_id = @fc_alt_id
                                                        AND v_type = 'FC';
                                              
                                            END;
				
                                        IF ( @curr_vendor_id IS NULL
                                             OR @curr_vendor_id < 1
                                           )
                                            BEGIN
                       INSERT  INTO dbo.vendor
                                                        ( alt_id ,
                                                          fname ,
                                                          lname ,
                                                          name ,
                                                          tin ,
                                                          tax_id ,
                                                          tax_name ,
                                                          aba_no ,
                                                          bnk_name ,
                                                          eft ,
                                                          bank_acct ,
                                                      v_type ,
                                                          sys_rec_id ,
                          acct_type ,
       eft_eff_date ,
     acct_name ,
                                                          pre_note ,
                                                          h_user ,
                                                          h_datetime
                                                        )
                                                VALUES  ( @fc_alt_id ,
                                                          NULL ,
                                                        NULL ,
                                                          @t_fc_name ,
                                                          @t_tin ,
                                                          @t_fc_tax_id ,
                                                          @t_fc_tax_name ,
                                                          NULL ,
                                                          NULL ,
                                                          NULL ,
                                                          NULL ,
                                                          'FC' ,
                                                          @curr_fc_id ,
                                                          NULL ,
                                                          NULL ,
                                                          NULL ,
                                                          NULL ,
                                                          @ls_user ,
                                                          @curr_datetime
                                                        );
					
                                                SELECT  @curr_vendor_id = vendor_id
                                                FROM    dbo.vendor (NOLOCK)
                                                WHERE   alt_id = @fc_alt_id
                                                        AND v_type = 'FC';
                                               
                                                IF @curr_vendor_id IS NULL
												BEGIN
												SET @a_error_no=540
                                                    RAISERROR('Facility Vendor Insertion Error',16,1);
												END
                                            END;
				
                                        UPDATE  dbo.facility
                                        SET     vendor_id = @curr_vendor_id
                                        WHERE   fc_id = @curr_fc_id; 

			-- CREATE NEW FACILITY NETWORK RECORD	
-- use ID found in prev. prog - $$KS01302005		let t_dds_net_id = t_net_id; 
                                        SET @a_error_no = 550;
                                        INSERT  INTO dbo.net_facility
											( net_id ,
                                                  fc_id ,
                                                  con_type ,
                                                  all_plans ,
                                                  ovr_ride ,
                                                  eff_date ,
                                                  exp_date ,
                                                  h_user ,
                                                  h_datetime
                                                )
                                        VALUES  ( @t_dds_net_id ,
                                                  @curr_fc_id ,
                                                  @t_contract_type ,
                                                  NULL ,
                                                  @t_ovr_ride ,
                                                  @t_action_date ,
                                                  NULL ,
                                                  @ls_user ,
                                 @curr_datetime
                                                );

			-- CREATE NEW FACILITY ADDRESS RECORD
				
						SET @a_error_no = 560;
   INSERT  INTO dbo.address
                                                ( subsys_code ,
                                                  sys_rec_id ,
                                                  addr_type ,
                                                  addr1 ,
            addr2 ,
                                                  zip ,
                                                  city ,
                                                  state ,
                                                  county ,
                                                  country ,
												 mail
					                             )
                                        VALUES  ( 'FC' ,
                                                  @curr_fc_id ,
                                                  @t_addr_type ,
                                                  @t_addr1 ,
                                                  @t_addr2 ,
                                                  @t_zip ,
                                                  @t_city ,
                                                  @t_state ,
                                                  @t_county ,
                                                  @t_country ,
                                                  @t_mail
                                                );

			-- CREATE NEW FACILITY CONTACT RECORD
				
                                        SET @a_error_no = 570;
                                        INSERT  INTO dbo.contact
                                                ( subsys_code ,
                                                  sys_rec_id ,
                                                  con_type ,
                                                  fname ,
                                                  lname ,
                                                  title ,
                                                  phone1 ,
                                                  ext1 ,
                                                  phone2 ,
                                                  ext2 ,
                                                  fax ,
                                                  addr_type
                                                )
                                        VALUES  ( 'FC' ,
                                                  @curr_fc_id ,
                                                  @t_con_type ,
												  @t_con_fname ,
                                                  @t_con_lname ,
                                                  @t_title ,
                                                  @t_phone1 ,
                                                  @t_ext1 ,
                                                  @t_phone2 ,
                                                  @t_ext2 ,
                                                  @t_fax ,
                                                  @t_addr_type
                                                );
                                    END;
                            ELSE
                                IF @t_action_code = 'FR'
                                    BEGIN
                                       /*
									    SET @SWV_cursor_var1 = CURSOR  FOR SELECT fc_stat_id, status, eff_date
			
                  FROM dbo.fcstat (NOLOCK)
                  WHERE facility_id = @t_dds_fc_id
                  ORDER BY fc_stat_id DESC;
                                        OPEN @SWV_cursor_var1;
                                        FETCH NEXT FROM @SWV_cursor_var1 INTO @curr_fcstat_id,
                                            @curr_fcstat, @curr_fcstat_eff;
                                        WHILE @@FETCH_STATUS = 0
										*/
                            DECLARE @SWV_cursor_var2 TABLE
                                            (
                              id INT IDENTITY ,
                                              fc_stat_id INT ,
                                              status CHAR(2) ,
                                              eff_date DATE
											  );

                                        INSERT  INTO @SWV_cursor_var2
                                                ( fc_stat_id ,
                                                  status ,
                                                  eff_date
												 )
                                                SELECT  fc_stat_id ,
                                                        status ,
                                                        eff_date
                                                FROM    dbo.fcstat (NOLOCK)
                                                WHERE   facility_id = @t_dds_fc_id
                                                ORDER BY fc_stat_id DESC;


                                        DECLARE @cur2_cnt INT ,
                                            @cur2_i INT;

                                        SET @cur2_i = 1;

					--Get the no. of records for the cursor
                                        SELECT  @cur2_cnt = COUNT(1)
                                        FROM    @SWV_cursor_var2;

                                        WHILE ( @cur2_i <= @cur2_cnt )
                                            BEGIN
                                                SELECT  @curr_fcstat_id = fc_stat_id ,
                                                        @curr_fcstat = status ,
                                                        @curr_fcstat_eff = eff_date
                                                FROM    @SWV_cursor_var2
                                                WHERE   id = @cur2_i;
                                                GOTO SWL_Label5;
                                                /*
												FETCH NEXT FROM @SWV_cursor_var1 INTO @curr_fcstat_id,
                                                    @curr_fcstat,
                                                    @curr_fcstat_eff;
													*/
                                                SET @cur2_i = @cur2_i + 1;
                                            END;
                                        SWL_Label5:
                                        --CLOSE @SWV_cursor_var1;
                 IF @curr_fcstat <> 'AC'
                                            BEGIN
                                                SET @a_error_no = 600;
                                                UPDATE  dbo.fcstat
                                                SET     exp_date = @t_action_date
                                                WHERE   fc_stat_id = @curr_fcstat_id;
                                                INSERT  INTO dbo.fcstat
                                                        ( facility_id ,
                                                          status ,
                                                          eff_date ,
                                                          exp_date
                                                        )
                                                VALUES  ( @t_dds_fc_id ,
                                                          'AC' ,
      @t_action_date ,
                                                          NULL
                                                        );
				
                                               /*
											    SET @SWV_cursor_var2 = CURSOR  FOR SELECT net_fc_id, eff_date, exp_date
				
                     FROM dbo.net_facility (NOLOCK)
WHERE net_id = @t_dds_net_id
                     AND fc_id = @t_dds_fc_id
                     AND con_type = 'PPO'
             AND eff_date <= @t_action_date;
                                                OPEN @SWV_cursor_var2;
                                         FETCH NEXT FROM @SWV_cursor_var2 INTO @curr_fcnet_id,
                                                    @curr_fcnet_eff,
      @curr_fcnet_exp;
                                                WHILE @@FETCH_STATUS = 0
												*/
                                                DECLARE @SWV_cursor_var3 TABLE
                                                    (
                         id INT IDENTITY ,
                                                      net_fc_id INT ,
                                                      eff_date DATE ,
                                                      exp_date DATE
                                                    );

                                                INSERT  INTO @SWV_cursor_var3
                                                        ( net_fc_id ,
                                                          eff_date ,
                                                          exp_date
					                                    )
                                                        SELECT
                                                              net_fc_id ,
                                                              eff_date ,
                                                              exp_date
                                                        FROM  dbo.net_facility (NOLOCK)
                                                        WHERE net_id = @t_dds_net_id
                                                              AND fc_id = @t_dds_fc_id
                                                              AND con_type = 'PPO'
                                                              AND eff_date <= @t_action_date;

                                                DECLARE @cur3_cnt INT ,
                                                    @cur3_i INT;

                                                SET @cur3_i = 1;

					--Get the no. of records for the cursor
                                                SELECT  @cur3_cnt = COUNT(1)
                                                FROM    @SWV_cursor_var3;

                                                WHILE ( @cur3_i <= @cur3_cnt )
                                      BEGIN
                                                        SELECT
                                                              @curr_fcnet_id = net_fc_id ,
                                                              @curr_fcnet_eff = eff_date ,
                                                              @curr_fcnet_exp = exp_date
                                                        FROM  @SWV_cursor_var3
                                                        WHERE id = @cur3_i;
                                                        SET @a_error_no = 610;
                                                        IF @curr_fcnet_id IS NULL
                                                            BEGIN
                                                              INSERT
                                                              INTO dbo.net_facility
                                                              (
                                net_id ,
                                                              fc_id ,
                                                              con_type ,
                                                              all_plans ,
                                                              ovr_ride ,
                                                              eff_date ,
                                                        exp_date ,
                                                              h_user ,
      h_datetime
                                                              )
                                                              VALUES
                                  (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                      @t_ovr_ride ,
                                                              @t_action_date ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );
						
                                                              GOTO SWL_Label6;
                                                            END;
                                                        ELSE
                                                            IF @curr_fcnet_exp IS NOT NULL
                                                              AND @t_action_date < @curr_fcnet_exp
                                                              BEGIN
                                                              INSERT
                                                              INTO dbo.net_facility
                                                              (
                                                              net_id ,
                                                              fc_id ,
                                                              con_type ,
                                                              all_plans ,
                                                              ovr_ride ,
                                                              eff_date ,
                                                              exp_date ,
                                                              h_user ,
                                                              h_datetime
            )
                                                              VALUES
                                                              (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                                              @t_ovr_ride ,
                                                              @curr_fcnet_exp ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );
						
                                                              GOTO SWL_Label6;
                                                              END;
                                        ELSE
                                                              IF @curr_fcnet_exp IS NOT NULL
                                                              AND @curr_fcnet_exp < @t_action_date
                                                              BEGIN
                                                              INSERT
     INTO dbo.net_facility
                                                              (
      net_id ,
                                                              fc_id ,
                                                              con_type ,
                                       all_plans ,
                                                              ovr_ride ,
                                                              eff_date ,
                       exp_date ,
                                                              h_user ,
                                                              h_datetime
                      )
                                                              VALUES
                                                              (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                                              @t_ovr_ride ,
                                                              @t_action_date ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );
						
                                                              GOTO SWL_Label6;
                                                              END;
                                                              ELSE
                                                              IF @curr_fcnet_exp IS NULL
                                                              BEGIN
                                                              UPDATE
                                                              dbo.net_facility
                                                              SET
                                                              exp_date = @t_action_date ,
                                                              h_user = @ls_user
                                    WHERE
                                                              net_fc_id = @curr_fcnet_id;
                                                              INSERT
                                                              INTO dbo.net_facility
                                                              (
                                                              net_id ,
                                                              fc_id ,
                                                              con_type ,
                                                              all_plans ,
                                                              ovr_ride ,
                                                              eff_date ,
                                                              exp_date ,
                                                              h_user ,
                                                              h_datetime
                                                              )
                                             VALUES
                                                              (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                         @t_ovr_ride ,
                                                              @t_action_date ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );
						
                                 GOTO SWL_Label6;
                                                              END;
															  /*
                                                        FETCH NEXT FROM @SWV_cursor_var2 INTO @curr_fcnet_id,
                                                            @curr_fcnet_eff,
    @curr_fcnet_exp;
															*/
                                                        SET @cur3_i = @cur3_i + 1;
                                                         
                                                    END;
                                                SWL_Label6:
                                               -- CLOSE @SWV_cursor_var2;
                                            END;
                                    END;
                                ELSE
                                    IF @t_action_code = 'NA'
                                        BEGIN
                                            SET @a_error_no = 700;
                                            INSERT  INTO dbo.net_facility
                                                    ( net_id ,
                                                      fc_id ,
                                                      con_type ,
                                                      all_plans ,
                                                      ovr_ride ,
                                                      eff_date ,
                                                      exp_date ,
                                                      h_user ,
                                                      h_datetime
                                                    )
                                            VALUES  ( @t_dds_net_id ,
                                                      @t_dds_fc_id ,
                                                      'PPO' ,
                                          NULL ,
                                                      @t_ovr_ride ,
                                                      @t_action_date ,
                                                      NULL ,
                                                      @ls_user ,
                                                      @curr_datetime
                                                    );
                                        END;
                                    ELSE
                                        IF @t_action_code = 'NR'
                                            BEGIN
                                               /*
											    SET @SWV_cursor_var3 = CURSOR  FOR SELECT net_fc_id, eff_date, exp_date
			
                  FROM dbo.net_facility (NOLOCK)
                  WHERE net_id = @t_dds_net_id
                  AND fc_id = @t_dds_fc_id
                  AND con_type = 'PPO'
                  ORDER BY net_fc_id DESC;
                                                OPEN @SWV_cursor_var3;
                                FETCH NEXT FROM @SWV_cursor_var3 INTO @curr_fcnet_id,
                                                    @curr_fcnet_eff,
                                                    @curr_fcnet_exp;
                                                WHILE @@FETCH_STATUS = 0
												*/
                                                DECLARE @SWV_cursor_var4 TABLE
                                                    (
                                   id INT IDENTITY ,
                                                      net_fc_id INT ,
                                                      eff_date DATE ,
                                                      exp_date DATE
                                                    );

                                   INSERT  INTO @SWV_cursor_var4
                                                        ( net_fc_id ,
                                                          eff_date ,
                                                          exp_date
					                                    )
                                                        SELECT
              net_fc_id ,
       eff_date ,
                                                              exp_date
                                                        FROM  dbo.net_facility (NOLOCK)
                                                        WHERE net_id = @t_dds_net_id
                                                              AND fc_id = @t_dds_fc_id
                                                              AND con_type = 'PPO'
                                                        ORDER BY net_fc_id DESC;

                                                DECLARE @cur4_cnt INT ,
                                                    @cur4_i INT;

                                                SET @cur4_i = 1;

					--Get the no. of records for the cursor
                                                SELECT  @cur4_cnt = COUNT(1)
                                                FROM    @SWV_cursor_var4;

                                                WHILE ( @cur4_i <= @cur4_cnt )
                                                    BEGIN
                                                        SELECT
                                                              @curr_fcnet_id = net_fc_id ,
                                                              @curr_fcnet_eff = eff_date ,
                                                              @curr_fcnet_exp = exp_date
                                                        FROM  @SWV_cursor_var4
                                                        WHERE id = @cur4_i;
                                                  GOTO SWL_Label7;
                                                        /*
														FETCH NEXT FROM @SWV_cursor_var3 INTO @curr_fcnet_id,
                                                            @curr_fcnet_eff,
                                                            @curr_fcnet_exp;
															*/
                                                        SET @cur4_i = @cur4_i
                                                            + 1;
                                                    END;
                                                SWL_Label7:
                                                --CLOSE @SWV_cursor_var3;
                                                SET @a_error_no = 800;
                                                SET @tape_fcnet_eff = @t_net_fc_eff_date;
                                                SET @tape_fcnet_exp = @t_net_fc_exp_date;
                                                SET @a_error_no = 810;
                                                IF ( @t_net_fc_exp_date IS NULL
                                                     OR @t_net_fc_exp_date = ''
                                                   )
                                                    IF @curr_fcnet_eff <= @tape_fcnet_eff
                                                        AND @tape_fcnet_eff < @curr_fcnet_exp
                                                        INSERT
                                                              INTO dbo.net_facility
                                                              (
                                                              net_id ,
                                                              fc_id ,
                                                              con_type ,
                                                              all_plans ,
                              ovr_ride ,
                                                              eff_date ,
                                                              exp_date ,
                       h_user ,
                                                              h_datetime
               )
VALUES
                                                              (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                                              @t_ovr_ride ,
                                                              @curr_fcnet_exp ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );

                                                    ELSE
                                                        IF @curr_fcnet_exp <= @tape_fcnet_eff
                                                            BEGIN
                                                              UPDATE
                                                              dbo.net_facility
                                                              SET
                                                              exp_date = @tape_fcnet_eff
                                                              WHERE
                                                              net_fc_id = @curr_fcnet_id;
  INSERT
                                                              INTO dbo.net_facility
                                                              (
                                                              net_id ,
                                                              fc_id ,
                                                              con_type ,
                                                              all_plans ,
                                                              ovr_ride ,
                                                              eff_date ,
                                                              exp_date ,
                                                              h_user ,
                                                              h_datetime
                                                              )
                                                              VALUES
                                                              (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                                              @t_ovr_ride ,
                                                              @tape_fcnet_eff ,
                                                              NULL ,
                                                              @ls_user ,
                                     @curr_datetime
                                                              );
                                                            END;
                                                        ELSE
                                                            IF @curr_fcnet_eff <= @tape_fcnet_eff
                                                              AND @tape_fcnet_eff < @curr_fcnet_exp
                                                              INSERT
                                                           INTO dbo.net_facility
                                                              (
                                                              net_id ,
                                                 fc_id ,
                con_type ,
                                                              all_plans ,
                                                              ovr_ride ,
            eff_date ,
                                                              exp_date ,
                                                              h_user ,
                                                              h_datetime
                                                              )
                                                              VALUES
                                                              (
                                                              @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                                              @t_ovr_ride ,
                                                              @curr_fcnet_exp ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );

                                                            ELSE
                                              IF @curr_fcnet_exp <= @tape_fcnet_eff
                                                              BEGIN
                                                              UPDATE
                                                              dbo.net_facility
                                                              SET
                                                              exp_date = @tape_fcnet_eff
                                                              WHERE
                                                              net_fc_id = @curr_fcnet_id;
                                                              INSERT
                                                              INTO dbo.net_facility
                                                              (
                                                              net_id ,
                                                              fc_id ,
                                                              con_type ,
                                                              all_plans ,
     ovr_ride ,
                                                              eff_date ,
                                                              exp_date ,
                                                              h_user ,
                                                              h_datetime
                                                              )
                                                              VALUES
                                                              (
                                             @t_dds_net_id ,
                                                              @t_dds_fc_id ,
                                                              'PPO' ,
                                                              NULL ,
                                                              @t_ovr_ride ,
                                                              @tape_fcnet_eff ,
                                                              NULL ,
                                                              @ls_user ,
                                                              @curr_datetime
                                                              );
                                                              END;
                        END;
            ELSE
                                            IF @t_action_code = 'NT'
                                                BEGIN
                                                    /*
													SET @SWV_cursor_var4 = CURSOR  FOR SELECT net_fc_id, eff_date, exp_date
			
                  FROM dbo.net_facility (NOLOCK)
                  WHERE net_id = @t_dds_net_id
                  AND fc_id = @t_dds_fc_id
                  AND con_type = 'PPO'
                  ORDER BY net_fc_id DESC;
                                                    OPEN @SWV_cursor_var4;
                                                    FETCH NEXT FROM @SWV_cursor_var4 INTO @curr_fcnet_id,
                                                        @curr_fcnet_eff,
                                                        @curr_fcnet_exp;
                                                    WHILE @@FETCH_STATUS = 0
													*/
                                                    DECLARE @SWV_cursor_var5 TABLE
                                                        (
                                                          id INT IDENTITY ,
                                                          net_fc_id INT ,
                                                          eff_date DATE ,
                                                          exp_date DATE
                                );

                                                    INSERT  INTO @SWV_cursor_var5
                                                            ( net_fc_id ,
                                                              eff_date ,
                                                              exp_date
					                                        )
                                                            SELECT
                                                              net_fc_id ,
                                                              eff_date ,
                                                              exp_date
                                                            FROM
                                                              dbo.net_facility (NOLOCK)
                                                            WHERE
                                                              net_id = @t_dds_net_id
                                                              AND fc_id = @t_dds_fc_id
                                                              AND con_type = 'PPO'
     ORDER BY net_fc_id DESC;

                                                    DECLARE @cur5_cnt INT ,
                                                        @cur5_i INT;

                                                    SET @cur5_i = 1;

					--Get the no. of records for the cursor
                                                    SELECT  @cur5_cnt = COUNT(1)
                                                    FROM    @SWV_cursor_var5;

                                                    WHILE ( @cur5_i <= @cur5_cnt )
                    BEGIN
                                                            SELECT
                                                              @curr_fcnet_id = net_fc_id ,
                                                              @curr_fcnet_eff = eff_date ,
                                                              @curr_fcnet_exp = exp_date
                                                            FROM
                                                              @SWV_cursor_var5
                                                            WHERE
                                                              id = @cur5_i;

                                                            GOTO SWL_Label8;
                                                            /*
															ETCH NEXT FROM @SWV_cursor_var4 INTO @curr_fcnet_id,
@curr_fcnet_eff,
                                                  @curr_fcnet_exp;
															  */
                                                            SET @cur5_i = @cur5_i
                                                              + 1;
  END;
                                                    SWL_Label8:
                                                   -- CLOSE @SWV_cursor_var4;
                                                    SET @a_error_no = 900;
                                                    SET @tape_fcnet_eff = @t_net_fc_eff_date;
                                                    SET @tape_fcnet_exp = @t_net_fc_exp_date;
                                                    SET @a_error_no = 910;
                                                    IF @curr_fcnet_eff <= @tape_fcnet_eff
                                                        AND @tape_fcnet_exp IS NOT NULL
                                                        UPDATE
                                                              dbo.net_facility
                                                        SET   exp_date = @tape_fcnet_exp ,
                           h_user = @ls_user
                                                        WHERE net_fc_id = @curr_fcnet_id;
                                                END;
                                            ELSE
                                                BEGIN
                                                    SET @v_Null = 0;
                                                END;  
			-- t_action_code = "NC"
			-- No Action
		
                            IF @s_error = 'Y'
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    UPDATE  dbo.dls_fac_net
                                    SET     dls_status = 'E'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    SET @n_succ_count = @n_succ_count + 1;
                                    UPDATE  dbo.dls_fac_net
                                    SET     dls_status = 'U'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
		
                            IF @n_process_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = @n_process_count
                                        - @n_succ_count
                                WHERE   bat_statistics_id = @i_statistics_id;
		
                            IF @n_in_transaction = 'Y'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'N';
                                END;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
            
                                           SET @n_in_transaction = 'N';
                                        END;
				
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
        + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
			
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @a_error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';
                        END CATCH;
                    END;
                    /*
					FETCH NEXT FROM @cSIR INTO @t_sir_id, @fc_alt_id,
                        @t_fc_type, @t_fc_name, @t_fc_stat_eff_date,
                        @t_fc_state, @t_fc_license, @t_fc_lrenew_dt,
                        @fc_vendor_id, @t_fc_tax_id, @t_tin, @t_fc_area,
                        @t_fc_rep, @t_fc_source, @t_phone_elig, @t_fax_elig,
                        @t_print_dir, @t_fc_mst_con_dt, @t_emergency_phone,
                        @t_em_phone_ext, @t_emg_contact_type, @t_legal_entity,
                        @t_fc_tax_name, @t_pnrx, @t_no2, @t_hndacs,
                        @t_fc_capacity, @t_fc_warn, @t_fc_no_new,
                        @t_fc_max_enrl, @t_fc_opr_tory, @fc_parent_id,
                        @t_barrier_c, @t_fc_cur_enrl, @t_next_cap_date,
                        @t_net_id, @t_contract_type, @t_net_fc_eff_date,
                        @t_ovr_ride, @t_net_fc_exp_date, @t_addr_type,
                        @t_addr1, @t_addr2, @t_zip, @t_city, @t_state,
                        @t_county, @t_country, @t_mail, @t_con_type,
                        @t_con_lname, @t_con_fname, @t_title, @t_phone1,
                        @t_ext1, @t_phone2, @t_ext2, @t_fax, @t_dds_fc_id,
                        @t_dds_net_id, @t_action_code;
						*/
                    SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @cSIR;
            SET @n_error_count = @n_process_count - @n_succ_count;
            EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @n_error_count
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                                   + @n_error_count ),
                                                 ' Failed to update statistics');
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

			UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @a_batch_id;

            SET @SWP_Ret_Value = 1;
           SET @SWP_Ret_Value1 = CONCAT('Finish Updating for Batch ',
                                         @a_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            IF @n_in_transaction = 'Y'
                BEGIN
                    
                    SET @n_in_transaction = 'N';
                END;
		
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



	--set debug file to "/tmp/dlp_up_fac_net.trc";
	--trace on;

    END;