﻿CREATE PROC [dbo].[usp_dl_GetBatchDetail]
@BatchId INT
AS
BEGIN
	DECLARE @BatchDetailId INT
--general
SELECT  bt.config_bat_id AS BatchId,
		bt.config_id	 AS ConfigurationId,
		cg.config_name	 AS ConfigurationName,
		cd.descr	     AS StatusDescription,
		bt.created_by    AS CreatedBy,
		bt.created_time AS CreatedTime FROM dl_config_bat bt
	INNER JOIN dl_config cg ON bt.config_id=cg.config_id
	INNER JOIN stc_common_detail cd ON bt.config_bat_status=cd.code and cd.common_header_id=2
	WHERE bt.config_bat_id=@BatchId

--detail
SELECT  bd.cfg_bat_det_id	AS BatchDetailId,
		bd.config_bat_id	AS BatchId,
		bd.cfg_bat_det_toler AS Tolerance,
		cd.descr	AS StatusDescription,
		bd.sp_id AS SpId,
		sp.sp_display AS Process,
		sir.display_name AS SirDefinitionName,
		bd.sir_def	AS SirDefinitionId, 
		bd.created_by AS CreatedBy,
		bd.created_time AS CreatedTime
		FROM dl_cfg_bat_det bd
INNER JOIN dl_sp sp ON bd.sp_id=sp.sp_id
INNER JOIN dl_sir_def sir ON bd.sir_def=sir.sir_def_id
INNER JOIN stc_common_detail cd ON bd.cfg_bat_det_stat=cd.code AND cd.common_header_id=2
WHERE bd.config_bat_id=@BatchId

--params
SELECT 
	bp.cfg_bat_param_id AS BatchParameterId,
	bp.config_bat_id AS BatchId,
	bp.sp_param_id AS SpParameterId,
	sp.param_name AS ParameterName,
	bp.param_value AS BatchParameterValue,
	bp.created_by AS CreatedBy,
	bp.created_time AS CreatedTime,
	s.sp_display AS SpName
FROM dl_cfg_bat_param bp
INNER JOIN dl_sp_param sp ON bp.sp_param_id=sp.sp_param_id
INNER JOIN dl_sp s ON sp.sp_id=s.sp_id
WHERE bp.config_bat_id=@BatchId

---statistics
SET @BatchDetailId=(SELECT top 1 cfg_bat_det_id FROM dl_cfg_bat_det WHERE config_bat_id=@BatchId order by sp_id asc)
EXEC usp_dl_GetBatchStatistics @BatchDetailId


--users
SELECT stc_user.usersl_id as UsersListId,   
            stc_user.user_id as  UserId,   
            stc_user.userfname as FirstName,   
            stc_user.userlname as LastName,   
            stc_user.user_type as  UserType,   
            stc_user.user_descr as Description,   
            stc_user.eff_date as EffectiveDate,   
            stc_user.exp_date as ExpiryDate,   
            stc_user.created_by as CreatedBy,   
            stc_user.created_time as CreatedTime  
    FROM stc_user  
    WHERE (stc_user.usersl_id not in (2,4) ) 

--select user_tbl.usersl_id as UsersListId,
--		                                                    user_tbl.user_id as UserId,
--		                                                    user_tbl.first_name as FirstName,
--		                                                    user_tbl.last_name as LastName,
--		                                                    'U' as UserType,
--		                                                    '' as Description,
--		                                                    user_tbl.eff_date as EffectiveDate,
--		                                                    user_tbl.exp_date as ExpiryDate,
--		                                                    user_tbl.h_user as CreatedBy,
--		                                                    user_tbl.h_datetime as CreatedTime
--                                                    from user_tbl
--													union 

--select group_tbl.groupsl_id as UsersListId,
--		                                                        group_tbl.group_id as UserId,
--		                                                        group_tbl.fname as FirstName,
--		                                                        group_tbl.lname as LastName,
--		                                                        'G' as UserType,
--		                                                        group_tbl.descr as Description,
--		                                                        group_tbl.eff_date as EffectiveDate,
--		                                                        group_tbl.exp_date as ExpiryDate,
--		                                                        group_tbl.h_user as CreatedBy,
--		                                                        group_tbl.h_datetime as CreatedTime
--                                                        from group_tbl where group_tbl.type='DL'

END