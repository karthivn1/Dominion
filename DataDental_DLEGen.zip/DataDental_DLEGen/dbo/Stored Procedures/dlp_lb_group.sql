﻿CREATE PROCEDURE [dbo].[dlp_lb_group]
    @p_dls_group_id INT ,
    @p_batch_id INT ,
    @p_invoice_no INT ,
    @p_ck_tol CHAR(1) ,
    @p_paid_amt MONEY ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(1) = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(30) = NULL OUTPUT ,
    @SWP_Ret_Value3 VARCHAR(64) = NULL OUTPUT
    
          -- s_error_descr
------------------------------------------------------------------------------
--
--            Procedure:   dlp_lb_group
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This procedure supports the lockbox pre-processing, 
--           dlp_bu_lockbox(), of DataLoad for the DataDental Alloation module,
-- a product of STC.  This SP performs employer group specific rules
--           checking on the lockbox data.
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--

--Used for DataLoad EG (Employer Group).  Called by dlp_bu_lockbox().
-------------------------------------------------------------------------------

                 -- err_no
          --integer,              -- group_id
                        -- s_alloc_flag
                       -- s_acct_num
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/

   
   
   
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @i_fatal INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @s_err_rtn_text VARCHAR(64);
   
        DECLARE @s_alloc_type CHAR(2);
        DECLARE @s_group_type CHAR(2);
   
        DECLARE @i_oc_id INT;
        DECLARE @i_group_id INT;

        DECLARE @s_alloc_flag CHAR(1);
        DECLARE @s_acct_num CHAR(20);
        DECLARE @t_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;

   ---------------------perform exception handling------------------------------
        SET NOCOUNT ON;
        SET @t_sir_id = 0;
       
        SET @i_sp_id = 0;
        
        SET @i_sir_def_id = 0 ;

		select @t_sir_id=VarValue from GlobalVar where BatchId=@p_batch_id AND  Module_Id = 5 and VarName='t_sir_id'
		select @i_sp_id=VarValue from GlobalVar where BatchId=@p_batch_id AND  Module_Id = 5 and VarName='i_sp_id'
		select @i_sir_def_id=VarValue from GlobalVar where BatchId=@p_batch_id AND  Module_Id = 5 and VarName='i_sir_def_id'
       
		/* NULL,* / 

      / * sets status to Error if condition deemed fatal * /
       / * NULL,*/ 
        BEGIN TRY
            SET @s_alloc_flag = 'A';
   
   /* Out 20131206.
   SELECT group_id
   INTO i_group_id
   FROM group
   WHERE group_id = group_payee
   AND group_id IN (SELECT group_id 
                    FROM bill_sum
                    WHERE invoice_num = p_invoice_no);
   */
            SET @i_group_id = @p_dls_group_id;
            IF @i_group_id IS NULL
			BEGIN
			SET @i_error_no=80
                RAISERROR('Cannot retrieve Group ID using Invoice No.',16,1);
			END
   

   --- get group type and operating co. id -----
            SELECT  @s_group_type = group_type ,
                    @i_oc_id = oc_id ,
                    @s_alloc_type = alloc_type
            FROM    dbo.[group] (NOLOCK)
            WHERE   group_id = @i_group_id;
            
            IF @i_oc_id IS NULL
			BEGIN
			SET @i_error_no=90
                RAISERROR('Cannot find the Oper Co for the Group',16,1);
			END
   
            IF NOT @s_group_type LIKE 'EG'
			BEGIN
			SET @i_error_no=100
                RAISERROR('Invalid Group Type for Group',16,1);
			END
   
   
   -----get bank acct # ---
            SELECT  @s_acct_num = acct_num
            FROM    dbo.bank_info (NOLOCK)
            WHERE   bank_info_id = ( SELECT deposit_acct
                                     FROM   dbo.oper_company (NOLOCK)
                                     WHERE  oc_id = @i_oc_id
                                   );
            
            IF ( @s_acct_num IS NULL
     OR @s_acct_num = ''
               )
			   BEGIN
			   SET @i_error_no=140
                RAISERROR('Cannot locate Bank Account for Group',16,1);
			END
   
   
   ---------- perform check if specfied by user ----------------
   
   
-- insert amount paid and group into temp table for later use
       /* i_group_id,*/ 
            IF @p_ck_tol = 'Y'
                BEGIN
                    INSERT  INTO #dls_lb_money_paid
                            ( group_id, paid_amt )
                    VALUES  ( @i_group_id, @p_paid_amt );
      
                    EXECUTE dbo.dlp_lb_ck_tol @p_batch_id, @i_group_id,
                        @i_error_no OUTPUT, @s_alloc_flag OUTPUT,
                        @s_error_descr OUTPUT;
       /* NULL,*/ 
                    IF @i_error_no <> 1
                        BEGIN
                            SET @SWP_Ret_Value = @i_error_no;
                            SET @SWP_Ret_Value1 = NULL;
                            SET @SWP_Ret_Value2 = NULL;
                            SET @SWP_Ret_Value3 = @s_error_descr;
                            RETURN;
                        END;
                END;
            ELSE
                IF ( @s_alloc_type = 'MA' )
                    SET @s_alloc_flag = 'M';
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @s_alloc_flag;
            SET @SWP_Ret_Value2 = @s_acct_num;
            SET @SWP_Ret_Value3 = NULL;
            RETURN;
        END TRY
        BEGIN CATCH
            --SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE(); /* NULL,*/ 
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
			IF ERROR_NUMBER()=50000
			BEGIN
				EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sir_id,
                                        @i_error_no;
			END
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


      
   -------------------------begin body of code----------------------------------
    END;