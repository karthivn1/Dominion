﻿---EXEC sgupdate_api 'UP',204853,'01/01/2017'
CREATE PROCEDURE [dbo].[sgupdate_api]
    @proc CHAR(2) ,
    @a INT ,
    @b CHAR(10)
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:28:28 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @returnvalue INT;
        DECLARE @returnmsg VARCHAR(64)='Invalid Stage Cd:';

        SET NOCOUNT ON;
        
        IF ( @proc = 'AL' )
            BEGIN
                EXECUTE dbo.dlp_al_sg_member @a, @b, @returnvalue OUTPUT,
                    @returnmsg OUTPUT;

					SELECT @returnvalue 'returnvalue',@returnmsg 'returnmsg'
					RETURN
              END;
        ELSE
            IF @proc = 'BU'
                BEGIN
			
                    EXECUTE dbo.dlp_bu_sg_member @a, 0, @b,
                        @returnvalue OUTPUT, @returnmsg OUTPUT;
						
						SELECT @returnvalue 'returnvalue',@returnmsg 'returnmsg'
						RETURN
                    
                END;
            ELSE
                IF @proc = 'UP'
                    BEGIN
                        EXECUTE dbo.dlp_up_sg_member @a, @b,
                            @returnvalue OUTPUT, @returnmsg OUTPUT;

                        SELECT @returnvalue 'returnvalue',@returnmsg 'returnmsg'

						RETURN
                    END;
                ELSE
                    BEGIN
                        RAISERROR(@returnmsg,16,1)
						RETURN
					END;
       SET NOCOUNT OFF;
 END;