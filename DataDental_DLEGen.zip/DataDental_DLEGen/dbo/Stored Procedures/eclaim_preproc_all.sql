﻿CREATE PROCEDURE [dbo].[eclaim_preproc_all]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:31:31 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;
        DECLARE @HCnt INT;
        DECLARE @DCnt INT;
        DECLARE @DT DATETIME2(0);
        DECLARE @eClaimID INT;
        DECLARE @RetVal INT;
        DECLARE @Msg CHAR(64); -- This may change when updates are allowed
        -- DECLARE @SWV_cursor_var1 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  eclaim_id INT
                );	

            
            INSERT  INTO @SWV_cursor_var1
                    ( eclaim_id
                    )
                    SELECT  eclaim_id
                    FROM    dbo.eclaim_h (NOLOCK)
                    WHERE   status = 12  -- Needs Preprocessing
                            AND dds_claim_id = 0;

           /* SET @SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_id 
      FROM dbo.eclaim_h (NOLOCK) WHERE status = 12  -- Needs Preprocessing
      AND dds_claim_id = 0;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
                    SELECT  @eClaimID = eclaim_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur_i;
                    EXECUTE dbo.eclaim_preprocess @eClaimID, @RetVal OUTPUT,
                        @Msg OUTPUT;
                   
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID;
                    SET @cur_i = @cur_i + 1;
                END;
            -- CLOSE @SWV_cursor_var1;
            
            EXECUTE dbo.eclaim_upd_status @RetVal OUTPUT, @Msg OUTPUT;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = 'Preprocess for all eclaims completed';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

----------------------------------------------------------------------

--set debug file to '/tmp/eclaim_preproc_all.trc';
--trace on;
    END;