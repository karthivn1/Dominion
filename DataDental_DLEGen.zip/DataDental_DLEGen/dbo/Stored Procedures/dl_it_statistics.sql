﻿CREATE PROCEDURE [dbo].[dl_it_statistics]
    @a_batch_id INT ,
    @a_sp_id CHAR(14) ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/

        DECLARE @i_sp_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @i_cfg_bat_det_id INT;

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_descr VARCHAR(64);
		DECLARE @created_by CHAR(15)

        SET NOCOUNT ON;
        BEGIN TRY
            IF ( @a_sp_id IS NULL
                 OR @a_sp_id = ''
               )
                OR @a_sp_id <= 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = NULL;
                    SET @SWP_Ret_Value3 = '(Internal) can''t retrieve sp_id';
                    RETURN;
                END;
	
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @a_sp_id;
            
            IF @i_cfg_bat_det_id IS NULL
                OR @i_cfg_bat_det_id <= 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = NULL;
                    SET @SWP_Ret_Value3 = '(Internal) Missing SP in batch';
                    RETURN;
                END;
	
		SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
		SET @a_start_time=FORMAT(GETDATE() , 'yyyy-MM-dd HH:mm:ss:ff');

            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      --ORIGINAL_LOGIN() ,
					  @created_by,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            
            IF @i_statistics_id IS NULL
                OR @i_statistics_id <= 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = NULL;
                    SET @SWP_Ret_Value3 = '(Internal) can''t retrieve statistics record';
                    RETURN;
                END;
	
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value2 = @i_statistics_id;
            SET @SWP_Ret_Value3 = 'Success when retrieve statistics';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = '(Internal) Error when creating statistics';
            RETURN;
     END CATCH;
        SET NOCOUNT OFF;


    END;