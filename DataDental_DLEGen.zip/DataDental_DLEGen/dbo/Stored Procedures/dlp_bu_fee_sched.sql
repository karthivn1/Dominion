﻿CREATE PROCEDURE [dbo].[dlp_bu_fee_sched]
@a_batch_id INT ,
@a_sir_id INT ,
@a_start_time VARCHAR(22) ,
@SWP_Ret_Value INT = NULL OUTPUT ,
@SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT

------------------------------------------------------------------------------
--
-- Procedure: dlp_bu_fee_sched
--
-- Created: 06/04/1999 
-- Author: Ameeta Mahendra
--
-- Purpose: This SP performs before update pre-processing on DataDental
-- fee schedule for the DataLoad Product of STC
--
--
-- Modification History:
--
-- DATE AUTHOR DETAILS
--
-------------------------------------------------------------------------------
AS
BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
　
DECLARE @i_statistics_id INT;
DECLARE @i_cfg_bat_det_id INT;
DECLARE @c_prev_err CHAR(1);
DECLARE @c_found_err CHAR(1);
DECLARE @n_error_no INT;
DECLARE @s_error_descr VARCHAR(64);
DECLARE @s_proc_name CHAR(14);
DECLARE @s_sir_def_name CHAR(14);
DECLARE @i_process_count INT;
DECLARE @i_succ_count INT;
DECLARE @i_init_count INT;
DECLARE @i_error_count INT;
DECLARE @i_error_no INT;
DECLARE @i_error INT;
DECLARE @i_fatal INT;
DECLARE @s_error_text VARCHAR(64);
DECLARE @s_err_rtn_text VARCHAR(64);
DECLARE @i_isam_error INT;
DECLARE @s_zip_code_3 CHAR(3);
DECLARE @s_d_proc_code CHAR(5);
DECLARE @s_percentile1 CHAR(6);
DECLARE @s_percentile2 CHAR(6);
DECLARE @s_percentile3 CHAR(6);
DECLARE @s_percentile4 CHAR(6);
DECLARE @s_percentile5 CHAR(6);
DECLARE @s_percentile6 CHAR(6);
DECLARE @s_percentile7 CHAR(6);
DECLARE @s_percentile8 CHAR(6);
　
-- Previously it is Int now chaging to CHAR(6)
DECLARE @i_zip_code_3 CHAR(6);
DECLARE @i_proc_code CHAR(5);
DECLARE @i_percentile1 CHAR(6);
DECLARE @i_percentile2 CHAR(6);
DECLARE @i_percentile3 CHAR(6);
DECLARE @i_percentile4 CHAR(6);
DECLARE @i_percentile5 CHAR(6);
DECLARE @i_percentile6 CHAR(6);
DECLARE @i_percentile7 CHAR(6);
DECLARE @i_percentile8 CHAR(6);
DECLARE @s_p_version CHAR(6);
DECLARE @s_p_source CHAR(6);
DECLARE @i_sir_id INT;
DECLARE @i_sp_id INT;
DECLARE @i_sp_id2 INT;
DECLARE @i_sir_def_id INT;
DECLARE @SWV_dl_get_sp_id INT;
DECLARE @SWV_dl_get_sir_def_id INT;
-- DECLARE @cFeeSIR CURSOR;
DECLARE @cFeeSIR TABLE
(
id INT IDENTITY ,
dls_sir_id INT, 
zip_code_3 VARCHAR(3), 
d_proc_code VARCHAR(5), 
percentile1 VARCHAR(6),
percentile2 VARCHAR(6), 
percentile3 VARCHAR(6), 
percentile4 VARCHAR(6), 
percentile5 VARCHAR(6),
percentile6 VARCHAR(6), 
percentile7 VARCHAR(6), 
percentile8 VARCHAR(6)
);
DECLARE @SWV_dl_upd_statistics INT;
DECLARE @SWV_dl_log_error INT;
-----exception handling------------------------------------------
SET NOCOUNT ON;
SET @i_sir_id = 0;
SET @i_sp_id = 0;
SET @i_sp_id2 = 0;
SET @i_sir_def_id = 0;
BEGIN TRY
--SET DEBUG FILE TO '/tmp/dlp_bu_fee_sched.trc';
--TRACE ON;
-----Initialize stored procedure variables-----------------------------------
SET @s_proc_name = 'bu_fee_sched';
SET @s_sir_def_name = 'fee_sched';
EXECUTE @SWV_dl_get_sp_id =dbo.dl_get_sp_id @a_batch_id, @s_proc_name;
SET @i_sp_id = @SWV_dl_get_sp_id
IF @i_sp_id = -1
BEGIN
SET @i_isam_error =0
RAISERROR('Can not retrieve valid Store Procedure ID',16,1);
RETURN
END
EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @a_batch_id, 'up_fee_sched';
SET @i_sp_id2 = @SWV_dl_get_sp_id
IF @i_sp_id2 = -1
BEGIN
SET @i_isam_error =0
RAISERROR('Can not retrieve valid Store Procedure ID',16,1);
RETURN
END
EXECUTE @SWV_dl_get_sir_def_id=dbo.dl_get_sir_def_id @s_sir_def_name;
SET @i_sir_def_id = @SWV_dl_get_sir_def_id
IF @i_sir_def_id = -1
BEGIN
SET @i_isam_error =5
RAISERROR('Can not retrieve valid SIR TABLE Definition ID',16,1);
RETURN
END
　
　
-- check if there were errors logged for prev runs
IF EXISTS ( SELECT *
FROM dbo.dl_log_error (NOLOCK)
WHERE config_bat_id = @a_batch_id
AND sp_id = @i_sp_id )
SET @c_prev_err = 'T';
ELSE
SET @c_prev_err = 'F';
　
　
-- get initial count of rows that have passed pre-processing --
SELECT @i_init_count = COUNT(*)
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_status = 'P';
/*
SELECT cfg_bat_det_id INTO i_cfg_bat_det_id
FROM dl_cfg_bat_det
WHERE config_bat_id = a_batch_id and sp_id = i_sp_id;
*/
EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
@n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
@i_statistics_id OUTPUT, @s_error_descr OUTPUT;
IF @n_error_no <= 0
BEGIN
SET @i_isam_error =0
RAISERROR('(Internal) error when creating statistics',16,1);
RETURN
END
SET @i_process_count = 0;
SET @i_succ_count = 0;
　
----------get params from user--------------------
SELECT @s_p_version=dbo.dl_get_param_value (@a_batch_id, @i_sp_id2, 'Version');
IF ( @s_p_version IS NULL
OR @s_p_version = ''
)
OR LEN(@s_p_version) < 6
BEGIN
SET @i_isam_error =0
RAISERROR('Missing Version parameter value',16,1);
RETURN
END
SELECT @s_p_source=dbo.dl_get_param_value( @a_batch_id, @i_sp_id2, 'Source');
-- single row passed in
-----exception handling w/in FOREACH---------------------------------
/*------- catch all other errors -------*/
IF ( @s_p_source IS NULL
OR @s_p_source = ''
)
OR LEN(@s_p_source) < 1
BEGIN
SET @i_isam_error =0
RAISERROR('Missing Source parameter value',16,1);
RETURN
END
　
　
　
-----Begin processing, one row at a time-------------------------------------
--- problems retrieving data from dB----
--business rules handling
------------------------------------------------------------------------
---------perform initial checks---------------------------------------
INSERT INTO @cFeeSIR (dls_sir_id, zip_code_3, d_proc_code, percentile1,
percentile2, percentile3, percentile4, percentile5,
percentile6, percentile7, percentile8)
SELECT dls_sir_id, zip_code_3, d_proc_code, percentile1,
percentile2, percentile3, percentile4, percentile5,
percentile6, percentile7, percentile8
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND (dls_status = 'L' OR dls_status = 'V')
AND ((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) -- allows process for
OR (@a_sir_id = 0 AND dls_sir_id > 0)) 
/* SET @cFeeSIR = CURSOR FOR SELECT dls_sir_id, zip_code_3, d_proc_code, percentile1,
percentile2, percentile3, percentile4, percentile5,
percentile6, percentile7, percentile8
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND (dls_status = 'L' OR dls_status = 'V')
AND ((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) -- allows process for
OR (@a_sir_id = 0 AND dls_sir_id > 0));
OPEN @cFeeSIR;
FETCH NEXT FROM @cFeeSIR INTO @i_sir_id, @s_zip_code_3,
@s_d_proc_code, @s_percentile1, @s_percentile2, @s_percentile3,
@s_percentile4, @s_percentile5, @s_percentile6, @s_percentile7,
@s_percentile8;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur_cnt = COUNT(1)
FROM @cFeeSIR;
WHILE ( @cur_i <= @cur_cnt )
BEGIN
select @i_sir_id = dls_sir_id, @s_zip_code_3 = zip_code_3,
@s_d_proc_code = d_proc_code, @s_percentile1 = percentile1, @s_percentile2 = percentile2, @s_percentile3 = percentile3,
@s_percentile4 = percentile4, @s_percentile5 = percentile5, @s_percentile6 = percentile6, @s_percentile7 = percentile7,
@s_percentile8 = percentile8 from @cFeeSIR where id = @cur_i
BEGIN
BEGIN TRY
-- if this proc and batch had prev stored errors, then
-- call sub-proc to see if it was this row, and if so, 
-- move to err history table
IF @c_prev_err = 'T'
BEGIN
EXECUTE dbo.dl_clean_curr_err @a_batch_id,
@i_sir_id, @i_sp_id,
@i_error_no OUTPUT,
@s_err_rtn_text OUTPUT;
END;
-- initialize variables for each record check----------------
SET @i_error = 0;
SET @c_found_err = 'N';
SET @i_process_count = @i_process_count + 1;
----zip_code
SET @i_error = 10; ---non numeric zip code
SET @i_zip_code_3 = @s_zip_code_3;
IF ( @s_zip_code_3 IS NULL
OR @s_zip_code_3 = ''
)
OR LEN(@s_zip_code_3) = 0
BEGIN
SET @i_isam_error =15
RAISERROR('ZIP code is required',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.fee_source (NOLOCK)
WHERE source = @s_p_source
AND version = @s_p_version
AND zip_code_3 = @s_zip_code_3 )
BEGIN
SET @i_isam_error =18
RAISERROR('Zip Code already exist',16,1);
RETURN
END
　
--d_proc_code
IF ( @s_d_proc_code IS NULL
OR @s_d_proc_code = ''
)
OR LEN(@s_d_proc_code) = 0
BEGIN
SET @i_isam_error =20
RAISERROR('Dental Procedure Code is required',16,1);
RETURN
END
ELSE
IF NOT EXISTS ( SELECT *
FROM dbo.plx_dent_proc (NOLOCK)
WHERE d_proc_code = @s_d_proc_code )
BEGIN
SET @i_isam_error =30
RAISERROR('Invalid Dental Procedure Code',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code_3 = @s_zip_code_3
AND d_proc_code = @s_d_proc_code
AND dls_sir_id != @i_sir_id )
BEGIN
SET @i_isam_error =35
RAISERROR('Duplicate ZIP & Procedure code',16,1);
RETURN
END
--percentile
SET @i_error = 40; -- Non Numeric percentile 1
SET @i_percentile1 = @s_percentile1;

IF ( @s_percentile1 IS NULL
OR @s_percentile1 = ''
)
OR LEN(@s_percentile1) = 0
BEGIN
SET @i_isam_error =40
RAISERROR('Non numeric percentile 1 ',16,1);
RETURN
END
SET @i_error = 50; -- Non Numeric percentile 2
SET @i_percentile2 = @s_percentile2;
IF ( @s_percentile2 IS NULL
OR @s_percentile2 = ''
)
OR LEN(@s_percentile2) = 0
BEGIN
SET @i_isam_error =50
RAISERROR('Non numeric percentile 2 ',16,1);
RETURN
END
SET @i_error = 60; -- Non Numeric percentile 3
SET @i_percentile3 = @s_percentile3;
IF ( @s_percentile3 IS NULL
OR @s_percentile3 = ''
)
OR LEN(@s_percentile3) = 0
BEGIN
SET @i_isam_error =60
RAISERROR('Non numeric percentile 3 ',16,1);
RETURN
END
SET @i_error = 70; -- Non Numeric percentile 4
SET @i_percentile4 = @s_percentile4;
IF ( @s_percentile4 IS NULL
OR @s_percentile4 = ''
)
OR LEN(@s_percentile4) = 0
BEGIN
SET @i_isam_error =70
RAISERROR('Non numeric percentile 1 ',16,1);
RETURN
END
SET @i_error = 80; -- Non Numeric percentile 5
SET @i_percentile5 = @s_percentile5;
IF ( @s_percentile5 IS NULL
OR @s_percentile5 = ''
)
OR LEN(@s_percentile5) = 0
BEGIN
SET @i_isam_error =80
RAISERROR('Non numeric percentile 5 ',16,1);
RETURN
END
SET @i_error = 90; -- Non Numeric percentile 6
SET @i_percentile6 = @s_percentile6;
IF ( @s_percentile6 IS NULL
OR @s_percentile6 = ''
)
OR LEN(@s_percentile6) = 0
BEGIN
SET @i_isam_error =90
RAISERROR('Non numeric percentile 6 ',16,1);
RETURN
END
SET @i_error = 100; -- Non Numeric percentile 7
SET @i_percentile7 = @s_percentile7;
IF ( @s_percentile7 IS NULL
OR @s_percentile7 = ''
)
OR LEN(@s_percentile7) = 0
BEGIN
SET @i_isam_error =100
RAISERROR('Non numeric percentile 7 ',16,1);
RETURN
END
SET @i_error = 110; -- Non Numeric percentile 8
SET @i_percentile8 = @s_percentile8;
IF ( @s_percentile8 IS NULL
OR @s_percentile8 = ''
)
OR LEN(@s_percentile8) = 0
BEGIN
SET @i_isam_error =110
RAISERROR('Non numeric percentile 8 ',16,1);
RETURN
END
IF NOT EXISTS ( SELECT *
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code_3 = zip_code
AND zip_code_3 = @s_zip_code_3 )
BEGIN
SET @i_isam_error =120
RAISERROR('ZIP code does not exist Fee ZIP SIR',16,1);
RETURN
END
IF @c_found_err = 'Y'
UPDATE dbo.dls_fee_sched
SET dls_status = 'E'
WHERE dls_batch_id = @a_batch_id
AND dls_sir_id = @i_sir_id 
-- WHERE CURRENT OF @cFeeSIR;
ELSE
/* update dls_status */
BEGIN
UPDATE dbo.dls_fee_sched
SET dls_status = 'P' WHERE dls_batch_id = @a_batch_id
AND dls_sir_id = @i_sir_id 
--WHERE CURRENT OF @cFeeSIR;
SET @i_succ_count = @i_succ_count + 1;
END;
/* update stats every 100 rows evaluated */
IF @i_process_count % 100 = 0
-----update the stats----------
UPDATE dbo.dl_bat_statistics
SET tot_record = @i_process_count ,
tot_success_rec = @i_succ_count ,
tot_fail_rec = ( @i_process_count
- @i_succ_count )
WHERE bat_statistics_id = @i_statistics_id;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
--SET @i_isam_error = ERROR_LINE();
SET @s_error_text = ERROR_MESSAGE();
-- known error conditions, including any conversion errors
-- fatal error
IF @i_error_no IN ( 244, 245, 246 )
BEGIN
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
@i_sp_id, @i_sir_def_id, @i_sir_id,
1000;
GOTO SWL_Label2;
END;
ELSE
IF (@i_error != 0 OR ERROR_NUMBER() =50000)
BEGIN
--------Modified for conversion issue against CH001
EXECUTE @SWV_dl_log_error=dbo.usp_dl_log_error @a_batch_id,
@i_sp_id, @i_sir_def_id, @i_sir_id,
@i_isam_error;
IF @SWV_dl_log_error != 1
BEGIN
SET @c_found_err = 'Y';
SET @i_error = 0;
END; -- reset error no
END;
ELSE
BEGIN
SET @s_err_rtn_text = 'DB Error: '
+ @i_error_no + ' Error msg: '
+ @s_error_text;
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = @s_err_rtn_text;
RETURN;
END;
END CATCH;
END;
SWL_Label2:
/* FETCH NEXT FROM @cFeeSIR INTO @i_sir_id, @s_zip_code_3,
@s_d_proc_code, @s_percentile1, @s_percentile2,
@s_percentile3, @s_percentile4, @s_percentile5,
@s_percentile6, @s_percentile7, @s_percentile8; */
Set @cur_i = @cur_i + 1
END;
-- CLOSE @cFeeSIR;
---------------perform final err count, update stats-----------------------
SELECT @i_succ_count = COUNT(*)
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_status = 'P';
SET @i_succ_count = @i_succ_count - @i_init_count;
SET @i_error_count = @i_process_count - @i_succ_count;
/* update statistics */
EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
@i_succ_count, @i_error_count;
IF @SWV_dl_upd_statistics <> 1
BEGIN
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
' Failed to update statistics');
RETURN;
END;
UPDATE dbo.dl_cfg_bat_det
SET cfg_bat_det_stat = 'S'
WHERE cfg_bat_det_id = @i_cfg_bat_det_id;
--TRACE OFF;
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
' records are processed for Batch ',
@a_batch_id);
RETURN;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
SET @i_isam_error = ERROR_LINE();
SET @s_error_text = ERROR_MESSAGE();
SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
' Error msg: ', @s_error_text);
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = @s_err_rtn_text;
RETURN;
END CATCH;
SET NOCOUNT OFF;
　
　
-----------------------------------------------------------------
END;