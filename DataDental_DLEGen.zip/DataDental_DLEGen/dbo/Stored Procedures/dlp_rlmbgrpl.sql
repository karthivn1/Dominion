﻿CREATE PROCEDURE [dbo].[dlp_rlmbgrpl]
@a_batch_id INT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 12:05:05 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1











000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_fatal INT;
        DECLARE @li_fc_mb_gr_pl_id INT;
	 
        DECLARE @d_eff_date DATE;
        DECLARE @d_exp_date DATE;
        DECLARE @d_eff_rt_date DATE;
        DECLARE @d_exp_rt_date DATE;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @d_fc_net_id INT;
        DECLARE @d_net_id INT;
        DECLARE @d_rel_gppl_id INT;
        DECLARE @d_mb_gr_pl_id INT;
        DECLARE @d_status CHAR(2);
        DECLARE @d_net_fc_id INT;
        DECLARE @d_action_code CHAR(2);
        DECLARE @d_rlplfc_id INT;
        DECLARE @d_rlmbrt_id INT;
        DECLARE @d_old_rate_code CHAR(2);

        DECLARE @n_count INT;
        DECLARE @n_tmp_name CHAR(15);
        DECLARE @n_member_id INT;
        DECLARE @n_family_id INT;
        DECLARE @n_alt_id CHAR(20);
        DECLARE @n_ffs_plan INT;

        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);

        DECLARE @n_new_eff_date DATE;
        DECLARE @d_new_group_term DATE;
        DECLARE @d_nnm_date DATE;

        DECLARE @ls_rate_code CHAR(2);
        DECLARE @d_ovr_ride CHAR(1);
        DECLARE @s_ins_opt CHAR(3);
--when group transfer, dep will use sub's msi#
        DECLARE @n_dep_msi INT;

        DECLARE @li_dep_sir_id INT;
        DECLARE @r_facility_id INT;
        DECLARE @li_rlplfc_id INT;
        DECLARE @li_rlmbrt_id INT;
        DECLARE @li_mb_gr_pl_id INT;
        DECLARE @li_new_mb_gr_pl_id INT;
        DECLARE @ls_user CHAR(20);

DECLARE @i_sp_id integer;
DECLARE @i_sir_def_id integer;

DECLARE @n_report_only	char(1);
DECLARE @n_has_facility_id char(1);
DECLARE @n_new_mb_w_fc_id char(1);

DECLARE @n_has_s_plan_term	char(1);
DECLARE @n_has_d_plan_term	char(1);
DECLARE @n_has_rate_code	char(1);
DECLARE @n_has_rate_eff	char(1);
DECLARE @n_has_address	char(1);
DECLARE @n_add_to_cl_fc  char(1);

DECLARE @t_tl_sir_id		integer;
DECLARE @t_tl_sub_sir_id	integer;
DECLARE @t_subscriber		char(2);
DECLARE @t_alt_id			char(20);
DECLARE @t_src_id			char(20);
DECLARE @t_ext_id_col		char(20);
DECLARE @t_sub_ssn			char(11);
DECLARE @t_ssn				char(11);
DECLARE @t_sub_alt_id		char(20);
DECLARE @t_sub_in_plan		smallint;	--Subscriber in plan.
DECLARE @t_member_id		integer;
DECLARE @t_sub_id			integer;



DECLARE @t_group_id		integer;
DECLARE @t_member_code	char(2);
DECLARE @t_plan_id			integer;
DECLARE @t_facility_id	integer;
DECLARE @t_type    		char(2);
DECLARE @t_last_name		char(15);
DECLARE @t_first_name		char(15);
DECLARE @t_middle_init	char(1);
DECLARE @t_date_of_birth	date;
DECLARE @t_student_flag	char(1);
DECLARE @t_disable_flag	char(1);
DECLARE @t_cobra_flag		char(1);
DECLARE @t_action_code	char(2);
DECLARE @t_address1		char(30);
DECLARE @t_address2		char(30);
DECLARE @t_city			char(30);
DECLARE @t_state			char(2);
DECLARE @t_zip			char(5);
DECLARE @t_zipx			char(4);
DECLARE @t_home_phone		char(10);
DECLARE @t_home_ext		char(4);
DECLARE @t_work_phone		char(10);
DECLARE @t_work_ext		char(4);
DECLARE @t_rate_code		char(2);
DECLARE @t_plan_eff_date date;
DECLARE @t_plan_term_date		date;
DECLARE @t_fac_eff_date		date;
DECLARE @t_action_date		date;
DECLARE @t_status			char(1);
DECLARE @n_datetime			datetime2(2)

DECLARE @n_msi	integer;
DECLARE @msi_upper	integer;

        
        DECLARE @t_load_period Date;
        DECLARE @SWV_dlp_gi_update INT;
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;
DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @SWV_cursor_var4 CURSOR;
        DECLARE @SWV_cursor_var5 CURSOR;
        DECLARE @SWV_cursor_var6 CURSOR;
        DECLARE @SWV_cursor_var7 CURSOR;
        DECLARE @SWV_cursor_var8 CURSOR;
        DECLARE @SWV_cursor_var9 CURSOR;
        DECLARE @SWV_cursor_var10 CURSOR;
        DECLARE @SWV_cursor_var11 CURSOR;
        DECLARE @SWV_cursor_var12 CURSOR;
        DECLARE @SWV_dlp_fc_count INT;
		DECLARE @created_by CHAR(8)

        SET NOCOUNT ON;
        SET @i_sp_id =0;
       
        SET @i_sir_def_id =0;
       
        SET @n_report_only ='';
       
        SET @n_has_facility_id ='';
       
        SET @n_new_mb_w_fc_id ='';
        
        SET @n_has_s_plan_term ='';
       
        SET @n_has_d_plan_term ='';
     
        SET @n_has_rate_code ='';
       
        SET @n_has_rate_eff ='';
      
        SET @n_has_address ='';
    
        SET @n_add_to_cl_fc ='';
       
        SET @t_tl_sir_id =0;
     
        SET @t_tl_sub_sir_id =0;
       
        SET @t_subscriber ='';
        
		SET @t_alt_id ='';
   
        SET @t_src_id ='';
     
        SET @t_ext_id_col ='';
      
        SET @t_sub_ssn ='';
       
        SET @t_ssn ='';
      
        SET @t_sub_alt_id ='';
      
        SET @t_sub_in_plan =NULL;
     
        SET @t_member_id =0;
    
        SET @t_sub_id =0;
     
        SET @t_group_id =0;
       
        SET @t_member_code ='';
 
        SET @t_plan_id =0;

        SET @t_facility_id =0;
     
        SET @t_type ='';
       
        SET @t_last_name ='';
       
        SET @t_first_name ='';
     
        SET @t_middle_init ='';
        
        SET @t_date_of_birth =NULL;
       
        SET @t_student_flag ='';
       
        SET @t_disable_flag ='';
       
        SET @t_cobra_flag ='';
       
        SET @t_action_code ='';
      
        SET @t_address1 ='';
     
        SET @t_address2 ='';
       
        SET @t_city ='';
       
        SET @t_state ='';
       
        SET @t_zip ='';
       
        SET @t_zipx ='';
       
        SET @t_home_phone ='';
      
        SET @t_home_ext ='';
       
        SET @t_work_phone ='';
      
        SET @t_work_ext ='';
       
        SET @t_rate_code ='';
        
        SET @t_plan_eff_date =NULL;
      
        SET @t_plan_term_date =NULL;
       
        SET @t_fac_eff_date =NULL;
       
        SET @t_action_date =NULL;
       
        SET @t_status ='';
        
        SET @n_datetime =NULL;
        
        SET @n_msi =0;
       
        SET @msi_upper =0;
      
        SET @t_load_period =NULL;
      
        BEGIN TRY

					EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'up_eligibility'
					SET @i_sir_def_id = dbo.dl_get_sir_def_id('elig');

					SELECT @created_by = LEFT(created_by,8) FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id

			--SELECT @n_datetime = VarValue from dbo.GlobalVar where VarName = 'n_datetime' and  BatchId = @a_batch_id AND Module_Id = 4
			SET @n_datetime = GETDATE()
			SELECT @t_tl_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_tl_sir_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_tl_sub_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_tl_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_in_plan = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_in_plan' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_member_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_facility_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 4
			
			SELECT @t_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_action_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_action_code' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_plan_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_plan_term_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_fac_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_status = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_status' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 4
			
			SELECT @t_src_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_src_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_action_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_action_date' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_ext_id_col = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @n_msi = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @msi_upper = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'msi_upper' and  BatchId = @a_batch_id AND Module_Id = 4
		
			--SELECT  @t_action_date = action_date from dbo.dl_action WHERE batch_id = @a_batch_id AND dls_sir_id = @t_tl_sub_sir_id
			
            SET @d_rel_gppl_id = NULL;
            SET @d_mb_gr_pl_id = NULL;
            SET @ls_user = CONCAT('dl', @a_batch_id);
           
            IF @t_group_id IS NULL
			BEGIN
			SET @n_return_code=402
                RAISERROR('Group id is NULL',16,1);
			END

            
            IF @t_plan_id IS NULL
			BEGIN
			SET @n_return_code=403
                RAISERROR('Plan id is NULL',16,1);
			END

 
        IF ( ( @t_action_code IS NULL
                   OR @t_action_code = ''
                 )
                 OR LEN(@t_action_code) = 0
               )
			   BEGIN
			   SET @n_return_code=404
                RAISERROR('Action code is NULL',16,1);
			END

       
            IF ( @t_action_code NOT IN ( 'MT', 'ST', 'SA', 'DA', 'RC', 'SR',
                            'DR', 'FX', 'GX', 'PC', 'MU', 'PA',
             'RI' )
                 AND @t_action_code NOT LIKE 'G[1-7]' ESCAPE '\'
               )
			   BEGIN
			   SET @n_return_code=406
                RAISERROR('Invalid action code',16,1);
			END

            
            IF ( @t_action_code LIKE 'G[1-7]' ESCAPE '\' )
                BEGIN
                    
                    EXECUTE @SWV_dlp_gi_update = dbo.dlp_gi_update @ls_user, @t_tl_sir_id,
                        @t_action_code

                    RETURN @SWV_dlp_gi_update
                END;

            
            IF ( @t_action_date IS NULL )
			BEGIN
			SET @n_return_code=405
                RAISERROR('Member''s action_date is NULL',16,1);
			END
            
            IF @t_action_code IN ( 'SA', 'SR', 'RC' )
                OR ( ( @t_action_code = 'PA'
                       OR @t_action_code = 'RI'
                     )
                     AND @t_subscriber = '00'
                   )
                BEGIN
                    
                    IF ( ( @t_rate_code IS NULL
                           OR @t_rate_code = ''
                         )
                         OR LEN(@t_rate_code) = 0
                       )
					   BEGIN
					   SET @n_return_code=407
                        RAISERROR('Rate code is NULL',16,1);
						END
	
                    
                    IF ( @t_action_date IS NULL )
					BEGIN
					SET @n_return_code=408
                        RAISERROR('Subscriber''s rate eff_date is NULL',16,1);
						END
                END;

           
            IF ( @t_action_code IN ( 'ST', 'MT', 'SR', 'PA', 'RI', 'DR', 'RC',
                                     'GX' ) )
                BEGIN
                  
                    IF ( @t_member_id IS NULL )
					BEGIN
					SET @n_return_code=413
                        RAISERROR('Member'' ID is NULL',16,1);
					END
                 
                    IF ( @t_sub_id IS NULL )
					BEGIN
						SET @n_return_code=414
                        RAISERROR('Member''s subscriber ID is NULL',16,1);
					END
                END;
				
            IF ( @t_action_code IN ( 'ST', 'MT', 'RC' ) )
                BEGIN
                    SET @d_mb_gr_pl_id = NULL;
					
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
		
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @t_sub_id AND
         group_id = @t_group_id AND
       plan_id = @t_plan_id AND
         eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
         ORDER BY 2 DESC,3;
		
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @d_mb_gr_pl_id,
                        @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label13;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                        END;
                    SWL_Label13:
                    CLOSE @SWV_cursor_var1;
					
                    IF ( @d_mb_gr_pl_id IS NULL )
                        BEGIN
                           
                            IF @t_action_code = 'MT'
                                BEGIN
                                 
                             IF @t_action_date = @t_plan_term_date
                                        RETURN 1;
    END;
							SET @n_return_code=416
       RAISERROR('Subscriber has no active group/plan',16,1);
                        END;
                END;

-------------------------------------------
  
            IF ( @t_action_code = 'MU' )
 BEGIN
                    
                    IF ( @t_src_id IS NULL
                         OR @t_src_id = ''
                       )
                        BEGIN
                            SET @t_src_id ='';
                           
                        END;
	

 IF @t_src_id = ''
    UPDATE  dbo.member
                        SET     new_ssn = @t_ssn ,
                               alt_id = @t_alt_id ,
                    last_name = @t_last_name ,
                                first_name = @t_first_name ,
                                middle_init = @t_middle_init ,
                                date_of_birth = @t_date_of_birth ,
                                member_code = @t_member_code ,
                                action_code = 'GI' ,
                                h_datetime = GETDATE() ,
                                h_user = @ls_user
                        WHERE   member_id = @t_member_id;
                    ELSE
                        UPDATE  dbo.member
                        SET     new_ssn = @t_ssn ,
                                alt_id = @t_alt_id ,
                                source_id = @t_src_id ,
                                last_name = @t_last_name ,
                                first_name = @t_first_name ,
                                middle_init = @t_middle_init ,
                                date_of_birth = @t_date_of_birth ,
                                member_code = @t_member_code ,
                                action_code = 'GI' ,
                                h_datetime = GETDATE() ,
                                h_user = @ls_user
                        WHERE   member_id = @t_member_id;
	 
---- Update external ID if necessary!

                    SELECT  @t_ext_id_col = str_1
                    FROM    dbo.typ_table_exp t (NOLOCK) ,
                            dbo.member m (NOLOCK)
                    WHERE   m.ext_id_type = t.int_1
                            AND t.subsys_code = 'MB'
                            AND t.tab_name = 'ext_id_type'
                            AND m.member_id = @t_member_id;
                    
                    
                   
                    IF @t_ext_id_col = 'new_ssn'
                        UPDATE  dbo.member
                        SET     member_ssn = new_ssn
                        WHERE   member_id = @t_member_id;
                    ELSE
                        BEGIN
                           
                            IF @t_ext_id_col = 'alt_id'
                                UPDATE  dbo.member
                                SET     member_ssn = alt_id
                               WHERE   member_id = @t_member_id;
                            ELSE
                                BEGIN
                                   
                                    IF @t_ext_id_col = 'source_id'
                                        UPDATE  dbo.member
                                        SET     member_ssn = source_id
                                        WHERE   member_id = @t_member_id;
                                END;
                        END;
                END;

--update action_code to GI, AR#4961
-------------------------------------------
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.[plan] (NOLOCK),
                                    dbo.ins_opt (NOLOCK)
                            WHERE   dbo.[plan].plan_id = @t_plan_id
                                    AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                    AND dbo.ins_opt.ins_opt_qual = 'I' )
                BEGIN
SET @n_ffs_plan = 0;
      SELECT  @s_ins_opt = ins_opt
 FROM    dbo.[plan] (NOLOCK)
                    WHERE   plan_id = @t_plan_id;
                   
                END;
        ELSE
         SET @n_ffs_plan = 1;

            IF @t_action_code IN ( 'MT', 'ST' )
     IF @n_ffs_plan = 0
                    BEGIN
               
                      IF ( @t_facility_id IS NULL )
					  BEGIN
						SET @n_return_code=415
							RAISERROR('No Facility ID specified',16,1);
					END
                    END;

            IF @t_action_code IN ( 'DA', 'SA', 'SR', 'DR', 'FX', 'PC', 'GX',
                                   'PA', 'RI' )
	--if t_action_code in ("DA", "SA", "SR", "DR", "FX","PC", "GX") then
                BEGIN
                  
                    SET @n_new_eff_date = @t_action_date;
	--end if

                    IF @n_ffs_plan = 0
                        BEGIN
                          
                            IF ( @t_facility_id IS NULL )
							BEGIN
								SET @n_return_code=415
                                RAISERROR('No Facility ID specified',16,1);
						END
                        END;
                END;

         
            IF @t_action_code = 'ST'
                BEGIN
                    
                    IF ( @t_subscriber <> '00' )
					BEGIN
					SET @n_return_code=425
                        RAISERROR('Dependent with ST action code.',16,1);
					END
	
                    IF ( @d_exp_gr_pl IS NOT NULL )
					BEGIN
						SET @n_return_code=426
                        RAISERROR('Subscriber ST on a terminated group/plan',16,1);
					END
                    
                    IF ( @t_plan_term_date < @d_eff_gr_pl )
					BEGIN
					SET @n_return_code=427
                        RAISERROR('Subscriber ST before group/plan is active',16,1);
					END
					
                    SET @n_msi = @n_msi + 1;
					
                    
					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
	 --$$ks puts prev action_code value into h_action column
	 -- normally that is SA
                    UPDATE  dbo.rlmbgrpl
                    SET     h_msi = @n_msi ,
                            exp_gr_pl = @t_plan_term_date ,
                            action_code = @t_action_code ,
                            h_action = action_code ,
     h_user = @ls_user ,
                            h_datetime = GETDATE()
                    WHERE   mb_gr_pl_id = @d_mb_gr_pl_id;
                   
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_1', @t_sub_id,@created_by;
                END;

            
            IF @t_action_code = 'MT'
                BEGIN
                   
                    IF ( @t_subscriber = '00' )
					BEGIN
					SET @n_return_code=428
                        RAISERROR('Subscriber with MT action code.',16,1);
					END
	
                    IF ( @d_exp_gr_pl IS NOT NULL )
                        BEGIN
                           
                            IF ( @t_plan_term_date = @d_exp_gr_pl )
                                RETURN 1;
		
                            
                            IF ( @t_plan_term_date > @d_exp_gr_pl )
							BEGIN
								SET @n_return_code=429
                                RAISERROR('Dependent MT after subscriber''s terminated',16,1);
								END
                        END;
                    ELSE
                        BEGIN
                          
                            IF (  @t_plan_term_date < @d_eff_gr_pl )
							BEGIN
							SET @n_return_code=431
                                RAISERROR('Dependent MT terminated before subsriber''s group/plan is active',               16,1);
								END
                        END;
	
                    IF @n_ffs_plan = 0
                        BEGIN
                 SELECT  @d_rlplfc_id = rlplfc_id
           FROM    dbo.rlplfc (NOLOCK)
            WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                 AND member_id = @t_member_id
                                    AND facility_id = @t_facility_id
                AND eff_date <= @t_plan_term_date
                                    AND exp_date IS NULL;
                            
                        END;
                    ELSE
                        BEGIN
                            SELECT  @d_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
            AND member_id = @t_member_id
                                    AND facility_id IS NULL
                                  AND eff_date <= @t_plan_term_date
                                    AND exp_date IS NULL;
                           
                        END;
	
                    IF ( @d_rlplfc_id IS NULL )
					BEGIN
					SET @n_return_code=432
                        RAISERROR('Dependent MT with no active facility',16,1);
					END

                    SET @n_msi = @n_msi + 1;

					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
					
                 
                    UPDATE  dbo.rlplfc
                    SET     exp_date = @t_plan_term_date ,
                            action_code = @t_action_code ,
                            h_action = action_code ,
                            h_user = @ls_user ,
                            h_datetime = GETDATE()
                    WHERE   rlplfc_id = @d_rlplfc_id;
                    
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2', @t_sub_id,@created_by;
                    RETURN 1;
                END;

           
            IF @t_action_code = 'RC'
                BEGIN
                    
                    IF @t_subscriber <> '00'
					BEGIN
					SET @n_return_code=451
                        RAISERROR('Dependent with RC',16,1);
					END
	
                    
                    IF ( @t_action_date < @d_eff_gr_pl )
					BEGIN
						SET @n_return_code=453
                        RAISERROR('RC before subscriber''s group/plan eff_gr_pl',16,1);
					END
	
                    IF ( @d_exp_gr_pl IS NOT NULL )
                        BEGIN
                            
                  IF ( @t_action_date) >= @d_exp_gr_pl 
							BEGIN
							SET @n_return_code=454
                                RAISERROR('RC after subscriber''s group/plan expired',16,1);
							END
                        END;
	
                    SET @d_rlmbrt_id = NULL;
                    SET @d_old_rate_code = NULL;
	/* 20150720$$ks - this is wrong, cannot change ratecode if already expired
	 * Causes major eoip errors
	 * Sub with 2 dependents
	 * Sub + 1 dep active 1/1/2015 ratecode = K1
	 * add sec dep added 03/30/2015 ratecode = K2 old K1 record exp 3/20/2015
	 * terminate dependent 1 as of 1/1/2015 system
	 * updates K1 record with 1/1/2015 exp date and leaves K2 active
	 * then adds new K1 record so we have 2 active RC records.
	foreach select rlmbrt_id, rate_code, eff_rt_date
		into d_rlmbrt_id, d_old_rate_code, d_eff_rt_date
		from rlmbrt
		where mb_gr_pl_id = d_mb_gr_pl_id and
			eff_rt_date <= t_action_date and
  	 (exp_rt_date > t_action_date or exp_rt_date is null) << cannot add rc t ween existing
	 */
                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT rlmbrt_id, rate_code, eff_rt_date
	  
         FROM dbo.rlmbrt (NOLOCK)
         WHERE mb_gr_pl_id = @d_mb_gr_pl_id
         AND eff_rt_date <= @t_action_date AND
	  (exp_rt_date IS NULL)
         ORDER BY 2 DESC;
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @d_rlmbrt_id,
                        @d_old_rate_code, @d_eff_rt_date;
 WHILE @@FETCH_STATUS = 0
             BEGIN
                            GOTO SWL_Label14;
                         FETCH NEXT FROM @SWV_cursor_var2 INTO @d_rlmbrt_id,
                                @d_old_rate_code, @d_eff_rt_date;
                        END;
                    SWL_Label14:
                    CLOSE @SWV_cursor_var2;
                    IF ( @d_rlmbrt_id IS NULL
                         OR ( @d_old_rate_code IS NULL
                              OR @d_old_rate_code = ''
                            )
                       )
					   BEGIN
					   SET @n_return_code=455
                        RAISERROR('Subscriber RC with no prior rate code',16,1);
					END
	
                    
                    IF ( @t_action_date) < @d_eff_rt_date 
					BEGIN
						SET @n_return_code=456
                        RAISERROR('Subscriber (RC) before prior rate code eff_rt_date',16,1);
					END
	
                    
                    IF @t_tl_sir_id IS NULL
					BEGIN
						SET @n_return_code=553
                        RAISERROR('Null subscriber sir Id. Action RC.',16,1);
					END
	
                 IF ( ( SELECT   rate_num_depend
                           FROM     dbo.pl_rat (NOLOCK)
                           WHERE    rate_code = @t_rate_code
                    ) - ( SELECT   rate_num_depend
                 FROM     dbo.pl_rat (NOLOCK)
                               WHERE    rate_code = @d_old_rate_code
                             ) ) >= 0
                        SET @d_action_code = 'DA';
                    ELSE
                        SET @d_action_code = 'MT';
	
                    
                    SET @n_msi = @n_msi + 1;
					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4

					                    
                    IF @n_msi > @msi_upper
					BEGIN
						SET @n_return_code=510
                        RAISERROR('msi number exceeded the maximum allocated number',16,1);
					END

					
                    UPDATE  dbo.rlmbrt
                    SET     exp_rt_date = @t_action_date ,
                            action_code = @d_action_code ,
                            h_msi = @n_msi ,
                            h_action = action_code ,
                            h_user = @ls_user ,
                            h_datetime = @n_datetime
                    WHERE   rlmbrt_id = @d_rlmbrt_id;
             
                    SET @n_msi = @n_msi + 1;
                   UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4

                    IF @n_msi > @msi_upper
					BEGIN
						SET @n_return_code=510
                        RAISERROR('msi number exceeded the maximum located number',16,1);
					END
	
                    INSERT  INTO dbo.rlmbrt
                            ( mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_rate_code ,
                              @t_action_date ,
                              @d_action_code ,
                              @d_action_code ,
                              @n_msi ,
                              @n_datetime ,
                              @ls_user
                            );
                END;

           
            IF @t_action_code = 'SA'
                BEGIN
                    SET @n_count = 0;
                    IF @t_subscriber <> '00'
					BEGIN
						SET @n_return_code=441
                        RAISERROR('Dependent with SA action code.',16,1);
					END
	
      IF NOT @t_fac_eff_date >= @t_action_date
					BEGIN
						SET @n_return_code=442
               RAISERROR('Subscriber''s rate eff_date later than action eff_date',16,1);
					END
	
                    IF @n_count = 0
                     BEGIN
                            
                            EXECUTE dbo.dlp_member @a_batch_id, @t_tl_sir_id,
                     'Y', @ls_user, @n_return_code OUTPUT,
                                @n_msi OUTPUT, @n_datetime OUTPUT;
                            IF @n_return_code < 0
                                RETURN @n_return_code;
		
                            UPDATE  dbo.dls_elig
                            SET     dls_member_id = @t_member_id ,
                                    dls_sub_id = @t_sub_id
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sir_id = @t_tl_sir_id;
                        END;
                    ELSE
                        BEGIN
                            SET @n_msi = @n_msi + 1;
                           UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=510
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
       END;	
						
						SELECT @t_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
						SELECT @t_member_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4

                    INSERT  INTO dbo.rlmbgrpl
                            ( member_id ,
                              group_id ,
                              plan_id ,
                              sub_in_plan ,
							  eff_gr_pl ,
							action_code ,
								 h_action ,
									  h_msi ,
                              h_datetime ,
                            h_user
            )
                    VALUES  ( @t_sub_id ,
                              @t_group_id ,
                              @t_plan_id ,
                              @t_sub_in_plan ,
                              @t_action_date ,
                              @t_action_code ,
                              @t_action_code ,
                              @n_msi ,
                              @n_datetime ,
      @ls_user
                      );
	
                    SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                    FROM    dbo.rlmbgrpl (NOLOCK)
                    WHERE   h_msi = @n_msi;
                   
                    IF ( @d_mb_gr_pl_id IS NULL )
					BEGIN
						SET @n_return_code=446
                        RAISERROR('DB failed to retireve inserted Group/Plan',16,1);
					END
	
                    INSERT  INTO dbo.rlmbrt
                            ( mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_rate_code ,
                              @t_action_date ,
                              @t_action_code ,
                              @t_action_code ,
                              @n_msi ,
                              @n_datetime ,
                              @ls_user
                            );
	
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
h_datetime ,
 h_user
                            )
             VALUES  ( @d_mb_gr_pl_id ,
                              @t_member_id ,
                        @t_facility_id ,
                              @t_action_date ,
                              @t_action_code ,
                              @t_action_code ,
    @n_msi ,
           @n_datetime ,
                              @ls_user
                            );
	
                    
                    EXECUTE dbo.mb_add_cat @d_mb_gr_pl_id, @t_member_id,
                        @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
                            RAISERROR(@n_error_desc,16,1);
                        END;
	
                    SELECT  @li_rlplfc_id = rlplfc_id
                    FROM    dbo.rlplfc (NOLOCK)
                    WHERE   h_msi = @n_msi
                            AND mb_gr_pl_id = @d_mb_gr_pl_id
                            AND member_id = @t_member_id;

							
                  
                    EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id, @li_rlplfc_id,
                        'N', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
            BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
                            RAISERROR(@n_error_desc,16,1);
                        END;
						
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'admenu_1', @t_sub_id,@created_by;
     END;

 
            IF @t_action_code = 'DA'
                BEGIN
    SET @n_count = 0;
                    
                    IF @t_subscriber = '00'
					BEGIN
					SET @n_return_code=464
           RAISERROR('Subscriber with DA action code.',16,1);
		   END
	
                    EXECUTE dbo.dlp_member @a_batch_id, @t_tl_sir_id,
                        @n_has_address, @ls_user, @n_return_code OUTPUT,
                        @n_msi OUTPUT, @n_datetime OUTPUT;
                    IF @n_return_code < 0
                        RETURN @n_return_code;
		
                    UPDATE  dbo.dls_elig
                    SET     dls_member_id = @t_member_id ,
                     dls_sub_id = @t_sub_id
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @t_tl_sir_id;

						SELECT @t_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
						SELECT @t_member_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4
						SELECT @n_msi = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4

							

                    SET @SWV_cursor_var3 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
		
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @t_sub_id AND
         group_id = @t_group_id AND
         plan_id = @t_plan_id AND
			(eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
         ORDER BY 2 DESC,3;
                    OPEN @SWV_cursor_var3;
                    FETCH NEXT FROM @SWV_cursor_var3 INTO @d_mb_gr_pl_id,
                        @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label15;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                        END;
                    SWL_Label15:
                    CLOSE @SWV_cursor_var3;
                    IF ( @d_mb_gr_pl_id IS NULL )
					BEGIN
						SET @n_return_code=462
                        RAISERROR('Dependent DA with no active subscriber''s group/plan',16,1);
					END
	
                    
   IF ( @d_eff_gr_pl > @t_action_date )
         SET @n_new_eff_date = @d_eff_gr_pl;
                    ELSE
                        BEGIN
       
                            SET @n_new_eff_date = @t_action_date;
                        END;
	

-- added so that only check when has_facility_id, UDC's unknown facility is not 
-- real unknown facility 

                   
                    IF @n_new_mb_w_fc_id = 'Y'
                        IF @n_ffs_plan = 0
                            BEGIN
                              
			   -- CH001
						 EXECUTE @SWV_dlp_fc_count = dlp_fc_count @d_mb_gr_pl_id,
                                    @t_tl_sir_id, @n_new_eff_date
                                    
                                IF @SWV_dlp_fc_count < 0
								BEGIN
								SET @n_return_code=469
                                    RAISERROR('Maximum facility count exceeded for subscriber'' rate code',                  16,1);
								END
                            END;
		
	
                    IF @n_count = 1
                        BEGIN
                            
                            SET @n_msi = @n_msi + 1;

							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                            
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=510
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
                        END;
	
								   
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              action_code ,
                              h_action ,
            h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_member_id ,
                              @t_facility_id ,
                              @n_new_eff_date ,
--		t_action_date,
            @t_action_code ,
                          @t_action_code ,
                              @n_msi ,
                     @n_datetime ,
                              @ls_user
          );
	
                    
                    EXECUTE dbo.mb_add_cat @d_mb_gr_pl_id, @t_member_id,
                        @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
								SET @n_return_code=520
                            RAISERROR(@n_error_desc,16,1);
                        END;
	
                    SELECT  @li_rlplfc_id = rlplfc_id
                    FROM    dbo.rlplfc (NOLOCK)
                    WHERE   h_msi = @n_msi
                            AND mb_gr_pl_id = @d_mb_gr_pl_id
                            AND member_id = @t_member_id;
                  
                    EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id, @li_rlplfc_id,
                        'N', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
								SET @n_return_code=520
                            RAISERROR(@n_error_desc,16,1);
                 END;
	
                   
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'admenu_2', @t_sub_id,@created_by;
                 
                    IF @t_plan_term_date IS NOT NULL
                        BEGIN
  
                            IF @t_plan_term_date < @n_new_eff_date
							BEGIN
							SET @n_return_code=470
                                RAISERROR('New dependent with termination date before plan''s effective date',               16,1);
							END
		
     UPDATE  dbo.rlplfc
              SET     exp_date = @t_plan_term_date ,
                                    action_code = 'MT' ,
h_action = action_code ,
                                    h_user = @ls_user ,
                                    h_datetime = GETDATE()
                            WHERE   h_msi = @n_msi;
                           
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2',
                                @t_member_id,@created_by;
                        END;
                END;

          
            IF @t_action_code = 'SR'
                BEGIN
                   
                    IF @t_subscriber <> '00'
					BEGIN
						SET @n_return_code=447
                        RAISERROR('Dependent with SR action code.',16,1);
					END
	
                    IF EXISTS ( SELECT  *
                                FROM    dbo.rlmbgrpl (NOLOCK)
                                WHERE   member_id = @t_member_id
                                        AND group_id = @t_group_id
                                        AND plan_id = @t_plan_id
                                        AND ( eff_gr_pl <= @t_action_date
                                              AND ( exp_gr_pl > @t_action_date
                                                    OR exp_gr_pl IS NULL
                                                  )
                                            ) )
										BEGIN
										SET @n_return_code=448
                        RAISERROR('SA with active subscriber''s group/plan',16,1);
						END
	
                  
                    IF @t_action_code = 'SR'
                        BEGIN
                          SET @t_action_code = 'SA' ;
                           
                        END;
	
                  
                  SET @n_msi = @n_msi + 1;
				   
				  UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
				  
                    IF @n_msi > @msi_upper
					BEGIN
						SET @n_return_code=510
    RAISERROR('msi number exceeded the maximum located number',16,1);
					END
	
	 
                    INSERT  INTO dbo.rlmbgrpl
                            ( member_id ,
							 group_id ,
                              plan_id ,
                              sub_in_plan ,
                              eff_gr_pl ,
  action_code ,
                              h_action ,
							 h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @t_sub_id ,
                              @t_group_id ,
                              @t_plan_id ,
                              @t_sub_in_plan ,
                              @t_action_date ,
                              @t_action_code ,
                              @t_action_code ,
                              @n_msi ,
                              @n_datetime ,
                              @ls_user
                            );
	
                    SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                    FROM    dbo.rlmbgrpl (NOLOCK)
                    WHERE   h_msi = @n_msi;
                 
                    IF ( @d_mb_gr_pl_id IS NULL )
					BEGIN
						SET @n_return_code=446
                        RAISERROR('DB failed to retireve inserted Group/Plan',16,1);
					END
	
                    INSERT  INTO dbo.rlmbrt
                            ( mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              action_code ,
                    h_action ,
                              h_msi ,
                              h_datetime ,
                            h_user
      )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_rate_code ,
                            @t_action_date ,
    @t_action_code ,
                @t_action_code ,
                              @n_msi ,
                              @n_datetime ,
                      @ls_user
                            );
	
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_member_id ,
                              @t_facility_id ,
                              @t_action_date ,
                              @t_action_code ,
                              @t_action_code ,
                              @n_msi ,
                              @n_datetime ,
                              @ls_user
                            );
	
                  
                    EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id, @t_member_id,
                        'N', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
								SET @n_return_code=520
                            RAISERROR(@n_error_desc,16,1);
                        END;
	
                    SELECT  @li_rlplfc_id = rlplfc_id
                    FROM    dbo.rlplfc (NOLOCK)
                    WHERE   h_msi = @n_msi
                            AND mb_gr_pl_id = @d_mb_gr_pl_id
                            AND member_id = @t_member_id;
                  
             EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id, @li_rlplfc_id,
                        'Y', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
       BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
            + @n_error_desc;
			SET @n_return_code=520
                            RAISERROR(@n_error_desc,16,1);
                        END;
	

	-- log subscriber reinstate
      
       EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_6', @t_sub_id,@created_by;
                END;

            IF @t_action_code = 'DR'
        BEGIN
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.member (NOLOCK)
                                    WHERE   member_id = @t_member_id )
							BEGIN
							SET @n_return_code=461
                        RAISERROR('DR with no existing member record',16,1);
						END
	
                    SET @d_mb_gr_pl_id = NULL;
                    SET @SWV_cursor_var4 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
		
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @t_sub_id AND
         group_id = @t_group_id AND
         plan_id = @t_plan_id AND
			(eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
         ORDER BY 2 DESC,3;
                    OPEN @SWV_cursor_var4;
                    FETCH NEXT FROM @SWV_cursor_var4 INTO @d_mb_gr_pl_id,
                        @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label16;
                            FETCH NEXT FROM @SWV_cursor_var4 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                        END;
                    SWL_Label16:
                    CLOSE @SWV_cursor_var4;
                   IF ( @d_mb_gr_pl_id IS NULL )
					BEGIN
					SET @n_return_code=466
                        RAISERROR('Dependent DR with no active subscriber''s group/plan',16,1);
					END
	
               
                    IF ( @d_eff_gr_pl > @t_action_date )
                        SET @n_new_eff_date = @d_eff_gr_pl;
             ELSE
                        BEGIN
                           
                            SET @n_new_eff_date = @t_action_date;
                        END;
	
                    IF EXISTS ( SELECT  *
                                FROM    dbo.rlplfc (NOLOCK)
                                WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                        AND member_id = @t_member_id
                                        AND ( ( eff_date <= @t_action_date
                                                AND ( exp_date > @t_action_date
                                                      OR exp_date IS NULL
                                                    )
                                              )
                                              OR ( eff_date > @t_action_date
                                                   AND ( exp_date > eff_date
                                                         OR exp_date IS NULL
                                                       )
                                                 )
                                            ) )
									BEGIN
									SET @n_return_code=468
                        RAISERROR('Dependent DR with active facility',16,1);
						END

                    IF @t_action_code = 'DR'
                        BEGIN
                            SET @t_action_code = 'DA' ;
                          
                        END;

        IF @n_has_facility_id = 'Y'
                        IF @n_ffs_plan = 0
                            BEGIN
			--CH001
                                EXECUTE dlp_fc_count @d_mb_gr_pl_id,
                                    @t_tl_sir_id, @n_new_eff_date,
                                    @SWV_dlp_fc_count OUTPUT;
                                IF @SWV_dlp_fc_count < 0
								BEGIN
								SET @n_return_code=469
                     RAISERROR('Maximum facility count exceeded for subscriber'' rate code',                  16,1);
									END
                            END;
	
                    SET @n_msi = @n_msi + 1;

					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                   
                    IF @n_msi > @msi_upper
				BEGIN
				SET @n_return_code=510
                        RAISERROR('msi number exceeded the maximum located number',16,1);
					END
	
                   INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
           member_id ,
              facility_id ,
                              eff_date ,
           action_code ,
              h_action ,
                   h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_member_id ,
                              @t_facility_id ,
                              @n_new_eff_date ,
                              @t_action_code ,
                              @t_action_code ,
                              @n_msi ,
                              @n_datetime ,
                              @ls_user
                            );
	
                   
                    EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id, @t_member_id,
                        'N', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                               + @n_error_desc;
								SET @n_return_code=520
                            RAISERROR(@n_error_desc,16,1);
                        END;
	
                    SELECT  @li_rlplfc_id = rlplfc_id
           FROM dbo.rlplfc (NOLOCK)
                    WHERE   h_msi = @n_msi
                            AND mb_gr_pl_id = @d_mb_gr_pl_id
         AND member_id = @t_member_id;
                   
                    EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id, @li_rlplfc_id,
                        'Y', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
                            SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
								SET @n_return_code=520
                            RAISERROR(@n_error_desc,16,1);
                        END;
	
	-- log Dep reinstate
                    
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_6', @t_sub_id,@created_by;
                   
                    IF @t_plan_term_date IS NOT NULL
                        BEGIN
                            
                            IF @t_plan_term_date < @n_new_eff_date
							BEGIN
							SET @n_return_code=470
                                RAISERROR('New dependent with termination date before plan''s effective date',             16,1);
								END
		
                            UPDATE  dbo.rlplfc
                            SET     exp_date = @t_plan_term_date ,
                                    action_code = 'MT' ,
                                    h_action = action_code ,
                                    h_user = @ls_user ,
                                    h_datetime = @n_datetime
                            WHERE   h_msi = @n_msi;
                          
                        EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2',
                                @t_member_id,@created_by;
                        END;
                END;

            IF @t_action_code = 'PA'
                BEGIN
                   
                    IF @t_subscriber = '00'
                        BEGIN
                           IF EXISTS ( SELECT  *
          FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @t_member_id
                                                AND group_id = @t_group_id
      AND plan_id = @t_plan_id
                                                AND ( eff_gr_pl <= @t_action_date
                                                      AND ( exp_gr_pl > @t_action_date
                                                            OR exp_gr_pl IS NULL
          )
                                                    ) )
													BEGIN
													SET @n_return_code=448
                              RAISERROR('SA with active subscriber''s group/plan',16,1);
							  END
		
                            
                          SET @n_msi = @n_msi + 1;

						  UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                          
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=510
                              RAISERROR('msi number exceeded the maximum located number',16,1);
							  END
		
                            INSERT  INTO dbo.rlmbgrpl
                                    ( member_id ,
                                      group_id ,
                                      plan_id ,
                                      sub_in_plan ,
                                      eff_gr_pl ,
                                      action_code ,
                                      h_action ,
            h_msi ,
                                      h_datetime ,
                                      h_user
            )
                            VALUES  ( @t_sub_id ,
       @t_group_id ,
                                      @t_plan_id ,
                                      @t_sub_in_plan ,
                                      @t_action_date ,
         @t_action_code ,
                     @t_action_code ,
      @n_msi ,
                        @n_datetime ,
                              @ls_user
                                    );
		
                            SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl (NOLOCK)
                            WHERE   h_msi = @n_msi;
                           
                            IF ( @d_mb_gr_pl_id IS NULL )
							BEGIN
							SET @n_return_code=446
              RAISERROR('DB failed to retireve inserted Group/Plan',16,1);
			  END
		
                            INSERT  INTO dbo.rlmbrt
                                    ( mb_gr_pl_id ,
                                      rate_code ,
                                      eff_rt_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @t_rate_code ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @t_action_code ,
                                      @n_msi ,
                                      @n_datetime ,
                                      @ls_user
                                    );
		
                            INSERT  INTO dbo.rlplfc
                       ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @t_member_id ,
                                      @t_facility_id ,
                                     @t_action_date ,
                                      @t_action_code ,
                                      @t_action_code ,
                                      @n_msi ,
                                      @n_datetime ,
                                      @ls_user
                                    );
	
                
                            EXECUTE dbo.mb_add_cat @d_mb_gr_pl_id,
                                @t_member_id, @n_error_code OUTPUT,
                  @n_error_desc OUTPUT;
               IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
             + ':' + @n_error_desc;
			 SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                                END;
	
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;

									      
                            EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                       @n_error_desc OUTPUT;
                 IF ( @n_error_code < 0 )
                             BEGIN
    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
											SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                           END;
	

	-- log subscriber Plan add
   
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'admenu_3',
                           @t_sub_id,@created_by;
                        END;
                    ELSE
                        BEGIN
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.member (NOLOCK)
                                            WHERE   member_id = @t_member_id )
											BEGIN
											SET @n_return_code=461
                                RAISERROR('PA with no existing member record',16,1);
								END
		
                            SET @d_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var5 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
			
            FROM dbo.rlmbgrpl
            WHERE member_id = @t_sub_id AND
            group_id = @t_group_id AND
            plan_id = @t_plan_id AND
				(eff_gr_pl <= @t_action_date AND
				(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
            ORDER BY 2 DESC,3;
                            OPEN @SWV_cursor_var5;
                            FETCH NEXT FROM @SWV_cursor_var5 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    GOTO SWL_Label17;
                                    FETCH NEXT FROM @SWV_cursor_var5 INTO @d_mb_gr_pl_id,
                                        @d_eff_gr_pl, @d_exp_gr_pl;
                                END;
     SWL_Label17:
                            CLOSE @SWV_cursor_var5;
                            IF ( @d_mb_gr_pl_id IS NULL )
							BEGIN
							SET @n_return_code=466
                                RAISERROR('Dependent PA with no active subscriber''s group/plan',16,1);
							END
		
                          
         IF ( @d_eff_gr_pl > @t_action_date )
                                SET @n_new_eff_date = @d_eff_gr_pl;
         ELSE
                                BEGIN
                                   
                                    SET @n_new_eff_date = @t_action_date;
                                END;
		
                            IF EXISTS ( SELECT  *
                                      FROM    dbo.rlplfc (NOLOCK)
                                        WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                                AND member_id = @t_member_id
                                                AND ( ( eff_date <= @t_action_date
                                                        AND ( exp_date > @t_action_date
                                                              OR exp_date IS NULL
           )
                                                      )
                                                      OR ( eff_date > @t_action_date
                    AND ( exp_date > eff_date
                         OR exp_date IS NULL
                                                              )
                                                         )
                                                    ) )
													BEGIN
												SET @n_return_code=468	
                                RAISERROR('Dependent PA with active facility',16,1);
								END
		
                     
                            IF @n_has_facility_id = 'Y'
                                IF @n_ffs_plan = 0
                                    BEGIN
			   --CH001
   EXECUTE dlp_fc_count @d_mb_gr_pl_id,
             @t_tl_sir_id, @n_new_eff_date,
@SWV_dlp_fc_count OUTPUT;
                                        IF @SWV_dlp_fc_count < 0
										BEGIN
										SET @n_return_code=469
                                            RAISERROR('Maximum facility count exceeded for subscriber'' rate code',                     16,1);
											END
        END;
			
		
                           
                            SET @n_msi = @n_msi + 1;

							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                            
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=510
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
		
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @t_member_id ,
                                      @t_facility_id ,
                                      @n_new_eff_date ,
                                      @t_action_code ,
                                      @t_action_code ,
                                      @n_msi ,
                                      @n_datetime ,
                                      @ls_user
                                    );
		
                           
                            EXECUTE dbo.mb_add_cat @d_mb_gr_pl_id,
                                @t_member_id, @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                    + ':' + @n_error_desc;
										SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                       END;
		
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;
                          
             EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
   BEGIN
                   SET @n_error_desc = CAST(-746 AS VARCHAR)
						+ ':' + @n_error_desc;
							SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                                END;
		
                           
           IF @t_plan_term_date IS NOT NULL
                                BEGIN
                                   
                                    IF @t_plan_term_date < @n_new_eff_date
									BEGIN
									SET @n_return_code=470
                        RAISERROR('New dependent with termination date before plan''s effective date',              16,1);
						END
			
                                    UPDATE  dbo.rlplfc
                                    SET     exp_date = @t_plan_term_date ,
                      action_code = 'MT' ,
                                            h_action = action_code ,
                                        h_user = @ls_user ,
                                 h_datetime = @n_datetime
                                    WHERE   h_msi = @n_msi;
                             
                                    EXECUTE dbo.dlp_elig_actv_log 'MB',
                                        'temenu_2', @t_member_id,@created_by;
          END;
  END;
          END;

           
            IF @t_action_code = 'RI'
                BEGIN
      
                    IF @t_subscriber = '00'
                        BEGIN
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @t_member_id
                                                AND group_id = @t_group_id
                                                AND plan_id = @t_plan_id
                                                AND ( eff_gr_pl <= @t_action_date
                                                      AND ( exp_gr_pl > @t_action_date
                                                            OR exp_gr_pl IS NULL
                                                          )
                                                    ) )
													BEGIN
													SET @n_return_code=448
                                RAISERROR('RI with active subscriber''s group/plan',16,1);
								END
		
                           
                            SET @n_msi = @n_msi + 1;
							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                            
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=510
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
		
                            INSERT  INTO dbo.rlmbgrpl
                                    ( member_id ,
        group_id ,
                                      plan_id ,
                                      sub_in_plan ,
                                      eff_gr_pl ,
                                      action_code ,
                                      h_action ,
         h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @t_sub_id ,
                              @t_group_id ,
                                      @t_plan_id ,
                                      @t_sub_in_plan ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @t_action_code ,
                                      @n_msi ,
                                      @n_datetime ,
                                      @ls_user
                                    );
		
                            SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl (NOLOCK)
                            WHERE   h_msi = @n_msi;
          
                            IF ( @d_mb_gr_pl_id IS NULL )
							BEGIN
							SET @n_return_code=446
                                RAISERROR('DB failed to retireve inserted Group/Plan',16,1);
							END
		
                            INSERT  INTO dbo.rlmbrt
                                    ( mb_gr_pl_id ,
                                      rate_code ,
                                      eff_rt_date ,
                               action_code ,
                                      h_action ,
                                      h_msi ,
              h_datetime ,
                            h_user
                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @t_rate_code ,
           @t_action_date ,
                                      @t_action_code ,
                                      @t_action_code ,
                                      @n_msi ,
                                      @n_datetime ,
                                      @ls_user
  );
		
                      INSERT  INTO dbo.rlplfc
                        ( mb_gr_pl_id ,
                             member_id ,
               facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @t_member_id ,
                                      @t_facility_id ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @t_action_code ,
                                      @n_msi ,
                                      @n_datetime ,
                                      @ls_user
                                    );
	
                           
                            EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id,
                                @t_member_id, 'N', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
										SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                                END;
	
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;
                           
                            EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                          BEGIN
                   SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
										SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                                END;

-- log subscriber Plan add

                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_6',
                                @t_sub_id,@created_by;
                       END;
                    ELSE -- Not subscriber 
                        BEGIN
                            IF NOT EXISTS ( SELECT  *
        FROM    dbo.member (NOLOCK)
 WHERE   member_id = @t_member_id )
 BEGIN
 SET @n_return_code=461
                                RAISERROR('RI with no existing member record',16,1);
							END
		
          SET @d_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var6 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl, h_msi
			
            FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @t_sub_id AND
            group_id = @t_group_id AND
            plan_id = @t_plan_id AND
				(eff_gr_pl <= @t_action_date AND
				(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
          ORDER BY 2 DESC,3;
                            OPEN @SWV_cursor_var6;
    FETCH NEXT FROM @SWV_cursor_var6 INTO @d_mb_gr_pl_id,
                   @d_eff_gr_pl, @d_exp_gr_pl, @n_dep_msi;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    GOTO SWL_Label18;
                                    FETCH NEXT FROM @SWV_cursor_var6 INTO @d_mb_gr_pl_id,
                                        @d_eff_gr_pl, @d_exp_gr_pl, @n_dep_msi;
 END;
                            SWL_Label18:
                            CLOSE @SWV_cursor_var6;
                            IF ( @d_mb_gr_pl_id IS NULL )
							BEGIN
							SET @n_return_code=466
                                RAISERROR('Dependent RI with no active subscriber''s group/plan',16,1);
							END		
                          
                            IF ( @d_eff_gr_pl > @t_action_date )
                                SET @n_new_eff_date = @d_eff_gr_pl;
                            ELSE
                                BEGIN
                                   
                                    SET @n_new_eff_date = @t_action_date;
                                END;
		
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.rlplfc (NOLOCK)
                                        WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                                AND member_id = @t_member_id
                                                AND ( ( eff_date <= @t_action_date
                                                        AND ( exp_date > @t_action_date
                                                              OR exp_date IS NULL
                                                            )
                                                      )
                                                      OR ( eff_date > @t_action_date
                                                           AND ( exp_date > eff_date
                                                              OR exp_date IS NULL
                                                              )
   )
                                                    ) )
													BEGIN
													SET @n_return_code=468
                                RAISERROR('Dependent RI with active facility',16,1);
							END
		
                           
                            IF @n_has_facility_id = 'Y'
    IF @n_ffs_plan = 0
                                    BEGIN
			   --CH001
                                        EXECUTE dlp_fc_count @d_mb_gr_pl_id,
                                            @t_tl_sir_id, @n_new_eff_date,
                                      @SWV_dlp_fc_count OUTPUT;
                                        IF @SWV_dlp_fc_count < 0
										BEGIN
										SET @n_return_code=469
                                            RAISERROR('Maximum facility count exceeded for subscriber'' rate code',                     16,1);
											END
                                    END;
			
		

-- 20120213$$ks - Dependent reinstate needs to use subs msi
		--LET n_msi = n_msi + 1;
                           
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=510
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
		
INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
        member_id ,
                                      facility_id ,
                                      eff_date ,
                  action_code ,
                                      h_action ,
                                      h_msi ,
                         h_datetime ,
      h_user
                                   )
                            VALUES  ( @d_mb_gr_pl_id ,
       @t_member_id ,
                                      @t_facility_id ,
                         @n_new_eff_date ,
                                      @t_action_code ,
                   @t_action_code ,
          @n_dep_msi ,
                                      @n_datetime ,
                                      @ls_user
                                    );
		
                          
                            EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id,
 @t_member_id, 'N', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                      BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
										SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                                END;
		
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;

									
                        
                            EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
										SET @n_return_code=520
                                    RAISERROR(@n_error_desc,16,1);
                                END;
		
                            
                            IF @t_plan_term_date IS NOT NULL
                                BEGIN
                                  
                                    IF @t_plan_term_date < @n_new_eff_date
									BEGIN
									SET @n_return_code=470
                                        RAISERROR('New dependent with termination date before plan''s effective date',                  16,1);
										END
			
                                    UPDATE  dbo.rlplfc
                                    SET     exp_date = @t_plan_term_date ,
                                            action_code = 'MT' ,
              h_action = action_code ,
                                            h_user = @ls_user ,
                                            h_datetime = @n_datetime
                                    WHERE   h_msi = @n_msi;

                                    EXECUTE dbo.dlp_elig_actv_log 'MB',
                                        'temenu_2', @t_member_id,@created_by;
                                END;
                        END;
                END;

            IF @t_action_code = 'FX'
                BEGIN
                    SET @d_mb_gr_pl_id = NULL;
                    SET @SWV_cursor_var7 = CURSOR  FOR SELECT eff_gr_pl, exp_gr_pl, mb_gr_pl_id
		
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id  = @t_sub_id AND
         group_id = @t_group_id AND
         plan_id = @t_plan_id AND
        eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
         ORDER BY eff_gr_pl DESC;
                    OPEN @SWV_cursor_var7;
                    FETCH NEXT FROM @SWV_cursor_var7 INTO @d_eff_gr_pl,
                        @d_exp_gr_pl, @d_mb_gr_pl_id;
                    WHILE @@FETCH_STATUS = 0
          BEGIN
                            GOTO SWL_Label19;
                          FETCH NEXT FROM @SWV_cursor_var7 INTO @d_eff_gr_pl,
                                @d_exp_gr_pl, @d_mb_gr_pl_id;
                        END;
                    SWL_Label19:
                    CLOSE @SWV_cursor_var7;
                    IF ( @d_mb_gr_pl_id IS NULL )
					BEGIN
					SET @n_return_code=600
                        RAISERROR('Member doesn''t have active mb_gr_pl_id.',16,1);
					END
	
                  IF @d_exp_gr_pl IS NOT NULL
				  BEGIN
				  SET @n_return_code=603
    RAISERROR('Subscriber already expired',16,1);
END
	

            SET @r_facility_id = NULL;
           SET @SWV_cursor_var8 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date
		
  FROM dbo.rlplfc (NOLOCK)
         WHERE member_id  = @t_member_id AND
         mb_gr_pl_id = @d_mb_gr_pl_id  AND
         eff_date <= @t_action_date AND
			(exp_date > @t_action_date OR exp_date IS NULL)
         ORDER BY eff_date DESC;
                    OPEN @SWV_cursor_var8;
                    FETCH NEXT FROM @SWV_cursor_var8 INTO @li_rlplfc_id,
                        @r_facility_id, @d_eff_date;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label20;
                            FETCH NEXT FROM @SWV_cursor_var8 INTO @li_rlplfc_id,
                                @r_facility_id, @d_eff_date;
                        END;
                    SWL_Label20:
   CLOSE @SWV_cursor_var8;
                    IF ( @r_facility_id IS NULL )
					BEGIN
					SET @n_return_code=601
                        RAISERROR('Member doesn''t have active group/plan',16,1);
					END
	
                    
                    IF ( @r_facility_id = @t_facility_id )
					BEGIN
					SET @n_return_code=602
                        RAISERROR('Member current facility_id is the same as the one needed to change to.',16,1);
					END
	
                   
                    SET @n_msi = @n_msi + 1;

					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                    
                    IF @n_msi > @msi_upper
					BEGIN
					SET @n_return_code=510
                        RAISERROR('msi number exceeded the maximum located number',16,1);
					END
	
                    UPDATE  dbo.rlplfc
                    SET     exp_date = @t_action_date ,
                            action_code = 'FU' ,
                 h_msi = @n_msi ,
                            h_action = action_code ,
                            h_user = @ls_user ,
                            h_datetime = GETDATE()
                    WHERE rlplfc_id = @li_rlplfc_id;
                   
                    SET @n_msi = @n_msi + 1;

					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                   
                    IF @n_msi > @msi_upper
					BEGIN
					SET @n_return_code=510
                        RAISERROR('msi number exceeded the maximum located number',16,1);
					END
	
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @t_member_id ,
                              @t_facility_id ,
                              @t_action_date ,
                              'FU' ,
                            @n_datetime ,
                              @n_msi ,
                              'FU' ,
         @ls_user
                 );
		
                    SELECT  @li_rlplfc_id = rlplfc_id
                    FROM    dbo.rlplfc (NOLOCK)
 WHERE   h_msi = @n_msi
                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                            AND member_id = @t_member_id;
                    
                    EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id, @li_rlplfc_id,
                        'Y', @n_error_code OUTPUT, @n_error_desc OUTPUT;
                    IF ( @n_error_code < 0 )
                        BEGIN
          SET @n_error_desc = CAST(-746 AS VARCHAR) + ':'
                                + @n_error_desc;
								SET @n_return_code=520
             RAISERROR(@n_error_desc,16,1);
     END;

                EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_2',
                        @t_member_id,@created_by;
                END;

            
     IF @t_action_code = 'PC'
                BEGIN

                    IF ( @t_subscriber IS NULL
                         OR @t_subscriber = ''
                       )
					   BEGIN
					   SET @n_return_code=530
                        RAISERROR('Member Flag value is null, action - PC.',16,1);
					END
  
                   
                    IF @t_action_date IS NULL
					BEGIN
					SET @n_return_code=531
                        RAISERROR('Action Date is null, action - PC.',16,1);
					END
  
                   
                    IF ( @t_action_code IS NULL
                         OR @t_action_code = ''
                       )
					   BEGIN
					   SET @n_return_code=532
                        RAISERROR('Action Date is null, action - PC.',16,1);
					END
  
                    
                    IF @t_member_id IS NULL
					BEGIN
					SET @n_return_code=533
                        RAISERROR('Member Id is null, action - PC.',16,1);
					END
  
                  
                    IF @t_subscriber = '00'
                        BEGIN
                           
                            IF @t_sub_id IS NULL
							BEGIN
							SET @n_return_code=535
                                RAISERROR('Subscriber Id is null, action - PC.',16,1);
							END
	
                           
                            IF @t_group_id IS NULL
							BEGIN
							SET @n_return_code=536
                                RAISERROR('Group Id is null, action - PC.',16,1);
							END
	
                          
                            IF @t_plan_id IS NULL
							BEGIN
							SET @n_return_code=537
                                RAISERROR('Plan Id is null, action - PC.',16,1);
							END
	
                           
                            IF ( @t_rate_code IS NULL
            OR @t_rate_code = ''
                               )
							   BEGIN
							   SET @n_return_code=538
                                RAISERROR('Rate Code is null, action - PC.',16,1);
							END
	
                           
                            IF @t_plan_eff_date IS NULL
							BEGIN
							SET @n_return_code=539
                                RAISERROR('Plan Effective Date is null, action - PC.',16,1);
							END
	
                            SET @li_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var9 = CURSOR  FOR SELECT eff_gr_pl, mb_gr_pl_id
		
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @t_sub_id AND
			eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
            ORDER BY eff_gr_pl DESC;
                            OPEN @SWV_cursor_var9;
                            FETCH NEXT FROM @SWV_cursor_var9 INTO @d_eff_gr_pl,
                                @li_mb_gr_pl_id;
                            WHILE @@FETCH_STATUS = 0
            BEGIN
                                    GOTO SWL_Label21;
                        FETCH NEXT FROM @SWV_cursor_var9 INTO @d_eff_gr_pl,
                                        @li_mb_gr_pl_id;
                  END;
      SWL_Label21:
                            CLOSE @SWV_cursor_var9;
                            IF @li_mb_gr_pl_id IS NULL
							BEGIN
							SET @n_return_code=540
                                RAISERROR('Subscriber doesn''t have active plan, action - PC',16,1);
							END
	
                            SET @li_rlmbrt_id = NULL;
                            SET @SWV_cursor_var10 = CURSOR FOR SELECT eff_rt_date, rlmbrt_id
		
  FROM dbo.rlmbrt (NOLOCK)
            WHERE mb_gr_pl_id = @li_mb_gr_pl_id AND
            eff_rt_date <= @t_action_date AND
			(exp_rt_date > @t_action_date OR exp_rt_date IS NULL)
            ORDER BY eff_rt_date DESC;
               OPEN @SWV_cursor_var10;
     FETCH NEXT FROM @SWV_cursor_var10 INTO @d_eff_rt_date,
                            @li_rlmbrt_id;
             WHILE @@FETCH_STATUS = 0
                            BEGIN
           GOTO SWL_Label22;
                                    FETCH NEXT FROM @SWV_cursor_var10 INTO @d_eff_rt_date,
                                        @li_rlmbrt_id;
                                END;
                            SWL_Label22:
                          CLOSE @SWV_cursor_var10;
                            IF @li_rlmbrt_id IS NULL
							BEGIN
							SET @n_return_code=542
                 RAISERROR('Subscriber doesn''t have active rate_code, action - PC',16,               1);
				 END
	
                           
                            SET @n_msi = @n_msi + 1;
							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                            
							IF @n_msi > @msi_upper
						BEGIN
						SET @n_return_code=543
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
	
                            UPDATE  dbo.rlmbgrpl
                            SET     exp_gr_pl = @t_action_date ,
                                    action_code = @t_action_code ,
                                    h_msi = @n_msi ,
                                    h_datetime = @n_datetime ,
                                    h_action = action_code ,
                                    h_user = @ls_user
                            WHERE   mb_gr_pl_id = @li_mb_gr_pl_id;
                            
                            SET @n_msi = @n_msi + 1;

							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
                            
                            IF @n_msi > @msi_upper
							BEGIN
							SET @n_return_code=543
                                RAISERROR('msi number exceeded the maximum located number',16,1);
							END
	
                            INSERT  INTO dbo.rlmbgrpl
                                    ( member_id ,
                                      group_id ,
                                      plan_id ,
sub_in_plan ,
                                      eff_gr_pl ,
                                      action_code ,
                                      h_datetime ,
                                      h_msi ,
                                      h_action ,
                                      h_user
                                    )
                            VALUES  ( @t_member_id ,
                                      @t_group_id ,
                                      @t_plan_id ,
                                      @t_sub_in_plan ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
  @n_msi ,
                                      @t_action_code ,
       @ls_user
                                    );
	 
                            SELECT  @li_new_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl (NOLOCK)
                            WHERE   member_id = @t_member_id
                                    AND group_id = @t_group_id
         AND plan_id = @t_plan_id
                                    AND eff_gr_pl = @t_action_date
                                    AND action_code = @t_action_code;
                           
                            IF @li_new_mb_gr_pl_id IS NULL
                                RAISERROR('Could not get the new mb_gr_pl_id, action - PC',16,1);
	
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
        member_id ,
                              facility_id ,
                                      eff_date ,
             action_code ,
                                      h_datetime ,
    h_msi ,
       h_action ,
       h_user
                                    )
                   VALUES  ( @li_new_mb_gr_pl_id ,
                                      @t_member_id ,
         @t_facility_id ,
                                      @t_action_date ,
                                @t_action_code ,
                                      @n_datetime ,
                                      @n_msi ,
                                      @t_action_code ,
                                      @ls_user
                         );
	
                            INSERT  INTO dbo.rlmbrt
                                    ( mb_gr_pl_id ,
                                      rate_code ,
      eff_rt_date ,
                                      action_code ,
                                      h_datetime ,
                                      h_msi ,
                                      h_action ,
                                      h_user
                                    )
                            VALUES  ( @li_new_mb_gr_pl_id ,
                                      @t_rate_code ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
                                      @n_msi ,
                                      @t_action_code ,
                                      @ls_user
                                    );
		
                            
                            EXECUTE dbo.mb_add_cat @li_new_mb_gr_pl_id,
                                @t_member_id, @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                 + ':' + @n_error_desc;
                                    RAISERROR(@n_error_desc,16,1);
                                END;
		
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
  WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;
                           
                            EXECUTE dbo.tiered_benefit @li_new_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
                                 RAISERROR(@n_error_desc,16,1);
                                END;
		
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_3',
                 @t_sub_id,@created_by;
                        END;
                    ELSE
                        BEGIN
                            SET @li_mb_gr_pl_id = NULL;
                     SET @SWV_cursor_var11 = CURSOR  FOR SELECT eff_gr_pl, h_msi, mb_gr_pl_id
			
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @t_sub_id AND
            group_id = @t_group_id AND
            plan_id = @t_plan_id AND
            eff_gr_pl <= @t_action_date AND
				(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
            ORDER BY eff_gr_pl DESC;
                            OPEN @SWV_cursor_var11;
              FETCH NEXT FROM @SWV_cursor_var11 INTO @d_eff_gr_pl,
                                @n_dep_msi, @li_mb_gr_pl_id;
                WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    GOTO SWL_Label23;
                     FETCH NEXT FROM @SWV_cursor_var11 INTO @d_eff_gr_pl,
     @n_dep_msi, @li_mb_gr_pl_id;
                                END;
                            SWL_Label23:
                            CLOSE @SWV_cursor_var11;
                            IF @li_mb_gr_pl_id IS NULL
                                RAISERROR('can''t retrieve valid group plan, action - PC',16,1);
		
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                  facility_id ,
                                      eff_date ,
            action_code ,
                                      h_datetime ,
                                      h_msi ,
                                      h_action ,
                                      h_user
                                    )
                            VALUES  ( @li_mb_gr_pl_id ,
                                      @t_member_id ,
                                      @t_facility_id ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
                                      @n_dep_msi ,
                                      @t_action_code ,
                                      @ls_user
                                    );
		
                          
                            EXECUTE dbo.mb_add_cat @li_mb_gr_pl_id,
                                @t_member_id, @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
                                    RAISERROR(@n_error_desc,16,1);
                                END;
		
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                  AND member_id = @t_member_id;
                           
                            EXECUTE dbo.tiered_benefit @li_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
      RAISERROR(@n_error_desc,16,1);
                                END;
		
                           
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_3',
                                @t_sub_id,@created_by;
                        END;
                END;

         
            IF @t_action_code = 'GX'
                BEGIN
                   
                    IF ( @t_subscriber IS NULL
           OR @t_subscriber = ''
                       )
                        RAISERROR('Member Flag value is null, action - GX.',16,1);
 	 	

                    IF @t_action_date IS NULL
              RAISERROR('Action Date is null, action - GX.',16,1);
 	 	
      
                    IF ( @t_action_code IS NULL
         OR @t_action_code = ''
                       )
                        RAISERROR('Action Date is null, action - GX.',16,1);
 	 	
                   
                    IF @t_member_id IS NULL
                        RAISERROR('Member Id is null, action - GX.',16,1);
  	

  	--if t_facility_id is null then
		--	RAISE EXCEPTION -746, 564, "Facility Id is null, action - GX.";
  	--end if

             
                  IF @t_subscriber = '00'
                        BEGIN
          
             IF @t_sub_id IS NULL
                                RAISERROR('Subscriber Id is null, action - GX.',16,1);
			
                          
                            IF @t_group_id IS NULL
                                RAISERROR('Group Id is null, action - GX.',16,1);
		
                           
                            IF @t_plan_id IS NULL
                   RAISERROR('Plan Id is null, action - GX.',16,1);
		
                            
         IF ( @t_rate_code IS NULL
                                 OR @t_rate_code = ''
                               )
                                RAISERROR('Rate Code is null, action - GX.',16,1);
		
                          
                            SET @n_msi = @n_msi + 1;
                            
							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4

                            IF @n_msi > @msi_upper
                                RAISERROR('msi number exceeded the maximum located number',16,1);
		
                            INSERT  INTO dbo.rlmbgrpl
                                    ( member_id ,
                                      group_id ,
                                      plan_id ,
                                      sub_in_plan ,
                                      eff_gr_pl ,
                                      action_code ,
                                      h_datetime ,
                                      h_msi ,
                                      h_action ,
                                      h_user
                                    )
                VALUES  ( @t_member_id ,
                                      @t_group_id ,
                                      @t_plan_id ,
                                      @t_sub_in_plan ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
                                      @n_msi ,
                                      @t_action_code ,
                                      @ls_user
                                    );
	 		
                            SELECT  @li_new_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl (NOLOCK)
                            WHERE   member_id = @t_member_id
                                    AND group_id = @t_group_id
                                    AND plan_id = @t_plan_id
                                    AND eff_gr_pl = @t_action_date
                                    AND action_code = @t_action_code;
  
                            IF @li_new_mb_gr_pl_id IS NULL
                                RAISERROR('Could not get the new mb_gr_pl_id, action - GX',16,1);
			
                            INSERT  INTO dbo.rlplfc
                         ( mb_gr_pl_id ,
                  member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_datetime ,
                                      h_msi ,
                                      h_action ,
                   h_user
                                    )
                          VALUES  ( @li_new_mb_gr_pl_id ,
 @t_member_id ,
                                      @t_facility_id ,
                                      @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
 @n_msi ,
                                  @t_action_code ,
                                      @ls_user
                     );
			
                            INSERT  INTO dbo.rlmbrt
              ( mb_gr_pl_id ,
                    rate_code ,
       eff_rt_date ,
                                      action_code ,
            h_datetime ,
                                      h_msi ,
                                      h_action ,
                                      h_user
                                    )
                       VALUES  ( @li_new_mb_gr_pl_id ,
                                      @t_rate_code ,
           @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
                           @n_msi ,
                                      @t_action_code ,
                                      @ls_user
                                    );
			
                           
                            EXECUTE dbo.mb_add_cat @li_new_mb_gr_pl_id,
                                @t_member_id, @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
                                    RAISERROR(@n_error_desc,16,1);
                                END;
			   
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;
                          
                            EXECUTE dbo.tiered_benefit @li_new_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                     SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
                                    RAISERROR(@n_error_desc,16,1);
                                END;
				
                           
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_4',
                                @t_sub_id,@created_by;
                        END;
                    ELSE
                        BEGIN
                            SET @li_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var12 = CURSOR  FOR SELECT eff_gr_pl, h_msi, mb_gr_pl_id
				
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @t_sub_id AND
            group_id = @t_group_id AND
            plan_id = @t_plan_id AND
            eff_gr_pl <= @t_action_date AND
					(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
            ORDER BY eff_gr_pl DESC;
      OPEN @SWV_cursor_var12;
                            FETCH NEXT FROM @SWV_cursor_var12 INTO @d_eff_gr_pl,
                                @n_dep_msi, @li_mb_gr_pl_id;
                            WHILE @@FETCH_STATUS = 0
  BEGIN
                                    GOTO SWL_Label24;
                                    FETCH NEXT FROM @SWV_cursor_var12 INTO @d_eff_gr_pl,
                                        @n_dep_msi, @li_mb_gr_pl_id;
                                END;
                            SWL_Label24:
                            CLOSE @SWV_cursor_var12;
                            IF @li_mb_gr_pl_id IS NULL
                                RAISERROR('can''t retrieve valid group plan, action - GX',16,1);
			
                            INSERT  INTO dbo.rlplfc
                              ( mb_gr_pl_id ,
             member_id ,
            facility_id ,
                             eff_date ,
                             action_code ,
                                      h_datetime ,
     h_msi ,
                                      h_action ,
                                      h_user
        )
                            VALUES  ( @li_mb_gr_pl_id ,
                                      @t_member_id ,
                                      @t_facility_id ,
                       @t_action_date ,
                                      @t_action_code ,
                                      @n_datetime ,
                        @n_dep_msi ,
                                      @t_action_code ,
                                      @ls_user
                                    );
			
                           
                            EXECUTE dbo.mb_add_cat @li_mb_gr_pl_id,
                                @t_member_id, @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                                    SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
                                    RAISERROR(@n_error_desc,16,1);
                                END;
			
                            SELECT  @li_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc (NOLOCK)
                            WHERE   h_msi = @n_msi
                                    AND mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @t_member_id;
                           
                            EXECUTE dbo.tiered_benefit @li_mb_gr_pl_id,
                                @li_rlplfc_id, 'Y', @n_error_code OUTPUT,
                                @n_error_desc OUTPUT;
                            IF ( @n_error_code < 0 )
                                BEGIN
                             SET @n_error_desc = CAST(-746 AS VARCHAR)
                                        + ':' + @n_error_desc;
                                    RAISERROR(@n_error_desc,16,1);
                                END;
		
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_4',
                                @t_sub_id,@created_by;
                        END;
                END;
 

--trace off;

            RETURN 1;
        END TRY
        BEGIN CATCH
		
		IF ERROR_NUMBER()=50000
		EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id, @t_tl_sir_id, @n_return_code;

            RETURN -200;
        END CATCH;
        SET NOCOUNT OFF;

/*
Work request 20130901:  Enhancements for Health Care Reform.

On new global variable:  t_sub_in_plan.

This variable, t_sub_in_plan, is set to a value by reading table dls_elig in dlp_up_eligibility().
Also true for dlp_up_sg_member() (single group).

Variable t_sub_in_plan is then checked for validity and set to the default
of 1 if it was invalid.

Later, dlp_rlmbgrpl() is called.  It also has access to global variable t_sub_in_plan.
Procedure dlp_rlmbgrpl() had six places in its code where table rlmbgrpl is updated (these
are actually SQL insert statements).

Whenever an SQL insert is made to table rlmbgrpl, now variable t_sub_in_plan is a part of
the set of variables used in this SQL insert.
*/



--set debug file to "/tmp/dlp_rlmbgrpl.trc";
--trace on;

    END;