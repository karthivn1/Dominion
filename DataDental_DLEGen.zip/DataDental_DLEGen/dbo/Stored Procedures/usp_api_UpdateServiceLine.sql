﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROC [dbo].[usp_api_UpdateServiceLine] 
@ClaimID INT,@ServiceLineType ServiceLineType READONLY,@user nVarchar(20)='claimAPI'
AS
BEGIN
IF OBJECT_ID('tempdb..#tempServiceLineType') IS NOT NULL
    DROP TABLE #tempServiceLineType

IF OBJECT_ID('tempdb..#tempSvc') IS NOT NULL
    DROP TABLE #tempSvc

IF OBJECT_ID('tempdb..#FilteredSVC') IS NOT NULL
    DROP TABLE #FilteredSVC

Select Cast(SvcLineID as INT) as SvcLineID,IIF(len(SvcDate)>0,CONVERT(nvarchar(10), cast(SvcDate as date), 101),getdate())  as SvcDate,SvcSubmitted,SvcProcCode,
SvcTooth,SvcSurface,SvcQuad,SvcCobamt
INTO #tempServiceLineType 
From @ServiceLineType 

SELECT
	t.SvcLineID,t.SvcProcCode,@ClaimID AS ClaimID
	INTO #tempSvc
	FROM #tempServiceLineType t

IF EXISTS(SELECT SvcLineID FROM #tempSvc)
BEGIN
	SELECT DISTINCT t.SvcLineID,t.SvcProcCode,t.ClaimID,d.claim_d_id as db_claim_d_id,d.[status],d.d_proc_code AS db_proc_code,d.claim_id AS db_claim_id
			INTO #FilteredSVC
			FROM #tempSvc t
			--LEFT JOIN #tempClaim tc ON tc.ClaimID=t.claimId
			LEFT JOIN claim_d d ON d.claim_id =t.ClaimID AND d.claim_d_id=t.SvcLineID

			IF EXISTS(SELECT f.ClaimID FROM #FilteredSVC f)
			BEGIN
					IF EXISTS(SELECT f.SvcProcCode FROM #FilteredSVC f
					WHERE f.db_claim_id IS NULL)
					BEGIN
						RAISERROR ('No matching Service line found!',16,1);
					END

					IF EXISTS(SELECT * FROM #FilteredSVC f
					WHERE f.status<>'Open' OR f.SvcProcCode COLLATE SQL_Latin1_General_CP1_CI_AS <>f.db_proc_code)
					BEGIN
						RAISERROR ('Procedure code mismatch on service line',16,1);
					END

					IF EXISTS(Select cd.claim_d_id
					From #tempServiceLineType t
					join claim_d cd on cd.claim_d_id=t.SvcLineID)
					BEGIN

					--Select top 100 *
					Update c Set c.h_datetime = getDate(),c.h_user=@user
					From claim_h c
					Where c.claim_id=@ClaimID
	     
					--Select *
					Update cd Set cd.svc_beg=t.SvcDate,cd.submitted_amt=t.SvcSubmitted,h_user=@user
					From #tempServiceLineType t
					join claim_d cd on cd.claim_d_id=t.SvcLineID
					Where cd.[status]='Open'
					AND cd.d_proc_code=t.SvcProcCode
					--AND t.SvcDate is Not null 
					--AND len(t.SvcSubmitted)>0

					END

			END
			ELSE
			BEGIN
				RAISERROR ('No matching Service line found!',16,1);
			END
END
ELSE
BEGIN
  RAISERROR ('No matching Service line found!',16,1);
END

END