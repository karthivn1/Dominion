﻿CREATE PROCEDURE [dbo].[dlp_mbgrpl_info_sg]
    @a_group_id INT ,
    @a_plan_id INT ,
    @a_member_id INT ,
    @a_as_of_date DATE ,
    @a_future CHAR(1) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT ,
    @SWP_Ret_Value4 SMALLINT = NULL OUTPUT ,
    @SWP_Ret_Value5 DATE = NULL OUTPUT ,
    @SWP_Ret_Value6 DATE = NULL OUTPUT
    
AS
    BEGIN
	/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_group_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_eff_gr_pl DATE;
        DECLARE @n_exp_gr_pl DATE;
        DECLARE @n_count INT;
        DECLARE @n_mb_gr_pl_id INT;
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_sub_in_plan SMALLINT;
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;
        --DECLARE @SWV_cursor_var3 CURSOR;
        --DECLARE @SWV_cursor_var4 CURSOR;
        --DECLARE @SWV_cursor_var5 CURSOR;
        --DECLARE @SWV_cursor_var6 CURSOR;
        --DECLARE @SWV_cursor_var7 CURSOR;
        --DECLARE @SWV_cursor_var8 CURSOR;
        --DECLARE @SWV_cursor_var9 CURSOR;
        --DECLARE @SWV_cursor_var10 CURSOR;
        --DECLARE @SWV_cursor_var11 CURSOR;
        --DECLARE @SWV_cursor_var12 CURSOR;

        SET NOCOUNT ON;
        BEGIN TRY
            SET @n_count = 0;
            SET @n_group_id = NULL;
            SET @n_plan_id = NULL;
            SET @n_mb_gr_pl_id = NULL;
            SET @n_eff_gr_pl = NULL;
            SET @n_exp_gr_pl = NULL;
            SET @n_sub_in_plan = NULL;
            IF @a_future = 'Y'
                IF @a_group_id > 0
                    IF @a_plan_id > 0
                        BEGIN
                           /*
						    SET @SWV_cursor_var1 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			 
               FROM dbo.rlmbgrpl (NOLOCK)
               WHERE member_id = @a_member_id AND group_id = @a_group_id
               AND plan_id = @a_plan_id AND eff_gr_pl > @a_as_of_date
               AND (exp_gr_pl > eff_gr_pl OR exp_gr_pl IS NULL);
                            OPEN @SWV_cursor_var1;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @n_mb_gr_pl_id,
                                @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                @n_exp_gr_pl, @n_sub_in_plan;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @SWV_cursor_var1 TABLE
                                (
                                  id INT IDENTITY ,
                                  mb_gr_pl_id INT ,
                                  group_id INT ,
                                  plan_id INT ,
                                  eff_gr_pl DATE ,
                                  exp_gr_pl DATE ,
                                  sub_in_plan SMALLINT
                                );

                            INSERT  INTO @SWV_cursor_var1
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
					                )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                                            plan_id ,
                eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND group_id = @a_group_id
                                            AND plan_id = @a_plan_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            DECLARE @cur1_cnt INT ,
                                @cur1_i INT;

                            SET @cur1_i = 1;

					--Get the no. of records for the cursor
                            SELECT  @cur1_cnt = COUNT(1)
                            FROM    @SWV_cursor_var1;

                            WHILE ( @cur1_i <= @cur1_cnt )
                                BEGIN
                                    SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                            @n_group_id = group_id ,
                                            @n_plan_id = plan_id ,
                                            @n_eff_gr_pl = eff_gr_pl ,
                                            @n_exp_gr_pl = exp_gr_pl ,
                                            @n_sub_in_plan = sub_in_plan
                                    FROM    @SWV_cursor_var1
                                    WHERE   id = @cur1_i;

                                    SET @n_count = @n_count + 1;
                                    /*
									FETCH NEXT FROM @SWV_cursor_var1 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
										*/
                                    SET @cur1_i = @cur1_i + 1;
                                END;
                            --CLOSE @SWV_cursor_var1;
                        END;
                    ELSE
                        BEGIN
                            /*
							SET @SWV_cursor_var2 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
               FROM dbo.rlmbgrpl (NOLOCK)
               WHERE member_id = @a_member_id AND group_id = @a_group_id
               AND eff_gr_pl > @a_as_of_date
               AND (exp_gr_pl > eff_gr_pl OR exp_gr_pl IS NULL);
                            OPEN @SWV_cursor_var2;
                            FETCH NEXT FROM @SWV_cursor_var2 INTO @n_mb_gr_pl_id,
                                @n_group_id, @n_plan_id, @n_eff_gr_pl,
                        @n_exp_gr_pl, @n_sub_in_plan;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @SWV_cursor_var2 TABLE
                                (
                                  id INT IDENTITY ,
                                  mb_gr_pl_id INT ,
                                  group_id INT ,
                                  plan_id INT ,
                                  eff_gr_pl DATE ,
                                  exp_gr_pl DATE ,
                                  sub_in_plan SMALLINT
                                );

                            INSERT  INTO @SWV_cursor_var2
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
					                )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                    plan_id ,
                                    eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND group_id = @a_group_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            DECLARE @cur2_cnt INT ,
                                @cur2_i INT;

                            SET @cur2_i = 1;

					--Get the no. of records for the cursor
                            SELECT  @cur2_cnt = COUNT(1)
                            FROM    @SWV_cursor_var2;

                            WHILE ( @cur2_i <= @cur2_cnt )
                                BEGIN
                                    SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                            @n_group_id = group_id ,
                                            @n_plan_id = plan_id ,
                                            @n_eff_gr_pl = eff_gr_pl ,
                                            @n_exp_gr_pl = exp_gr_pl ,
                                            @n_sub_in_plan = sub_in_plan
                                    FROM    @SWV_cursor_var2
                                    WHERE   id = @cur2_i;

                                    SET @n_count = @n_count + 1;
                                    /*
									FETCH NEXT FROM @SWV_cursor_var2 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
										*/
                                    SET @cur2_i = @cur2_i + 1;
                                END;
                         --   CLOSE @SWV_cursor_var2;
                        END;
		
                ELSE
                    IF @a_plan_id > 0
                        BEGIN
                           /*
						   SET @SWV_cursor_var3 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id, eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @a_member_id AND plan_id = @a_plan_id
            AND eff_gr_pl > @a_as_of_date
            AND (exp_gr_pl > eff_gr_pl OR exp_gr_pl IS NULL);
                            OPEN @SWV_cursor_var3;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @n_mb_gr_pl_id,
                                @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                @n_exp_gr_pl, @n_sub_in_plan;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @SWV_cursor_var3 TABLE
                                (
                                  id INT IDENTITY ,
                                  mb_gr_pl_id INT ,
                                  group_id INT ,
                                  plan_id INT ,
                                  eff_gr_pl DATE ,
                                  exp_gr_pl DATE ,
                                  sub_in_plan SMALLINT
                                );

                            INSERT  INTO @SWV_cursor_var3
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
					                )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                          plan_id ,
                        eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                 AND plan_id = @a_plan_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            DECLARE @cur3_cnt INT ,
                                @cur3_i INT;

                            SET @cur3_i = 1;

					--Get the no. of records for the cursor
                            SELECT  @cur3_cnt = COUNT(1)
                            FROM    @SWV_cursor_var3;

                            WHILE ( @cur3_i <= @cur3_cnt )
                                BEGIN

                                    SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                            @n_group_id = group_id ,
                                            @n_plan_id = plan_id ,
                                            @n_eff_gr_pl = eff_gr_pl ,
                                            @n_exp_gr_pl = exp_gr_pl ,
                                            @n_sub_in_plan = sub_in_plan
                                    FROM    @SWV_cursor_var3
                                    WHERE   id = @cur3_i;

                                    SET @n_count = @n_count + 1;
                                   /*
								    FETCH NEXT FROM @SWV_cursor_var3 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
										*/
                                    SET @cur3_i = @cur3_i + 1;
                                END;
                           -- CLOSE @SWV_cursor_var3;
                        END;
                    ELSE
                        BEGIN
                            /*
							SET @SWV_cursor_var4 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @a_member_id AND eff_gr_pl > @a_as_of_date
            AND (exp_gr_pl > eff_gr_pl OR exp_gr_pl IS NULL);
                            OPEN @SWV_cursor_var4;
                            FETCH NEXT FROM @SWV_cursor_var4 INTO @n_mb_gr_pl_id,
                                @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                @n_exp_gr_pl, @n_sub_in_plan;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @SWV_cursor_var4 TABLE
                                (
                                  id INT IDENTITY ,
                                  mb_gr_pl_id INT ,
                                  group_id INT ,
                                  plan_id INT ,
                                  eff_gr_pl DATE ,
                                  exp_gr_pl DATE ,
                                  sub_in_plan SMALLINT
                                );

                            INSERT  INTO @SWV_cursor_var4
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
					                )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                                            plan_id ,
             eff_gr_pl ,
                                            exp_gr_pl ,
                                       sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND eff_gr_pl > @a_as_of_date
    AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            DECLARE @cur4_cnt INT ,
                                @cur4_i INT;

                            SET @cur4_i = 1;

					--Get the no. of records for the cursor
                            SELECT  @cur4_cnt = COUNT(1)
                            FROM    @SWV_cursor_var4;

                            WHILE ( @cur4_i <= @cur4_cnt )
                                BEGIN
                                    SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                            @n_group_id = group_id ,
                                            @n_plan_id = plan_id ,
                                            @n_eff_gr_pl = eff_gr_pl ,
                                            @n_exp_gr_pl = exp_gr_pl ,
                                            @n_sub_in_plan = sub_in_plan
                                    FROM    @SWV_cursor_var4
                                    WHERE   id = @cur4_i;

                                    SET @n_count = @n_count + 1;
                                   /*
								    FETCH NEXT FROM @SWV_cursor_var4 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
										*/
                                    SET @cur4_i = @cur4_i + 1;
                                END;
                            --CLOSE @SWV_cursor_var4;
                        END;
		
            ELSE
                IF @a_future = 'N'
                    IF @a_group_id > 0
                        IF @a_plan_id > 0
                            BEGIN
                                /*
								SET @SWV_cursor_var5 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
               FROM dbo.rlmbgrpl (NOLOCK)
               WHERE member_id = @a_member_id AND group_id = @a_group_id
               AND plan_id = @a_plan_id AND eff_gr_pl <= @a_as_of_date
               AND (exp_gr_pl > @a_as_of_date OR exp_gr_pl IS NULL);
                                OPEN @SWV_cursor_var5;
                                FETCH NEXT FROM @SWV_cursor_var5 INTO @n_mb_gr_pl_id,
                                    @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                    @n_exp_gr_pl, @n_sub_in_plan;
                                WHILE @@FETCH_STATUS = 0
								*/
                                DECLARE @SWV_cursor_var5 TABLE
                                    (
                                      id INT IDENTITY ,
                                      mb_gr_pl_id INT ,
                                      group_id INT ,
                                      plan_id INT ,
                                      eff_gr_pl DATE ,
                                      exp_gr_pl DATE ,
                                      sub_in_plan SMALLINT
                                    );

                                INSERT  INTO @SWV_cursor_var5
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
					                    )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                         plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                   WHERE   member_id = @a_member_id
                                                AND group_id = @a_group_id
                                                AND plan_id = @a_plan_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );
					

                                DECLARE @cur5_cnt INT ,
                                    @cur5_i INT;

                                SET @cur5_i = 1;

					--Get the no. of records for the cursor
                                SELECT  @cur5_cnt = COUNT(1)
                                FROM    @SWV_cursor_var5;

                                WHILE ( @cur5_i <= @cur5_cnt )
                                    BEGIN
                                        SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                @n_group_id = group_id ,
                                                @n_plan_id = plan_id ,
                                                @n_eff_gr_pl = eff_gr_pl ,
                                                @n_exp_gr_pl = exp_gr_pl ,
                                                @n_sub_in_plan = sub_in_plan
                                        FROM    @SWV_cursor_var5
                                        WHERE   id = @cur5_i;

                                        SET @n_count = @n_count + 1;
                                       /*
									   FETCH NEXT FROM @SWV_cursor_var5 INTO @n_mb_gr_pl_id,
                                            @n_group_id, @n_plan_id,
                                            @n_eff_gr_pl, @n_exp_gr_pl,
                                            @n_sub_in_plan;
											*/
                                        SET @cur5_i = @cur5_i + 1;
                                    END;
                                --CLOSE @SWV_cursor_var5;
                            END;
                        ELSE
                            BEGIN
                                /*
								SET @SWV_cursor_var6 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
               FROM dbo.rlmbgrpl (NOLOCK)
               WHERE member_id = @a_member_id AND group_id = @a_group_id
               AND eff_gr_pl <= @a_as_of_date
               AND (exp_gr_pl > @a_as_of_date OR exp_gr_pl IS NULL);
                                OPEN @SWV_cursor_var6;
                                FETCH NEXT FROM @SWV_cursor_var6 INTO @n_mb_gr_pl_id,
                                    @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                    @n_exp_gr_pl, @n_sub_in_plan;
                                WHILE @@FETCH_STATUS = 0
								*/
                                DECLARE @SWV_cursor_var6 TABLE
                                    (
                                      id INT IDENTITY ,
                                      mb_gr_pl_id INT ,
                                      group_id INT ,
                                      plan_id INT ,
                                      eff_gr_pl DATE ,
                                      exp_gr_pl DATE ,
                                      sub_in_plan SMALLINT
                                    );

                                INSERT  INTO @SWV_cursor_var6
            ( mb_gr_pl_id ,
                                          group_id ,
         plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
					                    )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                        plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND group_id = @a_group_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                DECLARE @cur6_cnt INT ,
                                    @cur6_i INT;

                                SET @cur6_i = 1;

					--Get the no. of records for the cursor
                                SELECT  @cur6_cnt = COUNT(1)
                                FROM    @SWV_cursor_var6;

                                WHILE ( @cur6_i <= @cur6_cnt )
                                    BEGIN
                                        SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                @n_group_id = group_id ,
                                                @n_plan_id = plan_id ,
                                                @n_eff_gr_pl = eff_gr_pl ,
                                                @n_exp_gr_pl = exp_gr_pl ,
                                                @n_sub_in_plan = sub_in_plan
                                        FROM    @SWV_cursor_var6
                                        WHERE   id = @cur6_i;

                                        SET @n_count = @n_count + 1;
                                       /*
									    FETCH NEXT FROM @SWV_cursor_var6 INTO @n_mb_gr_pl_id,
                                            @n_group_id, @n_plan_id,
                                            @n_eff_gr_pl, @n_exp_gr_pl,
                                            @n_sub_in_plan;
											*/
                                        SET @cur6_i = @cur6_i + 1;
                                    END;
                              --  CLOSE @SWV_cursor_var6;
                            END;
		
                    ELSE
                        IF @a_plan_id > 0
                            BEGIN
                                /*
								SET @SWV_cursor_var7 = CURSOR  FOR SELECT mb_gr_pl_id, group_id, plan_id, eff_gr_pl, exp_gr_pl,   sub_in_plan
			  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @a_member_id AND plan_id = @a_plan_id
            AND eff_gr_pl <= @a_as_of_date
            AND (exp_gr_pl > @a_as_of_date OR exp_gr_pl IS NULL);
                                OPEN @SWV_cursor_var7;
                                FETCH NEXT FROM @SWV_cursor_var7 INTO @n_mb_gr_pl_id,
                                    @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                    @n_exp_gr_pl, @n_sub_in_plan;
                                WHILE @@FETCH_STATUS = 0
								*/
                                DECLARE @SWV_cursor_var7 TABLE
                                    (
                                      id INT IDENTITY ,
                                      mb_gr_pl_id INT ,
                                      group_id INT ,
                                      plan_id INT ,
                                      eff_gr_pl DATE ,
                                      exp_gr_pl DATE ,
                                      sub_in_plan SMALLINT
                                    );

                                INSERT  INTO @SWV_cursor_var7
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                              eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
					                    )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                                plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND plan_id = @a_plan_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                DECLARE @cur7_cnt INT ,
                                    @cur7_i INT;

                                SET @cur7_i = 1;

					--Get the no. of records for the cursor
                                SELECT  @cur7_cnt = COUNT(1)
                                FROM    @SWV_cursor_var7;

                                WHILE ( @cur7_i <= @cur7_cnt )
                                    BEGIN

                                        SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                @n_group_id = group_id ,
                                                @n_plan_id = plan_id ,
                                                @n_eff_gr_pl = eff_gr_pl ,
                                                @n_exp_gr_pl = exp_gr_pl ,
                                                @n_sub_in_plan = sub_in_plan
                                        FROM    @SWV_cursor_var7
                                        WHERE   id = @cur7_i;

                                        SET @n_count = @n_count + 1;
                                       /*
									    FETCH NEXT FROM @SWV_cursor_var7 INTO @n_mb_gr_pl_id,
                                            @n_group_id, @n_plan_id,
                                            @n_eff_gr_pl, @n_exp_gr_pl,
                                            @n_sub_in_plan;
											*/
                                        SET @cur7_i = @cur7_i + 1;
                                    END;
                                --CLOSE @SWV_cursor_var7;
                            END;
                        ELSE
                            BEGIN
                               /*
							    SET @SWV_cursor_var8 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @a_member_id AND eff_gr_pl <= @a_as_of_date
            AND (exp_gr_pl > @a_as_of_date OR exp_gr_pl IS NULL);
                                OPEN @SWV_cursor_var8;
                                FETCH NEXT FROM @SWV_cursor_var8 INTO @n_mb_gr_pl_id,
                                    @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                    @n_exp_gr_pl, @n_sub_in_plan;
                                WHILE @@FETCH_STATUS = 0
								*/
                                DECLARE @SWV_cursor_var8 TABLE
                        (
                                      id INT IDENTITY ,
                                      mb_gr_pl_id INT ,
                                      group_id INT ,
                                      plan_id INT ,
                                      eff_gr_pl DATE ,
                                      exp_gr_pl DATE ,
                                      sub_in_plan SMALLINT
                                    );

                      INSERT  INTO @SWV_cursor_var8
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
					                    )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                                plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                DECLARE @cur8_cnt INT ,
                                    @cur8_i INT;

                                SET @cur8_i = 1;

					--Get the no. of records for the cursor
                                SELECT  @cur8_cnt = COUNT(1)
                                FROM    @SWV_cursor_var8;

                                WHILE ( @cur8_i <= @cur8_cnt )
                                    BEGIN
                                        SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                @n_group_id = group_id ,
                                                @n_plan_id = plan_id ,
                                                @n_eff_gr_pl = eff_gr_pl ,
                                                @n_exp_gr_pl = exp_gr_pl ,
                                                @n_sub_in_plan = sub_in_plan
                                        FROM    @SWV_cursor_var8
                                        WHERE   id = @cur8_i;

                                        SET @n_count = @n_count + 1;
                                        /*
										FETCH NEXT FROM @SWV_cursor_var8 INTO @n_mb_gr_pl_id,
                                            @n_group_id, @n_plan_id,
                                            @n_eff_gr_pl, @n_exp_gr_pl,
                                            @n_sub_in_plan;
											*/
                                        SET @cur8_i = @cur8_i + 1;
                                    END;
                                --CLOSE @SWV_cursor_var8;
                            END;
		
                ELSE
                    IF @a_future = 'E'
                        IF @a_group_id > 0
                            IF @a_plan_id > 0
                                BEGIN
                                  /*
								    SET @SWV_cursor_var9 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
               FROM dbo.rlmbgrpl (NOLOCK)
               WHERE member_id = @a_member_id AND group_id = @a_group_id
               AND plan_id = @a_plan_id AND eff_gr_pl <= @a_as_of_date
               AND (exp_gr_pl IS NOT NULL AND eff_gr_pl = exp_gr_pl);
                                    OPEN @SWV_cursor_var9;
                                    FETCH NEXT FROM @SWV_cursor_var9 INTO @n_mb_gr_pl_id,
       @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                    DECLARE @SWV_cursor_var9 TABLE
                                        (
                                          id INT IDENTITY ,
                              mb_gr_pl_id INT ,
                                          group_id INT ,
                                          plan_id INT ,
                                          eff_gr_pl DATE ,
                                          exp_gr_pl DATE ,
                                          sub_in_plan SMALLINT
                                        );

                                    INSERT  INTO @SWV_cursor_var9
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
					                        )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND group_id = @a_group_id
                                                    AND plan_id = @a_plan_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );
					

                                    DECLARE @cur9_cnt INT ,
                                        @cur9_i INT;

                                    SET @cur9_i = 1;

					--Get the no. of records for the cursor
                                    SELECT  @cur9_cnt = COUNT(1)
                                    FROM    @SWV_cursor_var9;

                                    WHILE ( @cur9_i <= @cur9_cnt )
                                        BEGIN
                                            SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                    @n_group_id = group_id ,
                                                    @n_plan_id = plan_id ,
                                                    @n_eff_gr_pl = eff_gr_pl ,
                                                    @n_exp_gr_pl = exp_gr_pl ,
                                                    @n_sub_in_plan = sub_in_plan
                                            FROM    @SWV_cursor_var9
                                            WHERE   id = @cur9_i;
                                            SET @n_count = @n_count + 1;
                                            /*
											FETCH NEXT FROM @SWV_cursor_var9 INTO @n_mb_gr_pl_id,
                                                @n_group_id, @n_plan_id,
                                                @n_eff_gr_pl, @n_exp_gr_pl,
                                                @n_sub_in_plan;
												*/
                                            SET @cur9_i = @cur9_i + 1;
                                        END;
                         -- CLOSE @SWV_cursor_var9;
                                END;
                            ELSE
                   BEGIN
                                   /*
								    SET @SWV_cursor_var10 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
               FROM dbo.rlmbgrpl (NOLOCK)
               WHERE member_id = @a_member_id AND group_id = @a_group_id
               AND eff_gr_pl <= @a_as_of_date
               AND (exp_gr_pl IS NOT NULL AND eff_gr_pl = exp_gr_pl);
                                    OPEN @SWV_cursor_var10;
                                    FETCH NEXT FROM @SWV_cursor_var10 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                    DECLARE @SWV_cursor_var10 TABLE
                                        (
                                          id INT IDENTITY ,
                                          mb_gr_pl_id INT ,
                                          group_id INT ,
                                          plan_id INT ,
                                          eff_gr_pl DATE ,
                                          exp_gr_pl DATE ,
                                          sub_in_plan SMALLINT
                                        );

                                    INSERT  INTO @SWV_cursor_var10
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
					                        )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND group_id = @a_group_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );

                                    DECLARE @cur10_cnt INT ,
                                        @cur10_i INT;

                                    SET @cur10_i = 1;

					--Get the no. of records for the cursor
                                    SELECT  @cur10_cnt = COUNT(1)
                                    FROM    @SWV_cursor_var10;

                                    WHILE ( @cur10_i <= @cur10_cnt )
                                        BEGIN
                                            SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                    @n_group_id = group_id ,
                                                    @n_plan_id = plan_id ,
                                                    @n_eff_gr_pl = eff_gr_pl ,
                                                    @n_exp_gr_pl = exp_gr_pl ,
                                                    @n_sub_in_plan = sub_in_plan
                                            FROM    @SWV_cursor_var10
                                            WHERE   id = @cur10_i;
                                            SET @n_count = @n_count + 1;
                                           /*
										   FETCH NEXT FROM @SWV_cursor_var10 INTO @n_mb_gr_pl_id,
                                                @n_group_id, @n_plan_id,
                                                @n_eff_gr_pl, @n_exp_gr_pl,
                                                @n_sub_in_plan;
												*/
                                            SET @cur10_i = @cur10_i + 1;
                     END;
                                   --CLOSE @SWV_cursor_var10;
                                END;
		
                        ELSE
                            IF @a_plan_id > 0
                                BEGIN
                                   /*
								    SET @SWV_cursor_var11 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @a_member_id AND plan_id = @a_plan_id
            AND eff_gr_pl <= @a_as_of_date
            AND (exp_gr_pl IS NOT NULL AND eff_gr_pl = exp_gr_pl);
                        OPEN @SWV_cursor_var11;
                                    FETCH NEXT FROM @SWV_cursor_var11 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                    DECLARE @SWV_cursor_var11 TABLE
                                        (
                                          id INT IDENTITY ,
                                          mb_gr_pl_id INT ,
                                          group_id INT ,
                                          plan_id INT ,
                                          eff_gr_pl DATE ,
                                          exp_gr_pl DATE ,
                                          sub_in_plan SMALLINT
                                        );

                                    INSERT  INTO @SWV_cursor_var11
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
					                        )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND plan_id = @a_plan_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );

                                    DECLARE @cur11_cnt INT ,
                                        @cur11_i INT;

                                    SET @cur11_i = 1;

					--Get the no. of records for the cursor
                                    SELECT  @cur11_cnt = COUNT(1)
                                    FROM    @SWV_cursor_var11;

                                    WHILE ( @cur11_i <= @cur11_cnt )
                                        BEGIN
                      SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                    @n_group_id = group_id ,
                                @n_plan_id = plan_id ,
                                                    @n_eff_gr_pl = eff_gr_pl ,
                                                    @n_exp_gr_pl = exp_gr_pl ,
                                                    @n_sub_in_plan = sub_in_plan
                                            FROM    @SWV_cursor_var11
   WHERE   id = @cur11_i;
                                            SET @n_count = @n_count + 1;
                                          /*
										    FETCH NEXT FROM @SWV_cursor_var11 INTO @n_mb_gr_pl_id,
                                                @n_group_id, @n_plan_id,
                                                @n_eff_gr_pl, @n_exp_gr_pl,
                                                @n_sub_in_plan;
												*/
                                            SET @cur11_i = @cur11_i + 1;
                                        END;
                                   -- CLOSE @SWV_cursor_var11;
                                END;
                            ELSE
                                BEGIN
                                   /*
								    SET @SWV_cursor_var12 = CURSOR  FOR SELECT mb_gr_pl_id,   group_id,   plan_id,   eff_gr_pl,   exp_gr_pl,   sub_in_plan
			  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE member_id = @a_member_id AND eff_gr_pl <= @a_as_of_date
            AND (exp_gr_pl IS NOT NULL  AND eff_gr_pl = exp_gr_pl);
                                    OPEN @SWV_cursor_var12;
                                    FETCH NEXT FROM @SWV_cursor_var12 INTO @n_mb_gr_pl_id,
                                        @n_group_id, @n_plan_id, @n_eff_gr_pl,
                                        @n_exp_gr_pl, @n_sub_in_plan;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                    DECLARE @SWV_cursor_var12 TABLE
                                        (
                                          id INT IDENTITY ,
                                          mb_gr_pl_id INT ,
                                          group_id INT ,
                                          plan_id INT ,
                                          eff_gr_pl DATE ,
                                          exp_gr_pl DATE ,
                                          sub_in_plan SMALLINT
                                        );

                                    INSERT  INTO @SWV_cursor_var12
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
					                        )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );

                                    DECLARE @cur12_cnt INT ,
                                        @cur12_i INT;

                                    SET @cur12_i = 1;

					--Get the no. of records for the cursor
                                    SELECT  @cur12_cnt = COUNT(1)
                                    FROM    @SWV_cursor_var12;

                                    WHILE ( @cur12_i <= @cur12_cnt )
                                        BEGIN

                                            SELECT  @n_mb_gr_pl_id = mb_gr_pl_id ,
                                                    @n_group_id = group_id ,
                                                    @n_plan_id = plan_id ,
                                                    @n_eff_gr_pl = eff_gr_pl ,
                                                    @n_exp_gr_pl = exp_gr_pl ,
                                                    @n_sub_in_plan = sub_in_plan
                                            FROM    @SWV_cursor_var12
                                            WHERE   id = @cur12_i;
                                            SET @n_count = @n_count + 1;
                                           /*
										    FETCH NEXT FROM @SWV_cursor_var12 INTO @n_mb_gr_pl_id,
                                                @n_group_id, @n_plan_id,
                                                @n_eff_gr_pl, @n_exp_gr_pl,
                                                @n_sub_in_plan;
												*/
                                            SET @cur12_i = @cur12_i + 1;
                                        END;
                                   --CLOSE @SWV_cursor_var12;
                                END;
		
	
            SET @SWP_Ret_Value = @n_count;
            SET @SWP_Ret_Value1 = @n_mb_gr_pl_id;
            SET @SWP_Ret_Value2 = @n_group_id;
            SET @SWP_Ret_Value3 = @n_plan_id;
            SET @SWP_Ret_Value4 = @n_sub_in_plan;
            SET @SWP_Ret_Value5 = @n_eff_gr_pl;
            SET @SWP_Ret_Value6 = @n_exp_gr_pl;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = NULL;
            SET @SWP_Ret_Value4 = NULL;
            SET @SWP_Ret_Value5 = NULL;
            SET @SWP_Ret_Value6 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;