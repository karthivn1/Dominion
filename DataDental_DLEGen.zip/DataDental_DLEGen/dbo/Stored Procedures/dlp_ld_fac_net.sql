﻿CREATE procedure [dbo].[dlp_ld_fac_net]
@a_batch_id INT ,
@a_db_name CHAR(128) ,
@a_start_time char(22)
as
begin

SET NOCOUNT ON;

	Declare @execution_id bigint
	Declare @max bigint
	Declare @ERRORMESSAGE varchar(8000)
    
	EXEC [SSISDB].[catalog].[create_execution] @package_name=N'pkgDL_FacilityNetworkEligibility.dtsx', @folder_name=N'DataLoad', @project_name=N'prjData_Load', @use32bitruntime=0, @execution_id=@execution_id OUTPUT --@reference_id=1 ,
 
	EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=30, @parameter_name=N'prBatchid', @parameter_value=@a_batch_id 
	EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=30, @parameter_name=N'prDB_Name', @parameter_value=@a_db_name 
	EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=30, @parameter_name=N'prstart_time', @parameter_value=@a_start_time 

	EXEC [SSISDB].[catalog].[start_execution] @execution_id 

	DECLARE @status AS BIGINT = 1;
		WHILE(@status = 1 OR @status = 2 OR @status = 5 OR @status= 8)
		BEGIN
		
		WAITFOR DELAY '00:00:1';

		SET @status = (SELECT [Status] FROM SSISDB.[catalog].[executions] (NOLOCK)
				WHERE execution_id = @execution_id);
		END
		
	SELECT @max = max(activity_log_id)
	FROM up_ssis_activity_log (NOLOCK)
	WHERE batch_id = @a_batch_id

	

	IF NOT EXISTS (SELECT 'x'
			FROM up_ssis_activity_log (NOLOCK)
			WHERE batch_id		= @a_batch_id
			AND exec_status		= 'Completed'
			AND activity_log_id	= @max)
			BEGIN
			
				SELECT  @ERRORMESSAGE = SUBSTRING(error_desc,CHARINDEX('~',error_desc)+1,len(error_desc)-(CHARINDEX('~',REVERSE(error_desc))+CHARINDEX('~',error_desc)))
				FROM up_ssis_activity_log (NOLOCK)
				WHERE batch_id		= @a_batch_id
				AND activity_log_id	= @max

				RAISERROR(@ERRORMESSAGE,16,1)
				RETURN

			END
	SET NOCOUNT OFF; 
end