﻿CREATE PROCEDURE [dbo].[dlp_elig_sub_term]
@a_batch_id INT ,
@n_load_period DATE

-- DATE: 12/13/96
-- Modification: support multi_group and multi_plan
-- on 07/21/2000 by ameeta If the subscriber exist in dls_elig (source is "F" or "A") then do not add
AS
BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:11:11 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






　
　
　
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
DECLARE @n_error_no INT;
DECLARE @n_isam_error INT;
DECLARE @n_error_text CHAR(64);
DECLARE @i_temp_del_sub INT;
DECLARE @i_fatal INT;
DECLARE @n_in_transaction CHAR(1);
DECLARE @n_count INT;
DECLARE @n_tmp_name CHAR(2);
DECLARE @n_fatal INT;
DECLARE @n_mb_gr_pl_id INT;
DECLARE @n_parent_group_id INT;
DECLARE @n_tl_sir_id INT;
DECLARE @n_tl_sub_sir_id INT;
DECLARE @n_subscriber CHAR(1);
DECLARE @n_alt_id CHAR(20);
DECLARE @n_sub_ssn CHAR(11);
DECLARE @n_ssn CHAR(11);
DECLARE @n_sub_alt_id CHAR(20);
DECLARE @n_member_id INT;
DECLARE @n_sub_id INT;
DECLARE @n_group_id INT;
DECLARE @n_member_code CHAR(3);
DECLARE @n_plan_id INT;
DECLARE @n_facility_id INT;
DECLARE @n_key CHAR(2);
DECLARE @n_type CHAR(2);
DECLARE @n_last_name CHAR(15);
DECLARE @n_first_name CHAR(15);
DECLARE @n_middle_init CHAR(1);
DECLARE @n_date_of_birth DATE;
DECLARE @n_student_flag CHAR(1);
DECLARE @n_disable_flag CHAR(1);
DECLARE @n_cobra_flag CHAR(1);
DECLARE @n_action_code CHAR(2);
DECLARE @n_rate_code CHAR(2);
DECLARE @n_plan_eff_date DATE;
DECLARE @n_plan_term_date DATE;
DECLARE @n_rate_eff_date DATE;
DECLARE @n_sub_sir_id INT;
DECLARE @n_fac_eff_date DATE;
DECLARE @n_tmp_sub CHAR(1);
DECLARE @n_tmp_dep CHAR(1);
DECLARE @n_sir_count INT;
DECLARE @n_to_commit INT;
DECLARE @kkk INT;
DECLARE @new_dls_sir_id INT;
DECLARE @n_process_count INT;
DECLARE @n_succ_count INT;
DECLARE @i_sp_id INT;
DECLARE @i_sir_def_id INT;
--DECLARE @SWV_cursor_var1 CURSOR;
--DECLARE @SWV_cursor_var2 CURSOR;
--DECLARE @SWV_cursor_var3 CURSOR;
SET NOCOUNT ON;
SET @new_dls_sir_id =0;
--SET @n_process_count =0;
SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3
--SET @n_succ_count =0;
SET @i_sp_id =0;
SET @i_sir_def_id =0;
BEGIN TRY

SET @n_tmp_sub = 'N';
SET @n_tmp_dep = 'N';
SET @n_to_commit = 40;
/*commented by ameeta why we want to delete all the records which are inserted in dls_elig for group transfer, plan change, etc.
BEGIN WORK;
LET n_in_transaction = "Y";
　
FIX: WEE 02/04/2000: to skip delete records with
dls_source = "A" which has group transfer info
SELECT dls_sub_sir_id from dls_elig
WHERE dls_batch_id = a_batch_id and
member_flag = "00" and
dls_action_code = "GX"
into TEMP no_delete_gx_sir;
foreach select dls_sub_sir_id into kkk from no_delete_gx_sir
end foreach;
Foreach select dls_sir_id into i_temp_del_sub
from dls_elig
where dls_batch_id = a_batch_id and
member_flag = "00" and
dls_source = "A"
delete from dl_log_error where
config_bat_id = a_batch_id and
sir_def_id = i_sir_def_id and
sp_id = i_sp_id and
dls_sir_id in (
select dls_sir_id from
dls_elig where dls_batch_id = a_batch_id
and dls_sub_sir_id = i_temp_del_sub and
dls_source = "A" and
member_flag != "00");
DELETE FROM dl_action WHERE batch_id = a_batch_id and
dls_sir_id in (select dls_sir_id
from dls_elig
WHERE dls_batch_id = a_batch_id
and member_flag != "00" and
dls_source = "A" and
dls_sub_sir_id = i_temp_del_sub);
DELETE FROM DLS_ELIG
WHERE dls_batch_id = a_batch_id
and member_flag != "00" and
dls_source = "A" and
dls_sub_sir_id = i_temp_del_sub;
END FOREACH;
DELETE FROM dl_action WHERE batch_id = a_batch_id and
dls_sir_id in (SELECT dls_sir_id from dls_elig 
where dls_batch_id = a_batch_id and
member_flag = "00" and
dls_source = "A" and dls_sub_sir_id not in (select
dls_sub_sir_id from no_delete_gx_sir));
DELETE FROM dls_elig
WHERE dls_batch_id = a_batch_id and
member_flag = "00" and
dls_source = "A" and
dls_sub_sir_id not in (select
dls_sub_sir_id from no_delete_gx_sir);
COMMIT WORK;
*/
SET @n_in_transaction = 'N';
BEGIN TRAN;
-- assume existing members must have a member_id in tl_sir already
--CREATE TABLE #t_tape_sub (sub_ssn CHAR(11),last_name CHAR(15) ,dls_member_id int ,dls_group_id int,dls_plan_id int)
--INSERT INTO #t_tape_sub (sub_ssn ,last_name ,dls_member_id ,dls_group_id ,dls_plan_id)
SELECT DISTINCT
sub_ssn ,
last_name ,
dls_member_id ,
dls_group_id ,
dls_plan_id
INTO #t_tape_sub
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND member_flag = '00';
-- AND dls_source = "F"
CREATE INDEX t_tape_sub_dx1
ON #t_tape_sub 
(sub_ssn, 
last_name);
COMMIT; 
SET @n_tmp_sub = 'Y';
SET @n_sir_count = 0;
BEGIN TRAN;
SET @n_in_transaction = 'Y';

/*SET @SWV_cursor_var1 = CURSOR FOR SELECT DISTINCT group_id, plan_id
FROM dbo.dlsp_eg_group_plan (NOLOCK)
WHERE config_id IN(SELECT config_id
FROM dbo.dl_config_bat (NOLOCK)
WHERE config_bat_id = @a_batch_id);
OPEN @SWV_cursor_var1;
FETCH NEXT FROM @SWV_cursor_var1 INTO @n_group_id, @n_plan_id;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var1 TABLE
(
	id INT IDENTITY ,
	group_id INT, plan_id INT
)
INSERT  INTO @SWV_cursor_var1
( 
	group_id, plan_id
)
SELECT DISTINCT group_id, plan_id
FROM dbo.dlsp_eg_group_plan (NOLOCK)
WHERE config_id IN(SELECT config_id
FROM dbo.dl_config_bat (NOLOCK)
WHERE config_bat_id = @a_batch_id)

DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;
					
					
WHILE ( @cur_i <= @cur1_cnt )
BEGIN

SELECT @n_group_id=group_id, @n_plan_id=plan_id
FROM @SWV_cursor_var1
Where id = @cur_i
/*commented by ameeta why we want to termenate dependents when sub is terminated
FOREACH WITH HOLD 
SELECT DISTINCT mb.member_ssn, mb.last_name, mb.first_name, 
mb.member_id, mb.family_id
INTO n_ssn, n_last_name, n_first_name, 
n_member_id, n_sub_id
FROM member mb, rlplfc rf
WHERE rf.mb_gr_pl_id = n_mb_gr_pl_id 
AND mb.member_id != mb.family_id
AND rf.member_id = mb.member_id
AND ((rf.eff_date <= n_load_period
AND (rf.exp_date > n_load_period OR rf.exp_date is NULL))
OR (rf.eff_date > n_load_period
AND (rf.exp_date > rf.eff_date OR rf.exp_date is NULL)))
IF n_sir_count >= n_to_commit THEN
COMMIT WORK;
LET n_sir_count = 0;
BEGIN WORK;
ELSE
LET n_sir_count = n_sir_count + 1;
END IF
LET n_process_count = n_process_count + 1;
SELECT count(*) into n_count
FROM member mb, rlplfc rf, rlmbgrpl rp
WHERE rf.mb_gr_pl_id = n_mb_gr_pl_id
AND rf.mb_gr_pl_id = rp.mb_gr_pl_id
AND mb.member_id = n_member_id
AND rf.member_id = n_member_id
AND mb.member_id != mb.family_id
AND rf.exp_date is NULL;
IF n_count > 1 THEN
INSERT INTO dls_elig
(dls_sir_id, dls_batch_id, dls_sub_sir_id, member_flag,
ssn, sub_ssn, last_name, first_name,
def_key, type,
dls_member_id, dls_sub_id, dls_action_code, dls_status,
dls_source)
VALUES (0, a_batch_id, n_sub_sir_id, "09", 
n_ssn, n_ssn, n_last_name, n_first_name,
"DF","DF", n_member_id, n_sub_id, "MT","E","A");
LET i_fatal = dl_log_error(a_batch_id, i_sp_id, i_sir_def_id,
new_dls_sir_id, 152);
CONTINUE FOREACH;
END IF; 
　
SELECT mb.member_ssn, mb.last_name, mb.first_name, mb.middle_init, 
mb.family_id, mb.alt_id, mb.member_code, 
mb.date_of_birth, mb.student_flag, mb.disable_flag, rp.cobra_flag, 
rf.eff_date, rf.exp_date, rf.eff_date,
rp.group_id, rp.plan_id, rf.facility_id
INTO n_ssn, n_last_name, n_first_name, n_middle_init, 
n_sub_id, n_alt_id, n_member_code,
n_date_of_birth, n_student_flag, n_disable_flag, n_cobra_flag,
n_plan_eff_date, n_plan_term_date, n_fac_eff_date,
n_group_id, n_plan_id, n_facility_id
FROM member mb, rlplfc rf, rlmbgrpl rp
WHERE rf.mb_gr_pl_id = n_mb_gr_pl_id
AND rf.mb_gr_pl_id = rp.mb_gr_pl_id
AND mb.member_id = n_member_id
AND rf.member_id = n_member_id
AND mb.member_id != mb.family_id
AND rf.exp_date is NULL;
IF n_plan_term_date is not null THEN
LET n_plan_term_date = n_load_period;
INSERT INTO dls_elig 
(dls_sir_id, dls_batch_id, member_flag, alt_id, 
ssn, sub_ssn, sub_alt_id, member_code, 
last_name, first_name, middle_init, 
date_of_birth, student_flag, disable_flag, cobra_flag,
plan_eff_date, plan_term_date, rate_eff_date, 
def_key, type,
dls_member_id, dls_sub_id, dls_action_code, dls_status, dls_source) 
VALUES (0, a_batch_id, "01", n_alt_id, 
n_ssn, n_ssn, n_alt_id, n_member_code,
n_last_name, n_first_name, n_middle_init,
n_date_of_birth, n_student_flag, n_disable_flag, n_cobra_flag,
n_plan_eff_date, n_plan_term_date, n_fac_eff_date, 
"DF", "DF",
n_member_id, n_sub_id, "MT", "E", "A");
UPDATE dls_elig
SET dls_sub_sir_id = n_sub_sir_id
WHERE dls_batch_id = a_batch_id
AND dls_sir_id = new_dls_sir_id;
--CALL tl_log_error(t_tl_sir_id, 153) RETURNING n_fatal;
--if n_fatal != 0 then
-- CONTINUE FOREACH;
--end if
END IF
IF n_plan_eff_date > n_load_period THEN
LET n_plan_term_date = n_plan_eff_date;
ELSE
LET n_plan_term_date = n_load_period;
END IF
INSERT INTO dls_elig
(dls_sir_id, dls_batch_id, dls_sub_sir_id, member_flag, alt_id, 
ssn, sub_ssn, sub_alt_id, member_code, 
last_name, first_name, middle_init, 
date_of_birth, student_flag, disable_flag, cobra_flag,
plan_eff_date, plan_term_date, 
dls_group_id, dls_plan_id, facility_id,
def_key, type,
dls_member_id, dls_sub_id, dls_action_code, dls_status, dls_source) 
VALUES (0, a_batch_id, n_sub_sir_id, "01", n_alt_id, 
n_ssn, n_sub_ssn, n_alt_id, n_member_code,
n_last_name, n_first_name, n_middle_init,
n_date_of_birth, n_student_flag, n_disable_flag, n_cobra_flag,
n_plan_eff_date, n_plan_term_date, 
n_group_id, n_plan_id, n_facility_id,
"DF", "DF",
n_member_id, n_sub_id, "MT", "P", "A");
LET n_error_no = dl_log_action(a_batch_id, new_dls_sir_id, "MT",
n_plan_term_date);
LET n_succ_count = n_succ_count + 1;
END FOREACH;
*/
/*SET @SWV_cursor_var2 = CURSOR FOR SELECT DISTINCT mb.member_ssn, mb.last_name, mb.first_name,
mb.member_id, mb.family_id, rp.mb_gr_pl_id,
rp.eff_gr_pl
FROM dbo.member mb (NOLOCK), dbo.rlmbgrpl rp (NOLOCK)
WHERE rp.group_id = @n_group_id
AND rp.plan_id = @n_plan_id
AND rp.member_id = mb.member_id
AND rp.exp_gr_pl IS NULL;
OPEN @SWV_cursor_var2;
FETCH NEXT FROM @SWV_cursor_var2 INTO @n_ssn, @n_last_name,
@n_first_name, @n_member_id, @n_sub_id, @n_mb_gr_pl_id,
@n_plan_eff_date;
WHILE @@FETCH_STATUS = 0
*/

IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL 
DROP TABLE #SWV_cursor_var2

create table #SWV_cursor_var2
(
id INT IDENTITY ,
 member_ssn char(11), last_name char(15), first_name char(15),
 member_id int, family_id int, mb_gr_pl_id int, eff_gr_pl date
)
INSERT  INTO #SWV_cursor_var2
( 
	 member_ssn, last_name, first_name,
 member_id, family_id, mb_gr_pl_id, eff_gr_pl
)
SELECT DISTINCT mb.member_ssn, mb.last_name, mb.first_name,
mb.member_id, mb.family_id, rp.mb_gr_pl_id,
rp.eff_gr_pl
FROM dbo.member mb (NOLOCK), dbo.rlmbgrpl rp (NOLOCK)
WHERE rp.group_id = @n_group_id
AND rp.plan_id = @n_plan_id
AND rp.member_id = mb.member_id
AND rp.exp_gr_pl IS NULL;

DECLARE @cur2_cnt INT ,
                @cur2_i INT;

            SET @cur2_i = 1;

					
            SELECT  @cur2_cnt = COUNT(1)
            FROM    #SWV_cursor_var2;
					
					
            WHILE ( @cur2_i <= @cur2_cnt )
BEGIN
select @n_ssn=member_ssn, @n_last_name=last_name, @n_first_name=first_name,
 @n_member_id=member_id, @n_sub_id=family_id, @n_mb_gr_pl_id=mb_gr_pl_id, @n_plan_eff_date=eff_gr_pl
from #SWV_cursor_var2 where id = @cur2_i


IF EXISTS ( SELECT *
FROM #t_tape_sub
WHERE sub_ssn = @n_ssn
AND last_name = @n_last_name )
GOTO SWL_Label3;
SELECT @n_ssn = mb.member_ssn ,
@n_last_name = mb.last_name ,
@n_first_name = mb.first_name ,
@n_middle_init = mb.middle_init ,
@n_sub_id = mb.family_id ,
@n_alt_id = mb.alt_id ,
@n_member_code = mb.member_code ,
@n_date_of_birth = mb.date_of_birth ,
@n_student_flag = mb.student_flag ,
@n_disable_flag = mb.disable_flag
FROM dbo.member mb ( NOLOCK )
WHERE mb.member_id = @n_member_id;
-- add foreach, just in case multiple facilities
SET @n_plan_eff_date = NULL;

/*SET @SWV_cursor_var3 = CURSOR FOR SELECT rp.cobra_flag, rt.rate_code, rp.eff_gr_pl, rp.exp_gr_pl,
rt.eff_rt_date, rf.facility_id
FROM dbo.rlmbgrpl rp (NOLOCK), dbo.rlmbrt rt (NOLOCK), dbo.rlplfc rf (NOLOCK)
WHERE rf.member_id = @n_member_id
AND rp.mb_gr_pl_id = @n_mb_gr_pl_id
AND rt.mb_gr_pl_id = @n_mb_gr_pl_id
AND rf.mb_gr_pl_id = @n_mb_gr_pl_id
AND rp.exp_gr_pl IS NULL
AND rt.exp_rt_date IS NULL
AND rf.exp_date IS NULL;
OPEN @SWV_cursor_var3;
FETCH NEXT FROM @SWV_cursor_var3 INTO @n_cobra_flag,
@n_rate_code, @n_plan_eff_date,
@n_plan_term_date, @n_rate_eff_date,
@n_facility_id;
WHILE @@FETCH_STATUS = 0
*/

IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL 
DROP TABLE #SWV_cursor_var3

create table #SWV_cursor_var3
(
id INT IDENTITY ,
cobra_flag char(1), rate_code char(2), eff_gr_pl date, exp_gr_pl date,
eff_rt_date date, facility_id int
)
INSERT  INTO #SWV_cursor_var3
( 
cobra_flag, rate_code, eff_gr_pl, exp_gr_pl,
eff_rt_date, facility_id
)
SELECT rp.cobra_flag, rt.rate_code, rp.eff_gr_pl, rp.exp_gr_pl,
rt.eff_rt_date, rf.facility_id
FROM dbo.rlmbgrpl rp (NOLOCK), dbo.rlmbrt rt (NOLOCK), dbo.rlplfc rf (NOLOCK)
WHERE rf.member_id = @n_member_id
AND rp.mb_gr_pl_id = @n_mb_gr_pl_id
AND rt.mb_gr_pl_id = @n_mb_gr_pl_id
AND rf.mb_gr_pl_id = @n_mb_gr_pl_id
AND rp.exp_gr_pl IS NULL
AND rt.exp_rt_date IS NULL
AND rf.exp_date IS NULL;

DECLARE @cur3_cnt INT ,
                @cur3_i INT;

            SET @cur3_i = 1;

					
            SELECT  @cur3_cnt = COUNT(1)
            FROM    #SWV_cursor_var3;
					
					
            WHILE ( @cur3_i <= @cur3_cnt )
BEGIN
select @n_cobra_flag=cobra_flag, @n_rate_code=rate_code,  @n_plan_eff_date=eff_gr_pl, @n_plan_term_date=exp_gr_pl,
			@n_rate_eff_date=eff_rt_date, @n_facility_id=facility_id
from #SWV_cursor_var3 where id = @cur3_i

GOTO SWL_Label4;
--FETCH NEXT FROM @SWV_cursor_var3 INTO @n_cobra_flag,
--@n_rate_code, @n_plan_eff_date,
--@n_plan_term_date, @n_rate_eff_date,
--@n_facility_id;
set @cur3_i=@cur3_i+1
END;
SWL_Label4:
--CLOSE @SWV_cursor_var3;
IF @n_plan_eff_date IS NULL
GOTO SWL_Label3;
IF @n_plan_eff_date > @n_load_period
BEGIN
GOTO SWL_Label3;
SET @n_plan_term_date = @n_plan_eff_date;
END;
ELSE
SET @n_plan_term_date = @n_load_period;
BEGIN
INSERT INTO dbo.dls_elig
( dls_batch_id ,
member_flag ,
alt_id ,
ssn ,
sub_ssn ,
sub_alt_id ,
member_code ,
last_name ,
first_name ,
middle_init ,
date_of_birth ,
student_flag ,
disable_flag ,
cobra_flag ,
rate_code ,
plan_eff_date ,
plan_term_date ,
facility_eff_date ,
dls_group_id ,
dls_plan_id ,
facility_id ,
def_key ,
type ,
dls_member_id ,
dls_sub_id ,
dls_action_code ,
dls_status ,
dls_source
)
VALUES ( @a_batch_id ,
'00' ,
@n_alt_id ,
@n_ssn ,
@n_ssn ,
@n_alt_id ,
@n_member_code ,
@n_last_name ,
@n_first_name ,
@n_middle_init ,
@n_date_of_birth ,
@n_student_flag ,
@n_disable_flag ,
@n_cobra_flag ,
@n_rate_code ,
@n_plan_eff_date ,
@n_plan_term_date ,
@n_plan_eff_date ,
@n_group_id ,
@n_plan_id ,
@n_facility_id ,
'DF' ,
'DF' ,
@n_member_id ,
@n_member_id ,
'ST' ,
'P' ,
'A'
);
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@new_dls_sir_id, 'ST', @n_plan_term_date;
UPDATE dbo.dls_elig
SET dls_sub_sir_id = @new_dls_sir_id
WHERE dls_batch_id = @a_batch_id
AND dls_sir_id = @new_dls_sir_id;
END;
SET @n_sub_sir_id = @new_dls_sir_id;

SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_process_count = @n_process_count + 1;

UPDATE GlobalVar
SET VarValue = @n_process_count
WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_succ_count = @n_succ_count + 1;

UPDATE GlobalVar
SET VarValue = @n_succ_count
WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_sub_ssn = @n_ssn;
SET @n_sir_count = @n_sir_count + 1;
IF @n_sir_count >= @n_to_commit
BEGIN
COMMIT; 
BEGIN TRAN;
SET @n_sir_count = 0;
END;
SWL_Label3:
--FETCH NEXT FROM @SWV_cursor_var2 INTO @n_ssn,
--@n_last_name, @n_first_name, @n_member_id,
--@n_sub_id, @n_mb_gr_pl_id, @n_plan_eff_date;
set @cur2_i = @cur2_i +1
END;
--CLOSE @SWV_cursor_var2;
--FETCH NEXT FROM @SWV_cursor_var1 INTO @n_group_id,
--@n_plan_id;
	set @cur_i = @cur_i +1
END;
--CLOSE @SWV_cursor_var1;
DROP TABLE #t_tape_sub;
--DROP TABLE no_delete_gx_sir;
SET @n_tmp_sub = 'N';
COMMIT; 
--trace off;
RETURN 1;
END TRY
BEGIN CATCH
SET @n_error_no = ERROR_NUMBER();
SET @n_isam_error = ERROR_LINE();
SET @n_error_text = ERROR_MESSAGE();
IF @n_tmp_sub = 'Y'
DROP TABLE #t_tape_sub;
IF @n_in_transaction = 'Y'
ROLLBACK; 
RETURN -1;
END CATCH;
SET NOCOUNT OFF;
　
--set debug file to "/tmp/dlp_elig_sub_term.trc";
--trace on;
--set explain on;
END;