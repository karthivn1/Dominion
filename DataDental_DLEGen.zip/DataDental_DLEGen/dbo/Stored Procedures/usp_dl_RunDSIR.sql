﻿

CREATE PROC [dbo].[usp_dl_RunDSIR]
@P_BATCH_ID INT,@P_SIR_ID INT,@P_SIR_DEF_ID INT
AS
BEGIN
	declare @SpName varchar(20),
	@ReturnValue INT ,
	@ReturnMessage VARCHAR(MAX) ,
	@CurrentTime VARCHAR(25)

	BEGIN TRY
	SET @CurrentTime = FORMAT(GETDATE() , 'yyyy-MM-dd HH:mm:ss:ff');
		DELETE FROM dl_action  
		WHERE ( dl_action.batch_id = @P_BATCH_ID ) AND  
			( dl_action.dls_sir_id = @P_SIR_ID ) AND  
			( dl_action.process_status = 'N' )

		SELECT  @SpName = 'dlp_'+dl_sp.sp_name  
		FROM dl_cfg_bat_det, dl_sp  
		WHERE ( dl_cfg_bat_det.sp_id = dl_sp.sp_id ) and  
				 ( ( dl_cfg_bat_det.config_bat_id = @P_BATCH_ID ) AND  
				   ( dl_cfg_bat_det.sir_def = @P_SIR_DEF_ID ) AND  
				   ( dl_sp.sp_type = 'BU' ) )

		EXEC @SpName @P_BATCH_ID,@P_SIR_ID,@CurrentTime,@ReturnValue OUTPUT,@ReturnMessage OUTPUT

		SELECT  @P_BATCH_ID AS BatchId, 
			@ReturnValue AS ReturnValue,
			@ReturnMessage AS ReturnMessage

	END TRY
	BEGIN CATCH
		SET @ReturnValue =-1;
		SET @ReturnMessage = ERROR_MESSAGE();
		SELECT  @P_BATCH_ID AS BatchId, 
			@ReturnValue AS ReturnValue,
			@ReturnMessage AS ReturnMessage
	END CATCH
END