﻿--drop proc usp_dl_Savedlsutilization
CREATE PROCEDURE [dbo].[usp_dl_Savedlsutilization] (@dlsUtilization dbo.DlsUtilization READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_utilization 
					   SET dls_batch_id = dut.dls_batch_id
						  ,dls_utilization.dls_status = 
						  CASE WHEN dut.dls_status='E' OR dut.dls_status='P' THEN 'V'
								ELSE dls_utilization.dls_status END
						  --,dls_source = dut.dls_source
						  ,alt_id = dut.alt_id
						  ,document_no = dut.document_no
						  ,patient_id = dut.patient_id
						  ,subscriber_id = dut.subscriber_id
						  ,group_id = dut.group_id
						  ,plan_id = dut.plan_id
						  ,ins_type = dut.ins_type
						  ,pcp_id = dut.pcp_id
						  ,fc_id = dut.fc_id
						  ,prv_id = dut.prv_id
						  ,x_rays_rqd = dut.x_rays_rqd
						  ,returned_date = dut.returned_date
						  ,received_date = dut.received_date
						  ,preauth_switch = dut.preauth_switch
						  ,emergency_switch = dut.emergency_switch
						  ,pay_prv_switch = dut.pay_prv_switch
						  ,pv_state = dut.pv_state
						  ,first_name = dut.first_name
						  ,middle_init = dut.middle_init
						  ,last_name = dut.last_name
						  ,tax_id = dut.tax_id
						  ,addr1 = dut.addr1
						  ,addr2 = dut.addr2
						  ,city = dut.city
						  ,country = dut.country
						  ,county = dut.county
						  ,state = dut.state
						  ,zip = dut.zip
						  ,type = dut.type
						  ,speciality_type = dut.speciality_type
						  ,svc_beg = dut.svc_beg
						  ,d_proc_code = dut.d_proc_code
						  ,tooth_no = dut.tooth_no
						  ,surface = dut.surface
						  ,quad = dut.quad
						  ,cob_amt = dut.cob_amt
						  ,submitted_amt = dut.submitted_amt
						  --,dls_rlplfc_id = dut.dls_rlplfc_id
						  --,dls_mb_gr_pl_id = dut.dls_mb_gr_pl_id
						  --,dls_fc_id = dut.dls_fc_id
						  --,dls_prv_id = dut.dls_prv_id
						  --,dls_relates_to = dut.dls_relates_to
				from @dlsUtilization dut
				WHERE dls_utilization.dls_sir_id = dut.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END