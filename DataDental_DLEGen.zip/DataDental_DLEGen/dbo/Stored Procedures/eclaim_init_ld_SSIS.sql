﻿CREATE PROCEDURE [dbo].[eclaim_init_ld_SSIS]
    @FileName VARCHAR(50) ,
    @a_db_name CHAR(8)
    
AS
    BEGIN
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @RunStr CHAR(1250);
        DECLARE @RunStr1 CHAR(250);
        DECLARE @RunStr2 CHAR(250);
        DECLARE @RunStr3 CHAR(250);
        DECLARE @RunStr4 CHAR(250);
        DECLARE @RunStr5 CHAR(250);
        DECLARE @HCnt INT;
        DECLARE @DCnt INT;
        DECLARE @DT DATETIME2(0);
        DECLARE @TD DATE;
        DECLARE @i_isam_error INT;
        DECLARE @eClaimID INT;
        DECLARE @ALTID CHAR(20);
        DECLARE @DocNo CHAR(15);
        DECLARE @STAT INT;
        DECLARE @ErrCode CHAR(10);
        DECLARE @PreAuth CHAR(1);
        DECLARE @Emerg CHAR(1);
        DECLARE @PVNPID CHAR(10);
        DECLARE @PVALTID CHAR(20);
        DECLARE @PVFName CHAR(20);
        DECLARE @PVMI CHAR(1);
        DECLARE @PVLName CHAR(30);
        DECLARE @PVTaxID CHAR(9);
        DECLARE @PVAddr1 CHAR(30);
        DECLARE @PVAddr2 CHAR(30);
        DECLARE @PVCity CHAR(20);
        DECLARE @PVState CHAR(2);
        DECLARE @PVZIP CHAR(10);
        DECLARE @PVCountry CHAR(3);
        DECLARE @PVLicState CHAR(2);
        DECLARE @PVID CHAR(20);
        DECLARE @PaySw CHAR(1);
        DECLARE @FCName CHAR(50);
        DECLARE @FCNPID CHAR(10);
        DECLARE @FCAltID CHAR(20);
        DECLARE @FCID CHAR(20);
        DECLARE @PatFName CHAR(20);
        DECLARE @PatMI CHAR(1);
        DECLARE @PatLName CHAR(30);
        DECLARE @PatTaxID CHAR(11);
        DECLARE @PatALTID CHAR(20);
        DECLARE @PatSrcID CHAR(20);
        DECLARE @PatAddr1 CHAR(30);
        DECLARE @PatAddr2 CHAR(30);
        DECLARE @PatCity CHAR(20);
        DECLARE @PatState CHAR(2);
        DECLARE @PatZIP CHAR(10);
        DECLARE @PatCountry CHAR(3);
        DECLARE @PatID CHAR(20);
        DECLARE @PCPName CHAR(50);
        DECLARE @PCPNPID CHAR(10);
        DECLARE @PCPAltID CHAR(20);
        DECLARE @PCPID CHAR(20);
        DECLARE @SubFName CHAR(20);
        DECLARE @SubMI CHAR(1);
        DECLARE @SubLName CHAR(30);
        DECLARE @SubTaxID CHAR(11);
        DECLARE @SubALTID CHAR(20);
        DECLARE @SubSrcID CHAR(20);
        DECLARE @SubAddr1 CHAR(30);
        DECLARE @SubAddr2 CHAR(30);
        DECLARE @SubCity CHAR(20);
        DECLARE @SubState CHAR(2);
        DECLARE @SubZIP CHAR(10);
        DECLARE @SubCountry CHAR(3);
        DECLARE @SubID CHAR(20);
        DECLARE @GrpAltID CHAR(20);
        DECLARE @GrpName CHAR(50);
        DECLARE @GRPID CHAR(20);
        DECLARE @PlanName CHAR(30);
        DECLARE @PlanID CHAR(20);
        DECLARE @InsType CHAR(1);
        DECLARE @PlanType CHAR(3);
        DECLARE @XRays CHAR(1);
        DECLARE @ReceivedDate CHAR(10);
        DECLARE @SpecDeal CHAR(1);
        DECLARE @ClaimType CHAR(2);
        DECLARE @SpecType CHAR(2);
        DECLARE @sRemarks VARCHAR(100);
        DECLARE @UD1 CHAR(15);
        DECLARE @UD2 CHAR(15);
        DECLARE @UD3 CHAR(15);
        DECLARE @UD4 CHAR(15);
        DECLARE @UD5 VARCHAR(100);
        DECLARE @ConfigName VARCHAR(50);
        DECLARE @LinkNo INT;
        DECLARE @SWV_cursor_var1 CURSOR;
---------------exception Handling ------------------------
        SET NOCOUNT ON;
        SET @DT = GETDATE(); 
        SET @TD = CONVERT(DATE, @DT); 
        SELECT  @HCnt = COUNT(*)
        FROM    dbo.t_eclaim_h;
        IF @HCnt < 1
            BEGIN
              -- RAISERROR('~Records were not uploaded into eClaims~',16,1);
			   RAISERROR('~Error in uploading new claim file,~',16,1);
                RETURN;
            END;
        SELECT  @DCnt = COUNT(*)
        FROM    dbo.t_eclaim_d (NOLOCK);
        IF @DCnt < 1
            BEGIN
               -- RAISERROR( '~Detail Records were not uploaded into t_eclaim_d table~',16,1);
			    RAISERROR('~Error in uploading new claim file,~',16,1);
                RETURN;
            END;
IF EXISTS ( SELECT  *
                    FROM    dbo.eclaim_h e ( NOLOCK ) ,
                            dbo.t_eclaim_h t ( NOLOCK )
                    WHERE   e.alt_id = t.alt_id )
            BEGIN
                RAISERROR('~Claim(s) in this file have same Alt ID as in the eclaim_h table~',16,1);
                RETURN;
            END;
-- put default values in where not provided and field does not allow null.
        UPDATE  dbo.t_eclaim_h
        SET     status = 0
        WHERE   status IS NULL;

        UPDATE  dbo.t_eclaim_d
        SET     error_code = 'OK'
        WHERE   ( error_code IS NULL
                  OR error_code = ''
                );
-- Display rows loaded.
--- Insert data into e_claim_h
        /*
		SET @SWV_cursor_var1 = CURSOR FOR SELECT alt_id, document_no, status, error_code, preauth_switch,
emergency_switch, pv_np_id, pv_alt_id, pv_f_name, pv_mi,
pv_l_name, pv_tax_id, pv_addr1, pv_addr2, pv_city, pv_state,
pv_zip, pv_country, pv_lic_state, pv_id, pay_prv_switch,
contr_fc_name, contr_fc_np_id, contr_fc_alt_id, contr_fc_id,
pat_f_name, pat_mi, pat_l_name, pat_tax_id, pat_alt_id, pat_source_id,
pat_addr1, pat_addr2, pat_city, pat_state, pat_zip, pat_country,
patient_id, pcp_name, pcp_np_id, pcp_alt_id, pcp_id, sub_f_name,
sub_mi, sub_l_name, sub_tax_id, sub_alt_id, sub_source_id,
sub_addr1, sub_addr2, sub_city, sub_state, sub_zip, sub_country,
subscriber_id, group_alt_id, group_name, group_id, plan_dsp_name,
plan_id, ins_type, plan_type, x_rays_rqd, received_date,
special_deal_flg, hmo_claim_type, speciality_type, link, remarks,
ud_1, ud_2, ud_3, ud_4, ud_5, config_name
FROM dbo.t_eclaim_h (NOLOCK);
        OPEN @SWV_cursor_var1;
        FETCH NEXT FROM @SWV_cursor_var1 INTO @ALTID, @DocNo, @STAT, @ErrCode,
            @PreAuth, @Emerg, @PVNPID, @PVALTID, @PVFName, @PVMI, @PVLName,
            @PVTaxID, @PVAddr1, @PVAddr2, @PVCity, @PVState, @PVZIP,
            @PVCountry, @PVLicState, @PVID, @PaySw, @FCName, @FCNPID, @FCAltID,
            @FCID, @PatFName, @PatMI, @PatLName, @PatTaxID, @PatALTID,
            @PatSrcID, @PatAddr1, @PatAddr2, @PatCity, @PatState, @PatZIP,
            @PatCountry, @PatID, @PCPName, @PCPNPID, @PCPAltID, @PCPID,
            @SubFName, @SubMI, @SubLName, @SubTaxID, @SubALTID, @SubSrcID,
            @SubAddr1, @SubAddr2, @SubCity, @SubState, @SubZIP, @SubCountry,
            @SubID, @GrpAltID, @GrpName, @GRPID, @PlanName, @PlanID, @InsType,
            @PlanType, @XRays, @ReceivedDate, @SpecDeal, @ClaimType, @SpecType,
            @LinkNo, @sRemarks, @UD1, @UD2, @UD3, @UD4, @UD5, @ConfigName;
        WHILE @@FETCH_STATUS = 0
            BEGIN
                INSERT  INTO dbo.eclaim_h
                        ( alt_id ,
                          document_no ,
                          status ,
                          error_code ,
                          preauth_switch ,
                          emergency_switch ,
                          pv_np_id ,
                          pv_alt_id ,
                          pv_f_name ,
                          pv_mi ,
                          pv_l_name ,
                          pv_tax_id ,
                          pv_addr1 ,
                          pv_addr2 ,
                          pv_city ,
                          pv_state ,
                          pv_zip ,
                          pv_country ,
                          pv_lic_state ,
                          pv_id ,
                          pay_prv_switch ,
                          contr_fc_name ,
                          contr_fc_np_id ,
                          contr_fc_alt_id ,
                          contr_fc_id ,
                          pat_f_name ,
                          pat_mi ,
                          pat_l_name ,
                          pat_tax_id ,
                          pat_alt_id ,
                          pat_source_id ,
                          pat_addr1 ,
                          pat_addr2 ,
                          pat_city ,
                          pat_state ,
                          pat_zip ,
                          pat_country ,
                          patient_id ,
                          pcp_name ,
                          pcp_np_id ,
                          pcp_alt_id ,
                          pcp_id ,
                          sub_f_name ,
                          sub_mi ,
                          sub_l_name ,
                          sub_tax_id ,
                          sub_alt_id ,
                          sub_source_id ,
                          sub_addr1 ,
                          sub_addr2 ,
                          sub_city ,
                          sub_state ,
                          sub_zip ,
                          sub_country ,
                          subscriber_id ,
                          group_alt_id ,
                          group_name ,
                          group_id ,
                          plan_dsp_name ,
                          plan_id ,
                          ins_type ,
                          plan_type ,
                          x_rays_rqd ,
                          received_date ,
                          file_name ,
                          special_deal_flg ,
                          hmo_claim_type ,
                          speciality_type ,
                          remarks ,
                          ud_1 ,
                          ud_2 ,
                          ud_3 ,
                          ud_4 ,
                          ud_5 ,
                          h_user ,
                          h_datetime ,
                          config_name
                        )
                VALUES  ( @ALTID ,
                          @DocNo ,
                          @STAT ,
                          @ErrCode ,
                          @PreAuth ,
                          @Emerg ,
                          @PVNPID ,
                          @PVALTID ,
                          @PVFName ,
                          @PVMI ,
                          @PVLName ,
                          @PVTaxID ,
                          @PVAddr1 ,
                          @PVAddr2 ,
                          @PVCity ,
                          @PVState ,
                          @PVZIP ,
                          @PVCountry ,
                          @PVLicState ,
                          @PVID ,
                          @PaySw ,
                          @FCName ,
                          @FCNPID ,
                          @FCAltID ,
                          @FCID ,
                          @PatFName ,
                          @PatMI ,
                          @PatLName ,
                          @PatTaxID ,
                          @PatALTID ,
                          @PatSrcID ,
                          @PatAddr1 ,
                          @PatAddr2 ,
                          @PatCity ,
                          @PatState ,
                          @PatZIP ,
                          @PatCountry ,
                          @PatID ,
                          @PCPName ,
                          @PCPNPID ,
                          @PCPAltID ,
                          @PCPID ,
                          @SubFName ,
                          @SubMI ,
                          @SubLName ,
                          @SubTaxID ,
                          @SubALTID ,
                          @SubSrcID ,
                          @SubAddr1 ,
                          @SubAddr2 ,
                          @SubCity ,
                          @SubState ,
                          @SubZIP ,
                          @SubCountry ,
                          @SubID ,
                    @GrpAltID ,
                          @GrpName ,
                          @GRPID ,
       @PlanName ,
                         @PlanID ,
                          @InsType ,
                          @PlanType ,
                          @XRays ,
                          @ReceivedDate ,
                          @FileName ,
                          @SpecDeal ,
                          @ClaimType ,
                          @SpecType ,
                          @sRemarks ,
                          @UD1 ,
                          @UD2 ,
                          @UD3 ,
                          @UD4 ,
                          @UD5 ,
                          'E_Load' ,
                          GETDATE() ,
                          @ConfigName
                        );
-- Update the eclaim_id in t_eclaim_h with the assigned eclaim_id
                SELECT  @eClaimID = eclaim_id
                FROM    dbo.eclaim_h (NOLOCK)
                WHERE   dbo.eclaim_h.alt_id = @ALTID; 

                UPDATE  dbo.t_eclaim_h
                SET     eclaim_id = @eClaimID
                WHERE   link = @LinkNo;

				UPDATE  dbo.t_eclaim_d
                SET     eclaim_id = @eClaimID
                WHERE   link = @LinkNo;
-- Load the data to eclaim_d.
                INSERT  INTO dbo.eclaim_d
                        ( eclaim_id ,
                          svc_date ,
                          d_proc_code ,
                          tooth_no ,
                          surface ,
                          quad ,
                          cob_amt ,
                          submitted_amt ,
                          h_user ,
                          h_datetime ,
                          error_code
                        )
                        SELECT  @eClaimID ,
                                svc_date ,
                                d_proc_code ,
                                tooth_no ,
                                surface ,
                                quad ,
                                cob_amt ,
                                submitted_amt ,
                                'E_Load' ,
                                GETDATE() ,
                                error_code
                        FROM    dbo.t_eclaim_d (NOLOCK)
                        WHERE   eclaim_id = @eClaimID; 
                FETCH NEXT FROM @SWV_cursor_var1 INTO @ALTID, @DocNo, @STAT,
                    @ErrCode, @PreAuth, @Emerg, @PVNPID, @PVALTID, @PVFName,
                    @PVMI, @PVLName, @PVTaxID, @PVAddr1, @PVAddr2, @PVCity,
                    @PVState, @PVZIP, @PVCountry, @PVLicState, @PVID, @PaySw,
                    @FCName, @FCNPID, @FCAltID, @FCID, @PatFName, @PatMI,
                    @PatLName, @PatTaxID, @PatALTID, @PatSrcID, @PatAddr1,
                    @PatAddr2, @PatCity, @PatState, @PatZIP, @PatCountry,
                    @PatID, @PCPName, @PCPNPID, @PCPAltID, @PCPID, @SubFName,
                    @SubMI, @SubLName, @SubTaxID, @SubALTID, @SubSrcID,
                    @SubAddr1, @SubAddr2, @SubCity, @SubState, @SubZIP,
                    @SubCountry, @SubID, @GrpAltID, @GrpName, @GRPID,
                    @PlanName, @PlanID, @InsType, @PlanType, @XRays,
                    @ReceivedDate, @SpecDeal, @ClaimType, @SpecType, @LinkNo,
                    @sRemarks, @UD1, @UD2, @UD3, @UD4, @UD5, @ConfigName;
            END;
        CLOSE @SWV_cursor_var1;
		*/
		INSERT  INTO dbo.eclaim_h
                        ( alt_id ,
                          document_no ,
                          status ,
                          error_code ,
                          preauth_switch ,
                          emergency_switch ,
                          pv_np_id ,
                          pv_alt_id ,
                          pv_f_name ,
                          pv_mi ,
                          pv_l_name ,
                          pv_tax_id ,
                          pv_addr1 ,
                          pv_addr2 ,
                          pv_city ,
                          pv_state ,
                          pv_zip ,
                          pv_country ,
                          pv_lic_state ,
                          pv_id ,
                          pay_prv_switch ,
                          contr_fc_name ,
                          contr_fc_np_id ,
                          contr_fc_alt_id ,
                          contr_fc_id ,
                          pat_f_name ,
                          pat_mi ,
                          pat_l_name ,
                          pat_tax_id ,
                          pat_alt_id ,
                          pat_source_id ,
                          pat_addr1 ,
                          pat_addr2 ,
                          pat_city ,
                          pat_state ,
                          pat_zip ,
                          pat_country ,
                          patient_id ,
                          pcp_name ,
                          pcp_np_id ,
                          pcp_alt_id ,
                          pcp_id ,
                          sub_f_name ,
                          sub_mi ,
                          sub_l_name ,
                          sub_tax_id ,
                          sub_alt_id ,
                          sub_source_id ,
                          sub_addr1 ,
                          sub_addr2 ,
                          sub_city ,
                          sub_state ,
                          sub_zip ,
                          sub_country ,
                          subscriber_id ,
                          group_alt_id ,
                          group_name ,
                          group_id ,
                          plan_dsp_name ,
                          plan_id ,
                          ins_type ,
                          plan_type ,
                          x_rays_rqd ,
                          received_date ,
                          file_name ,
                          special_deal_flg ,
                          hmo_claim_type ,
                          speciality_type ,
                          remarks ,
                          ud_1 ,
                          ud_2 ,
                          ud_3 ,
                          ud_4 ,
                          ud_5 ,
                          h_user ,
                          h_datetime ,
                          config_name
                        )
					SELECT alt_id ,
                          document_no ,
                          status ,
                          error_code ,
                          preauth_switch ,
                          emergency_switch ,
                          pv_np_id ,
                          pv_alt_id ,
                          pv_f_name ,
                          pv_mi ,
                          pv_l_name ,
                          pv_tax_id ,
                          pv_addr1 ,
                          pv_addr2 ,
                          pv_city ,
                          pv_state ,
                          pv_zip ,
                          pv_country ,
                          pv_lic_state ,
                          pv_id ,
                          pay_prv_switch ,
                          contr_fc_name ,
                          contr_fc_np_id ,
                          contr_fc_alt_id ,
                          contr_fc_id ,
                          pat_f_name ,
                          pat_mi ,
                          pat_l_name ,
                          pat_tax_id ,
                          pat_alt_id ,
                          pat_source_id ,
                          pat_addr1 ,
                          pat_addr2 ,
                          pat_city ,
                          pat_state ,
                          pat_zip ,
                          pat_country ,
                          patient_id ,
                          pcp_name ,
                          pcp_np_id ,
                          pcp_alt_id ,
                          pcp_id ,
                          sub_f_name ,
                          sub_mi ,
                          sub_l_name ,
                          sub_tax_id ,
                          sub_alt_id ,
                          sub_source_id ,
                          sub_addr1 ,
                          sub_addr2 ,
                          sub_city ,
                          sub_state ,
                          sub_zip ,
                          sub_country ,
                          subscriber_id ,
                          group_alt_id ,
                          group_name ,
                          group_id ,
                          plan_dsp_name ,
                          plan_id ,
                          ins_type ,
                          plan_type ,
                          x_rays_rqd ,
                          received_date ,
                          file_name ,
                          special_deal_flg ,
                          hmo_claim_type ,
                          speciality_type ,
                          remarks ,
                          ud_1 ,
                          ud_2 ,
                          ud_3 ,
                          ud_4 ,
                          ud_5 ,
                          'E_Load' ,
                          GETDATE(),
                          config_name FROM dbo.t_eclaim_h (NOLOCK)

						  UPDATE teh
						  SET eclaim_id = eh.eclaim_id
						  FROM dbo.eclaim_h eh (NOLOCK)
						  INNER JOIN dbo.t_eclaim_h teh (NOLOCK)
						  ON eh.alt_id = teh.alt_id

						  UPDATE ted
						  SET eclaim_id = teh.eclaim_id
						  FROM dbo.t_eclaim_h teh (NOLOCK)
						  INNER JOIN dbo.t_eclaim_d ted (NOLOCK)
						  ON ted.link = teh.link

						INSERT  INTO dbo.eclaim_d
                        ( eclaim_id ,
                          svc_date ,
                          d_proc_code ,
                          tooth_no ,
                          surface ,
                          quad ,
                          cob_amt ,
                          submitted_amt ,
                          h_user ,
                          h_datetime ,
                          error_code
                        )
                        SELECT  eclaim_id ,
                                svc_date ,
                                d_proc_code ,
                                tooth_no ,
                                surface ,
                                quad ,
                                cob_amt ,
                                submitted_amt ,
                                'E_Load' ,
                                GETDATE() ,
                                error_code
                        FROM    dbo.t_eclaim_d (NOLOCK)
                       

        SET NOCOUNT OFF;
　
　
    END;