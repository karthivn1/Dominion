﻿CREATE proc [dbo].[usp_dl_GetBatchErrorList]
@BatchId INT,
@SIRDefId INT,
@Severity char(1)=NULL,
@ErrorNumber INT=NULL,
@SkipRows INT ,
@PageSize   INT ,
@TotalRows INT OUT
AS
BEGIN
	   SELECT    dl.error_no		AS ErrorNumber,   
				 cd.descr		    AS Severity,
				 spe.severity		AS SeverityCode,   
				 ltrim(rtrim(spe.error_descr))	AS ErrorDescription,   
				 CASE WHEN dl.corrected='N' THEN 'No' 
					  WHEN dl.corrected='Y' THEN 'Yes' 
					  ELSE dl.corrected END AS Corrected,
				 dl.config_bat_id	AS BatchId,   
				 dl.sp_id			AS SpId,   
				 dl.dls_sir_id	 AS SIRId,   
				 dl.log_error_id	AS LogErrorId,
				 sp.sp_display			AS ErrorStage
    FROM dl_log_error dl
	INNER JOIN dl_sp_error spe ON dl.sp_id=spe.sp_id and dl.error_no=spe.error_no
	INNER JOIN dl_sp sp ON spe.sp_id=sp.sp_id
	LEFT OUTER JOIN stc_common_detail cd ON spe.severity=cd.code and common_header_id=7
	WHERE dl.config_bat_id=@BatchId AND dl.sir_def_id=@SIRDefId
	AND (@Severity IS NULL OR spe.severity=@Severity) 
	AND (@ErrorNumber IS NULL OR dl.error_no=@ErrorNumber)
	order by ErrorNumber
	OFFSET @SkipRows ROWS
    FETCH NEXT @PageSize ROWS ONLY OPTION (RECOMPILE);

	SET @TotalRows =(SELECT  count(dl.error_no)
    FROM dl_log_error dl
	INNER JOIN dl_sp_error spe ON dl.sp_id=spe.sp_id and dl.error_no=spe.error_no
	INNER JOIN dl_sp sp ON spe.sp_id=sp.sp_id
	LEFT OUTER JOIN stc_common_detail cd ON spe.severity=cd.code and common_header_id=7
	WHERE dl.config_bat_id=@BatchId AND dl.sir_def_id=@SIRDefId
	AND (@Severity IS NULL OR severity=@Severity) 
	AND (@ErrorNumber IS NULL OR dl.error_no=@ErrorNumber))
END