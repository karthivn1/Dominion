﻿-- =============================================
-- Author:		Uthayan.S
-- Create date: 02 Jan 2017
-- Description:	Delete Batches from DataLoad
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_DeleteBatch]
	-- Add the parameters for the stored procedure here
	@configBatchId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
		DECLARE @dsirTableName varchar(50)
		DECLARE @DSIRquery Nvarchar(max)
		DECLARE @ParmDefinition nvarchar(50)

    -- Insert statements for procedure here
		Delete from dl_cfg_bat_param
		where config_bat_id = @configBatchId
		 
		Delete from dl_log_error
		where config_bat_id = @configBatchId
	
		Delete from dl_log_error_h
		where config_bat_id = @configBatchId
		 
		Delete from dl_bat_statistics
		where cfg_bat_det_id in (select cfg_bat_det_id 
					  from dl_cfg_bat_det
					  where config_bat_id = @configBatchId);
	
		Delete from dl_cfg_bat_det
		where config_bat_id = @configBatchId

		--Declare module_tables_cur Cursor for
		--	Select sir_def_id, sir_def_name
		--	From dl_sir_def
		--	Where module_id = :ll_module_id ;

		--Select module_id Into :ll_module_id
		--From dl_config, dl_config_bat
		--Where dl_config.config_id = dl_config_bat.config_id
		--And dl_config_bat.config_bat_id = @configBatchId
	 
		--Open module_tables_cur;
		--Fetch module_tables_cur into :ls_sir_def_id, :ls_sir_def_name;

		--Do while SQLCA.SQLCode = 0
		--	ls_sql = "Delete from dls_" + Trim(ls_sir_def_name) &
		--		 + " where dls_batch_id = " + String(ll_cfg_batch_id)
			
		--	Execute Immediate :ls_sql ;

		--	Fetch module_tables_cur into :ls_sir_def_id, :ls_sir_def_name;
		--loop
		--Close module_tables_cur;
		 
		SET @dsirTableName=(SELECT 'dls_'+ RTRIM(sir_def_name) 
		FROM dl_sir_def D
		INNER JOIN dl_config C ON C.module_id = D.module_id
		INNER JOIN dl_config_bat B ON B.config_id = C.config_id
		WHERE B.config_bat_id = @configBatchId)

		SET @DSIRquery = N'SELECT * FROM '+@dsirTableName+' WHERE dls_batch_id=@batchId '		
		SET @ParmDefinition = N'@batchId int'

		EXECUTE sp_executesql @DSIRquery, @ParmDefinition,@batchId=@configBatchId

		Delete from dl_config_bat
		where config_bat_id = @configBatchId
END