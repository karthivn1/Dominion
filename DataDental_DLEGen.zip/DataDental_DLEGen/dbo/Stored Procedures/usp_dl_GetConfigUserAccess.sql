﻿
CREATE PROC [dbo].[usp_dl_GetConfigUserAccess]
@OptType VARCHAR(3),
@UserName varchar(15)
AS
BEGIN
SET NOCOUNT ON;
	CREATE TABLE #TmpAccessTable (sysId int,accessType varchar(10))
	DECLARE @UserId INT
	SELECT @UserId=usersl_id FROM user_tbl WHERE user_id=@UserName
	INSERT INTO #TmpAccessTable
	SELECT config_id,sys_access_type FROM dl_config(NOLOCK)
			INNER JOIN (SELECT  DISTINCT b.sys_access_type ,b.sys_id,b.sys_opt_type
		FROM stc_user_access(NOLOCK) a, stc_sys_opt(NOLOCK) b
		WHERE b.sys_opt_type = @OptType AND
			a.sys_opt_id = b.sys_opt_id AND
			(a.usersl_id IN (SELECT group_id FROM stc_user_group WHERE usersl_id = @UserId AND (
									eff_date <= GETDATE() AND 	(exp_date > GETDATE() OR exp_date IS NULL)
								)) 
				OR a.usersl_id = @UserId) 
			AND (a.eff_date <= GETDATE() 
			AND (a.exp_date > GETDATE() OR a.exp_date IS NULL))) 
			As  ConfigAccess ON ConfigAccess.sys_id =config_id

	SELECT	C.config_id AS ConfigurationId,
			C.module_id AS ModuleId,
			C.config_name AS Name,
			C.config_descr AS Description,
			C.job_def_id AS JobDefinitonId,
			C.config_contact_ln AS LastName,
			C.config_contact_fn AS FirstName,
			C.config_contact_pho AS Phone,
			C.config_cont_ph_ext AS PhoneExtension,
			C.config_cont_email AS Email,
			--C.config_status AS Status,
			C.config_icon AS Icon,
			C.created_by AS CreatedBy,
			C.created_time AS CreatedTime,
			S.descr AS Status,
			J.job_def_name as JobDefiniton,
			M.module_name as ModuleName,
			RTRIM(SUBSTRING(ISNULL((SELECT ','+T.accessType 
			FROM #TmpAccessTable T WHERE T.sysId = C.config_id FOR XML PATH('')),' '),2,10000)) AS UserAccessTypes
			FROM dl_config(NOLOCK) C
			INNER JOIN dl_job_def J ON J.job_def_id=C.job_def_id
            INNER JOIN stc_common_detail S ON S.code = C.config_status AND S.common_header_id=1
            INNER JOIN dl_module M ON M.module_id = C.module_id
	DROP TABLE #TmpAccessTable;
	SET NOCOUNT OFF;
END