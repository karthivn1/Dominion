﻿CREATE PROCEDURE [dbo].[dl_get_err_sevr]
    @a_sp_id INT ,
    @a_error_no INT ,
    @SWP_Ret_Value CHAR(1) = NULL OUTPUT
    
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @c_severity CHAR(1);

        SET NOCOUNT ON;
        BEGIN TRY
            IF @a_sp_id < 0
                RAISERROR('Error',16,1);
	
            SELECT  @c_severity = severity
            FROM    dbo.dl_sp_error (NOLOCK)
            WHERE   sp_id = @a_sp_id
                    AND error_no = @a_error_no;
            IF @@rowcount = 0
                SELECT  @c_severity = NULL;
            IF ( @c_severity IS NULL
                 OR @c_severity = ''
               )
                SET @c_severity = 'F';
	
            SET @SWP_Ret_Value = @c_severity;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @SWP_Ret_Value = 'F';
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;
    END;