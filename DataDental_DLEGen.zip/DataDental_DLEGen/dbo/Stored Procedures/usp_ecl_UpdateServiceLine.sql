﻿
CREATE PROCEDURE [dbo].[usp_ecl_UpdateServiceLine]

@ServiceDate CHAR(10),
@CDT CHAR(5),
@ToothNo CHAR(2),
@SurfaceCode CHAR(5),
@QuadrantCode CHAR(5),
@CobAmount CHAR(20),
@SubmittedAmount CHAR(20),
@ErrorCode CHAR(10),
@EclaimDetailId	INT,
@User VARCHAR(20)

AS
BEGIN
	UPDATE eclaim_d SET svc_date	= @ServiceDate,
						d_proc_code	= @CDT,
						tooth_no	= @ToothNo,
						surface		= @SurfaceCode,
						quad		= @QuadrantCode,
						cob_amt		= @CobAmount,
						submitted_amt=@SubmittedAmount,
						error_code	= @ErrorCode,
						h_user		= @User,
						h_datetime  = GETDATE()
				  	    WHERE eclaim_d_id=@EclaimDetailId	
END