﻿CREATE PROCEDURE [dbo].[dlp_lb_rein_tol]
    @p_batch_id INT ,
    @p_group_id INT ,
    @p_eff_date DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(1) = NULL OUTPUT ,
    @SWP_Ret_Value2 VARCHAR(64) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_lb_rein_tol
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This procedure supports lockbox pre-processing, 
--           dlp_bu_lockbox(), of DataLoad for the DataDental Alloation module,
--           a product of STC.  This SP checks the payment tolerance for 
--           individual groups, including all plan premiums, to determine if
--           reinstatement is warrented.
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server

   */
   
   
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @i_fatal INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @s_err_rtn_text VARCHAR(64);
   
        DECLARE @m_alloc_cred DECIMAL(16, 2);
        DECLARE @m_tot_owed DECIMAL(16, 2);
        DECLARE @m_grp_tot_paid MONEY;
        DECLARE @m_mnth_prem MONEY;
   
        DECLARE @s_paid_amt CHAR(9);
   
        DECLARE @f_variance FLOAT;
   
        DECLARE @i_tmp_dls_sir_id INT;
        DECLARE @i_rtn INT;
   
        DECLARE @s_alloc_flag CHAR(1);
        DECLARE @s_alloc_type CHAR(2);

        DECLARE @i_pymt_tol DECIMAL(5, 2);
        DECLARE @t_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        --DECLARE @cTEMP_SIR CURSOR;
   
   ---------------------perform exception handling------------------------------
        SET NOCOUNT ON;
        SET @t_sir_id = 0
        
        SET @i_sp_id = 0
        
        SET @i_sir_def_id = 0
        
        BEGIN TRY
            SET @s_alloc_flag = 'A';
            SELECT  @i_pymt_tol = pymt_toler ,
                    @s_alloc_type = alloc_type
            FROM    dbo.[group] (NOLOCK)
            WHERE   group_id = @p_group_id;
            

   -- if group table specifies manual allocation, then set flag as such
            IF @s_alloc_type = 'MA'
                SET @s_alloc_flag = 'M';
   

   -- get amount already credited, but not allocated yet
            SELECT  @m_alloc_cred = SUM(amount)
            FROM    dbo.allocation (NOLOCK)
            WHERE   group_id = @p_group_id
                    AND al_transaction IS NULL
                    AND tran_code LIKE 'C_';
            
            IF @m_alloc_cred IS NULL
                SET @m_alloc_cred = 0.0;
   

   -- get total from this batch, for this group - paid_amt is a char
            SELECT  @m_grp_tot_paid = SUM(paid_amt)
            FROM    #dls_lb_money_paid
            WHERE   group_id = @p_group_id;
            
         
   -- get amount owed, but not allocated yet
            SELECT  @m_tot_owed = SUM(amount)
            FROM    dbo.allocation (NOLOCK)
            WHERE   group_id = @p_group_id
                    AND al_transaction IS NULL
                    AND tran_code LIKE 'D_';
            
            IF @m_tot_owed IS NULL
                SET @m_tot_owed = 0.0;
   

   -- get monthly premium for all plans for this group ---
            SELECT  @m_mnth_prem = SUM(prm_amt)
            FROM    dbo.group_cap_rate (NOLOCK)
            WHERE   exp_date IS NULL
                    AND rate_code IN (
                    SELECT  rate_code
                    FROM    dbo.rlmbrt (NOLOCK)
                    WHERE   mb_gr_pl_id IN ( SELECT mb_gr_pl_id
                                             FROM   dbo.rlmbgrpl (NOLOCK)
                                    WHERE  group_id = @p_group_id ) )
                    AND rel_gppl_id IN (
                    SELECT  rel_gppl_id
                    FROM    dbo.rel_gppl (NOLOCK)
                    WHERE   exp_date IS NULL
                            AND group_id = @p_group_id
                            AND plan_id IN ( SELECT plan_id
                                             FROM   dbo.rlmbgrpl (NOLOCK)
                                             WHERE  group_id = @p_group_id ) );
           
            IF @m_mnth_prem IS NULL
                SET @m_mnth_prem = 0.0;
   
            SET @m_tot_owed = @m_tot_owed + ( @m_mnth_prem * 12 );
            IF @m_tot_owed <= 0.0
                SET @f_variance = @i_pymt_tol;
            ELSE
      -- calc the variance
                SET @f_variance = ( ( @m_alloc_cred + @m_grp_tot_paid )
                                    / @m_tot_owed ) * 100;
   
         
   -- check if variance meets tolerance specs
            IF @f_variance < @i_pymt_tol
                BEGIN
                    SET @s_alloc_flag = 'M';
            
      -- insert err into temp table, it may be cleared by further proc
                    INSERT  INTO #dls_lockbox_var
                            ( dls_sir_id, group_id, error_no )
                    VALUES  ( @t_sir_id, @p_group_id, 260 );
                END;
            ELSE -- meets tolerance
         
      -- log the reinstate group action for this row
                BEGIN
                    
   
         -- only change if group did not specify a man alloc
                    EXECUTE @i_rtn = dbo.dl_log_action @p_batch_id, @t_sir_id,
                        'RG', @p_eff_date;

      -- now must check temp table and delete any prev errs 
      -- that are now OK, with total payment for group

	  DECLARE @cTEMP_SIR TABLE
                        (
                         id INT IDENTITY ,
						 dls_sir_id INT
                        );
INSERT  INTO @cTEMP_SIR
                                ( dls_sir_id 
                                )
								SELECT dls_sir_id 
         FROM #dls_lockbox_var
         WHERE group_id = @p_group_id;

	  DECLARE @cur_cnt INT ,
                            @cur_i INT;

                        SET @cur_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur_cnt = COUNT(1)
                        FROM   @cTEMP_SIR;
	  /*
                    SET @cTEMP_SIR = CURSOR  FOR SELECT dls_sir_id 
         FROM #dls_lockbox_var
         WHERE group_id = @p_group_id;
                    OPEN @cTEMP_SIR;
                    FETCH NEXT FROM @cTEMP_SIR INTO @i_tmp_dls_sir_id;
                    WHILE @@FETCH_STATUS = 0
					*/
                        WHILE ( @cur_i <= @cur_cnt )
            BEGIN
			SELECT  @i_tmp_dls_sir_id = dls_sir_id FROM @cTEMP_SIR
            WHERE   id = @cur_i;
                            IF NOT @s_alloc_type LIKE 'MA'
         
            -- change alloc flag from manual to auto
                                UPDATE  dbo.dls_lockbox
                                SET     dls_alloc_flag = 'A'
                                WHERE   dls_sir_id = @i_tmp_dls_sir_id;
         
               
         -- log a rein action for each row that belongs to the group
         -- and was prev identified as not meeting tolerance
                            EXECUTE @i_rtn = dbo.dl_log_action @p_batch_id,
                                @i_tmp_dls_sir_id, 'RG', @p_eff_date;

         -- delete entry from temp table
		 /*-
                            DELETE  FROM #dls_lockbox_var
                            WHERE CURRENT OF @cTEMP_SIR;
							*/
							DELETE  FROM #dls_lockbox_var
                            WHERE id=@cur_i



                            --FETCH NEXT FROM @cTEMP_SIR INTO @i_tmp_dls_sir_id;
							SET @cur_i = @cur_i + 1;
                        END;
                    --CLOSE @cTEMP_SIR;
                END;
    -- variance/tolerance check
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @s_alloc_flag;
            SET @SWP_Ret_Value2 = NULL;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = @i_error_no;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


   -----------------begin body of proc-----------------------------------
    END;