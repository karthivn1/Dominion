﻿CREATE PROCEDURE [dbo].[dlp_lb_indv]
    @p_dls_group_id INT ,
    @p_batch_id INT ,
    @p_invoice_no INT ,
    @p_paid_amt MONEY ,
    @p_ck_tol CHAR(1) ,
    @p_alw_n_annl CHAR(1) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(1) = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(30) = NULL OUTPUT ,
    @SWP_Ret_Value3 VARCHAR(64) = NULL OUTPUT
    
         -- s_error_descr
------------------------------------------------------------------------------
--
--            Procedure:   dlp_lb_indv
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This procedure supports lockbox pre-processing, dlp_bu_lockbox(),
--           of DataLoad for the DataDental Alloation module, a product of STC.
--           This SP performs individual group specific rules checking and
--           possible group reinstatement on the lockbox data.
--
-- Modification History:
--
--   DATE         AUTHOR       DETAILS
--   06/03/1999   G.Albers     group_id is retrieved from invoice_no, 
--                             not bill_sum table for single groups
--
--Used for DataLoad SG (Single Group).  Called by dlp_bu_lockbox().
-------------------------------------------------------------------------------
                -- i_error_no
          --integer,             -- i_group_id
                       -- s_alloc_flag
                      -- s_acct_num
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
   
   
   
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @i_fatal INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @s_err_rtn_text VARCHAR(64);
   
        DECLARE @i_invoice_no INT;
        DECLARE @i_oc_id INT;
        DECLARE @i_bill_freq INT;
        DECLARE @i_group_id INT;
   
        DECLARE @d_eff_date DATE;
   
        DECLARE @s_acct_num CHAR(20);
        DECLARE @s_alloc_flag CHAR(1);
        DECLARE @s_alloc_type CHAR(2);
        DECLARE @s_bill_type CHAR(2);
        DECLARE @s_group_stat CHAR(2);
        DECLARE @s_group_type CHAR(2);
        DECLARE @s_bill_descr CHAR(35);
        DECLARE @t_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;

          
   ---------------------perform exception handling------------------------------
        SET NOCOUNT ON;
        SET @t_sir_id = 0;
      
        SET @i_sp_id = 0;
      
        SET @i_sir_def_id = 0 ;

        select @t_sir_id=VarValue from GlobalVar where BatchId=@p_batch_id AND  Module_Id = 5 and VarName='t_sir_id'
		select @i_sp_id=VarValue from GlobalVar where BatchId=@p_batch_id AND  Module_Id = 5 and VarName='i_sp_id'
		select @i_sir_def_id=VarValue from GlobalVar where BatchId=@p_batch_id AND  Module_Id = 5 and VarName='i_sir_def_id'

      /* sets status to Error if condition deemed fatal * /
       / * NULL,* /  / * NULL,*/ 
        BEGIN TRY
            SET @s_alloc_flag = 'A';

   -- invoice no is the group no for single groups 
   --LET i_group_id = p_invoice_no;	--Out 20131206.
            SET @i_group_id = @p_dls_group_id;
            IF @i_group_id IS NULL
			BEGIN
				SET @i_error_no =80
                RAISERROR('Cannot retrieve Group ID using Invoice No.',16,1);
			END
   
            SELECT  @s_group_type = group_type ,
                    @i_oc_id = oc_id ,
                    @s_bill_type = bill_type ,
                    @i_bill_freq = bill_freq ,
                    @s_alloc_type = alloc_type
            FROM    dbo.[group] (NOLOCK)
            WHERE   dbo.[group].group_id = @i_group_id;
           
   
   -- if allowing only annual single groups and bill freq is more than 1/year 
   -- indicate an error
            IF @p_alw_n_annl = 'N'
                AND @i_bill_freq <> 1
				BEGIN
				SET @i_error_no=120
                RAISERROR('Invalid Billing Frequency for Single Group',16,1);
				END
   
            IF @i_oc_id IS NULL
			BEGIN
			SET @i_error_no=90
                RAISERROR('Cannot find the Oper Co for the Group',16,1);
			END
   

   -- check for valid group type
            IF @s_group_type NOT IN ( 'SG', 'SB' )
			BEGIN
				SET @i_error_no=100
                RAISERROR('Invalid Group Type for Group',16,1)
			END
   
         
   -- check that billing type is not auto-clearing house
            IF @s_bill_type LIKE 'AH'
			BEGIN
				SET @i_error_no=110
                RAISERROR('Invalid Billing Type, ACH, for Group',16,1);
			END
   

   ------get account # ------------
            SELECT  @s_acct_num = acct_num
            FROM    dbo.bank_info (NOLOCK)
            WHERE   bank_info_id = ( SELECT deposit_acct
                                     FROM   dbo.oper_company (NOLOCK)
                                     WHERE  oc_id = @i_oc_id
                                   );
           
            IF ( @s_acct_num IS NULL
                 OR @s_acct_num = ''
               )
			   BEGIN
			   SET @i_error_no=140
                RAISERROR('Cannot locate Bank Account for Group',16,1);
			END
   
   
   -- get status to determine if terminated
            SELECT  @s_group_stat = group_status ,
                    @d_eff_date = eff_date
            FROM    dbo.group_status (NOLOCK)
            WHERE   group_id = @i_group_id
                    AND exp_date IS NULL;
            

   -- get description of bill type
            SELECT  @s_bill_descr = descr
            FROM    dbo.typ_table (NOLOCK)
            WHERE   subsys_code = 'GP'
                    AND tab_name = 'bill_type'
                    AND code = @s_bill_type;
           

   -- check if terminated and an annual biil type
    /* i_group_id,*/ 
            IF @s_group_stat = 'T1'
                AND @s_bill_descr LIKE 'Annual%' ESCAPE '\'
                IF @d_eff_date IS NULL
				BEGIN
				SET @i_error_no=130
                    RAISERROR('Cannot locate effective date for reinstatement',16,1);
				END
                ELSE

         -- insert amount paid and group into temp table for later use
                    BEGIN
                        INSERT  INTO #dls_lb_money_paid
                                ( group_id, paid_amt )
                        VALUES  ( @i_group_id, @p_paid_amt );
         
                        EXECUTE dbo.dlp_lb_rein_tol @p_batch_id, @i_group_id,
                            @d_eff_date, @i_error_no OUTPUT,
                            @s_alloc_flag OUTPUT, @s_error_descr OUTPUT;
          /* NULL,*/ 
                        IF @i_error_no <> 1
                            BEGIN
                                SET @SWP_Ret_Value = @i_error_no;
                                SET @SWP_Ret_Value1 = NULL;
                                SET @SWP_Ret_Value2 = NULL;
                                SET @SWP_Ret_Value3 = @s_error_descr;
                                RETURN;
                            END;
                    END;
      
            ELSE
                IF @p_ck_tol = 'Y'
                    BEGIN
                        INSERT  INTO #dls_lb_money_paid
                                ( group_id, paid_amt )
                        VALUES  ( @i_group_id, @p_paid_amt );
         
                        EXECUTE dbo.dlp_lb_ck_tol @p_batch_id, @i_group_id,
                            @i_error_no OUTPUT, @s_alloc_flag OUTPUT,
               @s_error_descr OUTPUT;
          /* NULL,*/ 
                        IF @i_error_no <> 1
                            BEGIN
                                SET @SWP_Ret_Value = @i_error_no;
                                SET @SWP_Ret_Value1 = NULL;
                                SET @SWP_Ret_Value2 = NULL;
                                SET @SWP_Ret_Value3 = @s_error_descr;
                                RETURN;
                            END;
                    END;
                ELSE
                    IF ( @s_alloc_type = 'MA' )
                        SET @s_alloc_flag = 'M';
   
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @s_alloc_flag;
            SET @SWP_Ret_Value2 = @s_acct_num;
            SET @SWP_Ret_Value3 = NULL;
            RETURN;
        END TRY
        BEGIN CATCH
           -- SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE(); /* NULL,*/ 
			 IF ERROR_NUMBER()=50000
			 BEGIN
                                    
									
                                   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sir_id,
                                        @i_error_no;
                                   
                                   
			END;
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
          ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


      
   -------------------------begin body of code----------------------------------

    END;