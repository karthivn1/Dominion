﻿CREATE PROCEDURE [dbo].[dlp_al_pv_assoc]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    


	/*error variable*/
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(18);
        DECLARE @s_proc_name CHAR(18);
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);

        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_config_id INT;
        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_in_transaction CHAR(1);

        DECLARE @t_sir_id INT;
        DECLARE @t_alt_id CHAR(20); 
        DECLARE @t_pv_tax_id CHAR(9); 
        DECLARE @t_pv_license CHAR(18); 
        DECLARE @t_pv_lic_state CHAR(2);
        DECLARE @t_tin CHAR(1);
        DECLARE @t_pv_first_name CHAR(20);
        DECLARE @t_pv_middle_init CHAR(1);
        DECLARE @t_pv_last_name CHAR(30);
        DECLARE @t_discipline CHAR(2); 
        DECLARE @t_mal_car CHAR(30);
        DECLARE @t_mal_pol_no CHAR(15);
        DECLARE @t_mal_prac CHAR(10);
        DECLARE @t_mal_amt CHAR(18); 
        DECLARE @t_mal_amt_i CHAR(18);
        DECLARE @t_mal_comnt CHAR(50);
        DECLARE @t_dea_no CHAR(15); 
        DECLARE @t_dea_cert_dt CHAR(10);
        DECLARE @t_dea_exp_dt CHAR(10);
        DECLARE @t_cds_no CHAR(15);
        DECLARE @t_cds_cert_dt CHAR(10); 
        DECLARE @t_cds_exp_dt CHAR(10);
        DECLARE @t_cpr_cert_dt CHAR(10);
        DECLARE @t_cpr_exp_dt CHAR(10);
        DECLARE @t_prim_fc CHAR(40);
        DECLARE @t_school CHAR(50); 
        DECLARE @t_grd_date CHAR(10);
        DECLARE @t_degree CHAR(4);
        DECLARE @t_ada_mbr CHAR(1);
        DECLARE @tmpks CHAR(1);
        DECLARE @t_district_no CHAR(15);
        DECLARE @t_pv_dob CHAR(10);
        DECLARE @t_print_dir CHAR(1);
        DECLARE @t_race CHAR(2);
        DECLARE @t_gender CHAR(1); 
        DECLARE @t_num_yr_prac CHAR(3);
        DECLARE @t_peer_rv CHAR(1);
        DECLARE @t_pv_stat_eff_date CHAR(10);
	/* 20130804$$ks - expanded facility.alt_id fields to 40 char */
        DECLARE @t_fc_assoc_fc_id CHAR(40);
        DECLARE @t_fc_assoc_type CHAR(1);
        DECLARE @t_fc_assoc_eff CHAR(10);
        DECLARE @t_fc_assoc_exp CHAR(10); 
        DECLARE @t_pv_lic_eff_date CHAR(10);
        DECLARE @t_pv_lic_exp_date CHAR(10);
        DECLARE @t_pv_addr_type CHAR(2);
        DECLARE @t_pv_addr_1 CHAR(30); 
        DECLARE @t_pv_addr_2 CHAR(30);
        DECLARE @t_pv_addr_zip CHAR(10);
        DECLARE @t_pv_addr_city CHAR(30);
        DECLARE @t_pv_addr_state CHAR(2); 
        DECLARE @t_pv_addr_county CHAR(20);
        DECLARE @t_pv_addr_country CHAR(3);
        DECLARE @t_pv_addr_mail CHAR(1);
        DECLARE @t_pv_con_type CHAR(2);
        DECLARE @t_pv_con_lname CHAR(15); 
        DECLARE @t_pv_con_fname CHAR(10);
        DECLARE @t_pv_con_title CHAR(25);
        DECLARE @t_pv_con_phone1 CHAR(10);
        DECLARE @t_pv_con_ext1 CHAR(10);
        DECLARE @t_pv_con_phone2 CHAR(10);
        DECLARE @t_pv_con_ext2 CHAR(10);
        DECLARE @t_pv_con_fax CHAR(10); 
        DECLARE @d_city CHAR(30); 
        DECLARE @d_state CHAR(2); 
        DECLARE @d_county CHAR(20);

        DECLARE @d_rec_count INT;
        DECLARE @n_process_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @n_al_count INT;
        DECLARE @i_delete_id INT;
        --DECLARE @SWV_cursor_var1 CURSOR;
       --DECLARE @cSIR CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;


        SET NOCOUNT ON;
        BEGIN TRY

            
            SET @s_proc_name = 'al_pv_assoc';
            SET @s_sir_def_name = 'pv_assoc';
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, @s_proc_name;
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
				BEGIN
				SET @a_error_no  = 0 
                RAISERROR('Invalid SP Name',16,1);
				END
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
				BEGIN
				SET @a_error_no  = 0 
                RAISERROR('Invalid SIR TABLE Definition',16,1);
				END
	
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;
           
            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      ORIGINAL_LOGIN() ,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            
            SET @n_process_count = 0;
            SET @n_succ_count = 0;
            SET @n_in_transaction = 'N';
            IF EXISTS ( SELECT  *
                        FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @a_batch_id
                                AND sp_id = @i_sp_id )
                BEGIN
                    /*
					SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id 
         FROM dbo.dls_pv_assoc (NOLOCK)
         WHERE dls_batch_id = @a_batch_id AND dls_status = 'V';
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_delete_id;
                    WHILE @@FETCH_STATUS = 0
					*/
                    DECLARE @SWV_cursor_var1 TABLE
                        (
                          id INT IDENTITY ,
                          dls_sir_id INT
                        );

                    INSERT  INTO @SWV_cursor_var1
                            ( dls_sir_id
                            )
                            SELECT  dls_sir_id
                            FROM    dbo.dls_pv_assoc (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V';


                    DECLARE @cur1_cnt INT ,
                        @cur1_i INT;

                    SET @cur1_i = 1;

				--Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;

                    WHILE ( @cur1_i <= @cur1_cnt )
                        BEGIN
                            SELECT  @i_delete_id = dls_sir_id
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur1_i;

                            EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                @i_delete_id, @i_sp_id, @i_error_no OUTPUT,
      @s_error_descr OUTPUT;
                            UPDATE  dbo.dls_pv_assoc
                            SET     dls_status = 'L'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V'
                                    AND dls_sir_id = @i_delete_id;
                           -- FETCH NEXT FROM @SWV_cursor_var1 INTO @i_delete_id;
                            SET @cur1_i = @cur1_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var1;
                END;
	
            /*
			SET @cSIR = CURSOR  FOR SELECT	dls_sir_id, alt_id, pv_tax_id, pv_license, pv_lic_state, tin,
		pv_first_name, pv_middle_init, pv_last_name, discipline,
		mal_car, mal_pol_no, mal_prac, mal_amt, mal_amt_i, mal_comnt,
		dea_no, dea_cert_dt, dea_exp_dt, cds_no, cds_cert_dt,
		cds_exp_dt, cpr_cert_dt, cpr_exp_dt, prim_fc, school, grd_date,
		degree, ada_mbr, district_no, pv_dob, print_dir, race, gender,
		num_yr_prac, peer_rv, pv_stat_eff_date, fc_assoc_fc_id,
		fc_assoc_type, fc_assoc_eff_date, fc_assoc_exp_date,
		pv_lic_eff_date, pv_lic_exp_date, pv_addr_type, pv_addr_1,
		pv_addr_2, pv_addr_zip, pv_addr_city, pv_addr_state,
		pv_addr_county, pv_addr_country, pv_addr_mail, pv_con_type,
		pv_con_lname, pv_con_fname, pv_con_title, pv_con_phone1,
		pv_con_ext1, pv_con_phone2, pv_con_ext2, pv_con_fax
	
      FROM dbo.dls_pv_assoc (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'L';
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_alt_id, @t_pv_tax_id,
                @t_pv_license, @t_pv_lic_state, @t_tin, @t_pv_first_name,
                @t_pv_middle_init, @t_pv_last_name, @t_discipline, @t_mal_car,
                @t_mal_pol_no, @t_mal_prac, @t_mal_amt, @t_mal_amt_i,
                @t_mal_comnt, @t_dea_no, @t_dea_cert_dt, @t_dea_exp_dt,
                @t_cds_no, @t_cds_cert_dt, @t_cds_exp_dt, @t_cpr_cert_dt,
                @t_cpr_exp_dt, @t_prim_fc, @t_school, @t_grd_date, @t_degree,
                @t_ada_mbr, @t_district_no, @t_pv_dob, @t_print_dir, @t_race,
                @t_gender, @t_num_yr_prac, @t_peer_rv, @t_pv_stat_eff_date,
                @t_fc_assoc_fc_id, @t_fc_assoc_type, @t_fc_assoc_eff,
                @t_fc_assoc_exp, @t_pv_lic_eff_date, @t_pv_lic_exp_date,
                @t_pv_addr_type, @t_pv_addr_1, @t_pv_addr_2, @t_pv_addr_zip,
                @t_pv_addr_city, @t_pv_addr_state, @t_pv_addr_county,
                @t_pv_addr_country, @t_pv_addr_mail, @t_pv_con_type,
                @t_pv_con_lname, @t_pv_con_fname, @t_pv_con_title,
                @t_pv_con_phone1, @t_pv_con_ext1, @t_pv_con_phone2,
                @t_pv_con_ext2, @t_pv_con_fax;
            WHILE @@FETCH_STATUS = 0
			*/
			IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
		DROP TABLE #SWV_cursor_var2

           CREATE TABLE #SWV_cursor_var2
                (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                   alt_id CHAR (20), 
				   pv_tax_id CHAR (9), 
				   pv_license CHAR (18), 
				   pv_lic_state CHAR (2), 
				   tin CHAR (1), 
				   pv_first_name CHAR (20), 
				   pv_middle_init CHAR (1), 
				   pv_last_name CHAR (30), 
				   discipline CHAR (2), 
				   mal_car CHAR (30), 
				   mal_pol_no CHAR (15), 
				   mal_prac CHAR (10), 
				   mal_amt CHAR (20), 
				   mal_amt_i CHAR (20), 
				   mal_comnt CHAR (50), 
				   dea_no CHAR (15), 
				   dea_cert_dt CHAR (10), 
				   dea_exp_dt CHAR (10), 
				   cds_no CHAR (15), 
				   cds_cert_dt CHAR (10), 
				   cds_exp_dt CHAR (10), 
				   cpr_cert_dt CHAR (10), 
				   cpr_exp_dt CHAR (10), 
				   prim_fc CHAR (40), 
				   school CHAR (50), 
				   grd_date CHAR (10), 
				   degree CHAR (4), 
				   ada_mbr CHAR (1), 
				   district_no CHAR (15), 
				   pv_dob CHAR (10), 
				   print_dir CHAR (1), 
				   race CHAR (2), 
				   gender CHAR (1), 
				   num_yr_prac CHAR (11), 
				   peer_rv CHAR (1), 
				   pv_stat_eff_date CHAR (10), 
				   fc_assoc_fc_id CHAR (40), 
				   fc_assoc_type CHAR (1), 
				   fc_assoc_eff_date CHAR (10), 
				   fc_assoc_exp_date CHAR (10), 
				   pv_lic_eff_date CHAR (10), 
				   pv_lic_exp_date CHAR (10), 
				   pv_addr_type CHAR (2), 
				   pv_addr_1 CHAR (30), 
				   pv_addr_2 CHAR (30), 
				   pv_addr_zip CHAR (10), 
				   pv_addr_city CHAR (30), 
				   pv_addr_state CHAR (2), 
				   pv_addr_county CHAR (20), 
				   pv_addr_country CHAR (3), 
				   pv_addr_mail CHAR (1), 
				   pv_con_type CHAR (2), 
				   pv_con_lname CHAR (15), 
				   pv_con_fname CHAR (10), 
				   pv_con_title CHAR (25), 
				   pv_con_phone1 CHAR (14), 
				   pv_con_ext1 CHAR (5), 
				   pv_con_phone2 CHAR (14), 
				   pv_con_ext2 CHAR (5), 
				   pv_con_fax CHAR(14)	
                );

            INSERT  INTO #SWV_cursor_var2
                    ( dls_sir_id ,
                      alt_id ,
                      pv_tax_id ,
                      pv_license ,
                      pv_lic_state ,
                      tin ,
                      pv_first_name ,
                      pv_middle_init ,
                      pv_last_name ,
                      discipline ,
                      mal_car ,
                      mal_pol_no ,
                      mal_prac ,
                      mal_amt ,
                      mal_amt_i ,
                      mal_comnt ,
                      dea_no ,
                      dea_cert_dt ,
                      dea_exp_dt ,
                      cds_no ,
                      cds_cert_dt ,
                      cds_exp_dt ,
                      cpr_cert_dt ,
                      cpr_exp_dt ,
                      prim_fc ,
                      school ,
                      grd_date ,
                      degree ,
                      ada_mbr ,
                      district_no ,
                      pv_dob ,
                      print_dir ,
                      race ,
                      gender ,
                      num_yr_prac ,
                      peer_rv ,
                      pv_stat_eff_date ,
                      fc_assoc_fc_id ,
                      fc_assoc_type ,
                      fc_assoc_eff_date ,
                      fc_assoc_exp_date ,
                      pv_lic_eff_date ,
                      pv_lic_exp_date ,
                      pv_addr_type ,
                      pv_addr_1 ,
                      pv_addr_2 ,
                      pv_addr_zip ,
                      pv_addr_city ,
                      pv_addr_state ,
                      pv_addr_county ,
                      pv_addr_country ,
                      pv_addr_mail ,
                      pv_con_type ,
                      pv_con_lname ,
                      pv_con_fname ,
                      pv_con_title ,
                      pv_con_phone1 ,
                      pv_con_ext1 ,
                      pv_con_phone2 ,
                      pv_con_ext2 ,
                      pv_con_fax
                    )
                    SELECT  dls_sir_id ,
                            alt_id ,
                            pv_tax_id ,
                            pv_license ,
                            pv_lic_state ,
                            tin ,
                            pv_first_name ,
                            pv_middle_init ,
                            pv_last_name ,
                            discipline ,
                            mal_car ,
                            mal_pol_no ,
                     mal_prac ,
                            mal_amt ,
                            mal_amt_i ,
                            mal_comnt ,
                            dea_no ,
               dea_cert_dt ,
                            dea_exp_dt ,
                            cds_no ,
                            cds_cert_dt ,
                            cds_exp_dt ,
                            cpr_cert_dt ,
                            cpr_exp_dt ,
                            prim_fc ,
                            school ,
                            grd_date ,
                            degree ,
                            ada_mbr ,
                            district_no ,
                            pv_dob ,
                            print_dir ,
                            race ,
                        gender ,
                            num_yr_prac ,
                            peer_rv ,
                            pv_stat_eff_date ,
                            fc_assoc_fc_id ,
                            fc_assoc_type ,
                            fc_assoc_eff_date ,
                            fc_assoc_exp_date ,
                            pv_lic_eff_date ,
                            pv_lic_exp_date ,
                            pv_addr_type ,
                            pv_addr_1 ,
                            pv_addr_2 ,
                            pv_addr_zip ,
                            pv_addr_city ,
                            pv_addr_state ,
                            pv_addr_county ,
                            pv_addr_country ,
                            pv_addr_mail ,
                            pv_con_type ,
                            pv_con_lname ,
                            pv_con_fname ,
                            pv_con_title ,
                            pv_con_phone1 ,
                            pv_con_ext1 ,
                            pv_con_phone2 ,
                            pv_con_ext2 ,
                            pv_con_fax
                    FROM    dbo.dls_pv_assoc (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'L';


            DECLARE @cur2_cnt INT ,
                @cur2_i INT;

            SET @cur2_i = 1;

				--Get the no. of records for the cursor
            SELECT  @cur2_cnt = COUNT(1)
            FROM    #SWV_cursor_var2;

            WHILE ( @cur2_i <= @cur2_cnt )
                BEGIN
				
                    SELECT  @t_sir_id = dls_sir_id ,
                            @t_alt_id = alt_id ,
                            @t_pv_tax_id = pv_tax_id ,
                            @t_pv_license = pv_license ,
                            @t_pv_lic_state = pv_lic_state ,
                            @t_tin = tin ,
                            @t_pv_first_name = pv_first_name ,
                            @t_pv_middle_init = pv_middle_init ,
                            @t_pv_last_name = pv_last_name ,
                            @t_discipline = discipline ,
                            @t_mal_car = mal_car ,
                            @t_mal_pol_no = mal_pol_no ,
                            @t_mal_prac = mal_prac ,
                            @t_mal_amt = mal_amt ,
                            @t_mal_amt_i = mal_amt_i ,
                            @t_mal_comnt = mal_comnt ,
                            @t_dea_no = dea_no ,
                            @t_dea_cert_dt = dea_cert_dt ,
                            @t_dea_exp_dt = dea_exp_dt ,
                            @t_cds_no = cds_no ,
                            @t_cds_cert_dt = cds_cert_dt ,
                            @t_cds_exp_dt = cds_exp_dt ,
                            @t_cpr_cert_dt = cpr_cert_dt ,
                            @t_cpr_exp_dt = cpr_exp_dt ,
                            @t_prim_fc = prim_fc ,
                            @t_school = school ,
                            @t_grd_date = grd_date ,
                            @t_degree = degree ,
                            @t_ada_mbr = ada_mbr ,
                            @t_district_no = district_no ,
                            @t_pv_dob = pv_dob ,
                            @t_print_dir = print_dir ,
                            @t_race = race ,
                            @t_gender = gender ,
                            @t_num_yr_prac = num_yr_prac ,
                            @t_peer_rv = peer_rv ,
                            @t_pv_stat_eff_date = pv_stat_eff_date ,
                            @t_fc_assoc_fc_id = fc_assoc_fc_id ,
                            @t_fc_assoc_type = fc_assoc_type ,
 @t_fc_assoc_eff = fc_assoc_eff_date ,
                            @t_fc_assoc_exp = fc_assoc_exp_date ,
                            @t_pv_lic_eff_date = pv_lic_eff_date ,
                            @t_pv_lic_exp_date = pv_lic_exp_date ,
                            @t_pv_addr_type = pv_addr_type ,
                            @t_pv_addr_1 = pv_addr_1 ,
                            @t_pv_addr_2 = pv_addr_2 ,
                            @t_pv_addr_zip = pv_addr_zip ,
                            @t_pv_addr_city = pv_addr_city ,
                            @t_pv_addr_state = pv_addr_state ,
                            @t_pv_addr_county = pv_addr_county ,
                            @t_pv_addr_country = pv_addr_country ,
                            @t_pv_addr_mail = pv_addr_mail ,
                            @t_pv_con_type = pv_con_type ,
                            @t_pv_con_lname = pv_con_lname ,
                            @t_pv_con_fname = pv_con_fname ,
                            @t_pv_con_title = pv_con_title ,
                            @t_pv_con_phone1 = pv_con_phone1 ,
                            @t_pv_con_ext1 = pv_con_ext1 ,
                            @t_pv_con_phone2 = pv_con_phone2 ,
                            @t_pv_con_ext2 = pv_con_ext2 ,
                            @t_pv_con_fax = pv_con_fax
                    FROM    #SWV_cursor_var2
                    WHERE   id = @cur2_i;

                    BEGIN

                    --    DECLARE #SWV_cursor_var2 CURSOR;
                        BEGIN TRY
                            SET @s_error = 'N';
                            IF @n_in_transaction = 'N'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'Y';
                                END;
		
                            SET @a_error_no = 10;
                            IF ( ( (@t_ada_mbr IS NULL
                                   OR @t_ada_mbr = '')
                                 )
                                 OR ( LEN(RTRIM(LTRIM(@t_ada_mbr))) = 0 )
                               )
                                UPDATE  dbo.dls_pv_assoc
                                SET     ada_mbr = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 20;
                            IF ( (@t_print_dir IS NULL
                                 OR @t_print_dir = '')
                               )
                                OR LEN(@t_print_dir) = 0
                                UPDATE  dbo.dls_pv_assoc
                                SET     print_dir = 'Y'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 30;
                            IF ( (@t_peer_rv IS NULL
                                 OR @t_peer_rv = '')
                               )
                                OR LEN(@t_peer_rv) = 0
                                UPDATE  dbo.dls_pv_assoc
                                SET     peer_rv = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
          SET @a_error_no = 40;
                            IF ( (@t_fc_assoc_type IS NULL
                                 OR @t_fc_assoc_type = '')
                               )
                                OR LEN(@t_fc_assoc_type) = 0
                                UPDATE  dbo.dls_pv_assoc
                                SET     fc_assoc_type = 'P'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 50;
                  IF ( ( @t_pv_addr_type IS NULL
 OR @t_pv_addr_type = ''
                                 )
                                 OR LEN(@t_pv_addr_type) = 0
                               )
                                AND NOT ( ( @t_pv_addr_zip IS NULL
                                            OR @t_pv_addr_zip = ''
                                          )
                                          OR LEN(@t_pv_addr_zip) = 0
                                        )
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_addr_type = 'L'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 60;
                            IF ( (@t_pv_addr_country IS NULL
                                 OR @t_pv_addr_country = '')
                               )
                                OR LEN(@t_pv_addr_country) = 0
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_addr_country = 'USA'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 70;
                            IF ( (@t_pv_addr_mail IS NULL
                                 OR @t_pv_addr_mail = '')
                               )
                                OR LEN(@t_pv_addr_mail) = 0
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_addr_mail = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 80;
		/* 20121010$$ks - ZIP can have more than one city - need to match up where possible
		 */
                            SET @d_city = NULL;
                            SET @d_state = NULL;
                            SET @d_county = NULL;
                            SELECT  @d_rec_count = COUNT(*)
                            FROM    dbo.usa_zip (NOLOCK)
                            WHERE   zip_code = SUBSTRING(@t_pv_addr_zip, 1, 5);
                            IF @d_rec_count > 0
                                IF @d_rec_count = 1
                                    BEGIN
                                        SELECT  @d_city = city ,
                                                @d_state = state_code ,
                                                @d_county = county
                                        FROM    dbo.usa_zip (NOLOCK)
                                        WHERE   zip_code = SUBSTRING(@t_pv_addr_zip,
                                                              1, 5);
                                        
                     END;
                                ELSE
                                    BEGIN
                                       /*
									    SET #SWV_cursor_var2 = CURSOR  FOR SELECT city, state_code, county
                     FROM dbo.usa_zip
                     WHERE zip_code = SUBSTRING(@t_pv_addr_zip,1,5);
                                        OPEN #SWV_cursor_var2;
                                        FETCH NEXT FROM #SWV_cursor_var2 INTO @d_city,
        @d_state, @d_county;
                                        WHILE @@FETCH_STATUS = 0
										*/
										IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
										DROP TABLE #SWV_cursor_var3

                                        CREATE TABLE  #SWV_cursor_var3
                                            (
											 id INT IDENTITY ,
                                              city CHAR ,
                                              state_code CHAR ,
                                              county CHAR
                                            );

                                        INSERT  INTO #SWV_cursor_var3
                                              ( city ,
                                                  state_code ,
                                                  county
                                                )
                                                SELECT  city ,
                                                        state_code ,
                                                        county
                                                FROM    dbo.usa_zip
                                                WHERE   zip_code = SUBSTRING(@t_pv_addr_zip,
                                                              1, 5);


                                        DECLARE @cur3_cnt INT ,
                                            @cur3_i INT;

                                        SET @cur3_i = 1;

				--Get the no. of records for the cursor
                                        SELECT  @cur3_cnt = COUNT(1)
                                        FROM    #SWV_cursor_var3;

                                        WHILE ( @cur3_i <= @cur3_cnt )
                                            BEGIN
                                                SELECT  @d_city = city ,
                                                        @d_state = state_code ,
                                                        @d_county = county
                                                FROM    #SWV_cursor_var3
                                                WHERE   id = @cur3_i;

                                                IF ( @t_pv_addr_city IS NULL
                                                     OR @t_pv_addr_city = ''
                                                   ) 
					  -- use first city provided 
                                                    GOTO SWL_Label2;
					
                                                IF UPPER(@t_pv_addr_city) = UPPER(@d_city)
                                                    GOTO SWL_Label2;
                                                ELSE
                                                    BEGIN
                                                        SET @d_city = NULL;
                                                        SET @d_state = NULL;
                                                        SET @d_county = NULL;
                                                    END;
                                               /*
											   FETCH NEXT FROM #SWV_cursor_var2 INTO @d_city,
                                                    @d_state, @d_county;
													*/ 
                                                SET @cur3_i = @cur3_i + 1;
                                            END;
                                        SWL_Label2:
                                       -- CLOSE #SWV_cursor_var2;
     END;
			
		
                            SET @a_error_no = 90;
                            IF ( ( ( @t_pv_addr_city IS NULL
                                     OR @t_pv_addr_city = ''
                                   )
                                   AND ( @d_city IS NOT NULL
                                         AND @d_city <> ''
                                       )
                                 )
                                 OR ( UPPER(@t_pv_addr_city) = UPPER(@d_city)
                                      AND @t_pv_addr_city != @d_city
                                    )
                               )
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_addr_city = @d_city
                           WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 100;
                            IF ( @t_pv_addr_state IS NULL
                                 OR @t_pv_addr_state = ''
                               )
                         AND ( @d_state IS NOT NULL
                                      AND @d_state <> ''
                                    )
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_addr_state = @d_state
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 110;
                            IF ( @t_pv_addr_county IS NULL
                                 OR @t_pv_addr_county = ''
                               )
                                AND ( @d_county IS NOT NULL
                                      AND @d_county <> ''
                                    )
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_addr_county = @d_county
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 120;
                            IF ( (@t_pv_con_type IS NULL
                                 OR @t_pv_con_type = '')
                               )
                                OR LEN(@t_pv_con_type) = 0
                                UPDATE  dbo.dls_pv_assoc
                                SET     pv_con_type = 'OF'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            IF @s_error = 'Y'
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'E'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    SET @n_succ_count = @n_succ_count + 1;
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'V'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
		
                            IF @n_process_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                               tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = @n_process_count
                                        - @n_succ_count
                                WHERE   bat_statistics_id = @i_statistics_id;
		
                            IF @n_in_transaction = 'Y'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'N';
          END;
                        END TRY
                        BEGIN CATCH
						IF ERROR_NUMBER() = 50000
						BEGIN
						EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @a_error_no;
						END
						ELSE
						BEGIN
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
             IF @n_in_transaction = 'Y'
                                        BEGIN
                                            
                                            SET @n_in_transaction = 'N';
                                        END;
				
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
			
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @a_error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';
								END
                        END CATCH;
                    END;
                    /*
					FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_alt_id,
                        @t_pv_tax_id, @t_pv_license, @t_pv_lic_state, @t_tin,
                        @t_pv_first_name, @t_pv_middle_init, @t_pv_last_name,
                        @t_discipline, @t_mal_car, @t_mal_pol_no, @t_mal_prac,
                        @t_mal_amt, @t_mal_amt_i, @t_mal_comnt, @t_dea_no,
                        @t_dea_cert_dt, @t_dea_exp_dt, @t_cds_no,
                        @t_cds_cert_dt, @t_cds_exp_dt, @t_cpr_cert_dt,
                        @t_cpr_exp_dt, @t_prim_fc, @t_school, @t_grd_date,
                        @t_degree, @t_ada_mbr, @t_district_no, @t_pv_dob,
                        @t_print_dir, @t_race, @t_gender, @t_num_yr_prac,
                        @t_peer_rv, @t_pv_stat_eff_date, @t_fc_assoc_fc_id,
                        @t_fc_assoc_type, @t_fc_assoc_eff, @t_fc_assoc_exp,
                        @t_pv_lic_eff_date, @t_pv_lic_exp_date,
                        @t_pv_addr_type, @t_pv_addr_1, @t_pv_addr_2,
                        @t_pv_addr_zip, @t_pv_addr_city, @t_pv_addr_state,
                        @t_pv_addr_county, @t_pv_addr_country, @t_pv_addr_mail,
                        @t_pv_con_type, @t_pv_con_lname, @t_pv_con_fname,
                        @t_pv_con_title, @t_pv_con_phone1, @t_pv_con_ext1,
                        @t_pv_con_phone2, @t_pv_con_ext2, @t_pv_con_fax;
						*/
                    SET @cur2_i = @cur2_i + 1;
                END;
           -- CLOSE @cSIR;
            SET @n_error_count = @n_process_count - @n_succ_count;
            EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @n_error_count
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                                   + @n_error_count ),
                                                 ' Failed to update statistics');
                    RETURN;
              END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish After-load process for Batch ',
                                         @a_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



--	set debug file to "/tmp/dlp_al_pv_assoc.trc";
--	trace on;

    END;