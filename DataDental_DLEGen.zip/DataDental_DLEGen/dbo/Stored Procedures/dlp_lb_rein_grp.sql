﻿CREATE PROCEDURE [dbo].[dlp_lb_rein_grp]
    @p_batch_id INT ,
    @p_group_id INT ,
    @p_eff_date DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(128) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_lb_rein_grp
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This procedure supports lockbox update processing, 
--           dlp_up_lockbox(), of DataLoad for the DataDental Alloation module,
--           a product of STC.  This SP reinstates individual groups that had
--           been terminated and meet the payment tolerance.
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--   11/25/98   G. Albers    took gp_ch_rein(), gp_update_status(),
--                           gp_update_activity(), unknown_facility()
--                           from DD to create this SP for DataLoad.  
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:16:16 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @cnt_rlmbgrpl INT;

        DECLARE @iMemberId INT;
        DECLARE @iNewId INT;
        DECLARE @iNewMbGrPlId INT;
        DECLARE @iNewMsi INT;
        DECLARE @iPlanId INT;
        DECLARE @iTmpMbGrPlId INT;
        DECLARE @iTmpHMSI INT;

        DECLARE @n_msi INT;
        DECLARE @n_datetime DATETIME;
        DECLARE @n_sub_count INT;
        DECLARE @n_mem_count INT;
        DECLARE @n_unknown_fac INT;
        DECLARE @n_action_code CHAR(2);
        DECLARE @n_plan_type CHAR(2);
        DECLARE @n_plan_opt CHAR(3);
        DECLARE @n_plan_id INT;
        DECLARE @n_status_id INT;

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(128);

        DECLARE @n_reason_code CHAR(2);
        DECLARE @n_subsys_code CHAR(2);
        DECLARE @n_act_mast_id INT;
        DECLARE @v_mbgrpl_id INT;

        DECLARE @PlanOpt CHAR(3);
        DECLARE @ls_user CHAR(20);
        DECLARE @SWV_cursor_var1 CURSOR;

	--------------------------------------------------------------------
	-- get all CURRENT rate code rows that need to be added into 
	-- temporary table t_gpchst_mbrt 
	-------------------------------------------------------------------- 
-------------------------------------------------------------------
-- Changed 8/8/97 ksavage
------------------------------------------------------------------
        DECLARE @SWV_cursor_var2 CURSOR;
        DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @cur1 CURSOR;
        DECLARE @SWV_cursor_var4 CURSOR;
        DECLARE @SWV_cursor_var5 CURSOR;

   -- insert new mb_gr_pl record (by locking table)
   ----   LOCK TABLE rlmbgrpl IN EXCLUSIVE MODE;

        DECLARE @SWV_cursor_var6 CURSOR;



        SET NOCOUNT ON;
        BEGIN TRY
            SET @n_datetime = GETDATE();
            SET @ls_user = CONCAT('dl', @p_batch_id);

---------------------------------------------------
-- Create temporary tables
---------------------------------------------------
            CREATE TABLE #t_gpchst_pl
                (
                  plan_id INT ,
                  ins_type CHAR(3) ,
                  ins_opt CHAR(3) ,
                  eff_date DATE ,
                  exp_date DATE ,
                  new_id INT IDENTITY
                             NOT NULL
                             PRIMARY KEY
                ); 
            CREATE INDEX t_gpchst_pl_1 ON #t_gpchst_pl 
            (plan_id);
            CREATE TABLE #t_gpchst_gppl
                (
                  new_id INT IDENTITY
                             NOT NULL
                             PRIMARY KEY ,
                  new_mb_gr_pl_id INT ,
                  flag INT ,
                  mb_gr_pl_id INT ,
                  member_id INT ,
                  group_id INT ,
                  plan_id INT ,
                  sign_flag CHAR(1) ,
                  cobra_flag CHAR(1) ,
                  rec_date DATE ,
                  eff_gr_pl DATE NOT NULL ,
                  exp_gr_pl DATE ,
                  action_code CHAR(2) NOT NULL ,
                  h_datetime DATETIME NOT NULL ,
                  h_msi INT NOT NULL ,
                  h_action CHAR(2) NOT NULL ,
                  h_user CHAR(10) NOT NULL
                ); 
            CREATE UNIQUE INDEX t_gpchst_gppl_1 ON #t_gpchst_gppl 
            (mb_gr_pl_id);
            CREATE INDEX t_gpchst_gppl_2 ON #t_gpchst_gppl 
            (member_id);
            CREATE INDEX t_gpchst_gppl_3 ON #t_gpchst_gppl 
            (plan_id);
            CREATE TABLE #t_gpchst_mbrt
                (
                  rlmbrt_id INT ,
                  mb_gr_pl_id INT ,
                  rate_code CHAR(2) ,
                  eff_rt_date DATE NOT NULL ,
                  exp_rt_date DATE ,
                  action_code CHAR(2) NOT NULL ,
                  h_datetime DATETIME NOT NULL ,
                  h_msi INT NOT NULL ,
                  h_action CHAR(2) NOT NULL ,
                  h_user CHAR(10) NOT NULL ,
                  flag INT ,
                  new_id INT IDENTITY
                             NOT NULL
                             PRIMARY KEY
                ); 
            CREATE INDEX t_gpchst_mbrt_1 ON #t_gpchst_mbrt 
            (flag, 
            new_id);
            CREATE UNIQUE INDEX t_gpchst_mbrt_2 ON #t_gpchst_mbrt 
            (mb_gr_pl_id);

---------------------------------------------------
-- Create temporary table t_gpchst_plfc
---------------------------------------------------
            CREATE TABLE #t_gpchst_plfc
                (
                  rlplfc_id INT ,
                  mb_gr_pl_id INT ,
                  member_id INT ,
                  facility_id INT ,
                  eff_date DATE NOT NULL ,
                  exp_date DATE ,
                  action_code CHAR(2) NOT NULL ,
                  h_datetime DATETIME NOT NULL ,
                  h_msi INT NOT NULL ,
                  h_action CHAR(2) NOT NULL ,
                  h_user CHAR(10) NOT NULL ,
                  flag INT ,
                  new_id INT IDENTITY
                             NOT NULL
                             PRIMARY KEY
                ); 
            CREATE INDEX t_gpchst_plfc_1 ON #t_gpchst_plfc 
            (mb_gr_pl_id);
            CREATE INDEX t_gpchst_plfc_2 ON #t_gpchst_plfc 
            (rlplfc_id);
            CREATE INDEX t_gpchst_plfc_3 ON #t_gpchst_plfc 
            (facility_id);
            CREATE INDEX t_gpchst_plfc_4 ON #t_gpchst_plfc 
            (member_id);
            CREATE TABLE #t_gpchst_fc ( plan_id INT,      -- LIKE net_plans.plan_id,
                                        fc_id INT       -- LIKE net_facility.fc_id,
                                        ); 
            CREATE INDEX t_gpchst_fc_1 ON #t_gpchst_fc 
            (plan_id, 
            fc_id);

---------------------------------------------------
-- Get all group & plan as of p_eff_date AND 
-- insert data to table t_gpchst_pl
---------------------------------------------------
            INSERT  INTO #t_gpchst_pl
                    SELECT  dbo.[plan].plan_id ,
                            dbo.[plan].ins_type ,
                            dbo.[plan].ins_opt ,
                            dbo.rel_gppl.eff_date ,
                            dbo.rel_gppl.exp_date
                    FROM    dbo.rel_gppl (NOLOCK) ,
                            dbo.[plan] (NOLOCK)
                    WHERE   dbo.[plan].plan_id = dbo.rel_gppl.plan_id
                            AND dbo.rel_gppl.group_id = @p_group_id
                            AND ( ( dbo.rel_gppl.eff_date <= @p_eff_date
                                    AND ( dbo.rel_gppl.exp_date > @p_eff_date
                                          OR dbo.rel_gppl.exp_date IS NULL
                                        )
                                  )
                                  OR ( dbo.rel_gppl.eff_date > @p_eff_date
                                       AND ( dbo.rel_gppl.exp_date > dbo.rel_gppl.eff_date
                                             OR dbo.rel_gppl.exp_date IS NULL
                                           )
                                     )
                                );
            SET @n_action_code = 'GR';


-- Not an Employer Group!
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT DISTINCT(plan_id)
   
      FROM #t_gpchst_pl;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @iPlanId;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    INSERT  INTO #t_gpchst_gppl
                            SELECT DISTINCT
                                    1 ,
                                    mgp.mb_gr_pl_id ,
                                    mgp.member_id ,
                                    mgp.group_id ,
                                    mgp.plan_id ,
                                    hmgp.sign_flag ,
                                    hmgp.cobra_flag ,
                                    mgp.rec_date ,
                                    @p_eff_date ,
                                    hmgp.exp_gr_pl ,
                                    @n_action_code ,
                                    @n_datetime ,
                                    mgp.h_msi ,
                                    @n_action_code ,
                                    --ORIGINAL_LOGIN()
									mgp.h_user
                            FROM    dbo.rlmbgrpl mgp ( NOLOCK ) ,
                                    dbo.h_rlmbgrpl hmgp ( NOLOCK )
                            WHERE   mgp.group_id = @p_group_id
                                    AND mgp.plan_id = @iPlanId
                                    AND mgp.h_msi = hmgp.new_msi
                                    AND mgp.h_datetime IN (
                                    SELECT  MAX(mgp.h_datetime)
                                    FROM    dbo.rlmbgrpl mgp ( NOLOCK )
                                    WHERE   mgp.group_id = @p_group_id
                                    GROUP BY mgp.group_id ,
                                            mgp.plan_id )
                                    AND ( mgp.exp_gr_pl = @p_eff_date
                                          OR ( mgp.eff_gr_pl > @p_eff_date
                                               AND mgp.exp_gr_pl IS NOT NULL
                                               AND mgp.eff_gr_pl = mgp.exp_gr_pl
                                             )
                                        );
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @iPlanId;
                END;
            CLOSE @SWV_cursor_var1;   -- foreach with hold SELECT max(distinct(plan_id))


-----------------------------------------------------------------------
-- Update statistics for t_gpchst_gppl
-----------------------------------------------------------------------
            UPDATE STATISTICS   #t_gpchst_gppl;


------------------------------------------
-- Get activity log reason code ...
------------------------------------------
            SELECT  @n_subsys_code = b.subsys_code ,
                    @n_act_mast_id = a.act_mast_id ,
                    @n_reason_code = c.reason_code
            FROM    dbo.act_mast a ( NOLOCK ) ,
                    dbo.mod_def b ( NOLOCK ) ,
                    dbo.reas_mast c ( NOLOCK )
            WHERE   ( a.act_mast_id = c.act_mast_id
                      AND c.reason_code = 'DF'
                    )
                    AND a.activity_flag = 'Y'
                    AND ( a.mod_id = b.mod_id
                          AND b.subsys_code = 'GP'
                          AND b.descr = 'Group Reinstate'
                        );
            IF @@rowcount = 0
                SELECT  @n_subsys_code = NULL ,
                        @n_act_mast_id = NULL ,
                        @n_reason_code = NULL;
            IF ( ( @n_subsys_code IS NULL
                   OR @n_subsys_code = ''
                 )
                 OR @n_act_mast_id IS NULL
                 OR ( @n_reason_code IS NULL
                      OR @n_reason_code = ''
                    )
               )
                RAISERROR('Failed to look up reason code for activity log!',16,1);


--------------------------------------------
-- Get subscriber count for this group
--------------------------------------------
            SELECT  @n_sub_count = COUNT(DISTINCT member_id) ,
                    @cnt_rlmbgrpl = COUNT(*)
            FROM    #t_gpchst_gppl;
            IF @n_sub_count = 0
                OR @n_sub_count IS NULL
                RAISERROR('Failed to find member for group to be reinstated!',16,1);


-----------------------------------------------------------------------
-- There is subscriber for this group!
-- Get all members's rate code (rlmbrt) AND plan/facilities (rlplfc) 
-- rows that need to be added
-----------------------------------------------------------------------
            SET @SWV_cursor_var2 = CURSOR  FOR SELECT mb_gr_pl_id
   
      FROM #t_gpchst_gppl;
            OPEN @SWV_cursor_var2;
            FETCH NEXT FROM @SWV_cursor_var2 INTO @iTmpMbGrPlId;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    INSERT  INTO #t_gpchst_mbrt
                            ( rlmbrt_id ,
                              mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              exp_rt_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user ,
                              flag
                            )
                            SELECT  mbrt.rlmbrt_id ,
                                    mbrt.mb_gr_pl_id ,
                                    mbrt.rate_code ,
                                    @p_eff_date ,
                                    mbrt.exp_rt_date ,
                                    @n_action_code ,
                                    @n_datetime ,
                                    mbrt.h_msi ,
                                    @n_action_code ,
                                    --ORIGINAL_LOGIN() ,
									mbrt.h_user,
                                    1
                            FROM    dbo.rlmbrt mbrt ( NOLOCK )
                            WHERE   mbrt.mb_gr_pl_id = @iTmpMbGrPlId
                                    AND ( mbrt.eff_rt_date <= @p_eff_date
                                          AND ( mbrt.exp_rt_date > @p_eff_date
                                                OR mbrt.exp_rt_date IS NULL
                                              )
                                        );
                    INSERT  INTO #t_gpchst_mbrt
                            ( rlmbrt_id ,
                              mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              exp_rt_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
               h_user ,
                              flag
                            )
                            SELECT  mbrt.rlmbrt_id ,
                                    mbrt.mb_gr_pl_id ,
                                    mbrt.rate_code ,
                                    mbrt.eff_rt_date ,
                                    mbrt.exp_rt_date ,
                                    @n_action_code ,
                                    @n_datetime ,
                                    mbrt.h_msi ,
                                    @n_action_code ,
                                    --ORIGINAL_LOGIN() ,
									mbrt.h_user,
                                    2
                            FROM    dbo.rlmbrt mbrt ( NOLOCK )
                            WHERE   mbrt.mb_gr_pl_id = @iTmpMbGrPlId
                                    AND ( mbrt.eff_rt_date > @p_eff_date
                                          AND ( mbrt.exp_rt_date > mbrt.eff_rt_date
                                                OR mbrt.exp_rt_date IS NULL
                                              )
                                        );

   --------------------------------------------------------------------
   -- get all CURRENT plan/fac rows that need to be added into  
   -- temporary table t_gpchst_plfc 
   -------------------------------------------------------------------- 
                    INSERT  INTO #t_gpchst_plfc
                            ( rlplfc_id ,
                              mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              exp_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user ,
                              flag
                            )
                            SELECT  plfc.rlplfc_id ,
                                    plfc.mb_gr_pl_id ,
                                    plfc.member_id ,
                                    plfc.facility_id ,
                                    @p_eff_date ,
                                    plfc.exp_date ,
                                    @n_action_code ,
                                    @n_datetime ,
                                    plfc.h_msi ,
                                    plfc.h_action ,
                                    --ORIGINAL_LOGIN() ,
									plfc.h_user,
                                    1
                            FROM    dbo.rlplfc plfc ( NOLOCK )
                            WHERE   mb_gr_pl_id = @iTmpMbGrPlId
                                    AND ( plfc.eff_date <= @p_eff_date
                                          AND ( plfc.exp_date > @p_eff_date
                                                OR plfc.exp_date IS NULL
                                              )
                                        );

   --------------------------------------------------------------------
   -- get all FUTURE plan/fac rows that need to be added into 
   -- temporary table t_gpchst_plfc 
   -------------------------------------------------------------------- 
                    INSERT  INTO #t_gpchst_plfc
                            ( rlplfc_id ,
                              mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              exp_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user ,
                              flag
                            )
                            SELECT  plfc.rlplfc_id ,
                                    plfc.mb_gr_pl_id ,
                             plfc.member_id ,
                                    plfc.facility_id ,
                                    plfc.eff_date ,
                                    plfc.exp_date ,
                                    @n_action_code ,
                                    @n_datetime ,
                                    plfc.h_msi ,
                                    plfc.h_action ,
                                    --ORIGINAL_LOGIN() ,
									plfc.h_user,
                                    2
                            FROM    dbo.rlplfc plfc ( NOLOCK )
                            WHERE   mb_gr_pl_id = @iTmpMbGrPlId
                                    AND ( plfc.eff_date > @p_eff_date
                                          AND ( plfc.exp_date > plfc.eff_date
                                                OR plfc.exp_date IS NULL
                                              )
                                        );
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @iTmpMbGrPlId;
                END;
            CLOSE @SWV_cursor_var2;   -- get all members's rate code AND plan/facilities

-----------------------------------------------------------------------
-- Update statistics for t_gpchst_mbrt, t_gpchst_plfc
-----------------------------------------------------------------------
            UPDATE STATISTICS   #t_gpchst_mbrt;
            UPDATE STATISTICS   #t_gpchst_plfc;

-------------------------------------------------------------------
-- Create plan/network facility to temporary table t_gpchst_fc
-------------------------------------------------------------------
            SELECT  @n_mem_count = COUNT(DISTINCT member_id)
            FROM    #t_gpchst_plfc;

-- Determine which facilities accept which plan as of the reinstate date!
------------------------------------------------------------------------
--- Changed logic 8/8/1997 ksavage
-----------------------------------------------------------------------
   -- PlanOpt = HMO, RFS

            SET @SWV_cursor_var3 = CURSOR  FOR SELECT DISTINCT t.plan_id, p.ins_opt
   
      FROM #t_gpchst_pl t, dbo.[plan] p (NOLOCK)
      WHERE t.plan_id = p.plan_id;
            OPEN @SWV_cursor_var3;
            FETCH NEXT FROM @SWV_cursor_var3 INTO @iPlanId, @PlanOpt;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    IF @PlanOpt IN ( 'HMO', 'RFS' )
                        INSERT  INTO #t_gpchst_fc
                                SELECT  @iPlanId ,
                                        nf.fc_id
                                FROM    dbo.net_facility nf ( NOLOCK ) ,
                                        dbo.net_plans np ( NOLOCK )
                                WHERE   np.plan_id = @iPlanId
                                        AND nf.fc_id IN ( SELECT DISTINCT
                                                              fc_id
                                                          FROM
                                                              #t_gpchst_plfc )
                                        AND nf.net_id = np.fc_net_id
                                        AND nf.con_type = np.con_type
                                        AND nf.eff_date <= @p_eff_date
                                        AND np.exp_date IS NULL
                                        AND np.eff_date <= @p_eff_date
                                        AND np.exp_date IS NULL
                                        AND NOT EXISTS ( SELECT
                                                              *
                                                         FROM dbo.fc_plans fp ( NOLOCK )
                                                         WHERE
                                                              nf.net_fc_id = fp.net_facility
                                                              AND nf.con_type = fp.con_type
                            AND nf.ovr_ride = fp.ovr_ride
                                                              AND np.plan_id = fp.plan_id
                                                              AND fp.eff_date = fp.exp_date
                                                              AND fp.ovr_ride = 'Y' )
                                        AND EXISTS ( SELECT *
                                                     FROM   dbo.fcstat (NOLOCK) ,
                                                            dbo.typ_table (NOLOCK)
                                                     WHERE  dbo.fcstat.facility_id = nf.fc_id
                                                            AND ( dbo.fcstat.eff_date <= @p_eff_date
                                                              AND ( dbo.fcstat.exp_date > @p_eff_date
                                                              OR dbo.fcstat.exp_date IS NULL
                                                              )
                                                              )
                                                            AND dbo.typ_table.subsys_code = 'FC'
                                                            AND dbo.typ_table.tab_name = 'fcstat'
                                                            AND dbo.typ_table.code = dbo.fcstat.status
                                                            AND dbo.typ_table.action IN (
                                                            'AC', 'CL', 'UF' ) );
                    FETCH NEXT FROM @SWV_cursor_var3 INTO @iPlanId, @PlanOpt;
                END;
            CLOSE @SWV_cursor_var3;    -- Retrieve Plan 

-------------------------------------------------
-- Get new msi number (lock table sysdatetime!)
-------------------------------------------------

--LOCK TABLE sysdatetime IN EXCLUSIVE MODE;

-- Update current msi w/ new number
            UPDATE  dbo.sysdatetime
            SET     msi = msi + @cnt_rlmbgrpl;

-- Get current msi number
            SELECT  @n_msi = msi
            FROM    dbo.sysdatetime;
            IF @n_msi IS NULL
                RAISERROR('Failed to update system msi number!',16,1);

            SET @n_msi = @n_msi - @cnt_rlmbgrpl;

-----------------------------------------------------------------------
-- Update msi number in t_gpchst_gppl, t_gpchst_mbrt, t_gpchst_plfc
-----------------------------------------------------------------------
            SET @cur1 = CURSOR  FOR SELECT mb_gr_pl_id, new_id
   
      FROM #t_gpchst_gppl;
            OPEN @cur1;
            FETCH NEXT FROM @cur1 INTO @iTmpMbGrPlId, @iNewId;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    SET @iNewMsi = @n_msi + @iNewId;
                    UPDATE  #t_gpchst_gppl
                    SET     h_msi = @iNewMsi
                    WHERE CURRENT OF @cur1;
                    UPDATE  #t_gpchst_mbrt
                    SET     h_msi = @iNewMsi
                    WHERE   mb_gr_pl_id = @iTmpMbGrPlId;
                    UPDATE  #t_gpchst_plfc
                    SET     h_msi = @iNewMsi
                    WHERE   mb_gr_pl_id = @iTmpMbGrPlId;
                    FETCH NEXT FROM @cur1 INTO @iTmpMbGrPlId, @iNewId;
                END;
            CLOSE @cur1;

-----------------------------------------------------------
-- Set to unknown_facility for those old facilities that 
-- do not accept the new plan
-----------------------------------------------------------
-- First go through each plan ...
            SET @SWV_cursor_var4 = CURSOR  FOR SELECT DISTINCT plan_id, ins_opt
   
      FROM #t_gpchst_pl tpl;
            OPEN @SWV_cursor_var4;
            FETCH NEXT FROM @SWV_cursor_var4 INTO @n_plan_id, @n_plan_opt;
            WHILE @@FETCH_STATUS = 0
                BEGIN
      --****************VASANTHA*********************--
      --Added foreach to perform this only for n_plan_id
      --**********************************************--
      
   
   --- Vasantha ----
                    IF ( @n_plan_opt = 'FFS' )
                        BEGIN
                            SET @SWV_cursor_var5 = CURSOR  FOR SELECT mb_gr_pl_id
         
            FROM #t_gpchst_gppl
            WHERE plan_id = @n_plan_id;
                            OPEN @SWV_cursor_var5;
                            FETCH NEXT FROM @SWV_cursor_var5 INTO @v_mbgrpl_id;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    UPDATE  #t_gpchst_plfc
                                    SET     facility_id = NULL
                                    WHERE   mb_gr_pl_id = @v_mbgrpl_id
                                            AND EXISTS ( SELECT
                                                              *
                                                         FROM #t_gpchst_fc a
                                                         WHERE
                                                              a.plan_id = @n_plan_id
                                                              AND a.fc_id = facility_id );
                                    FETCH NEXT FROM @SWV_cursor_var5 INTO @v_mbgrpl_id;
                                END;
                            CLOSE @SWV_cursor_var5;
                        END;
                    ELSE
                        IF @n_plan_opt IN ( 'HMO', 'RFS' )
                            BEGIN
                                SELECT  @n_unknown_fac = MAX(dbo.facility.fc_id)
                                FROM    dbo.facility (NOLOCK) ,
                                        dbo.fcstat (NOLOCK) ,
                                        dbo.[plan] (NOLOCK)
                                WHERE   dbo.[plan].plan_id = @n_plan_id
                                        AND dbo.fcstat.facility_id = dbo.facility.fc_id
                                        AND ( dbo.fcstat.eff_date <= @p_eff_date
                                              AND ( dbo.fcstat.exp_date IS NULL
                                                    OR dbo.fcstat.exp_date > @p_eff_date
                                                  )
                                            )
                                        AND dbo.fcstat.status = 'UF'
                                        AND dbo.[plan].ins_type = dbo.facility.fc_type;
                                IF @@rowcount = 0
                                    SELECT  @n_unknown_fac = NULL;
                                IF @n_unknown_fac IS NULL
                                    RAISERROR('Unknown Facility for specified plan. Facility was not found',
               16,1);
      

      -- check invalid facility AND set it to unknown facility

                                UPDATE  #t_gpchst_plfc
                                SET     facility_id = @n_unknown_fac
                                WHERE   mb_gr_pl_id IN (
                                        SELECT  mb_gr_pl_id
                                        FROM    #t_gpchst_gppl t
                                        WHERE   t.plan_id = @n_plan_id )
                                        AND NOT EXISTS ( SELECT
                                                              *
                                                         FROM #t_gpchst_fc
                                                         WHERE
                                                              plan_id = @n_plan_id
                                                              AND fc_id = facility_id );
                            END;
                    FETCH NEXT FROM @SWV_cursor_var4 INTO @n_plan_id,
                        @n_plan_opt;
                END;
            CLOSE @SWV_cursor_var4;   -- foreach with hold SELECT plan_id, ins_opt 


--------------------------------------------
-- Go through each member
--------------------------------------------
            SET @SWV_cursor_var6 = CURSOR  FOR SELECT new_id, mb_gr_pl_id, member_id, h_msi
   
      FROM #t_gpchst_gppl tgp;
            OPEN @SWV_cursor_var6;
            FETCH NEXT FROM @SWV_cursor_var6 INTO @iNewId, @iTmpMbGrPlId,
                @iMemberId, @iTmpHMSI;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    INSERT  INTO dbo.rlmbgrpl
                            ( member_id ,
                              group_id ,
                              plan_id ,
                              sign_flag ,
                              cobra_flag ,
                              rec_date ,
                              eff_gr_pl ,
                              exp_gr_pl ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user
                            )
                            SELECT  member_id ,
                                    group_id ,
                                    plan_id ,
                                    sign_flag ,
                                    cobra_flag ,
                                    rec_date ,
                                    eff_gr_pl ,
                                    exp_gr_pl ,
                                    action_code ,
                                    h_datetime ,
                                    h_msi ,
                                    h_action ,
                                    h_user
                            FROM    #t_gpchst_gppl
                            WHERE   #t_gpchst_gppl.new_id = @iNewId;
                    SELECT  @iNewMbGrPlId = mb_gr_pl_id
                    FROM    dbo.rlmbgrpl (NOLOCK)
                    WHERE   h_msi = @iTmpHMSI;
                    IF @@rowcount = 0
                        SELECT  @iNewMbGrPlId = NULL;

   -- insert new rlmbrt record
                    INSERT  INTO dbo.rlmbrt
                            ( mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              exp_rt_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user
                            )
                            SELECT  @iNewMbGrPlId ,
                                    rate_code ,
                                    eff_rt_date ,
                                    exp_rt_date ,
                                    action_code ,
                                    h_datetime ,
                                    h_msi ,
                                    h_action ,
                                    h_user
                            FROM    #t_gpchst_mbrt
                            WHERE   mb_gr_pl_id = @iTmpMbGrPlId;

   -- insert new rlplfc record
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              exp_date ,
                              action_code ,
                              h_datetime ,
                              h_msi ,
                              h_action ,
                              h_user
                            )
                            SELECT  @iNewMbGrPlId ,
                                    member_id ,
                                    facility_id ,
                                    eff_date ,
                                    exp_date ,
                                    action_code ,
                                    h_datetime ,
                                    h_msi ,
                                    h_action ,
                                    h_user
                            FROM    #t_gpchst_plfc
                            WHERE   mb_gr_pl_id = @iTmpMbGrPlId;

   -- Log the activity for member
                    INSERT  INTO dbo.act_log
                            ( sub_sys ,
                              act_mast_id ,
                              event_sys_id ,
                              reason_code ,
                              log_user ,
                              log_date ,
                              log_time
                            )
                    VALUES  ( 'MB' ,
                              @n_act_mast_id ,
                              @iMemberId ,
                              @n_reason_code ,
                              @ls_user ,
                              @n_datetime ,
                              @n_datetime
                            );
                    FETCH NEXT FROM @SWV_cursor_var6 INTO @iNewId,
                        @iTmpMbGrPlId, @iMemberId, @iTmpHMSI;
                END;
            CLOSE @SWV_cursor_var6;

----------------------------------------
-- Valid group_status?
----------------------------------------
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.typ_table
                            WHERE   subsys_code = 'GP'
                                    AND tab_name = 'group_status'
                                    AND code = 'A4' )
                RAISERROR('Invalid status code <A4>',16,1);



----------------------------------------
--  Update group table
----------------------------------------
            UPDATE  dbo.[group]
            SET     h_user = @ls_user ,
                    h_datetime = @n_datetime ,
                    paid_to_date = @p_eff_date ,
                    next_renew_date = DATEADD(MONTH,
                                              dbo.[group].renewal_intervl,
                                              @p_eff_date) ,
                    next_enrol_date = DATEADD(MONTH,
                                              dbo.[group].renewal_intervl,
                                              @p_eff_date)
            WHERE   group_id = @p_group_id;


----------------------------------------
--  Update group_status table
----------------------------------------
            SELECT  @n_status_id = group_status_id
            FROM    dbo.group_status (NOLOCK)
            WHERE   group_id = @p_group_id
                    AND exp_date IS NULL;
            IF @@rowcount = 0
                SELECT  @n_status_id = NULL;
            IF @n_status_id IS NOT NULL
                BEGIN
                    UPDATE  dbo.group_status
                    SET     exp_date = @p_eff_date ,
                            h_user = @ls_user ,
                            h_datetime = @n_datetime
                    WHERE   group_status_id = @n_status_id;
                    INSERT  INTO dbo.group_status
                            ( group_id ,
                              group_status ,
                              reason_code ,
                              eff_date ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @p_group_id ,
                              'A4' ,
                              NULL ,
                              @p_eff_date ,
                              @n_datetime ,
                              @ls_user
                            );
                END;


----------------------------------------------------
-- Log the activity
----------------------------------------------------
            INSERT  INTO dbo.act_log
                    ( sub_sys ,
                      act_mast_id ,
                      event_sys_id ,
             reason_code ,
                      log_user ,
                      log_date ,
                      log_time
                    )
            VALUES  ( @n_subsys_code ,
                      @n_act_mast_id ,
                      @p_group_id ,
                      @n_reason_code ,
                      @ls_user ,
                      @n_datetime ,
                      @n_datetime
                    );

----------------------------------------------------------
-- Delete temporary tables if exists
----------------------------------------------------------

            DROP TABLE #t_gpchst_pl;
            DROP TABLE #t_gpchst_gppl;
            DROP TABLE #t_gpchst_mbrt;
            DROP TABLE #t_gpchst_plfc;
            DROP TABLE #t_gpchst_fc;
            SET @SWP_Ret_Value = @n_sub_count;
            SET @SWP_Ret_Value1 = @n_mem_count;
            SET @SWP_Ret_Value2 = CONCAT('Group ', @p_group_id,
                                         ' has been reinstated');
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            DROP TABLE #t_gpchst_pl;
            DROP TABLE #t_gpchst_gppl;
            DROP TABLE #t_gpchst_mbrt;
            DROP TABLE #t_gpchst_plfc;
            DROP TABLE #t_gpchst_fc;
            IF ( @n_error_no = -746 )
                BEGIN
                    SET @SWP_Ret_Value = @n_error_no;
                    SET @SWP_Ret_Value1 = @n_isam_error;
                    SET @SWP_Ret_Value2 = @n_error_text;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @n_error_no;
                    SET @SWP_Ret_Value2 = @n_error_text;
                    RETURN;
                END;
        END CATCH;
        SET NOCOUNT OFF;


-------------------------------------------------------------------------------
-- get current date --
    END;