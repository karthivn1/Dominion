﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_GetClaimReq 0,'','',20171240001515,1016678,'','','',0,null,'','','',null
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_GetClaimReq]
@ClaimID INT,@ClaimAltID NVARCHAR(20),@ClaimDocNo NVARCHAR(100),@ClaimNo NVARCHAR(max),
@memberID INT,@SSN NVARCHAR(11),@SubAltID NVARCHAR(20),@SubSourceID NVARCHAR(20),@DepSW bit,
@PatID INT,@PatSSN NVARCHAR(11),@patSourceID NVARCHAR(20),@PatAltID NVARCHAR(20),@PatMemberCode NVARCHAR(20)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets FROM
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempErrorTable') IS NOT NULL
    DROP TABLE #tempErrorTable
IF OBJECT_ID('tempdb..#tempClaim') IS NOT NULL
    DROP TABLE #tempClaim
IF OBJECT_ID('tempdb..#tempSub') IS NOT NULL
    DROP TABLE #tempSub
IF OBJECT_ID('tempdb..#tempPatient') IS NOT NULL
    DROP TABLE #tempPatient
IF OBJECT_ID('tempdb..#tempClaimInfo') IS NOT NULL
    DROP TABLE #tempClaimInfo

CREATE TABLE #tempErrorTable(ID INT IDENTITY(1,1),ErrorName NVARCHAR(50),ErrorDesc NVARCHAR(1000))	
CREATE TABLE #tempClaim(ClaimID INT,mbgrpl_id INT,rlplfc_id INT)
CREATE TABLE #tempSub(memberID INT,SSN NVARCHAR(11) null,SubAltID NVARCHAR(20) null,SubSourceID NVARCHAR(20) null)
CREATE TABLE #tempPatient(member_id INT null) 

--drop table #tempClaim
BEGIN TRY

IF @ClaimID>0
BEGIN
IF EXISTS(SELECT claim_id 
				FROM claim_h 
				WHERE  claim_id = @ClaimID)
				BEGIN
					INSERT INTO #tempClaim
					SELECT c.claim_id,c.mbgrpl_id,c.rlplfc_id
					FROM claim_h c
					WHERE  c.claim_id = @ClaimID
				END
END
ELSE IF LEN(@ClaimAltID)>0
BEGIN
IF EXISTS(SELECT c.claim_id 
				FROM claim_h c
				WHERE  c.alt_id= @ClaimAltID)
				BEGIN
					INSERT INTO #tempClaim
					SELECT c.claim_id,c.mbgrpl_id,c.rlplfc_id
					FROM claim_h c
					WHERE c.alt_id= @ClaimAltID
				END
END
ELSE IF LEN(@ClaimDocNo)>0
BEGIN
IF EXISTS(SELECT c.claim_id 
				FROM claim_h c
				WHERE  c.document_no= @ClaimDocNo)
				BEGIN
					INSERT INTO #tempClaim
					SELECT c.claim_id,c.mbgrpl_id,c.rlplfc_id
					FROM claim_h c
					WHERE c.document_no= @ClaimDocNo
				END
END
ELSE IF LEN(@ClaimNo)>0
BEGIN
IF EXISTS(SELECT c.claim_id 
				FROM claim_h c
				WHERE  c.claim_no= CAST(@ClaimNo as float))
				BEGIN
					INSERT INTO #tempClaim
					SELECT c.claim_id,c.mbgrpl_id,c.rlplfc_id
					FROM claim_h c
					WHERE c.claim_no= CAST(@ClaimNo as float)
				END
END
IF @memberID>0
BEGIN

IF EXISTS (SELECT member_id FROM member m
	WHERE m.member_id = m.family_id AND m.member_id=@memberID)
	BEGIN
		INSERT INTO #tempSub 
		SELECT m.member_id,m.member_ssn,m.alt_id,m.source_id FROM member m
		WHERE m.member_id = m.family_id AND m.member_id=@memberID 

	END

END
ELSE IF LEN(@SSN)>0
BEGIN

IF EXISTS (SELECT member_id FROM member m
	WHERE m.member_id = m.family_id AND m.member_ssn=@SSN )
	BEGIN
		INSERT INTO #tempSub 
		SELECT m.member_id,m.member_ssn,m.alt_id,m.source_id FROM member m
		WHERE m.member_id = m.family_id AND m.member_ssn=@SSN

	END

END
ELSE IF LEN(@SubAltID)>0
BEGIN

IF EXISTS (SELECT member_id FROM member m
	WHERE m.member_id = m.family_id AND m.alt_id=@SubAltID )
	BEGIN
		INSERT INTO #tempSub 
		SELECT m.member_id,m.member_ssn,m.alt_id,m.source_id FROM member m
		WHERE m.member_id = m.family_id AND m.alt_id=@SubAltID

	END

END
ELSE IF LEN(@SubSourceID)>0
BEGIN

IF EXISTS (SELECT member_id FROM member m
	WHERE m.member_id = m.family_id AND m.source_id=@SubSourceID )
	BEGIN
		INSERT INTO #tempSub 
		SELECT m.member_id,m.member_ssn,m.alt_id,m.source_id FROM member m
		WHERE m.member_id = m.family_id AND m.source_id=@SubSourceID

	END

END
 
DECLARE @claimCount INT=0

SELECT @claimCount=COUNT(DISTINCT t.ClaimID)
             FROM #tempClaim t
			 JOIN rlmbgrpl r ON r.mb_gr_pl_id=t.mbgrpl_id 
	    	 JOIN #tempSub s ON s.memberID=r.member_id

IF @claimCount=0
BEGIN
	   INSERT INTO #tempErrorTable VALUES ('ClaimInput','No Claims were identified in the database with the given options');
	   THROW 51000,'User Validation Faild',1
END

IF @claimCount>1
BEGIN
	   INSERT INTO #tempErrorTable VALUES ('ClaimInput','Mutiple claims were identified in the database with the given options');
	   THROW 51000,'User Validation Faild',1
END
             
 SELECT c.claim_id claim_id,
		rmg.member_id subscriber,
		rmg.group_id group_id,
		rmg.plan_id plan_id,
		rmg.mb_gr_pl_id mb_gr_pl_id,  
		c.fc_id facility_id,  
		c.prv_id provider_id,  
		rpf.member_id patient  
		INTO #tempClaimInfo
		FROM #tempClaim t
		JOIN claim_h c ON c.claim_id=t.ClaimID 
		JOIN rlmbgrpl rmg ON rmg.mb_gr_pl_id=c.mbgrpl_id
		JOIN rlplfc rpf ON rpf.mb_gr_pl_id=rmg.mb_gr_pl_id AND c.rlplfc_id = rpf.rlplfc_id
		JOIN  #tempSub s ON s.memberID=rmg.member_id 
    

--SELECT *FROM #tempClaimInfo
IF NOT EXISTS (SELECT t.claim_id FROM #tempClaimInfo t)
BEGIN
	   INSERT INTO #tempErrorTable VALUES ('ClaimInput','Unable to get Claim for the given subscriber FROM Database');
	   THROW 51000,'User Validation Faild',1
END

--validate Patient
IF @DepSW=1
BEGIN
IF @PatID>0
BEGIN
IF EXISTS (SELECT m.member_id 
			   FROM member m
			   JOIN #tempSub t on m.family_id=t.memberID
			   WHERE m.member_id<>m.family_id AND m.member_id=@PatID AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				SELECT Distinct m.member_id 
				   FROM member m
				   JOIN #tempSub t on m.family_id=t.memberID
				   WHERE m.member_id<>m.family_id AND m.member_id=@PatID AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END

END
ELSE IF len(@PatAltID)>0
BEGIN

IF EXISTS (SELECT m.member_id 
			   FROM member m
			    JOIN #tempSub t on m.family_id=t.memberID
			   WHERE m.member_id<>m.family_id AND m.alt_id=@PatAltID AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				SELECT Distinct m.member_id 
				   FROM member m
				    JOIN #tempSub t on m.family_id=t.memberID
				   WHERE m.member_id<>m.family_id AND m.alt_id=@PatAltID AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END

END

ELSE IF len(@PatSSN)>0
BEGIN

IF EXISTS (SELECT m.member_id 
			   FROM member m
			    JOIN #tempSub t on m.family_id=t.memberID
			   WHERE m.member_id<>m.family_id AND m.member_ssn=@PatSSN AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				SELECT Distinct m.member_id 
				   FROM member m
				    JOIN #tempSub t on m.family_id=t.memberID
				   WHERE m.member_id<>m.family_id AND m.member_ssn=@PatSSN  AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END
END
ELSE IF len(@patSourceID)>0
BEGIN

IF EXISTS (SELECT m.member_id 
			   FROM member m
			    JOIN #tempSub t on m.family_id=t.memberID
			   WHERE m.member_id<>m.family_id AND m.source_id=@patSourceID AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				SELECT Distinct m.member_id 
				   FROM member m
				    JOIN #tempSub t on m.family_id=t.memberID
				   WHERE m.member_id<>m.family_id AND m.source_id=@patSourceID AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END

END


IF EXISTS(SELECT member_id FROM #tempPatient)
BEGIN 
  IF EXISTS(SELECT t.member_id FROM #tempPatient t
  JOIN #tempPatient s ON s.member_id<>t.member_id)
  BEGIN
	 INSERT INTO #tempErrorTable VALUES ('PatientInput','Multiple Patients found in the database for the given options');
	 THROW 51000,'User Validation Faild',1
	END
END
ELSE
BEGIN
	 INSERT INTO #tempErrorTable VALUES ('PatientInput','No matching Patient found in the database for the given options ');
	 THROW 51000,'User Validation Faild',1
END

IF EXISTS(SELECT member_id FROM #tempPatient t 
JOIN #tempClaimInfo ct ON ct.patient<>t.member_id)
BEGIN
	INSERT INTO #tempErrorTable VALUES ('PatientInput','Patient info provided does not match the Patient in claim');
	THROW 51000,'User Validation Faild',1

END



END


--IF EXISTS(SELECT member_id FROM #tempPatient)
--BEGIN 
--  IF EXISTS(SELECT member_id FROM #tempPatient t WHERE t.member_id<>t.member_id)
--  BEGIN
--	 INSERT INTO #tempErrorTable VALUES ('Pat','Multiple Patients found in the database for the given options');
--	 THROW 51000,'User Validation Faild',1
--	END
--END
--ELSE
--BEGIN
--	 INSERT INTO #tempErrorTable VALUES ('Pat','No matching Patient found in the database for the given options ');
--	 THROW 51000,'User Validation Faild',1
--END

--IF EXISTS(SELECT member_id FROM #tempPatient t 
--JOIN #tempClaimInfo ct ON ct.patient<>t.member_id)
--BEGIN
--	INSERT INTO #tempErrorTable VALUES ('Pat','Patient info provided does not match the Patient in claim');
--	THROW 51000,'User Validation Faild',1

--END

--Error Table
 Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempErrorTable t


---get group info

Select g.group_id as GroupID,g.alt_id as GroupAltID,g.group_name as GroupName
	From #tempClaimInfo t
	JOIN [group] g on t.group_id=g.group_id


--get Plan info

Select p.plan_id as PlanID,p.plan_dsp_name as PlanDSPName
	From #tempClaimInfo t
	JOIN [plan] p ON p.plan_id=t.plan_id


--Get subscriber info
Select 
	m.member_id as MemberID,
	m.family_id as FamilyID,
	m.alt_id as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	m.first_name as FirstName,
	m.middle_init as MiddleInitial,
	m.last_name as LastName,
	m.date_of_birth as DOB,
	m.member_ssn as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	m.action_code as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	m.h_action as UserAction,
	m.h_user as [User],
	m.hire_date as Hire,
	m.new_ssn as SSN,
	m.source_id as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
	t.group_id AS GroupID,
	t.plan_id AS PlanID
	From #tempClaimInfo t
	JOIN member m ON m.member_id=t.subscriber



--Get Subscriber Address info
Select
	a.sys_rec_id AS SysRecId,
	a.addr_type AS [Type],
	a.addr1 AS Addr1,
	a.addr2 AS Addr2,
	a.city AS City,
	a.country AS Country,
	a.county AS County,
	a.[state] AS [State],
	a.zip AS Zip,
	p.home_phone AS Home,
	p.home_ext AS HomeX,
	p.work_phone AS Work,
	p.work_ext AS WorkX,
	p.fax AS Fax,
	p.email AS Email
	From #tempClaimInfo t
	JOIN [address] a on t.subscriber=a.sys_rec_id
	Left JOIN mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'


--Get Patient info

Select m.member_id as MemberID,
	m.family_id as FamilyID,
	m.alt_id as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS  Gender,
	m.first_name as FirstName,
	m.middle_init as MiddleInitial,
	m.last_name as LastName,
	m.date_of_birth as DOB,
	m.member_ssn as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	m.action_code as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	m.h_action as UserAction,
	m.h_user as [User],
	m.hire_date as Hire,
	m.new_ssn as SSN,
	m.source_id as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless
	From #tempClaimInfo t
	JOIN member m on m.member_id=t.patient

--pat address
Select 
	a.sys_rec_id AS SysRecId,
	a.addr_type AS [Type],
	a.addr1 AS Addr1,
	a.addr2 AS Addr2,
	a.city AS City,
	a.country AS Country,
	a.county AS County,
	a.[state] AS [State],
	a.zip AS Zip,
	p.home_phone AS Home,
	p.home_ext AS HomeX,
	p.work_phone AS Work,
	p.work_ext AS WorkX,
	p.fax AS Fax,
	p.email AS Email
	From #tempClaimInfo t
	JOIN [address] a on t.patient=a.sys_rec_id
	Left Join mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'

--Claim info

Select c.claim_status AS ClaimStatus,
		c.claim_id AS ClaimID,
		c.claim_no AS ClaimNum,
		c.alt_id AS ClaimAltID,
		c.document_no AS ClaimDocNum,
		c.svc_date_beg AS ClaimBegin,
		c.svc_date_end AS ClaimEnd,
		c.received_date AS ClaimRecd,
		c.preauth_switch AS PreAuthSW,
		c.use_by AS UseBy,
		c.entered_by AS EntryMethod,
		c.[type] AS ClaimType,
		c.speciality_type AS SpecialtyType,
		b.[status] As ObjectStatus,
		t.facility_id AS FcId,
		t.provider_id AS PvId,
		t.subscriber AS SubId,
		t.patient AS PatId,
		t.plan_id AS PlanId,
		t.group_id AS GroupId
		From #tempClaimInfo t
		join claim_h c on c.claim_id=t.claim_id
		Left Join object_queue b ON b.[object_id]=t.claim_id


---get serviceLine info		
 SELECT c.claim_d_id AS SvcLineID,  
			 c.claim_id AS ClaimId,  
			 c.svc_beg AS SvcBegin,  
			 c.d_proc_code AS ProceCode,    
			 c.tooth_no AS Tooth,  
			 c.surface AS Surface,  
			 c.quad AS Quad,  
			 c.submitted_amt AS SubmittedAmt,    
			 c.lab_fee AS LabFeeAmt,  
			 c.allowed AS AllowedAmt,  
			 c.patient_resp AS PatResp,    
			 c.plan_resp AS PlanResp,    
			 c.h_datetime AS UpdDateTime,    
			 c.h_msi AS MSI,  
			 c.h_action AS [Action],    
			 c.h_user AS UpdUser,  
			 c.date_to_pay AS DateToPay,  
			 c.date_processed AS ProcessedDate,  
			 c.[status] AS [Status],    
			 c.reversal_switch AS ReversalSwitch,    
			 c.statement_id AS StatementID,    
			 c.cob_amt AS CobAmt,    
			 c.max_allowed AS MaxAllowedAmt,    
			 c.perc_covered AS PercentCovered,    
			 c.ded_applied AS DedApplied,    
			 c.rollover_applied AS RollOverApplied,    
			 c.co_ins AS CoIns,    
			 c.provider_resp AS PvdResp,  
			 c.tpa_inv_number AS TPANum,  
			 c.relates_to AS RelatesTo,   
			 c.relates_to_order AS RelatesToOrder,  
			 c.proc_subst_id AS ProcSubstID,  
			 c.substitute_sw AS SubstituteSW
			 FROM #tempClaimInfo t 
			 JOIN claim_d  c ON t.claim_id=c.claim_id
			 --JOIN eop_d e ON  e.claim_id = c.claim_id and e.claim_d_id = c.claim_d_id
			 --where e.eop_id = @EopID   
		     order by c.svc_beg


---get Processing code

Select pc.claim_pc_id AS ID,   
		pc.claim_id AS ClaimID,   
		pc.process_code_id AS ProcessCodeID,   
		pc.claim_d_id AS ClaimDId,  
		pc.h_datetime,  
		pc.h_msi AS MSI,   
		pc.h_action AS [Action],   
		pc.h_user,   
		pc.deassigned_at AS DeassignedAt,   
		pc.deassigned_by AS DeassignedBy,   
		cpc.process_code AS ProcessingCode,   
		cpc.code_type AS CodeType,   
		cpc.descr AS ProceCodeDesc
		From #tempClaimInfo t 
		JOIN claim_pc pc ON t.claim_id=pc.claim_id
		JOIN clm_process_codes cpc ON pc.process_code_id = cpc.clm_proc_code_id   
		Where pc.deassigned_at is null and (pc.claim_d_id is null or pc.claim_d_id = 0)  


END TRY
BEGIN CATCH
IF ERROR_MESSAGE()='User Validation Faild'
BEGIN
  Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempErrorTable t
END
ELSE 
 THROW; 
END CATCH

END