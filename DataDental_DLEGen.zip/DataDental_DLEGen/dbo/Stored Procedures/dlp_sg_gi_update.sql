﻿CREATE PROCEDURE [dbo].[dlp_sg_gi_update]
    @a_tl_sir_id INT ,
    @a_action_code CHAR(2)
    
-- DATE: 10/23/96

-- DOB: G1
-- Address: G2
-- DOB + Address: G3
-- Phone: G4
-- DOB + Phone: G5
-- Address + Phone: G6
-- DOB + Address + Phone: G7
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:36:36 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1










000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_fatal INT;
        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);

        DECLARE @d_severity CHAR(1);

        DECLARE @d_date_of_birth DATE;
        DECLARE @n_paperless CHAR(1);
        DECLARE @n_last_name CHAR(15);
        DECLARE @n_date_of_birth DATE;
        DECLARE @n_address_id INT;
        DECLARE @n_address1 CHAR(30);
        DECLARE @n_address2 CHAR(30);
        DECLARE @n_city CHAR(30);
        DECLARE @n_state CHAR(2);
        DECLARE @n_zip CHAR(10);
        DECLARE @n_county CHAR(20);
        DECLARE @n_g1 INT;
        DECLARE @n_g2 INT;
        DECLARE @n_g4 INT;
        DECLARE @n_count INT;
        DECLARE @n_action INT;

DECLARE @s_member_flag	char(2);
DECLARE @s_dls_mb_id	integer;
DECLARE @s_paperless  char(1);
DECLARE @s_last_name	char(15);
DECLARE @s_date_of_birth	char(10);
DECLARE @s_student_flag	char(1);
DECLARE @s_disable_flag	char(1);
DECLARE @s_cobra_flag	char(1);

DECLARE @s_address1	char(30);
DECLARE @s_address2	char(30);
DECLARE @s_city		char(30);
DECLARE @s_state		char(2);
DECLARE @s_zip		char(5);
DECLARE @s_zipx		char(4);
DECLARE @s_home_phone	char(10);
DECLARE @s_home_ext	char(5);
DECLARE @s_work_phone	char(10);
DECLARE @s_work_ext	char(5);
DECLARE @s_email		char(250);
DECLARE @sg_up_sp_id 	integer;

DECLARE @sg_sir_def_id 	integer;
       
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;
		DECLARE @created_by CHAR(8)
		DECLARE @a_batch_id INT




-- No errors will be logged, and only the error number will be returned
        SET NOCOUNT ON;

		SELECT @a_batch_id = dls_batch_id FROM dbo.dls_sg_member(NOLOCK) WHERE dls_sir_id = @a_tl_sir_id

		SELECT @created_by = LEFT(created_by,8)
		FROM dl_config_bat(NOLOCK) 
		WHERE config_bat_id =@a_batch_id

        SET @s_member_flag ='';
    
        SET @s_dls_mb_id = 0;
      
        SET @s_paperless ='';
     
        SET @s_last_name ='';
     
        SET @s_date_of_birth ='';
    
        SET @s_student_flag ='';
      
        SET @s_disable_flag ='';
        
        SET @s_cobra_flag ='';
       
        SET @s_address1 ='';
      
        SET @s_address2 ='';
    
        SET @s_city ='';
       
        SET @s_state ='';
     
        SET @s_zip ='';
      
        SET @s_zipx ='';
       
        SET @s_home_phone ='';
       
        SET @s_home_ext ='';
       
        SET @s_work_phone ='';
       
        SET @s_work_ext ='';
       
        SET @s_email ='';
       
        SET @sg_up_sp_id = 0;
      
        SET @sg_sir_def_id = 0;
    
        BEGIN TRY
          
			SELECT @s_member_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_dls_mb_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_paperless = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_paperless' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_zipx' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_email = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 2

			SELECT @s_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 2

			SELECT @s_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 2

			SET @d_date_of_birth = @s_date_of_birth;

-- only allow changes on the subscriber
          
            IF @s_member_flag != '00'
                AND @a_action_code != 'G1'
                RETURN -310;

            IF SUBSTRING(@a_action_code, 2, 1) = '0'
                RETURN -311;

           
            IF @s_dls_mb_id IS NULL
				BEGIN
				SET @n_error_code = 304
                RAISERROR('Interna Error - Null member_id',16,1);
				END

            SET @n_action = '0' + SUBSTRING(@a_action_code, 2, 1);
            SET @n_g4 = CONVERT(DECIMAL, @n_action) / 4;
            SET @n_g2 = CONVERT(DECIMAL, @n_action % 4) / 2;
            SET @n_g1 = @n_action % 2;
			
-- 20120528$$ks - added logic for paperless switch
            IF @n_g1 = 1
                BEGIN
                    SELECT  @n_last_name = last_name ,
                            @n_date_of_birth = date_of_birth ,
                            @n_paperless = paperless
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_id = @s_dls_mb_id;
                   
                    IF ( @n_last_name IS NULL
                         
                       )
					   BEGIN 
					   SET @n_error_code = 304
                        RAISERROR('Interna Error - Record not in member with member_id',16,1);
					END
	
                    IF @d_date_of_birth IS NOT NULL
                        AND @n_date_of_birth != @d_date_of_birth
                        UPDATE  dbo.member
                        SET     date_of_birth = @d_date_of_birth
                        WHERE   member_id = @s_dls_mb_id;
	
                   
                    IF ( @s_paperless IS NOT NULL
                         
                       )
                        AND @s_paperless != @n_paperless
                        UPDATE  dbo.member
                        SET     paperless = @s_paperless
                        WHERE   member_id = @s_dls_mb_id;
                END;

            IF @n_g2 = 1
                OR @n_g4 = 1
                BEGIN
                    SELECT  @n_address_id = address_id ,
                            @n_address1 = addr1 ,
                            @n_address2 = addr2 ,
                            @n_zip = zip
                    FROM    dbo.[address] (NOLOCK)
                    WHERE   subsys_code = 'MB'
                            AND sys_rec_id = @s_dls_mb_id
                            AND addr_type = 'L';
               
                END;

            IF @n_g2 = 1
                IF @n_address_id IS NULL
	 /* 20131112$$ks same zip can be used for different cities find match or 
	  * use value provided
	  */
                    BEGIN
                        SET @SWV_cursor_var1 = CURSOR  FOR SELECT city, county, state_code 
            FROM dbo.usa_zip (NOLOCK)
            WHERE zip_code = @s_zip;
                        OPEN @SWV_cursor_var1;
                        FETCH NEXT FROM @SWV_cursor_var1 INTO @n_city,
                            @n_county, @n_state;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                
                                IF ( ( @s_city IS NOT NULL
                                      
                                     )
                                     AND @s_city != ''
                                     AND @s_city = @n_city
                                   )
        GOTO SWL_Label3;
                                FETCH NEXT FROM @SWV_cursor_var1 INTO @n_city,
@n_county, @n_state;
                    END;
  SWL_Label3:
       CLOSE @SWV_cursor_var1;
                        IF ( (@n_city IS NULL
                             )
                           )
                            OR ( (@n_county IS NULL
                                 )
                               )
                            OR ( (@n_state IS NULL
                                 )
                               )
							   BEGIN
							   SET @n_error_code = 305
							 RAISERROR('Member address Zip is not recognized by DataDental',0,1);
							END
		
                      
                        IF ( @s_zipx IS NULL
                             
                           )
                            BEGIN
                              
                                SET @n_zip = @s_zip;
                            END;
                        ELSE
		-- 20131101$$ks remove hypen
			--LET n_zip = s_zip || "-" || s_zipx;
                            BEGIN
                              
						 SET @n_zip = @s_zip + @s_zipx;
                            END;
		
                        INSERT  INTO dbo.[address]
                                ( subsys_code ,
                                  sys_rec_id ,
                                  addr_type ,
                                  addr1 ,
                                  addr2 ,
                                  city ,
                                  county ,
                                  state ,
                                  zip ,
                                  mail
                                )
                        VALUES  ( 'MB' ,
                                  @s_dls_mb_id ,
                                  'L' ,
                                  @s_address1 ,
                                  @s_address2 ,
                                  @n_city ,
                                  @n_county ,
                                  @n_state ,
                                  @n_zip ,
                                  'N'
                                );
		
                        
                        IF NOT ( ( @s_home_phone IS NULL
                                   OR @s_home_phone = ''
                                 )
                                 AND ( @s_work_phone IS NULL
                                       OR @s_work_phone = ''
                                     )
                               )
                            BEGIN
                                SELECT  @n_address_id = address_id
                                FROM    dbo.address (NOLOCK)
                                WHERE   subsys_code = 'MB'
                                        AND sys_rec_id = @s_dls_mb_id
                                        AND addr_type = 'L';
                               
                                IF @n_address_id IS NULL
								BEGIN
									SET @n_error_code = 100
                                    RAISERROR('Database Error',16,1);
								END
                            END;
                    END;
                ELSE
                    BEGIN
                       
                        IF ( @s_zip IS NOT NULL
                             
                           )
                            AND ( ( @n_zip IS NULL
                                    
              )
                                  OR @s_zip != SUBSTRING(@n_zip, 1, 5)
                                )
		/* 20131114$$ks - zipcodes can be for multiple cities - need to determine
		 * which to use 
		 */
                            BEGIN
                                SET @SWV_cursor_var2 = CURSOR  FOR SELECT city, county, state_code 
               FROM dbo.usa_zip (NOLOCK)
               WHERE zip_code = @s_zip;
                                OPEN @SWV_cursor_var2;
                         FETCH NEXT FROM @SWV_cursor_var2 INTO @n_city,
       @n_county, @n_state;
                             WHILE @@FETCH_STATUS = 0
                                    BEGIN
                                        EXECUTE SWPGetGlVar 's_city',
                                            @s_city OUTPUT;
                                        IF ( ( @s_city IS NOT NULL
                                               )
                                             AND @s_city != ''
                                             AND @s_city = @n_city
                                           )
                                            GOTO SWL_Label4;
                                 FETCH NEXT FROM @SWV_cursor_var2 INTO @n_city,
                                            @n_county, @n_state;
                                    END;
                                SWL_Label4:
                                CLOSE @SWV_cursor_var2;
                                IF ( (@n_city IS NULL
                                     )
                                   )
                                    OR ( (@n_county IS NULL
                                        )
                                       )
                                    OR ( (@n_state IS NULL
                                         )
                                       )
									   BEGIN
									   SET @n_error_code =305
										RAISERROR('Member address Zip is not recognized by DataDental',0,1);
									END
			
                               
                                IF ( @s_zipx IS NULL
                                    
                                   )
                                    BEGIN
                                        
                                        SET @n_zip = @s_zip;
                                    END;
                                ELSE
				--LET n_zip = s_zip || "-" || s_zipx;
                                    BEGIN
                                     
                                        SET @n_zip = @s_zip + @s_zipx;
                                    END;
			
                                UPDATE  dbo.[address]
                                SET     addr1 = @s_address1 ,
                                        addr2 = @s_address2 ,
                                        city = @n_city ,
                                        [state] = @n_state ,
                                        county = @n_county ,
                                        zip = @n_zip ,
                                        mail = 'N'
                                WHERE   address_id = @n_address_id;
                            END;
                        ELSE
                            UPDATE  dbo.address
                            SET     addr1 = @s_address1 ,
                                    addr2 = @s_address2 ,
                                    mail = 'N'
                            WHERE   address_id = @n_address_id;
                    END;
	

            IF @n_g4 = 1
	-- 20131101$$ks email cannot be null
                BEGIN
                   
                    IF ( @s_email IS NULL
                        
                       )
                        BEGIN
                            SET @s_email ='';
                           
                        END;
	
                    SELECT  @n_count = COUNT(*)
                    FROM    dbo.mbr_phone (NOLOCK)
                    WHERE   address_id = @n_address_id;
                    IF @n_count = 0
                        INSERT  INTO dbo.mbr_phone
                                ( address_id ,
                                  home_phone ,
                                  home_ext ,
                                  work_phone ,
                            work_ext ,
    email
      )
        VALUES  ( @n_address_id ,
                                  @s_home_phone ,
  @s_home_ext ,
               @s_work_phone ,
                                  @s_work_ext ,
                                  @s_email
                                );
	
                    IF @n_count = 1
                        UPDATE  dbo.mbr_phone
                        SET     home_phone = @s_home_phone ,
                                home_ext = @s_home_ext ,
                                work_phone = @s_work_phone ,
                                work_ext = @s_work_ext ,
                                email = @s_email
                        WHERE   address_id = @n_address_id;
                    ELSE
						BEGIN
						SET @n_error_code =306
                        RAISERROR('Multiple member phone records.',16,1);
						END
                END;

                 EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_1', @s_dls_mb_id,@created_by;

--trace off;
            RETURN 1;
        END TRY
        BEGIN CATCH
            --SET @n_error_code = ERROR_NUMBER();
            SET @n_return_code = ERROR_LINE();
	        SET @n_error_desc = ERROR_MESSAGE();

            RETURN -@n_error_code;
        END CATCH;
        SET NOCOUNT OFF;
		
--set debug file to "/tmp/dlp_sg_gi_update.trc";
--trace on;

    END;