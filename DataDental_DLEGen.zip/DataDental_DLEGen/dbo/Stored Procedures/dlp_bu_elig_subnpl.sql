﻿CREATE PROCEDURE [dbo].[dlp_bu_elig_subnpl]
    @n_count INT ,
    @t_sub_in_plan SMALLINT ,
    @n_sub_in_plan SMALLINT ,
    @batch_id INT ,
    @sp_id INT ,
    @sir_def_id INT ,
    @dls_sir_id INT ,
    @SWP_Ret_Value SMALLINT = NULL OUTPUT
     
 		--t_sub_in_plan or n_sub_in_plan

/*
This method is called by dlp_bu_eligibility() and dlp_bu_sg_member().

*/
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @int_log_value INT;

        SET NOCOUNT ON;
        IF ( @t_sub_in_plan IS NULL )
            RAISERROR('IllegalArgumentException:  dlp_bu_elig_subnpl():  t_sub_in_plan was NULL.',16,1);


        IF ( @n_count = 0 )
            BEGIN
                SET @SWP_Ret_Value = @t_sub_in_plan;
                RETURN;
            END;
        ELSE
            IF ( @n_count >= 1 )
                BEGIN
                    IF ( @n_sub_in_plan IS NULL )
                        RAISERROR('IllegalArgumentException:  dlp_bu_elig_subnpl():  n_sub_in_plan was NULL and n_count >= 1.',16,1);
	
                    IF ( @n_sub_in_plan = @t_sub_in_plan )
                        BEGIN
                            SET @SWP_Ret_Value = @n_sub_in_plan;
                            RETURN;
                        END;
                    ELSE
		--Log a warning that
		--"Change in subscriber-in-plan (field sub_in_plan) ignored"
                        BEGIN
						
                            EXECUTE @int_log_value = dbo.usp_dl_log_error @batch_id,
                                @sp_id, @sir_def_id, @dls_sir_id, 143;
                            SET @SWP_Ret_Value = @n_sub_in_plan;
                            RETURN;
                        END;
                END;

--This statement will only be reached if n_count < 0 which probably
--represents some type of error condition;  so, just return the value
--already in table rlmbgrpl, that represented by n_sub_in_plan.

        SET @SWP_Ret_Value = @n_sub_in_plan;
        RETURN;
        SET NOCOUNT OFF;

    END;