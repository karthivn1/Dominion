﻿CREATE PROCEDURE [dbo].[dlp_up_fee_zip]
    @p_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT 
	

------------------------------------------------------------------------------
--
--            Procedure:   dlp_up_fee_zip
--
--            Created:     06/04/99 
--            Author:      Ameeta Mahendra
--
-- Purpose:  This SP performs update processing on 
--		DataDental Fee Sourc table
--           for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE   AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;

        DECLARE @i_stats_id INT;

        DECLARE @i_error_count INT;
        DECLARE @i_total_count INT;
        DECLARE @i_init_count INT;
        DECLARE @i_count INT;
        DECLARE @i_fatal INT;
        DECLARE @i_succ_count INT;
        DECLARE @i_last_total INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sp_id2 INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @s_proc_name VARCHAR(20);
        DECLARE @s_sir_def_name VARCHAR(20);
        DECLARE @c_cur_err_flag CHAR(1);

        DECLARE @t_sir_id INT;
        DECLARE @temp_sir_id INT;

        DECLARE @t_zip_code_3 CHAR(3);
        DECLARE @t_zip_code CHAR(3);

        DECLARE @d_p_eff_date DATE;
        DECLARE @s_p_version CHAR(6);
        DECLARE @s_p_source CHAR(10);
        DECLARE @i_p_percent CHAR(3);

        DECLARE @s_p_eff_date CHAR(10);


        DECLARE @s_user CHAR(10);
        DECLARE @dt_current DATETIME;

        DECLARE @i_FEEID INT;
   --DECLARE @cFeeSir CURSOR
   --DECLARE @c1FeeSir CURSOR
        DECLARE @SWV_dl_upd_statistics INT;
		DECLARE @Error_no INT;

-----exception handling---------------------------------------------------------


 -- error converting text param values to correct type

  
   -- intrpt - server or user terminated -----NO ROLLBACK---
        SET NOCOUNT ON;
        BEGIN TRY
      -- NOT SUPPORTED set explain on;

            SET @s_proc_name = 'up_fee_zip';
            SET @s_sir_def_name = 'fee_zip';
            SET @dt_current = GETDATE();
            SET @s_user = CONCAT('dl', @p_batch_id);
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @p_batch_id, @s_proc_name;
            IF @i_sp_id = -1
                BEGIN
					SET @Error_no = 0
                    RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
                    
                END;

            EXECUTE @i_sp_id2 = dbo.dl_get_sp_id @p_batch_id, 'up_fee_sched';
            IF @i_sp_id2 = -1
                BEGIN
					SET @Error_no = 0
                    RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
                    
                END;

            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id = -1
                BEGIN
					SET @Error_no = 0
                    RAISERROR('Could not retrieve valid SIR Table ID',16,1);
                   
                END;


-- prepare for keeping stats on preprocessing-----------------

-- move all logged errors to the log error history table

            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  dls_sir_id INT
                );

            INSERT  INTO @SWV_cursor_var1
                    ( dls_sir_id 
                    )
                    SELECT  dls_sir_id
                    FROM    dbo.dl_log_error
                    WHERE   config_bat_id = @p_batch_id
                            AND sp_id = @i_sp_id
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_fee_zip
                            WHERE   dls_batch_id = @p_batch_id
                                    AND ( dls_status = 'P'
                                          OR dls_status = 'V'
                                        ) );

            DECLARE @cur1_cnt INT ,
                @cur1_i INT;

            SET @cur1_i = 1;
						--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;

/*
      SET @cFeeSir = CURSOR  FOR SELECT dls_sir_id 
 FROM dbo.dl_log_error
      WHERE config_bat_id = @p_batch_id
      AND   sp_id = @i_sp_id
      AND   dls_sir_id IN(SELECT dls_sir_id
      FROM dbo.dls_fee_zip
      WHERE  dls_batch_id = @p_batch_id
      AND   (dls_status   = 'P' or dls_status = 'V'))
      OPEN @cFeeSir
      FETCH NEXT FROM @cFeeSir INTO @temp_sir_id
      while @@FETCH_STATUS = 0
	  */
            WHILE ( @cur1_i <= @cur1_cnt )
                BEGIN
                    SELECT  @temp_sir_id = dls_sir_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur1_i;
                    EXECUTE dbo.dl_clean_curr_err @p_batch_id, @temp_sir_id,
                        @i_sp_id, @i_error_no OUTPUT, @s_err_rtn_text OUTPUT;
         --FETCH NEXT FROM @cFeeSir INTO @temp_sir_id
                    SET @cur1_i = @cur1_i + 1;
                END;
      --CLOSE @cFeeSir
      

-- get initial count of rows that have passed pre-processing --

/*
SELECT cfg_bat_det_id INTO i_cfg_bat_det_id
FROM dl_cfg_bat_det
WHERE config_bat_id = p_batch_id and sp_id = i_sp_id;
*/
            EXECUTE dbo.dl_it_statistics @p_batch_id, @i_sp_id, @a_start_time,
                @a_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_stats_id OUTPUT, @s_error_descr OUTPUT;
            IF @a_error_no <= 0
                BEGIN
					SET @Error_no = 0
                    RAISERROR('(Internal) error when creating statistics',16,1);
                    
                END;

            SET @i_total_count = 0;
            SET @i_succ_count = 0;
            SET @i_last_total = 0;
----------get params from user--------------------
            SET @s_p_eff_date = dbo.dl_get_param_value(@p_batch_id, @i_sp_id2,
                                                       'Run Date');
            IF ( @s_p_eff_date IS NULL
                 OR @s_p_eff_date = ''
               )
                OR LEN(@s_p_eff_date) < 1
                BEGIN
					SET @Error_no = 0
                    RAISERROR('Missing Run Date parameter value',16,1);
                    
                END;
            ELSE
                BEGIN
                    SET @s_err_rtn_text = 'Can not convert Run Date to type Date';
                    SET @a_error_no = 1;
                    SET @d_p_eff_date = @s_p_eff_date;
                    SET @a_error_no = 0;
                END;

            SET @s_p_version = dbo.dl_get_param_value(@p_batch_id, @i_sp_id2,
                                                      'Version');
            IF ( @s_p_version IS NULL
                 OR @s_p_version = ''
               )
                OR LEN(@s_p_version) < 6
                BEGIN
					SET @Error_no = 0
                    RAISERROR('Missing Version parameter value',16,1);
                    
                END;

            SET @s_p_source = dbo.dl_get_param_value(@p_batch_id, @i_sp_id2,
                                                     'Source');
            IF ( @s_p_source IS NULL
                 OR @s_p_source = ''
               )
                OR LEN(@s_p_source) < 1
                BEGIN
					SET @Error_no = 0
                    RAISERROR('Missing Source parameter value',16,1);
                    
                END;

 

	-----exception handling w/in foreach------------------------------------
  
            SET @c_cur_err_flag = 'F';
-----begin processing one zip code record at a time-----------------------------
-----the outer loop will create the fee_sched_h, fee_sched_d, fee_source entry -----

         
	   -- problems retrieving data from dB --------
	   
         
      -------------------------------------------------------------------------
            DECLARE @SWV_cursor_var2 TABLE
                (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                  zip_code_3 CHAR(3) ,
                  zip_code CHAR(3)
                );

            INSERT  INTO @SWV_cursor_var2
                    ( dls_sir_id ,
                      zip_code_3 ,
                      zip_code
                    )
                    SELECT  dls_sir_id ,
                            zip_code_3 ,
                            zip_code
                    FROM    dbo.dls_fee_zip
                    WHERE   dls_batch_id = @p_batch_id
                            AND zip_code_3 != zip_code
                            AND ( dls_status = 'P'
                                  OR dls_status = 'V'
                                );

            DECLARE @cur2_cnt INT ,
                @cur2_i INT;

            SET @cur2_i = 1;
						--Get the no. of records for the cursor
            SELECT  @cur2_cnt = COUNT(1)
            FROM    @SWV_cursor_var2;


	  /*
      SET @c1FeeSir = CURSOR  FOR SELECT dls_sir_id, zip_code_3, zip_code
	
      FROM   dbo.dls_fee_zip
      WHERE  dls_batch_id = @p_batch_id
      AND	zip_code_3 != zip_code
      AND    (dls_status   = 'P' or dls_status = 'V')
      OPEN @c1FeeSir
      FETCH NEXT FROM @c1FeeSir INTO @t_sir_id,@t_zip_code_3,@t_zip_code
      while @@FETCH_STATUS = 0
	  */
            WHILE ( @cur2_i <= @cur2_cnt )
                BEGIN
                    SELECT  @t_sir_id = dls_sir_id ,
                            @t_zip_code_3 = zip_code_3 ,
                            @t_zip_code = zip_code
                    FROM    @SWV_cursor_var2
                    WHERE   id = @cur2_i;
                    BEGIN
            --DECLARE @cFeeSource CURSOR
           	-- set all records to "E" for  zip code
		   


	   -- if fatal err, rollback and cont with next grp - else resume
                        BEGIN TRY
           
                            SET @a_error_no = 0;
                            IF ( @t_zip_code_3 IS NULL
                                 OR @t_zip_code_3 = ''
                               )
                                OR LEN(@t_zip_code_3) != 3
                                BEGIN
									SET @Error_no = 10
                                    RAISERROR('Invalid initial ZIP code ',16,1);
                                    
                                END;
	
                            IF ( @t_zip_code IS NULL
                                 OR @t_zip_code = ''
                               )
                                OR LEN(@t_zip_code) != 3
                                BEGIN
									SET @Error_no = 20
                                    RAISERROR('Invalid Required ZIP code ',16,1);
                                    
                                END;
	
                            SET @i_total_count = @i_total_count + 1;

							
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.fee_source
                                            WHERE   source = @s_p_source
                                                    AND version = @s_p_version
                                                    AND zip_code_3 = @t_zip_code_3 )
                                BEGIN
									SET @Error_no = 30
                                    RAISERROR('Zip Code does not exist',16,1);
                                    
                                END;
	
                            IF EXISTS ( SELECT  *
                                        FROM dbo.fee_source
                                        WHERE   source = @s_p_source
                                                AND version = @s_p_version
                                                AND zip_code_3 = @t_zip_code )
                                BEGIN
									SET @Error_no = 35
                                    RAISERROR('Zip Code 2 already exist',16,1);
                                    
                                END;

                           -- DECLARE #SWV_cursor_var3 TABLE
									IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
									DROP TABLE #SWV_cursor_var3
								 CREATE TABLE #SWV_cursor_var3
                                (
                                  id INT IDENTITY ,
                                  fee_sched_id INT ,
                                  percentile CHAR(2)
                                );

                            INSERT  INTO #SWV_cursor_var3
                                    ( fee_sched_id ,
                                      percentile
                                    )
                                    SELECT  fee_sched_id ,
                                            percentile
                                    FROM    dbo.fee_source
                                    WHERE   source = @s_p_source
                                            AND version = @s_p_version
                                            AND zip_code_3 = @t_zip_code_3;

                            DECLARE @cur3_cnt INT ,
                                @cur3_i INT;

                            SET @cur3_i = 1;
						--Get the no. of records for the cursor
                            SELECT  @cur3_cnt = COUNT(1)
                            FROM    #SWV_cursor_var3;
				  /*
	
               SET @cFeeSource = CURSOR  FOR SELECT fee_sched_id, percentile
		
               FROM dbo.fee_source
               WHERE source = @s_p_source and version = @s_p_version
               and zip_code_3 = @t_zip_code_3
               OPEN @cFeeSource
               FETCH NEXT FROM @cFeeSource INTO @i_FEEID,@i_p_percent
               while @@FETCH_STATUS = 0
			   */

                            WHILE ( @cur3_i <= @cur3_cnt )
                                BEGIN
                                    SELECT  @i_FEEID = fee_sched_id ,
                                            @i_p_percent = percentile
                                    FROM    #SWV_cursor_var3
                                    WHERE   id = @cur3_i;

                                    SET @a_error_no = 40;	--update fee_source failed
------------EXPIRE previous verion of schedule in fee_source table
                                    UPDATE  dbo.fee_source
                                    SET     exp_date = @d_p_eff_date
                                    WHERE   source = @s_p_source
                                            AND zip_code_3 = @t_zip_code
                                            AND exp_date IS NULL
                                            AND percentile = @i_p_percent;
                                    SET @a_error_no = 50;	----insert into fee_source failed
		--INSERT records into fee_source table 
                                    INSERT  INTO dbo.fee_source
                                            ( source ,
                                              version ,
                                              zip_code_3 ,
                                              percentile ,
                                              eff_date ,
                                              exp_date ,
                                              fee_sched_id ,
  h_datetime ,
                                              h_user ,
                                              h_action
                                            )
                                    VALUES  ( @s_p_source ,
                                              @s_p_version ,
                                              @t_zip_code ,
											 @i_p_percent ,
                                              @d_p_eff_date ,
                                              NULL ,
                                              @i_FEEID ,
                                              @dt_current ,
                                              @s_user ,
                                              'IN'
                                            );
                  --FETCH NEXT FROM @cFeeSource INTO @i_FEEID,@i_p_percent
                                    SET @cur3_i = @cur3_i + 1;
                                END;
               --CLOSE @cFeeSource
---------------------

                            UPDATE  dbo.dls_fee_zip
                            SET     dls_status = 'U'
                            WHERE   dls_sir_id = @t_sir_id; 
			  
                            SET @i_succ_count = @i_succ_count + 1;
               
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -244, -245, -246 )
                                SET @a_error_no = 1000; -- db locked by another user -- fatal
	   
            
           -- must have been an unexpected db error 
                            IF (@a_error_no = 0 OR  @Error_no = 0)
                                BEGIN
                                    SET @s_err_rtn_text = 'DB Error: '
                                        + CAST(@i_error_no AS VARCHAR(20)) + ' Error msg: '
                                        + @s_error_descr;
                                    SET @SWP_Ret_Value = -1;
                                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                                    RETURN;
                                END;
	   
               
            
           	-- set record to "E" for  zip code
                            UPDATE  dbo.dls_fee_zip
                            SET     dls_status = 'E'
                            WHERE   dls_sir_id = @t_sir_id;

	   -- fatal err, rollback and cont with next zip code
							IF ERROR_NUMBER()=50000
							BEGIN
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @Error_no;
							END
               
                        END CATCH;
                    END;
         --FETCH NEXT FROM @c1FeeSir INTO @t_sir_id,@t_zip_code_3,@t_zip_code
                    SET @cur2_i = @cur2_i + 1;
                END;
      --CLOSE @c1FeeSir  --end outer loop, based on unique alt_id------------------

            SET @i_error_count = @i_total_count - @i_succ_count;
            EXECUTE @SWV_dl_upd_statistics= dbo.dl_upd_statistics @i_stats_id,
                @i_total_count, @i_succ_count, @i_error_count;
            IF @SWV_dl_upd_statistics <> 1

-- TRACE OFF;
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_total_count,
                                                 ' Failed to update statistics');
                    RETURN;
                END;


-- updates this step (sp_id) to S  Success/Complete  --
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

--  updates entire batch status to S Success/Complete  --
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @p_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT(@i_succ_count,
                                         ' records are updated for Batch ',
                                         @p_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
		SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            IF @a_error_no > 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
         --set @SWP_Ret_Value1 = @s_err_rtn_text
                    SET @SWP_Ret_Value1 = @s_error_descr;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                                 ' Error msg: ',
                                                 @s_error_descr);
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                    RETURN;
                END;
        END CATCH;
        SET NOCOUNT OFF;

--TRACE OFF;


--------------------------------------------------------------------------------

--SET DEBUG FILE TO  '/tmp/dlp_up_fee_zip.trc';
--TRACE ON;

    END;