﻿CREATE PROCEDURE [dbo].[dlp_up_fee_sched]
    @p_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
	

------------------------------------------------------------------------------
--
--            Procedure:   dlp_up_fee_sched
--
--            Created:     06/04/99
--            Author:      Ameeta Mahendra
--
-- Purpose:  This SP performs update processing on
--		DataDental Fee Schedule tables
--           for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;

        DECLARE @i_stats_id INT;
        DECLARE @i_zip_count INT;

        DECLARE @i_error_count INT;
        DECLARE @i_total_count INT;
        DECLARE @i_init_count INT;
        DECLARE @i_count INT;
        DECLARE @i_fatal INT;
        DECLARE @i_succ_count INT;
        DECLARE @i_last_total INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id2 INT;
        DECLARE @i_sp_id2 INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @s_proc_name VARCHAR(20);
        DECLARE @s_sir_def_name VARCHAR(20);
        DECLARE @c_cur_err_flag CHAR(1);

        DECLARE @t_sir_id INT;
        DECLARE @temp_sir_id INT;
        DECLARE @s_zip CHAR(10);
--define	s_d_proc_code	char(5);

        DECLARE @t_zip_code_3 CHAR(3);
        DECLARE @t_zip_code CHAR(3);

        DECLARE @d_p_eff_date DATE;
        DECLARE @s_p_version CHAR(6);
        DECLARE @s_p_source CHAR(6);
        DECLARE @i_p_percent1 CHAR(3);
        DECLARE @i_p_percent2 CHAR(3);
        DECLARE @i_p_percent3 CHAR(3);
        DECLARE @i_p_percent4 CHAR(3);
        DECLARE @i_p_percent5 CHAR(3);
        DECLARE @i_p_percent6 CHAR(3);
        DECLARE @i_p_percent7 CHAR(3);
        DECLARE @i_p_percent8 CHAR(3);

        DECLARE @s_p_eff_date CHAR(10);

        DECLARE @s_version SMALLINT;

        DECLARE @s_user CHAR(10);
        DECLARE @dt_current DATETIME;

        DECLARE @i_FEEID1 INT;
        DECLARE @i_FEEID2 INT;
        DECLARE @i_FEEID3 INT;
        DECLARE @i_FEEID4 INT;
        DECLARE @i_FEEID5 INT;
        DECLARE @i_FEEID6 INT;
        DECLARE @i_FEEID7 INT;
        DECLARE @i_FEEID8 INT;

        DECLARE @s_code_type CHAR(2);
        DECLARE @s_sir_id INT;
        DECLARE @s_zip_code_3 CHAR(3);
        DECLARE @s_d_proc_code CHAR(5);
        DECLARE @s_percentile1 CHAR(10);
        DECLARE @s_percentile2 CHAR(10);
        DECLARE @s_percentile3 CHAR(10);
        DECLARE @s_percentile4 CHAR(10);
        DECLARE @s_percentile5 CHAR(10);
        DECLARE @s_percentile6 CHAR(10);
        DECLARE @s_percentile7 CHAR(10);
        DECLARE @s_percentile8 CHAR(10);
        DECLARE @i_percentile1 DECIMAL(7, 2);
        DECLARE @i_percentile2 DECIMAL(7, 2);
        DECLARE @i_percentile3 DECIMAL(7, 2);
        DECLARE @i_percentile4 DECIMAL(7, 2);
        DECLARE @i_percentile5 DECIMAL(7, 2);
        DECLARE @i_percentile6 DECIMAL(7, 2);
        DECLARE @i_percentile7 DECIMAL(7, 2);
        DECLARE @i_percentile8 DECIMAL(7, 2);


        DECLARE @s_fee_sched_code1 CHAR(25);
        DECLARE @s_fee_sched_code2 CHAR(25);
        DECLARE @s_fee_sched_code3 CHAR(25);
        DECLARE @s_fee_sched_code4 CHAR(25);
        DECLARE @s_fee_sched_code5 CHAR(25);
        DECLARE @s_fee_sched_code6 CHAR(25);
        DECLARE @s_fee_sched_code7 CHAR(25);
        DECLARE @s_fee_sched_code8 CHAR(25);
        DECLARE @s_fee_sched_desc1 CHAR(50);
        DECLARE @s_fee_sched_desc2 CHAR(50);
        DECLARE @s_fee_sched_desc3 CHAR(50);
        DECLARE @s_fee_sched_desc4 CHAR(50);
        DECLARE @s_fee_sched_desc5 CHAR(50);
        DECLARE @s_fee_sched_desc6 CHAR(50);
        DECLARE @s_fee_sched_desc7 CHAR(50);
        DECLARE @s_fee_sched_desc8 CHAR(50);
        DECLARE @serialid INT;
        --DECLARE @cFeeSir CURSOR;
        --DECLARE @c1FeeSir CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;

-----exception handling---------------------------------------------------------


 -- error converting text param values to correct type


   -- intrpt - server or user terminated -----NO ROLLBACK---
        SET NOCOUNT ON;
        SET @serialid = 0;
     
        BEGIN TRY
            
            SET @s_proc_name = 'up_fee_sched';
            SET @s_sir_def_name = 'fee_sched';
            SET @dt_current = GETDATE();
            SET @s_user = CONCAT('dl', @p_batch_id);
			
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @p_batch_id, @s_proc_name;
			
            IF @i_sp_id = -1
			BEGIN
				SET @a_error_no = 0
                RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
				RETURN
			END

            EXECUTE @i_sp_id2 = dbo.dl_get_sp_id @p_batch_id, 'up_fee_zip';
            IF @i_sp_id2 = -1
			BEGIN
				SET @a_error_no = 0
                RAISERROR('Could not retrieve valid Second Store Procedure ID',16,1);
				RETURN
			END

            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id = -1
			BEGIN
				SET @a_error_no = 0
                RAISERROR('Could not retrieve valid SIR Table ID',16,1);
				RETURN
			END

            SET @i_sir_def_id2 = dbo.dl_get_sir_def_id('fee_zip');
            IF @i_sir_def_id2 = -1
			BEGIN
				SET @a_error_no = 0
                RAISERROR('Could not retrieve valid ZIP SIR Table ID',16,1);
				RETURN
			END


-- prepare for keeping stats on preprocessing-----------------

-- move all logged errors to the log error history table

DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 dls_sir_id INT 
                        );

						INSERT  INTO @SWV_cursor_var1
                                ( dls_sir_id 
                                )
                                SELECT dls_sir_id 
      FROM dbo.dl_log_error (NOLOCK)
      WHERE config_bat_id = @p_batch_id
      AND   sp_id = @i_sp_id
      AND   dls_sir_id IN(SELECT dls_sir_id
      FROM dbo.dls_fee_sched (NOLOCK)
      WHERE  dls_batch_id = @p_batch_id
      AND   (dls_status   = 'P'))

				DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM    @SWV_cursor_var1;


/*
            SET @cFeeSir = CURSOR  FOR SELECT dls_sir_id 
      FROM dbo.dl_log_error (NOLOCK)
      WHERE config_bat_id = @p_batch_id
      AND   sp_id = @i_sp_id
      AND   dls_sir_id IN(SELECT dls_sir_id
      FROM dbo.dls_fee_sched (NOLOCK)
      WHERE  dls_batch_id = @p_batch_id
      AND   (dls_status   = 'P'));
            OPEN @cFeeSir;
            FETCH NEXT FROM @cFeeSir INTO @temp_sir_id;
            WHILE @@FETCH_STATUS = 0
			*/

                WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @temp_sir_id =dls_sir_id 
            FROM    @SWV_cursor_var1
            WHERE   id = @cur1_i;
                    EXECUTE dbo.dl_clean_curr_err @p_batch_id, @temp_sir_id,
                        @i_sp_id, @i_error_no OUTPUT, @s_err_rtn_text OUTPUT;
                    --FETCH NEXT FROM @cFeeSir INTO @temp_sir_id;
					SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @cFeeSir;
            

-- get initial count of rows that have passed pre-processing --
            SELECT  @i_init_count = COUNT(*)
            FROM    dbo.dls_fee_sched (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'P';

/*
SELECT cfg_bat_det_id INTO i_cfg_bat_det_id
FROM dl_cfg_bat_det
WHERE config_bat_id = p_batch_id and sp_id = i_sp_id;
*/
            EXECUTE dbo.dl_it_statistics @p_batch_id, @i_sp_id, @a_start_time,
                @a_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_stats_id OUTPUT, @s_error_descr OUTPUT;
            IF @a_error_no <= 0
			BEGIN
				SET @a_error_no = 0
                RAISERROR('(Internal) error when creating statistics',16,1);
				RETURN
			END

            SET @i_total_count = 0;
            SET @i_succ_count = 0;
            SET @i_last_total = 0;
----------get params from user--------------------
            SET @s_p_eff_date = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                    'Run Date');
            IF ( @s_p_eff_date IS NULL
                 OR @s_p_eff_date = ''
               )
                OR LEN(@s_p_eff_date) < 1
				BEGIN
					SET @a_error_no = 0
					RAISERROR('Missing Run Date parameter value',16,1);
					RETURN
				END
            ELSE
                BEGIN
                    SET @s_err_rtn_text = 'Can not convert Run Date to type Date';
                    SET @a_error_no = 1;
                    SET @d_p_eff_date = @s_p_eff_date;
                    SET @a_error_no = 0;
                END;

            SET @s_p_version = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                      'Version');
            IF ( @s_p_version IS NULL
                 OR @s_p_version = ''
               )
                OR LEN(@s_p_version) < 6
				BEGIN
					SET @a_error_no = 0
                RAISERROR('Missing Version parameter value',16,1);
				RETURN
				END

            SET @s_p_source = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                     'Source');
            IF ( @s_p_source IS NULL
                 OR @s_p_source = ''
               )
                OR LEN(@s_p_source) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Source parameter value',16,1);
				RETURN
				END

            IF EXISTS ( SELECT  *
                        FROM    dbo.fee_source
                        WHERE   source = @s_p_source
                                AND version = @s_p_version )
								BEGIN
								SET @a_error_no = 0
                RAISERROR('Source & Version Already exists in DataDental',16,1);
				RETURN
				END

            SET @i_p_percent1 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 1');
            IF ( @i_p_percent1 IS NULL
                 OR @i_p_percent1 = ''
               )
                OR LEN(@i_p_percent1) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 1 parameter value',16,1);
				RETURN
				END

            SET @i_p_percent2 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 2');
            IF ( @i_p_percent2 IS NULL
                 OR @i_p_percent2 = ''
               )
                OR LEN(@i_p_percent2) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 2 parameter value',16,1);
				RETURN
				END

            SET @i_p_percent3 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 3');
            IF ( @i_p_percent3 IS NULL
                 OR @i_p_percent3 = ''
               )
                OR LEN(@i_p_percent3) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 3 parameter value',16,1);
				RETURN
				END

            SET @i_p_percent4 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 4');
            IF ( @i_p_percent4 IS NULL
OR @i_p_percent4 = ''
               )
                OR LEN(@i_p_percent4) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 4 parameter value',16,1);
				END

            SET @i_p_percent5 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 5');
            IF ( @i_p_percent5 IS NULL
                 OR @i_p_percent5 = ''
               )
                OR LEN(@i_p_percent5) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 5 parameter value',16,1);
				RETURN
				END

            SET @i_p_percent6 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 6');
            IF ( @i_p_percent6 IS NULL
                 OR @i_p_percent6 = ''
               )
                OR LEN(@i_p_percent6) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 6 parameter value',16,1);
				END

            SET @i_p_percent7 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 7');
            IF ( @i_p_percent7 IS NULL
                 OR @i_p_percent7 = ''
               )
     OR LEN(@i_p_percent7) < 1
	 BEGIN
	 SET @a_error_no = 0
                RAISERROR('Missing Percentile 7 parameter value',16,1);
				RETURN
				END

            SET @i_p_percent8 = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Percentile 8');
            IF ( @i_p_percent8 IS NULL
                 OR @i_p_percent8 = ''
               )
                OR LEN(@i_p_percent8) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Percentile 8 parameter value',16,1);
				RETURN
				END

            IF @i_p_percent1 IN ( @i_p_percent2, @i_p_percent3, @i_p_percent4,
                                  @i_p_percent5, @i_p_percent6, @i_p_percent7,
                                  @i_p_percent8 )
								  BEGIN
								  SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 1',16,1);
				RETURN
				END

            IF @i_p_percent2 IN ( @i_p_percent3, @i_p_percent4, @i_p_percent5,
                                  @i_p_percent6, @i_p_percent7, @i_p_percent8 )
								  BEGIN
								  SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 2',16,1);
				RETURN
				END

            IF @i_p_percent3 IN ( @i_p_percent4, @i_p_percent5, @i_p_percent6,
                                  @i_p_percent7, @i_p_percent8 )
					BEGIN
					SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 3',16,1);
				RETURN
				END

            IF @i_p_percent4 IN ( @i_p_percent5, @i_p_percent6, @i_p_percent7,
                                  @i_p_percent8 )
								BEGIN
								SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 4',16,1);
				RETURN
				END

            IF @i_p_percent5 IN ( @i_p_percent6, @i_p_percent7, @i_p_percent8 )
			BEGIN
			SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 5',16,1);
			RETURN
				END

            IF @i_p_percent6 IN ( @i_p_percent7, @i_p_percent8 )
			BEGIN
			SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 6',16,1);
				RETURN
				END

            IF @i_p_percent7 IN ( @i_p_percent8 )
			BEGIN
			SET @a_error_no = 100
                RAISERROR('Duplicate Value in Parameter Percentile 7',16,1);
				RETURN
				END

            SET @s_code_type = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                      'Code Type ');
            IF ( @s_code_type IS NULL
                 OR @s_code_type = ''
               )
                OR LEN(@s_code_type) < 1
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Code Type  parameter value',16,1);
				RETURN
				END



	-----exception handling w/in foreach------------------------------------

            SET @c_cur_err_flag = 'F';
-----begin processing one zip code record at a time-----------------------------
-----the outer loop will create the fee_sched_h, fee_sched_d, fee_source entry -----


	   -- problems retrieving data from dB --------
	   

      -------------------------------------------------------------------------


	


/*
	---------update stats every 100 records-----------------------
	IF i_total_count >= (i_last_total + 2) THEN

	   LET i_error_count = i_total_count - i_succ_count;

	   -----update the stats----------
	   UPDATE dl_bat_statistics
	   SET (tot_record,    tot_success_rec, tot_fail_rec) =
	       (i_total_count, i_succ_count,    i_error_count)
	 WHERE bat_statistics_id = i_stats_id;

	   LET i_last_total = i_total_count;
	END IF;

*/
IF OBJECT_ID('tempdb..#SWV_cursor_var2 ') IS NOT NULL
    DROP TABLE #SWV_cursor_var2 

CREATE TABLE #SWV_cursor_var2 
                        (
                         id INT IDENTITY ,
						 dls_sir_id INT,
						 zip_code_3 CHAR(3), 
						 zip_code CHAR(3)
                        );

						INSERT  INTO #SWV_cursor_var2
                                ( dls_sir_id, zip_code_3, zip_code
                                )
                                SELECT dls_sir_id, zip_code_3, zip_code
	
      FROM   dbo.dls_fee_zip (NOLOCK)
      WHERE  dls_batch_id = @p_batch_id
      AND	zip_code_3 = zip_code
      AND    (dls_status   = 'P' OR dls_status = 'V')

				DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
                        FROM    #SWV_cursor_var2;


/*
            SET @c1FeeSir = CURSOR  FOR SELECT dls_sir_id, zip_code_3, zip_code
	
      FROM   dbo.dls_fee_zip (NOLOCK)
      WHERE  dls_batch_id = @p_batch_id
      AND	zip_code_3 = zip_code
      AND    (dls_status   = 'P' OR dls_status = 'V');
            OPEN @c1FeeSir;
            FETCH NEXT FROM @c1FeeSir INTO @t_sir_id, @t_zip_code_3,
                @t_zip_code;
            WHILE @@FETCH_STATUS = 0
			*/

               WHILE ( @cur2_i <= @cur2_cnt )
            BEGIN
			SELECT  @t_sir_id=dls_sir_id,
			@t_zip_code_3= zip_code_3,
			@t_zip_code=zip_code
            FROM    #SWV_cursor_var2
            WHERE   id = @cur2_i;
                    BEGIN
                        --DECLARE @c2FeeSir CURSOR;
           	-- set all records to "E" for  zip code
		   


	   -- if fatal err, rollback and cont with next grp - else resume
		  --LET i_fatal = dl_log_error(p_batch_id, i_sp_id,
		   -- i_sir_def_id, 0, i_isam_error);
                        BEGIN TRY
                           
                            SET @a_error_no = 0;
                            SET @c_cur_err_flag = 'F';
                            IF ( @t_zip_code_3 IS NULL
                                 OR @t_zip_code_3 = ''
                               )
                                OR LEN(@t_zip_code_3) != 3
								BEGIN
								SET @a_error_no = 10
                                RAISERROR('Invalid initial ZIP code ',16,1);
								RETURN
				END
	
                            IF ( @t_zip_code IS NULL
                                 OR @t_zip_code = ''
                               )
                                OR LEN(@t_zip_code) != 3
								BEGIN
								SET @a_error_no = 20
                                RAISERROR('Invalid Required ZIP code ',16,1);
								RETURN
				END
	
                            SET @i_total_count = @i_total_count + 1;
                            SET @s_fee_sched_code1 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
                                + @i_p_percent1;
                            SET @s_fee_sched_desc1 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent1 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code2 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
           + @i_p_percent2;
                            SET @s_fee_sched_desc2 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent2 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code3 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
                                + @i_p_percent3;
                            SET @s_fee_sched_desc3 = RTRIM(LTRIM(@s_p_source))
                  + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent3 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code4 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
                                + @i_p_percent4;
                            SET @s_fee_sched_desc4 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent4 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code5 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
                                + @i_p_percent5;
                            SET @s_fee_sched_desc5 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent5 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code6 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
                                + @i_p_percent6;
                            SET @s_fee_sched_desc6 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent6 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code7 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
                                + @i_p_percent7;
                            SET @s_fee_sched_desc7 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent7 + ' ZIP:' + @t_zip_code;
                            SET @s_fee_sched_code8 = RTRIM(LTRIM(@s_p_source))
                                + '-' + @s_p_version + '-' + @t_zip_code + '-'
          + @i_p_percent8;
                            SET @s_fee_sched_desc8 = RTRIM(LTRIM(@s_p_source))
                                + '- Version:' + @s_p_version + ' Percentile:'
                                + @i_p_percent8 + ' ZIP:' + @t_zip_code;
                            SET @s_version = SUBSTRING(@s_p_version, 5, 2);

-- INSERT record into fee_sched_h fee_sched_d tables----------------------------

-- insert First percentile record into fee_sched_h, fee_sched_d
                            SET @a_error_no = 210; 	-----insert in fee_sched_h failed

							
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code1 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc1 ,
                                      @d_p_eff_date ,
                               NULL ,
                                      NULL ,
                                      1
     );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID1 = @@identity;
                            IF @i_FEEID1 IS NULL
							BEGIN 
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
							END
	
------
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code2 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc2 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      NULL ,
                                      1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID2 = @@identity;
                            IF @i_FEEID2 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
							END

	
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code3 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc3 ,
                                      @d_p_eff_date ,
                    NULL ,
                                      NULL ,
                                      1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID3 = @@identity;
                            IF @i_FEEID3 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
				END
	
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code4 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc4 ,
    @d_p_eff_date ,
                                      NULL ,
                                      NULL ,
                                      1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID4 = @@identity;
                 IF @i_FEEID4 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
				END
	
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code5 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc5 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      NULL ,
                                      1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID5 = @@identity;
                            IF @i_FEEID5 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
				END
	
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code6 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc6 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      NULL ,
                           1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID6 = @@identity;
                            IF @i_FEEID6 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
				END
	
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
                                    )
                            VALUES  ( @s_fee_sched_code7 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc7 ,
                         @d_p_eff_date ,
                                      NULL ,
                                      NULL ,
                                      1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID7 = @@identity;
                            IF @i_FEEID7 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
				END
	
                            INSERT  INTO dbo.fee_sched_h
                                    ( fee_sched_code ,
                                      version ,
                                      code_type ,
                                      descr ,
                                      eff_date ,
                                      exp_date ,
                                      create_mode ,
                                      ext_source_sw
  )
                            VALUES  ( @s_fee_sched_code8 ,
                                      @s_version ,
                                      @s_code_type ,
                                      @s_fee_sched_desc8 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      NULL ,
                                      1
                                    );

	   -- retrieve Fee id for new fee_sched just added
	
                            
                            SET @i_FEEID8 = @@identity;
                            IF @i_FEEID8 IS NULL
							BEGIN
							SET @a_error_no = 210
                                RAISERROR('Could not insert record into fee_sched_h table',16,1);
								RETURN
				END
	
                            SET @a_error_no = 220;	----insert into fee_sched_d failed

							
                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID1 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID2 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID3 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID4 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID5 ,
                                            d_proc_code ,
                                  0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID6 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
								 FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID7 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

                            INSERT  INTO dbo.fee_sched_d(fee_sched_id,d_proc_code,amount,[percent],amount_type)
                                    SELECT  @i_FEEID8 ,
                                            d_proc_code ,
                                            0 ,
                                            0 ,
                                            '$'
                                    FROM    dbo.plx_dent_proc
                                    WHERE   code_type = @s_code_type;

------------EXPIRE previous verion of schedule in fee_source table
                            SET @a_error_no = 50;	----update into fee_source failed
                            UPDATE  dbo.fee_source
                            SET     exp_date = @d_p_eff_date
                            WHERE   source = @s_p_source
                                    AND zip_code_3 = @t_zip_code_3
                                    AND exp_date IS NULL
                                    AND percentile IN ( @i_p_percent1,
                                                        @i_p_percent2,
                                                        @i_p_percent3,
                                                        @i_p_percent4,
                                                        @i_p_percent5,
                                                        @i_p_percent6,
                                                        @i_p_percent7,
                                                        @i_p_percent8 );
                            SET @a_error_no = 30;	----insert into fee_source failed
--INSERT records into fee_source table one for each percentile---------
                            INSERT  INTO dbo.fee_source
                                  ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
                                    )
                            VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent1 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID1 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                                    );
	
      INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
                                    )
                            VALUES  ( @s_p_source ,
                             @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent2 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID2 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                     );
	
                            INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
                                    )
                            VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent3 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID3 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                                    );
	
                            INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
  )
                            VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent4 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID4 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                                    );
	
                            INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
                                    )
                     VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent5 ,
   @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID5 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                                    );
	
                            INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
         h_action
                                    )
                            VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent6 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID6 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                                    );
	
                            INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
                                    )
                            VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent7 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID7 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                   );
	

	------------------begin exception handling----------------------
	
                            INSERT  INTO dbo.fee_source
                                    ( source ,
                                      version ,
                                      zip_code_3 ,
                                      percentile ,
                                      eff_date ,
                                      exp_date ,
                                      fee_sched_id ,
                                      h_datetime ,
                                      h_user ,
                                      h_action
                                    )
                            VALUES  ( @s_p_source ,
                                      @s_p_version ,
                                      @t_zip_code ,
                                      @i_p_percent8 ,
                                      @d_p_eff_date ,
                                      NULL ,
                                      @i_FEEID8 ,
                                      @dt_current ,
                                      @s_user ,
                                      'IN'
                                 );
---------------------

	

		-- problems retrieving data from dB --------
		
	-------------begin body of procedure----------------------------
	IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
    DROP TABLE #SWV_cursor_var3

	CREATE TABLE #SWV_cursor_var3 
                        (
                         id INT IDENTITY ,
						 dls_sir_id INT, 
						 zip_code_3 CHAR(3), 
						 d_proc_code CHAR(5),
						 percentile1 CHAR(6),
		                 percentile2 CHAR(6),
		                 percentile3 CHAR(6),
		                 percentile4 CHAR(6),
		                 percentile5 CHAR(6), 
		                 percentile6 CHAR(6), 
		                 percentile7 CHAR(6), 
		                 percentile8 CHAR(6)
                        );	

						INSERT  INTO #SWV_cursor_var3
                               (dls_sir_id, 
								zip_code_3, 
								d_proc_code,
								percentile1,
		                        percentile2,
		                        percentile3,
		                        percentile4,
		                        percentile5, 
		                        percentile6, 
		                        percentile7, 
		                        percentile8
                                )
                                SELECT dls_sir_id, zip_code_3, d_proc_code, percentile1,
		percentile2, percentile3, percentile4,
		percentile5, percentile6, percentile7, percentile8
	   
               FROM dbo.dls_fee_sched
               WHERE dls_batch_id = @p_batch_id
               AND zip_code_3 = @t_zip_code
               AND   (dls_status   = 'P' OR dls_status = 'V')

				DECLARE @cur3_cnt INT ,
                            @cur3_i INT;

                        SET @cur3_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur3_cnt = COUNT(1)
                        FROM    #SWV_cursor_var3;

	
	/*
                            SET @c2FeeSir = CURSOR  FOR SELECT dls_sir_id, zip_code_3, d_proc_code, percentile1,
		percentile2, percentile3, percentile4,
		percentile5, percentile6, percentile7, percentile8
	   
               FROM dbo.dls_fee_sched
               WHERE dls_batch_id = @p_batch_id
               AND zip_code_3 = @t_zip_code
               AND   (dls_status   = 'P' OR dls_status = 'V');
                            OPEN @c2FeeSir;
                            FETCH NEXT FROM @c2FeeSir INTO @s_sir_id,
                                @s_zip_code_3, @s_d_proc_code, @s_percentile1,
                                @s_percentile2, @s_percentile3, @s_percentile4,
                                @s_percentile5, @s_percentile6, @s_percentile7,
                                @s_percentile8;
                            WHILE @@FETCH_STATUS = 0
							*/
                                WHILE ( @cur3_i <= @cur3_cnt )
            BEGIN
			SELECT  @s_sir_id =dls_sir_id,
                    @s_zip_code_3 =zip_code_3,
			        @s_d_proc_code =d_proc_code, 
					@s_percentile1 =percentile1,
                    @s_percentile2 =percentile2, 
					@s_percentile3 =percentile3, 
					@s_percentile4 =percentile4,
                    @s_percentile5 =percentile5, 
					@s_percentile6 =percentile6, 
					@s_percentile7 =percentile7,
                    @s_percentile8 =percentile8
            FROM    #SWV_cursor_var3
            WHERE   id = @cur3_i;
                                    BEGIN
                                        BEGIN TRY
                                            
                                            SET @i_percentile1 = @s_percentile1;
                                            IF ( @s_percentile1 IS NULL
                                                 OR @s_percentile1 = ''
                                               )
                                                OR LEN(@s_percentile1) = 0
												BEGIN
												SET @a_error_no = 110
                                                RAISERROR('Non numeric percentile 1 ',16,1);
												RETURN
				END
        
                                            
                                            SET @i_percentile2 = @s_percentile2;
										  IF ( @s_percentile2 IS NULL
										 OR @s_percentile2 = ''
                                               )
                                                OR LEN(@s_percentile2) = 0
												BEGIN
												SET @a_error_no = 120
                                                RAISERROR('Non numeric percentile 2 ',16,1);
												RETURN
				END
        
                                            
                                            SET @i_percentile3 = @s_percentile3;
                                            IF ( @s_percentile3 IS NULL
                                                 OR @s_percentile3 = ''
                                             )
                                                OR LEN(@s_percentile3) = 0
												BEGIN
												SET @a_error_no = 130
                                                RAISERROR('Non numeric percentile 3 ',16,1);
												RETURN
				END
        
                                   
                                            SET @i_percentile4 = @s_percentile4;
                                            IF ( @s_percentile4 IS NULL
                                                 OR @s_percentile4 = ''
                                               )
                                                OR LEN(@s_percentile4) = 0
												BEGIN
												SET @a_error_no = 140
                                                RAISERROR('Non numeric percentile 4 ',16,1);
												RETURN
				END
        
                                            
                                            SET @i_percentile5 = @s_percentile5;
                                            IF ( @s_percentile5 IS NULL
                                                 OR @s_percentile5 = ''
                                               )
                                                OR LEN(@s_percentile5) = 0
												BEGIN
												SET @a_error_no = 150
                                                RAISERROR('Non numeric percentile 5 ',16,1);
												RETURN
				END
        
                                            
                                            SET @i_percentile6 = @s_percentile6;
                                            IF ( @s_percentile6 IS NULL
                                                 OR @s_percentile6 = ''
                                               )
                                                OR LEN(@s_percentile6) = 0
												BEGIN
												SET @a_error_no = 160;
                                                RAISERROR('Non numeric percentile 6 ',16,1);
												RETURN
				END
        
                                            
                                            SET @i_percentile7 = @s_percentile7;
                                            IF ( @s_percentile7 IS NULL
                                                 OR @s_percentile7 = ''
                                               )
                                                OR LEN(@s_percentile7) = 0
												BEGIN
												SET @a_error_no = 170;
                                                RAISERROR('Non numeric percentile 7 ',16,1);
												RETURN
												END
        
                                            
                                            SET @i_percentile8 = @s_percentile8;
                                            IF ( @s_percentile8 IS NULL
                                                 OR @s_percentile8 = ''
                                               )
                                                OR LEN(@s_percentile8) = 0
												BEGIN
												SET @a_error_no = 180
                                                RAISERROR('Non numeric percentile 8 ',16,1);
												RETURN
				END
        
                                            SET @a_error_no = 40; 	----------fee_sched_d update failed
	--insert record into fee_sched_d table
            UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile1
                                            WHERE   fee_sched_id = @i_FEEID1
                                                    AND d_proc_code = @s_d_proc_code;
                                            UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile2
                             WHERE   fee_sched_id = @i_FEEID2
                                                    AND d_proc_code = @s_d_proc_code;
                                            UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile3
                                            WHERE   fee_sched_id = @i_FEEID3
                                                    AND d_proc_code = @s_d_proc_code;
                                            UPDATE  dbo.fee_sched_d
                                        SET     amount = @i_percentile4
                                            WHERE   fee_sched_id = @i_FEEID4
                                                    AND d_proc_code = @s_d_proc_code;
        UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile5
                                            WHERE   fee_sched_id = @i_FEEID5
                                                    AND d_proc_code = @s_d_proc_code;
                                            UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile6
                                            WHERE   fee_sched_id = @i_FEEID6
                                                    AND d_proc_code = @s_d_proc_code;
                                            UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile7
                                            WHERE   fee_sched_id = @i_FEEID7
                                                    AND d_proc_code = @s_d_proc_code;
                                            UPDATE  dbo.fee_sched_d
                                            SET     amount = @i_percentile8
                                            WHERE   fee_sched_id = @i_FEEID8
                                                    AND d_proc_code = @s_d_proc_code;
                                            
											UPDATE  dbo.dls_fee_sched
                                            SET     dls_status = 'U'
											where dls_sir_id = @s_sir_id
                                            
                                        END TRY
                                        BEGIN CATCH
                                            SET @i_error_no = ERROR_NUMBER();
                                            SET @i_isam_error = ERROR_LINE();
                                            SET @s_error_descr = ERROR_MESSAGE();
                                            IF @i_error_no IN ( -244, -245,
                                                              -246 )
                                                SET @a_error_no = 1000;
		
                                            IF @a_error_no = 0
                                                SET @a_error_no = @i_error_no;
		
                                            
                                            UPDATE  dbo.dls_fee_zip
                                            SET     dls_status = 'E'
                                            WHERE   dls_sir_id = @t_sir_id;
                                            UPDATE  dbo.dls_fee_sched
                                            SET     dls_status = 'E'
                            WHERE   dls_sir_id = @s_sir_id;

		-- log error that occurred on current record
                                            EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                 @i_sp_id, @i_sir_def_id,
                                                @s_sir_id, @a_error_no;
                  

		-- set flag t indicate an error
                                            SET @c_cur_err_flag = 'T';

		-- break out of inner loop & continue with
		-- next zip code header
                                            GOTO SWL_Label2;
                       END CATCH;
                                    END;
                                    --FETCH NEXT FROM @c2FeeSir INTO @s_sir_id,
                                    --    @s_zip_code_3, @s_d_proc_code,
                                    --    @s_percentile1, @s_percentile2,
                                    --    @s_percentile3, @s_percentile4,
                                    --    @s_percentile5, @s_percentile6,
               --    @s_percentile7, @s_percentile8;
									SET @cur3_i = @cur3_i + 1;
                                END;
                            SWL_Label2:
                            --CLOSE @c2FeeSir;  --end inner loop, based on unique proc_code------------------
	-- only commit work if no err for this header group
                            IF @c_cur_err_flag = 'F'
                                BEGIN
                                    UPDATE  dbo.dls_fee_zip
                                    SET     dls_status = 'U'
                                    WHERE   dls_sir_id = @t_sir_id;
--CURRENT OF c1FeeSir;
                                    SET @i_succ_count = @i_succ_count + 1;
                                    
                                END;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -244, -245, -246 )
                                SET @a_error_no = 1000; -- db locked by another user -- fatal
	   

           -- must have been an unexpected db error
                            IF @a_error_no = 0
                                BEGIN
                                    SET @s_err_rtn_text = 'DB Error: '
                                        + @i_error_no + ' Error msg: '
                                        + @s_error_descr;
                                    SET @SWP_Ret_Value = -1;
                                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                                    RETURN;
                                END;
	   
                           
                            
           	-- set all records to "E" for  zip code
                            UPDATE  dbo.dls_fee_zip
                            SET     dls_status = 'E'
                            WHERE   dls_sir_id = @t_sir_id;

	   -- fatal err, rollback and cont with next zip code
		   --LET i_fatal = dl_log_error(p_batch_id, i_sp_id,
		    --i_sir_def_id, 0, a_error_no);
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                @i_sp_id2, @i_sir_def_id2, @t_sir_id,
                                @a_error_no;
                            
                        END CATCH;
                    END;
                    --FETCH NEXT FROM @c1FeeSir INTO @t_sir_id, @t_zip_code_3,
                    --    @t_zip_code;
					SET @cur2_i = @cur2_i + 1;
                END;
            --CLOSE @c1FeeSir;  --end outer loop, based on unique alt_id------------------

--SELECT count(*)
--INTO  i_succ_count
--FROM dls_fee_zip
--WHERE dls_batch_id = p_batch_id
--AND dls_status = "U";

            SET @i_error_count = @i_total_count - @i_succ_count;
            EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_stats_id, @i_total_count,
                @i_succ_count, @i_error_count;
  IF @SWV_dl_upd_statistics <> 1

-- TRACE OFF;
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_total_count,
                                                 ' Failed to update statistics');
                    RETURN;
                END;


-- updates this step (sp_id) to S  Success/Complete  --
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

--  updates entire batch status to S Success/Complete  --
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @p_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT(@i_succ_count,
                                         ' records are updated for Batch ',
                                         @p_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
			
        IF @i_error_no > 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    --SET @SWP_Ret_Value1 = @s_err_rtn_text;
					SET @SWP_Ret_Value1 = @s_error_descr;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                                 ' Error msg: ',
                                                 @s_error_descr);
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                    RETURN;
                END;
        END CATCH;
        SET NOCOUNT OFF;

--TRACE OFF;


--------------------------------------------------------------------------------

--SET DEBUG FILE TO  '/tmp/dlp_up_fee_sched.trc';
--TRACE ON;

--set explain on;
    END;