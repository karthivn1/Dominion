﻿CREATE PROCEDURE [dbo].[dlp_al_eligibility]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:02:02 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1















000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @do_trace BIT;

--error variables
        DECLARE @i_error_no INT;
		DECLARE @error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(18);
        DECLARE @s_proc_name CHAR(18);
        DECLARE @a_error_no INT;

        DECLARE @i_pre_process_sp INT;

        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @i_count INT;
		
        DECLARE @s_error CHAR(1);

        DECLARE @t_sir_id INT;
        DECLARE @t_sub_sir_id INT;
        DECLARE @t_sub_alt_id CHAR(20);
        DECLARE @t_alt_id CHAR(20);
        DECLARE @t_member_flag CHAR(2);
        DECLARE @t_ssn CHAR(11);
        DECLARE @t_sub_ssn CHAR(11);
        DECLARE @t_dls_status CHAR(1);
        DECLARE @n_mb_ssn CHAR(11);
        DECLARE @n_mb_sub_ssn CHAR(11);
        DECLARE @n_sub_sir_id INT;


        DECLARE @n_process_count INT;
        DECLARE @n_sub_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @n_al_count INT;
        DECLARE @n_count INT;
        DECLARE @i_delete_id INT;
        DECLARE @s_sub_alt_id CHAR(20);
/* 20130514$$ks - added def_key and type variables */
        DECLARE @s_def_key CHAR(2);
        DECLARE @s_type CHAR(2);
/* 20131229$$ks - added group and plan
 */
        DECLARE @s_member_id INT;
        DECLARE @s_group_id INT;
        DECLARE @s_plan_id INT;
        DECLARE @true VARCHAR(5);
        DECLARE @false VARCHAR(5);
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_config_id INT;
        DECLARE @s_create_ssn CHAR(1);
        DECLARE @s_lookup_by CHAR(1);
        DECLARE @SWV_dl_get_sp_id INT;
        -- DECLARE @SWV_cursor_var1 CURSOR;
        -- DECLARE @cSIR CURSOR;
        -- DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;
        DECLARE @v_Null INT;
		DECLARE @created_by CHAR(15)

        SET NOCOUNT ON;
        SET @true = 't';
   
        SET @false = 'f';
        
        SET @i_sp_id = 0;
        
        SET @i_sir_def_id = 0 ;
      
        SET @i_config_id = 0;
        
        SET @s_create_ssn = '';
        
        SET @s_lookup_by = '';
        
        BEGIN TRY
            
            SET @do_trace = 1;
            IF ( @do_trace = 1 )
                BEGIN--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/dlp_al_eligibility_dev_" || a_batch_id || ".trc";

	--TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;

            BEGIN
                DECLARE @currentDateAndTime DATETIME;
                DECLARE @userSessionId INT;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "dlp_al_eligibility():  Entered.";
                        SET @v_Null = 0;
                    END;
	
                SET @currentDateAndTime = GETDATE();
                SET @userSessionId = @@spid;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "a_batch_id = " || a_batch_id;

		--TRACE statement has no equivalent in MSSQL
--trace "a_start_time = " || a_start_time;
                        SET @v_Null = 0;
                    END;
	
            END;
            
            
            SET @s_proc_name = 'al_eligibility';
            SET @s_sir_def_name = 'elig';
            EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, @s_proc_name
              
            SET @i_sp_id = @SWV_dl_get_sp_id ;
            
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name) ;
            
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;
            
			SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id

            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                     --ORIGINAL_LOGIN() ,
					 @created_by,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
                       
            SET @s_create_ssn = dbo.dl_get_param_value(@a_batch_id,
                                                            @i_sp_id,
                                                            'create ssn');
            
            IF ( @s_create_ssn IS NULL
                 OR @s_create_ssn = ''
               )
			   BEGIN
			   SET @error_no = 0
                RAISERROR('Missing Flag for creating ssn',16,1);
				END
            ELSE
                BEGIN
                    
                    IF @s_create_ssn NOT IN ( 'Y', 'N' )
					BEGIN
					SET @error_no = 0
                        RAISERROR('Invalid flag for creating ssn',16,1);
						END
                END;
	
            EXECUTE @i_pre_process_sp = dbo.dl_get_sp_id @a_batch_id,
                'bu_eligibility';
            SET @s_lookup_by = dbo.dl_get_param_value(@a_batch_id,
                                                           @i_pre_process_sp,
                                                           'SSN/ALT');
      
            IF ( @s_lookup_by IS NULL
                 OR @s_lookup_by = ''
               )
			   BEGIN
			   SET @error_no = 0
                RAISERROR('Mising Flag for Lookup Member',16,1);
				END
            ELSE
                BEGIN
                   
                    IF @s_lookup_by NOT IN ( 'A', 'S', 'U', 'F', 'Z' )
					BEGIN
					SET @error_no = 0
                        RAISERROR('Invalid Flag for Lookup Member',16,1);
						END
                END;
	
            
            IF @s_lookup_by = 'S'
                AND @s_create_ssn = 'Y'
				BEGIN
				SET @error_no = 0
                RAISERROR('Can not create SSN if lookup is based on SSN',16,1);
				END

            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  sub_alt_id CHAR(20) ,
                  dls_sir_id INT
                );
							
            SET @n_sub_count = 0;
            SET @n_process_count = 0;
            SET @n_succ_count = 0;

		--	select @a_batch_id, @i_sp_id

		  SELECT  @n_process_count = COUNT(*)
                FROM    dbo.dls_elig (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'L';
									
            IF EXISTS ( SELECT  *
FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @a_batch_id
                                AND sp_id = @i_sp_id )
                BEGIN
                     
INSERT  INTO @SWV_cursor_var1
                            ( sub_alt_id ,
                              dls_sir_id
                            )
                            SELECT  sub_alt_id ,
                                    dls_sir_id
                FROM    dbo.dls_elig (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'L';
					/* 
					SET @SWV_cursor_var1 = CURSOR  FOR SELECT sub_alt_id, dls_sir_id
			
         FROM dbo.dls_elig (NOLOCK)
         WHERE dls_batch_id = @a_batch_id AND
         dls_status = 'L';
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @s_sub_alt_id,
                        @i_delete_id;
                    WHILE @@FETCH_STATUS = 0 
					*/
                    DECLARE @cur1_cnt INT ,
                        @cur_i INT;

                    SET @cur_i = 1;

				--Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;
				
				--while @@FETCH_STATUS = 0
                    WHILE ( @cur_i <= @cur1_cnt )
                        BEGIN
                            SELECT  @s_sub_alt_id = sub_alt_id ,
                                    @i_delete_id = dls_sir_id
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur_i;

                             EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                @i_delete_id, @i_sp_id, @i_error_no OUTPUT,
                                @s_error_descr OUTPUT;
                            UPDATE  dbo.dls_elig
                            SET     dls_status = 'L'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V'
                                    AND sub_alt_id = @s_sub_alt_id;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @s_sub_alt_id,
                            SET @cur_i = @cur_i + 1;
							                               
                        END;
                   -- CLOSE @SWV_cursor_var1;
                END;

            DECLARE @cSIR TABLE
                (
                  id INT IDENTITY ,
                  dls_sub_sir_id INT ,
                  dls_sir_id INT ,
                  sub_alt_id CHAR(20) ,
                  ssn CHAR(11) ,
				  sub_ssn CHAR(11) ,
                  def_key CHAR(2) ,
                  [type] CHAR(2) ,
                  member_id INT ,
                  group_id INT ,
                  plan_id INT
                );

            INSERT  INTO @cSIR
                    ( dls_sub_sir_id ,
                      dls_sir_id ,
                      sub_alt_id ,
                      ssn ,
                      sub_ssn ,
                      def_key ,
                      type ,
                      member_id ,
                      group_id ,
                      plan_id 
		            )
                    SELECT  dls_sir_id ,
                            dls_sir_id ,
                            sub_alt_id ,
                            ssn ,
                            sub_ssn ,
                            def_key ,
                            type ,
                            member_id ,
                            group_id ,
                            plan_id
                    FROM    dbo.dls_elig (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND member_flag = '00'
                            AND dls_status = 'L';
            /*
			SET @cSIR = CURSOR  FOR SELECT dls_sir_id, dls_sir_id, sub_alt_id, ssn, sub_ssn,
		 def_key, type, member_id, group_id, plan_id
		
      FROM dbo.dls_elig (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND
      member_flag = '00' AND dls_status = 'L';
            OPEN @cSIR;
   FETCH NEXT FROM @cSIR INTO @t_sub_sir_id, @t_sir_id, @t_sub_alt_id,
                @t_ssn, @t_sub_ssn, @s_def_key, @s_type, @s_member_id,
                @s_group_id, @s_plan_id;
            WHILE @@FETCH_STATUS = 0
			*/

            DECLARE @cur2_cnt INT ,
                @cur2_i INT;

     SET @cur2_i = 1;

				--Get the no. of records for the cursor
            SELECT  @cur2_cnt = COUNT(1)
            FROM    @cSIR;
				
				--while @@FETCH_STATUS = 0
            WHILE ( @cur2_i <= @cur2_cnt )
                BEGIN
                    BEGIN 
			--			dls_status = "L" 
						--order by member_flag
                        SELECT  @t_sub_sir_id = dls_sub_sir_id ,
                                @t_sir_id = dls_sir_id ,
                                @t_sub_alt_id = sub_alt_id ,
                                @t_ssn = ssn ,
                                @t_sub_ssn = sub_ssn ,
                                @s_def_key = def_key ,
                                @s_type = type ,
                                @s_member_id = member_id ,
                                @s_group_id = group_id ,
                                @s_plan_id = plan_id
                        FROM    @cSIR
                        WHERE   id = @cur2_i;

                        -- DECLARE @SWV_cursor_var2 CURSOR;
                       -- DECLARE @SWV_cursor_var2 TABLE
					   IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
						DROP TABLE #SWV_cursor_var2
					    CREATE TABLE #SWV_cursor_var2
                            (
                              id INT IDENTITY ,
                              dls_sir_id INT ,
                              alt_id CHAR(20) ,
                              member_flag CHAR(2) ,
                              sub_alt_id CHAR(20) ,
                              dls_status CHAR ,
                              ssn CHAR(11) ,
                              sub_ssn CHAR(11)
                            );

                        BEGIN TRY
                            SET @s_error = 'N';
                            SET @n_sub_sir_id = @t_sub_sir_id;
                           
                            IF @s_create_ssn = 'Y'
		/* 20131229$$ks - use member ID if provided
		 */
                                IF ( @t_sub_ssn IS NULL
                                     OR @t_sub_ssn = ''
                                   )
                                    AND ( @t_ssn IS NULL
             OR @t_ssn = ''
              )
                                    BEGIN
                                        SELECT  @n_count = COUNT(*)
                                        FROM    dbo.member (NOLOCK)
                                        WHERE   alt_id = @t_sub_alt_id
                                                AND ( ( @s_member_id IS NOT NULL
                                                        AND member_id = @s_member_id
                                                      )
                                                      OR ( @s_member_id IS NULL )
                                                    );
                                        IF @n_count > 1
										BEGIN
										SET @error_no = 1
                                            RAISERROR('Multiple records in DD with same alt_id',0,1);
											EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @error_no;
								IF @i_fatal <> 1
                                SET @s_error = 'Y';
											END
                                        ELSE
                                            BEGIN
                                                SELECT  @n_mb_ssn = member_ssn
 FROM    dbo.member (NOLOCK)
                                                WHERE   alt_id = @t_sub_alt_id
                                                        AND ( ( @s_member_id IS NOT NULL
                                                 AND member_id = @s_member_id
                                                              )
        OR ( @s_member_id IS NULL )
                );

   IF ( @n_mb_ssn IS NULL
                                                     OR @n_mb_ssn = ''
                                                   )
                                                    BEGIN

                  EXECUTE dbo.dlp_gen_ssn @a_batch_id,
                                                            @a_start_time,
                                                            @n_mb_ssn OUTPUT;
                                                        
                                                    END;
					
                                                SET @n_mb_sub_ssn = @n_mb_ssn;
                                            END;
                                    END;
                                ELSE
                                    IF ( @t_sub_ssn IS NULL
                                         OR @t_sub_ssn = ''
                                       )
                                        BEGIN
                                            SET @n_mb_sub_ssn = @t_ssn;
                                            SET @n_mb_ssn = @t_ssn;
                                        END;
                                    ELSE
                                        IF ( @t_ssn IS NULL
                                             OR @t_ssn = ''
                                           )
                                            BEGIN
                                                SET @n_mb_sub_ssn = @t_sub_ssn;
                                                SET @n_mb_ssn = @t_sub_ssn;
                                            END;
                                        ELSE
                                            BEGIN
                                                SET @n_mb_sub_ssn = @t_sub_ssn;
                                                SET @n_mb_ssn = @t_ssn;
                                            END;
					
				
			
		 -- s_create_ssn = Y

                            
                            SET @n_sub_count = @n_sub_count + 1;
	/*
	 *	20130514$$ks - adding group and plan values to determine if
	 *	subscriber's alt ID is used more than once
	 *	20131229$$ks - added actual group and plan ID to the query
	 * 	use member_id if provided
	 */
	
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.dls_elig (NOLOCK)
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND alt_id = @t_sub_alt_id   -- ?? should we ignore alt_id if member_id provided??
                                                AND member_flag = '00'
                                                AND ( ( @s_member_id IS NOT NULL
                                                        AND member_id = @s_member_id
                                                      )
                                                      OR ( @s_member_id IS NULL )
                                                    )
                                                AND ( ( def_key != 'FI'
                                                        AND def_key = ISNULL(@s_def_key,def_key)
                                                        AND type = ISNULL(@s_type,type)
                                                      )
                                                      OR ( def_key = 'FI'
                                                           AND group_id = ISNULL(@s_group_id,group_id)
                               AND plan_id = ISNULL(@s_plan_id,plan_id)
                                                         )
                                                    )
               AND dls_sir_id != @t_sub_sir_id )
												BEGIN
												SET @error_no = 10
     RAISERROR('Same alt_id for different subscriber',0,1);
	 EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';
								END
		
   IF @s_error = 'N'
                                BEGIN
																
                                    INSERT  INTO #SWV_cursor_var2
                                            ( dls_sir_id ,
                                              alt_id ,
											 member_flag ,
											  sub_alt_id ,
                                              dls_status ,
                                              ssn ,
                                              sub_ssn
								            )
                                            SELECT  dls_sir_id ,
                                                    alt_id ,
                                                    member_flag ,
                                                    sub_alt_id ,
                                                    dls_status ,
                                                    ssn ,
                                                    sub_ssn
                                            FROM    dbo.dls_elig (NOLOCK)
                                            WHERE   dls_batch_id = @a_batch_id
                                                    AND sub_alt_id = @t_sub_alt_id
                                                    AND dls_status NOT IN (
                                                    'V', 'E', 'P', 'U' )
                                                    AND ( ( def_key != 'FI'
                                                            AND def_key = ISNULL(@s_def_key,def_key)
                                                            AND type = ISNULL(@s_type,type)
                                                          )
                                                          OR ( def_key = 'FI'
                                                              AND group_id = ISNULL(@s_group_id,group_id)
                                                              AND plan_id = ISNULL(@s_plan_id,plan_id)
                                                             )
                                                        );
                                    /*
									SET @SWV_cursor_var2 = CURSOR  FOR SELECT dls_sir_id, alt_id, member_flag, sub_alt_id, dls_status, ssn, sub_ssn
				
                  FROM dbo.dls_elig (NOLOCK)
                  WHERE dls_batch_id = @a_batch_id
                  AND sub_alt_id = @t_sub_alt_id
                  AND dls_status NOT IN('V','E','P','U')
                  AND ((def_key != 'FI' AND def_key = @s_def_key AND type = @s_type)
                  OR (def_key = 'FI' AND group_id = @s_group_id AND plan_id = @s_plan_id));
                                    OPEN @SWV_cursor_var2;
                                    FETCH NEXT FROM @SWV_cursor_var2 INTO @t_sir_id,
                                        @t_alt_id, @t_member_flag,
                                        @t_sub_alt_id, @t_dls_status, @t_ssn,
                                        @t_sub_ssn;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                    DECLARE @cur3_cnt INT ,
                                        @cur3_i INT;

                                    SET @cur3_i = 1;

				--Get the no. of records for the cursor
                                    SELECT  @cur3_cnt = COUNT(1)
                    FROM    #SWV_cursor_var2;

													
				--while @@FETCH_STATUS = 0
                                    WHILE ( @cur3_i <= @cur3_cnt )
                                        BEGIN
										
                                            SELECT  @t_sir_id = dls_sir_id ,
                                                    @t_alt_id = alt_id ,
                                                    @t_member_flag = member_flag ,
               @t_sub_alt_id = sub_alt_id ,
												 @t_dls_status = dls_status ,
                      @t_ssn = ssn ,
                        @t_sub_ssn = sub_ssn
                                        FROM    #SWV_cursor_var2
                                            WHERE   id = @cur3_i;
                       -- SET @n_process_count = @n_process_count  + 1;

					--LET n_sir_id = t_sub_sir_id;

                                            
                                            IF @s_create_ssn = 'Y'
                                                BEGIN
                                                    IF @t_member_flag != '00'
                                                        IF ( @t_sub_ssn IS NULL
                                                             OR @t_sub_ssn = ''
                                                           )
                                                            AND ( @t_ssn IS NULL
                                                              OR @t_ssn = ''
                                                              )
                                                            BEGIN
                                                              SELECT
                                                              @n_count = COUNT(*)
                                                              FROM
                                                              dbo.member (NOLOCK)
                                                              WHERE
                                                              alt_id = @t_alt_id
                                                              AND ( ( @s_member_id IS NOT NULL
                                                              AND member_id = @s_member_id
                                                              )
                                                              OR ( @s_member_id IS NULL )
                                                              );
              IF @n_count > 1
			  BEGIN
			  SET @error_no = 2
        RAISERROR('Multiple Dep records based on alt_id',0,1);
		EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';
		END
							
                                                              SELECT
        @n_mb_ssn = member_ssn
                                                              FROM
                                                              dbo.member (NOLOCK)
                                                              WHERE
                                                              alt_id = @t_alt_id
                                                              AND ( ( @s_member_id IS NOT NULL
                                                              AND member_id = @s_member_id
                                                              )
                                                              OR ( @s_member_id IS NULL )
                                                              );
                                                             
                                                              IF ( @n_mb_ssn IS NULL
                                                              OR @n_mb_ssn = ''
                            )
                                                              SET @n_mb_ssn = @n_mb_sub_ssn;
                                                            END;
                                                        ELSE
                                                            IF ( @t_ssn IS NULL
                                                              OR @t_ssn = ''
                                                              )
                                                              SET @n_mb_ssn = @n_mb_sub_ssn;
             ELSE
                                          SET @n_mb_ssn = @t_ssn;
							
						
					
           UPDATE  dbo.dls_elig
                                SET     sub_ssn = @n_mb_sub_ssn ,
                              ssn = @n_mb_ssn
          WHERE   dls_batch_id = @a_batch_id
                                   AND dls_sir_id = @t_sir_id;
                                                END;
				
			/* 20130812$$ks -- added s_def_key and s_type to make sub-group-plan unique
			 */
                                            IF @s_error = 'Y'
											--	SET dls_status = "E", 
                                                UPDATE  dbo.dls_elig
                                                SET     dls_sub_sir_id = @n_sub_sir_id
                                                WHERE   dls_batch_id = @a_batch_id
                                                        AND sub_alt_id = @t_sub_alt_id
                                                        AND ( ( @s_member_id IS NOT NULL
                                                              AND member_id = @s_member_id
                                                              )
                                                              OR ( @s_member_id IS NULL )
                                                            )
                                                        AND ( ( def_key != 'FI'
                                                              AND def_key = @s_def_key
                                                              AND type = @s_type
                                                              )
                                                              OR ( def_key = 'FI'
                                                              AND group_id = @s_group_id
                                                              AND plan_id = @s_plan_id
                                                              )
                                                            )
                                                        AND dls_sir_id != @t_sub_sir_id;
                                            ELSE
                                             BEGIN
                                                    SET @n_succ_count = @n_succ_count
                                                        + 1;
                                                    UPDATE  dbo.dls_elig
                                                    SET     dls_status = 'V' ,
                                                            dls_sub_sir_id = @n_sub_sir_id
                                                    WHERE   dls_batch_id = @a_batch_id
                                                            AND dls_sir_id = @t_sir_id;
                                                END;
                                            /*FETCH NEXT FROM @SWV_cursor_var2 INTO @t_sir_id,
                                                @t_alt_id, @t_member_flag,
                                                @t_sub_alt_id, @t_dls_status,
                                                @t_ssn, @t_sub_ssn;
												*/
                                            SET @cur3_i = @cur3_i + 1;
                                        END;
                                    -- CLOSE @SWV_cursor_var2;
                                END;
                         ELSE
                               -- SET @n_process_count = @n_process_count + 1;
			
			--Update dls_elig
			--	set dls_status = "E"
			--	where dls_batch_id = a_batch_id and
			--	dls_sir_id = t_sub_sir_id;

                            IF @n_sub_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = @n_process_count
                                        - @n_succ_count
                           WHERE   bat_statistics_id = @i_statistics_id;
      END TRY
                        BEGIN CATCH
						IF ERROR_NUMBER() = 50000
						BEGIN
						EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @error_no;
						END
						ELSE
						BEGIN
                            SET @i_error_no = ERROR_NUMBER();

                   SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = @i_error_no
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
				
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';

								   IF @s_error = 'Y'
											--	SET dls_status = "E", 
                                                UPDATE  dbo.dls_elig
                                                SET     dls_sub_sir_id = @n_sub_sir_id
                                                WHERE   dls_batch_id = @a_batch_id
                                                        AND sub_alt_id = @t_sub_alt_id
                                                        AND ( ( @s_member_id IS NOT NULL
                                                              AND member_id = @s_member_id
                                                              )
                                                              OR ( @s_member_id IS NULL )
                                                            )
                                                        AND ( ( def_key != 'FI'
                                                              AND def_key = @s_def_key
                                                              AND type = @s_type
                                                              )
                                                              OR ( def_key = 'FI'
                                                              AND group_id = @s_group_id
                                                              AND plan_id = @s_plan_id
                                                              )
                                                            )
                                                        AND dls_sir_id != @t_sub_sir_id;
                                            ELSE
                                             BEGIN
                                                    SET @n_succ_count = @n_succ_count
                                                        + 1;
                                                    UPDATE  dbo.dls_elig
                                                    SET     dls_status = 'V' ,
                                                            dls_sub_sir_id = @n_sub_sir_id
                                                    WHERE   dls_batch_id = @a_batch_id
                                                           AND dls_sir_id = @t_sir_id;
                                                END;


								END
                        END CATCH;
                    END;
                    /*
					FETCH NEXT FROM @cSIR INTO @t_sub_sir_id, @t_sir_id,
                        @t_sub_alt_id, @t_ssn, @t_sub_ssn, @s_def_key, @s_type,
                        @s_member_id, @s_group_id, @s_plan_id;
						*/
                    SET @cur2_i = @cur2_i + 1;
       END;
            --CLOSE @cSIR;
            DECLARE @SWV_cursor_var3 TABLE
       (
       id INT IDENTITY ,
                  dls_sub_sir_id INT ,
     dls_sir_id INT ,
                  sub_alt_id CHAR(20)
                );
            INSERT  INTO @SWV_cursor_var3
                    ( dls_sub_sir_id ,
                      dls_sir_id ,
                      sub_alt_id
							
                    )
                    SELECT  dls_sir_id ,
                            dls_sir_id ,
                            sub_alt_id
                    FROM    dbo.dls_elig (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND member_flag != '00'
                            AND dls_status = 'L'
                            AND dls_sir_id NOT IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dl_log_error (NOLOCK)
                            WHERE   config_bat_id = @a_batch_id
                                    AND sp_id = @i_sp_id
                                    AND sir_def_id = @i_sir_def_id );

           /* SET @SWV_cursor_var3 = CURSOR  FOR SELECT dls_sir_id, dls_sir_id, sub_alt_id
		
      FROM dbo.dls_elig (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND
      member_flag != '00' AND dls_status = 'L'
      AND dls_sir_id NOT IN(SELECT dls_sir_id FROM
      dbo.dl_log_error (NOLOCK) WHERE config_bat_id = @a_batch_id AND
      sp_id = @i_sp_id AND sir_def_id = @i_sir_def_id);
            OPEN @SWV_cursor_var3;
            FETCH NEXT FROM @SWV_cursor_var3 INTO @t_sub_sir_id, @t_sir_id,
                @t_sub_alt_id;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cur4_cnt INT ,
                @cur4_i INT;

            SET @cur4_i = 1;

				--Get the no. of records for the cursor
            SELECT  @cur4_cnt = COUNT(1)
            FROM    @SWV_cursor_var3;
				
				--while @@FETCH_STATUS = 0
            WHILE ( @cur4_i <= @cur4_cnt )
                BEGIN
                    SELECT  @t_sub_sir_id = dls_sub_sir_id ,
                            @t_sir_id = dls_sir_id ,
                  @t_sub_alt_id = sub_alt_id
                    FROM    @SWV_cursor_var3
                    WHERE   id = @cur4_i;

 --SET @n_process_count = @n_process_count + 1;
    
                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                        @i_sp_id, @i_sir_def_id, @t_sir_id, 11;
                    /*FETCH NEXT FROM @SWV_cursor_var3 INTO @t_sub_sir_id,
                        @t_sir_id, @t_sub_alt_id;*/
                    SET @cur4_i = @cur4_i + 1;
                END;
            --CLOSE @SWV_cursor_var3;
            SET @SWV_func_DL_UPD_STATISTICS_par0 = @n_process_count - @n_succ_count;
            EXECUTE @SWV_dl_upd_statistics= dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @SWV_func_DL_UPD_STATISTICS_par0
                
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                                   + @n_error_count ),
                                                 ' Failed to update statistics');
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish After-load process for Batch ',
                                         @a_batch_id);
            RETURN;
            IF ( @do_trace = 1 )
BEGIN--TRACE statement has no equivalent in MSSQL
--trace off;
                    SET @v_Null = 0;
         END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
   SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
 RETURN;
        END CATCH;
        SET NOCOUNT OFF;

/*
Here is a call sequence tree derived from the code in
this procedure dlp_al_eligibility():

Calling hierarchy for dlp_al_eligibility():

dl_log_error			No exceptions raised:  returns -1.
dl_get_sp_id			No exceptions raised:  returns -1.
dl_get_sir_def_id		No exceptions raised:  returns -1.
dl_get_param_value		No exceptions raised:  returns NULL.
	dl_get_param_id		No exceptions raised:  returns -1.
dl_clean_curr_err		No exceptions raised:  returns -1.
dlp_gen_ssn				No exceptions raised:  returns NULL.
dl_upd_statistics		No exceptions raised:  returns -1.
* /

/ *
Work request 20130901:  Enhancements for Health Care Reform.

Two new local variables:  s_def_key and s_type.

These variables are set to values by reading table dls_elig.

Now subscriber alt ID used to be considered alone for uniqueness.
Now "uniqueness" is coupled not only to the alt ID, but to also
"def key" and "type" as well - a triple compound key test for uniqueness.
*/


    END;