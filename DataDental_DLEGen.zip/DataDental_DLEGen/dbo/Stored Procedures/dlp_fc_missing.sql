﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_fc_missing]
    @a_batch_id INT ,
    @a_net_id INT ,
    @a_term_eff_date DATE
    
AS
    BEGIN

        DECLARE @a_error_no INT;
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @n_in_transaction CHAR(1);

        DECLARE @i_fc_id INT;
        DECLARE @j_ovr_ride CHAR(1);
        DECLARE @i_dds_eff_date DATE;
        DECLARE @j_fcstat_eff DATE;
        DECLARE @j_alt_id CHAR(20);
        DECLARE @j_fc_type CHAR(2);
        DECLARE @j_fc_name CHAR(50);
        DECLARE @j_fc_state CHAR(2);
        DECLARE @j_tax_id CHAR(9);
        DECLARE @j_tin CHAR(1);
        DECLARE @j_tax_name CHAR(50);
        DECLARE @j_next_cap DATE;
        DECLARE @j_addr1 CHAR(30);
        DECLARE @j_zip CHAR(10);
        DECLARE @j_phone1 CHAR(14);
        DECLARE @j_sir_id INT;

DECLARE @i_sp_id integer ;
DECLARE @i_sir_def_id integer ;
DECLARE @i_config_id integer ;
DECLARE @n_process_count integer ;
DECLARE @n_error_count integer ;
DECLARE @n_succ_count integer ;

       /*
ON EXCEPTION SET i_error_no, i_isam_error, s_error_descr 
IF i_error_no IN (-213, -457) THEN 
RAISE EXCEPTION i_error_no, i_isam_error, s_error_descr;
END IF;

LET i_fatal = dl_log_error(a_batch_id, i_sp_id, i_sir_def_id, j_sir_id, a_error_no); 
END EXCEPTION WITH RESUME;
*/

       -- DECLARE @SWV_cursor_var1 CURSOR;


        SET NOCOUNT ON;
        SET @i_sp_id = 0;
        
        SET @i_sir_def_id = 0;
       
        SET @i_config_id = 0;
       
        --SET @n_process_count = 0;
        
        SET @n_error_count = 0;
        
        --SET @n_succ_count = 0;
		SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
       
        BEGIN TRY
           
            SET @n_in_transaction = 'N';
            SET @j_sir_id = 0;

			EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_fac_net' ;
			SET @i_sir_def_id = dbo.dl_get_sir_def_id('fac_net') ;

/* 20130804$$ks - this program is looking for facilities in the given network that are not in 
 *  the input file and terminating them!
 *  I don't think this is what the client wants!! 
 */
          --  RETURN 1; --- 20130804$$ks


            /*SET @SWV_cursor_var1 = CURSOR  FOR SELECT fc_id, ovr_ride, eff_date

      FROM dbo.net_facility (NOLOCK)
      WHERE net_id = @a_net_id
      AND exp_date IS NULL
      AND con_type = 'PPO'
      AND net_fc_id NOT IN(SELECT a.net_fc_id
      FROM dbo.net_facility a (NOLOCK), dbo.dls_fac_net b (NOLOCK)
      WHERE b.dls_batch_id = @a_batch_id
      AND b.dls_source = 'F'
      AND b.dls_facility_id = a.fc_id
      AND b.contract_type = a.con_type
      AND a.net_id = @a_net_id
      AND a.con_type = 'PPO'
      AND a.exp_date IS NULL);
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_fc_id, @j_ovr_ride,
                @i_dds_eff_date;
            WHILE @@FETCH_STATUS = 0*/
DECLARE @SWV_cursor_var1 TABLE
            (
              id INT IDENTITY ,
              fc_id int, ovr_ride char(1), eff_date date
            );

        INSERT  INTO @SWV_cursor_var1
                ( fc_id, ovr_ride, eff_date
                )
              SELECT fc_id, ovr_ride, eff_date

      FROM dbo.net_facility (NOLOCK)
      WHERE net_id = @a_net_id
      AND exp_date IS NULL
      AND con_type = 'PPO'
      AND net_fc_id NOT IN(SELECT a.net_fc_id
      FROM dbo.net_facility a (NOLOCK), 
	  dbo.dls_fac_net b (NOLOCK)
      WHERE b.dls_batch_id = @a_batch_id
      AND b.dls_source = 'F'
      AND b.dls_facility_id = a.fc_id
      AND b.contract_type = a.con_type
     AND a.net_id = @a_net_id
      AND a.con_type = 'PPO'
      AND a.exp_date IS NULL);  

        DECLARE @cur1_cnt INT ,
            @cur_i INT;

        SET @cur_i = 1;

--Get the no. of records for the cursor
        SELECT  @cur1_cnt = COUNT(1)
        FROM    @SWV_cursor_var1;
WHILE ( @cur_i <= @cur1_cnt )
       BEGIN
SELECT  @i_fc_id=fc_id, @j_ovr_ride=ovr_ride, @i_dds_eff_date=eff_date
                FROM    @SWV_cursor_var1
                WHERE   id = @cur_i;
BEGIN

                        BEGIN TRY
                            IF @n_in_transaction = 'N'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'Y';
                                END;
                            SET @j_fcstat_eff = NULL;
                            SET @j_sir_id = 0;
							select @a_term_eff_date,@i_dds_eff_date
                            IF @a_term_eff_date < @i_dds_eff_date
--RAISE EXCEPTION -746, 260, "Intended FCNET Exp Date is before DataDental FCNET Eff Date"; 
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                          
                                            SET @n_in_transaction = 'N';
                                        END;
--let n_process_count = n_process_count + 1;
                                    GOTO SWL_Label2;
                                END;
                            SET @a_error_no = 250;
                            SELECT  @j_fcstat_eff = eff_date
                            FROM    dbo.fcstat (NOLOCK)
                            WHERE   facility_id = @i_fc_id
                                    AND status = 'AC'
                                    AND exp_date IS NULL;
                      
                            IF @j_fcstat_eff IS NULL
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                            
                                            SET @n_in_transaction = 'N';
                                        END;
                                    GOTO SWL_Label2;
                                END;
                            SELECT  @j_alt_id = alt_id ,
                                    @j_fc_type = fc_type ,
                                    @j_fc_name = fc_name ,
                                    @j_fc_state = fc_state ,
                                    @j_tax_id = fc_tax_id ,
                                    @j_tin = tin ,
                                    @j_tax_name = fc_tax_name ,
                                    @j_next_cap = next_cap_date
                            FROM    dbo.facility (NOLOCK)
                            WHERE   fc_id = @i_fc_id;
                          
                            SELECT  @j_addr1 = addr1 ,
                                    @j_zip = zip
                            FROM    dbo.address (NOLOCK)
                            WHERE   subsys_code = 'FC'
                                    AND sys_rec_id = @i_fc_id
                                    AND addr_type = 'L';
                          
                            SELECT  @j_phone1 = phone1
                            FROM    dbo.contact
							WHERE   subsys_code = 'FC'
                                    AND sys_rec_id = @i_fc_id
                                    AND addr_type = 'L'
                                    AND con_type = 'OF';
                           
                            INSERT  INTO dbo.dls_fac_net
                                    ( dls_batch_id ,
                                      alt_id ,
                                      fc_type ,
                                      fc_name ,
        fc_stat_eff_date ,
                                      fc_state ,
                                      fc_tax_id ,
                                      tin ,
                                      fc_tax_name ,
                                      next_cap_date ,
                                      net_id ,
                                      contract_type ,
                                      net_fc_eff_date ,
                                      ovr_ride ,
                                      net_fc_exp_date ,
                                      addr_type ,
                                      addr1 ,
                                      zip ,
                                      con_type ,
                                      phone1 ,
                                      dls_network_id ,
                                      dls_facility_id ,
                                      dls_action_code ,
                                      dls_status ,
                                      dls_source
                                    )
                            VALUES  ( @a_batch_id ,
                                      @j_alt_id ,
                                      @j_fc_type ,
                                      @j_fc_name ,
                                      CAST(@j_fcstat_eff AS CHAR(10)) ,
                                      @j_fc_state ,
                                      @j_tax_id ,
                                      @j_tin ,
                                      @j_tax_name ,
                                      CAST(@j_next_cap AS CHAR(10)) ,
                                      CAST(@a_net_id AS CHAR(20)) ,
                                      'PPO' ,
                                      CAST(@i_dds_eff_date AS CHAR(10)) ,
                                      @j_ovr_ride ,
                                      CAST(@a_term_eff_date AS CHAR(10)) ,
                                      'L' ,
                                      @j_addr1 ,
                                      @j_zip ,
                                      'OF' ,
                                      @j_phone1 ,
                                      @a_net_id ,
                                      @i_fc_id ,
                                      'NT' ,
                                      'P' ,
                                      'A'
                                    );
                            SELECT  @j_sir_id = MAX(dls_sir_id)
                            FROM    dbo.dls_fac_net (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id;
                            
                            EXECUTE @i_error_no = dbo.dl_log_action @a_batch_id,
                                @j_sir_id, 'NT', @a_term_eff_date;
                           
						   SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
							SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6

                            SET @n_process_count = @n_process_count + 1;
                           SET @n_succ_count = @n_succ_count + 1;

						   UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
						UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6

                            
 IF @n_in_transaction = 'Y'
                           BEGIN
                                    
                                    SET @n_in_transaction = 'N';
                                END;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
  
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @j_sir_id,
                            @i_isam_error;
                        END CATCH;
                    END;
                    SWL_Label2:
                   /* FETCH NEXT FROM @SWV_cursor_var1 INTO @i_fc_id,
                        @j_ovr_ride, @i_dds_eff_date;*/
SET @cur_i = @cur_i + 1;
                END;
           -- CLOSE @SWV_cursor_var1;


--trace off;

            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
       IF @n_in_transaction = 'Y'
   BEGIN
                    
                    SET @n_in_transaction = 'N';
                END;
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;




--set debug file to "/tmp/dlp_fc_missing.trc";
--trace on;

    END;