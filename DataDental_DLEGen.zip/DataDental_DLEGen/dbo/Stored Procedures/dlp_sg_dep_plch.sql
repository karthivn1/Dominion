﻿CREATE PROCEDURE [dbo].[dlp_sg_dep_plch]
    @a_batch_id INT ,
    @a_mb_gr_pl_id INT ,
    @a_sub_sir_id INT ,
    @a_sub_id INT ,
    @a_plan_eff_date DATE
    

-- Modification: support multi_group and multi_plan
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_fatal INT;
	
        DECLARE @n_batch_id INT;
        DECLARE @n_family_id INT;
        DECLARE @n_alt_id CHAR(20);
        DECLARE @n_sub_ssn CHAR(11);
        DECLARE @n_ssn CHAR(11);
        DECLARE @n_sub_alt_id CHAR(20);
        DECLARE @n_member_id INT;
        DECLARE @n_sub_id INT;
        DECLARE @n_msg_id INT;
        DECLARE @n_group_id INT;
        DECLARE @n_member_code CHAR(3);
        DECLARE @n_plan_id INT;
        DECLARE @n_facility_id INT;
        DECLARE @n_last_name CHAR(15);
        DECLARE @n_first_name CHAR(15);
        DECLARE @n_middle_init CHAR(1);
        DECLARE @n_date_of_birth DATE;
        DECLARE @n_student_flag CHAR(1);
        DECLARE @n_disable_flag CHAR(1);
        DECLARE @n_cobra_flag CHAR(1);
        DECLARE @n_action_code CHAR(2);
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_plan_eff_date DATE;
        DECLARE @n_plan_term_date DATE;
        DECLARE @n_rate_eff_date DATE;
        DECLARE @n_sub_fc_id INT;
        DECLARE @n_sub_action_code CHAR(2);
        DECLARE @s_msg_id CHAR(20);
        DECLARE @s_pl_id CHAR(30);
        DECLARE @s_fc_id CHAR(20);
        DECLARE @s_rc CHAR(2);
        DECLARE @s_gppl_eff CHAR(10);
        DECLARE @s_fc_eff CHAR(10);
        DECLARE @s_term_date CHAR(10);
        DECLARE @new_dls_sir_id INT
        DECLARE @n_process_count INT
        DECLARE @n_succ_count INT
        DECLARE @sg_sp_id INT
        DECLARE @sg_sir_def_id INT
        --DECLARE @SWV_cursor_var1 CURSOR;
	
        SET NOCOUNT ON;
        SET @new_dls_sir_id = 0
        
        --SET @n_process_count = 0
        
        --SET @n_succ_count = 0
		SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
        
        SET @sg_sp_id = 0
        
        SET @sg_sir_def_id = 0
        
        BEGIN TRY
            
            SELECT  @n_batch_id = dls_batch_id ,
                    @n_family_id = dls_member_id ,
                    @s_msg_id = msg_group_id ,
                    @s_pl_id = plan_id ,
                    @s_fc_id = facility_id ,
                    @s_rc = rate_code ,
                    @s_gppl_eff = mb_gppl_eff_date ,
                    @s_fc_eff = mb_fc_eff_date ,
                    @s_term_date = mb_term_date ,
                    @n_msg_id = dls_msg_id ,
                    @n_group_id = dls_group_id ,
                    @n_plan_id = dls_plan_id ,
                    @n_sub_fc_id = dls_facility_id ,
                    @n_sub_action_code = dls_action_code ,
                    @n_sub_ssn = ssn ,
                    @n_sub_alt_id = alt_id
FROM    dbo.dls_sg_member (NOLOCK)
            WHERE   dls_batch_id = @a_batch_id
                    AND dls_sir_id = @a_sub_sir_id;
            
            IF @n_family_id IS NULL
                RETURN 1;
	
            IF @n_group_id IS NULL
                OR @n_plan_id IS NULL
                RETURN -1;

				DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 member_id INT, facility_id INT
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								member_id, facility_id
                                )
								SELECT DISTINCT member_id, facility_id
	
      FROM dbo.rlplfc (NOLOCK)
      WHERE mb_gr_pl_id = @a_mb_gr_pl_id
      AND member_id != @n_family_id
      AND exp_date IS NULL
      AND NOT EXISTS(SELECT * FROM dbo.dls_sg_member (NOLOCK)
         WHERE dls_batch_id = @a_batch_id
   AND dls_sub_sir_id = @a_sub_sir_id
         AND dls_sir_id != @a_sub_sir_id
         AND dls_member_id = dbo.rlplfc.member_id);

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;
				/*
	
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT DISTINCT member_id, facility_id
	
      FROM dbo.rlplfc (NOLOCK)
      WHERE mb_gr_pl_id = @a_mb_gr_pl_id
      AND member_id != @n_family_id
      AND exp_date IS NULL
      AND NOT EXISTS(SELECT * FROM dbo.dls_sg_member (NOLOCK)
         WHERE dls_batch_id = @a_batch_id
         AND dls_sub_sir_id = @a_sub_sir_id
         AND dls_sir_id != @a_sub_sir_id
         AND dls_member_id = dbo.rlplfc.member_id);
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @n_member_id, @n_facility_id;
            WHILE @@FETCH_STATUS = 0
			*/
               WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @n_member_id=member_id, @n_facility_id=facility_id
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;

                    SELECT  @n_ssn = member_ssn ,
                            @n_last_name = last_name ,
                            @n_first_name = first_name ,
                            @n_middle_init = middle_init ,
                            @n_sub_id = family_id ,
                            @n_alt_id = alt_id ,
                            @n_member_code = member_code ,
                            @n_date_of_birth = date_of_birth ,
                            @n_student_flag = student_flag ,
                            @n_disable_flag = disable_flag
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_id = @n_member_id;
                    
                    SET @n_plan_eff_date = @a_plan_eff_date;
		--LET n_facility_id = n_sub_fc_id;
                    SET @n_plan_term_date = NULL;
                    INSERT  INTO dbo.dls_sg_member
                            ( dls_batch_id ,
                              dls_sub_sir_id ,
                              member_flag ,
                              alt_id ,
                              ssn ,
                              sub_ssn ,
                              sub_alt_id ,
                              member_code ,
                              last_name ,
                              first_name ,
                              middle_init ,
                              date_of_birth ,
                              student_flag ,
                              disable_flag ,
                              msg_group_id ,
                              plan_id ,
                              facility_id ,
                              rate_code ,
               mb_gppl_eff_date ,
                              mb_fc_eff_date ,
                              mb_term_date ,
                              dls_member_id ,
                              dls_subscriber_id ,
                              dls_msg_id ,
                              dls_group_id ,
                              dls_plan_id ,
      dls_facility_id ,
                              dls_action_code ,
                              dls_status ,
                              dls_source
                            )
                    VALUES  ( @n_batch_id ,
                              @a_sub_sir_id ,
                              '09' ,
                              @n_alt_id ,
                              @n_ssn ,
                              @n_sub_ssn ,
                              @n_sub_alt_id ,
                              @n_member_code ,
                              @n_last_name ,
                              @n_first_name ,
                              @n_middle_init ,
              CAST(@n_date_of_birth AS CHAR(10)) ,
                              @n_student_flag ,
                              @n_disable_flag ,
                              CAST(@s_msg_id AS INT) ,
                              CAST(@s_pl_id AS INT) ,
                              CAST(@s_fc_id AS INT) ,
                              @s_rc ,
                              @s_gppl_eff ,
                              @s_fc_eff ,
                              @s_term_date ,
                              @n_member_id ,
                              @n_sub_id ,
                              @n_msg_id ,
                              @n_group_id ,
                              @n_plan_id ,
                              @n_sub_fc_id ,
                              'PC' ,
                              'P' ,
                              'A'
                            );
		
                    
                    EXECUTE @n_error_no = dbo.dl_log_action @n_batch_id,
                        @new_dls_sir_id, 'PC', @n_plan_eff_date;

						SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
				SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                    
                    SET @n_process_count = @n_process_count + 1;
                    
                    SET @n_succ_count = @n_succ_count + 1;
                    
					UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
				UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @n_member_id,
                    --    @n_facility_id;
					SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @SWV_cursor_var1;
	
--trace off;
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            RETURN -400;
        END CATCH;
        SET NOCOUNT OFF;

	
--set debug file to "/tmp/dlp_sg_dep_plch.trc";
--trace on;
--set explain on;
	
    END;