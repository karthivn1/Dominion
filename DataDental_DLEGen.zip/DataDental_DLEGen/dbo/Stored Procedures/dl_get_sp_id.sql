﻿CREATE PROCEDURE [dbo].[dl_get_sp_id]
    @a_batch_id INT ,
    @a_sp_name CHAR(14)
    
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/

        DECLARE @i_sp_id INT;
        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_descr CHAR(64);

        DECLARE @i_config_id INT;
        DECLARE @i_module_id INT;

        SET NOCOUNT ON;
        --BEGIN TRY

			
            SELECT  @i_config_id = config_id
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
		
           
            IF isnull(@i_config_id,'') =''
			BEGIN
			
				--RAISERROR('Missing batch id',16,1);
				RETURN -1
				RETURN
			END
				
            SELECT  @i_module_id = module_id
            FROM    dbo.dl_config (NOLOCK)
            WHERE   config_id = @i_config_id;
           
		

            IF @i_module_id IS NULL
			BEGIN
                RAISERROR('Missing Configuration',16,1);
			RETURN
			END

            SELECT  @i_sp_id = sp_id
            FROM    dbo.dl_sp (NOLOCK)
            WHERE   sp_name = @a_sp_name
                    AND module_id = @i_module_id;
            
		

            IF @i_sp_id IS NULL
			BEGIN
                RAISERROR('Missing SP Name',16,1);
			RETURN
			END
			
			IF ISNULL(@i_sp_id,'') <>''
			BEGIN
                RETURN @i_sp_id ;
			
			END
			ELSE
			BEGIN
				RETURN -1;
			END

            
       -- END TRY
        --BEGIN CATCH
            --SET @n_error_code = ERROR_NUMBER();
            --SET @n_return_code = ERROR_LINE();
            --SET @n_error_descr = ERROR_MESSAGE();
            --RETURN -1;
       -- END CATCH;
        SET NOCOUNT OFF; 

    END;