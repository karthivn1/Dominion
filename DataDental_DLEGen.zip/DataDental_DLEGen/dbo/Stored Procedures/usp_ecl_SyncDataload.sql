﻿CREATE PROC [dbo].[usp_ecl_SyncDataload]
AS
BEGIN
	DECLARE @SYNCDATALOAD INT
	DECLARE @SUBMITTEDSTATUS INT
	DECLARE @LOCKEDSTATUS INT
	DECLARE @COMPLETEDSTATUS INT
	DECLARE @ERRORSTATUS INT
	DECLARE @BATCH_ID INT
	DECLARE @configId INT
	DECLARE @JobID INT
	DECLARE @ParamTable TABLE(ID INT IDENTITY,ParamVal int)
	SET @SUBMITTEDSTATUS =1
	SET @SYNCDATALOAD = 1
	SET @LOCKEDSTATUS= 2
	SET @COMPLETEDSTATUS = 4
	SET @ERRORSTATUS = 5
	SET @BATCH_ID = 0 
	DECLARE	@SWP_Ret_Value int,
			@SWP_Ret_Value1 varchar(MAX)
	SELECT  @BATCH_ID = ISNULL(batch_id,0)  FROM [batch_process_details] 
			WHERE event_id =  @SYNCDATALOAD AND status= @SUBMITTEDSTATUS ORDER BY batch_id ASC
	IF (@BATCH_ID <> 0 )
	BEGIN
		UPDATE [batch_process_details] SET status = @LOCKEDSTATUS WHERE batch_id = @BATCH_ID
		BEGIN TRY
			INSERT INTO [dbo].[eclaim_report] ([StartDate],[Source],[ProcName],[StatusId],[HUser],[BatchId])
					VALUES (GETDATE(),'SyncDL', 'dload_sync',1,SYSTEM_USER,@BATCH_ID);
			SET @JobID = SCOPE_IDENTITY();
			EXEC	[dbo].[dload_sync]
					@SWP_Ret_Value = @SWP_Ret_Value OUTPUT,
					@SWP_Ret_Value1 = @SWP_Ret_Value1 OUTPUT
			IF(@SWP_Ret_Value<0) --  -1 -failed output 
				BEGIN
					RAISERROR (@SWP_Ret_Value1, 16, 1 );
				END
			ELSE -- success output
				BEGIN
					UPDATE dbo.eclaim_report SET StatusId = 2,EndDate = GETDATE(), ReturnValue = @SWP_Ret_Value 
						WHERE JobId=@JobID
				END
			UPDATE [batch_process_details] SET status = @COMPLETEDSTATUS , completed_time = GETDATE() WHERE batch_id = @BATCH_ID
		END TRY
		BEGIN CATCH
			SET @SWP_Ret_Value1=ERROR_MESSAGE();
			UPDATE dbo.eclaim_report SET StatusId=3, ErrorDetail=@SWP_Ret_Value1 WHERE JobId=@JobID
			UPDATE [batch_process_details] SET status = @ERRORSTATUS WHERE batch_id = @BATCH_ID
			RAISERROR (@SWP_Ret_Value1, 16, 1 );
		END CATCH
	END
END