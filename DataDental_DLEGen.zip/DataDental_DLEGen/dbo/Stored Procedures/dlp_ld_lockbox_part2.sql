﻿CREATE PROCEDURE [dbo].[dlp_ld_lockbox_part2]
    @p_batch_id INT ,
    @p_db_name CHAR(128) ,
    @p_start_time VARCHAR(22),
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(500) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_ld_lockbox
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This SP loads lockbox data into a holding area of DataLoad as the
--           first step in the processing of data for the DataDental Allocation
--           Module.  This is a DataLoad product of STC.
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 11:53:53 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1







000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @n_err_rtn_text VARCHAR(64);
        DECLARE @n_rtn_text VARCHAR(100);

        DECLARE @n_system_cmd CHAR(512);
        DECLARE @n_sys_cmd1 CHAR(200);
        DECLARE @n_sys_cmd2 CHAR(200);
        DECLARE @n_load_file CHAR(128);
        DECLARE @n_tmp_file CHAR(64);
        DECLARE @n_date_str VARCHAR(10);
        DECLARE @n_sir_count INT;
        DECLARE @n_ld_exist INT;
        DECLARE @n_splt_fname CHAR(64);
        DECLARE @n_file_count INT;
        DECLARE @s_suffix CHAR(2);
        DECLARE @n_min_sir INT;
        DECLARE @n_max_sir INT;
        DECLARE @n_sp_id INT;
        DECLARE @n_sir_def_id INT;
        DECLARE @n_cfg_bat_det_id INT;
        DECLARE @n_statistics_id INT;
        DECLARE @n_line_cnt INT;
   
        DECLARE @i_temp INT;
   
        DECLARE @n_tmp_len INT;

        DECLARE @s_sir_def_name VARCHAR(18);
        DECLARE @s_proc_name VARCHAR(18);
        DECLARE @SWV_RaiseMsg VARCHAR(400);
        DECLARE @SWV_dl_upd_statistics INT;
		DECLARE @i_cfg_bat_det_id INT
        

        SET NOCOUNT ON;

		SET @s_proc_name = 'ld_lockbox';
        SET @s_sir_def_name = 'lockbox';
     
	 EXECUTE @n_sp_id = dbo.dl_get_sp_id @p_batch_id, @s_proc_name;
      -----update the stats----------
        SELECT  @n_sir_count = COUNT(*)
        FROM    dbo.dls_lockbox (NOLOCK)
        WHERE   dls_batch_id = @p_batch_id;

		SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @p_batch_id
                    AND sp_id = @n_sp_id;

			SELECT  @n_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

        UPDATE  dbo.dl_bat_statistics
        SET     tot_record = @n_sir_count ,
                tot_success_rec = @n_sir_count ,
                tot_fail_rec = 0
        WHERE   bat_statistics_id = @n_statistics_id;

        SET @n_file_count = @n_file_count + 1;
            
   -- count of updated records
        SELECT  @n_sir_count = COUNT(*)
        FROM    dbo.dls_lockbox (NOLOCK)
        WHERE   dls_batch_id = @p_batch_id;

   --- update stats in table dl_bat_statistics, ---
        EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @n_statistics_id, @n_sir_count,@n_sir_count, 0;

        IF @SWV_dl_upd_statistics <> 1
		BEGIN
            RAISERROR('~Failed to update statistics~',16,1);
			RETURN
		END
	

        UPDATE  dbo.dl_cfg_bat_det
        SET     cfg_bat_det_stat = 'S'
        WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
   
   --  updates entire batch status to S Success/Complete  --
        UPDATE  dbo.dl_config_bat
        SET     config_bat_status = 'I'
        WHERE   config_bat_id = @p_batch_id;

        UPDATE STATISTICS   dbo.dls_lockbox;

 
        SET @SWP_Ret_Value1 = CONCAT(@n_sir_count,
                                     ' SIR records loaded for batch ',
                                     @p_batch_id);
       
        RETURN;
   
     
        SET NOCOUNT OFF;
    END;