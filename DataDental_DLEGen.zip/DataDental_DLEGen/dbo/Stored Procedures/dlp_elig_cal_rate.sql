﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_elig_cal_rate]
    @a_batch_id INT ,
    @a_sub_sir_id INT ,
    @a_sub_id INT ,
    @n_has_rate_code CHAR(1)
    
	
	/*	Modified Date 	: 06/15/00
		Modified By	: Ameeta
				: Added new action_code "PA", "RI"
	*/
AS
    BEGIN
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text VARCHAR(64);

        DECLARE @i_dep_cnt INT;
        DECLARE @i_spouse INT;

        DECLARE @d_plan_eff_date DATE;
        DECLARE @d_plan_term_date DATE;
        DECLARE @i_sir_id INT;

        DECLARE @s_member_code CHAR(2);
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_old_rate_code CHAR(2);
        DECLARE @n_temp_rate CHAR(2);
        DECLARE @i_num_dependent INT;
        DECLARE @i_num_facility INT;
        DECLARE @s_allow_spouse CHAR(1);
        DECLARE @i_group_id INT;
        DECLARE @i_plan_id INT;
        DECLARE @n_member_id INT;
        DECLARE @n_member_code CHAR(2);

        DECLARE @n_sub_id INT;
        DECLARE @n_sub_group_id INT;
        DECLARE @n_sub_plan_id INT;
        DECLARE @n_sub_facility_id INT;
        DECLARE @n_sub_plan_eff DATE;
        DECLARE @s_action_code CHAR(2);
        DECLARE @i_mb_gr_pl_id INT;
        DECLARE @d_action_date DATE;
        DECLARE @i_dls_sir_id INT;
        DECLARE @d_eff_rt_date DATE;
        DECLARE @tmp_rate CHAR(2);
        DECLARE @s_sub_action_code CHAR(2);
        DECLARE @n_sub_rate_code CHAR(2);
        DECLARE @n_fatal INT;
        DECLARE @d_min_action_date DATE;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        --DECLARE #SWV_cursor_var1 CURSOR;
        --DECLARE #SWV_cursor_var2 CURSOR;
       -- DECLARE @cRCSir CURSOR;


        SET NOCOUNT ON;
        SET @i_sp_id = 0;
        
        SET @i_sir_def_id = 0;
        
		SELECT @i_sir_def_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'i_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 3
        SELECT @i_sp_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'i_sp_id' and  BatchId = @a_batch_id AND Module_Id = 3
   


        IF EXISTS ( SELECT  *
                    FROM    tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#dls_elig_eff')
                            AND xtype = 'U' )
            DROP TABLE #dls_elig_eff;
        CREATE TABLE #dls_elig_eff
            (
              dls_sir_id INT ,
              action_code CHAR(2) ,
              action_date DATE
            );
        BEGIN TRY
            SELECT  @s_sub_action_code = dls_action_code ,
                    @n_sub_id = dls_sub_id ,
                    @n_sub_group_id = dls_group_id ,
                    @n_sub_plan_id = dls_plan_id ,
                    @n_sub_facility_id = facility_id ,
                    @n_sub_plan_eff = plan_eff_date ,
                    @n_sub_rate_code = rate_code
            FROM    dbo.dls_elig (NOLOCK)
            WHERE   dls_batch_id = @a_batch_id
                    AND dls_sir_id = @a_sub_sir_id;
            
            IF @s_sub_action_code = 'ST'
                RETURN 1;
	
            BEGIN
                BEGIN TRY
                    DELETE  FROM #dls_elig_eff;
                END TRY
     BEGIN CATCH
                    SET @n_error_no = ERROR_NUMBER();
                    SET @n_isam_error = ERROR_LINE();
                    SET @n_error_text = ERROR_MESSAGE();
                    DELETE  FROM #dls_elig_eff;
                    DROP TABLE #dls_elig_eff;
                END CATCH;
            END;

	--create unique index dls_elig_eff_1 on dls_elig_eff(plan_date);

            SET @i_spouse = 0;
            SET @i_dep_cnt = 0;
            SET @n_old_rate_code = NULL;
            INSERT  INTO #dls_elig_eff
                    ( dls_sir_id ,
                      action_code ,
              action_date
                    )
    SELECT dls_sir_id ,
                            action_code ,
                            action_date
                    FROM    dbo.dl_action (NOLOCK)
                    WHERE  batch_id = @a_batch_id
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_elig (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @a_sub_sir_id
                                    AND dls_action_code != 'ST' );
            IF NOT EXISTS ( SELECT  *
                            FROM    #dls_elig_eff
                            WHERE   action_code IN ( 'DA', 'DR', 'MT', 'SA',
                                                     'SR', 'GX', 'PC', 'PA',
                                                     'RI' ) )
                RETURN 1;
	
            IF @s_sub_action_code LIKE 'G[1-7]' ESCAPE '\'
                OR @s_sub_action_code = 'GI'
                OR @s_sub_action_code = 'FX'
                OR @s_sub_action_code = 'MU'
                BEGIN
                    SELECT  @d_min_action_date = MIN(action_date)
                    FROM    #dls_elig_eff;
                    
                    SELECT  @i_mb_gr_pl_id = mb_gr_pl_id
                    FROM    dbo.rlmbgrpl (NOLOCK)
                    WHERE   member_id = @n_sub_id
                            AND group_id = @n_sub_group_id
                            AND plan_id = @n_sub_plan_id
                            AND eff_gr_pl <= @n_sub_plan_eff
                            AND ( exp_gr_pl > @n_sub_plan_eff
                                  OR exp_gr_pl IS NULL
                                );
                   
                    IF @i_mb_gr_pl_id IS NULL
					BEGIN  
					SET @n_isam_error = 230
                        RAISERROR('Missing Sub''s active group/plan record',16,1);
						END
		
                   /* SET #SWV_cursor_var1 = CURSOR  FOR SELECT rate_code, eff_rt_date
			
         FROM dbo.rlmbrt (NOLOCK)
         WHERE mb_gr_pl_id = @i_mb_gr_pl_id
         AND exp_rt_date IS NULL
         ORDER BY eff_rt_date DESC;
                    OPEN #SWV_cursor_var1;
                    FETCH NEXT FROM #SWV_cursor_var1 INTO @n_old_rate_code,
                        @d_eff_rt_date;
                    WHILE @@FETCH_STATUS = 0*/
					IF OBJECT_ID('tempdb..#SWV_cursor_var1') IS NOT NULL
					DROP TABLE #SWV_cursor_var1

			CREATE TABLE #SWV_cursor_var1 
            (
              id INT IDENTITY ,
              rate_code char(2), 
			  eff_rt_date date
            );

        INSERT  INTO #SWV_cursor_var1
                ( rate_code, eff_rt_date
                )
                SELECT rate_code, eff_rt_date
			
         FROM dbo.rlmbrt (NOLOCK)
         WHERE mb_gr_pl_id = @i_mb_gr_pl_id
         AND exp_rt_date IS NULL
         ORDER BY eff_rt_date DESC;

        DECLARE @cur1_cnt INT ,
            @cur_i INT;

        SET @cur_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur1_cnt = COUNT(1)
        FROM    #SWV_cursor_var1;
	
	WHILE ( @cur_i <= @cur1_cnt )
                        BEGIN

						SELECT  @n_old_rate_code=rate_code,
						 @d_eff_rt_date=eff_rt_date
					FROM    #SWV_cursor_var1
					WHERE   id = @cur_i;

                            GOTO SWL_Label5;
                            /*FETCH NEXT FROM #SWV_cursor_var1 INTO @n_old_rate_code,
                                @d_eff_rt_date;*/
								 SET @cur_i = @cur_i + 1;
                        END;
                    SWL_Label5:
                   -- CLOSE #SWV_cursor_var1;
                    IF ( @n_old_rate_code IS NULL
                         )
					   BEGIN  
					SET @n_isam_error = 231
                        RAISERROR('Missing Sub''s active rate code',16,1);
						END
		
          IF @d_min_action_date < @d_eff_rt_date
SET @d_min_action_date = @d_eff_rt_date;
		
 /*SET #SWV_cursor_var2 = CURSOR  FOR SELECT DISTINCT m.member_id, m.member_code
				
         FROM dbo.rlplfc rf (NOLOCK), dbo.member m (NOLOCK)
         WHERE rf.mb_gr_pl_id = @i_mb_gr_pl_id
         AND m.member_id = rf.member_id
         AND m.member_id != @n_sub_id
   AND ((rf.eff_date <= @d_min_action_date
         AND (rf.exp_date >  @d_min_action_date OR rf.exp_date IS NULL))
         OR (rf.eff_date > @d_min_action_date AND
							(rf.exp_date > @d_min_action_date OR rf.exp_date IS NULL)));
                    OPEN #SWV_cursor_var2;
                    FETCH NEXT FROM #SWV_cursor_var2 INTO @n_member_id,
                        @n_member_code;
                    WHILE @@FETCH_STATUS = 0*/
				IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
			DROP TABLE #SWV_cursor_var2

			CREATE TABLE #SWV_cursor_var2 
            (
              id INT IDENTITY ,
              member_id int,
			   member_code char(3)
            );

        INSERT  INTO #SWV_cursor_var2
                ( member_id, member_code
                )
                SELECT DISTINCT m.member_id, m.member_code
				
         FROM dbo.rlplfc rf (NOLOCK), dbo.member m (NOLOCK)
         WHERE rf.mb_gr_pl_id = @i_mb_gr_pl_id
         AND m.member_id = rf.member_id
         AND m.member_id != @n_sub_id
         AND ((rf.eff_date <= @d_min_action_date
         AND (rf.exp_date >  @d_min_action_date OR rf.exp_date IS NULL))
         OR (rf.eff_date > @d_min_action_date AND
							(rf.exp_date > @d_min_action_date OR rf.exp_date IS NULL)))

        DECLARE @cur2_cnt INT ,
            @cur2_i INT;

        SET @cur2_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur2_cnt = COUNT(1)
        FROM    #SWV_cursor_var2;
	
	WHILE ( @cur2_i <= @cur2_cnt )
                        BEGIN

						SELECT @n_member_id=member_id,
						 @n_member_code=member_code
						FROM    #SWV_cursor_var2
						WHERE   id = @cur2_i;

                            IF @n_member_code IN ( '30', '40' )
                                BEGIN
                                    SET @i_spouse = @i_spouse + 1;
                                    SET @i_dep_cnt = @i_dep_cnt + 1;
                                END;
						
                            IF @n_member_code IN ( '50', '70' )
                                SET @i_dep_cnt = @i_dep_cnt + 1;
                           /* FETCH NEXT FROM #SWV_cursor_var2 INTO @n_member_id,
                                @n_member_code;*/
								 SET @cur2_i = @cur2_i + 1;
                        END;
                   -- CLOSE #SWV_cursor_var2;
                END;
	
            SET @n_rate_code = NULL;
           
		   /* SET @cRCSir = CURSOR  FOR SELECT
      DISTINCT action_date
		
      FROM #dls_elig_eff
      ORDER BY action_date;
            OPEN @cRCSir;
            FETCH NEXT FROM @cRCSir INTO @d_action_date;
            WHILE @@FETCH_STATUS = 0 */
			DECLARE @SWV_cursor_var3 TABLE
            (
              id INT IDENTITY ,
             action_date date
            );

        INSERT  INTO @SWV_cursor_var3
                ( action_date
                )
                SELECT
      DISTINCT action_date
		
      FROM #dls_elig_eff
      ORDER BY action_date;

        DECLARE @cur3_cnt INT ,
            @cur3_i INT;

        SET @cur3_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur3_cnt = COUNT(1)
        FROM    @SWV_cursor_var3;
	
	WHILE ( @cur3_i <= @cur3_cnt )
                BEGIN
                    BEGIN

					SELECT @d_action_date=action_date
                FROM    @SWV_cursor_var3
                WHERE   id = @cur3_i;

                        --DECLARE @SWV_cursor_var3 CURSOR;
                        --DECLARE #SWV_cursor_var4 CURSOR;
                        --DECLARE #SWV_cursor_var5 CURSOR;
                        BEGIN TRY
                   /*
						    SET @SWV_cursor_var3 = CURSOR  FOR SELECT dls_sir_id, action_code
			
               FROM #dls_elig_eff
               WHERE action_date = @d_action_date;
                            OPEN @SWV_cursor_var3;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @i_dls_sir_id,
                                @s_action_code;
                            WHILE @@FETCH_STATUS = 0
							*/
			IF OBJECT_ID('tempdb..#SWV_cursor_var4') IS NOT NULL
			DROP TABLE #SWV_cursor_var4

			CREATE TABLE #SWV_cursor_var4
            (
              id INT IDENTITY ,
             dls_sir_id int, 
			 action_code CHAR(2)
            );

        INSERT  INTO #SWV_cursor_var4
                ( dls_sir_id, action_code
                )
                SELECT dls_sir_id, action_code
			
               FROM #dls_elig_eff
               WHERE action_date = @d_action_date;

        DECLARE @cur4_cnt INT ,
            @cur4_i INT;

        SET @cur4_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur4_cnt = COUNT(1)
        FROM    #SWV_cursor_var4;
	
	WHILE ( @cur4_i <= @cur4_cnt )
                                BEGIN

								SELECT   @i_dls_sir_id=dls_sir_id,
								 @s_action_code=action_code
							FROM    #SWV_cursor_var4
							WHERE   id = @cur4_i;

                                    IF @s_action_code LIKE 'G[1-7]' ESCAPE '\'
                                        OR @s_action_code = 'GI'
                                        GOTO SWL_Label6;
				
                                    SELECT  @s_member_code = member_code
                                    FROM    dbo.dls_elig (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @i_dls_sir_id;
                                    
                                    IF @s_member_code IN ( '30', '40' )
                                        BEGIN
                                            IF @s_action_code IN ( 'DR', 'DA',
                                                              'PC', 'PA', 'RI',
                                                              'GX' )
                                                BEGIN
                                                    SET @i_spouse = @i_spouse
                                                        + 1;
                                                    SET @i_dep_cnt = @i_dep_cnt
                                                        + 1;
                                                END;
					
                                            IF @s_action_code = 'MT'
                                                BEGIN
                                                    SET @i_spouse = @i_spouse- 1;
													SET @i_dep_cnt = @i_dep_cnt- 1;
                                                END;
                                        END;
				
                                    IF @s_member_code IN ( '50', '70' )
                                        BEGIN
                                            IF @s_action_code IN ( 'DA', 'DR',
                                                              'PC', 'PA', 'RI',
                                                              'GX' )
                                                SET @i_dep_cnt = @i_dep_cnt
                                                    + 1;
					
                                            IF @s_action_code = 'MT'
                                                SET @i_dep_cnt = @i_dep_cnt
                                                    - 1;
                                        END;
                                    SWL_Label6:
                                    /*FETCH NEXT FROM @SWV_cursor_var3 INTO @i_dls_sir_id,
       @s_action_code;
										*/
										 SET @cur4_i = @cur4_i + 1;
  END;
                            --CLOSE @SWV_cursor_var3;
                            IF @i_spouse > 0
                                BEGIN
                             /* SET #SWV_cursor_var4 = CURSOR  FOR SELECT pr.rate_code, pr.rate_num_depend,
						pr.num_facil, pr.spouse
				 
                  FROM dbo.pl_rat pr (NOLOCK), dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_group_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.spouse = 'Y' AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
							 (gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY rate_num_depend;
                                    OPEN #SWV_cursor_var4;
                                    FETCH NEXT FROM #SWV_cursor_var4 INTO @n_rate_code,
                                        @i_num_dependent, @i_num_facility,
                                        @s_allow_spouse;
                                    WHILE @@FETCH_STATUS = 0*/

				IF OBJECT_ID('tempdb..#SWV_cursor_var5') IS NOT NULL
				DROP TABLE #SWV_cursor_var5

			CREATE TABLE #SWV_cursor_var5
            (
              id INT IDENTITY ,
              rate_code CHAR(2), 
			  rate_num_depend smallint,
				num_facil smallint,
				spouse char(1)
            );


        INSERT  INTO #SWV_cursor_var5
                ( rate_code, rate_num_depend,
						num_facil,spouse
				 
                )
                SELECT pr.rate_code, pr.rate_num_depend,
						pr.num_facil, pr.spouse
				 
                  FROM dbo.pl_rat pr (NOLOCK), dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_group_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.spouse = 'Y' AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
							 (gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY rate_num_depend;

        DECLARE @cur5_cnt INT ,
            @cur5_i INT;

        SET @cur5_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur5_cnt = COUNT(1)
        FROM    #SWV_cursor_var5;
	
	WHILE ( @cur5_i <= @cur5_cnt )
                                        BEGIN

										SELECT  @n_rate_code=rate_code, @i_num_dependent=rate_num_depend,
											@i_num_facility=num_facil,@s_allow_spouse=spouse
									FROM    #SWV_cursor_var5
									WHERE   id = @cur5_i;

											GOTO SWL_Label7;
                                           /* FETCH NEXT FROM #SWV_cursor_var4 INTO @n_rate_code,
                                                @i_num_dependent,
                                                @i_num_facility,
                                                @s_allow_spouse;*/
												 SET @cur5_i = @cur5_i + 1;
                                        END;
                                    SWL_Label7:
                                    --CLOSE #SWV_cursor_var4;
                                END;
                            ELSE
                                BEGIN
                                   /* SET #SWV_cursor_var5 = CURSOR  FOR SELECT pr.rate_code, pr.rate_num_depend,
						pr.num_facil, pr.spouse
					
                  FROM dbo.pl_rat pr (NOLOCK), dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_group_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
								(gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY spouse,rate_num_depend;
                                  OPEN #SWV_cursor_var5;
                                    FETCH NEXT FROM #SWV_cursor_var5 INTO @n_rate_code,
                                        @i_num_dependent, @i_num_facility,
                                        @s_allow_spouse;
                       WHILE @@FETCH_STATUS = 0*/
		IF OBJECT_ID('tempdb..#SWV_cursor_var6') IS NOT NULL
		DROP TABLE #SWV_cursor_var6

			CREATE TABLE #SWV_cursor_var6
            (
              id INT IDENTITY ,
             rate_code char(2), 
			 rate_num_depend smallint,
			num_facil smallint,
			spouse char(1)
            );
			

        INSERT  INTO #SWV_cursor_var6
         (rate_code, rate_num_depend,
						num_facil, spouse
                )
                SELECT pr.rate_code, pr.rate_num_depend,
						pr.num_facil, pr.spouse
					
                  FROM dbo.pl_rat pr (NOLOCK), dbo.group_cap_rate gcr (NOLOCK)
                  WHERE gcr.group_id = @n_sub_group_id AND
                  gcr.plan_id = @n_sub_plan_id AND
                  pr.rate_code = gcr.rate_code AND
                  pr.rate_num_depend >= @i_dep_cnt AND
                  gcr.eff_date <= @d_action_date AND
								(gcr.exp_date > @d_action_date OR gcr.exp_date IS NULL)
                  ORDER BY spouse,rate_num_depend;

        DECLARE @cur6_cnt INT ,
            @cur6_i INT;

        SET @cur6_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur6_cnt = COUNT(1)
        FROM    #SWV_cursor_var6;
	
	WHILE ( @cur6_i <= @cur6_cnt )
            
		          BEGIN
			
				SELECT  @n_rate_code=rate_code, @i_num_dependent=rate_num_depend,
						@i_num_facility=num_facil, @s_allow_spouse=spouse
                FROM    #SWV_cursor_var6
                WHERE   id = @cur6_i;
                                            GOTO SWL_Label8;
                                            /*FETCH NEXT FROM #SWV_cursor_var5 INTO @n_rate_code,
                                                @i_num_dependent,
                                                @i_num_facility,
                                                @s_allow_spouse;*/
												 SET @cur6_i = @cur6_i + 1;
                                        END;
                                    SWL_Label8:
                                    --CLOSE #SWV_cursor_var5;
                                END;
			
                            IF ( @n_rate_code IS NULL
                                 )
                                RETURN -141;
		
                            IF ( @n_old_rate_code IS NULL
                                )
                                IF @n_has_rate_code = 'Y'
                                    BEGIN
                                        IF @s_sub_action_code = 'SA'
                                            IF @n_sub_rate_code != @n_rate_code
                                                BEGIN
                                                    
                                                    
                                                    EXECUTE @n_error_no = dbo.usp_dl_log_error @a_batch_id,
                                                        @i_sp_id,
                                                        @i_sir_def_id,
                                                        @a_sub_sir_id, 232;
                                                    UPDATE  dbo.dls_elig
                                                    SET     rate_code = @n_rate_code
                                                    WHERE   dls_batch_id = @a_batch_id
                                                            AND dls_sir_id = @a_sub_sir_id;
                                                END;
					
				
									SET @n_old_rate_code = @n_sub_rate_code;
                                    END;
                               ELSE
                                    BEGIN
                                        SET @n_old_rate_code = @n_rate_code;
                                        UPDATE  dbo.dls_elig
                                        SET     rate_code = @n_rate_code
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND dls_sir_id = @a_sub_sir_id;
                                    END;
			
                            ELSE
                                IF @n_rate_code != @n_old_rate_code
								  BEGIN
								  
								  EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                            @a_sub_sir_id, 'RC',
                                            @d_action_date;
                                        SET @n_old_rate_code = @n_rate_code;
                                        UPDATE  dbo.dls_elig
                                        SET     rate_code = @n_rate_code
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND dls_sir_id IN (
                                                SELECT  dls_sir_id
                                                FROM    #dls_elig_eff
                                                WHERE   action_date = @d_action_date
                                                        AND dls_sir_id != @a_sub_sir_id );
                                    END;
			
		
                IF @i_num_facility = 1
                                UPDATE  dbo.dls_elig
                                SET     facility_id = @n_sub_facility_id
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_action_code != 'MT'
                                        AND dls_sir_id IN (
                                        SELECT  dls_sir_id
                                        FROM    #dls_elig_eff
                                        WHERE   action_date = @d_action_date );
                        END TRY
                        BEGIN CATCH
                            SET @n_error_no = ERROR_NUMBER();
                           -- SET @n_isam_error = ERROR_LINE();
                            SET @n_error_text = ERROR_MESSAGE();
                            
                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @a_sub_sir_id,
                                @n_isam_error;
                            IF @n_fatal <> 1
                                RETURN -1;
                        END CATCH;
                    END;
                  --  FETCH NEXT FROM @cRCSir INTO @d_action_date;
				   SET @cur3_i = @cur3_i + 1;
                END;
           -- CLOSE @cRCSir;
            IF ( @n_rate_code IS NOT NULL
                
               )
                IF @s_sub_action_code != 'SA'
                    AND @n_has_rate_code != 'N'
                    UPDATE  dbo.dls_elig
                    SET     rate_code = @n_rate_code
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @a_sub_sir_id;
		
	
	--trace off;
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;

    END;