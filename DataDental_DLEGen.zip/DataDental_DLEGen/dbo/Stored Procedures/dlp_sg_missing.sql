﻿CREATE PROCEDURE [dbo].[dlp_sg_missing]
    @a_batch_id INT ,
    @n_term_missing DATE
    

-- DATE: 04/23/2001
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);

        DECLARE @n_in_transaction CHAR(1);
        DECLARE @go_to_next CHAR(1);
        DECLARE @i_fatal INT;
        DECLARE @sg_sir_id INT;
        DECLARE @sg_sub_sir_id INT;
        DECLARE @a_error_no INT;
        DECLARE @n_tmp_sub CHAR(1);
        DECLARE @n_tmp_dep CHAR(1);
        DECLARE @n_to_commit INT;
        DECLARE @n_sir_count INT;
        DECLARE @d_family_id INT;
        DECLARE @n_member_id INT;
        DECLARE @n_family_id INT;
        DECLARE @n_master_gp_id INT;
        DECLARE @n_group_id INT;
        DECLARE @n_group_type CHAR(2);
        DECLARE @n_mbgrpl_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_mbgrpl_eff DATE;
        DECLARE @n_fc_id INT;
        DECLARE @n_plfc_eff DATE;
        DECLARE @n_term_date DATE;
        DECLARE @n_sub_ssn CHAR(11);
        DECLARE @n_ssn CHAR(11);
        DECLARE @n_last_name CHAR(15);
        DECLARE @n_first_name CHAR(15);
        DECLARE @n_middle_init CHAR(1);
        DECLARE @n_sub_alt_id CHAR(20);
        DECLARE @n_alt_id CHAR(20);
        DECLARE @n_member_code CHAR(3);
        DECLARE @n_date_of_birth DATE;
        DECLARE @n_student_flag CHAR(1);
        DECLARE @n_disable_flag CHAR(1);
        DECLARE @n_cobra_flag CHAR(1);
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_mbrt_eff DATE;
        DECLARE @n_addr1 CHAR(30);
        DECLARE @n_addr2 CHAR(30);
        DECLARE @n_city CHAR(30);
        DECLARE @n_state CHAR(2);
        DECLARE @n_zip CHAR(5);
        DECLARE @n_msg_alt CHAR(20);
        DECLARE @n_plan_name CHAR(30);
        DECLARE @n_fc_alt CHAR(20);
        DECLARE @new_dls_sir_id INT
        DECLARE @n_process_count INT
        DECLARE @n_succ_count INT
        DECLARE @sg_sp_id INT
        DECLARE @sg_sir_def_id INT
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;
        --DECLARE @SWV_cursor_var3 CURSOR;
        --DECLARE @SWV_cursor_var4 CURSOR;
        --DECLARE @SWV_cursor_var5 CURSOR;
        --DECLARE @SWV_cursor_var6 CURSOR;
        --DECLARE @SWV_cursor_var7 CURSOR;
        --DECLARE @SWV_cursor_var8 CURSOR;



        SET NOCOUNT ON;
        SET @new_dls_sir_id = 0
        
        --SET @n_process_count = 0
        
        --SET @n_succ_count = 0
		SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
        
        SET @sg_sp_id = 0
        
        SET @sg_sir_def_id = 0
        
        BEGIN TRY
            
            SET @n_tmp_sub = 'N';
            SET @n_tmp_dep = 'N';
            SET @n_to_commit = 40;
            SET @sg_sir_id = 0;
            SET @n_in_transaction = 'N';
            SET @n_sir_count = 0;
-- 20120528$$ks - I cannot think of any reason we would want to terminate all Single Groups
--  not included in a specific file!! If the need arises I will unblock this code!
-- I can see some one changing the parameter to see what would happen and CHAOS ensueing!


            RETURN 1; --- We may want to terminate all members of a given MSG but NEVER like this!
           
            SET @n_in_transaction = 'Y';


-- TERMINATE MISSING SUBSCRIBERS FIRST
-- START FROM GROUP TABLE WITH GROUP TYPE "MS"

DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 group_id INT
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								group_id
                                )
								SELECT group_id

      FROM dbo.[group] (NOLOCK)
      WHERE group_type = 'MS';

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

   SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;

/*

            SET @SWV_cursor_var1 = CURSOR  FOR SELECT group_id

      FROM dbo.[group] (NOLOCK)
      WHERE group_type = 'MS';
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @n_master_gp_id;
            WHILE @@FETCH_STATUS = 0
			*/
                WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @n_master_gp_id=group_id
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;



			DECLARE @SWV_cursor_var2 TABLE
                        (
                         id INT IDENTITY ,
						 group_id INT
                        );
                          INSERT  INTO @SWV_cursor_var2
                                ( 
								group_id
                                )
								SELECT group_id
 
         FROM dbo.[group] (NOLOCK)
         WHERE group_type = 'SG'
         AND group_parent = @n_master_gp_id;

	  DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
                        FROM  @SWV_cursor_var2;

				
				/*
                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT group_id
 
         FROM dbo.[group] (NOLOCK)
         WHERE group_type = 'SG'
         AND group_parent = @n_master_gp_id;
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @n_group_id;
                    WHILE @@FETCH_STATUS = 0
					*/

                        WHILE ( @cur2_i <= @cur2_cnt )
            BEGIN
			SELECT  @n_group_id=group_id
					FROM @SWV_cursor_var2
            WHERE   id = @cur2_i;


			DECLARE @SWV_cursor_var3 TABLE
                        (
                         id INT IDENTITY ,
						 member_id INT
                        );
                          INSERT  INTO @SWV_cursor_var3
                                ( 
								member_id
                                )
								SELECT DISTINCT member_id
  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE group_id = @n_group_id
            AND exp_gr_pl IS NULL;

	  DECLARE @cur3_cnt INT ,
                            @cur3_i INT;

                        SET @cur3_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur3_cnt = COUNT(1)
                        FROM  @SWV_cursor_var3;


			/*
                            SET @SWV_cursor_var3 = CURSOR  FOR SELECT DISTINCT member_id
  
            FROM dbo.rlmbgrpl (NOLOCK)
            WHERE group_id = @n_group_id
            AND exp_gr_pl IS NULL;
                            OPEN @SWV_cursor_var3;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @d_family_id;
                            WHILE @@FETCH_STATUS = 0
							*/
                                WHILE ( @cur3_i <= @cur3_cnt )
            BEGIN
			SELECT  @d_family_id=member_id
					FROM @SWV_cursor_var3
            WHERE   id = @cur3_i;

                                    IF EXISTS ( SELECT  *
           FROM    dbo.dls_sg_member (NOLOCK)
                                                WHERE   dls_batch_id = @a_batch_id
                                                        AND ( dls_status IS NOT NULL
                                                              AND dls_status <> ''
                                                            )
                                                        AND dls_subscriber_id = @d_family_id )
                                        GOTO SWL_Label9;


										DECLARE @SWV_cursor_var4 TABLE
                        (
                          id INT IDENTITY ,
						  member_id INT, 
						  family_id INT, 
						  member_ssn CHAR(11), 
						  last_name CHAR(15), 
						  first_name CHAR(15),
	                      middle_init CHAR, 
	                      alt_id CHAR(20), 
	                      member_code CHAR(3), 
	                      date_of_birth DATE, 
	                      student_flag CHAR,
	                      disable_flag CHAR
                        );
                          INSERT  INTO @SWV_cursor_var4
                                ( 
								 member_id, family_id, member_ssn, last_name, first_name,
	middle_init, alt_id, member_code, date_of_birth, student_flag,
	disable_flag
                                )
								SELECT member_id, family_id, member_ssn, last_name, first_name,
	middle_init, alt_id, member_code, date_of_birth, student_flag,
	disable_flag
   
               FROM dbo.member (NOLOCK)
               WHERE member_id = @d_family_id;

	  DECLARE @cur4_cnt INT ,
                            @cur4_i INT;

                        SET @cur4_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur4_cnt = COUNT(1)
                        FROM  @SWV_cursor_var4;



										/*
   
                                    SET @SWV_cursor_var4 = CURSOR  FOR SELECT member_id, family_id, member_ssn, last_name, first_name,
	middle_init, alt_id, member_code, date_of_birth, student_flag,
	disable_flag
   
               FROM dbo.member (NOLOCK)
               WHERE member_id = @d_family_id;
                                    OPEN @SWV_cursor_var4;
                                    FETCH NEXT FROM @SWV_cursor_var4 INTO @n_member_id,
                                        @n_family_id, @n_ssn, @n_last_name,
                                        @n_first_name, @n_middle_init,
                                        @n_alt_id, @n_member_code,
                                        @n_date_of_birth, @n_student_flag,
                                        @n_disable_flag;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                        WHILE ( @cur4_i <= @cur4_cnt )
            BEGIN
			SELECT @n_member_id=member_id,
                                        @n_family_id=family_id, @n_ssn=member_ssn, @n_last_name=last_name,
                                        @n_first_name=first_name, @n_middle_init=middle_init,
                                        @n_alt_id=alt_id, @n_member_code=member_code,
                                        @n_date_of_birth=date_of_birth, @n_student_flag=student_flag,
                                        @n_disable_flag=disable_flag
					FROM @SWV_cursor_var4
            WHERE   id = @cur4_i;

                                            SELECT  @n_addr1 = addr1 ,
                                                    @n_addr2 = addr2 ,
                                                    @n_city = city ,
                                                    @n_state = state ,
                                                    @n_zip = zip
                                            FROM    dbo.address (NOLOCK)
                                            WHERE   subsys_code = 'MB'
                                                    AND sys_rec_id = @n_family_id
             AND addr_type = 'L';
                                            
                                            SET @n_mbgrpl_id = NULL;
                                            SET @n_fc_id = NULL;



											DECLARE @SWV_cursor_var5 TABLE
                        (
                         id INT IDENTITY ,
						   mb_gr_pl_id INT, 
						   plan_id INT, 
						   eff_gr_pl DATE, 
						   cobra_flag CHAR,
		                   facility_id INT, 
		                   eff_date DATE,
		                   rate_code CHAR(2),
		                   eff_rt_date DATE
                        );
                          INSERT  INTO @SWV_cursor_var5
   ( 
								 mb_gr_pl_id, plan_id, eff_gr_pl, cobra_flag,
		facility_id, eff_date,rate_code,eff_rt_date
                                )
								SELECT a.mb_gr_pl_id, a.plan_id, a.eff_gr_pl, a.cobra_flag,
		b.facility_id, b.eff_date, c.rate_code, c.eff_rt_date
	
                  FROM dbo.rlmbgrpl a (NOLOCK),
				  dbo.rlplfc b (NOLOCK),
				  dbo.rlmbrt c (NOLOCK)
                  WHERE a.member_id = @n_family_id
                  AND a.group_id = @n_group_id
                  AND a.exp_gr_pl IS NULL
                  AND b.member_id = @n_member_id
                  AND b.mb_gr_pl_id = a.mb_gr_pl_id
                  AND b.exp_date IS NULL
                  AND c.mb_gr_pl_id = a.mb_gr_pl_id
                  AND c.exp_rt_date IS NULL;

	  DECLARE @cur5_cnt INT ,
                            @cur5_i INT;

                        SET @cur5_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur5_cnt = COUNT(1)
                        FROM  @SWV_cursor_var5;
											/*
                                            SET @SWV_cursor_var5 = CURSOR  FOR SELECT a.mb_gr_pl_id, a.plan_id, a.eff_gr_pl, a.cobra_flag,
		b.facility_id, b.eff_date, c.rate_code, c.eff_rt_date
	
                  FROM dbo.rlmbgrpl a (NOLOCK),
				  dbo.rlplfc b (NOLOCK),
				  dbo.rlmbrt c (NOLOCK)
                  WHERE a.member_id = @n_family_id
                  AND a.group_id = @n_group_id
                  AND a.exp_gr_pl IS NULL
                  AND b.member_id = @n_member_id
                  AND b.mb_gr_pl_id = a.mb_gr_pl_id
                  AND b.exp_date IS NULL
                  AND c.mb_gr_pl_id = a.mb_gr_pl_id
                  AND c.exp_rt_date IS NULL;
                                            OPEN @SWV_cursor_var5;
                                            FETCH NEXT FROM @SWV_cursor_var5 INTO @n_mbgrpl_id,
                                                @n_plan_id, @n_mbgrpl_eff,
                                                @n_cobra_flag, @n_fc_id,
                                                @n_plfc_eff, @n_rate_code,
                                                @n_mbrt_eff;
                                            WHILE @@FETCH_STATUS = 0
											*/
                                                
												WHILE ( @cur5_i <= @cur5_cnt )
            BEGIN
			SELECT  @n_mbgrpl_id=mb_gr_pl_id,
                                                @n_plan_id=plan_id, @n_mbgrpl_eff=eff_gr_pl,
                                                @n_cobra_flag=cobra_flag, @n_fc_id=facility_id,
                                                @n_plfc_eff=eff_date, @n_rate_code=rate_code,
                                                @n_mbrt_eff=eff_rt_date
					FROM @SWV_cursor_var5
            WHERE   id = @cur5_i;

                                                    SET @go_to_next = 'N';
                                                    IF @n_mbgrpl_id IS NULL
                                                        OR @n_mbgrpl_eff IS NULL
                                                        OR @n_plfc_eff IS NULL
                                                        OR @n_mbrt_eff IS NULL
                      BEGIN
                                                            SET @go_to_next = 'Y';
                                                            GOTO SWL_Label11;
                                                        END;
		
                                                    IF @n_mbgrpl_eff > @n_term_missing
                                                        SET @n_term_date = @n_mbgrpl_eff;
                                                    ELSE
                                                        IF @n_plfc_eff > @n_term_missing
                                                            SET @n_term_date = @n_plfc_eff;
                                                        ELSE
                                                    IF @n_mbrt_eff > @n_term_missing
                                                              SET @n_term_date = @n_plfc_eff;
                                                            ELSE
                                                              SET @n_term_date = @n_term_missing;
		
                                                    SET @n_msg_alt = NULL;
                                                    SET @n_plan_name = NULL;
                                                    SET @n_fc_alt = NULL;
                                                    SELECT  @n_msg_alt = alt_id
                                                    FROM    dbo.[group]  (NOLOCK)
                                                    WHERE   group_id = @n_group_id;
                                                    
                                                    SELECT  @n_plan_name = plan_dsp_name
                                                    FROM    dbo.[plan](NOLOCK)
                                                    WHERE   plan_id = @n_plan_id;
                                                    
                                                    SELECT  @n_fc_alt = alt_id
                                                    FROM    dbo.facility (NOLOCK)
                                                    WHERE   fc_id = @n_fc_id;
                                                   
                                                    BEGIN
                                                        INSERT
                                                              INTO dbo.dls_sg_member
                                                              ( dls_batch_id ,
                                                              member_flag ,
                                                              alt_id ,
                                                              ssn ,
                                                              sub_ssn ,
                                                              sub_alt_id ,
                                                              member_code ,
                                                              last_name ,
                                                              first_name ,
                                                              middle_init ,
                                                              date_of_birth ,
                                                              student_flag ,
                                                              disable_flag ,
                                                              cobra_flag ,
                                                              msg_group_id ,
                                                              plan_id ,
                                                              facility_id ,
                                                              rate_code ,
                                                              mb_gppl_eff_date ,
                                                              mb_fc_eff_date ,
                               mb_term_date ,
                                                              address1 ,
                                                              address2 ,
                                                              city ,
                                                              state ,
                                                              zip ,
                                                              dls_member_id ,
                                                              dls_subscriber_id ,
                dls_msg_id ,
                                                              dls_group_id ,
    dls_plan_id ,
                                                              dls_facility_id ,
                dls_action_code ,
                                                              dls_status ,
                                                              dls_source
                                                              )
                                                        VALUES
                                                              ( @a_batch_id ,
                                                              '00' ,
                                                              @n_alt_id ,
                                                              @n_ssn ,
                                                              @n_ssn ,
                                                              @n_alt_id ,
                                                              @n_member_code ,
                                                              @n_last_name ,
                                                              @n_first_name ,
                                                              @n_middle_init ,
                                                              CAST(@n_date_of_birth AS CHAR(10)) ,
                                                              @n_student_flag ,
                                                              @n_disable_flag ,
                                                              @n_cobra_flag ,
                                                              @n_master_gp_id ,
                                                              @n_plan_id ,
                                                              @n_fc_id ,
                                                              @n_rate_code ,
                                                              CAST(@n_mbgrpl_eff AS CHAR(10)) ,
                                                              CAST(@n_plfc_eff AS CHAR(10)) ,
                                                              CAST(@n_term_date AS CHAR(10)) ,
                                                              @n_addr1 ,
                                                              @n_addr2 ,
                                                              @n_city ,
                                                              @n_state ,
                                                              @n_zip ,
                                                              @n_member_id ,
                                                              @n_family_id ,
                                                              @n_master_gp_id ,
                                                              @n_group_id ,
                                                              @n_plan_id ,
                                                              @n_fc_id ,
                                                              'ST' ,
                                                              'P' ,
       'A'
                                                              );
		
                                             ;
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                            @new_dls_sir_id,
                                                            'ST', @n_term_date;
                                                        UPDATE
                                                              dbo.dls_sg_member
                                                        SET   dls_sub_sir_id = @new_dls_sir_id
                                                        WHERE dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @new_dls_sir_id;
       END;
                                             SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
				SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1

                                                    SET @n_process_count = @n_process_count                    + 1;
                                 
                                             
                                                    SET @n_succ_count = @n_succ_count
                                                        + 1;
                                             UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
								UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                                                    SET @n_sir_count = @n_sir_count
                                                        + 1;
                                                    IF @n_sir_count >= @n_to_commit
                                                        BEGIN
                                                            
                                                            SET @n_sir_count = 0;
                                                        END;
		
                                                    SET @n_mbgrpl_id = NULL;
                                                    SET @n_fc_id = NULL;
                                                    --FETCH NEXT FROM @SWV_cursor_var5 INTO @n_mbgrpl_id,
                                                    --    @n_plan_id,
                                                    --    @n_mbgrpl_eff,
                                                    --    @n_cobra_flag,
                                                    --    @n_fc_id, @n_plfc_eff,
                                                    --    @n_rate_code,
                                                    --    @n_mbrt_eff;

													SET @cur5_i = @cur5_i + 1;
                                                END;
                                            SWL_Label11:
                                            --CLOSE @SWV_cursor_var5;
                                            IF @go_to_next = 'Y'
                                                GOTO SWL_Label10;
                                            --FETCH NEXT FROM @SWV_cursor_var4 INTO @n_member_id,
                                            --    @n_family_id, @n_ssn,
                                            --    @n_last_name, @n_first_name,
                                            --    @n_middle_init, @n_alt_id,
                                            --    @n_member_code,
  --    @n_date_of_birth,
                                            --    @n_student_flag,
    --    @n_disable_flag;
											SET @cur4_i = @cur4_i + 1;
                                        END;
                                    SWL_Label10:
                                    --CLOSE @SWV_cursor_var4;
                                    IF @go_to_next = 'Y'
                                        GOTO SWL_Label8;
                                    SWL_Label9:
                                    --FETCH NEXT FROM @SWV_cursor_var3 INTO @d_family_id;
									SET @cur3_i = @cur3_i + 1;
                                END;
                            SWL_Label8:
                            --CLOSE @SWV_cursor_var3;
                            --FETCH NEXT FROM @SWV_cursor_var2 INTO @n_group_id;
							SET @cur2_i = @cur2_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var2;
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @n_master_gp_id;
					SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @SWV_cursor_var1;



-- TERMINATE MISSING DEPENDENTS THEN
-- CAN ONLY TERMINATE DEPENDENT WHOSE SUBSCRIBER SIR IS IN THE TAPE

            
            SET @n_sir_count = 0;

			DECLARE @SWV_cursor_var6 TABLE
                        (
                         id INT IDENTITY ,
						   member_id INT, 
						   family_id INT
                        );
                          INSERT  INTO @SWV_cursor_var6
                         ( 
								 member_id, family_id
                                )
								SELECT member_id, family_id

      FROM dbo.member (NOLOCK)
  WHERE member_id <> family_id
      AND family_id IN(SELECT dls_member_id FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND (dls_status IS NOT NULL AND dls_status <> '')
      AND dls_action_code <> 'ST')
      AND member_id NOT IN(SELECT dls_member_id FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND (dls_status IS NOT NULL AND  dls_status <> ''));

	  DECLARE @cur6_cnt INT ,
                            @cur6_i INT;

                        SET @cur6_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur6_cnt = COUNT(1)
                        FROM  @SWV_cursor_var6;

			/*
            SET @SWV_cursor_var6 = CURSOR  FOR SELECT member_id, family_id

      FROM dbo.member (NOLOCK)
      WHERE member_id <> family_id
      AND family_id IN(SELECT dls_member_id FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND (dls_status IS NOT NULL AND dls_status <> '')
      AND dls_action_code <> 'ST')
      AND member_id NOT IN(SELECT dls_member_id FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND (dls_status IS NOT NULL AND  dls_status <> ''));
            OPEN @SWV_cursor_var6;
            FETCH NEXT FROM @SWV_cursor_var6 INTO @n_member_id, @n_family_id;
            WHILE @@FETCH_STATUS = 0
			*/

                WHILE ( @cur6_i <= @cur6_cnt )
            BEGIN
			SELECT  @n_member_id=member_id, @n_family_id=family_id
					FROM @SWV_cursor_var6
            WHERE   id = @cur6_i;

                    SET @n_group_id = NULL;
                    SET @n_group_type = NULL;


					DECLARE @SWV_cursor_var7 TABLE
                        (
                         id INT IDENTITY ,
						   group_id INT, 
						   group_type CHAR(2), 
						   group_parent INT
                        );
                          INSERT  INTO @SWV_cursor_var7
                                ( 
								 group_id, group_type, group_parent
                                )
								SELECT group_id, group_type, group_parent
	
         FROM dbo.[group] (NOLOCK)
         WHERE group_id IN(SELECT group_id FROM dbo.rlmbgrpl
         WHERE member_id = @n_family_id
         AND exp_gr_pl IS NULL);

	  DECLARE @cur7_cnt INT ,
                            @cur7_i INT;

    SET @cur7_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur7_cnt = COUNT(1)
                        FROM  @SWV_cursor_var7;
					/*
                    SET @SWV_cursor_var7 = CURSOR  FOR SELECT group_id, group_type, group_parent
	
         FROM dbo.[group] (NOLOCK)
         WHERE group_id IN(SELECT group_id FROM dbo.rlmbgrpl
         WHERE member_id = @n_family_id
         AND exp_gr_pl IS NULL);
                    OPEN @SWV_cursor_var7;
                    FETCH NEXT FROM @SWV_cursor_var7 INTO @n_group_id,
                        @n_group_type, @n_master_gp_id;
                    WHILE @@FETCH_STATUS = 0
					*/

                        WHILE ( @cur7_i <= @cur7_cnt )
            BEGIN
			SELECT  @n_group_id=group_id,
                    @n_group_type=group_type, 
					@n_master_gp_id=group_parent
					FROM @SWV_cursor_var7
            WHERE   id = @cur7_i;

                            IF @n_group_type = 'SG'
                                GOTO SWL_Label13;
                            --FETCH NEXT FROM @SWV_cursor_var7 INTO @n_group_id,
                            --    @n_group_type, @n_master_gp_id;
							SET @cur7_i = @cur7_i + 1;
                        END;
                    SWL_Label13:
                    --CLOSE @SWV_cursor_var7;
                    IF ( @n_group_type IS NULL
                         OR @n_group_type = ''
       )
                        OR @n_group_type <> 'SG'
                        GOTO SWL_Label12;
	
                    SELECT  @n_ssn = member_ssn ,
                            @n_last_name = last_name ,
                         @n_first_name = first_name ,
                            @n_middle_init = middle_init ,
                            @n_alt_id = alt_id ,
                            @n_member_code = member_code ,
                            @n_date_of_birth = date_of_birth ,
                            @n_student_flag = student_flag ,
                            @n_disable_flag = disable_flag
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_id = @n_member_id;
                    
                    SELECT  @n_sub_ssn = member_ssn ,
                            @n_sub_alt_id = alt_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_id = @n_family_id;
                    
                    SELECT  @n_addr1 = addr1 ,
                            @n_addr2 = addr2 ,
                            @n_city = city ,
                            @n_state = state ,
                            @n_zip = zip
                    FROM    dbo.address (NOLOCK)
                    WHERE   subsys_code = 'MB'
                            AND sys_rec_id = @n_family_id
                            AND addr_type = 'L';
                   
                    SELECT DISTINCT
                            @sg_sub_sir_id = dls_sir_id
                    FROM    dbo.dls_sg_member (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND ( dls_status IS NOT NULL
                                  AND dls_status <> ''
                                )
                            AND dls_member_id = @n_family_id;
                    
                    SET @n_mbgrpl_id = NULL;
                    SET @n_fc_id = NULL;

					DECLARE @SWV_cursor_var8 TABLE
                        (
                         id INT IDENTITY ,
						  mb_gr_pl_id INT, 
						  plan_id INT, 
						  eff_gr_pl DATE, 
						  cobra_flag CHAR,
		                  facility_id INT, 
		                  eff_date DATE, 
		                  rate_code CHAR(2), 
		                  eff_rt_date DATE
                        );
                          INSERT  INTO @SWV_cursor_var8
                                ( 
								mb_gr_pl_id, plan_id, eff_gr_pl, cobra_flag,
		facility_id, eff_date, rate_code, eff_rt_date
                                )
								SELECT a.mb_gr_pl_id, a.plan_id, a.eff_gr_pl, a.cobra_flag,
		b.facility_id, b.eff_date, c.rate_code, c.eff_rt_date
	
         FROM dbo.rlmbgrpl a (NOLOCK), 
		 dbo.rlplfc b (NOLOCK), 
		 dbo.rlmbrt c (NOLOCK)
         WHERE a.member_id = @n_family_id
         AND a.group_id = @n_group_id
         AND a.exp_gr_pl IS NULL
         AND b.member_id = @n_member_id
         AND b.mb_gr_pl_id = a.mb_gr_pl_id
         AND b.exp_date IS NULL
         AND c.mb_gr_pl_id = a.mb_gr_pl_id
         AND c.exp_rt_date IS NULL;

	  DECLARE @cur8_cnt INT ,
                            @cur8_i INT;

                        SET @cur8_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur8_cnt = COUNT(1)
                        FROM  @SWV_cursor_var8;

					/*
                    SET @SWV_cursor_var8 = CURSOR  FOR SELECT a.mb_gr_pl_id, a.plan_id, a.eff_gr_pl, a.cobra_flag,
		b.facility_id, b.eff_date, c.rate_code, c.eff_rt_date
	
         FROM dbo.rlmbgrpl a (NOLOCK), 
		 dbo.rlplfc b (NOLOCK), 
		 dbo.rlmbrt c (NOLOCK)
         WHERE a.member_id = @n_family_id
         AND a.group_id = @n_group_id
         AND a.exp_gr_pl IS NULL
         AND b.member_id = @n_member_id
         AND b.mb_gr_pl_id = a.mb_gr_pl_id
         AND b.exp_date IS NULL
         AND c.mb_gr_pl_id = a.mb_gr_pl_id
         AND c.exp_rt_date IS NULL;
                    OPEN @SWV_cursor_var8;
                    FETCH NEXT FROM @SWV_cursor_var8 INTO @n_mbgrpl_id,
                        @n_plan_id, @n_mbgrpl_eff, @n_cobra_flag, @n_fc_id,
    @n_plfc_eff, @n_rate_code, @n_mbrt_eff;
    WHILE @@FETCH_STATUS = 0
					*/

                        WHILE ( @cur8_i <= @cur8_cnt )
            BEGIN
			SELECT  @n_mbgrpl_id=mb_gr_pl_id,
                                                @n_plan_id=plan_id, @n_mbgrpl_eff=eff_gr_pl,
                                                @n_cobra_flag=cobra_flag, @n_fc_id=facility_id,
                                                @n_plfc_eff=eff_date, @n_rate_code=rate_code,
                                                @n_mbrt_eff=eff_rt_date
					FROM @SWV_cursor_var8
            WHERE   id = @cur8_i;

                            IF @n_mbgrpl_id IS NULL
                                OR @n_mbgrpl_eff IS NULL
                                OR @n_plfc_eff IS NULL
                                OR @n_mbrt_eff IS NULL
                                GOTO SWL_Label14;
		
                            IF @n_plfc_eff > @n_term_missing
                                SET @n_term_date = @n_plfc_eff;
                            ELSE
                                SET @n_term_date = @n_term_missing;
		
                            SET @n_msg_alt = NULL;
                            SET @n_plan_name = NULL;
                            SET @n_fc_alt = NULL;
                            SELECT  @n_msg_alt = alt_id
                            FROM    dbo.[group] (NOLOCK)
                            WHERE   group_id = @n_group_id;
                            
                            SELECT  @n_plan_name = plan_dsp_name
                            FROM    dbo.[plan] (NOLOCK)
                            WHERE   plan_id = @n_plan_id;
                            
                            SELECT  @n_fc_alt = alt_id
                            FROM    dbo.facility (NOLOCK)
                            WHERE   fc_id = @n_fc_id;
                           
                            BEGIN
                                INSERT  INTO dbo.dls_sg_member
                                        ( dls_sub_sir_id ,
                                          dls_batch_id ,
                                          member_flag ,
                                          alt_id ,
                                          ssn ,
           sub_ssn ,
                                          sub_alt_id ,
                                          member_code ,
                                          last_name ,
                                          first_name ,
                                          middle_init ,
                                          date_of_birth ,
                                          student_flag ,
                                          disable_flag ,
                                          cobra_flag ,
                                          msg_group_id ,
                                          plan_id ,
                                          facility_id ,
                                          rate_code ,
                                          mb_gppl_eff_date ,
                                          mb_fc_eff_date ,
                                          mb_term_date ,
                                          address1 ,
                                          address2 ,
                                          city ,
                                          state ,
                   zip ,
                                          dls_member_id ,
                                          dls_subscriber_id ,
                                          dls_msg_id ,
                                          dls_group_id ,
                                          dls_plan_id ,
                                          dls_facility_id ,
                                          dls_action_code ,
                                          dls_status ,
    dls_source
                                        )
                                VALUES  ( @sg_sub_sir_id ,
                                          @a_batch_id ,
                                          '09' ,
                                          @n_alt_id ,
                                          @n_ssn ,
                                          @n_sub_ssn ,
                                          @n_sub_alt_id ,
                                          @n_member_code ,
                                          @n_last_name ,
                                          @n_first_name ,
                                          @n_middle_init ,
                                          CAST(@n_date_of_birth AS CHAR(10)) ,
                                          @n_student_flag ,
                                          @n_disable_flag ,
                                          @n_cobra_flag ,
                                          @n_master_gp_id ,
                                          @n_plan_id ,
                                          @n_fc_id ,
                                          @n_rate_code ,
                                          CAST(@n_mbgrpl_eff AS CHAR(10)) ,
                                          CAST(@n_plfc_eff AS CHAR(10)) ,
                                          CAST(@n_term_date AS CHAR(10)) ,
                                          @n_addr1 ,
                                          @n_addr2 ,
                                          @n_city ,
                                          @n_state ,
                                          @n_zip ,
                                          @n_member_id ,
                                          @n_family_id ,
                                          @n_master_gp_id ,
                                          @n_group_id ,
                                          @n_plan_id ,
                                          @n_fc_id ,
                                          'MT' ,
                                          'P' ,
                                          'A'
                                       );
		
                                
                                EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                    @new_dls_sir_id, 'MT', @n_term_date;
                            END;

							SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                            
                            SET @n_process_count = @n_process_count + 1;
                            
                            
        SET @n_succ_count = @n_succ_count + 1;

		UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                            
                            SET @n_sir_count = @n_sir_count + 1;
                            IF @n_sir_count >= @n_to_commit
                                BEGIN
                                   
                                    SET @n_sir_count = 0;
                                END;
		
                            SET @n_mbgrpl_id = NULL;
                            SET @n_fc_id = NULL;
                           --FETCH NEXT FROM @SWV_cursor_var8 INTO @n_mbgrpl_id,
                            --    @n_plan_id, @n_mbgrpl_eff, @n_cobra_flag,
                            --    @n_fc_id, @n_plfc_eff, @n_rate_code,
                            --    @n_mbrt_eff;
							SET @cur8_i = @cur8_i + 1;

                        END;
                    SWL_Label14:
                    --CLOSE @SWV_cursor_var8;
                    SWL_Label12:
                    --FETCH NEXT FROM @SWV_cursor_var6 INTO @n_member_id,
                    --    @n_family_id;
					SET @cur6_i = @cur6_i + 1;
                END;
            --CLOSE @SWV_cursor_var6;
           
  SET @n_in_transaction = 'N';


--trace off;

            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            IF @n_in_transaction = 'Y'
                BEGIN
               
                    SET @n_in_transaction = 'N';
                END;
	
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;




--set debug file to "/tmp/dlp_sg_missing.trc";
--trace on;
--set explain on;

    END;