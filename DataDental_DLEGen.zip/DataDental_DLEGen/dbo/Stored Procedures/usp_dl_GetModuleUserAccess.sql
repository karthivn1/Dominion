﻿
CREATE PROC [dbo].[usp_dl_GetModuleUserAccess]
@OptType VARCHAR(3),
@UserName varchar(15)
AS
BEGIN
SET NOCOUNT ON;
	CREATE TABLE #TmpAccessTable (sysId int,accessType varchar(10))
	DECLARE @UserId INT
	SELECT @UserId=usersl_id FROM user_tbl WHERE user_id=@UserName
	INSERT INTO #TmpAccessTable
	SELECT module_id,sys_access_type FROM dl_module(NOLOCK)
			INNER JOIN (SELECT  DISTINCT b.sys_access_type ,b.sys_id,b.sys_opt_type
		FROM stc_user_access(NOLOCK) a, stc_sys_opt(NOLOCK) b
		WHERE b.sys_opt_type = @OptType AND
			a.sys_opt_id = b.sys_opt_id AND
			(a.usersl_id IN (SELECT group_id FROM stc_user_group WHERE usersl_id = @UserId AND (
									eff_date <= GETDATE() AND 	(exp_date > GETDATE() OR exp_date IS NULL)
								)) 
				OR a.usersl_id = @UserId) 
			AND (a.eff_date <= GETDATE() 
			AND (a.exp_date > GETDATE() OR a.exp_date IS NULL))) 
			As  ModuleAccess ON ModuleAccess.sys_id =module_id

	SELECT	module_id as ModuleId,
            appl_option_id as ApplicationOptionId,
            module_name as ModuleName,
            module_descr as ModuleDescription,
            module_icon as ModuleIcon,
            created_by as CreatedBy,
            created_time as CreatedTime,
			RTRIM(SUBSTRING(ISNULL((SELECT ','+T.accessType 
			FROM #TmpAccessTable T WHERE T.sysId = module_id FOR XML PATH('')),' '),2,10000)) AS UserAccessTypes
			FROM dl_module(NOLOCK);	
	DROP TABLE #TmpAccessTable;
	SET NOCOUNT OFF;
END