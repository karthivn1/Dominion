﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_GetEOPInfo 2,''
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_GetEOPInfo]
	-- Add the parameters for the stored procedure here
@EopID INT,@ErrorMsg NVARCHAR(50) OUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	

IF OBJECT_ID('tempdb..#tempEop') IS NOT NULL
    DROP TABLE #tempEop

IF OBJECT_ID('tempdb..#tempEopMaster') IS NOT NULL
    DROP TABLE #tempEopMaster

IF OBJECT_ID('tempdb..#tempFcPv') IS NOT NULL
    DROP TABLE #tempFcPv

IF OBJECT_ID('tempdb..#FcPvInfo') IS NOT NULL
    DROP TABLE #FcPvInfo

IF OBJECT_ID('tempdb..#tempClaim') IS NOT NULL
    DROP TABLE #tempClaim

SET @ErrorMsg='';

BEGIN TRY
IF EXISTS (select eop_id,eop_master_id,eop_blob_id,created_on,reprinted,reprint_counter,pay_method,  
		check_id,bal_forward,void_switch  From eop_h 
		Where eop_id = @EopID)
		BEGIN
		 select eop_id,eop_master_id,eop_blob_id,created_on,reprinted,reprint_counter,pay_method,  
			check_id,bal_forward,void_switch  
			INTO #tempEop
			From eop_h 
			Where eop_id = @EopID
		 
		END
		ELSE
		BEGIN
		 SET @ErrorMsg='EOPID is required to proccess request';	
	     RAISERROR (@ErrorMsg, 16, 1)  
		END

 IF EXISTS(Select  em.eop_master_id
		--INTO #tempEopMaster
		FROM #tempEop t
		join eop_master em on em.eop_master_id =t.eop_master_id
		Where em.eop_master_id>0)
		BEGIN

		Select  em.eop_master_id, 
				em.entity_type, 
				em.[entity_id], 
				em.entity_addr_id, 
				em.oc_id, 
				em.min_chk_amt 
				INTO #tempEopMaster
				FROM #tempEop t
				join eop_master em on em.eop_master_id =t.eop_master_id
				Where em.eop_master_id>0

		END
		ELSE
		BEGIN
		  SET @ErrorMsg='Unable to get EOP Master from Database for ID:' + CAST(@EopID as nvarchar(20));		
	      RAISERROR (@ErrorMsg, 16, 1) 
		END
		
---Get EOP Adjustments record

DECLARE @BalFwd INT=0;

SELECT @BalFwd=eop_adj.amount
	 FROM #tempEopMaster T 
	 JOIN eop_adj eop_adj ON eop_adj.eop_master_id =T.eop_master_id
	 Where from_eop_id = @EopID
	 AND from_eop_id>0
	 AND eop_adj.[type]=0


---Get Check Vendor
SELECT Distinct t.eop_id AS EopID,
			t.created_on AS CreatedOn,
			@BalFwd AS BalFwd,
			t.pay_method AS PayMethod,
			t.void_switch AS VoidSw,
			RTRIM(b.bank_name) AS BankName,
			RTRIM(b.acct_num) AS BankAcct,
			RTRIM(b.acct_name) AS BankAcctName,
			RTRIM(b.acct_type) AS AcctType,
			RTRIM(b.bank_aba_no) AS BankAbaNo,
			RTRIM(b.chk_header_line1) AS CheckHead1,
			RTRIM(b.chk_header_line2) AS CheckHead2,
			RTRIM(b.chk_micrs) AS CheckMicrs,
			RTRIM(b.chk_macro_str) AS ChkMacroStr,
			c.check_id AS CheckID,
			c.check_nbr AS CheckNum,
			c.amount AS CheckAmount
			From #tempEop t
			JOIN check_vendor c on t.check_id=c.check_id
			Left Join bank_info b on c.bank_info_id=b.bank_info_id
		 


--Get Operating company record if oc_id>0

Select DISTINCT	oc.oc_id AS OcID, 
		RTRIM(oc.name) AS OcName, 
		RTRIM(oc.bill_remit_addr_tp) AS AddrType,
		RTRIM(oc.claim_logo_addr1) AS Addr1,
		RTRIM(oc.claim_logo_addr2) AS Addr2,
		RTRIM(oc.claim_logo_csz) AS CityStateZip,
		RTRIM(oc.claim_logo_phone) AS claim_logo_phone,
		RTRIM(oc.prepay_cap) AS prepay_cap, 
		RTRIM(oc.group_net_switch) AS group_net_switch, 
		oc.clam_withdraw_acct, 
		oc.clam_withdraw_acc2, 
		RTRIM(oc.claim_logo_co_name) AS claim_logo_co_name   
		FROM #tempEopMaster t
		JOIN oper_company oc on oc.oc_id=t.oc_id

--get vendor if VD

IF EXISTS(Select t.eop_master_id from  #tempEopMaster t Where t.entity_type='VD')
BEGIN
Select DISTINCT v.vendor_id AS ID, 
		RTRIM(v.alt_id) AS AltId,
		RTRIM(v.tin) AS Tin, 
		RTRIM(v.name) AS Name,  
		RTRIM(a.addr1) AS Addr1,
		RTRIM(a.addr2) AS Addr2,
		RTRIM(a.city) AS City,
		RTRIM(a.country) AS Country,
		RTRIM(a.[state]) AS [State],
		RTRIM(a.zip) AS Zip,
		1 as isVendor 
		--v.tax_name,  
		--v.tax_id, 
		--v.v_type, 
		--v.sys_rec_id   
		From #tempEopMaster t
		Join vendor v ON v.vendor_id=t.[entity_id]
		Left JOIN [address] a ON a.sys_rec_id=v.sys_rec_id AND a.subsys_code=v.v_type
		AND a.addr_type='L'


END
ELSE IF EXISTS(Select t.eop_master_id from  #tempEopMaster t Where t.entity_type='MB')
BEGIN
Select DISTINCT m.member_id, 
		RTRIM(m.first_name) AS first_name, 
		m.last_name,
		m.middle_init, 
		m.alt_id,  
		m.member_ssn,
		m.source_id, 
	    m.date_of_birth,  
		m.member_code,
		a.addr_type,
		a.addr1,
		a.addr2,
		a.city,
		a.[state],
		a.country,
		a.zip,
		0 as isVendor
		From  #tempEopMaster t
		JOIN member m ON m.member_id=t.[entity_id]
	    Left JOIN [address] a ON a.sys_rec_id=m.member_id AND a.subsys_code='MB'
		AND a.addr_type='L'

END
ELSE
BEGIN
---dummy case

Select DISTINCT m.member_id, 
		m.first_name, 
		m.last_name,
		m.middle_init, 
		m.alt_id,  
		m.member_ssn,
		m.source_id, 
	    m.date_of_birth,  
		m.member_code,
		a.addr_type,
		a.addr1,
		a.addr2,
		a.city,
		a.[state],
		a.country,
		a.zip,
		0 as isVendor
		From  member m
	    Left JOIN [address] a ON a.sys_rec_id=m.member_id AND a.subsys_code='MB'
		AND a.addr_type='L'
		WHERE m.member_id=0

END

--select top 1 * from  member
--select *From #tempEopMaster

-----------------------------------------------------------Get EOPdetail records------------------------------------------------------------

--drop table #tempFcPv
 select c.fc_id, c.prv_id  
		INTO #tempFcPv	
		 from claim_h c 
		 join eop_d e on e.claim_id = c.claim_id  
		 Where e.eop_id = @EopID  
 		 group by  c.fc_id , c.prv_id order by c.fc_id, c.prv_id 

--Select *From #tempFcPv
--drop table #FcPvInfo
Select DISTINCT ISNULL(f.fc_id,0) as FcID,RTRIM(f.fc_name) AS FcName,RTRIM(f.alt_id) as FcAltID,t.prv_id AS PvID,P.first_name AS PvFirstName,P.last_name AS PvLastName,P.alt_id as PvAltID,
			IIF(f.fc_id>0,'FC','PV') AS subsys_code,IIF(f.fc_id>0,f.fc_id,P.pv_id) AS sys_rec_id
			INTO #FcPvInfo
			From #tempFcPv t
			Left JOIN providers P on P.pv_id=t.prv_id
			Left JOIN facility f on f.fc_id=t.fc_id

---Select *From #FcPvInfo

Select DISTINCT F.*,a.addr_type AS PvAddrType,a.addr1 AS PvAdd1,
	a.city AS PvCity,a.[state] AS PvState,a.zip AS PvZip,a.country AS PvCountry
	From #FcPvInfo F
	LEFT JOIN [address] a on a.sys_rec_id=F.sys_rec_id AND a.addr_type='L' 
	Where a.subsys_code=F.subsys_code 
	order by F.FcID, F.PvID 
	

select DISTINCT c.claim_id claim_id,  
		rmg.member_id subscriber,  
		rmg.group_id group_id,  
		rmg.plan_id plan_id,  
		rmg.mb_gr_pl_id mb_gr_pl_id,  
		c.fc_id facility_id,  
		c.prv_id provider_id,  
		rpf.member_id patient  
		INTO #tempClaim
		From claim_h c
		JOIN eop_d e ON c.claim_id=e.claim_id
		JOIN #FcPvInfo F ON F.FcID=c.fc_id AND F.PvID=c.prv_id
		LEFT JOIN rlmbgrpl rmg ON c.mbgrpl_id=rmg.mb_gr_pl_id 
		LEFT JOIN rlplfc rpf on rpf.mb_gr_pl_id=rmg.mb_gr_pl_id AND c.rlplfc_id=rpf.rlplfc_id 
		where e.eop_id = @EopID

--Select *From #tempClaim
--drop table #tempClaim

--Claim info

Select c.claim_status AS ClaimStatus,
		c.claim_id AS ClaimID,
		c.claim_no AS ClaimNum,
		c.alt_id AS ClaimAltID,
		c.document_no AS ClaimDocNum,
		c.svc_date_beg AS ClaimBegin,
		c.svc_date_end AS ClaimEnd,
		c.received_date AS ClaimRecd,
		c.preauth_switch AS PreAuthSW,
		c.use_by AS UseBy,
		c.entered_by AS EntryMethod,
		c.[type] AS ClaimType,
		c.speciality_type AS SpecialtyType,
		b.[status] As ObjectStatus,
		t.facility_id AS FcId,
		t.provider_id AS PvId,
		t.subscriber AS SubId,
		t.patient AS PatId,
		t.plan_id AS PlanId,
		t.group_id AS GroupId
		From #tempClaim t
		join claim_h c on c.claim_id=t.claim_id
		Left Join object_queue b ON b.[object_id]=t.claim_id
	
---get serviceLine info		
 SELECT c.claim_d_id AS ID,  
			 c.claim_id AS ClaimID,  
			 c.svc_beg AS ServiceDate,  
			 c.d_proc_code AS ProcCode,    
			 c.tooth_no AS Tooth,  
			 c.surface AS Surface,  
			 c.quad AS Quad,  
			 c.submitted_amt AS SubmittedAmt,    
			 c.lab_fee AS LabFeeAmt,  
			 c.allowed AS Allowed,  
			 c.patient_resp AS PatientResp,    
			 c.plan_resp AS PlanResp,    
			 c.h_datetime AS UpdDateTime,    
			 c.h_msi AS MSI,  
			 c.h_action AS [Action],    
			 c.h_user AS UpdUser,  
			 c.date_to_pay AS DateToPay,  
			 c.date_processed AS DateProcessed,  
			 c.[status] AS [Status],    
			 c.reversal_switch AS ReversalSwitch,    
			 c.statement_id AS StatementID,    
			 c.cob_amt AS COBAmt,    
			 c.max_allowed AS MaxAllowed,    
			 c.perc_covered AS PercCovered,    
			 c.ded_applied AS DedApplied,    
			 c.rollover_applied AS RollOverApplied,    
			 c.co_ins AS CoInsAmt,    
			 c.provider_resp AS ProviderResp,  
			 c.tpa_inv_number AS TPANum,  
			 c.relates_to AS RelatesTo,   
			 c.relates_to_order AS RelatesToOrder,  
			 c.proc_subst_id AS ProcSubstID,  
			 c.substitute_sw AS SubstituteSW
			 FROM #tempClaim t 
			 JOIN claim_d  c ON t.claim_id=c.claim_id
			 JOIN eop_d e ON  e.claim_id = c.claim_id and e.claim_d_id = c.claim_d_id
			 where e.eop_id = @EopID   
		     order by c.svc_beg


---get Processing code

Select pc.claim_pc_id AS ID,   
		pc.claim_id AS ClaimID,   
		pc.process_code_id AS ProcessCodeID,   
		pc.claim_d_id AS ClaimDID,  
		pc.h_datetime,  
		pc.h_msi AS MSI,   
		pc.h_action AS [Action],   
		pc.h_user,   
		pc.deassigned_at AS DeassignedAt,   
		pc.deassigned_by AS DeassignedBy,   
		cpc.process_code AS ProcessCode,   
		cpc.code_type AS CodeType,   
		RTRIM(cpc.descr) AS Descr
		From #tempClaim t 
		JOIN claim_pc pc ON t.claim_id=pc.claim_id
		JOIN clm_process_codes cpc ON pc.process_code_id = cpc.clm_proc_code_id   
		Where pc.deassigned_at is null and (pc.claim_d_id is null or pc.claim_d_id = 0)  


---get group info

Select g.group_id as GroupID,RTRIM(g.alt_id) as GroupAltID,RTRIM(g.group_name) as GroupName
	From #tempClaim t
	JOIN [group] g on t.group_id=g.group_id


--get Plan info

Select p.plan_id as PlanID,RTRIM(p.plan_dsp_name) as PlanDSPName
	From #tempClaim t
	JOIN [plan] p ON p.plan_id=t.plan_id
	
--Get subscriber info
Select 
	m.member_id as MemberID,
	m.family_id as FamilyID,
	RTRIM(m.alt_id) as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	RTRIM(m.first_name) as FirstName,
	RTRIM(m.middle_init) as MiddleInitial,
	RTRIM(m.last_name) as LastName,
	m.date_of_birth as DOB,
	RTRIM(m.member_ssn) as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	RTRIM(m.action_code) as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	RTRIM(m.h_action) as UserAction,
	RTRIM(m.h_user) as [User],
	m.hire_date as Hire,
	RTRIM(m.new_ssn) as SSN,
	RTRIM(m.source_id) as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
	t.group_id AS GroupID,
	t.plan_id AS PlanID
	From #tempClaim t
	JOIN member m ON m.member_id=t.subscriber


--Get Subscriber Address info
Select
	a.sys_rec_id AS SysRecId,
	RTRIM(a.addr_type) AS [Type],
	RTRIM(a.addr1) AS Addr1,
	RTRIM(a.addr2) AS Addr2,
	RTRIM(a.city) AS City,
	RTRIM(a.country) AS Country,
	RTRIM(a.county) AS County,
	RTRIM(a.[state]) AS [State],
	RTRIM(a.zip) AS Zip,
	RTRIM(p.home_phone) AS Home,
	RTRIM(p.home_ext) AS HomeX,
	RTRIM(p.work_phone) AS Work,
	RTRIM(p.work_ext) AS WorkX,
	RTRIM(p.fax) AS Fax,
	RTRIM(p.email) AS Email
	From #tempClaim t
	JOIN [address] a on t.subscriber=a.sys_rec_id
	Left JOIN mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'



--Get Patient info

Select m.member_id as MemberID,
	m.family_id as FamilyID,
	RTRIM(m.alt_id) as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS  Gender,
	RTRIM(m.first_name) as FirstName,
	RTRIM(m.middle_init) as MiddleInitial,
	RTRIM(m.last_name) as LastName,
	m.date_of_birth as DOB,
	RTRIM(m.member_ssn) as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	RTRIM(m.action_code) as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	RTRIM(m.h_action) as UserAction,
	RTRIM(m.h_user) as [User],
	m.hire_date as Hire,
	RTRIM(m.new_ssn) as SSN,
	RTRIM(m.source_id) as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless
	From #tempClaim t
	JOIN member m on m.member_id=t.patient


Select 
	a.sys_rec_id AS SysRecId,
	RTRIM(a.addr_type) AS [Type],
	RTRIM(a.addr1) AS Addr1,
	RTRIM(a.addr2) AS Addr2,
	RTRIM(a.city) AS City,
	RTRIM(a.country) AS Country,
	RTRIM(a.county) AS County,
	RTRIM(a.[state]) AS [State],
	RTRIM(a.zip) AS Zip,
	RTRIM(p.home_phone) AS Home,
	RTRIM(p.home_ext) AS HomeX,
	RTRIM(p.work_phone) AS Work,
	RTRIM(p.work_ext) AS WorkX,
	RTRIM(p.fax) AS Fax,
	RTRIM(p.email) AS Email
	From #tempClaim t
	JOIN [address] a on t.patient=a.sys_rec_id
	Left Join mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'


END TRY
BEGIN CATCH
--IF ERROR_MESSAGE()<>'User Validation Faild'
 THROW;  
END CATCH
END