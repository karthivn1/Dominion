﻿
CREATE PROCEDURE [dbo].[eclaim_dds_sync1]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(100) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1









000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr CHAR(256);
        DECLARE @s_err_rtn_text CHAR(256);
        DECLARE @ProcessCnt INT;
        DECLARE @UpdateCnt INT;
        DECLARE @DT DATETIME2(0);
        DECLARE @TD DATE;
        DECLARE @eReopenDT DATETIME2(0);
        DECLARE @eReopenDate DATE;
        DECLARE @dReopenDT DATETIME2(0);
        DECLARE @dReopenDate DATE;
        DECLARE @FromDT DATETIME2(0);
        DECLARE @FromDate DATE;
        DECLARE @eClaimID INT;
        DECLARE @ddClaimID INT;
        DECLARE @ddDetID INT;
        DECLARE @eDetID INT;
        DECLARE @eClaimStatus INT;
        DECLARE @ddsClaimStatus CHAR(10);
        DECLARE @ObjService CHAR(20);
        DECLARE @ObjStatus CHAR(20);
        DECLARE @ALTID CHAR(20);
        DECLARE @DocNo CHAR(15);
        DECLARE @STAT INT;
        DECLARE @Wt SMALLINT;
        DECLARE @Lvl SMALLINT;
        DECLARE @ErrCode CHAR(10);
--20101014$$ks - removed status 6 from exclusion
--	       - need to test leave at status 6 if not processed
--	 where dds_claim_id > 0 and status not in (4, 5, 6, 9, 10, 11)
-- 20100325$$ks added to line above new statuses to not process
--	where dds_claim_id > 0 and status not in (9, 10)
        --DECLARE #SWV_cursor_var1 CURSOR;
        --DECLARE #SWV_cursor_var2 CURSOR;
        --DECLARE #SWV_cursor_var3 CURSOR;
        --DECLARE #SWV_cursor_var4 CURSOR;
        --DECLARE #SWV_cursor_var5 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            --set debug file to 'sync.trc';
--trace on;

            SET @DT = GETDATE(); 
            SET @TD = CONVERT(DATE, @DT); 
            SET @FromDT = DATEADD(MONTH, -1, @DT);
            SET @ProcessCnt = 0;
            SET @UpdateCnt = 0;
            
           /*
		    SET #SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_id, dds_claim_id, status
	  
      FROM dbo.eclaim_h (NOLOCK)
      WHERE dds_claim_id > 0 AND status NOT IN(4,5,9,10,11);
            OPEN #SWV_cursor_var1;
            FETCH NEXT FROM #SWV_cursor_var1 INTO @eClaimID, @ddClaimID,
                @eClaimStatus;
            WHILE @@FETCH_STATUS = 0
			*/
			IF OBJECT_ID('tempdb..#SWV_cursor_var1') IS NOT NULL
		DROP TABLE #SWV_cursor_var1

            CREATE TABLE #SWV_cursor_var1
                (
                  id INT IDENTITY ,
                  eclaim_id INT ,
                  dds_claim_id INT ,
                  status INT 
                );

            INSERT  INTO #SWV_cursor_var1
                    ( eclaim_id ,
                      dds_claim_id ,
                      status
					)
                    SELECT  eclaim_id ,
                            dds_claim_id ,
                            status
                    FROM    dbo.eclaim_h (NOLOCK)
                    WHERE   dds_claim_id > 0
                            AND status NOT IN ( 4, 5, 9, 10, 11, 91, 92, 93);

            DECLARE @cur1_cnt INT ,
                @cur1_i INT;

            SET @cur1_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    #SWV_cursor_var1;

            WHILE ( @cur1_i <= @cur1_cnt )
                BEGIN

                    SELECT  @eClaimID = eclaim_id ,
                            @ddClaimID = dds_claim_id ,
                            @eClaimStatus = status
                    FROM    #SWV_cursor_var1
               WHERE   id = @cur1_i;

          SET @ProcessCnt = @ProcessCnt + 1;
                    SELECT  @ddsClaimStatus = claim_status
                    FROM    dbo.claim_h (NOLOCK)
                    WHERE   claim_id = @ddClaimID;
                   
                    IF RTRIM(LTRIM(@ddsClaimStatus)) = 'Processed'
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     status = 9 ,
                                    error_code = '' ,
                                    h_user = 'DDSSync' ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
                            SET @UpdateCnt = @UpdateCnt + 1; 
                            
                            GOTO SWL_Label4; 
                        END;
	
                    IF @ddsClaimStatus = 'Denied'
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     status = 10 ,
                                    error_code = '' ,
                                    h_user = 'DDSSync' ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
                            SET @UpdateCnt = @UpdateCnt + 1; 
                            
                            GOTO SWL_Label4; 
                        END;
	
--20101014$$ks - don't process further if eclaim status = 6
                    IF @eClaimStatus = 6
                        GOTO SWL_Label4;
	
                    IF @ddsClaimStatus != 'In Process'
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     status = 91 ,
                                    h_user = 'DDSSync' ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
                            SET @UpdateCnt = @UpdateCnt + 1; 
                            
                            GOTO SWL_Label4; 
                        END;
	
	-- From here all claims have In Process Status
                    SELECT  @ObjService = service ,
                            @ObjStatus = status
                    FROM    dbo.object_queue (NOLOCK)
                    WHERE   object_id = @ddClaimID; 
                   
                    IF ( @ObjService IS NULL
                         OR @ObjService = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     status = 92 ,
                                    h_user = 'DDSSync' ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
                            SET @UpdateCnt = @UpdateCnt + 1; 
                            
                            GOTO SWL_Label4; 
                        END;
	
-- The following statuses mean the claim is still auto adjudicating
                    IF @ObjService = 'TrafficCop'
                        OR @ObjService = 'adjudicator'
                        OR @ObjService = 'validator'
                        OR @ObjService = 'claim_pricer'
                        OR @ObjService = 'ExternalPricer'
                        OR @ObjService = 'claim_payer'
                        OR @ObjService = 'eligibility'
                        OR @ObjService = 'claim_denier'
                        OR @ObjService = 'procsubst'
                        BEGIN
                            
                            GOTO SWL_Label4; 
                        END;
	
                    IF @ObjService != 'claim_review'
                        AND @ObjService != 'claim_entry'
                        AND @ObjService != 'ISError'
BEGIN
							UPDATE  dbo.eclaim_h
                            SET     status = 93 ,
                                    h_user = 'DDSSync' ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
                            SET @UpdateCnt = @UpdateCnt + 1; 
                            
                            GOTO SWL_Label4; 
                        END;
	
-- Check processing code to error code matrix IF not there set to review
                    SET @STAT = 0;
                   /*
				    SET #SWV_cursor_var2 = CURSOR  FOR SELECT m.status_to_assign, m.error_code, m.level, e.weight, c.claim_d_id
		
         FROM dbo.eclaim_matrix m (NOLOCK),
		  dbo.eclaim_dds_matrix e (NOLOCK),
		   dbo.claim_pc c (NOLOCK)
         WHERE e.process_code_id = c.process_code_id
         AND c.claim_id = @ddClaimID
         AND c.deassigned_at IS NULL
         AND e.error_code = m.error_code AND e.void = 0
         ORDER BY weight DESC;
                    OPEN #SWV_cursor_var2;
                    FETCH NEXT FROM #SWV_cursor_var2 INTO @STAT, @ErrCode,
                        @Lvl, @Wt, @ddDetID;
                    WHILE @@FETCH_STATUS = 0
					*/
					IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
					DROP TABLE #SWV_cursor_var2

                    CREATE TABLE #SWV_cursor_var2
                        (
                          id INT IDENTITY ,
                          status_to_assign INT ,
                          error_code CHAR(10) ,
                          level SMALLINT ,
                          weight SMALLINT ,
                          claim_d_id INT
                        );

                    INSERT  INTO #SWV_cursor_var2
                            ( status_to_assign ,
                              error_code ,
                              level ,
                              weight ,
                              claim_d_id
					        )
                            SELECT  m.status_to_assign ,
                                    m.error_code ,
                                    m.level ,
                                    e.weight ,
                                    c.claim_d_id
                            FROM    dbo.eclaim_matrix m ( NOLOCK ) ,
                                    dbo.eclaim_dds_matrix e ( NOLOCK ) ,
                                    dbo.claim_pc c ( NOLOCK )
                            WHERE   e.process_code_id = c.process_code_id
                                    AND c.claim_id = @ddClaimID
                                    AND c.deassigned_at IS NULL
                                    AND e.error_code = m.error_code
                                    AND e.void = 0
                            ORDER BY weight DESC;

                    DECLARE @cur2_cnt INT ,
                        @cur2_i INT;

                    SET @cur2_i = 1;

					--Get the no. of records for the cursor
                    SELECT  @cur2_cnt = COUNT(1)
                    FROM    #SWV_cursor_var2;

                    WHILE ( @cur2_i <= @cur2_cnt )
                        BEGIN

                            SELECT  @STAT = status_to_assign ,
                                    @ErrCode = error_code ,
                                    @Lvl = level ,
                                    @Wt = weight ,
                                    @ddDetID = claim_d_id
                            FROM    #SWV_cursor_var2
                            WHERE   id = @cur2_i;

                            IF @Lvl = 1
                            AND @ddDetID IS NULL
                                BEGIN
                                    SET @Lvl = 0;
                                    SET @ErrCode = 'UnKDDSync1';
                                END;
		
                            IF @Lvl = 1
                                BEGIN
 /*
								    SET #SWV_cursor_var3 = CURSOR  FOR SELECT eclaim_d_id 
               FROM dbo.eclaim_d e (NOLOCK),
			    dbo.claim_d d (NOLOCK)
               WHERE eclaim_id = @eClaimID
               AND d.claim_d_id = @ddDetID
               AND d.svc_beg = e.svc_date
               AND d.d_proc_code = e.d_proc_code
               AND d.tooth_no = e.tooth_no
               AND d.quad = e.quad
               AND d.surface = e.surface;
                                    OPEN #SWV_cursor_var3;
                                    FETCH NEXT FROM #SWV_cursor_var3 INTO @eDetID;
                                    WHILE @@FETCH_STATUS = 0
									*/
									IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
									DROP TABLE #SWV_cursor_var3

                                    CREATE TABLE #SWV_cursor_var3
                                        (
                                          id INT IDENTITY ,
                                          eclaim_d_id INT
                                        );

                                    INSERT  INTO #SWV_cursor_var3
                                            ( eclaim_d_id
					                        )
                                            SELECT  eclaim_d_id
                                            FROM    dbo.eclaim_d e ( NOLOCK ) ,
                                                    dbo.claim_d d ( NOLOCK )
                                            WHERE   eclaim_id = @eClaimID
                                                    AND d.claim_d_id = @ddDetID
                                                    AND d.svc_beg = e.svc_date
                                                    AND d.d_proc_code = e.d_proc_code
                                                    AND d.tooth_no = e.tooth_no
                                                    AND d.quad = e.quad
                                                    AND d.surface = e.surface;

                                    DECLARE @cur3_cnt INT ,
                                        @cur3_i INT;

                                    SET @cur3_i = 1;

					--Get the no. of records for the cursor
                                    SELECT  @cur3_cnt = COUNT(1)
                                    FROM    #SWV_cursor_var3;

                                    WHILE ( @cur3_i <= @cur3_cnt )
                                        BEGIN
                                            SELECT  @eDetID = eclaim_d_id
                                            FROM    #SWV_cursor_var3
                                            WHERE   id = @cur3_i;
                                            GOTO SWL_Label6;
                                            --FETCH NEXT FROM #SWV_cursor_var3 INTO @eDetID;
                                            SET @cur3_i = @cur3_i + 1;
                                        END;
                                    SWL_Label6:
                                   -- CLOSE #SWV_cursor_var3;
                                    IF @eDetID = 0
                                        BEGIN
                                            SET @Lvl = 0;
                                            SET @ErrCode = 'UnkDDSync1';
                                        END;
                                    ELSE
                                        BEGIN
                                            UPDATE  dbo.eclaim_d
                                            SET     error_code = @ErrCode ,
                                                    h_user = 'DDSSync1' ,
                                                    h_datetime = GETDATE()
											 WHERE   eclaim_d_id = @eDetID;
                                            SET @ErrCode = 'PART'; 
                                        END;
                                END;
		
                            UPDATE  dbo.eclaim_h
							SET     status = @STAT ,
							error_code = @ErrCode ,
                                    h_user = 'DDSSync' ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
               SET @UpdateCnt = @UpdateCnt + 1; 
                             
                            GOTO SWL_Label5;
                            /*
							FETCH NEXT FROM #SWV_cursor_var2 INTO @STAT,
                                @ErrCode, @Lvl, @Wt, @ddDetID;
								*/
                            SET @cur2_i = @cur2_i + 1;
                        END;
                    SWL_Label5:
                    --CLOSE #SWV_cursor_var2;
                    IF @STAT = 0 -- No entry in above matrix
	-- 5-20-2004 ksavage Added new statuses
                        BEGIN
                            IF @ObjService = 'claim_entry'
                                IF @ObjStatus = 'PAWaiting'
                                    UPDATE  dbo.eclaim_h
                                    SET     status = 7 ,
                                            h_user = 'DDSSync' ,
                                            h_datetime = GETDATE()
                                    WHERE   eclaim_id = @eClaimID;
                                ELSE
                                    UPDATE  dbo.eclaim_h
                                    SET     status = 8 ,
                                            h_user = 'DDSSync' ,
                                            h_datetime = GETDATE()
                                    WHERE   eclaim_id = @eClaimID;
			
                            ELSE
                                UPDATE  dbo.eclaim_h
                                SET     status = 8 ,
                                        h_user = 'DDSSync' ,
                                        h_datetime = GETDATE()
                                WHERE   eclaim_id = @eClaimID;
		
                            SET @UpdateCnt = @UpdateCnt + 1; 
                            
                        END;
	
                    
                    SWL_Label4:
                   /*
				    FETCH NEXT FROM #SWV_cursor_var1 INTO @eClaimID,
                        @ddClaimID, @eClaimStatus;
						*/
                    SET @cur1_i = @cur1_i + 1;
                END;
           -- CLOSE #SWV_cursor_var1;
            
--set debug file to 'sync.trc';
--trace on;
            
            /*
			SET #SWV_cursor_var4 = CURSOR  FOR SELECT e.eclaim_id, e.dds_claim_id, e.reopen_date, e.reopen_datetime
	  
      FROM dbo.eclaim_h e (NOLOCK)
      WHERE dds_claim_id > 0 
	 --and status not in (4, 5, 9, 10, 11) -- removed as per Jenn 201203015$$ks
      AND (e.h_datetime > @FromDT)
      AND (e.reopen_datetime IS NOT NULL  AND e.reopen_date IS NOT NULL);
            OPEN #SWV_cursor_var4;
            FETCH NEXT FROM #SWV_cursor_var4 INTO @eClaimID, @ddClaimID,
                @eReopenDate, @eReopenDT;
            WHILE @@FETCH_STATUS = 0
			*/
			IF OBJECT_ID('tempdb..#SWV_cursor_var4') IS NOT NULL
				DROP TABLE #SWV_cursor_var4

            CREATE TABLE #SWV_cursor_var4
                (
                  id INT IDENTITY ,
                  eclaim_id INT ,
                  dds_claim_id INT ,
                  reopen_date DATE ,
                  reopen_datetime DATETIME
                );

            INSERT  INTO #SWV_cursor_var4
                    ( eclaim_id ,
                      dds_claim_id ,
                      reopen_date ,
                      reopen_datetime
					)
                    SELECT  e.eclaim_id ,
                            e.dds_claim_id ,
                     e.reopen_date ,
                            e.reopen_datetime
                    FROM    dbo.eclaim_h e ( NOLOCK )
                    WHERE   dds_claim_id > 0 
	 --and status not in (4, 5, 9, 10, 11) -- removed as per Jenn 201203015$$ks
                            AND ( e.h_datetime > @FromDT )
                            AND ( e.reopen_datetime IS NOT NULL
                                  AND e.reopen_date IS NOT NULL
                                );

            DECLARE @cur4_cnt INT ,
                @cur4_i INT;

            SET @cur4_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur4_cnt = COUNT(1)
            FROM    #SWV_cursor_var4;

            WHILE ( @cur4_i <= @cur4_cnt )
                BEGIN

                    SELECT  @eClaimID = eclaim_id ,
                            @ddClaimID = dds_claim_id ,
                            @eReopenDate = reopen_date ,
                            @eReopenDT = reopen_datetime
                    FROM    #SWV_cursor_var4
                    WHERE   id = @cur4_i;

                    IF EXISTS ( SELECT  claim_id
                                FROM    dbo.claim_h (NOLOCK)
                                WHERE   claim_id = @ddClaimID
                                        AND ( reopen_date IS NULL
                                              OR ( reopen_date IS NOT NULL
                                                   AND reopen_date != @eReopenDate
                                                 )
                                            ) )
                        BEGIN
                            SELECT  @dReopenDate = reopen_date ,
                                    @dReopenDT = reopen_datetime
                            FROM    dbo.claim_h (NOLOCK)
                            WHERE   claim_id = @ddClaimID;
                            
                            IF ( @dReopenDT IS NULL
                                 OR @dReopenDT < @eReopenDT
                               )
                                UPDATE  dbo.claim_h
                                SET     reopen_date = @eReopenDate ,
                                        reopen_datetime = GETDATE() ,
                                        h_datetime = GETDATE() ,
                                        h_user = 'SyncROPN'
                                WHERE   claim_id = @ddClaimID;
		
                            IF ( @eReopenDT < @dReopenDT )
                                UPDATE  dbo.eclaim_h
                                SET     reopen_date = @dReopenDate ,
                                        reopen_datetime = GETDATE() ,
                                        h_datetime = GETDATE() ,
                                        h_user = 'SyncROPN'
                                WHERE   eclaim_id = @eClaimID;
                        END;
	
                    
                    
                   /*
				    FETCH NEXT FROM #SWV_cursor_var4 INTO @eClaimID,
                        @ddClaimID, @eReopenDate, @eReopenDT;
						*/
                    SET @cur4_i = @cur4_i + 1;
                END;
            --CLOSE #SWV_cursor_var4;
            
            
      /*
	        SET #SWV_cursor_var5 = CURSOR  FOR SELECT d.claim_id, d.reopen_date, d.reopen_datetime
	  
      FROM dbo.claim_h d (NOLOCK)
      WHERE (d.h_datetime > @FromDT)
      AND (d.reopen_datetime IS NOT NULL AND d.reopen_date IS NOT NULL);
            OPEN #SWV_cursor_var5;
            FETCH NEXT FROM #SWV_cursor_var5 INTO @ddClaimID, @dReopenDate,
                @dReopenDT;
            WHILE @@FETCH_STATUS = 0
			*/
			IF OBJECT_ID('tempdb..#SWV_cursor_var5') IS NOT NULL
			DROP TABLE #SWV_cursor_var5

            CREATE TABLE #SWV_cursor_var5
                (
                  id INT IDENTITY ,
              claim_id INT ,
                  reopen_date DATE ,
                  reopen_datetime DATETIME
                );

            INSERT  INTO #SWV_cursor_var5
                    ( claim_id ,
                      reopen_date ,
                      reopen_datetime
					)
                    SELECT  d.claim_id ,
             d.reopen_date ,
      d.reopen_datetime
FROM    dbo.claim_h d ( NOLOCK )
                    WHERE   ( d.h_datetime > @FromDT )
                            AND ( d.reopen_datetime IS NOT NULL
                                  AND d.reopen_date IS NOT NULL
                                );

            DECLARE @cur5_cnt INT ,
                @cur5_i INT;

            SET @cur5_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur5_cnt = COUNT(1)
            FROM    #SWV_cursor_var5;

            WHILE ( @cur5_i <= @cur5_cnt )
                BEGIN

                    SELECT  @ddClaimID = claim_id ,
                            @dReopenDate = reopen_date ,
                            @dReopenDT = reopen_datetime
                    FROM    #SWV_cursor_var5
                    WHERE   id = @cur5_i;

                    IF EXISTS ( SELECT  dds_claim_id
                                FROM    dbo.eclaim_h (NOLOCK)
                                WHERE   dds_claim_id = @ddClaimID
                                        AND ( reopen_date IS NULL
                                              OR ( reopen_date IS NOT NULL
                                                   AND reopen_date != @dReopenDate
                                                 )
                                            ) )
                        BEGIN
                            SELECT  @eClaimID = eclaim_id ,
                                    @eReopenDate = reopen_date ,
                                    @eReopenDT = reopen_datetime
                            FROM    dbo.eclaim_h (NOLOCK)
                            WHERE   dds_claim_id = @ddClaimID;
                           
                            IF ( @eReopenDT IS NULL
                                 OR @eReopenDT < @dReopenDT
                               )
                                UPDATE  dbo.eclaim_h
                                SET     reopen_date = @dReopenDate ,
                                        reopen_datetime = GETDATE() ,
                                        h_datetime = GETDATE() ,
                                        h_user = 'SyncROPN'
                                WHERE   eclaim_id = @eClaimID;
		
                            IF ( @dReopenDT < @eReopenDT )
                                UPDATE  dbo.claim_h
                                SET     reopen_date = @eReopenDate ,
                                        reopen_datetime = GETDATE() ,
                                        h_datetime = GETDATE() ,
                                        h_user = 'SyncROPN'
                                WHERE   claim_id = @ddClaimID;
                        END;
	
                    
                    
                    /*
					FETCH NEXT FROM #SWV_cursor_var5 INTO @ddClaimID,
                        @dReopenDate, @dReopenDT;
						*/
                    SET @cur5_i = @cur5_i + 1;
                END;
           -- CLOSE #SWV_cursor_var5;
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('eClaims Sync''d with DataDental; Processed: ',
                                         @ProcessCnt, ' Updated: ', @UpdateCnt);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_isam_error, @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


----------------------------------------------------------------------
    END;