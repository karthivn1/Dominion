﻿
CREATE PROC [dbo].[usp_dl_GetBatchUserAccess]
@ConfigId INT,
@OptType VARCHAR(3),
@UserName VARCHAR(15)
AS
BEGIN
SET NOCOUNT ON;
	CREATE TABLE #TmpAccessTable (sysId int,accessType varchar(10))
	DECLARE @UserId INT
	SELECT @UserId=usersl_id FROM user_tbl WHERE user_id=@UserName
	INSERT INTO #TmpAccessTable
	SELECT config_bat_id,sys_access_type FROM dl_config_bat(NOLOCK) 
			INNER JOIN (SELECT  DISTINCT b.sys_access_type ,b.sys_id,b.sys_opt_type
		FROM stc_user_access(NOLOCK) a, stc_sys_opt(NOLOCK) b
		WHERE b.sys_opt_type = @OptType AND
			a.sys_opt_id = b.sys_opt_id AND
			(a.usersl_id IN (SELECT group_id FROM stc_user_group WHERE usersl_id = @UserId AND (
									eff_date <= GETDATE() AND 	(exp_date > GETDATE() OR exp_date IS NULL)
								)) 
			OR a.usersl_id = @UserId) 
			AND (a.eff_date <= GETDATE() 
			AND (a.exp_date > GETDATE() OR a.exp_date IS NULL)))
			As  BatchAccess ON BatchAccess.sys_id =config_bat_id
			
			SELECT cb.config_bat_id AS BatchId,
					cb.config_id AS ConfigurationId,
					cg.config_name AS ConfigurationName,
					cd.descr+'('+cb.config_bat_status+')' AS StatusDescription,
					cb.config_bat_status AS   Status,                                                          
					cb.created_by AS CreatedBy,
					cb.created_time AS CreatedTime,
					RTRIM(SUBSTRING(ISNULL((SELECT ','+T.accessType 
			FROM #TmpAccessTable T Where T.sysId = cb.config_bat_id FOR XML PATH('')),''),2,1000000)) AS UserAccessTypes
					FROM dl_config_bat(NOLOCK) cb
					INNER JOIN dl_config cg on cb.config_id=cg.config_id
					LEFT OUTER JOIN stc_common_detail cd ON cb.config_bat_status=cd.code AND cd.common_header_id=2
					WHERE cb.config_id=@ConfigId
					ORDER BY 1 DESC
			DROP TABLE #TmpAccessTable	
			SET NOCOUNT OFF;
END