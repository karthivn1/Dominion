﻿CREATE PROCEDURE [dbo].[dlp_lb_gen_bnum]
	@p_batch_id INT,
    @SWP_Ret_Value CHAR(18) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_lb_gen_bnum
--
--            Created:     11/25/98 
--            Author:   Gene Albers
--
-- Purpose:  This procedure supports the lockbox update processing of DataLoad
--           for the DataDental Alloation module, a product of STC.
--           This SP generates a unique batch number used as an identifier
--           when data is loaded into the Allocation tables.
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--	 07/19/2000	KSavage		Change program to use next_batch_no2 - 
--									Removed logic that drops and recreates
--									table daily!
--
-------------------------------------------------------------------------------
   
--		return sql_err ;
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @Str CHAR(100);
        DECLARE @jan1 DATE;
        DECLARE @BDate DATE;
        DECLARE @itargetdate INT;
        DECLARE @ijan1 INT;
        DECLARE @juldays INT;
        DECLARE @i INT;
        DECLARE @s_user_str CHAR(25);
        DECLARE @s_user_sub CHAR(8);
        DECLARE @yearstr CHAR(4);
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr CHAR(100);

        SET NOCOUNT ON;
        BEGIN TRY
            SET @Str = CONVERT(DATE, GETDATE());
            IF SUBSTRING(@Str, 3, 1) = '/'
                BEGIN
                    SET @yearstr = SUBSTRING(@Str, 7, 4);
                    SET @Str = STUFF(@Str, 1, 1, '0');
                    SET @Str = STUFF(@Str, 2, 1, '1');
                    SET @Str = STUFF(@Str, 4, 1, '0');
                    SET @Str = STUFF(@Str, 5, 1, '1');
                    SET @jan1 = @Str;
                    SET @ijan1 = DATEDIFF(DAY, '1899-12-31', @jan1);
                    SET @itargetdate = DATEDIFF(DAY, '1899-12-31',
                                                CONVERT(DATE, GETDATE()));
                    SET @juldays = ( @itargetdate - @ijan1 ) + 1;
                END;
            ELSE
                IF SUBSTRING(@Str, 5, 1) = '-'
                    BEGIN
                        SET @yearstr = SUBSTRING(@Str, 1, 4);
                        SET @Str = STUFF(@Str, 6, 1, '0');
                        SET @Str = STUFF(@Str, 7, 1, '1');
                        SET @Str = STUFF(@Str, 9, 1, '0');
                        SET @Str = STUFF(@Str, 10, 1, '1');
                        SET @jan1 = @Str;
                        SET @ijan1 = DATEDIFF(DAY, '1899-12-31', @jan1);
                        SET @itargetdate = DATEDIFF(DAY, '1899-12-31',
                                                    CONVERT(DATE, GETDATE()));
                        SET @juldays = ( @itargetdate - @ijan1 ) + 1;
                    END;
            SET @BDate = NULL;
   
   --  Get batch number
            SELECT  @BDate = MAX(batch_date)
            FROM    dbo.next_batch_no2 (NOLOCK);
            
            IF @BDate IS NULL
                OR @BDate <> CONVERT(DATE, GETDATE())
                BEGIN
                    DELETE  FROM dbo.next_batch_no2
                    WHERE   batch_date <> CONVERT(DATE, GETDATE()); 

				SET IDENTITY_INSERT dds_prod.dbo.next_batch_no2 ON 
				INSERT INTO next_batch_no2 (batch_serial,batch_date,batch_no) VALUES(1,CONVERT(DATE, GETDATE()), 0);
				SET IDENTITY_INSERT dds_prod.dbo.next_batch_no2 OFF

                END;
   
            UPDATE  dbo.next_batch_no2
            SET     batch_no = batch_no + 1
            WHERE   batch_serial = 1;

            SELECT  @i = batch_no
            FROM    dbo.next_batch_no2 (NOLOCK)
            WHERE   batch_serial = 1; 

			
			            
            --SET @s_user_str = ORIGINAL_LOGIN();
			SELECT @s_user_str = LEFT(created_by,8) FROM dl_config_bat(NOLOCK) WHERE config_bat_id = @p_batch_id;
			SET @s_user_sub = SUBSTRING(@s_user_str, 1, 8);
            SET @Str = CONCAT(@yearstr, @juldays, @s_user_sub, @i);

		
       INSERT INTO al_batch_ctrl (batch_no,timestamp) values (@Str, GETDATE());
            SET @SWP_Ret_Value = @Str;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


/*   ON EXCEPTION IN (-206)
 CREATE TABLE next_batch_no (
      batch_date  DATE,
      batch_serial SERIAL
      );
   END EXCEPTION WITH RESUME;
*/
   -- Calc julian date
    END;