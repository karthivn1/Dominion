﻿CREATE PROCEDURE [dbo].[usp_ecl_UpdateInsertDentalErrorMatrix]
			@MatrixId INT,
			@ErrorCode CHAR(10), 
			@ProcessCodeId INT,
			@Void SMALLINT,
			@Weight SMALLINT,
			@User varchar(20)
AS
BEGIN
	
DECLARE @ERR_MSG AS NVARCHAR(4000),
		@ERR_SEV AS SMALLINT,
		@ERR_STA AS SMALLINT
		--UPDATE DATA DENTAL ERROR 
	IF(@MatrixId!=0)
	BEGIN
		BEGIN TRY
			BEGIN TRAN
				IF NOT EXISTS(SELECT * FROM eclaim_dds_matrix WHERE matrix_id=@MatrixId AND process_code_id=@ProcessCodeId)
				BEGIN
					 IF EXISTS(SELECT * FROM eclaim_dds_matrix WHERE process_code_id=@ProcessCodeId)
					 RAISERROR ('This processing code already had been established in this matrix.', 16, 1 );
				END
				UPDATE eclaim_dds_matrix
				SET error_code			= UPPER(@ErrorCode),
					process_code_id		= @ProcessCodeId,
					void				= @Void,
					weight				= @Weight,
					h_user				= @User,
					h_datetime			= GETDATE()
				WHERE matrix_id=@MatrixId
			COMMIT TRAN
		END TRY
		BEGIN CATCH
			 ROLLBACK
			 SELECT  @ERR_MSG = ERROR_MESSAGE(),
					 @ERR_SEV =ERROR_SEVERITY(),
					 @ERR_STA = ERROR_STATE()
			 RAISERROR (@ERR_MSG, @ERR_SEV, @ERR_STA);
		END CATCH
	END
	--ADD NEW DATA DENTAL ERROR  
	ELSE IF(@MatrixId=0)
	BEGIN TRY
		BEGIN TRAN 
		IF EXISTS(SELECT * FROM eclaim_dds_matrix WHERE process_code_id=@ProcessCodeId)
				 RAISERROR ('This processing code already had been established in this matrix.', 16, 1 );
		SET @Weight=1;
			INSERT INTO eclaim_dds_matrix  (error_code,
											process_code_id,
											void,
											weight,
											h_user)
									VALUES( UPPER(@ErrorCode),
											@ProcessCodeId,
											@Void,
											@Weight,
											@User)
		COMMIT TRAN
	END TRY
	BEGIN CATCH
		 ROLLBACK
		 SELECT  @ERR_MSG = ERROR_MESSAGE(),
				 @ERR_SEV =ERROR_SEVERITY(),
				 @ERR_STA = ERROR_STATE()
		 RAISERROR (@ERR_MSG, @ERR_SEV, @ERR_STA);
	END CATCH
  END