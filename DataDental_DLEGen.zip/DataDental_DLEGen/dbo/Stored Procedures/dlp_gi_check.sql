﻿CREATE PROCEDURE [dbo].[dlp_gi_check]
@a_tl_sir_id INT ,
@a_has_address CHAR(1) ,
@SWP_Ret_Value INT = NULL OUTPUT ,
@SWP_Ret_Value1 CHAR(2) = NULL OUTPUT
 
-- DATE: 04/30/97
-- DOB and paperless Switch: sets G1
-- Address: G2
-- Phone: G4
-- DOB + Address: G3
-- DOB + Phone: G5
-- Address + Phone: G6
-- DOB + Address + Phone: G7
--
-- add codes to correctly handle null zip
AS
BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:14:14 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1





　
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
DECLARE @n_fatal INT;
DECLARE @n_error_code INT;
DECLARE @n_return_code INT;
DECLARE @n_error_desc CHAR(64);
DECLARE @n_last_name CHAR(15);
DECLARE @n_date_of_birth DATE;
DECLARE @n_action_code CHAR(2);
DECLARE @n_address1 CHAR(30);
DECLARE @n_address2 CHAR(30);
DECLARE @n_city CHAR(30);
DECLARE @n_county CHAR(20);
DECLARE @n_state CHAR(2);
DECLARE @n_zip CHAR(10);
DECLARE @n_home_phone CHAR(10);
DECLARE @n_home_ext CHAR(4);
DECLARE @n_work_phone CHAR(10);
DECLARE @n_work_ext CHAR(4);
DECLARE @n_email CHAR(100);
DECLARE @n_paperless CHAR(1);
DECLARE @n_address_id INT;
DECLARE @n_g1 INT;
DECLARE @n_g2 INT;
DECLARE @n_g4 INT;
DECLARE @n_count INT;
DECLARE @t_subscriber CHAR(2);
DECLARE @t_member_id INT;
DECLARE @t_last_name CHAR(15);
DECLARE @t_date_of_birth DATE;
DECLARE @t_paperless CHAR(1);
DECLARE @t_email CHAR(100);
DECLARE @t_student_flag CHAR(1);
DECLARE @t_disable_flag CHAR(1);
DECLARE @t_cobra_flag CHAR(1);
DECLARE @t_action_code CHAR(2);
DECLARE @t_address1 CHAR(30);
DECLARE @t_address2 CHAR(30);
DECLARE @t_city CHAR(30);
DECLARE @t_state CHAR(2);
DECLARE @t_zip CHAR(5);
DECLARE @t_zipx CHAR(4);
DECLARE @t_home_phone CHAR(10);
DECLARE @t_home_ext CHAR(4);
DECLARE @t_work_phone CHAR(10);
DECLARE @t_work_ext CHAR(4);
DECLARE @t_status CHAR(1);
DECLARE @a_batch_id INT
--DECLARE @SWV_cursor_var1 CURSOR;
DECLARE @v_Null INT;
SET NOCOUNT ON;
SET @t_subscriber = '' 
SET @t_member_id = 0 
SET @t_last_name = '' 
SET @t_date_of_birth = NULL 
SET @t_paperless = '' 
SET @t_email = '' 
SET @t_student_flag = '' 
SET @t_disable_flag = '' 
SET @t_cobra_flag = '' 
SET @t_action_code = '' 
SET @t_address1 = '' 
SET @t_address2 = '' 
SET @t_city = '' 
SET @t_state = '' 
SET @t_zip = '' 
SET @t_zipx = '' 
SET @t_home_phone = '' 
SET @t_home_ext ='' 
SET @t_work_phone = '' 
SET @t_work_ext = '' 
SET @t_status = '' 
BEGIN TRY

SELECT @a_batch_id = dls_batch_id FROM dbo.dls_elig(NOLOCK) WHERE dls_sir_id = @a_tl_sir_id

SELECT @t_member_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_email = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_email' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_paperless = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_paperless' and  BatchId = @a_batch_id AND Module_Id = 3


SET @n_action_code = 'GI';
IF @t_subscriber != '00'
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = @n_action_code;
RETURN;
END;
SET @n_last_name = NULL; 
-- 20120521$$ks - system limitation requires us to include both DoB and paperless switch on G!
SELECT @n_last_name = last_name ,
@n_date_of_birth = date_of_birth ,
@n_paperless = paperless
FROM dbo.member (NOLOCK)
WHERE member_id = @t_member_id;
IF ( @n_last_name IS NULL
)
BEGIN
RAISERROR('Internal - Null member_id',16,1);
RETURN
END
SET @n_g1 = 0;
SET @n_g2 = 0;
SET @n_g4 = 0;
SET @n_city = NULL; 
SET @n_county = NULL; 
SET @n_state = NULL; 
IF @t_date_of_birth IS NOT NULL
BEGIN
IF @t_date_of_birth != @n_date_of_birth
SET @n_g1 = 1;
END;
IF ( @t_paperless IS NOT NULL
)
AND LEN(@t_paperless) > 0
BEGIN
IF @t_paperless != @n_paperless
SET @n_g1 = 1;
END;
IF @a_has_address = 'Y'
BEGIN
SELECT @n_address_id = address_id ,
@n_address1 = addr1 ,
@n_address2 = addr2 ,
@n_zip = zip
FROM dbo.[address] (NOLOCK)
WHERE subsys_code = 'MB'
AND sys_rec_id = @t_member_id
AND addr_type = 'L';
IF @n_address_id IS NOT NULL
BEGIN
IF @n_g2 = 0
BEGIN
IF ( @t_address1 IS NOT NULL
)
BEGIN
IF @t_address1 != @n_address1
SET @n_g2 = 1;
END;
END;
IF @n_g2 = 0
BEGIN
IF ( @t_address2 IS NOT NULL
)
BEGIN
IF @t_address2 != @n_address2
SET @n_g2 = 1;
END;
ELSE
BEGIN
IF ( @t_address2 IS NOT NULL
)
SET @n_g2 = 1;
END;
END;
IF ( @t_zip IS NOT NULL
)
BEGIN
IF ( @n_zip IS NULL
OR @n_zip = ''
)
OR @t_zip != SUBSTRING(@n_zip, 1, 5)
BEGIN
DECLARE @SWV_cursor_var1 TABLE
(
id INT IDENTITY ,
city char(30), county char(20), state_code char (2)
);
INSERT INTO @SWV_cursor_var1
( city, county, state_code
)
SELECT city, county, state_code
FROM dbo.usa_zip (NOLOCK) WHERE zip_code = @t_zip;
DECLARE @cur1_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur1_cnt = COUNT(1)
FROM @SWV_cursor_var1;
WHILE ( @cur_i <= @cur1_cnt )
SELECT @n_city = city, @n_county = county, @n_state = state_code
FROM @SWV_cursor_var1
WHERE id = @cur_i;
/*
SET @SWV_cursor_var1 = CURSOR FOR SELECT city, county, state_code
FROM dbo.usa_zip (NOLOCK) WHERE zip_code = @t_zip;
OPEN @SWV_cursor_var1;
FETCH NEXT FROM @SWV_cursor_var1 INTO @n_city,
@n_county, @n_state;
WHILE @@FETCH_STATUS = 0
*/
BEGIN
IF @n_city = @t_city
GOTO SWL_Label2;
--FETCH NEXT FROM @SWV_cursor_var1 INTO @n_city,
-- @n_county, @n_state;
SET @cur_i = @cur_i + 1;
END;
SWL_Label2:
--CLOSE @SWV_cursor_var1;
IF ( (@n_city IS NULL
)
)
OR ( (@n_county IS NULL
)
)
OR ( (@n_state IS NULL
)
)
BEGIN
RAISERROR('Address Zip is not recognized by DataDental',16,1);
RETURN
END
SET @n_g2 = 1;
END;
END;
IF @n_g2 = 0
BEGIN
IF ( @t_zipx IS NOT NULL
)
AND @t_zipx != SUBSTRING(@n_zip, 6, 4)
SET @n_g2 = 1;
END;
SELECT @n_count = COUNT(*)
FROM dbo.mbr_phone (NOLOCK)
WHERE address_id = @n_address_id;
IF @n_count > 1
BEGIN
RAISERROR('Multiple member phone records',16,1);
RETURN
END
IF @n_count = 1
BEGIN
SELECT @n_home_phone = home_phone ,
@n_home_ext = home_ext ,
@n_work_phone = work_phone ,
@n_work_ext = work_ext ,
@n_email = email
FROM dbo.mbr_phone (NOLOCK)
WHERE address_id = @n_address_id;
IF @n_g4 = 0
IF ( @n_home_phone IS NULL

)
BEGIN
IF ( @t_home_phone IS NOT NULL
)
SET @n_g4 = 1;
END;
ELSE
BEGIN
IF ( @t_home_phone IS NULL
)
BEGIN
SET @v_Null = 0;
END;
-- LET n_g4 = 1;
ELSE
BEGIN
IF @t_home_phone != @n_home_phone
SET @n_g4 = 1;
ELSE
BEGIN
IF ( ( @t_home_ext IS NOT NULL
)
AND ( @n_home_ext IS NOT NULL
)
)
BEGIN
IF @t_home_ext != @n_home_ext
SET @n_g4 = 1;
END;
END;
END;
END;
IF @n_g4 = 0
IF ( @n_work_phone IS NULL

)
BEGIN
IF ( @t_work_phone IS NOT NULL

)
SET @n_g4 = 1;
END;
ELSE
BEGIN
IF ( @t_work_phone IS NULL

)
BEGIN
SET @v_Null = 0;
END;
-- LET n_g4 = 1;
ELSE
BEGIN
IF @t_work_phone != @n_work_phone
SET @n_g4 = 1;
ELSE
BEGIN
IF ( ( @t_work_ext IS NOT NULL

)
AND ( @n_work_ext IS NOT NULL

)
)
BEGIN
IF @t_work_ext != @n_work_ext
SET @n_g4 = 1;
END;
END;
END;
END;
IF @n_g4 = 0 /* 20120726$$ks - add email logic */
BEGIN
IF ( @t_email IS NOT NULL

)
AND LEN(@t_email) > 1
BEGIN
IF ( @n_email IS NOT NULL

)
AND @n_email != @t_email
SET @n_g4 = 1;
END;
END;
END;
ELSE
SET @n_g4 = 1;
END;
ELSE
BEGIN
SET @n_g2 = 1;
IF NOT ( ( @t_home_phone IS NULL

)
AND ( @t_work_phone IS NULL

)
)
SET @n_g4 = 1;
END;
END;
SET @n_g4 = @n_g4 * 4 + @n_g2 * 2 + @n_g1;
IF @n_g4 != 0
SET @n_action_code = CONCAT('G', @n_g4);
　
--trace off;
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = @n_action_code;
RETURN;
END TRY
BEGIN CATCH
SET @n_error_code = ERROR_NUMBER();
SET @n_return_code = ERROR_LINE();
SET @n_error_desc = ERROR_MESSAGE();
--if dbo.tl_log_error(@a_tl_sir_id,@n_return_code) != 0
--begin
SET @SWP_Ret_Value = -@n_return_code;
SET @SWP_Ret_Value1 = NULL;
RETURN;
-- end
END CATCH;
SET NOCOUNT OFF;
　
　
--set debug file to "/tmp/dlp_gi_check.trc";
--trace on;
END;