﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_CheckForErrors]
@spTypeID Char(4),@ModuleName nVarchar(18),@BatchID INT,@EligUpdSirRecID INT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
BEGIN TRY
	SET NOCOUNT ON;

DECLARE @SirRec INT=NULL;

IF @EligUpdSirRecID>0
	SET @SirRec=@EligUpdSirRecID

IF OBJECT_ID('tempdb..#tmpBatch') IS NOT NULL
    DROP TABLE #tmpBatch

IF OBJECT_ID('tempdb..#tmpError') IS NOT NULL
    DROP TABLE #tmpError

CREATE TABLE #tmpBatch (Id INT IDENTITY,dls_sir_id	INT null,dls_batch_id INT null,dls_status CHAR(1) null)

CREATE TABLE #tmpError(log_error_id INT NULL,ErrorNo INT,ErrorSeverity CHAR(1),[Status] CHAR(1),ErrorMsg CHAR(64),ErrorType CHAR(2))


INSERT INTO #tmpError
SELECT d.log_error_id,  
		 --d.config_bat_id ,  
		 --d.sp_id ,  
		 --d.sir_def_id ,  
		 --d.dls_sir_id ,  
		 d.error_no AS ErrorNo,  
		 --d.corrected,d.created_by ,d.created_time,d.corrected_by ,d.corrected_time,
		 e.severity AS ErrorSeverity,
		 CASE  WHEN e.severity='W' THEN 'W'
		 WHEN e.severity='F' THEN 'F' ELSE 'S' END as [Status], 
		 e.error_descr AS ErrorMsg, s.sp_type AS ErrorType 
		 FROM dl_log_error d
		 JOIN dl_sp_error e ON d.sp_id=e.sp_id
		 JOIN dl_sp s ON e.sp_id=s.sp_id
		 JOIN dl_module m ON s.module_id=m.module_id
		 WHERE d.error_no = e.error_no 
		 AND d.config_bat_id =@BatchID
		 AND m.module_name =@ModuleName
		 AND s.sp_type=@spTypeID
		 AND d.dls_sir_id =COALESCE(@SirRec,d.dls_sir_id)

IF NOT EXISTS(SELECT ErrorNo FROM #tmpError)
BEGIN

	IF @ModuleName='Member Eligibility'
	BEGIN

	INSERT INTO #tmpBatch
	SELECT e.dls_sir_id,e.dls_batch_id,e.dls_status
		FROM dls_elig e
		WHERE e.dls_batch_id=@BatchID

	END

	ELSE IF @ModuleName='SG Member'
	BEGIN

	INSERT INTO #tmpBatch
	SELECT e.dls_sir_id,e.dls_batch_id,e.dls_status
		FROM dls_sg_member e
		WHERE e.dls_batch_id=@BatchID

	END


	ELSE IF @ModuleName='Utilization Module'
	BEGIN

	INSERT INTO #tmpBatch
	SELECT e.dls_sir_id,e.dls_batch_id,e.dls_status
		FROM dls_utilization e
		WHERE e.dls_batch_id=@BatchID

	END

	ELSE IF @ModuleName='Lockbox Module'
	BEGIN

	INSERT INTO #tmpBatch
	SELECT e.dls_sir_id,e.dls_batch_id,e.dls_status
		FROM dls_lockbox e
		WHERE e.dls_batch_id=@BatchID

	END

IF @spTypeID='AL'
BEGIN
	IF EXISTS(SELECT * FROM #tmpBatch t WHERE t.dls_status<>'V')
	BEGIN
		INSERT INTO #tmpError(ErrorNo,ErrorSeverity,[Status],ErrorMsg,ErrorType)
		VALUES(6,'F','F','Error Found at After load',@spTypeID)
	END
END

IF @spTypeID='BU'
BEGIN
	IF EXISTS(SELECT * FROM #tmpBatch t WHERE t.dls_status<>'P')
	BEGIN
		INSERT INTO #tmpError(ErrorNo,ErrorSeverity,[Status],ErrorMsg,ErrorType)
		VALUES(7,'F','F','Error Found at Before Update',@spTypeID)
	END
END

IF @spTypeID='UP'
BEGIN
	IF EXISTS(SELECT * FROM #tmpBatch t WHERE t.dls_status<>'U')
	BEGIN
		INSERT INTO #tmpError(ErrorNo,ErrorSeverity,[Status],ErrorMsg,ErrorType)
		VALUES(7,'F','F','Error Found at Update SP',@spTypeID)
	END
END

END

SELECT * FROM #tmpError
		 
END TRY
BEGIN CATCH
THROW;
END CATCH

END