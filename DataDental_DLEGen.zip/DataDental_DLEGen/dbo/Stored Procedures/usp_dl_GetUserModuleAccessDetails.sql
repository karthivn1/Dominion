﻿-- =============================================
-- Author:		Uthayan.S
-- Create date: 31 Jan 2017
-- Description:	Get User Module access details for Dataload Application
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_GetUserModuleAccessDetails]
	-- Add the parameters for the stored procedure here
	@userCode varchar(15)=NULL ,
	@appName varchar(10) = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    Declare @userId int, @moduleController varchar(50),@parentId int
	SELECT @userId = usersl_id,@parentId = parent_id from user_tbl where ltrim(rtrim([user_tbl].user_id)) = @userCode

	IF(@appName='DL')
	BEGIN
		SET @moduleController = 'DataLoad'

		SELECT 	UG.usersl_id AS UserId,
					ModDef.mod_id AS ModuleId,
					ModAcc.eff_date AS EffectiveDate,
					ModAcc.exp_date AS ExpirationDate,
					ModAcc.access AS Access,
					ModDef.code AS ModuleCode,		
					ModDef.subsys_code AS SubSystemCode,
					ModDef.menu_opt AS MenuOption,		
					MenuDef.module AS Module,
					MenuDef.module_controller AS ModuleController,
					MenuDef.[sub_module] AS [SubModule],
					MenuDef.[action] AS Action,
					MenuDef.menu AS Menu,
					MenuDef.menu_description AS MenuDescription,
					MenuDef.menu_action AS MenuAction,
					MenuDef.submenu AS SubMenu,
					MenuDef.submenu_description AS SubMenuDescription,
					MenuDef.submenu_action AS SubMenuAction,		
					0 AS ActivityMasterId,
					0 AS ActivityReasonFlag 
			FROM   stc_user_group UG
			INNER JOIN mod_acc ModAcc on ModAcc.usersl_id = UG.group_id and ModAcc.[type]='DL'
			INNER JOIN mod_def ModDef ON ModAcc.mod_id = ModDef.mod_id
			INNER JOIN menu_definition_new MenuDef on MenuDef.mod_id = ModAcc.mod_id AND MenuDef.module_controller=@moduleController
			WHERE UG.usersl_id=@userId	AND (UG.exp_date > GETDATE() OR UG.exp_date is null)
	END
	ELSE
		BEGIN
			SET @moduleController = 'Eclaim';

			--DECLARE @voyager_admin int,
			--		@voyager_view int,
			--		@voyager_admin_mod_id int,
			--		@mod_id int;

			--SELECT @voyager_admin=groupsl_id FROM group_tbl WHERE group_id='Voyager Admin' and [type]='DL'
			--SELECT @voyager_view=groupsl_id FROM group_tbl WHERE group_id='Voyager View' and [type]='DL'
			--SELECT @voyager_admin_mod_id=mod_id FROM mod_acc WHERE usersl_id=@voyager_admin and [type]='DL'

			--IF EXISTS(SELECT * FROM stc_user_group WHERE usersl_id=@userId AND group_id in (@voyager_admin,@voyager_view))
			--		SET @mod_id = @voyager_admin_mod_id;
			

			--SELECT 	UG.usersl_id AS UserId,
			--		ModDef.mod_id AS ModuleId,
			--		ModAcc.eff_date AS EffectiveDate,
			--		ModAcc.exp_date AS ExpirationDate,
			--		ModAcc.access AS Access,
			--		ModDef.code AS ModuleCode,		
			--		ModDef.subsys_code AS SubSystemCode,
			--		ModDef.menu_opt AS MenuOption,		
			--		MenuDef.module AS Module,
			--		MenuDef.module_controller AS ModuleController,
			--		MenuDef.[sub_module] AS [SubModule],
			--		MenuDef.[action] AS Action,
			--		MenuDef.menu AS Menu,
			--		MenuDef.menu_description AS MenuDescription,
			--		MenuDef.menu_action AS MenuAction,
			--		MenuDef.submenu AS SubMenu,
			--		MenuDef.submenu_description AS SubMenuDescription,
			--		MenuDef.submenu_action AS SubMenuAction,		
			--		0 AS ActivityMasterId,
			--		0 AS ActivityReasonFlag 
			--FROM   stc_user_group UG
			--INNER JOIN mod_acc ModAcc on  ModAcc.[type]='DL'
			--INNER JOIN mod_def ModDef ON ModAcc.mod_id = ModDef.mod_id
			--INNER JOIN menu_definition_new MenuDef on MenuDef.mod_id = ModAcc.mod_id AND MenuDef.module_controller=@moduleController
			--WHERE ModAcc.usersl_id in (@voyager_admin,@voyager_view) and MenuDef.mod_id=@mod_id AND  UG.usersl_id=@userId	AND (UG.exp_date > GETDATE() OR UG.exp_date is null)


			WITH 
				ModuleGroupAccess_CTE (modId,modAccessId) AS  
				(  
					select moddef.mod_id modId,
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					 from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					 where usersl_id = @parentId and type = 'GP'
				),
				ModuleUserAccess_CTE (modId,modAccessId) AS  
				(  
					select moddef.mod_id modId,
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					where usersl_id = @userId and type is null
				)  

	SELECT 	@userId AS UserId,
				ModAcc.mod_id AS ModuleId,
				ModAcc.eff_date AS EffectiveDate,
				ModAcc.exp_date AS ExpirationDate,
				ModAcc.access AS Access,
				ModDef.code AS ModuleCode,		
				ModDef.subsys_code AS SubSystemCode,
				ModDef.menu_opt AS MenuOption,		
				MenuDef.module AS Module,
				MenuDef.module_controller AS ModuleController,
				MenuDef.[sub_module] AS [SubModule],
				MenuDef.[action] AS Action,
				MenuDef.menu AS Menu,
				MenuDef.menu_description AS MenuDescription,
				MenuDef.menu_action AS MenuAction,
				MenuDef.submenu AS SubMenu,
				MenuDef.submenu_description AS SubMenuDescription,
				MenuDef.submenu_action AS SubMenuAction,		
				0 AS ActivityMasterId,
				0 AS ActivityReasonFlag 
		FROM menu_definition_new MenuDef				
		INNER JOIN (SELECT modId,modAccessId from ModuleGroupAccess_CTE UNION SELECT modId,modAccessId FROM ModuleUserAccess_CTE) modAccCTE ON modAccCTE.modId = MenuDef.mod_id
		INNER JOIN mod_acc ModAcc on modAccCTE.modAccessId = ModAcc.modacc_id --AND (ModAcc.exp_date >= getdate() OR ModAcc.exp_date IS NULL) AND ModAcc.eff_date <=getdate()
		INNER JOIN mod_def ModDef ON ModDef.mod_id = ModAcc.mod_id
		WHERE MenuDef.subsys_code='EL' --AND ModAcc.usersl_id = @userId

		END

SET NOCOUNT OFF
END