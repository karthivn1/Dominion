﻿-- =============================================
-- Author:		Uthayan.S
-- Create date: 02 Jan 2017
-- Description:	Copy batch from dataload
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_CopyBatch] 
	@configBatchId int,
	@createdBy char(15)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @NewconfigBatchId int;

	DECLARE @curr_time VARCHAR(23);
    DECLARE @curr_time1 VARCHAR(23);
    DECLARE @curr_time2 VARCHAR(23);

	 SET @curr_time = GETDATE();
        SET @curr_time1 = SUBSTRING(@curr_time, 12, 11);
        SET @curr_time2 = CONVERT(VARCHAR, CONVERT(DATE, GETDATE())) + ' '
            + @curr_time1;

    SELECT @curr_time2 = FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:ff');

	INSERT INTO dl_config_bat
	SELECT dl_config_bat.config_id,
		   'N',
		   @createdBy,
		   @curr_time2
	FROM dl_config_bat WHERE config_bat_id=@configBatchId
	SELECT @NewconfigBatchId=SCOPE_IDENTITY()

	INSERT INTO dl_cfg_bat_det
	SELECT @NewconfigBatchId,   
         dl_cfg_bat_det.sp_id,   
         dl_cfg_bat_det.sir_def,   
         dl_cfg_bat_det.cfg_bat_det_toler,   
         dl_cfg_bat_det.cfg_bat_det_stat,   
         @createdBy,   
         @curr_time2  
    FROM dl_cfg_bat_det  
	WHERE dl_cfg_bat_det.config_bat_id = @configBatchId    

	INSERT INTO dl_cfg_bat_param
	SELECT @NewconfigBatchId,   
         dl_cfg_bat_param.sp_param_id,   
         dl_cfg_bat_param.param_value,   
         @createdBy,   
         @curr_time2  
    FROM dl_cfg_bat_param  
	WHERE dl_cfg_bat_param.config_bat_id = @configBatchId    


	--SELECT stc_user_access.user_access_id,   
 --        stc_user_access.usersl_id,   
 --        stc_user_access.sys_opt_id,   
 --        stc_user_access.eff_date,   
 --        stc_user_access.exp_date,   
 --        stc_user_access.created_by,   
 --        stc_user_access.created_time,   
 --        stc_sys_opt.sys_access_type  
 --   FROM stc_sys_opt,   
 --        stc_user_access  
	--WHERE ( stc_user_access.sys_opt_id = stc_sys_opt.sys_opt_id ) and  
 --        ( ( stc_sys_opt.sys_opt_type = :as_sys_opt_type ) AND  
 --        ( stc_sys_opt.sys_id = :ai_sys_id ) ) 
 
	INSERT INTO stc_user_access (usersl_id,sys_opt_id,eff_date,exp_date,created_by,created_time) 
	SELECT A.usersl_id,   
			 C.sys_opt_id,   
			 A.eff_date,   
			 A.exp_date,                                    
			 @createdBy,  
			 @curr_time2   
	FROM stc_user_access A
	INNER JOIN stc_sys_opt B on A.sys_opt_id = B.sys_opt_id and B.sys_id=@configBatchId and B.sys_opt_type='BT'
	INNER JOIN stc_sys_opt C on B.sys_access_type= C.sys_access_type and  C.sys_id=@NewconfigBatchId and C.sys_opt_type='BT'
	WHERE C.sys_opt_id is not null     

END