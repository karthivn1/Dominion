﻿CREATE PROCEDURE [dbo].[dlp_al_lockbox]
    @p_batch_id INT ,
    @p_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_al_lockbox
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This SP performs afterload processing on DataDental LockBox
--           for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR    DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:04:04 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1









000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/


        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(8000);
        DECLARE @s_err_rtn_text VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(18);
        DECLARE @s_proc_name CHAR(18);
        DECLARE @a_error_no INT;

        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @s_dls_status CHAR(1);

        DECLARE @t_sir_id INT;
        DECLARE @t_invoice_no CHAR(9);
        DECLARE @t_invoice_amt CHAR(9);
        DECLARE @new_check_number CHAR(9);
        DECLARE @t_paid_amt CHAR(9);
        DECLARE @t_group_id VARCHAR(20);
        DECLARE @t_group_alt_id VARCHAR(20);
        DECLARE @t_dls_group_id INT;

        DECLARE @new_dls_group_id INT;
   
        DECLARE @i_invoice_amt DECIMAL(12, 2);
        DECLARE @i_paid_amt DECIMAL(12, 2);
        DECLARE @i_tmp_grp_num INT;
   
        DECLARE @s_prev_err CHAR(1);
	
        DECLARE @s_batch_type CHAR(1);
   
        DECLARE @i_process_count INT;
        DECLARE @i_error_count INT;
        DECLARE @i_succ_count INT;
        DECLARE @true char(1);
        DECLARE @false char(1);
       --  DECLARE @cSIR CURSOR;

	   DECLARE @cSIR TABLE
                                (
                                  id INT IDENTITY ,
                                  dls_sir_id INT, 
								  invoice_no VARCHAR(9),   
								  invoice_amt VARCHAR(9),   
								  check_no VARCHAR(9),         
								  paid_amt VARCHAR(9),   
								  group_id VARCHAR(20),   
								  group_alt_id VARCHAR(20),   
								  dls_group_id INT
                                );

        DECLARE @SWV_dl_upd_statistics INT;

   -----------------exception handling------------
        SET NOCOUNT ON;
        SET @true = 't';
      
        SET @false = 'f';
      
        BEGIN TRY
            
   --SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/dlp_al_lockbox.trc";

--   TRACE ON;
   
            
            SET @s_proc_name = 'al_lockbox';
            SET @s_sir_def_name = 'lockbox';
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @p_batch_id, @s_proc_name;
            IF @i_sp_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
				RETURN
			END
   
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve valid SIR Table ID',16,1);
				RETURN
			END
   

   /* get batch type from user as entered for param batch_type */
            SET @s_batch_type = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Batch Type');
            IF ( @s_batch_type IS NULL
                 OR @s_batch_type = ''
               )
                OR LEN(@s_batch_type) = 0
				BEGIN
				SET @i_error_no=0
                RAISERROR('Missing Batch Type Value',16,1);
				RETURN
			END
            ELSE
                IF @s_batch_type NOT IN ( 'G', 'I' )
				BEGIN
					SET @i_error_no=0
                    RAISERROR('Batch Type must be (G or I)',16,1);
					RETURN
			END
      
   

   -- prepare for keeping stats on preprocessing-----------------
            EXECUTE dbo.dl_it_statistics @p_batch_id, @i_sp_id, @p_start_time,
                @i_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_descr OUTPUT;
            IF @i_error_no <= 0
			BEGIN
				SET @i_error_no=0
                RAISERROR('(Internal) error when creating statistics',16,1);
				RETURN
			END
   
   
   -- check if there were errors logged for prev runs
            IF EXISTS ( SELECT  *
                        FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @p_batch_id
                                AND sp_id = @i_sp_id )
                SET @s_prev_err = 'T';
            ELSE
                SET @s_prev_err = 'F';
   
            SET @i_process_count = 0;
            SET @i_succ_count = 0;
   

      -- catch all other errors --
             
   
   /* begin eval data, one row at a time */
   
   

      -- conversion err - char to numeric or numeric to char --
      
      ------------------------------------------------
           /* SET @cSIR = CURSOR  FOR SELECT dls_sir_id, invoice_no,   invoice_amt,   check_no,         paid_amt,   group_id,   group_alt_id,   dls_group_id
      
      FROM dbo.dls_lockbox (NOLOCK)
      WHERE dls_batch_id = @p_batch_id
      AND   dls_status = 'L';
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_invoice_no,
                @t_invoice_amt, @new_check_number, @t_paid_amt, @t_group_id,
                @t_group_alt_id, @t_dls_group_id;
            WHILE @@FETCH_STATUS = 0 */
			INSERT INTO @cSIR (dls_sir_id, invoice_no,   invoice_amt,   check_no,         paid_amt,   group_id,   group_alt_id,   dls_group_id)
			SELECT dls_sir_id, invoice_no,  invoice_amt, check_no, paid_amt, group_id, group_alt_id, dls_group_id
            FROM dbo.dls_lockbox (NOLOCK)
      WHERE dls_batch_id = @p_batch_id
      AND   dls_status = 'L';

            	 DECLARE @cur_cnt INT ,
                                @cur_i INT;

                            SET @cur_i = 1;

				--Get the no. of records for the cursor
                            SELECT  @cur_cnt = COUNT(1)
                            FROM    @cSIR;

                            WHILE ( @cur_i <= @cur_cnt )
                BEGIN
				select @t_sir_id = dls_sir_id, @t_invoice_no = invoice_no,
                @t_invoice_amt = invoice_amt, @new_check_number = check_no, @t_paid_amt = paid_amt, @t_group_id = group_id,
                @t_group_alt_id = group_alt_id, @t_dls_group_id = dls_group_id from @cSIR where id = @cur_i
                    BEGIN
                        BEGIN TRY
                                  
      -- if this proc and batch had prev stored errors, then
      -- call sub-proc to see if it was this row, and if so, 
      -- move to err history table
                            IF @s_prev_err = 'T'
                                EXECUTE dbo.dl_clean_curr_err @p_batch_id,
                                    @t_sir_id, @i_sp_id, @i_error_no OUTPUT,
                                    @s_err_rtn_text OUTPUT;
      
                            SET @i_process_count = @i_process_count + 1;
	  
	  --dls_lockbox.dls_group_id must be populated and it will subsequently
	  --be updated with the value of new_dls_group_id.
	  
                            SET @new_dls_group_id = NULL;
                            IF ( ( NOT @t_dls_group_id IS NULL
                                 )
           AND @t_dls_group_id > 0
 )
	  	
	  	--ignore fields group_id and group_alt_id.
                                SET @new_dls_group_id = @t_dls_group_id;
	  
                            IF ( @new_dls_group_id IS NULL
                                 AND ( ( NOT ( @t_group_id IS NULL
                                               OR @t_group_id = ''
                                             )
                                       )
                                       AND LEN(RTRIM(LTRIM(@t_group_id))) > 0
                                     )
                               )
                                BEGIN
                                    SET @new_dls_group_id = @t_group_id;
                                    IF ( @new_dls_group_id <= 0 )
                                        BEGIN
                                            SET @new_dls_group_id = NULL;
											BEGIN
												SET @i_error_no=0
												RAISERROR('dlp_al_lockbox():  new_dls_group_id <= 0.',16,1);
												RETURN
											END
                                        END;
                                END;
	  
                            IF ( @new_dls_group_id IS NULL
                                 AND ( ( NOT ( @t_group_alt_id IS NULL
                                               OR @t_group_alt_id = ''
                                             )
     )
                                       AND LEN(RTRIM(LTRIM(@t_group_alt_id))) > 0
                                     )
                               )
                                BEGIN
                                    DECLARE @returned_group_id INT;
			--define i_group_alt_id integer;	Table group.alt_id is char(20).
											--So, unclear why we would want to assign this to an integer.
											--Just use t_group_alt_id to find the record.
			
			--let i_group_alt_id = t_group_alt_id;
			/*
			if (i_group_alt_id > 0) then
				--Using the value of i_group_alt_id as the group Alt ID in the where clause,
				--query the group table to find the appropriate record and then set
				--new_dls_group_id to group.group_id.
				--
				--XXX:  Not coded yet.
				
				RAISE EXCEPTION -746, 0, "dlp_al_lockbox():  Not coded yet to determine group ID from group Alt ID.";
			else
				--Give up, we will not be able to determine the group ID.
				
				RAISE EXCEPTION -746, 0, "dlp_al_lockbox():  Unable to determine group ID.";
			end if;
			*/
			
                                    SET @returned_group_id = dbo.dl_grp_alt_id_to_grp_id(@t_group_alt_id);
                                    IF ( ( NOT @returned_group_id IS NULL
                                         )
                                         AND @returned_group_id > 0
                                       )
                                        SET @new_dls_group_id = @returned_group_id;
			
                                END;
	  
                            BEGIN
                                DECLARE @i_check_number INT;
			
				--On any exception, and particular if the assignment below
				--of the value of string new_check_number to
				--integer i_check_number fails because new_check_number
				--contains characters other than digits,
				--then set new_check_number to null which will eventually
				--be used to update table dls_lockbox.
				
                                BEGIN TRY
                                    SET @i_check_number = 0;
                                    IF ( NOT ( @new_check_number IS NULL
                                               OR @new_check_number = ''
                                             )
                                       )
                                        BEGIN
                                            SET @new_check_number = RTRIM(LTRIM(@new_check_number));
                                            SET @i_check_number = @new_check_number;
										END;
                                END TRY
						  BEGIN CATCH
						  SET @new_check_number = NULL;
                                END CATCH;
                            END;
		
      -- convert invoice amt from penneys to dollars --
	  
                            IF ( ( @t_invoice_amt IS NULL
                                   OR @t_invoice_amt = ''
                                 )
                                 OR LEN(RTRIM(LTRIM(@t_invoice_amt))) = 0
                               )
                                SET @t_invoice_amt = '0';
	  
                            SET @a_error_no = 50;
                            SET @i_invoice_amt = @t_invoice_amt * 0.01;
                            SET @a_error_no = 51;
                            SET @t_invoice_amt = @i_invoice_amt;
	  
      -- convert paid amt from penneys to dollars --
	  
                            IF ( ( @t_paid_amt IS NULL
                                   OR @t_paid_amt = ''
                                 )
                                 OR LEN(RTRIM(LTRIM(@t_paid_amt))) = 0
                               )
                                SET @t_paid_amt = '0';
	  
                            SET @a_error_no = 55;
                            SET @i_paid_amt = CAST(@t_paid_amt AS DECIMAL(12,2)) * 0.01;
							SET @a_error_no = 56;
                            SET @t_paid_amt = @i_paid_amt;
                            SET @a_error_no = 0;
							 
                            IF ( ( @t_invoice_no IS NULL
                                   OR @t_invoice_no = ''
                                 )
                                 OR LEN(RTRIM(LTRIM(@t_invoice_no))) = 0
                               )
							  
                                IF ( NOT @new_dls_group_id IS NULL
                                   )
                                    SET @t_invoice_no = @new_dls_group_id;	--Added 20131206.
                                ELSE
                                    SET @t_invoice_no = NULL;
			
		
                            IF ( @new_dls_group_id IS NULL )
                                UPDATE  dbo.dls_lockbox
                                SET     dls_status = 'V' ,
                                        invoice_no = @t_invoice_no ,
                                        invoice_amt = @t_invoice_amt ,
                                        paid_amt = @t_paid_amt ,
                                        check_no = @new_check_number
								WHERE dls_sir_id=@t_sir_id
                               -- WHERE  CURRENT OF @cSIR;
                            ELSE
                                UPDATE  dbo.dls_lockbox
                                SET     dls_status = 'V' ,
                                        invoice_no = @t_invoice_no ,
                                        invoice_amt = @t_invoice_amt ,
                                        paid_amt = @t_paid_amt ,
                                        check_no = @new_check_number ,
                                        dls_group_id = @new_dls_group_id
									where dls_sir_id=@t_sir_id
                                -- WHERE  CURRENT OF @cSIR;
	  
	  
         
      /* update stats every 100 rows evaluated */
                            IF @i_process_count % 100 = 0
                                BEGIN
                                    SET @i_error_count = @i_process_count
                                        - @i_succ_count;
            
         -----update the stats----------
                                    UPDATE  dbo.dl_bat_statistics
                                    SET     tot_record = @i_process_count ,
                                            tot_success_rec = @i_succ_count ,
                                            tot_fail_rec = @i_error_count
                                    WHERE   bat_statistics_id = @i_statistics_id;
                                END;
      
                            SET @i_succ_count = @i_succ_count + 1;
                           
                      END TRY
						BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no <> 50000
                                SET @s_error_descr = CAST(@i_error_no AS VARCHAR) + ':' + @s_error_descr 
                            RAISERROR(@s_error_descr,16,1);
							RETURN
                        END CATCH;
                    END;
                    SWL_Label2:
                   /* FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_invoice_no,
                        @t_invoice_amt, @new_check_number, @t_paid_amt,
                        @t_group_id, @t_group_alt_id, @t_dls_group_id; */
						set @cur_i = @cur_i + 1
                END;
            --CLOSE @cSIR;
   --------------------------end of major loop-------------------------------
            
            SET @i_error_count = @i_process_count - @i_succ_count;
            EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
                @i_succ_count, @i_error_count;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
                                                 ': Failed to update statistics');
                    RETURN;
                END;
   
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished Afterload for Batch ',
                                         @p_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            --SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
			 IF ERROR_NUMBER()=50000
		 BEGIN
                                    
                                   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sir_id,
                                        @i_error_no;
                                   
                                   ;
		END;
                           
       --interupt by user or server terminated 
            IF @i_error_no IN ( -213, -457 )
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                    RETURN;
                END;
            ELSE
                BEGIN
                     
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                    RETURN;
                END;
        END CATCH;
        SET NOCOUNT OFF;

--   TRACE OFF;



   -------------------------begin body of proc------------------------------
    END;