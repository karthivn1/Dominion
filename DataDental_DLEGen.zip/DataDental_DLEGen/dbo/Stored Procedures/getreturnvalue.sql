﻿CREATE PROCEDURE [dbo].[getreturnvalue]
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 04:57:57 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @returnvalue VARBINARY(8000);

        SET NOCOUNT ON;
        SET @returnvalue = CAST(0 AS VARBINARY(8000));
        EXECUTE SWPCrtGlVar 'returnvalue';
        EXECUTE SWPAddGlVar 'returnvalue', @returnvalue;
        RETURN @returnvalue;
        SET NOCOUNT OFF;
    END;