﻿CREATE PROCEDURE [dbo].[dlp_up_sg_pdcomm]
    @a_batch_id INT ,
    @a_pdcomm_eff DATE
    



/*
	Created Date	: 05/11/2001 
	Created By	: Jacky Chang 
	Reason		: Single Group Update -  PRODUCER COMMISSION.
* /


/ *error variable*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_fatal INT;

        DECLARE @t_temp_action_code CHAR(2);
        DECLARE @tot_msi INT;

        DECLARE @ls_user CHAR(20);
        DECLARE @d_mb_gr_pl_id INT;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @n_ffs_plan INT;
        DECLARE @s_ins_opt CHAR(3);
        DECLARE @n_new_eff_date DATE;
        DECLARE @i_dds_pd_type CHAR(2);
        DECLARE @i_comm_scheme_id INT;
        DECLARE @i_rel_gppl_id INT;

DECLARE @t_sir_id		integer;
DECLARE @sg_bu_sp_id	integer;
DECLARE @sg_up_sp_id	integer;
DECLARE @sg_sir_def_id	integer;
DECLARE @t_sub_sir_id	integer;
DECLARE @t_action_date	date;
DECLARE @n_msi		integer;
DECLARE @msi_num		integer;
DECLARE @msi_num1		integer;
DECLARE @msi_upper		integer;
DECLARE @n_datetime	datetime2(2)

DECLARE @s_dls_sir_id	integer;
DECLARE @s_dls_batch_id	integer;
DECLARE @s_dls_sub_sir_id	integer;
DECLARE @s_member_flag	char(2);
DECLARE @s_alt_id		char(20);
DECLARE @s_ssn		char(11);
DECLARE @s_sub_ssn		char(11);
DECLARE @s_sub_alt_id	char(20);
DECLARE @s_member_code	char(3);
DECLARE @s_last_name	char(15);
DECLARE @s_first_name	char(15);
DECLARE @s_middle_init	char(1);
DECLARE @s_date_of_birth	char(10);
DECLARE @s_student_flag	char(1);

DECLARE @s_disable_flag	char(1);
DECLARE @s_cobra_flag	char(1);
DECLARE @s_msg_group_id	integer;
DECLARE @s_plan_id		integer;
DECLARE @s_facility_id	integer;
DECLARE @s_rate_code	char(2);
DECLARE @s_mb_gppl_eff	char(10);
DECLARE @s_mb_fc_eff_date	char(10);
DECLARE @s_mb_term_date	char(10);

DECLARE @s_bank_account	char(25);
DECLARE @s_account_type	char(2);
DECLARE @s_tr_nbr		char(9);
DECLARE @s_trans_code	char(2);
DECLARE @s_address1	char(30);
DECLARE @s_address2	char(30);
DECLARE @s_city		char(30);
DECLARE @s_state		char(2);
DECLARE @s_zip 		char(5);
DECLARE @s_zipx 		char(4);
DECLARE @s_home_phone	char(10);
DECLARE @s_home_ext 	char(5);
DECLARE @s_work_phone	char(10);
DECLARE @s_work_ext	char(5);
DECLARE @s_producer_id	integer;
DECLARE @s_comm_scheme_id 	char(5);
DECLARE @s_pd_type		char(2);
DECLARE @s_license_number	char(9);
DECLARE @s_selling_period	char(1);
DECLARE @s_pdcomm_eff	char(10);
DECLARE @s_dls_mb_id	integer;
DECLARE @s_dls_sub_id	integer;
DECLARE @s_dls_msg_id	integer;
DECLARE @s_dls_group_id	integer;
DECLARE @s_dls_plan_id	integer;
DECLARE @s_dls_fc_id	integer;
DECLARE @s_dls_pd_id	integer;
DECLARE @s_dls_act_code	char(2);

       
        --DECLARE @SWV_cursor_var1 CURSOR;


        SET NOCOUNT ON;
        SET @t_sir_id =0;
       
        SET @sg_bu_sp_id =0;
       
        SET @sg_up_sp_id =0;
      
        SET @sg_sir_def_id =0;
       
        SET @t_sub_sir_id =0;
       
        SET @t_action_date =NULL;
      
        SET @n_msi =0;
    
        SET @msi_num =0;
   
        SET @msi_num1 =0;
      
        SET @msi_upper =0;
       
        SET @n_datetime =NULL;
       
        SET @s_dls_sir_id =0;
      
        SET @s_dls_batch_id =0;
      
        SET @s_dls_sub_sir_id =0;
      
        SET @s_member_flag ='';
      
        SET @s_alt_id ='';
       
        SET @s_ssn ='';
    
        SET @s_sub_ssn ='';
      
        SET @s_sub_alt_id ='';
     
        SET @s_member_code ='';
    
        SET @s_last_name ='';
     
        SET @s_first_name ='';
        
       SET @s_middle_init ='';
      
        SET @s_date_of_birth ='';
       
        SET @s_student_flag ='';
    
        SET @s_disable_flag ='';
       
        SET @s_cobra_flag ='';
       
        SET @s_msg_group_id =0;
      
        SET @s_plan_id =0;
    
        SET @s_facility_id =0;
     
        SET @s_rate_code ='';
     
        SET @s_mb_gppl_eff ='';
       
        SET @s_mb_fc_eff_date ='';
     
        SET @s_mb_term_date ='';
      
        SET @s_bank_account ='';
      
        SET @s_account_type ='';
       
        SET @s_tr_nbr ='';
       
        SET @s_trans_code ='';
       
        SET @s_address1 ='';
      
        SET @s_address2 ='';
     
        SET @s_city ='';
     
        SET @s_state ='';
       
        SET @s_zip ='';
      
        SET @s_zipx ='';
       
        SET @s_home_phone ='';
      
        SET @s_home_ext ='';
     
        SET @s_work_phone ='';
     
        SET @s_work_ext ='';
      
        SET @s_producer_id =0;
      
        SET @s_comm_scheme_id ='';
      
        SET @s_pd_type ='';
       
        SET @s_license_number ='';
      
        SET @s_selling_period ='';
       
        SET @s_pdcomm_eff ='';
       
        SET @s_dls_mb_id =0;
      
        SET @s_dls_sub_id =0;
     
        SET @s_dls_msg_id =0;
    
        SET @s_dls_group_id =0;
       
        SET @s_dls_plan_id =0;
       
        SET @s_dls_fc_id =0;

        SET @s_dls_pd_id =0;
     
        SET @s_dls_act_code ='';
      
        BEGIN TRY
            
				SELECT @s_member_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_dls_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_dls_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_plan_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_dls_pd_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_pd_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_dls_act_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_act_code' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_pd_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_license_number = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_comm_scheme_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 2

            IF @s_member_flag <> '00'
                RETURN 1;

            SET @ls_user = CONCAT('dl', @a_batch_id);
          
            IF ( @s_alt_id IS NULL
                 OR @s_alt_id = ''
               )
                OR LEN(@s_alt_id) = 0
                RAISERROR('Member alt_id is NULL',16,1);

           
            IF @s_dls_group_id IS NULL
                RAISERROR('Group id is NULL',16,1);

          
            IF @s_dls_plan_id IS NULL
                RAISERROR('Plan id is NULL',16,1);

            
            IF @s_dls_pd_id IS NULL
                RAISERROR('Producer id is NULL',16,1);

           
            IF ( @s_dls_act_code IS NULL
                 OR @s_dls_act_code = ''
               )
                OR LEN(@s_dls_act_code) = 0
                RAISERROR('Action code is NULL',16,1); 

--COMMENT OUT BECAUSE IT CAN BE CALLED BY "SA"
--elif s_dls_act_code <> "CA" then
--	RAISE EXCEPTION -746, 706, "Invalid action code"; 


            IF @a_pdcomm_eff IS NULL
                RAISERROR('Missing New PDCOMM Effective Date',16,1);

            
            IF ( @s_pd_type IS NULL
                 OR @s_pd_type = ''
               )
                BEGIN


				DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 producer_type CHAR(2)
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								producer_type
                                )
								SELECT producer_type
	
         FROM dbo.pdstat (NOLOCK)
         WHERE producer_id = @s_dls_pd_id
         AND status = 'AC'
         AND producer_type IS NOT NULL
         AND eff_date <= @a_pdcomm_eff
         AND (exp_date IS NULL OR @a_pdcomm_eff < exp_date);

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;
				/*
                   SET @SWV_cursor_var1 = CURSOR  FOR SELECT producer_type
	
         FROM dbo.pdstat (NOLOCK)
         WHERE producer_id = @s_dls_pd_id
         AND status = 'AC'
         AND producer_type IS NOT NULL
         AND eff_date <= @a_pdcomm_eff
         AND (exp_date IS NULL OR @a_pdcomm_eff < exp_date);
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_dds_pd_type;
                    WHILE @@FETCH_STATUS = 0
					*/


                        WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @i_dds_pd_type=producer_type
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;

                            SET @s_pd_type = @i_dds_pd_type ;
                           
                            GOTO SWL_Label2;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_dds_pd_type;
							SET @cur1_i = @cur1_i + 1;
                        END;
                    SWL_Label2:
                    --CLOSE @SWV_cursor_var1;
                END;

          
            IF ( @s_license_number IS NOT NULL
                 AND @s_license_number <> ''
               )
                AND NOT EXISTS ( SELECT *
                                 FROM   dbo.pdl_d (NOLOCK)
                                 WHERE  producer_id = @s_dls_pd_id
                                        AND license_number = @s_license_number )
                RAISERROR('Invalid Producer License Number',16,1);

            SET @i_comm_scheme_id = NULL;
            
            IF ( @s_comm_scheme_id IS NOT NULL
                 AND @s_comm_scheme_id <> ''
               )
                BEGIN
                  
                    SET @i_comm_scheme_id = @s_comm_scheme_id;
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.comm_scheme (NOLOCK)
                                    WHERE   comm_scheme_id = @i_comm_scheme_id )
                        RAISERROR('Invalid Commission Scheme Id',16,1);
                END;

            SELECT  @i_rel_gppl_id = MAX(rel_gppl_id)
            FROM    dbo.rel_gppl (NOLOCK)
            WHERE   group_id = @s_dls_group_id
                    AND plan_id = @s_dls_plan_id
                    AND eff_date <= @a_pdcomm_eff
                    AND ( exp_date IS NULL
                          OR @a_pdcomm_eff < exp_date
                        );
            
            IF @i_rel_gppl_id IS NULL
                RAISERROR('Missing Group Plan Relationship record',16,1);

            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.group_pdcomm (NOLOCK)
                            WHERE   group_id = @s_dls_group_id
                                    AND plan_id = @s_dls_plan_id
                                    AND rel_gppl_id = @i_rel_gppl_id
                                    AND prod_id = @s_dls_pd_id
                                    AND eff_date <= @a_pdcomm_eff
                                    AND ( exp_date IS NULL
                                 OR @a_pdcomm_eff < exp_date
                                        ) )
                INSERT  INTO dbo.group_pdcomm
                        ( group_id ,
                          plan_id ,
                prod_id ,
                          pd_type ,
                          license_number ,
                          comm_scheme_id ,
                          eff_date ,
                          exp_date ,
                          selling_prod ,
                          rel_gppl_id ,
                          h_user ,
                          h_datetime
                        )
                VALUES  ( @s_dls_group_id ,
                          @s_dls_plan_id ,
                          @s_dls_pd_id ,
                          @s_pd_type ,
                          @s_license_number ,
                          @i_comm_scheme_id ,
                          @a_pdcomm_eff ,
                          NULL ,
                          @s_selling_period ,
                          @i_rel_gppl_id ,
                          @ls_user ,
                          GETDATE()
                        );



--trace off;

            RETURN 1;
        END TRY
        BEGIN CATCH
            RETURN -200;
        END CATCH;
        SET NOCOUNT OFF;




--set debug file to "/tmp/dlp_up_sg_pdcomm.trc";
--trace on;
--set explain on;


    END;