﻿CREATE PROCEDURE [dbo].[dlp_ld_pv_assoc_part2]
    @a_batch_id INT ,
    @a_db_name CHAR(128) ,
    @a_start_time VARCHAR(22)
    
AS
    BEGIN

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_rtn_text VARCHAR(64);

        DECLARE @n_system_cmd CHAR(1200);
        DECLARE @n_syscmd1 CHAR(250);
        DECLARE @n_syscmd2 CHAR(250);
        DECLARE @n_syscmd3 CHAR(250);
        DECLARE @n_syscmd4 CHAR(250);
        DECLARE @n_load_file CHAR(128);
        DECLARE @n_load_period DATE;
        DECLARE @n_batch_status CHAR;
        DECLARE @n_tmp_file CHAR(64);
        DECLARE @n_tmp_file_1 CHAR(64);
        DECLARE @n_temp_file CHAR(64);
        DECLARE @n_random DATE;
        DECLARE @n_date_str VARCHAR(10);
        DECLARE @n_sir_count INT;
        DECLARE @i_ld_exist INT;
        DECLARE @s_debug_on CHAR(1);
        DECLARE @i_success INT;
        DECLARE @n_pre_file CHAR(64);
        DECLARE @i_file_count INT;
        DECLARE @s_surfix CHAR(2);
        DECLARE @n_prefix_load VARCHAR(64);
        DECLARE @min_sir INT;
        DECLARE @max_sir INT;
        DECLARE @load_record CHAR(1);
        DECLARE @i_record_count INT;
        DECLARE @i_delete_count INT;
        DECLARE @i_no_load_record INT;
        DECLARE @ls_now VARCHAR(22);

        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_sir_id INT;
        DECLARE @s_sub_alt_id CHAR(20);
        DECLARE @i_statistics_id INT;
        DECLARE @SWV_RaiseMsg VARCHAR(400);
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;

        SET NOCOUNT ON;
--		SYSTEM n_system_cmd;
   
        EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'ld_pv_assoc';
        EXECUTE @i_sir_def_id = dbo.dl_get_sir_def_id 'pv_assoc';
        SET @n_load_file = NULL;
        EXECUTE @n_load_file = dbo.dl_get_param_value @a_batch_id, @i_sp_id,
            'Input File Name'

        EXECUTE @i_ld_exist = dbo.dl_dlp_status @a_batch_id, @i_sir_def_id,
            @i_sp_id, 'LD';
     
        SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
        FROM    dbo.dl_cfg_bat_det (NOLOCK)
        WHERE   config_bat_id = @a_batch_id
                AND sp_id = @i_sp_id;
       
	
        SELECT  @i_statistics_id = MAX(bat_statistics_id)
        FROM    dbo.dl_bat_statistics (NOLOCK)
        WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
       
     			
        SELECT  @n_sir_count = COUNT(*)
        FROM    dbo.dls_pv_assoc (NOLOCK)
        WHERE   dls_batch_id = @a_batch_id;

        UPDATE  dbo.dl_bat_statistics
        SET     tot_record = @n_sir_count ,
                tot_success_rec = @n_sir_count ,
                tot_fail_rec = @n_sir_count - @n_sir_count
        WHERE   bat_statistics_id = @i_statistics_id;
       
        SELECT  @n_sir_count = COUNT(*)
        FROM    dbo.dls_pv_assoc (NOLOCK)
        WHERE   dls_batch_id = @a_batch_id;
        SET @SWV_func_DL_UPD_STATISTICS_par0 = ( @n_sir_count - @n_sir_count );
        EXECUTE dbo.dl_upd_statistics @i_statistics_id, @n_sir_count,
            @n_sir_count, @SWV_func_DL_UPD_STATISTICS_par0;
	        
        UPDATE  dbo.dl_cfg_bat_det
        SET     cfg_bat_det_stat = 'S'
        WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

     
    END;