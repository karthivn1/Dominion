﻿


CREATE PROCEDURE [dbo].[usp_ecl_InsertServiceLine]

@ServiceDate CHAR(10),
@CDT CHAR(5),
@ToothNo CHAR(2),
@SurfaceCode CHAR(5),
@QuadrantCode CHAR(5),
@CobAmount CHAR(20),
@SubmittedAmount CHAR(20),
@ErrorCode CHAR(10),
@EclaimId	INT,
@User VARCHAR(20)

AS
BEGIN
	INSERT INTO eclaim_d 
	(eclaim_id,svc_date,d_proc_code,tooth_no,surface,quad,cob_amt,submitted_amt,error_code,h_user ) 
	VALUES(@EclaimId,@ServiceDate,@CDT,@ToothNo,@SurfaceCode,@QuadrantCode,@CobAmount,@SubmittedAmount,@ErrorCode,@User)				
END