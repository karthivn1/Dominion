﻿
CREATE PROCEDURE [dbo].[dc_log_bat_trace]
    @a_batch_id INT ,
    @a_severity CHAR(1) ,
    @a_msg CHAR(64)
    
AS
    BEGIN

/*-- This procedure was converted on Fri Aug 19 02:26:26 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_code INT;
        DECLARE @i_return_code INT;
        DECLARE @c_error_desc CHAR(64);

        SET NOCOUNT ON;
        BEGIN TRY
            INSERT  INTO dbo.dc_batch_trace
                    ( batch_id ,
                      severity ,
                      trace_msg ,
                      trace_time
                    )
            VALUES  ( @a_batch_id ,
                      @a_severity ,
                      @a_msg ,
                      GETDATE()
                    );
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_code = ERROR_NUMBER();
            SET @i_return_code = ERROR_LINE();
            SET @c_error_desc = ERROR_MESSAGE();
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;