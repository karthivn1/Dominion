﻿CREATE PROCEDURE [dbo].[dlp_ld_eligibility_part2]
    @a_batch_id INT ,
    @a_db_name CHAR(128) ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
 


--AUTHOR : Wee Tan
--DATE: 03/28/97
--Purpose : To load member information into dls_elig(sir table)
AS
    BEGIN
/* Dominion Upgrade Project:: DB migration by Cognizant Technology using SQLWays and SQL Server best practices */
        DECLARE @n_sir_count INT;
        DECLARE @i_statistics_id INT;   
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;
        DECLARE @SWV_dl_upd_statistics INT;

        EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'ld_eligibility';

        SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
        FROM    dbo.dl_cfg_bat_det (NOLOCK)
        WHERE   config_bat_id = @a_batch_id
                AND sp_id = @i_sp_id;
       

        SELECT  @i_statistics_id = MAX(bat_statistics_id)
        FROM    dbo.dl_bat_statistics (NOLOCK)
        WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
        

        SELECT  @n_sir_count = COUNT(*)
        FROM    dbo.dls_elig (NOLOCK)
        WHERE   dls_batch_id = @a_batch_id;

        UPDATE  dbo.dl_bat_statistics
        SET     tot_record = @n_sir_count ,
                tot_success_rec = @n_sir_count ,
                tot_fail_rec = @n_sir_count - @n_sir_count
        WHERE   bat_statistics_id = @i_statistics_id;

        SELECT  @n_sir_count = COUNT(*)
        FROM    dbo.dls_elig (NOLOCK)
        WHERE   dls_batch_id = @a_batch_id;

        SET @SWV_func_DL_UPD_STATISTICS_par0 = ( @n_sir_count - @n_sir_count );
        EXECUTE dbo.dl_upd_statistics @i_statistics_id, @n_sir_count,
            @n_sir_count, @SWV_func_DL_UPD_STATISTICS_par0;

        IF @SWV_dl_upd_statistics <> 1
            BEGIN
                SET @SWP_Ret_Value = -1;
                SET @SWP_Ret_Value1 = CONCAT(@n_sir_count,
                                             ' Failed to update statistics');
                RETURN;
            END;

        UPDATE  dbo.dl_cfg_bat_det
        SET     cfg_bat_det_stat = 'S'
        WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;



--update statistics for table dls_elig;


        SET @SWP_Ret_Value = 1;
        SET @SWP_Ret_Value1 = CONCAT(@n_sir_count,
                                     ' SIR records loaded for batch ',
                                     @a_batch_id);
        RETURN;
      

    END;