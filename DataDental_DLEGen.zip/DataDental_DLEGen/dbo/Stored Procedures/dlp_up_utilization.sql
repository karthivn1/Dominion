﻿CREATE PROCEDURE [dbo].[dlp_up_utilization]
    @p_batch_id INT ,
    @p_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
	

------------------------------------------------------------------------------
--
--            Procedure:   dlp_up_utilization
--
--            Created:     02/15/99
--            Author:      Kim Nguyen, Gene Albers
--
-- Purpose:  This SP performs update processing on DataDental Claims tables
--           for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE          AUTHOR       DETAILS
--   07/30/1999    G.Albers     Added insert into obect_queue for each entry
--                                 claim_h
--   08/11/1999    G.Albers     Added check for providers being added prev.
--          in batch for a rec that has an action logged
--   08/11/1999    G.Albers     For unknown DB errors, they will now be logged
--                                 as a fatal err #0 an processing will cont.
--
--   03/30/2000    Ameeta       If Provider or Facility ID is null Initialize to 0.
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:09:09 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1











000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;

        DECLARE @i_error_count INT;
        DECLARE @i_total_count INT;
        DECLARE @i_init_count INT;
        DECLARE @i_sub_count INT;
        DECLARE @i_fatal INT;
        DECLARE @i_succ_count INT;
        DECLARE @i_last_total INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_stats_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @s_proc_name VARCHAR(20);
        DECLARE @s_sir_def_name VARCHAR(20);
        DECLARE @c_cur_err_flag CHAR(1);

        DECLARE @t_sir_id INT;
        DECLARE @temp_sir_id INT;
        DECLARE @i_rlplfc_id INT;
        DECLARE @i_mb_gr_pl_id INT;
        DECLARE @i_claim_id INT;
        DECLARE @i_fc_id INT;
        DECLARE @i_prv_id INT;
        DECLARE @i_tmp_prv_id INT;

        DECLARE @i_preauth_switch SMALLINT;
        DECLARE @i_emergency_switch SMALLINT;
        DECLARE @i_pay_prv_switch SMALLINT;

        DECLARE @d_returned_date DATE;
        DECLARE @d_received_date DATE;
        DECLARE @d_max_svc DATE;
        DECLARE @d_min_svc DATE;
        DECLARE @d_svc_beg DATE;
        DECLARE @d_cur_stamp DATETIME;
        DECLARE @d_pv_add_date DATE;

        DECLARE @dc_claim_no FLOAT;
        DECLARE @dc_cob_amt DECIMAL(16, 2);
        DECLARE @dc_sub_amt DECIMAL(16, 2);

        DECLARE @s_f_name CHAR(20);
        DECLARE @s_l_name CHAR(30);
        DECLARE @s_mid_init CHAR(1);
        DECLARE @s_prv_alt_id CHAR(20);
        DECLARE @s_addr1 CHAR(30);
        DECLARE @s_addr2 CHAR(30);
        DECLARE @s_city CHAR(20);
        DECLARE @s_county CHAR(20);
        DECLARE @s_state CHAR(2);
        DECLARE @s_zip CHAR(10);
        DECLARE @s_country CHAR(3);
        DECLARE @s_doc_no CHAR(15);
        DECLARE @s_x_rays_rqd CHAR(1);
        DECLARE @s_tax_id CHAR(9);
        DECLARE @s_claim_status CHAR(10);
        DECLARE @s_pv_state CHAR(2);
        DECLARE @s_type CHAR(2);
        DECLARE @s_spcl_type CHAR(2);
        DECLARE @s_svc_beg CHAR(10);
        DECLARE @s_returned_date CHAR(10);
        DECLARE @s_received_date CHAR(10);
        DECLARE @s_d_proc_code CHAR(5);
DECLARE @s_tooth_no CHAR(2);
        DECLARE @s_surface CHAR(5);
        DECLARE @s_quad CHAR(5);
        DECLARE @t_tooth_no CHAR(2);
        DECLARE @t_surface CHAR(5);
        DECLARE @t_quad CHAR(5);
        DECLARE @s_cob_amt CHAR(20);
        DECLARE @s_sub_amt CHAR(20);
        DECLARE @s_relates_to CHAR(1);
        DECLARE @t_action_code CHAR(2);
        DECLARE @t_alt_id CHAR(20);
        DECLARE @t_pv_tax_id CHAR(20);
        DECLARE @s_ins_opt CHAR(4);
        DECLARE @ls_user CHAR(20);
        DECLARE @rules_type_name CHAR(20);

        DECLARE @s_speciality_type CHAR(2);
        DECLARE @s_preauth_switch CHAR(9);
        DECLARE @s_emergency_switch CHAR(9);
        DECLARE @s_pay_prv_switch CHAR(9);
/* 20120514$$ks - added special designation logic */
        DECLARE @i_desig_id INT;
        DECLARE @i_ddesig_id INT;
        DECLARE @serialid INT;
        DECLARE @c3UtilSir CURSOR;
        DECLARE @c1UtilSir CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;

-----exception handling---------------------------------------------------------
        SET NOCOUNT ON;
        SET @serialid = 0;
         
        BEGIN TRY
            
            SET @s_proc_name = 'up_utilization';
            SET @s_sir_def_name = 'utilization';
            SET @d_cur_stamp = GETDATE();
            SET @d_pv_add_date = DATEADD(YEAR, -5, CONVERT(DATE, GETDATE()));
            SET @ls_user = CONCAT('dl', @p_batch_id);
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @p_batch_id, @s_proc_name;
            IF @i_sp_id = -1
			BEGIN
				SET @a_error_no=0
				RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
			END

            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id = -1
			BEGIN
				SET @a_error_no=0
                RAISERROR('Could not retrieve valid SIR Table ID',16,1);
			END


-- prepare for keeping stats on preprocessing-----------------
            EXECUTE dbo.dl_it_statistics @p_batch_id, @i_sp_id, @p_start_time,
                @i_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_stats_id OUTPUT, @s_error_descr OUTPUT;
            IF @i_error_no <= 0
			BEGIN
				SET @a_error_no=0
                RAISERROR('(Internal) error when creating statistics',16,1);
			END



-- move all logged errors to the log error history table
            SET @c3UtilSir = CURSOR  FOR SELECT dls_sir_id 
      FROM dbo.dl_log_error (NOLOCK)
      WHERE config_bat_id = @p_batch_id
      AND   sp_id = @i_sp_id
      AND   dls_sir_id IN(SELECT dls_sir_id
      FROM dbo.dls_utilization (NOLOCK)
      WHERE  dls_batch_id = @p_batch_id
      AND    dls_status   = 'P');
            OPEN @c3UtilSir;
            FETCH NEXT FROM @c3UtilSir INTO @temp_sir_id;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    EXECUTE dbo.dl_clean_curr_err @p_batch_id, @temp_sir_id,
                        @i_sp_id, @i_error_no OUTPUT, @s_err_rtn_text OUTPUT;
                    FETCH NEXT FROM @c3UtilSir INTO @temp_sir_id;
                END;
            CLOSE @c3UtilSir;
           -- COMMIT; 

-- get initial count of rows that have passed pre-processing --
            SELECT  @i_init_count = COUNT(*)
            FROM    dbo.dls_utilization (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'U';
            SET @i_total_count = 0;
            SET @i_succ_count = 0;
            SET @i_last_total = 0;

---20120514$$ks -- Get Special Designation info ------

            SELECT  @i_desig_id = desig_id
            FROM    dbo.desig (NOLOCK)
            WHERE   subsys_code = 'PL'
                    AND desig_name = 'Pay Contracted FC';
            
	-----exception handling w/in foreach------------------------------------

            IF @i_desig_id IS NULL
			BEGIN
			SET @a_error_no=101
           RAISERROR('Cannot find Special Designation to Pay Contr FC',16,1);
		   END

-----begin processing one record at a time-------------------------------------
-----the outer loop will create the claim_h entry & add a provider if nec-----


	   -- problems retrieving data from dB --------
	   

	   -- if fatal err, rollback and cont with next grp - else resume
	   

      -------------------------------------------------------------------------

            SET @c1UtilSir = CURSOR  FOR SELECT DISTINCT alt_id, tax_id 
      FROM   dbo.dls_utilization (NOLOCK)
      WHERE  dls_batch_id = @p_batch_id
      AND    dls_status   = 'P';
            OPEN @c1UtilSir;
            FETCH NEXT FROM @c1UtilSir INTO @t_alt_id, @t_pv_tax_id;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    BEGIN
                        DECLARE @c2UtilSir CURSOR;
                        DECLARE @SWV_dl_get_err_sevr CHAR(1);
                        DECLARE @SWV_cursor_var1 CURSOR;
                        DECLARE @SWV_cursor_var2 CURSOR;

		-- get num records for header, not already counted
		

		-- log error that occurred for all effected records
		

		   -- set all records to "E" for alt_id
		   

		-- break out of inner loop &amp; continue with next claim header
		
		-- log warning that occurred for all effected records
                        BEGIN TRY
                            IF EXISTS ( SELECT  dls_status
                                        FROM    dbo.dls_utilization (NOLOCK)
                                        WHERE   dls_batch_id = @p_batch_id
                                                AND alt_id = @t_alt_id
                                                AND dls_status != 'P' )
	---Ignore claim because at least one service line is in error.
                                GOTO SWL_Label3; 
	
                            --BEGIN TRAN;
                            SET @a_error_no = 0;
                            SET @i_prv_id = NULL;
                            SET @d_returned_date = NULL;
                            SET @d_received_date = NULL;

	-- determine if any actions (add provider) need to be
	-- performed for this alt id

                            IF EXISTS ( SELECT  *
                                        FROM    dbo.dl_action (NOLOCK)
                                        WHERE   batch_id = @p_batch_id
                                                AND process_status = 'N'
                                                AND action_code = 'PA'
                                                AND dls_sir_id IN (
                                                SELECT  dls_sir_id
                                                FROM    dbo.dls_utilization
                                                WHERE   dls_batch_id = @p_batch_id
                                                        AND dls_status = 'P'
                                                        AND alt_id = @t_alt_id ) )

	   -- see if already been added --
                                BEGIN
                                    SELECT  @i_prv_id = pv_id
                                    FROM    dbo.providers (NOLOCK)
                                    WHERE   tax_id = @t_pv_tax_id;
                                

	   -- now check if added in this processing by prev record
                                    IF @i_prv_id IS NOT NULL

	      -- provider was added previously

  	      -- update all the actions for the given alt_id
                                        UPDATE  dbo.dl_action
                                        SET     process_status = 'Y'
                                        WHERE   batch_id = @p_batch_id
                                                AND action_code = 'PA'
                                                AND dls_sir_id IN (
                                                SELECT  dls_sir_id
FROM dbo.dls_utilization (NOLOCK)
                WHERE   dls_batch_id = @p_batch_id
                                                        AND dls_status = 'P'
                                                        AND alt_id = @t_alt_id );
                                    ELSE  -- was null, must add the provider --

 	      -- must add new provider
                                        BEGIN
                                            SET @a_error_no = 10;
                                            SELECT DISTINCT
                                                    @s_tax_id = tax_id ,
                                                    @s_f_name = first_name ,
                                                    @s_mid_init = middle_init ,
                                                    @s_l_name = last_name ,
                                                    @s_prv_alt_id = prv_id ,
                                                    @s_addr1 = addr1 ,
                                                    @s_addr2 = addr2 ,
                                                    @s_city = city ,
                                                    @s_county = county ,
                                                    @s_state = state ,
                                                    @s_zip = zip ,
                                                    @s_country = country
                                            FROM    dbo.dls_utilization (NOLOCK)
                                            WHERE   dls_batch_id = @p_batch_id
                                                    AND dls_status = 'P'
                                                    AND alt_id = @t_alt_id;
                                           
                                            SET @a_error_no = 0;  -- reset

	      -- insert record into providers table
                                            INSERT  INTO dbo.providers
                                                    ( alt_id ,
                                                      tax_id ,
                                                      tin ,
                                                      first_name ,
                                                      middle_init ,
                                                      last_name ,
                                                      discipline ,
                                                      ada_mbr ,
                                                      print_dir ,
                                                      pvstat ,
                                                      h_user ,
                                                      h_datetime ,
                                                      peer_rv
                                                    )
                           VALUES  ( @s_prv_alt_id ,
                                                      @s_tax_id ,
                                                      'Y' ,
                                                      @s_f_name ,
                                                      @s_mid_init ,
                                                      @s_l_name ,
                                                      'GN' ,
                                                      'N' ,
                                                      'Y' ,
                                                      'AC' ,
                                                      @ls_user ,
                                                      @d_cur_stamp ,
                                                      'N'
                                                    );

	      -- retrieve prv id for new provider just added
	      
                                            SELECT  @i_prv_id = pv_id
                                            FROM    dbo.providers (NOLOCK)
 WHERE   tax_id = @s_tax_id
                                AND h_datetime = @d_cur_stamp;
                                            
                                       IF @i_prv_id IS NULL
									   BEGIN
									   SET @a_error_no=100
                                                RAISERROR('Could not insert record into provider table',16,1);
										END
	      

	      -- insert record into pv_status table
                                            INSERT  INTO dbo.pv_status
                                                    ( pv_id ,
                                                      pv_status ,
                                                      eff_date ,
                                                      exp_date
                                                    )
                                            VALUES  ( @i_prv_id ,
                                                      'AC' ,
                                                      @d_pv_add_date ,
                                                      NULL
                                                    );

	      --Verify successful insert
	      
                                            IF NOT EXISTS ( SELECT
                                                              *
                                                            FROM
                                                              dbo.pv_status (NOLOCK)
                                                            WHERE
                                                              pv_id = @i_prv_id
                                                              AND pv_status = 'AC'
                                                              AND eff_date = @d_pv_add_date )
															  BEGIN
															  SET @a_error_no=110
														RAISERROR('Could not insert record into pv_status table',16,1);
												END
	      

	      -- insert record into address table
                                            INSERT  INTO dbo.address
                                                    ( subsys_code ,
                                                      sys_rec_id ,
                                                      addr_type ,
                                                      addr1 ,
                                                      addr2 ,
                                                      city ,
                                                      county ,
                                                      state ,
                                                      zip ,
                                                      country ,
                                                      mail
                                                    )
                            VALUES  ( 'PV' ,
                                                      @i_prv_id ,
                                                      'L' ,
                                                      @s_addr1 ,
                                                      @s_addr2 ,
                                                      @s_city ,
                                                      @s_county ,
                                                      @s_state ,
                                                      @s_zip ,
                                                      @s_country ,
                                                      'N'
                                                    );

	      --Verify successful insert
	      
                                            IF NOT EXISTS ( SELECT
                                                              *
                                                            FROM
                                                              dbo.address (NOLOCK)
 WHERE
        subsys_code = 'PV'
                                                  AND sys_rec_id = @i_prv_id
                               AND addr_type = 'L' )
															  BEGIN
															  SET @a_error_no=120
												 RAISERROR('Could not insert record into address table',16,1);
													END

	      -- update all the actions for the given alt_id
                                            UPDATE  dbo.dl_action
                                            SET     process_status = 'Y'
                                            WHERE   batch_id = @p_batch_id
                                                    AND action_code = 'PA'
                                                    AND dls_sir_id IN (
                                                    SELECT  dls_sir_id
                                                    FROM    dbo.dls_utilization (NOLOCK)
                                                    WHERE   dls_batch_id = @p_batch_id
                                                            AND dls_status = 'P'
                                                            AND alt_id = @t_alt_id );
                                        END;
                                END; -- added provider

	 ---end check if provider added  --

                            SET @a_error_no = 20; -- fatal -- non-unique header info for alt id

	-- retrieve info for inserting claim header info
                            SELECT DISTINCT
                                    @s_doc_no = document_no ,
                                    @s_x_rays_rqd = x_rays_rqd ,
                                    --@s_returned_date = CASE WHEN ISNULL(returned_date,'') <>'' then STUFF(STUFF(returned_date,3,0,'/'),6,0,'/') ELSE returned_date END  ,
									@s_returned_date=CASE WHEN ISNULL(returned_date,'') = '' THEN returned_date
				 WHEN returned_date LIKE '%/%' THEN returned_date
				 ELSE STUFF(STUFF(returned_date,3,0,'/'),6,0,'/') END,
                                    --@s_received_date = CASE WHEN ISNULL(received_date ,'') <>'' then STUFF(STUFF(received_date ,3,0,'/'),6,0,'/') ELSE received_date  END ,
									@s_received_date =CASE WHEN ISNULL(received_date,'') = '' THEN received_date 
				 WHEN received_date like '%/%' THEN received_date
				 ELSE STUFF(STUFF(received_date,3,0,'/'),6,0,'/') END,
                                    @s_preauth_switch = preauth_switch ,
                                    @s_emergency_switch = emergency_switch ,
                                    @s_pay_prv_switch = pay_prv_switch ,
                                    @s_type = type ,
                                    @s_spcl_type = speciality_type ,
                                    @i_rlplfc_id = dls_rlplfc_id ,
                                    @i_mb_gr_pl_id = dls_mb_gr_pl_id ,
                                    @i_fc_id = dls_fc_id ,
                                    @i_tmp_prv_id = dls_prv_id
                            FROM    dbo.dls_utilization (NOLOCK)
                            WHERE   dls_batch_id = @p_batch_id
                                    AND dls_status = 'P'
                                    AND alt_id = @t_alt_id;
                            
                            SET @a_error_no = 200;

	-- retrieve service date, convert to date type and store in temp table
                            SET @d_min_svc = NULL;
                            SET @d_max_svc = NULL;
                            IF @s_preauth_switch = 'N'
                                BEGIN
                                    SELECT  CONVERT(DATETIME2(0), CONVERT(CHAR, SUBSTRING(svc_beg,
                                                              1, 2)) + '-'
                                            + CONVERT(CHAR, SUBSTRING(svc_beg,
                                                              3, 2)) + '-'
    + CONVERT(CHAR, SUBSTRING(svc_beg,
                                                              5, 4))) begin_date
                  INTO    #dls_ut_temp
                     FROM    dbo.dls_utilization (NOLOCK)
                                    WHERE   dls_batch_id = @p_batch_id
                   AND dls_status = 'P'
                                            AND alt_id = @t_alt_id;
		
                                    SET @a_error_no = 0;

	-- get min and max date values from temp table
                                    SELECT  @d_max_svc = MAX(begin_date) ,
                      @d_min_svc = MIN(begin_date)
                                    FROM    #dls_ut_temp;
                                    
                                    DROP TABLE #dls_ut_temp;
                                    IF @d_max_svc IS NULL
                                        OR @d_min_svc IS NULL
										BEGIN
										SET @a_error_no=200
                                        RAISERROR('Can not convert Service Date to date, must be MMDDYYYY',16,                     1);
										END
                                END;
	

	-- did not add new user
                            IF @i_prv_id IS NULL
                                IF @i_tmp_prv_id > 0
                                    SET @i_prv_id = @i_tmp_prv_id;
                                ELSE
                                    SET @i_prv_id = 0;
		
	
                            IF @i_fc_id IS NULL
                                SET @i_fc_id = 0;
	

	-- convert preauth switch
                            IF @s_preauth_switch = 'Y'
                                SET @i_preauth_switch = 1;
                            ELSE
                                SET @i_preauth_switch = 0;
	

	-- convert emergency switch
                            IF @s_emergency_switch = 'Y'
                                SET @i_emergency_switch = 1;
                            ELSE
                                SET @i_emergency_switch = 0;
	

	-- convert pay_prv switch
                            SET @i_pay_prv_switch = @s_pay_prv_switch;
	/* 20120508$$ks - Some plans require contracted provider to be paid - not the member
		setting value back to "System Decides" under the following conditions:
		i_pay_prv_switch = 3 - pay member, fc_id > 0 and plan requires that provider be paid
		i_pay_prv_switch = 2 - pay FC but fc_id = 0
		i_pay_prv_switch = 1 - pay provider and prv_id = 0

	*/
                            IF @i_pay_prv_switch = 3
                                AND @i_fc_id > 0
                                BEGIN
                                    SET @i_ddesig_id = NULL;
                                    SELECT  @i_ddesig_id = plx_spc_desig_id
                                    FROM    dbo.plx_spc_desig (NOLOCK)
                                    WHERE   plan_id = ( SELECT
                                                              plan_id
                                                        FROM  dbo.rlmbgrpl (NOLOCK)
                                                        WHERE mb_gr_pl_id = @i_mb_gr_pl_id
                                                      )
                                            AND pl_spc_desig_id = @i_desig_id
                                            AND exp_date IS NULL;
                                   
                                    IF @i_ddesig_id IS NOT NULL
                                        SET @i_pay_prv_switch = 0;
                                END;
	
                            IF @i_pay_prv_switch = 2
                                AND @i_fc_id = 0
                                SET @i_pay_prv_switch = 0;
	
                            IF @i_pay_prv_switch = 1
                                AND @i_prv_id = 0
                                SET @i_pay_prv_switch = 0;
	
--	IF s_pay_prv_switch = "Y" THEN
--	   LET i_pay_prv_switch = 1;
--	ELSE
--	   LET i_pay_prv_switch = 0;
--	END IF;

	-- convert returned date if exists
                   IF ( @s_returned_date IS NOT NULL
                       AND @s_returned_date <> ''
                               )
                                AND LEN(@s_returned_date) > 0
                                BEGIN
                                    SET @a_error_no = 170;
                                    SET @d_returned_date = CAST(@s_returned_date AS DATE);
                                    SET @a_error_no = 0;
                                END;
	

	-- convert received date if exists
         IF ( @s_received_date IS NULL
                                 OR @s_received_date = ''
                               )
                                OR LEN(@s_received_date) < 1
								BEGIN
								SET @a_error_no=190
						RAISERROR('Received date is required, default is afterload param value',                  16,1);
						 END
                            ELSE
                                BEGIN
                                    SET @a_error_no = 180;
                                    SET @d_received_date = CAST (@s_received_date AS DATE);
                                    SET @a_error_no = 0;
                                END;
	

	-- get claim no
                            EXECUTE dbo.dlp_ut_get_clm_no @i_error_no OUTPUT,
                                @dc_claim_no OUTPUT;
                            IF @i_error_no = -1
							BEGIN
							SET @a_error_no=130
                                RAISERROR('Could not retrieve/generate new claim no.',16,1);
							END
	  
		   
		         INSERT  INTO dbo.claim_h
                                    ( claim_no ,
                                      mbgrpl_id ,
                                      rlplfc_id ,
                                      fc_id ,
                                      prv_id ,
                                      x_rays_rqd ,
                                      returned_date ,
                                      received_date ,
                                      preauth_switch ,
                                      emergency_switch ,
                                      pay_prv_switch ,
                                      svc_date_beg ,
                                      svc_date_end ,
                                      document_no ,
                                      alt_id ,
                                      claim_status ,
                                      h_user ,
                                      type ,
                                      speciality_type
                                    )
                            VALUES  ( @dc_claim_no ,   -- claim number just generated
                                      @i_mb_gr_pl_id ,   -- id from the member-group-plan table
                                      @i_rlplfc_id ,     -- id from the member-plan-facility table
                                      @i_fc_id ,         --  facility id where claim took place
                                      @i_prv_id ,        -- id of provider, may have been added above
                                      @s_x_rays_rqd ,    -- Y or N
                                      @d_returned_date ,
                                      @d_received_date ,
                                      @i_preauth_switch ,
                                      @i_emergency_switch ,
                                      @i_pay_prv_switch ,
                                      @d_min_svc ,        -- min svc beg date from file for givenalt_id
                                      @d_max_svc ,        -- max svc beg date from file for given alt_id
                                      @s_doc_no ,
                                      @t_alt_id ,
                                      'In Process' ,
                                      @ls_user ,
                                      @s_type ,
 @s_spcl_type
                                    );
	
                           --SET @i_claim_id = @serialid;
						   SET @i_claim_id = IDENT_CURRENT( 'dds_prod.dbo.claim_h' );
     IF @i_claim_id IS NULL
							BEGIN
							SET @a_error_no=140
                                RAISERROR('Could not insert claim header into claim_h',16,1);
							END
	
                            SET @a_error_no = 210; -- Fatal

                            SELECT  @rules_type_name = dbo.rule_types.type_name
                            FROM    dbo.business_rules (NOLOCK) ,
                                    dbo.claim_obj_status (NOLOCK) ,
                                    dbo.rule_modules (NOLOCK) ,
                dbo.rule_submodules (NOLOCK) ,
                                    dbo.rule_types (NOLOCK)
                            WHERE   dbo.business_rules.rule_type_id = dbo.claim_obj_status.rule_type_id
        AND dbo.rule_submodules.module_id = dbo.rule_modules.module_id
                                    AND dbo.rule_types.sub_module_id = dbo.rule_submodules.submodule_id
                                    AND dbo.rule_types.rule_type_id = dbo.claim_obj_status.rule_type_id
                                    AND dbo.rule_types.rule_type_id = dbo.business_rules.rule_type_id
                                    AND dbo.rule_modules.module_name = 'TrafficCop'
                                    AND dbo.rule_submodules.submod_name = 'claim_entry'
                                    AND dbo.claim_obj_status.[order] = 1
                                    AND dbo.business_rules.exp_date IS NULL;
                            
                            SET @a_error_no = 220;
                            INSERT  INTO dbo.object_queue
                                    ( object_type ,
                                      object_id ,
                                      service ,
                                      role ,
                                      user_id ,
                                      status ,
                                      locked ,
                                      locked_by ,
									lock_datetime ,
                                      service_requested ,
                                      sleep_to ,
                                      last_service
                                    )
                            VALUES  ( 'claim' ,
                                      @i_claim_id ,
                                      'TrafficCop' ,
                                      '' ,
                                      '' ,
                                      @rules_type_name ,
                                      0 ,
                                      'DataLoad' ,
                                      GETDATE() ,
                                      '' ,
                                      NULL ,
                                      'DataLoad'
                                    );
									
					INSERT INTO dbo.Claim_Process_No(object_id,Batch_id)
					VALUES (@i_claim_id,@p_batch_id)

                            SET @a_error_no = 0;
	

		------------------begin exception handling----------------------
                            SET @c_cur_err_flag = 'F';


	-- insert details of claims into claim_d table--------------------------
	

		   -- problems retrieving data from dB --------
		   

		-------------begin body of procedure----------------------------

                            SET @c2UtilSir = CURSOR  FOR SELECT dls_sir_id,
		       CAST(CASE WHEN ISNULL(svc_beg,'') <>'' then STUFF(STUFF(svc_beg,3,0,'/'),6,0,'/') ELSE svc_beg END AS DATE) 'svc_beg' ,
		       d_proc_code,
		       tooth_no,
		       surface,
		       quad,
		       submitted_amt,
		       cob_amt,
		       dls_relates_to
		
               FROM   dbo.dls_utilization (NOLOCK)
               WHERE dls_batch_id = @p_batch_id
          AND    dls_status   = 'P'
               AND    alt_id       = @t_alt_id;
        OPEN @c2UtilSir;
                            FETCH NEXT FROM @c2UtilSir INTO @t_sir_id,
                                @d_svc_beg, @s_d_proc_code, @s_tooth_no,
            @s_surface, @s_quad, @s_sub_amt, @s_cob_amt,
                                @s_relates_to;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    BEGIN
                                        BEGIN TRY
                                            SET @i_total_count = @i_total_count
                                                + 1;

		-- assign any defalut values---------------
                                            SET @dc_sub_amt = 0.0;
                                            SET @dc_cob_amt = 0.0;
                                            SET @t_tooth_no = '';
                                            SET @t_surface = '';
                                            SET @t_quad = '';
                  SET @a_error_no = 0;

		-- convert cob amt, must be 0.0 or greater
                                            IF ( @s_cob_amt IS NOT NULL
                                                 AND @s_cob_amt <> ''
                                               )
                                                AND LEN(@s_cob_amt) > 0
                                                BEGIN
                                                    SET @a_error_no = 150;
                                                    SET @dc_cob_amt = @s_cob_amt;
                                                    SET @a_error_no = 0;
                                                    IF @dc_cob_amt < 0.0
                                                        SET @dc_cob_amt = 0.0;
                                                END;
		

		-- convert sub amt, must be 0.0 or greater
                                            IF ( @s_sub_amt IS NOT NULL
                                                 AND @s_sub_amt <> ''
                                               )
                                                AND LEN(@s_sub_amt) > 0
                                                BEGIN
                              SET @a_error_no = 160;
                                                    SET @dc_sub_amt = @s_sub_amt;
                                                    SET @a_error_no = 0;
                                                    IF @dc_sub_amt < 0.0
                                                        SET @dc_sub_amt = 0.0;
                                                END;
		

		-- determines which dental info is loaded into tgt db
                                            IF @s_relates_to = 'Q'
                                                SET @t_quad = @s_quad;
                                            ELSE
                                                IF @s_relates_to = 'T'
                                                    SET @t_tooth_no = @s_tooth_no;
                                                ELSE
                                                    IF @s_relates_to = 'S'
                                                        BEGIN
                                                            SET @t_tooth_no = @s_tooth_no;
                                                            SET @t_surface = @s_surface;
                                                        END;
														
		-- create a claims detail record in tgt db with info
                                            INSERT  INTO dbo.claim_d
                                                    ( claim_id ,
                                                      svc_beg ,
                                                      d_proc_code ,
      tooth_no ,
                                                      surface ,
                                                      quad ,
            submitted_amt ,
                                                      h_datetime ,
                           h_user ,
                     status ,
                                                      cob_amt
                                                    )
                                            VALUES  ( @i_claim_id ,
                                                      @d_svc_beg ,
                                                      @s_d_proc_code ,
                                                      @t_tooth_no ,
                                                      @t_surface ,
													 @t_quad ,
                                                      @dc_sub_amt ,
                                                      @d_cur_stamp ,
                                                      @ls_user ,
                                                     'Open' ,
                                                      @dc_cob_amt
                                                    );

		-- update row status to 'U'pdate, pending no group problems
		

                                            UPDATE  dbo.dls_utilization
                                            SET     dls_status = 'U'
                                            WHERE	dls_sir_id=@t_sir_id;

                                            SET @i_succ_count = @i_succ_count+ 1;

                                        END TRY
                                        BEGIN CATCH
                                            SET @i_error_no = ERROR_NUMBER();
                                            SET @i_isam_error = ERROR_LINE();
                                            SET @s_error_descr = ERROR_MESSAGE();
                                            IF @i_error_no IN ( -244, -245,
                                                              -246 )
                                                SET @a_error_no = 1000;
		   

		   -- if fatal err, rollback and cont. with next claim header
                                            EXECUTE dbo.dl_get_err_sevr @i_sp_id,
                                                @a_error_no,
                                                @SWV_dl_get_err_sevr OUTPUT;
                                            IF ( @SWV_dl_get_err_sevr ) = 'F'

			-- get num records for header, not already counted
                                                BEGIN
                                                    SELECT  @i_sub_count = COUNT(*)
                                                    FROM    dbo.dls_utilization (NOLOCK)
                                                    WHERE   alt_id = @t_alt_id
                                                            AND dls_batch_id = @p_batch_id
                                                            AND dls_status = 'P';

            		-- can't count the 'P' for the row that caused err,
            		-- it was already counted
                                                    SET @i_total_count = @i_total_count
                                                        + @i_sub_count - 1;
                                                    --ROLLBACK; 
                                                    --BEGIN TRAN;

			-- only set row that failed to "E", tot count will
			-- include all rows for group as processed above
                                                    UPDATE  dbo.dls_utilization
                                                    SET     dls_status = 'E'
                                                    WHERE   dls_sir_id = @t_sir_id;

			-- log error that occurred on current record
                                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                                        @i_sp_id,
                                                 @i_sir_def_id,
        @t_sir_id, @a_error_no;
                            --COMMIT; 

			-- set flag t indicate an error
                                    SET @c_cur_err_flag = 'T';

			-- break out of inner loop & continue with
			-- next claim header
                                                    GOTO SWL_Label4;
                                                END;
                                            ELSE
			-- log warning that occurred on current record
      EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                                    @i_sp_id, @i_sir_def_id,
                                                    @t_sir_id, @a_error_no;
                                        END CATCH;
   END;
                                    FETCH NEXT FROM @c2UtilSir INTO @t_sir_id,
                                        @d_svc_beg, @s_d_proc_code,
                                        @s_tooth_no, @s_surface, @s_quad,
                                        @s_sub_amt, @s_cob_amt, @s_relates_to;
                                END;
                            SWL_Label4:
                            CLOSE @c2UtilSir; -- loads the claim detail records for each claim header


	---------update stats every 100 records-----------------------
                            IF @i_total_count >= ( @i_last_total + 100 )
                                BEGIN
                                    SET @i_error_count = @i_total_count
                                        - @i_succ_count;

	   -----update the stats----------
                                    UPDATE  dbo.dl_bat_statistics
                                    SET     tot_record = @i_total_count ,
                                            tot_success_rec = @i_succ_count ,
                                            tot_fail_rec = @i_error_count
            WHERE   bat_statistics_id = @i_stats_id;
                                    SET @i_last_total = @i_total_count;
                                END;
	

	-- only commit work if no err for this header group
                            --IF @c_cur_err_flag = 'F'
                            --    COMMIT; 
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -244, -245, -246 )
                                SET @a_error_no = 1000; -- db locked by another user -- fatal
	   

	   -- if fatal err, rollback and cont with next grp - else resume
                            EXECUTE @SWV_dl_get_err_sevr = dbo.dl_get_err_sevr @i_sp_id, @a_error_no
                                 
                            IF ( @SWV_dl_get_err_sevr ) = 'F'

		-- get num records for header, not already counted
                                BEGIN
                                    SELECT  @i_sub_count = COUNT(*)
                                    FROM    dbo.dls_utilization (NOLOCK)
                                    WHERE   alt_id = @t_alt_id
                                            AND dls_batch_id = @p_batch_id
                                            AND dls_status = 'P';
                                    SET @i_total_count = @i_total_count
                                        + @i_sub_count;
                                    --ROLLBACK; 
                                    --BEGIN TRAN;

		-- log error that occurred for all effected records
                                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id  
                  FROM   dbo.dls_utilization (NOLOCK)
  WHERE dls_batch_id = @p_batch_id
                  AND   dls_status   = 'P'
 AND   alt_id       = @t_alt_id;
                                    OPEN @SWV_cursor_var1;
                FETCH NEXT FROM @SWV_cursor_var1 INTO @temp_sir_id;
                                    WHILE @@FETCH_STATUS = 0
              BEGIN
                                         EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                                @i_sp_id, @i_sir_def_id,
                                                @temp_sir_id, @a_error_no;

		  -- set all records to "E" for alt_id
                                            UPDATE  dbo.dls_utilization
                                            SET     dls_status = 'E'
                                            WHERE   dls_sir_id = @temp_sir_id;
     FETCH NEXT FROM @SWV_cursor_var1 INTO @temp_sir_id;
                                        END;
                                    CLOSE @SWV_cursor_var1;
                                   -- COMMIT; 

		-- break out of inner loop & continue with next claim header
                                    GOTO SWL_Label3;
                                END;
                            ELSE
		-- log warning that occurred for all effected records
                                BEGIN
                                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT dls_sir_id  
                  FROM   dbo.dls_utilization (NOLOCK)
                  WHERE dls_batch_id = @p_batch_id
                  AND   dls_status   = 'P'
                  AND  alt_id       = @t_alt_id;
                                    OPEN @SWV_cursor_var2;
                                    FETCH NEXT FROM @SWV_cursor_var2 INTO @temp_sir_id;
                                    WHILE @@FETCH_STATUS = 0
                                        BEGIN
                                            EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                                @i_sp_id, @i_sir_def_id,
                                                @temp_sir_id, @a_error_no;
                                            FETCH NEXT FROM @SWV_cursor_var2 INTO @temp_sir_id;
                                        END;
                                    CLOSE @SWV_cursor_var2;
                                END;
                        END CATCH;
                    END;
                    SWL_Label3:
                    FETCH NEXT FROM @c1UtilSir INTO @t_alt_id, @t_pv_tax_id;
                END;
            CLOSE @c1UtilSir;  --end outer loop, based on unique alt_id------------------

            SELECT  @i_succ_count = COUNT(*)
            FROM    dbo.dls_utilization (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'U';
            SET @i_succ_count = @i_succ_count - @i_init_count;
            SET @i_error_count = @i_total_count - @i_succ_count;
            EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_stats_id, @i_total_count,
                @i_succ_count, @i_error_count;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN--TRACE statement has no equivalent in MSSQL
--TRACE OFF;

                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_total_count,
                                                 ' Failed to update statistics');
                    RETURN;
                END;


-- updates this step (sp_id) to S  Success/Complete  --
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

--  updates entire batch status to S Success/Complete  --
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @p_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT(@i_succ_count,
                                         ' records are updated for Batch ',
                                @p_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
			IF @@TRANCOUNT>0
			ROLLBACK TRAN
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
     SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

--TRACE OFF;


--------------------------------------------------------------------------------

--SET DEBUG FILE TO  '/tmp/dlp_up_utilization.trc';
--TRACE ON;

    END;