﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_group_setup]
    @a_config_id INT ,
    @a_def_key CHAR(2) ,
    @a_type CHAR(2) ,
    @a_sir_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT
    
AS
    BEGIN

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_descr VARCHAR(64);

        DECLARE @n_group_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_facility_id INT;

        SET NOCOUNT ON;
        BEGIN TRY
            SET @n_group_id = NULL;
            SET @n_plan_id = NULL;
            SET @n_facility_id = NULL;
            IF @a_def_key = 'AP'
                AND @a_type = 'IS'
                BEGIN
                    SELECT  @n_group_id = dls_group_id ,
                            @n_plan_id = dls_plan_id ,
                            @n_facility_id = facility_id
                    FROM    dbo.dls_elig (NOLOCK)
                    WHERE   dls_sir_id = @a_sir_id;
                    
                END;
            ELSE
                BEGIN
				
                    SELECT  @n_group_id = group_id ,
                            @n_plan_id = plan_id ,
                            @n_facility_id = facility_id
                    FROM    dbo.dlsp_eg_group_plan (NOLOCK)
                    WHERE   config_id = @a_config_id
                            AND def_key = @a_def_key
                            AND type = @a_type;
                    
                END;
				
	
            IF @n_group_id IS NULL
                OR @n_plan_id IS NULL
                BEGIN
                    SET @SWP_Ret_Value = -101;
                    SET @SWP_Ret_Value1 = @n_group_id;
                    SET @SWP_Ret_Value2 = @n_plan_id;
                    SET @SWP_Ret_Value3 = @n_facility_id;
                    RETURN;
                END;
	
            IF @n_facility_id IS NULL
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.[plan] (NOLOCK) ,
                                        dbo.ins_opt (NOLOCK)
                                WHERE   dbo.[plan].plan_id = @n_plan_id
                                        AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                        AND dbo.ins_opt.ins_opt_qual = 'I' )
                    BEGIN
                        SET @SWP_Ret_Value = -102;
                        SET @SWP_Ret_Value1 = @n_group_id;
                        SET @SWP_Ret_Value2 = @n_plan_id;
                        SET @SWP_Ret_Value3 = @n_facility_id;
                        RETURN;
                    END;
		
	
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @n_group_id;
            SET @SWP_Ret_Value2 = @n_plan_id;
            SET @SWP_Ret_Value3 = @n_facility_id;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;