﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_elig_sub_xfrgp]
@a_batch_id INT ,
@a_sir_id INT ,
@a_member_id INT ,
@a_term_date DATE

AS
BEGIN
DECLARE @i_error_no INT;
DECLARE @i_isam_error INT;
DECLARE @s_error_desscr VARCHAR(64);
DECLARE @n_error_no INT;
DECLARE @n_term_mb_gr_pl_id INT;
DECLARE @n_term_group_id INT;
DECLARE @n_term_plan_id INT;
DECLARE @n_gr_pl_date DATE;
DECLARE @s_rate_code CHAR(2);
DECLARE @i_facility_id INT;
DECLARE @d_fac_eff_date DATE;
DECLARE @d_temp_term_date DATE;
DECLARE @new_dls_sir_id integer;
DECLARE @n_process_count integer;
DECLARE @n_succ_count integer;
DECLARE @t_sir_id integer;
DECLARE @t_sub_sir_id integer;
DECLARE @t_subscriber char(2);
DECLARE @t_alt_id char(20);
DECLARE @t_ssn char(11);
DECLARE @t_sub_ssn char(11);
DECLARE @t_sub_alt_id char(20);
DECLARE @t_member_code char(2);
DECLARE @t_last_name char(15);
DECLARE @t_first_name char(15);
DECLARE @t_middle_init char(1);
DECLARE @t_date_of_birth date;
DECLARE @t_student_flag char(1);
DECLARE @t_disable_flag char(1);
DECLARE @t_cobra_flag char(1);
DECLARE @t_address1 char(30);
DECLARE @t_address2 char(30);
DECLARE @t_city char(30);
DECLARE @t_state char(2);
DECLARE @t_zip char(5);
DECLARE @t_zipx char(4);
DECLARE @t_home_phone char(10);
DECLARE @t_home_ext char(4);
DECLARE @t_work_phone char(10);
DECLARE @t_work_ext char(4);
DECLARE @t_rate_code char(2);
DECLARE @t_plan_eff_date date;
DECLARE @t_plan_term_date date;
DECLARE @t_fac_eff_date date;
DECLARE @t_group_id integer;
DECLARE @t_plan_id integer;
DECLARE @t_facility_id integer;
DECLARE @t_def_key char(2);
DECLARE @t_type char(2);
DECLARE @t_sub_id integer;
DECLARE @t_member_id integer;
DECLARE @n_ffs_plan integer;
-- DECLARE @SWV_cursor_var1 CURSOR;
SET NOCOUNT ON;
SET @new_dls_sir_id =0;
--SET @n_process_count =0;
--SET @n_succ_count =0;
SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SET @t_sir_id =0;
SET @t_sub_sir_id =0;
SET @t_subscriber ='';
SET @t_alt_id ='';
SET @t_ssn ='';
SET @t_sub_ssn ='';
SET @t_sub_alt_id ='';
SET @t_member_code ='';
SET @t_last_name ='';
SET @t_first_name ='';
SET @t_middle_init ='';
SET @t_date_of_birth = NULL
SET @t_student_flag ='';
SET @t_disable_flag ='';
SET @t_cobra_flag ='';
SET @t_address1 ='';
SET @t_address2 ='';
SET @t_city ='';
SET @t_state ='';
SET @t_zip ='';
SET @t_zipx ='';
SET @t_home_phone ='';
SET @t_home_ext ='';
SET @t_work_phone ='';
SET @t_work_ext ='';
SET @t_rate_code ='';
SET @t_plan_eff_date = NULL
SET @t_plan_term_date = NULL
SET @t_fac_eff_date = NULL
SET @t_group_id =0;
SET @t_plan_id =0;
SET @t_facility_id =0;
SET @t_def_key ='';
SET @t_type ='';
SET @t_sub_id =0;
SET @t_member_id =0;
SET @n_ffs_plan =0;
BEGIN TRY
SET @d_temp_term_date = NULL;
/* SET @SWV_cursor_var1 = CURSOR FOR SELECT mb_gr_pl_id, group_id, plan_id, eff_gr_pl
FROM dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @a_member_id AND
-- eff_gr_pl <= a_term_date and
exp_gr_pl IS NULL;
OPEN @SWV_cursor_var1;
FETCH NEXT FROM @SWV_cursor_var1 INTO @n_term_mb_gr_pl_id,
@n_term_group_id, @n_term_plan_id, @n_gr_pl_date;
WHILE @@FETCH_STATUS = 0*/


SELECT @t_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_term_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_fac_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_facility_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_def_key = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_def_key' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 3


DECLARE @SWV_cursor_var1 TABLE
(
id INT IDENTITY ,
mb_gr_pl_id int, group_id int, plan_id int, eff_gr_pl date
);
INSERT INTO @SWV_cursor_var1
( mb_gr_pl_id, group_id, plan_id, eff_gr_pl
)
SELECT mb_gr_pl_id, group_id, plan_id, eff_gr_pl
FROM dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @a_member_id AND
exp_gr_pl IS NULL;
DECLARE @cur1_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur1_cnt = COUNT(1)
FROM @SWV_cursor_var1;
WHILE ( @cur_i <= @cur1_cnt )
BEGIN
SELECT @n_term_mb_gr_pl_id=mb_gr_pl_id,
@n_term_group_id=group_id,@n_term_plan_id=plan_id,
@n_gr_pl_date=eff_gr_pl
FROM @SWV_cursor_var1
WHERE id = @cur_i;
SELECT @s_rate_code = rate_code
FROM dbo.rlmbrt (NOLOCK)
WHERE mb_gr_pl_id = @n_term_mb_gr_pl_id
AND exp_rt_date IS NULL;
SELECT @i_facility_id = facility_id ,
@d_fac_eff_date = eff_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_term_mb_gr_pl_id
AND member_id = @a_member_id
AND exp_date IS NULL;
IF @n_gr_pl_date > @a_term_date
SET @d_temp_term_date = @n_gr_pl_date;
ELSE
SET @d_temp_term_date = @a_term_date;
INSERT INTO dbo.dls_elig
( dls_sub_sir_id ,
dls_batch_id ,
member_flag ,
alt_id ,
ssn ,
sub_ssn ,
sub_alt_id ,
member_code ,
last_name ,
first_name ,
middle_init ,
date_of_birth ,
student_flag ,
disable_flag ,
cobra_flag ,
rate_code ,
plan_eff_date ,
plan_term_date ,
facility_eff_date ,
dls_group_id ,
dls_plan_id ,
facility_id ,
def_key ,
type ,
dls_member_id ,
dls_sub_id ,
dls_action_code ,
dls_status ,
dls_source
)
VALUES ( @a_sir_id ,
@a_batch_id ,
'00' ,
@t_alt_id ,
@t_ssn ,
@t_sub_ssn ,
@t_alt_id ,
@t_member_code ,
@t_last_name ,
@t_first_name ,
@t_middle_init ,
CONVERT(DATE, CONVERT(VARCHAR, @t_date_of_birth)) ,
@t_student_flag ,
@t_disable_flag ,
@t_cobra_flag ,
@s_rate_code ,
@n_gr_pl_date ,
@d_temp_term_date ,
@d_fac_eff_date ,
@n_term_group_id ,
@n_term_plan_id ,
@i_facility_id ,
'DF' ,
'DF' ,
@a_member_id ,
@a_member_id ,
'ST' ,
'P' ,
'A'
);

SET @new_dls_sir_id=IDENT_CURRENT('dbo.dls_elig')
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@new_dls_sir_id, 'ST', @d_temp_term_date;

SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_process_count = @n_process_count + 1;
SET @n_succ_count = @n_succ_count + 1;

UPDATE GlobalVar
SET VarValue = @n_process_count
WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3


UPDATE GlobalVar
SET VarValue = @n_succ_count
WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3

/*FETCH NEXT FROM @SWV_cursor_var1 INTO @n_term_mb_gr_pl_id,
@n_term_group_id, @n_term_plan_id, @n_gr_pl_date;*/
SET @cur_i = @cur_i + 1;
END;
--CLOSE @SWV_cursor_var1;
RETURN 1;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
SET @i_isam_error = ERROR_LINE();
SET @s_error_desscr = ERROR_MESSAGE();
RETURN -1;
END CATCH;
SET NOCOUNT OFF;
END;