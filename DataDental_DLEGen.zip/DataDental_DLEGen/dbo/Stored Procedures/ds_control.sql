﻿CREATE PROCEDURE [dbo].[ds_control] @a_oc_id INT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/ 
        DECLARE @ll_count INT;

        DECLARE @i_oc_id INT;
        DECLARE @i_group_id INT;
        DECLARE @s_gp_status CHAR(2);
        DECLARE @i_plan_id INT;
        DECLARE @i_fc_id INT;
        DECLARE @s_fc_status CHAR(2);
        DECLARE @i_mb_gr_pl_id INT;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @d_eff_date DATE;
        DECLARE @d_exp_date DATE;
        DECLARE @i_member_id INT;
        DECLARE @i_family_id INT;
        DECLARE @i_act_sub INT;
        DECLARE @i_act_dep INT;
        DECLARE @i_term_sub INT;
        DECLARE @i_term_dep INT;


        DECLARE @commit_cnt INT;
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;

	--set explain on;
--	set debug file to "ds_control.trc";
--	trace on;
        SET NOCOUNT ON;
        SET LOCK_TIMEOUT -1;


        BEGIN TRAN;
        SET @ll_count = 0;
        SELECT  @ll_count = COUNT(*)
        FROM    sysobjects
        WHERE   name = 'dt_control1';
        IF @ll_count > 0
            DROP TABLE dbo.dt_control1;


        SET @ll_count = 0;
        SELECT  @ll_count = COUNT(*)
        FROM    sysobjects
        WHERE   name = 'dt_control2';
        IF @ll_count > 0
            DROP TABLE dbo.dt_control2;


        CREATE TABLE dbo.dt_control1
            (
              oc_id INT ,
              group_id INT ,
              gp_status CHAR(2) ,
              plan_id INT ,
              act_sub INT ,
              act_dep INT ,
              term_sub INT ,
              term_dep INT
            );
        CREATE INDEX dt_control10 ON dbo.dt_control1 
        (oc_id, 
        group_id, 
        plan_id);

        CREATE TABLE dbo.dt_control2
            (
              oc_id INT ,
              facility_id INT ,
              fc_status CHAR(2) ,
              act_sub INT ,
              act_dep INT ,
              term_sub INT ,
              term_dep INT ,
              cont_i CHAR(1) ,
              cont_p CHAR(1) ,
              cont_s CHAR(1)
            );
        CREATE INDEX dt_control20 ON dbo.dt_control2 
        (oc_id, 
        facility_id);

        CREATE TABLE #dt_fcinfo
            (
              facility_id INT ,
              fc_status CHAR(2) ,
              act_sub INT ,
              act_dep INT ,
              term_sub INT ,
              term_dep INT
            );
        CREATE INDEX dt_fcinfo1 ON #dt_fcinfo 
        (facility_id);
        COMMIT; 
        SET @i_oc_id = @a_oc_id;

        INSERT  INTO #dt_fcinfo
                SELECT DISTINCT
                        a.fc_id ,
                        c.status ,
                        0 ,
                        0 ,
                        0 ,
                        0
                FROM    dbo.net_facility a ( NOLOCK ) ,
                        dbo.net_oper b ( NOLOCK ) ,
                        dbo.fcstat c ( NOLOCK )
                WHERE   b.oc_id = @a_oc_id
                        AND a.net_id = b.net_id
                        AND a.fc_id = c.facility_id
                        AND c.exp_date IS NULL;
        SET @commit_cnt = 0;
        BEGIN TRAN;
        SET @SWV_cursor_var1 = CURSOR  FOR SELECT a.group_id, b.group_status, c.plan_id
	  
   FROM dbo.[group] a (NOLOCK),
    dbo.group_status b (NOLOCK), 
	dbo.rel_gppl c (NOLOCK)
   WHERE a.oc_id = @a_oc_id AND
   a.group_id = b.group_id AND
   b.exp_date IS NULL
   AND a.group_id = c.group_id;
        OPEN @SWV_cursor_var1;
        FETCH NEXT FROM @SWV_cursor_var1 INTO @i_group_id, @s_gp_status,
            @i_plan_id;
        WHILE @@FETCH_STATUS = 0
            BEGIN
                SET @i_act_sub = 0;
                SET @i_act_dep = 0;
                SET @i_term_sub = 0;
                SET @i_term_dep = 0;
                SET @commit_cnt = @commit_cnt + 1;
                IF @commit_cnt > 100
                    BEGIN
                        COMMIT; 
                        BEGIN TRAN;
                        SET @commit_cnt = 0;
                    END;
		
                SET @SWV_cursor_var2 = CURSOR  FOR SELECT a.mb_gr_pl_id, a.eff_gr_pl, a.exp_gr_pl, a.member_id,
				b.facility_id, b.member_id, b.eff_date, b.exp_date
			  
      FROM dbo.rlmbgrpl a (NOLOCK),
	   dbo.rlplfc b (NOLOCK)
      WHERE a.group_id = @i_group_id AND a.plan_id = @i_plan_id AND
      a.mb_gr_pl_id = b.mb_gr_pl_id;
                OPEN @SWV_cursor_var2;
                FETCH NEXT FROM @SWV_cursor_var2 INTO @i_mb_gr_pl_id,
                    @d_eff_gr_pl, @d_exp_gr_pl, @i_family_id, @i_fc_id,
                    @i_member_id, @d_eff_date, @d_exp_date;
                WHILE @@FETCH_STATUS = 0
                    BEGIN
                        IF @i_member_id = @i_family_id
                            IF @d_exp_gr_pl IS NULL
                                AND @d_exp_date IS NULL
                                BEGIN
                                    SET @i_act_sub = @i_act_sub + 1;
                                    UPDATE  #dt_fcinfo
                                    SET     act_sub = act_sub + 1
                                    WHERE   facility_id = @i_fc_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @i_term_sub = @i_term_sub + 1;
                                    UPDATE  #dt_fcinfo
                                    SET     term_sub = term_sub + 1
                                    WHERE   facility_id = @i_fc_id;
                                END;
				
                        ELSE
                            IF @d_exp_gr_pl IS NULL
                                AND @d_exp_date IS NULL
                                BEGIN
                                    SET @i_act_dep = @i_act_dep + 1;
                                    UPDATE  #dt_fcinfo
                                    SET     act_dep = act_dep + 1
                                    WHERE   facility_id = @i_fc_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @i_term_dep = @i_term_dep + 1;
                                    UPDATE  #dt_fcinfo
                                    SET     term_dep = term_dep + 1
                                    WHERE   facility_id = @i_fc_id;
                                END;
				
                        FETCH NEXT FROM @SWV_cursor_var2 INTO @i_mb_gr_pl_id,
                            @d_eff_gr_pl, @d_exp_gr_pl, @i_family_id, @i_fc_id,
                            @i_member_id, @d_eff_date, @d_exp_date;
                    END;
                CLOSE @SWV_cursor_var2;   -- subscriber & dependent end
                INSERT  INTO dbo.dt_control1
                VALUES  ( @i_oc_id, @i_group_id, @s_gp_status, @i_plan_id,
                          @i_act_sub, @i_act_dep, @i_term_sub, @i_term_dep );
                FETCH NEXT FROM @SWV_cursor_var1 INTO @i_group_id,
                    @s_gp_status, @i_plan_id;
            END;
        CLOSE @SWV_cursor_var1; -- Oper Co. end
        COMMIT; 

        BEGIN TRAN;
        INSERT  INTO dbo.dt_control2
                ( oc_id ,
                  facility_id ,
                  fc_status ,
                  act_sub ,
                  act_dep ,
                  term_sub ,
                  term_dep
                )
            SELECT  @i_oc_id ,
                        facility_id ,
                        fc_status ,
                        act_sub ,
                        act_dep ,
                        term_sub ,
                        term_dep
                FROM    #dt_fcinfo;
        UPDATE  dbo.dt_control2
        SET     cont_s = 'X'
        WHERE   EXISTS ( SELECT *
                         FROM   dbo.net_facility
                         WHERE  dbo.net_facility.fc_id = dbo.dt_control2.facility_id
                                AND con_type = 'S' );
        UPDATE  dbo.dt_control2
        SET     cont_i = 'X'
        WHERE   EXISTS ( SELECT fc_id
                         FROM   dbo.net_facility
                         WHERE  dbo.net_facility.fc_id = dbo.dt_control2.facility_id
                                AND con_type = 'PPO' );
        UPDATE  dbo.dt_control2
        SET     cont_p = 'X'
        WHERE   EXISTS ( SELECT fc_id
                         FROM   dbo.net_facility
                         WHERE  dbo.net_facility.fc_id = dbo.dt_control2.facility_id
                                AND ( con_type = 'HMO'
                                      OR con_type = 'RFS'
                                    ) );

        DROP TABLE #dt_fcinfo;

        COMMIT; 
        SET NOCOUNT OFF;

--trace off;
    END;