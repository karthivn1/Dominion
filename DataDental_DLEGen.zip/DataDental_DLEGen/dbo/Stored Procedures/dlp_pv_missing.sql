﻿CREATE PROCEDURE [dbo].[dlp_pv_missing]
    @a_batch_id INT ,
    @a_term_eff_date DATE
    
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @a_error_no INT;
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
		DECLARE @n_in_transaction CHAR(1);
        DECLARE @s_error CHAR(1);
		DECLARE @pv_sir_id INT;
        DECLARE @i_fcassoc_type CHAR(1);
        DECLARE @i_fcassoc_eff DATE;
        DECLARE @i_fc_id INT;
        DECLARE @i_pv_id INT;
        DECLARE @i_pvfc_cnt INT;
        DECLARE @fc_alt_id CHAR(20);
        DECLARE @pv_alt_id CHAR(20);
        DECLARE @pv_tax_id CHAR(9);
        DECLARE @pv_tin CHAR(1);
        DECLARE @pv_first_name CHAR(20);
        DECLARE @pv_last_name CHAR(30);
        DECLARE @pv_discipline CHAR(2);
        DECLARE @pv_stat_eff DATE;
        DECLARE @pv_license CHAR(9);
        DECLARE @pv_state CHAR(2);
        DECLARE @pv_sp_id INT
        DECLARE @pv_sir_def_id INT
        DECLARE @pv_config_id INT
        DECLARE @n_process_count INT
        DECLARE @n_error_count INT
        DECLARE @n_succ_count INT
        --DECLARE @SWV_cursor_var1 CURSOR;


        SET NOCOUNT ON;
        SET @pv_sp_id = 0
        
        SET @pv_sir_def_id = 0
        
        SET @pv_config_id = 0
        
        --SET @n_process_count = 0
        
        SET @n_error_count = 0
        
        --SET @n_succ_count = 0
		SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7
        
        BEGIN TRY
            
            SET @n_in_transaction = 'N';


			DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 fc_id INT, 
						 pv_id INT
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								fc_id, pv_id
                                )
								SELECT DISTINCT fc_id, pv_id

      FROM dbo.fc_assoc (NOLOCK)
      WHERE exp_date IS NULL
      AND fc_assoc_id NOT IN(SELECT a.fc_assoc_id
      FROM dbo.fc_assoc a (NOLOCK),
	  dbo.dls_pv_assoc b (NOLOCK)
      WHERE b.dls_batch_id = @a_batch_id
      AND b.dls_source = 'F'
      AND b.dls_facility_id = a.fc_id
      AND b.dls_provider_id = a.pv_id
      AND a.exp_date IS NULL)

	  DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;
			/*
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT DISTINCT fc_id, pv_id

      FROM dbo.fc_assoc (NOLOCK)
      WHERE exp_date IS NULL
      AND fc_assoc_id NOT IN(SELECT a.fc_assoc_id
      FROM dbo.fc_assoc a (NOLOCK),
	  dbo.dls_pv_assoc b (NOLOCK)
      WHERE b.dls_batch_id = @a_batch_id
      AND b.dls_source = 'F'
      AND b.dls_facility_id = a.fc_id
      AND b.dls_provider_id = a.pv_id
      AND a.exp_date IS NULL);
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_fc_id, @i_pv_id;
            WHILE @@FETCH_STATUS = 0
			*/
               WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT @i_fc_id=fc_id ,
                    @i_pv_id= pv_id
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;
                    BEGIN
                        BEGIN TRY
                            IF @n_in_transaction = 'N'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'Y';
                                END;
	
         SET @i_fcassoc_type = NULL;
                            SET @i_fcassoc_eff = NULL;
                            SET @a_error_no = 0;
                            SET @pv_sir_id = 0;
 SET @s_error = 'N';
                            SELECT  @i_pvfc_cnt = COUNT(*)
            FROM    dbo.fc_assoc (NOLOCK)
                            WHERE   fc_id = @i_fc_id
                                    AND pv_id = @i_pv_id
                                    AND exp_date IS NULL;
                            IF @i_pvfc_cnt > 1
	--	RAISE EXCEPTION -746, 340, "Multiple Facility Association records found in FCPV Termination";
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                            
                                            SET @n_in_transaction = 'N';
                                        END;
		
	--	let n_process_count = n_process_count + 1;
                                    GOTO SWL_Label2;
                                END;
	
                            SELECT  @i_fcassoc_type = assoc_type ,
                                    @i_fcassoc_eff = eff_date
                            FROM    dbo.fc_assoc (NOLOCK)
                            WHERE   fc_id = @i_fc_id
                                    AND pv_id = @i_pv_id
                                    AND exp_date IS NULL;
                            
                            IF @i_fcassoc_eff IS NULL
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                             
                                            SET @n_in_transaction = 'N';
                                        END;
		
                                    GOTO SWL_Label2;
                                END;
	
                            IF @a_term_eff_date < @i_fcassoc_eff
	--	RAISE EXCEPTION -746, 350, "Intended FCPV Expiration Date is before DataDental Association Effective Date";
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                            
                                            SET @n_in_transaction = 'N';
                                        END;
		
	--	let n_process_count = n_process_count + 1;
                                    GOTO SWL_Label2;
                                END;
	
                            SELECT  @fc_alt_id = alt_id
                            FROM    dbo.facility (NOLOCK)
                            WHERE   fc_id = @i_fc_id;
                           
                            SELECT  @pv_alt_id = alt_id ,
                                    @pv_tax_id = tax_id ,
                                    @pv_tin = tin ,
                                    @pv_first_name = first_name ,
                                    @pv_last_name = last_name ,
                                    @pv_discipline = discipline
                            FROM    dbo.providers (NOLOCK)
                            WHERE   pv_id = @i_pv_id;
                            
                            SELECT  @pv_stat_eff = eff_date
  FROM    dbo.pv_status (NOLOCK)
                            WHERE   pv_id = @i_pv_id
                                    AND pv_status = 'AC'
                                    AND exp_date IS NULL;
                           

/*
	SELECT license, state
	INTO pv_license, pv_state
	FROM pv_license
	WHERE pv_id = i_pv_id
	AND exp_date is null;
*/


                            INSERT  INTO dbo.dls_pv_assoc
                                    ( dls_batch_id ,
                                      alt_id ,
                                      pv_tax_id ,
                                      pv_license ,
                                      pv_lic_state ,
                                      tin ,
                                      pv_first_name ,
  pv_last_name ,
      discipline ,
                                      pv_stat_eff_date ,
                                      fc_assoc_fc_id ,
                                      fc_assoc_type ,
                                      fc_assoc_eff_date ,
                                      fc_assoc_exp_date ,
                                      dls_facility_id ,
                                      dls_provider_id ,
                                      dls_action_code ,
                                      dls_status ,
                                      dls_source
                                    )
                            VALUES  ( @a_batch_id ,
                                      @pv_alt_id ,
                                      @pv_tax_id ,
                                      NULL ,
                                      NULL ,
                                      @pv_tin ,
                                      @pv_first_name ,
                                      @pv_last_name ,
                                      @pv_discipline ,
                                      CAST(@pv_stat_eff AS CHAR(10)) ,
                                      @fc_alt_id ,
                                      @i_fcassoc_type ,
                                      CAST(@i_fcassoc_eff AS CHAR(10)) ,
                                      CAST(@a_term_eff_date AS CHAR(10)) ,
                                      @i_fc_id ,
                                      @i_pv_id ,
                                      'AT' ,
                                      'P' ,
                                      'A'
                                    );
	
                            SELECT  @pv_sir_id = MAX(dls_sir_id)
                            FROM    dbo.dls_pv_assoc
                            WHERE   dls_batch_id = @a_batch_id;
                           
                            EXECUTE @i_error_no = dbo.dl_log_action @a_batch_id,
                                @pv_sir_id, 'AT', @a_term_eff_date;
                            
							SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
						SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7

                            SET @n_process_count = @n_process_count + 1;
                            
                            SET @n_succ_count = @n_succ_count + 1;
                            
							
						UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 7
						UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 7

                            IF @n_in_transaction = 'Y'
                                BEGIN
                                   
                                    SET @n_in_transaction = 'N';
                                END;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    BEGIN
									RAISERROR(@s_error_descr,16,1);
									RETURN
								END
                                END;
		
                            
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @pv_sp_id, @pv_sir_def_id, @pv_sir_id,
                                @a_error_no;
                        END CATCH;
                    END;
                    SWL_Label2:
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_fc_id, @i_pv_id;
					SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @SWV_cursor_var1;


--trace off;

            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
  IF @n_in_transaction = 'Y'
                BEGIN
                   
                    SET @n_in_transaction = 'N';
                END;
	
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;




--set debug file to "/tmp/dlp_pv_missing.trc";
--trace on;

    END;