﻿CREATE PROCEDURE [dbo].[SWPGetGlVar]
    @name VARCHAR(255) ,
    @value VARBINARY(8000) OUTPUT
    
AS
    SELECT  @value = value
    FROM    ##SwtGlVar
    WHERE   spid = @@spid
            AND name = @name;