﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
/*********************************************************************************
DATE				: 08/02/2016
MODIFIED BY			: COGNIZANT
CHANGE DESCRIPTION	: DATE conversion issue
CHANGE NUMBER		: CH001
*********************************************************************************/
CREATE PROCEDURE [dbo].[dlp_check_pd]
    @a_batch_id INT ,
    @t_sir_id INT ,
    @i_msg_id INT ,
    @i_gp_id INT ,
    @i_pl_id INT ,
    @gpplrt_eff DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(2) = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 DATE = NULL OUTPUT
    

/*error variable*/
AS
    BEGIN

        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
   
        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @n_error_count INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @has_producer CHAR(1);
/* paramater variable*/

/*member info in sir table*/


        DECLARE @d_msg_id INT;
        DECLARE @d_bill_type CHAR(2);
        DECLARE @d_zip_id INT;
        DECLARE @d_city CHAR(30);
        DECLARE @d_state CHAR(2);
        DECLARE @d_county CHAR(30);
        DECLARE @d_gp_state CHAR(2);
        DECLARE @d_comm_scheme_id INT;
        DECLARE @as_msg_id INT;
        DECLARE @as_gp_id INT;
        DECLARE @as_pl_id INT;
        DECLARE @as_fc_id INT;
        DECLARE @as_gpplrt_eff DATE;
        DECLARE @as_fc_eff DATE;
        DECLARE @as_term_date DATE;
        DECLARE @as_pd_id INT;
        DECLARE @as_pdcomm_eff DATE;
        DECLARE @as_action_code CHAR(2);
        DECLARE @PdGp CHAR(1);
        DECLARE @Action CHAR(2);
        DECLARE @InsType CHAR(5);
        DECLARE @InsOpt CHAR(5);
        DECLARE @iCount INT;
        DECLARE @TmpProdID INT;
        DECLARE @iMatchCount INT;
        DECLARE @LicNo CHAR(9);
        DECLARE @ProdName CHAR(30);
        DECLARE @LastName CHAR(20);
        DECLARE @FirstName CHAR(20);
        DECLARE @CommID CHAR(5);
        DECLARE @ProdType CHAR(2);

DECLARE @sg_sp_id integer;
DECLARE @sg_sir_def_id integer;
DECLARE @sg_sir_def_name varchar(14);
DECLARE @sg_proc_name varchar(14);
DECLARE @sg_config_id integer;
DECLARE @n_has_facility_id char(1);
DECLARE @n_multiple_plans char(1);
DECLARE @n_allow_pl_change char(1);
DECLARE @n_multiple_fc char(1);
DECLARE @n_allow_fc_change char(1);
DECLARE @n_def_eff_date char(10);
DECLARE @n_def_exp_date char(10);
DECLARE @n_has_term_date char(1);
DECLARE @d_def_eff_date date;
DECLARE @d_def_exp_date date;
DECLARE @s_dls_sir_id integer;
DECLARE @s_dls_sub_sir_id integer;
DECLARE @s_member_flag char(2);
DECLARE @s_msg_group_id integer ;
DECLARE @s_plan_id integer;
DECLARE @s_facility_id integer;
DECLARE @s_mb_gppl_eff_date char(10);
DECLARE @s_mb_fc_eff_date char(10);
DECLARE @s_mb_term_date char(10);
DECLARE @s_address1 char(30);
DECLARE @s_address2 char(30);
DECLARE @s_city char(30);
DECLARE @s_state char(2);
DECLARE @s_zip char(5);
DECLARE @s_zipx char(4);
DECLARE @s_producer_id integer;
DECLARE @s_comm_scheme_id char(5);
DECLARE @s_pd_type char(2);
DECLARE @s_license_number char(9);
DECLARE @s_selling_period char(1);
DECLARE @s_pdcomm_eff_date char(10);

    -- DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_RaiseMsg VARCHAR(400);
        DECLARE @v_Null INT;
        SET NOCOUNT ON;
        SET @sg_sp_id =0;
      
        SET @sg_sir_def_id =0;
        
        SET @sg_sir_def_name ='';
        
        SET @sg_proc_name ='';
        
        SET @sg_config_id =0;
        
        SET @n_has_facility_id ='';
        
        SET @n_multiple_plans ='';
        
        SET @n_allow_pl_change ='';
        
        SET @n_multiple_fc ='';
        
        SET @n_allow_fc_change ='';
        
        SET @n_def_eff_date ='';
       
        SET @n_def_exp_date ='';
        
        SET @n_has_term_date ='';
        
        SET @d_def_eff_date = NULL;
        
        SET @d_def_exp_date = NULL;
        
        SET @s_dls_sir_id =0;
        
        SET @s_dls_sub_sir_id =0;
        
        SET @s_member_flag ='';
        
        SET @s_msg_group_id =0;
        
        SET @s_plan_id =0;
       
        SET @s_facility_id =0;
        
        SET @s_mb_gppl_eff_date ='';
       
        SET @s_mb_fc_eff_date ='';
        
        SET @s_mb_term_date ='';
        
        SET @s_address1 ='';
        
        SET @s_address2 ='';
        
        SET @s_city ='';
        
        SET @s_state ='';
        
        SET @s_zip ='';
        
        SET @s_zipx ='';
        
        SET @s_producer_id =0;
        
        SET @s_comm_scheme_id ='';
        
        SET @s_pd_type ='';
        
        SET @s_license_number ='';
        
        SET @s_selling_period ='';
        
        SET @s_pdcomm_eff_date ='';
        
        BEGIN TRY
            
            SET @s_error = 'N';
            SET @a_error_no = 0;
            SET @as_msg_id = @i_msg_id;
            SET @as_gp_id = @i_gp_id;
            SET @as_pl_id = @i_pl_id;
            SET @as_fc_id = NULL;
            SET @as_gpplrt_eff = @gpplrt_eff;
            SET @as_fc_eff = NULL;
            SET @as_term_date = NULL;
            SET @as_pd_id = NULL;
            SET @as_pdcomm_eff = NULL;
            SET @as_action_code = NULL;
            SET @has_producer = NULL;
            SET @PdGp = NULL;
            SET @Action = NULL;
            SET @InsType = NULL;
            SET @InsOpt = NULL;
            SET @iCount = 0;
            SET @as_action_code = 'CA';
            SET @TmpProdID = 0;
            SET @iMatchCount = 0;
            SET @LicNo = NULL;
            SET @ProdName = NULL;
            SET @LastName = NULL;
            SET @FirstName = NULL;
            SET @CommID = NULL;
            SET @ProdType = NULL;
            SET @a_error_no = 115;
            
		select @s_pd_type = VarValue from GlobalVar(NOLOCK) where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_license_number = VarValue from GlobalVar(NOLOCK) where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_producer_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_producer_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_selling_period = VarValue from GlobalVar(NOLOCK) where VarName = 's_selling_period' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_pdcomm_eff_date = VarValue from GlobalVar(NOLOCK) where VarName = 's_pdcomm_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_comm_scheme_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 1
		
            IF @s_producer_id IS NULL
                OR @s_producer_id = 0
                BEGIN
                    SET @as_action_code = NULL;
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = @as_action_code;
                    SET @SWP_Ret_Value2 = @as_pd_id;
                    SET @SWP_Ret_Value3 = @as_gpplrt_eff;
                 RETURN;
                END;
            ELSE
                BEGIN
                    
                    SET @as_pd_id = @s_producer_id;
                END;
	
           IF ( ( @s_zip IS NOT NULL
                   AND @s_zip <> ''
                 )
                 AND LEN(@s_zip) > 0
               )
                BEGIN
                    SELECT  @d_zip_id = zip_id ,
                            @d_city = city ,
                            @d_state = state_code ,
                            @d_county = county
                    FROM    dbo.usa_zip (NOLOCK)
                    WHERE   zip_code = @s_zip;
                   
                END;
	
            IF ( @d_state IS NOT NULL
                 AND @d_state <> ''
          )
                SET @d_gp_state = @d_state;
            ELSE
                BEGIN
                    SET @a_error_no = 117;
                    SELECT  @d_gp_state = state
                    FROM    dbo.address (NOLOCK)
                    WHERE   subsys_code = 'GP'
                            AND sys_rec_id = @as_msg_id
                            AND addr_type = 'L';
                    
                END;
	
            IF ( ( @d_gp_state IS NULL
                   OR @d_gp_state = ''
                 )
                 OR LEN(@d_gp_state) = 0
               )
                BEGIN
                    RAISERROR('State could not be determined from the provided information',
         16,1);
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @as_action_code;
                    SET @SWP_Ret_Value2 = @as_pd_id;
                    SET @SWP_Ret_Value3 = @as_pdcomm_eff;
                    RETURN;
                END;
	
            
            IF ( @s_pd_type IS NOT NULL
                 AND @s_pd_type <> ''
               )
                AND LEN(@s_pd_type) <> 0
                BEGIN
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.typ_table (NOLOCK)
                                    WHERE   subsys_code = 'PD'
                                            AND tab_name = 'producer type'
                                            AND code = @s_pd_type )
                        RAISERROR('Producer Type is not defined in Common Type Table',16,1);
		
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.pdstat (NOLOCK)
                                    WHERE   producer_id = @as_pd_id
                                            AND status = 'AC'
                                            AND producer_type = @s_pd_type )
                        RAISERROR('Producer Type is not with Active Status Producer record',16,
            1);
                END;
	
           
            IF ( @s_license_number IS NOT NULL
                 AND @s_license_number <> ''
               )
                AND LEN(@s_license_number) <> 0
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.pdl_d (NOLOCK)
                                WHERE   producer_id = @as_pd_id
                                        AND license_number = @s_license_number )
                    RAISERROR('Producer License Number is not in Producer License record',
            16,1);
		
	
            IF ( @s_selling_period IS NOT NULL
                 AND @s_selling_period <> ''
               )
                AND LEN(@s_selling_period) <> 0
                BEGIN
                   
                    IF @s_selling_period NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Selling Producer Indicator',16,1);
                END;
	
            IF ( @s_pdcomm_eff_date IS NOT NULL
                 AND @s_pdcomm_eff_date <> ''
               )
                AND LEN(@s_pdcomm_eff_date) <> 0
                BEGIN
                    SET @a_error_no = 127;
                    
                    SET @as_pdcomm_eff = CAST(@s_pdcomm_eff_date AS DATE); --CH001
                    IF DATEPART(DAY, @as_pdcomm_eff) <> 1
                        RAISERROR('GP PD Commission Eff Date is not first of the month',16,1);
		
                    IF @as_pdcomm_eff < @as_gpplrt_eff
                        RAISERROR('GP PD Commission Eff Date is before Member GP PL RT Eff Date',
            16,1);
		
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.pdstat (NOLOCK)
                                    WHERE   producer_id = @as_pd_id
                                            AND status = 'AC'
                                            AND eff_date <= @as_pdcomm_eff
          AND ( exp_date IS NULL
                                                  OR @as_pdcomm_eff < exp_date
                                                ) )
                        RAISERROR('Invalid GP PD Commission Eff Date by Producer Status',16,1);
		
                    IF ( @d_gp_state IS NOT NULL
                         AND @d_gp_state <> ''
                       )
                        AND NOT EXISTS ( SELECT *
                                         FROM   dbo.pdl_d (NOLOCK)
                                         WHERE  producer_id = @as_pd_id
                                                AND issuing_state = @d_gp_state
                                                AND eff_date <= @as_pdcomm_eff
                                                AND ( exp_date IS NULL
                                                      OR @as_pdcomm_eff < exp_date
                                                    ) )
                        RAISERROR('Invalid GP PD Commission Eff Date by Producer License',16,1);
                END;
	
            IF @as_pdcomm_eff IS NULL
                BEGIN
                    SET @v_Null = 0;
                END;
            ELSE
                SET @as_gpplrt_eff = @as_pdcomm_eff;
	
            IF ( @as_gp_id IS NOT NULL
                 AND @as_gp_id > 0
               )
                BEGIN
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rel_gppl (NOLOCK)
                                    WHERE   group_id = @as_gp_id
                                            AND plan_id = @as_pl_id
                                            AND eff_date <= @as_gpplrt_eff
                                            AND ( exp_date IS NULL
                                                  OR @as_gpplrt_eff < exp_date
                                                ) )
                        RAISERROR('Invalid GP PD Commission Eff Date by SG Plan Relation',16,1);
		   
                    IF EXISTS ( SELECT  dbo.group_pdcomm.group_pdcomm_id
                                FROM    dbo.group_pdcomm (NOLOCK)
                                WHERE   ( dbo.group_pdcomm.group_id = @as_gp_id )
                                        AND ( dbo.group_pdcomm.plan_id = @as_pl_id )
                                        AND ( dbo.group_pdcomm.prod_id = @as_pd_id )
                                        AND ( dbo.group_pdcomm.eff_date < @as_gpplrt_eff
                                              AND ( dbo.group_pdcomm.exp_date > @as_gpplrt_eff
                                                    OR dbo.group_pdcomm.exp_date IS NULL
                                                  )
                                            ) )
					-- This EXCEPTION could be removed when functionality to expire or modify is added
              RAISERROR('PRODUCER is already active in group',16,1);
                END;
			-- Check if Producer alreay exists and is active in group
			
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.rel_gppl (NOLOCK)
                                WHERE   group_id = @as_msg_id
                                        AND plan_id = @as_pl_id
                                        AND eff_date <= @as_gpplrt_eff
                                        AND ( exp_date IS NULL
                                              OR @as_gpplrt_eff < exp_date
                                            ) )
                    RAISERROR('Invalid GP PD Commission Eff Date by MSG Plan Relation',16,
         1);
		   

            IF ( @s_comm_scheme_id IS NOT NULL
                 AND @s_comm_scheme_id <> ''
               )
                AND LEN(@s_comm_scheme_id) <> 0
                BEGIN
                    SET @a_error_no = 120;
 
                    SET @d_comm_scheme_id = @s_comm_scheme_id;
           IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.comm_scheme (NOLOCK)
                                    WHERE   comm_scheme_id = @d_comm_scheme_id )
                        RAISERROR('Invalid Producer Commission Scheme ID value',16,1);
                END;
	
            SELECT  @PdGp = UPPER(add_inter_pd_to_gp)
            FROM    dbo.dds_default (NOLOCK);
            
            IF ( @PdGp IS NULL
                 OR @PdGp = ''
               )
                SET @PdGp = 'N'; 
   
            SELECT  @Action = [action]
            FROM    dbo.typ_table (NOLOCK)
            WHERE   subsys_code = 'PD'
                    AND tab_name = 'producer type'
                    AND code = ( SELECT dbo.pdstat.producer_type
                                 FROM   dbo.pd (NOLOCK) ,
                                        dbo.pdstat (NOLOCK)
                                 WHERE  dbo.pd.producer_id = @as_pd_id
                                        AND dbo.pdstat.producer_id = @as_pd_id
                                        AND dbo.pd.producer_id = dbo.pdstat.producer_id
                                        AND dbo.pdstat.status = 'AC'
                                        AND dbo.pdstat.eff_date <= @as_gpplrt_eff
                                        AND ( dbo.pdstat.exp_date IS NULL
                                              OR dbo.pdstat.exp_date > @as_gpplrt_eff
                                            )
                               );
            
            SELECT  @as_pd_id = producer_id
            FROM    dbo.pd (NOLOCK)
            WHERE   producer_id = @s_producer_id;
            
            IF @PdGp = 'Y'
                AND ( @Action = 'AM'
                      OR @Action = 'GS'
                      OR @Action = 'SD'
                    )
                BEGIN
                    SELECT  @TmpProdID = dbo.pd.producer_id ,
        @ProdName = dbo.pd.producer_name ,
                            @LastName = dbo.pd.last_name ,
                            @FirstName = dbo.pd.first_name ,
                            @ProdType = dbo.pdstat.producer_type
                    FROM    dbo.pd (NOLOCK) ,
                            dbo.pdstat (NOLOCK)
                    WHERE   dbo.pd.producer_id = @as_pd_id
                            AND dbo.pdstat.producer_id = @as_pd_id
                            AND dbo.pdstat.status = 'AC'
                            AND dbo.pdstat.eff_date <= @as_gpplrt_eff
                            AND ( dbo.pdstat.exp_date IS NULL
                                  OR dbo.pdstat.exp_date > @as_gpplrt_eff
                                );
                 
                END;
            ELSE
                IF ( @d_comm_scheme_id IS NOT NULL
                     AND LEN(@d_comm_scheme_id) <> 0
                   )
                    BEGIN
                        SELECT  @TmpProdID = dbo.pd.producer_id ,
                                @ProdName = dbo.pd.producer_name ,
                                @LastName = dbo.pd.last_name ,
                                @FirstName = dbo.pd.first_name ,
                                @CommID = dbo.rlpdpl.comm_scheme_id ,
                                @ProdType = dbo.pdstat.producer_type
                        FROM    dbo.pd (NOLOCK) ,
                                dbo.pdstat (NOLOCK) ,
                                dbo.rlpdpl (NOLOCK)
                        WHERE   dbo.rlpdpl.plan_id = @as_pl_id
                                AND dbo.pd.producer_id = @as_pd_id
                                AND dbo.pdstat.producer_id = @as_pd_id
                                AND dbo.rlpdpl.producer_id = @as_pd_id
                                AND dbo.rlpdpl.comm_scheme_id = @d_comm_scheme_id
                                AND dbo.pd.producer_id = dbo.pdstat.producer_id
                                AND dbo.pd.producer_id = dbo.rlpdpl.producer_id
                     AND dbo.pdstat.status = 'AC'
                                AND dbo.pdstat.eff_date <= @as_gpplrt_eff
                                AND ( dbo.pdstat.exp_date IS NULL
                                      OR dbo.pdstat.exp_date > @as_gpplrt_eff
                                    )
                                AND dbo.rlpdpl.eff_date <= @as_gpplrt_eff
                                AND ( dbo.rlpdpl.exp_date IS NULL
                                      OR dbo.rlpdpl.exp_date > @as_gpplrt_eff
                                    );
                     
                    END;
                ELSE
                    BEGIN
                        SELECT  @TmpProdID = dbo.pd.producer_id ,
                                @ProdName = dbo.pd.producer_name ,
                                @LastName = dbo.pd.last_name ,
                                @FirstName = dbo.pd.first_name ,
                                @CommID = dbo.rlpdpl.comm_scheme_id ,
                                @ProdType = dbo.pdstat.producer_type
                        FROM    dbo.pd (NOLOCK) ,
                                dbo.pdstat (NOLOCK) ,
                                dbo.rlpdpl (NOLOCK)
                        WHERE   dbo.rlpdpl.plan_id = @as_pl_id
                                AND dbo.pd.producer_id = @as_pd_id
                                AND dbo.pdstat.producer_id = @as_pd_id
                                AND dbo.rlpdpl.producer_id = @as_pd_id
                                AND dbo.pd.producer_id = dbo.pdstat.producer_id
                                AND dbo.pd.producer_id = dbo.rlpdpl.producer_id
                                AND dbo.pdstat.status = 'AC'
                                AND dbo.pdstat.eff_date <= @as_gpplrt_eff
                                AND ( dbo.pdstat.exp_date IS NULL
                                      OR dbo.pdstat.exp_date > @as_gpplrt_eff
                                    )
                                AND dbo.rlpdpl.eff_date <= @as_gpplrt_eff
                                AND ( dbo.rlpdpl.exp_date IS NULL
                                      OR dbo.rlpdpl.exp_date > @as_gpplrt_eff
                                    );
                    
                    END;
			
		
            IF ( @TmpProdID IS NULL )
                OR @TmpProdID = 0
                RAISERROR('Producer not active or does not sell plan based on the effective date.',16,1);
		
            SELECT  @InsOpt = ins_opt ,
                    @InsType = ins_type
            FROM    dbo.[plan] (NOLOCK)
            WHERE   plan_id = @as_pl_id;
           
            SELECT  @iCount = COUNT(*)
            FROM    dbo.ins_opt (NOLOCK) ,
                    dbo.pl_license_req (NOLOCK)
            WHERE   dbo.ins_opt.ins_opt_qual = dbo.pl_license_req.ins_opt_qual
                    AND dbo.pl_license_req.state_code = @d_gp_state
                    AND dbo.pl_license_req.ins_type = @InsType
                    AND dbo.ins_opt.ins_opt = @InsOpt
                    AND dbo.pl_license_req.eff_date <= @as_gpplrt_eff
                    AND ( dbo.pl_license_req.exp_date IS NULL
                          OR dbo.pl_license_req.exp_date > @as_gpplrt_eff
                        );
            SET @iMatchCount = 0;
            /*
			SET @SWV_cursor_var1 = CURSOR  FOR SELECT dbo.pdl_d.license_number
	  
      FROM dbo.pdl_d (NOLOCK)
      WHERE dbo.pdl_d.producer_id = @as_pd_id
      AND dbo.pdl_d.issuing_state = @d_gp_state
      AND CONVERT(DATETIME2(0),CONVERT(CHAR,MONTH(dbo.pdl_d.eff_date))+'-'+CONVERT(CHAR,1)+'-'+CONVERT(CHAR,YEAR(dbo.pdl_d.eff_date))) <= @as_gpplrt_eff
      AND (dbo.pdl_d.exp_date IS NULL OR dbo.pdl_d.exp_date > @as_gpplrt_eff)
      AND dbo.pdl_d.license_type IN(SELECT dbo.pl_license_req.license_type
      FROM dbo.ins_opt (NOLOCK), dbo.pl_license_req (NOLOCK)
      WHERE dbo.ins_opt.ins_opt_qual = dbo.pl_license_req.ins_opt_qual
      AND dbo.pl_license_req.state_code = @d_gp_state
      AND dbo.pl_license_req.ins_type = @InsType
      AND dbo.ins_opt.ins_opt = @InsOpt
      AND dbo.pl_license_req.eff_date <= @as_gpplrt_eff
      AND (dbo.pl_license_req.exp_date IS NULL OR
      dbo.pl_license_req.exp_date > @as_gpplrt_eff));
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @LicNo;
            WHILE @@FETCH_STATUS = 0
			*/
			DECLARE @SWV_cursor_var1 TABLE
            (
              id INT IDENTITY ,
              license_number char(10) 
              
            );

        INSERT  INTO @SWV_cursor_var1
                ( license_number
                )
                SELECT dbo.pdl_d.license_number
	  
      FROM dbo.pdl_d (NOLOCK)
      WHERE dbo.pdl_d.producer_id = @as_pd_id
      AND dbo.pdl_d.issuing_state = @d_gp_state
      AND CONVERT(DATETIME2(0),CONVERT(CHAR,MONTH(dbo.pdl_d.eff_date))+'-'+CONVERT(CHAR,1)+'-'+CONVERT(CHAR,YEAR(dbo.pdl_d.eff_date))) <= @as_gpplrt_eff
      AND (dbo.pdl_d.exp_date IS NULL OR dbo.pdl_d.exp_date > @as_gpplrt_eff)
      AND dbo.pdl_d.license_type IN(SELECT dbo.pl_license_req.license_type
      FROM dbo.ins_opt (NOLOCK), dbo.pl_license_req (NOLOCK)
      WHERE dbo.ins_opt.ins_opt_qual = dbo.pl_license_req.ins_opt_qual
      AND dbo.pl_license_req.state_code = @d_gp_state
      AND dbo.pl_license_req.ins_type = @InsType
      AND dbo.ins_opt.ins_opt = @InsOpt
      AND dbo.pl_license_req.eff_date <= @as_gpplrt_eff
      AND (dbo.pl_license_req.exp_date IS NULL OR
      dbo.pl_license_req.exp_date > @as_gpplrt_eff));

        DECLARE @cur1_cnt INT ,
            @cur_i INT;

        SET @cur_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur1_cnt = COUNT(1)
        FROM    @SWV_cursor_var1;
	
	WHILE ( @cur_i <= @cur1_cnt )
            BEGIN
				SELECT  @LicNo= license_number
                FROM    @SWV_cursor_var1
                WHERE   id = @cur_i;

                    IF ( ( @s_license_number IS NOT NULL
                           AND @s_license_number <> ''
                         )
                         AND @s_license_number = @LicNo
                       )
                        GOTO SWL_Label2;
			
                    SET @iMatchCount = @iMatchCount + 1;
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @LicNo;
					 SET @cur_i = @cur_i + 1;
                END;
            SWL_Label2:
            --CLOSE @SWV_cursor_var1;
            IF @iMatchCount <> 0
          AND ( @LicNo IS NULL
                      OR @LicNo = ''
                    )
                BEGIN
                    SET @SWV_RaiseMsg = 'Producer does not have required license in State: '
                        + @d_gp_state + ' Ins Type: ' + @InsType
                        + ' Ins Opt: ' + @InsOpt
                        + ' System will hold commissions until licensed.';
                    RAISERROR(@SWV_RaiseMsg,16,1);
                END;
	
            IF ( ( @s_license_number IS NOT NULL
                   AND @s_license_number <> ''
                 )
                 AND @s_license_number <> @LicNo
               )
                RAISERROR('Producer does not have the provided license in State: ',16,
         1);
	
--End If;
	
--trace off;
            IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @as_action_code;
                    SET @SWP_Ret_Value2 = @as_pd_id;
                    SET @SWP_Ret_Value3 = @as_gpplrt_eff;
                    RETURN;
                END;
            ELSE
                BEGIN
					UPDATE dbo.GlobalVar set VarValue = @as_pd_id where VarName = 's_producer_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @ProdType where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @LicNo where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_selling_period where VarName = 's_selling_period' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @as_gpplrt_eff where VarName = 's_pdcomm_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @CommID where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 1

                    SET @s_producer_id = @as_pd_id;
                   
                    SET @s_comm_scheme_id = @CommID;
                    
                    SET @s_pd_type = @ProdType;
                    
                    SET @s_license_number = @LicNo;
                   
                    SET @s_selling_period = @s_selling_period;
                    
                    SET @s_pdcomm_eff_date = @as_gpplrt_eff;
                   
                    UPDATE  dbo.dls_sg_member
                    SET     producer_id = @s_producer_id ,
                            comm_scheme_id = @s_comm_scheme_id ,
                            license_number = @s_license_number ,
                            selling_period = @s_selling_period ,
                            pdcomm_eff_date = @s_pdcomm_eff_date
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @t_sir_id;
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = @as_action_code;
                    SET @SWP_Ret_Value2 = @as_pd_id;
                    SET @SWP_Ret_Value3 = @as_gpplrt_eff;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            
            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @sg_sp_id,
                @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
            IF @i_fatal <> 1
                SET @s_error = 'Y';
        END CATCH;
        SET NOCOUNT OFF;

--set debug file to "/tmp/dlp_sg_pd.trc";
--trace on;
    END;