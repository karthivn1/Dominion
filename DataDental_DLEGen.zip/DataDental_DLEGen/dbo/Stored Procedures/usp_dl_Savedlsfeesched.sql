﻿
CREATE PROCEDURE [dbo].[usp_dl_Savedlsfeesched] (@dlsfeeSched dbo.DlsFeeSched READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_fee_sched 
				 SET dls_batch_id = dfs.dls_batch_id
					  ,dls_fee_sched.dls_status = CASE WHEN dfs.dls_status='E' OR dfs.dls_status='P' THEN 'V'
				ELSE dls_fee_sched.dls_status END
					  --,dls_source = dfs.dls_source
					  ,zip_code_3 = dfs.zip_code_3
					  ,d_proc_code = dfs.d_proc_code
					  ,percentile1 = dfs.percentile1
					  ,percentile2 = dfs.percentile2
					  ,percentile3 = dfs.percentile3
					  ,percentile4 = dfs.percentile4
					  ,percentile5 = dfs.percentile5
					  ,percentile6 = dfs.percentile6
					  ,percentile7 = dfs.percentile7
					  ,percentile8 = dfs.percentile8
				from @dlsfeeSched dfs
				WHERE dls_fee_sched.dls_sir_id = dfs.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END