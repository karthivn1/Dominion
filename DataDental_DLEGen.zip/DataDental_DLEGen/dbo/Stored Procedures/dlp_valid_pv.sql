﻿CREATE PROCEDURE [dbo].[dlp_valid_pv]
    @a_batch_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT ,
    @SWP_Ret_Value4 DATE = NULL OUTPUT ,
    @SWP_Ret_Value5 DATE = NULL OUTPUT ,
    @SWP_Ret_Value6 DATE = NULL OUTPUT
    

/* $$ks2006-11-02 Removed commented out logic to make more readable * / 

/ *error variable*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;


        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);




        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @s_batch_status CHAR(1);
        DECLARE @x_dds_lic_exp CHAR(10);
        DECLARE @y_dds_lic_exp DATE;
        DECLARE @x_LR_eff_date CHAR(10);
        DECLARE @y_LR_eff_date DATE;
        DECLARE @as_LR_sir_id INT;


        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);



        DECLARE @n_al_count INT;

		DECLARE @pvfc_sir_def_name char(18);
		DECLARE @pvfc_proc_name char(18);
		DECLARE @pv_sp_id integer;
		DECLARE @pv_sir_def_id integer;
		DECLARE @pv_config_id integer;
		DECLARE @x_def_eff_date char(10);
		DECLARE @y_def_eff_date date;
		DECLARE @x_def_exp_date char(10);
		DECLARE @y_def_exp_date date;
		DECLARE @x_has_term_date char(1);
		
		DECLARE @p_sir_id integer;
		DECLARE @p_alt_id char(20);
		DECLARE @p_pv_tax_id char(9);
		DECLARE @p_pv_license char(18);
		DECLARE @p_pv_lic_state char(2);
		DECLARE @p_tin char(1);
		DECLARE @p_pv_first_name char(20);
		DECLARE @p_pv_middle_init char(1);
		DECLARE @p_pv_last_name char(30);
		DECLARE @p_discipline char(2);
		DECLARE @p_mal_car char(30);
		DECLARE @p_mal_pol_no char(15);
		DECLARE @p_mal_prac char(10);
		DECLARE @p_mal_amt char(18);
		DECLARE @p_mal_amt_i char(18);
		DECLARE @p_mal_comnt char(50);
		DECLARE @p_dea_no char(15);
		DECLARE @p_dea_cert_dt char(10);
		






		DECLARE @p_dea_exp_dt char(10);
		DECLARE @p_cds_no char(15);
		DECLARE @p_cds_cert_dt char(10);
		DECLARE @p_cds_exp_dt char(10);
		DECLARE @p_cpr_cert_dt char(10);
		DECLARE @p_cpr_exp_dt char(10);
		DECLARE @p_prim_fc char(40);
		DECLARE @p_school char(50);
		DECLARE @p_grd_date char(10);
		DECLARE @p_degree char(4);
		DECLARE @p_ada_mbr char(1);
		DECLARE @p_district_no char(15);
		DECLARE @p_pv_dob char(10);
		DECLARE @p_print_dir char(1);
		DECLARE @p_race char(2);
		DECLARE @p_gender char(1);
		DECLARE @p_num_yr_prac char(3);
		DECLARE @p_peer_rv char(1);
		DECLARE @p_vendor_id char(20);
		DECLARE @p_pv_stat_eff_date char(10);
		DECLARE @p_fc_assoc_fc_id char(40);
		DECLARE @p_fc_assoc_type char(1);
		DECLARE @p_fc_assoc_eff char(10);
		DECLARE @p_fc_assoc_exp char(10);
		DECLARE @p_pv_lic_eff char(10);
		DECLARE @p_pv_lic_exp char(10);
		DECLARE @p_pv_addr_type char(2);
		DECLARE @p_pv_addr_1 char(30);
		DECLARE @p_pv_addr_2 char(30);
		DECLARE @p_pv_addr_zip char(10);
		DECLARE @p_pv_addr_city char(30);
		DECLARE @p_pv_addr_state char(2);
		DECLARE @p_pv_addr_county char(20);
		DECLARE @p_pv_addr_country char(3);
		DECLARE @p_pv_addr_mail char(1);
		DECLARE @p_pv_con_type char(2);
		DECLARE @p_pv_con_lname char(15);
		DECLARE @p_pv_con_fname char(10);
		DECLARE @p_pv_con_title char(25);
		DECLARE @p_pv_con_phone1 char(10);
		DECLARE @p_pv_con_ext1 char(10);
		DECLARE @p_pv_con_phone2 char(10);
		DECLARE @p_pv_con_ext2 char(10);
		DECLARE @p_pv_con_fax char(10);
		
		DECLARE @as_action_code char(2);
		DECLARE @as_pv_stat_eff date;
		DECLARE @as_fcassoc_eff date;
		DECLARE @as_fcassoc_exp date;
		DECLARE @i_pv_id integer;
		DECLARE @pvlic_cnt integer;
		DECLARE @i_mal_prac date;
		DECLARE @i_mal_amt decimal(16,2);
		DECLARE @i_mal_amt_i decimal(16,2);
		DECLARE @i_dea_cert_dt date;
		DECLARE @i_dea_exp_dt date;
		DECLARE @i_cds_cert_dt date;
		DECLARE @i_cds_exp_dt date;
		DECLARE @i_grd_date date;
		DECLARE @i_cpr_cert_dt date;
		DECLARE @i_cpr_exp_dt date;
		DECLARE @i_pv_dob date;
		DECLARE @i_num_yr_prac integer;
		DECLARE @i_fcstat_eff_date date;
		DECLARE @i_pv_stat_eff_date date;
		DECLARE @i_fc_id integer;
		DECLARE @i_fc_assoc_cnt integer;
		DECLARE @i_fc_assoc_eff date;
		DECLARE @i_pv_lic_eff date;
		DECLARE @i_fc_assoc_exp date;
		DECLARE @i_pv_lic_exp date;
		DECLARE @i_zip integer;
		DECLARE @i_zip_id integer;
		DECLARE @i_city char(30);
		DECLARE @i_state char(2);
		DECLARE @i_county char(20);
		DECLARE @i_phone_err char(1);
		DECLARE @i_phone1 integer;
		DECLARE @i_ext1 integer;
	

	DECLARE @i_phone2 integer;
		DECLARE @i_ext2 integer;
		DECLARE @i_fax integer;

        
        DECLARE @n_process_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @SWV_dl_get_sp_id INT;
		DECLARE @Error_No INT
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @SWV_cursor_var2 CURSOR;


        SET NOCOUNT ON;
        SET @pvfc_sir_def_name ='';
       
        SET @pvfc_proc_name ='';

		SELECT @pvfc_proc_name= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'pvfc_proc_name' and  BatchId = @a_batch_id AND Module_Id = 7
      
        SET @pv_sp_id =0;
       
        SET @pv_sir_def_id =0;
      
        SET @pv_config_id =0;
       
        SET @x_def_eff_date ='';
      
        SET @y_def_eff_date =NULL;
       
        SET @x_def_exp_date ='';
  
        SET @y_def_exp_date =NULL;
     
        SET @x_has_term_date ='';
    
        SET @p_sir_id =0;
      
        SET @p_alt_id ='';
      
        SET @p_pv_tax_id ='';
     
        SET @p_pv_license ='';
      
        SET @p_pv_lic_state ='';
      
        SET @p_tin ='';
    
        SET @p_pv_first_name ='';
       
        SET @p_pv_middle_init ='';
      
        SET @p_pv_last_name ='';
       
        SET @p_discipline ='';
       
        SET @p_mal_car ='';
       
        SET @p_mal_pol_no ='';
     
        SET @p_mal_prac ='';
    
        SET @p_mal_amt ='';
      
        SET @p_mal_amt_i ='';
     
        SET @p_mal_comnt ='';
     
        SET @p_dea_no ='';
     
        SET @p_dea_cert_dt ='';
      
        SET @p_dea_exp_dt ='';
       
        SET @p_cds_no ='';
      
        SET @p_cds_cert_dt ='';
       
        SET @p_cds_exp_dt ='';
        
        SET @p_cpr_cert_dt ='';
       
        SET @p_cpr_exp_dt ='';
       
        SET @p_prim_fc ='';
        
        SET @p_school ='';
        
        SET @p_grd_date ='';
      
        SET @p_degree ='';
      
        SET @p_ada_mbr ='';
      
        SET @p_district_no ='';
   
        SET @p_pv_dob ='';
      
        SET @p_print_dir ='';
      
        SET @p_race ='';
     
        SET @p_gender ='';
        
        SET @p_num_yr_prac ='';
       
        SET @p_peer_rv ='';
       
        SET @p_vendor_id ='';
       
        SET @p_pv_stat_eff_date ='';
      
        SET @p_fc_assoc_fc_id ='';
      
        SET @p_fc_assoc_type ='';
       
        SET @p_fc_assoc_eff ='';
       
        SET @p_fc_assoc_exp ='';
      
        SET @p_pv_lic_eff ='';
        
        SET @p_pv_lic_exp ='';
       
        SET @p_pv_addr_type ='';
       
        SET @p_pv_addr_1 ='';
      
        SET @p_pv_addr_2 ='';
       
        SET @p_pv_addr_zip ='';
       
        SET @p_pv_addr_city ='';
     
        SET @p_pv_addr_state ='';
       
        SET @p_pv_addr_county ='';
      
        SET @p_pv_addr_country ='';
      
        SET @p_pv_addr_mail ='';
      
        SET @p_pv_con_type ='';
   
        SET @p_pv_con_lname ='';
   
        SET @p_pv_con_fname ='';
      
        SET @p_pv_con_title ='';
       
        SET @p_pv_con_phone1 ='';
      
 SET @p_pv_con_ext1 ='';
       
        SET @p_pv_con_phone2 ='';
      
        SET @p_pv_con_ext2 ='';

      SET @p_pv_con_fax ='';
      
        SET @as_action_code ='';
     
        SET @as_pv_stat_eff =NULL;
      
        SET @as_fcassoc_eff =NULL;
      
        SET @as_fcassoc_exp =NULL;
       
        SET @i_pv_id =0;
      
        SET @pvlic_cnt =0;
    
        SET @i_mal_prac =NULL;
   
        SET @i_mal_amt =0;
     
        SET @i_mal_amt_i =0;
     
        SET @i_dea_cert_dt =NULL;
       
        SET @i_dea_exp_dt =NULL;
      
        SET @i_cds_cert_dt =NULL;
  
        SET @i_cds_exp_dt =NULL;
     
        SET @i_grd_date =NULL;
   
        SET @i_cpr_cert_dt =NULL;
    
        SET @i_cpr_exp_dt =NULL;
       
        SET @i_pv_dob =NULL;
      
        SET @i_num_yr_prac =0;
      
        SET @i_fcstat_eff_date =NULL;
       
        SET @i_pv_stat_eff_date =NULL;
    
        SET @i_fc_id =0;
        
        SET @i_fc_assoc_cnt =0;
       
        SET @i_fc_assoc_eff =NULL;
       
        SET @i_pv_lic_eff =NULL;
      
        SET @i_fc_assoc_exp =NULL;
     
        SET @i_pv_lic_exp =NULL;
        
        SET @i_zip =0;
     
        SET @i_zip_id =0;
      
        --SET @i_city ='';
        --EXECUTE SWPCrtGlVar 'i_city';
        --EXECUTE SWPAddGlVar 'i_city', @i_city;
        --SET @i_state ='';
        --EXECUTE SWPCrtGlVar 'i_state';
        --EXECUTE SWPAddGlVar 'i_state', @i_state;
        --SET @i_county ='';
        --EXECUTE SWPCrtGlVar 'i_county';
        --EXECUTE SWPAddGlVar 'i_county', @i_county;
        SET @i_phone_err ='';
       
        SET @i_phone1 =0;
      
        SET @i_ext1 =0;
   
     SET @i_phone2 =0;
      
        SET @i_ext2 =0;
       
        SET @i_fax =0;
      
        SET @n_process_count =0;
       
        SET @n_error_count =0;
      
        SET @n_succ_count =0;
       
        BEGIN TRY
            
            SET @s_error = 'N';
            SET @a_error_no = 0;
            SET @i_pv_id =NULL;
           
            SET @as_pv_stat_eff =NULL;
          --  EXECUTE SWPAddGlVar 'as_pv_stat_eff', @as_pv_stat_eff;
            SET @as_fcassoc_eff =NULL;
           -- EXECUTE SWPAddGlVar 'as_fcassoc_eff', @as_fcassoc_eff;
            SET @as_fcassoc_exp =NULL;
           -- EXECUTE SWPAddGlVar 'as_fcassoc_exp', @as_fcassoc_exp;
           -- EXECUTE SWPGetGlVar 'pvfc_proc_name', @pvfc_proc_name OUTPUT;

				SELECT @p_sir_id= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_sir_id,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_alt_id= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_alt_id,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_tax_id= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_tax_id,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_license= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_license,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_lic_state= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_lic_state,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_tin= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_tin,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_first_name= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_first_name,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_middle_init= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_middle_init,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_last_name= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_last_name,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_discipline= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_discipline,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_mal_car= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_mal_car,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_mal_pol_no= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_mal_pol_no,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_mal_prac= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_mal_prac,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_mal_amt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_mal_amt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_mal_amt_i= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_mal_amt_i,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_mal_comnt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_mal_comnt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_dea_no= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_dea_no,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_dea_cert_dt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_dea_cert_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_dea_exp_dt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_dea_exp_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_cds_no= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_cds_no,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_cds_cert_dt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_cds_cert_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_cds_exp_dt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_cds_exp_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_cpr_cert_dt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_cpr_cert_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_cpr_exp_dt= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_cpr_exp_dt,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_prim_fc= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_prim_fc,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_school= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_school,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_grd_date= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_grd_date,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_degree= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_degree,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_ada_mbr= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_ada_mbr,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_district_no= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_district_no,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_dob= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_dob,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_print_dir= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_print_dir,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_race= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_race,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_gender= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_gender,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_num_yr_prac= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_num_yr_prac,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_peer_rv= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_peer_rv,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_vendor_id= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_vendor_id,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_stat_eff_date= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_stat_eff_date,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_fc_assoc_fc_id= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_fc_assoc_fc_id,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_fc_assoc_type= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_fc_assoc_type,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_fc_assoc_eff= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_fc_assoc_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_fc_assoc_exp= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_fc_assoc_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_lic_eff= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_lic_eff,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_lic_exp= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_lic_exp,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_type= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_type,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_1= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_1,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_2= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_2,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_zip= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_zip,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_city= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_city,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_state= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_state,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_county= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_county,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_country= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_country,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_addr_mail= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_addr_mail,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_con_lname= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_con_lname,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_con_fname= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_con_fname,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_con_title= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_con_title,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_con_phone1= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_con_phone1,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @p_pv_con_ext1= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'p_pv_con_ext1,' and  BatchId = @a_batch_id AND Module_Id = 7
				SELECT @y_def_exp_date= VarValue  from dbo.GlobalVar(NOLOCK) where VarName = 'y_def_exp_date' and  BatchId = @a_batch_id AND Module_Id = 7


            EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, @pvfc_proc_name
                 
            SET @pv_sp_id = @SWV_dl_get_sp_id;
            
            IF @pv_sp_id IS NULL
                OR @pv_sp_id <= 0
				BEGIN
				SET @Error_No = 1
                RAISERROR('Invalid SP Name',16,1);
			END
			
			SET @pvfc_sir_def_name = 'pv_assoc';

            SET @pv_sir_def_id = dbo.dl_get_sir_def_id(@pvfc_sir_def_name);
            
            IF @pv_sir_def_id IS NULL
                OR @pv_sir_def_id <= 0
				BEGIN
					SET @Error_No = 2
					RAISERROR('Invalid SIR TABLE Definition',16,1);
				END
   
             IF ( @p_alt_id IS NULL
                 OR @p_alt_id = ''
               )
                OR LEN(@p_alt_id) = 0
				BEGIN
					SET @Error_No = 10
					RAISERROR('Provider Alt ID is missing',16,1);
				END
   
            IF ( @p_pv_tax_id IS NULL
                 OR @p_pv_tax_id = ''
               )
     OR LEN(@p_pv_tax_id) = 0
				BEGIN 
				SET @Error_No = 20
                RAISERROR('Provider Tax ID is missing',16,1);
				END
            ELSE
                BEGIN
       
                    IF LEN(@p_pv_tax_id) <> 9
					BEGIN
						SET @Error_No = 21
                        RAISERROR('Provider Tax ID must be 9 digit long',16,1);
					END
                END;
   
      
            IF ( @p_tin IS NULL
                 OR @p_tin = ''
               )
                OR LEN(@p_tin) = 0
				BEGIN
				SET @Error_No = 25
                RAISERROR('Provider TIN is missing',16,1);
				END
            ELSE
                BEGIN
                   
                    IF @p_tin NOT IN ( 'Y', 'N' )
					BEGIN
					SET @Error_No = 26
                        RAISERROR('Invalid Provider TIN',16,1);
						END
                END;
   
           
            IF ( @p_pv_first_name IS NULL
                 OR @p_pv_first_name = ''
               )
                OR LEN(@p_pv_first_name) = 0
				BEGIN
				SET @Error_No = 40
                RAISERROR('Provider First Name is missing',16,1);
				END
   
           
            IF ( @p_pv_last_name IS NULL
                 OR @p_pv_last_name = ''
               )
                OR LEN(@p_pv_last_name) = 0
				BEGIN
				SET @Error_No = 41
                RAISERROR('Provider Last Name is missing',16,1);
				END
   
          
            IF ( @p_pv_license IS NULL
                 OR @p_pv_license = ''
               )
                OR LEN(@p_pv_license) = 0
				BEGIN
				SET @Error_No = 30
                RAISERROR('Provider License is missing',16,1);
				END
   
           
            IF ( @p_pv_lic_state IS NULL
                 OR @p_pv_lic_state = ''
               )
                OR LEN(@p_pv_lic_state) = 0
				BEGIN
				SET @Error_No = 31
                RAISERROR('Provider License State is missing',16,1);
				END
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.state (NOLOCK)
                                WHERE   code = @p_pv_lic_state )
								BEGIN
								SET @Error_No = 32
 RAISERROR('Invalid Provider State Code',16,1);
					END

            IF ( @p_pv_license IS NOT NULL
       AND @p_pv_license <> ''
               )
                AND ( @p_pv_lic_state IS NOT NULL
                      AND @p_pv_lic_state <> ''
                    )
                BEGIN
                    SELECT  @pvlic_cnt = COUNT(*)
                    FROM    dbo.pv_license (NOLOCK)
                    WHERE   license = @p_pv_license
                            AND state = @p_pv_lic_state
                            AND ( exp_date IS NULL
                                  OR eff_date <> exp_date
          );
                    
                    IF @pvlic_cnt = 0
                        BEGIN
                     SET @i_pv_id =NULL;
          
                            SELECT  @i_pv_id = pv_id
                            FROM    dbo.providers (NOLOCK)
                            WHERE   alt_id = @p_alt_id;
                         
                            
                            IF @i_pv_id IS NOT NULL
							BEGIN
								SET @Error_No = 38
                                RAISERROR('Existing Provider found with different License Info',0,1);
								EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
							END
                            ELSE
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.providers (NOLOCK)
                                            WHERE   SUBSTRING(first_name, 1, 7) = SUBSTRING(@p_pv_first_name,
                                                              1, 7)
                                                    AND SUBSTRING(last_name, 1,
                                                   7) = SUBSTRING(@p_pv_last_name,
                                                              1, 7) )
															  BEGIN
															  SET @Error_No = 37
                                    RAISERROR('Provider found with different License Info - Will Add as New',               0,1);
									EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
									END
                        END;
                    ELSE
                        BEGIN
                      
                            IF @pvlic_cnt = 1
                                BEGIN
                                    SELECT  @i_pv_id = pv_id
                                    FROM    dbo.pv_license (NOLOCK)
                                    WHERE   license = @p_pv_license
                                            AND state = @p_pv_lic_state
                                            AND ( exp_date IS NULL
                                                  OR eff_date <> exp_date
                                                );
                               
                                END;
                            ELSE
                                BEGIN
                            
                                    IF @pvlic_cnt > 1
                                        BEGIN
                                            SET @i_pv_id =NULL;
                                       
					DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
						 pv_id INT
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
								pv_id 
                                )
								SELECT a.pv_id 
                  FROM dbo.pv_license a (NOLOCK), 
				  dbo.providers b (NOLOCK)
                  WHERE a.license = @p_pv_license
                  AND a.state = @p_pv_lic_state
                  AND (a.exp_date IS NULL OR a.eff_date <> a.exp_date)
                  AND a.pv_id = b.pv_id
                  AND SUBSTRING(b.first_name,1,7) = SUBSTRING(@p_pv_first_name,1,7)
                  AND SUBSTRING(b.last_name,1,7) = SUBSTRING(@p_pv_last_name,1,7);

	                    DECLARE @cur1_cnt INT ,
                        @cur1_i INT;

                        SET @cur1_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;

                                /*
                                            SET @SWV_cursor_var1 = CURSOR  FOR SELECT a.pv_id 
                  FROM dbo.pv_license a (NOLOCK), 
				  dbo.providers b (NOLOCK)
                  WHERE a.license = @p_pv_license
                  AND a.state = @p_pv_lic_state
                  AND (a.exp_date IS NULL OR a.eff_date <> a.exp_date)
                  AND a.pv_id = b.pv_id
                  AND SUBSTRING(b.first_name,1,7) = SUBSTRING(@p_pv_first_name,1,7)
                  AND SUBSTRING(b.last_name,1,7) = SUBSTRING(@p_pv_last_name,1,7);
                    OPEN @SWV_cursor_var1;
                                            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_pv_id;
                                 WHILE @@FETCH_STATUS = 0
											*/
            WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @i_pv_id=pv_id 
					FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;
                                 SET @Error_No = 34
								                    RAISERROR('Multiple matches on provider license number - use first match',0,1);
													EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
                                                    GOTO SWL_Label3;
                                                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_pv_id;
													SET @cur1_i = @cur1_i + 1;
                                                END;
                                            SWL_Label3:
                                            --CLOSE @SWV_cursor_var1;
                                        END;
                                END;
                        END;
                END;
   
     
            IF ( @p_discipline IS NULL
                 OR @p_discipline = ''
               )
                OR LEN(@p_discipline) = 0
				BEGIN
				SET @Error_No = 50
                RAISERROR('Provider Discipline is missing',16,1);
				END
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'PV'
            AND tab_name = 'pv_certified'
                                        AND code = @p_discipline )
										BEGIN
										SET @Error_No = 51
                    RAISERROR('Invalid Provider Discipline',16,1);
					END
      
   
           
            IF ( @p_mal_prac IS NOT NULL
                 AND @p_mal_prac <> ''
               )
                OR LEN(@p_mal_prac) > 0
                BEGIN
                    SET @a_error_no = 60;
                    
                    SET @i_mal_prac = @p_mal_prac ;
                  
                END;
   
          
            IF ( @p_mal_amt IS NOT NULL
                 AND @p_mal_amt <> ''
               )
                OR LEN(@p_mal_amt) > 0
                BEGIN
                    SET @a_error_no = 61;
                   
                    SET @i_mal_amt = @p_mal_amt ;
              
                END;

            IF ( @p_mal_amt_i IS NOT NULL
                 AND @p_mal_amt_i <> ''
               )
                OR LEN(@p_mal_amt_i) > 0
                BEGIN
                    SET @a_error_no = 62;
               
                    SET @i_mal_amt_i = @p_mal_amt_i;
                  
                END;
   
         
            IF ( @p_dea_no IS NULL
                 OR @p_dea_no = ''
               )
                OR LEN(@p_dea_no) = 0
                BEGIN
                  
                    IF ( @p_dea_cert_dt IS NOT NULL
                         AND @p_dea_cert_dt <> ''
                       )
                        OR LEN(@p_dea_cert_dt) > 0
						BEGIN
						SET @Error_No = 70
                        RAISERROR('DEA Number is required if DEA Certification Date is given', 16,1);
						END
   END;
   
            SET @i_dea_cert_dt =NULL;
         
   IF ( @p_dea_cert_dt IS NULL
                 OR @p_dea_cert_dt = ''
               )
                OR LEN(@p_dea_cert_dt) = 0
                BEGIN
               
                    IF ( @p_dea_no IS NOT NULL
                         AND @p_dea_no <> ''
                       )
                        OR LEN(@p_dea_no) > 0
						BEGIN
						SET @Error_No = 71
                        RAISERROR('DEA Certification Date is required if DEA Number is given',            16,1);
						END
                END;
            ELSE
                BEGIN
                    SET @a_error_no = 72;
                  
                    SET @i_dea_cert_dt = @p_dea_cert_dt;
  
                END;
   
       
            IF ( @p_dea_exp_dt IS NOT NULL
                 AND @p_dea_exp_dt <> ''
    )
                OR LEN(@p_dea_exp_dt) > 0
                BEGIN
                    SET @a_error_no = 73;
                   
                    SET @i_dea_exp_dt = @p_dea_exp_dt ;
      
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_dea_cert_dt)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_dea_cert_dt)) > CONVERT(DATE, CONVERT(VARCHAR, @i_dea_exp_dt))
						BEGIN
						SET @Error_No = 74
                        RAISERROR('DEA Expiration Date must be after DEA Certification Date',16,            1);
						END
                END;
   
     
            IF ( @p_cds_no IS NULL
                 OR @p_cds_no = ''
               )
                OR LEN(@p_cds_no) = 0
                BEGIN
            
                    IF ( @p_cds_cert_dt IS NOT NULL
                         AND @p_cds_cert_dt <> ''
                       )
                  OR LEN(@p_cds_cert_dt) > 0
						BEGIN
						SET @Error_No = 80
                        RAISERROR('CDS Number is required if CDS Certification Date is given',            16,1);
						END
                END;
   
            SET @i_cds_cert_dt =NULL;
           
            IF ( @p_cds_cert_dt IS NULL
                 OR @p_cds_cert_dt = ''
               )
                OR LEN(@p_cds_cert_dt) = 0
                BEGIN
        
                    IF ( @p_cds_no IS NOT NULL
                         AND @p_cds_no <> ''
                       )
                        OR LEN(@p_cds_no) > 0
						BEGIN
						SET @Error_No = 81
                        RAISERROR('CDS Certification Date is required if CDS Number is given',            16,1);
						END
                END;
            ELSE
                BEGIN
                    SET @a_error_no = 82;
              
                    SET @i_cds_cert_dt = @p_cds_cert_dt;
            
                END;
   
          
            IF ( @p_cds_exp_dt IS NOT NULL
                 AND @p_cds_exp_dt <> ''
               )
                OR LEN(@p_cds_exp_dt) > 0
                BEGIN
                    SET @a_error_no = 85;
                   
                    SET @i_cds_exp_dt = @p_cds_exp_dt;
                   
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_cds_cert_dt)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_cds_cert_dt)) > CONVERT(DATE, CONVERT(VARCHAR, @i_cds_exp_dt))
						BEGIN
						SET @Error_No = 86
                        RAISERROR('CDS Expiration Date must be after CDS Certification Date',16,            1);
						END
                END;
   
            SET @i_cpr_cert_dt =NULL;
        
            IF ( @p_cpr_cert_dt IS NOT NULL
                 AND @p_cpr_cert_dt <> ''
               )
                OR LEN(@p_cpr_cert_dt) > 0
                BEGIN
                    SET @a_error_no = 90;
                  
                    SET @i_cpr_cert_dt = @p_cpr_cert_dt;
                
                END;
   
       
            IF ( @p_cpr_exp_dt IS NOT NULL
                 AND @p_cpr_exp_dt <> ''
               )
                OR LEN(@p_cpr_exp_dt) > 0
  BEGIN
                    SET @a_error_no = 91;
                  
                    SET @i_cpr_exp_dt = @p_cpr_exp_dt;
                   
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_cpr_cert_dt)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_cpr_cert_dt)) > CONVERT(DATE, CONVERT(VARCHAR, @i_cpr_exp_dt))
						BEGIN
						SET @Error_No = 92
                        RAISERROR('CPR Expiration Date must be after CPR Certification Date',16,            1);
						END
                END;
   
     
            IF ( @p_grd_date IS NOT NULL
                 AND @p_grd_date <> ''
               )
                OR LEN(@p_grd_date) > 0
                BEGIN
               
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date)) IS NULL
                        BEGIN
                            SET @a_error_no = 83;
                        
                            SET @i_grd_date = @p_grd_date ;
                           
      END;
      
                   
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date)) >= CONVERT(DATE, GETDATE())
					BEGIN
					SET @Error_No = 95
                        RAISERROR('Provider Graduation Date must be before Today',16,1);
						END
      
                  
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_cds_cert_dt)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date)) > CONVERT(DATE, CONVERT(VARCHAR, @i_cds_cert_dt))
						BEGIN
						SET @Error_No = 84
                        RAISERROR('CDS Certification Date must be after Provider Graduation Date',            16,1);
						END
                END;

            IF ( @p_ada_mbr IS NOT NULL
                 AND @p_ada_mbr <> ''
               )
                OR LEN(@p_ada_mbr) > 0
                BEGIN
           
                    IF @p_ada_mbr NOT IN ( 'Y', 'N' )
					BEGIN
						SET @Error_No = 99
                        RAISERROR('Invalid ADA Member Flag',16,1);
					END
                END;

            IF ( @p_pv_dob IS NOT NULL
                 AND @p_pv_dob <> ''
               )
                OR LEN(@p_pv_dob) > 0
                BEGIN
           
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob)) IS NULL
                        BEGIN
                            SET @a_error_no = 96;
                    
                            SET @i_pv_dob = @p_pv_dob;
                          
                        END;
      
                   
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob)) >= CONVERT(DATE, GETDATE())
					BEGIN
						SET @Error_No = 100
                        RAISERROR('Provider Birthday must be before Today',16,1);
					END
      
                   
                    IF YEAR(CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob))) + 20 > YEAR(CONVERT(DATE, GETDATE()))
					BEGIN
					SET @Error_No = 101
                        RAISERROR('Provider is not over 20 years old',16,1);
						END
   
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_dea_cert_dt)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_dea_cert_dt)) >= CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob))
						BEGIN
						SET @Error_No = 102
                        RAISERROR('Provider Birthday must be before DEA Certification Date',16,            1);
						END
     
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_cds_cert_dt)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_cds_cert_dt)) >= CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob))
						BEGIN
						SET @Error_No = 103
                        RAISERROR('Provider Birthday must be before CDS Certification Date',16,            1);
						END
      

                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_cpr_cert_dt)) IS NOT NULL
                  AND CONVERT(DATE, CONVERT(VARCHAR, @i_cpr_cert_dt)) >= CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob))
						BEGIN
						SET @Error_No = 104
                        RAISERROR('Provider Birthday must be before CPR Certification Date',16,            1);
						END
      
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date)) IS NOT NULL
                        AND CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date)) >= CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob))
						BEGIN
						SET @Error_No = 105
                        RAISERROR('Provider Birthday must be before Provider Graduation Date',            16,1);
						END
                END;
   
            IF ( @p_print_dir IS NOT NULL
                 AND @p_print_dir <> ''
               )
                OR LEN(@p_print_dir) > 0
                BEGIN

                    IF @p_print_dir NOT IN ( 'Y', 'N' )
					BEGIN
						SET @Error_No = 108
                        RAISERROR('Invalid ADA Member Flag',16,1);
					END
                END;
   
            IF ( @p_race IS NOT NULL
                 AND @p_race <> ''
               )
                OR LEN(@p_race) > 0
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'PV'
                                        AND tab_name = 'race'
                                        AND code = @p_race )
										BEGIN
										SET @Error_No = 110
                    RAISERROR('Invalid Provider Race',16,1);
					END
      
               IF ( @p_gender IS NOT NULL
                 AND @p_gender <> ''
               )
                OR LEN(@p_gender) > 0
               BEGIN
              
                    IF @p_gender NOT IN ( 'M', 'F' )
					BEGIN
						SET @Error_No = 115
                        RAISERROR('Invalid Provider Gender',16,1);
					END
                END;
   
            IF ( @p_num_yr_prac IS NOT NULL
                 AND @p_num_yr_prac <> ''
               )
                OR LEN(@p_num_yr_prac) > 0
                BEGIN
                    SET @a_error_no = 120;

                    SET @i_num_yr_prac = @p_num_yr_prac;
        
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob)) IS NOT NULL
                        AND ( ( YEAR(CONVERT(DATE, GETDATE()))
                                - YEAR(CONVERT(DATE, CONVERT(VARCHAR, @i_pv_dob))) ) <= @p_num_yr_prac )
								BEGIN
								SET @Error_No = 125
                        RAISERROR('Provider Years in Practice cannot be greater than his age',            16,1);
						END

                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date)) IS NOT NULL
                        AND ( ( YEAR(CONVERT(DATE, GETDATE()))
                                - YEAR(CONVERT(DATE, CONVERT(VARCHAR, @i_grd_date))) ) <= @p_num_yr_prac )
								BEGIN
								SET @Error_No = 126
                        RAISERROR('Provider Years in Practice cannot be greater than the years after Graduation',16,1);
						END
                END;
   
            IF ( @p_peer_rv IS NOT NULL
                 AND @p_peer_rv <> ''
               )
                OR LEN(@p_peer_rv) > 0
                BEGIN

                    IF @p_peer_rv NOT IN ( 'Y', 'N' )
					BEGIN
					SET @Error_No = 130
                        RAISERROR('Invalid Peer Review Panel Flag',16,1);
					END
                END;

            IF ( @p_vendor_id IS NOT NULL
                 AND @p_vendor_id <> ''
               )
                OR LEN(@p_vendor_id) > 0
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.vendor (NOLOCK)
                                WHERE   v_type = 'PV'
                                        AND alt_id = @p_vendor_id )
										BEGIN
										SET @Error_No = 135
                    RAISERROR('Given Vendor Alt ID is not found in VENDOR table.  Will ignore',            0,1);
					EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
					END
   

            IF ( @p_pv_stat_eff_date IS NULL
                 OR @p_pv_stat_eff_date = ''
               )
                OR LEN(@p_pv_stat_eff_date) = 0
                BEGIN
					SET @Error_No = 140
                    RAISERROR('Provider Status Effective Date is missing',16,1);
     
                    SET @as_pv_stat_eff =  @y_def_eff_date
                  
                END;
            ELSE
                BEGIN
                    SET @a_error_no = 141;
            
                    SET @i_pv_stat_eff_date = CAST(@p_pv_stat_eff_date AS DATE);
               
                    IF DATEPART(DAY,
                                CONVERT(DATE, CONVERT(VARCHAR, @i_pv_stat_eff_date))) <> 1
								BEGIN
								SET @Error_No = 142
                        RAISERROR('Provider Status Effective Date is not first of the month',16,            1);
						END
      
     
        SET @as_pv_stat_eff = @i_pv_stat_eff_date;
              
   END;
   
            SET @i_fc_id =NULL;
          
            IF ( @p_fc_assoc_fc_id IS NOT NULL
                 AND @p_fc_assoc_fc_id <> ''
               )
                OR LEN(@p_fc_assoc_fc_id) > 0
                BEGIN
                    SET @a_error_no = 150;
                    SELECT  @i_fc_id = fc_id
                    FROM    dbo.facility (NOLOCK)
                    WHERE   alt_id = @p_fc_assoc_fc_id;
              
                    IF @i_fc_id IS NULL
					BEGIN
						SET @Error_No = 151
                        RAISERROR('Cannot find facility record by given fc_assoc_fc_id',16,1);
					END

                    IF @i_pv_id IS NOT NULL
                        BEGIN
                            SELECT  @i_fc_assoc_cnt = COUNT(*)
                            FROM    dbo.fc_assoc (NOLOCK)
                            WHERE   fc_id = @i_fc_id
                                    AND pv_id = @i_pv_id
                          AND exp_date IS NULL;
 
                            IF @i_fc_assoc_cnt > 1
							BEGIN
								SET @Error_No = 154
								RAISERROR('Combination of Facility ID and Provider ID is not unique',16,1);
							END
                        END;
      
 
                    IF ( @p_fc_assoc_type IS NULL
                         OR @p_fc_assoc_type = ''
                       )
                        OR LEN(@p_fc_assoc_type) = 0
						BEGIN
							SET @Error_No = 155
							RAISERROR('Missing Facility Association Type while associated Facility ID is given',16,1);
						END

                    IF ( @p_fc_assoc_eff IS NULL
                         OR @p_fc_assoc_eff = ''
                       )
                        OR LEN(@p_fc_assoc_eff) = 0
						BEGIN
						SET @Error_No = 156
                        RAISERROR('Missing Facility Association Effective Date while associated Facility ID is given',16,1);
						END
                END;
   
 
            IF ( @p_fc_assoc_type IS NOT NULL
                 AND @p_fc_assoc_type <> ''
               )
                OR LEN(@p_fc_assoc_type) > 0
                BEGIN
  
                    IF @p_fc_assoc_type NOT IN ( 'P', 'S' )
					BEGIN
						SET @Error_No = 157
                        RAISERROR('Invalid Facility Association Type',16,1)
					END
      
  
                    IF ( @p_fc_assoc_fc_id IS NULL
                         OR @p_fc_assoc_fc_id = ''
                       )
                        OR LEN(@p_fc_assoc_fc_id) = 0
						BEGIN
						SET @Error_No = 158
                        RAISERROR('Missing Associated Facility ID while Facility Association Type is given',16,1);
						END
                END;
   
   
            IF ( @p_fc_assoc_eff IS NOT NULL
                 AND @p_fc_assoc_eff <> ''
               )
                OR LEN(@p_fc_assoc_eff) > 0
    BEGIN
               
                    IF ( @p_fc_assoc_fc_id IS NULL
                OR @p_fc_assoc_fc_id = ''
                       )
               OR LEN(@p_fc_assoc_fc_id) = 0
						BEGIN
						SET @Error_No = 159
                        RAISERROR('Missing Associated Facility ID while Facility Association Effective Date is given',16,1);
						END
      
                    SET @a_error_no = 160;
                   
                    SET @i_fc_assoc_eff = @p_fc_assoc_eff;
                  
                    IF DATEPART(DAY,
                                CONVERT(DATE, CONVERT(VARCHAR, @i_fc_assoc_eff))) <> 1
								BEGIN
								SET @Error_No = 161
                        RAISERROR('Facility Association Effective Date is not first of the month',            16,1);
						END
      
                   
                    SET @as_fcassoc_eff =  @i_fc_assoc_eff ;
                 
                END;
            ELSE -- p_fc_assoc_eff is missing from the tape
                BEGIN
                  
                    SET @as_fcassoc_eff =  @y_def_eff_date ;
          
                END;
   
            IF ( @p_fc_assoc_exp IS NOT NULL
                 AND @p_fc_assoc_exp <> ''
               )
                OR LEN(@p_fc_assoc_exp) > 0
                BEGIN
                   
                    IF ( @p_fc_assoc_fc_id IS NULL
                         OR @p_fc_assoc_fc_id = ''
                       )
                        OR LEN(@p_fc_assoc_fc_id) = 0
						BEGIN
						SET @Error_No = 170
                        RAISERROR('Missing Associated Facility ID while Facility Association Expiration Date is given',16,1);
						END
      
                  
                    IF ( @p_fc_assoc_eff IS NULL
                         OR @p_fc_assoc_eff = ''
                       )
             OR LEN(@p_fc_assoc_eff) = 0
						BEGIN
						SET @Error_No = 171
                        RAISERROR('Missing Facility Association Effective Date while Facility Association Expiration Date is given',16,1);
						END
      
                    SET @a_error_no = 172;
                
                    SET @i_fc_assoc_exp = @p_fc_assoc_exp;
               
                    IF DATEPART(DAY,
                                CONVERT(DATE, CONVERT(VARCHAR, @i_fc_assoc_exp))) <> 1
								BEGIN
								SET @Error_No = 173
                        RAISERROR('Facility Association Expiration Date is not first of the month',16,1);
						END
      
                 
      --IF CONVERT(DATE, CONVERT(VARCHAR, @as_fcassoc_eff)) > CONVERT(DATE, CONVERT(VARCHAR, @i_fc_assoc_exp))
	  IF @as_fcassoc_eff> @i_fc_assoc_exp
	  BEGIN
	  SET @Error_No = 174
             RAISERROR('Facility Association Effective Date is after Facility Association Expiration Date',16,1);
      END
                
                    SET @as_fcassoc_exp =  @i_fc_assoc_exp;
               
                END;
            ELSE -- p_fc_assoc_exp is missing from the tape
                BEGIN
                 
                    SET @as_fcassoc_exp =  @y_def_exp_date;
                    
                END;
   
        
            IF @x_has_term_date = 'N'
                OR @as_fcassoc_exp IS NULL
                BEGIN
                 
                    SET @as_fcassoc_exp = @y_def_exp_date;
                  
                END;

            IF CONVERT(DATE, CONVERT(VARCHAR, @i_pv_lic_eff)) IS NULL
                BEGIN
               
                    IF ( @p_pv_lic_eff IS NOT NULL
                         AND @p_pv_lic_eff <> ''
                       )
                        BEGIN
                            SET @a_error_no = 164;
                         
                            SET @i_pv_lic_eff = @p_pv_lic_eff ;
                         
                        END;
                END;
   
       
            IF ( @p_pv_lic_exp IS NOT NULL
              AND @p_pv_lic_exp <> ''
               )
       BEGIN
                    SET @a_error_no = 176;
   
                    SET @i_pv_lic_exp = @p_pv_lic_exp ;
                
                    IF CONVERT(DATE, CONVERT(VARCHAR, @i_pv_lic_eff)) IS NULL
					BEGIN
					SET @Error_No = 177
                        RAISERROR('Missing Facility License Effective Date while Facility License Expiration Date presents',16,1);
						END
                    ELSE
                        BEGIN
                        
                            IF CONVERT(DATE, CONVERT(VARCHAR, @i_pv_lic_eff)) > CONVERT(DATE, CONVERT(VARCHAR, @i_pv_lic_exp))
							BEGIN
							SET @Error_No = 178
                                RAISERROR('Facility License Effective Date is after Facility License Expiration Date',16,1);
								END
                        END;
                END;
   
          
            IF ( @p_pv_addr_type IS NULL
                 OR @p_pv_addr_type = ''
               )
                OR LEN(@p_pv_addr_type) = 0
                BEGIN
                  
                    IF ( @p_pv_addr_zip IS NOT NULL
                 AND @p_pv_addr_zip <> ''
                )
				BEGIN
				SET @Error_No = 180
                        RAISERROR('Provider Address Type cannot be null while Provider Zip Code is given',16,1);
					END
                END;
            ELSE
                BEGIN
              
                    IF @p_pv_addr_type <> 'L'
					BEGIN
					SET @Error_No = 181
                        RAISERROR('Provider Address Type must be for Location',16,1);
					END
     
                  
                    IF ( ( @p_pv_addr_1 IS NULL
                           OR @p_pv_addr_1 = ''
                         )
                         OR LEN(@p_pv_addr_1) = 0
                       )
                        AND ( ( @p_pv_addr_2 IS NULL
                                OR @p_pv_addr_2 = ''
                              )
                              OR LEN(@p_pv_addr_2) = 0
                            )
							BEGIN
							SET @Error_No = 185
							RAISERROR('Provider Address Line 1 and Line 2 cannot both missing',16,            1);
							END
      
             
                    IF ( ( @p_pv_addr_zip IS NULL
                           OR @p_pv_addr_zip = ''
                         )
                         OR LEN(@p_pv_addr_zip) = 0
                       )
                        BEGIN
                        
                            IF ( @p_pv_addr_1 IS NOT NULL
                                 AND @p_pv_addr_1 <> ''
                               )
                       OR ( @p_pv_addr_2 IS NOT NULL
                     AND @p_pv_addr_2 <> ''
                                   )
								   BEGIN
								   SET @Error_No = 190
                                RAISERROR('Provider Address Zip Code is missing with Address Info given',               16,1);
								END
                        END;
                    ELSE
                        BEGIN
                         
                            IF NOT ( LEN(@p_pv_addr_zip) = 5
                                     OR LEN(@p_pv_addr_zip) = 9
                                   )
								   BEGIN
								    SET @Error_No = 191
                                RAISERROR('Provider Address Zip Code must be 5 or 9 digits long',16,1);
								END
         
                            SET @a_error_no = 192;
                           
                            SET @i_zip = @p_pv_addr_zip;
                         
                            SET @i_zip = SUBSTRING(@p_pv_addr_zip, 1, 5) ;
                            
                            SET @a_error_no = 193;
         --CHANGE for handling multiple cities per zip
                           
                            IF ( @p_pv_addr_city IS NOT NULL
  AND @p_pv_addr_city <> ''
                               )
               BEGIN
         SELECT  @i_zip_id = zip_id ,
                                          @i_city = city  ,
                                            @i_state = state_code  ,
       @i_county = county 
                                    FROM    dbo.usa_zip (NOLOCK)
       WHERE   zip_code = SUBSTRING(@p_pv_addr_zip,
                                                              1, 5)
                                            AND city = @p_pv_addr_city; 
                               
                                    
                                END;
			
                        
                            IF @i_zip_id IS NULL
                                BEGIN

								DECLARE @SWV_cursor_var2 TABLE
                        (
                         id INT IDENTITY ,
						 zip_id INT, 
						 city CHAR(30), 
						 state_code CHAR(2), 
						 county CHAR(20)
                        );
                          INSERT  INTO @SWV_cursor_var2
                                ( 
								zip_id , city, state_code, county
                                )
								SELECT zip_id, city, state_code, county
              
               FROM dbo.usa_zip (NOLOCK)
               WHERE zip_code = SUBSTRING(@p_pv_addr_zip,1,5)
               ORDER BY zip_id;

	  DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
                        FROM  @SWV_cursor_var2;

								/*
                                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT zip_id, city, state_code, county
              
               FROM dbo.usa_zip (NOLOCK)
               WHERE zip_code = SUBSTRING(@p_pv_addr_zip,1,5)
               ORDER BY zip_id;
                                    OPEN @SWV_cursor_var2;
                                    FETCH NEXT FROM @SWV_cursor_var2 INTO @i_zip_id,
                                        @i_city, @i_state, @i_county;
                                    WHILE @@FETCH_STATUS = 0
									*/
                                        WHILE ( @cur2_i <= @cur2_cnt )
            BEGIN
			SELECT  @i_zip_id=zip_id,
                    @i_city=city,
					@i_state=state_code,
					@i_county=county
					FROM @SWV_cursor_var2
            WHERE   id = @cur2_i;
                                            GOTO SWL_Label4;
                                            --FETCH NEXT FROM @SWV_cursor_var2 INTO @i_zip_id,
                                            --    @i_city, @i_state, @i_county;
											SET @cur2_i = @cur2_i + 1;
                      END;
          SWL_Label4:
                                    --CLOSE @SWV_cursor_var2;
                                END;
			
         
                            IF @i_zip_id IS NULL
							BEGIN
							 SET @Error_No = 194
                                RAISERROR('Provider Address Zip Code is not in the USA_ZIP table',16,1);
						END
                        
                            IF ( @p_pv_addr_city IS NOT NULL
                                 AND @p_pv_addr_city <> ''
                               )
                                AND @p_pv_addr_city <> @i_city
								BEGIN
								 SET @Error_No = 195
                                RAISERROR('Provider Address City is not the same as in the USA_ZIP table',               0,1);
								EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
								END
			
                        
                            IF ( @p_pv_addr_state IS NOT NULL
                                 AND @p_pv_addr_state <> ''
               )
                                AND @p_pv_addr_state <> @i_state
								BEGIN
								 SET @Error_No = 196
                                RAISERROR('Provider Address State is not the same as in the USA_ZIP table',               0,1);
								EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
         
								END

               IF ( @p_pv_addr_county IS NOT NULL
       AND @p_pv_addr_county <> ''
                              )
                                AND @p_pv_addr_county <> @i_county
								BEGIN
								 SET @Error_No = 197
                                RAISERROR('Provider Address County is not the same as in the USA_ZIP table',               0,1);
								EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
								END
                        END;

                    IF ( @p_pv_addr_mail IS NOT NULL
                         AND @p_pv_addr_mail <> ''
                       )
                        OR LEN(@p_pv_addr_mail) > 0
                        BEGIN

                            IF @p_pv_addr_mail NOT IN ( 'Y', 'N' )
							BEGIN
							 SET @Error_No = 198
                                RAISERROR('Invalid Provider Address Undeliverable Mail Indicator value',               16,1);
								END
                        END;
                END;

            IF ( @p_pv_con_phone1 IS NOT NULL
                 AND @p_pv_con_phone1 <> ''
               )
                AND LEN(@p_pv_con_phone1) <> 0
                BEGIN
 
                    IF LEN(@p_pv_con_phone1) <> 10
					BEGIN
					 SET @Error_No = 210
                        RAISERROR('Provider Contact Phone 1 must be 10 digits long',16,1);
					END
      
                    SET @i_phone_err = 'N';
                  
                    SET @a_error_no = 211;
                   
                    SET @i_phone1 = SUBSTRING(@p_pv_con_phone1, 1, 3);
  
                    IF @i_phone1 < 0
                        BEGIN
                            SET @i_phone_err = 'Y' ;
                          
                        END;
         
                    SET @a_error_no = 212;
                 
                    SET @i_phone1 = SUBSTRING(@p_pv_con_phone1, 4, 3) ;
                 
                    IF @i_phone1 < 0
                        BEGIN
                            SET @i_phone_err = 'Y' ;
                         
                        END;
         
                    SET @a_error_no = 213;
             
                    SET @i_phone1 = SUBSTRING(@p_pv_con_phone1, 7, 4) ;
                 
                    IF @i_phone1 < 0
                        BEGIN
                            SET @i_phone_err = 'Y' 
                      
                        END;
         
                  
                    IF @i_phone_err = 'Y'
					BEGIN
					 SET @Error_No = 214
                        RAISERROR('Error in Provider Contact Phone 1',16,1);
					END
                END;
      
        
            IF ( @p_pv_con_ext1 IS NOT NULL
                 AND @p_pv_con_ext1 <> ''
               )
                AND LEN(@p_pv_con_ext1) <> 0
                BEGIN
                    SET @a_error_no = 215;
                   
                    SET @i_ext1 = SUBSTRING(@p_pv_con_ext1, 1, 5) ;
               
                    IF @i_ext1 < 0
					BEGIN
						 SET @Error_No = 215
                        RAISERROR('Error in Provider Contact Phone Extension 1',16,1);
					END
         
                
                    IF LEN(@p_pv_con_ext1) > 5
					BEGIN
					 SET @Error_No = 216
                        RAISERROR('Provider Contact Phone Extension 1 is more than 5 digits long',            0,1);
						EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
						END
                END;
      
      
            IF ( @p_pv_con_phone2 IS NOT NULL
                 AND @p_pv_con_phone2 <> ''
               )
                AND LEN(@p_pv_con_phone2) <> 0
                BEGIN
          
                    IF LEN(@p_pv_con_phone2) <> 10
				BEGIN
				 SET @Error_No = 220
                        RAISERROR('Provider Contact Phone 2 must be 10 digits long',16,1);
				END
         
                    SET @i_phone_err = 'N';
                
                    SET @a_error_no = 221;
                   
                    SET @i_phone2 = SUBSTRING(@p_pv_con_phone2, 1, 3);
                   
                    IF @i_phone2 < 0
  BEGIN
                            SET @i_phone_err = 'Y' ;
                           
                        END;
         
                    SET @a_error_no = 222;
                 
                    SET @i_phone2 = SUBSTRING(@p_pv_con_phone2, 4, 3) ;
                  
                    IF @i_phone2 < 0
                        BEGIN
                            SET @i_phone_err = 'Y';
                      
                        END;
         
                    SET @a_error_no = 223;
                   
                    SET @i_phone2 = SUBSTRING(@p_pv_con_phone2, 7, 4);
                
                    IF @i_phone2 < 0
                        BEGIN
                            SET @i_phone_err = 'Y' ;
                           
                        END;
   
                 
                    IF @i_phone_err = 'Y'
					BEGIN
					 SET @Error_No = 224
                        RAISERROR('Error in Provider Contact Phone 2',16,1);
					END
                END;
      
         
            IF ( @p_pv_con_ext2 IS NOT NULL
                 AND @p_pv_con_ext2 <> ''
               )
                AND LEN(@p_pv_con_ext2) <> 0
                BEGIN
                    SET @a_error_no = 225;
                  
                    SET @i_ext2 = SUBSTRING(@p_pv_con_ext2, 1, 5);
                   
                    IF @i_ext2 < 0
					BEGIN
					 SET @Error_No = 225
                        RAISERROR('Error in Provider Contact Phone Extension 2',16,1);
					END
         
                 
                    IF LEN(@p_pv_con_ext2) > 5
					BEGIN
					 SET @Error_No = 226
                        RAISERROR('Provider Contact Phone Extension 2 is more than 5 digits long',            0,1);
						EXECUTE dbo.usp_dl_log_error @a_batch_id,@pv_sp_id, @pv_sir_def_id, @p_sir_id,@Error_No;
					END
                END;
      
         
        IF ( @p_pv_con_fax IS NOT NULL
                 AND @p_pv_con_fax <> ''
               )
                AND LEN(@p_pv_con_fax) <> 0
                BEGIN
                  
                    IF LEN(@p_pv_con_fax) <> 10
					BEGIN
					 SET @Error_No = 230
                        RAISERROR('Provider Contact Fax must be 10 digits long',16,1);
					END
         
                    SET @i_phone_err = 'N' ;
                  
                    SET @a_error_no = 231;
                  
                    SET @i_fax = SUBSTRING(@p_pv_con_fax, 1, 3);
                 
                    IF @i_fax < 0
                        BEGIN
                            SET @i_phone_err = 'Y';
                          
                        END;
         
                    SET @a_error_no = 232;
                 
                    SET @i_fax = SUBSTRING(@p_pv_con_fax, 4, 3);
                 
                    IF @i_fax < 0
                        BEGIN
                            SET @i_phone_err = 'Y';
                        
                        END;
     
                    SET @a_error_no = 233;
                   
                    SET @i_fax = SUBSTRING(@p_pv_con_fax, 7, 4);
                
                    IF @i_fax < 0
                        BEGIN
                            SET @i_phone_err = 'Y' ;
                           
                        END;
         
       
                 IF @i_phone_err = 'Y'
				 BEGIN
					 SET @Error_No = 234
                        RAISERROR('Error in Provider Contact Fax',16,1);
				END
                END;
      
--  END IF


--trace off;

            IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = NULL;
                   
                    SET @SWP_Ret_Value2 = @i_pv_id;
                   
                    SET @SWP_Ret_Value3 = @i_fc_id;
                    
                    SET @SWP_Ret_Value4 = @as_pv_stat_eff;
               
         SET @SWP_Ret_Value5 = @as_fcassoc_eff;
  
SET @SWP_Ret_Value6 = @as_fcassoc_exp;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = NULL;
                    
                    SET @SWP_Ret_Value2 = @i_pv_id;
                   
                    SET @SWP_Ret_Value3 = @i_fc_id;
                    
                    SET @SWP_Ret_Value4 = @as_pv_stat_eff;
                  
                    SET @SWP_Ret_Value5 = @as_fcassoc_eff;
               
                    SET @SWP_Ret_Value6 = @as_fcassoc_exp;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH

		SET @i_error_no = ERROR_NUMBER();

		IF @i_error_no = 50000
			BEGIN
			EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @pv_sp_id, @pv_sir_def_id, @p_sir_id,
                                @Error_No;
			END

			 IF @i_fatal <> 1 
			 BEGIN
			 SET @s_error = 'Y'
			 END 

			    IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = NULL;
                   
                    SET @SWP_Ret_Value2 = @i_pv_id;
                   
                    SET @SWP_Ret_Value3 = @i_fc_id;
                    
                    SET @SWP_Ret_Value4 = @as_pv_stat_eff;
               
                    SET @SWP_Ret_Value5 = @as_fcassoc_eff;
                  
                    SET @SWP_Ret_Value6 = @as_fcassoc_exp;
                    RETURN;
                END;
				ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = NULL;
                    
                    SET @SWP_Ret_Value2 = @i_pv_id;
                   
                    SET @SWP_Ret_Value3 = @i_fc_id;
                    
                    SET @SWP_Ret_Value4 = @as_pv_stat_eff;
                  
                    SET @SWP_Ret_Value5 = @as_fcassoc_eff;
               
                    SET @SWP_Ret_Value6 = @as_fcassoc_exp;
                    RETURN;
                END;
            --SET @i_error_no = ERROR_NUMBER();
            --SET @i_isam_error = ERROR_LINE();
            --SET @s_error_descr = ERROR_MESSAGE();
            --SET @SWP_Ret_Value = @i_error_no;
            --SET @SWP_Ret_Value1 = @s_error_descr;
           
            --SET @SWP_Ret_Value2 = @i_pv_id;
          
            --SET @SWP_Ret_Value3 = @i_fc_id;
        
            --SET @SWP_Ret_Value4 = CONVERT(DATE, CONVERT(VARCHAR, @as_pv_stat_eff));
          
            --SET @SWP_Ret_Value5 = CONVERT(DATE, CONVERT(VARCHAR, @as_fcassoc_eff));
            
            --SET @SWP_Ret_Value6 = CONVERT(DATE, CONVERT(VARCHAR, @as_fcassoc_exp));

        END CATCH;
        SET NOCOUNT OFF;




--set debug file to "/tmp/dlp_valid_pv.trc";
--trace on;
    END;