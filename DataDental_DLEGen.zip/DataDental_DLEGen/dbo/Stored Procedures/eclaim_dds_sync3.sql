﻿CREATE PROCEDURE [dbo].[eclaim_dds_sync3]
    @AsOfDate DATE = NULL,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:28:28 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1





000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @RtnCode INT;
        DECLARE @ProcCnt INT;
        DECLARE @StatEffDt DATETIME;
        DECLARE @UpdCnt INT;
        DECLARE @i_isam_error INT;
        DECLARE @eClaimID INT;
        DECLARE @ddsClaimID INT;
        DECLARE @hUser CHAR(20);
        --DECLARE #SWV_cursor_var1 CURSOR;
        --DECLARE #SWV_cursor_var2 CURSOR;
        --DECLARE #SWV_cursor_var3 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;

                 
							
        --IF @AsOfDate = '1900-01-01'
		IF @AsOfDate IS NULL
            SET @AsOfDate = CONVERT(DATE, GETDATE());
        BEGIN TRY
            --set debug file to 'sync3.trc';
--trace on;

            SET @ProcCnt = 0; 
            SET @UpdCnt = 0; 

	IF OBJECT_ID('tempdb..#SWV_cursor_var1') IS NOT NULL
		DROP TABLE #SWV_cursor_var1
					
		CREATE TABLE #SWV_cursor_var1 
            (
              id INT IDENTITY ,
              eclaim_id INT
            );

            INSERT  INTO #SWV_cursor_var1
                    ( eclaim_id
                    )
                    SELECT  e.eclaim_id
                    FROM    dbo.eclaim_h e ( NOLOCK ) ,
                            dbo.claim_h c ( NOLOCK )
                    WHERE   e.dds_claim_id != 0
                            AND e.dds_claim_id = c.claim_id
                            AND CONVERT(DATE, c.entered_at) >= @AsOfDate;

           /* SET #SWV_cursor_var1 = CURSOR  FOR SELECT e.eclaim_id
	       FROM dbo.eclaim_h e (NOLOCK),
	   dbo.claim_h c (NOLOCK)
      WHERE e.dds_claim_id != 0
      AND e.dds_claim_id = c.claim_id
      AND CONVERT(DATE,c.entered_at) >= @AsOfDate;
            OPEN #SWV_cursor_var1;
            FETCH NEXT FROM #SWV_cursor_var1 INTO @eClaimID;
            WHILE @@FETCH_STATUS = 0
			*/

            DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    #SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
                    SELECT  @eClaimID = eclaim_id
                    FROM    #SWV_cursor_var1
                    WHERE   id = @cur_i;
			
			IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
			DROP TABLE #SWV_cursor_var2

			CREATE TABLE #SWV_cursor_var2
            (
              id INT IDENTITY ,
              eff_date DATETIME ,
              h_user CHAR(20)
            );
                    INSERT  INTO #SWV_cursor_var2
                            ( eff_date ,
                              h_user
                            )
                            SELECT  eff_date ,
                                    h_user
                            FROM    dbo.eclaim_status (NOLOCK)
                            WHERE   eclaim_id = @eClaimID;

                    /*SET #SWV_cursor_var2 = CURSOR  FOR SELECT eff_date, h_user 
         FROM dbo.eclaim_status (NOLOCK) WHERE eclaim_id = @eClaimID;
                    OPEN #SWV_cursor_var2;
                    FETCH NEXT FROM #SWV_cursor_var2 INTO @StatEffDt, @hUser;
                    WHILE @@FETCH_STATUS = 0 */
                    DECLARE @cur2_cnt INT ,
                     @cur2_i INT;

                    SET @cur2_i = 1;

					--Get the no. of records for the cursor
                    SELECT  @cur2_cnt = COUNT(1)
                    FROM    #SWV_cursor_var2;
					
					--while @@FETCH_STATUS = 0
                    WHILE ( @cur2_i <= @cur2_cnt )
                        BEGIN
                            SELECT  @StatEffDt = eff_date ,
                                    @hUser = h_user
                            FROM    #SWV_cursor_var2
                            WHERE   id = @cur2_i;
                            SET @ProcCnt = @ProcCnt + 1;
                            EXECUTE dbo.process_actlog @eClaimID, @StatEffDt,
                                @hUser, @RtnCode OUTPUT, @s_error_descr OUTPUT;
                            IF @RtnCode > 0
                                SET @UpdCnt = @UpdCnt + @RtnCode;
                            --FETCH NEXT FROM #SWV_cursor_var2 INTO @StatEffDt,@hUser;
                            SET @cur2_i = @cur2_i + 1;
                        END;
                    -- CLOSE #SWV_cursor_var2;
                    
                   -- FETCH NEXT FROM #SWV_cursor_var1 INTO @eClaimID;
                    SET @cur_i = @cur_i + 1;
                END;
            -- CLOSE #SWV_cursor_var1;

-- Now get newly updated statuses
		IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
			DROP TABLE #SWV_cursor_var3

            CREATE  TABLE #SWV_cursor_var3 
            (
              id INT IDENTITY ,
              eclaim_id INT ,
              eff_date DATETIME ,
              h_user CHAR(20)
            );

            INSERT  INTO #SWV_cursor_var3
                    ( eclaim_id ,
                      eff_date ,
                      h_user
                    )
                    SELECT  s.eclaim_id ,
                            s.eff_date ,
                            s.h_user
                    FROM    dbo.eclaim_status s ( NOLOCK ) ,
                            dbo.eclaim_h h ( NOLOCK )
                    WHERE   s.eclaim_id = h.eclaim_id
                            AND h.dds_claim_id != 0
                            AND CONVERT(DATE, s.eff_date) >= @AsOfDate;
            /*
			SET #SWV_cursor_var3 = CURSOR  FOR SELECT s.eclaim_id, s.eff_date, s.h_user
	        FROM dbo.eclaim_status s (NOLOCK),
	   dbo.eclaim_h h (NOLOCK)
      WHERE s.eclaim_id = h.eclaim_id
      AND h.dds_claim_id != 0
      AND CONVERT(DATE,s.eff_date) >= @AsOfDate;
            OPEN #SWV_cursor_var3;
            FETCH NEXT FROM #SWV_cursor_var3 INTO @eClaimID, @StatEffDt,
                @hUser;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cur3_cnt INT ,
                @cur3_i INT;

            SET @cur3_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur3_cnt = COUNT(1)
            FROM    #SWV_cursor_var3;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur3_i <= @cur3_cnt )
                BEGIN
                    SELECT  @eClaimID = eclaim_id ,
                            @StatEffDt = eff_date ,
                            @hUser = h_user
                    FROM    #SWV_cursor_var3
                    WHERE   id = @cur3_i;
                    SET @ProcCnt = @ProcCnt + 1;
                    EXECUTE dbo.process_actlog @eClaimID, @StatEffDt, @hUser,
                        @RtnCode OUTPUT, @s_error_descr OUTPUT;
                    IF @RtnCode > 0
                        SET @UpdCnt = @UpdCnt + @RtnCode;
	
                    
                   -- FETCH NEXT FROM #SWV_cursor_var3 INTO @eClaimID,@StatEffDt, @hUser;
                    SET @cur3_i = @cur3_i + 1;
                END;
           -- CLOSE #SWV_cursor_var3;
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Events Found: ', @ProcCnt,
                                         ' Updated: ', @UpdCnt);
            RETURN;
        END TRY
     BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
              ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


----------------------------------------------------------------------

    END;