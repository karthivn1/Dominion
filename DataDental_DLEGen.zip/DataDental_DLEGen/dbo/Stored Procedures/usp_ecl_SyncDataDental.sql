﻿CREATE PROCEDURE [dbo].[usp_ecl_SyncDataDental]
AS
BEGIN
	DECLARE @SYNCTODATADENTAL INT
	DECLARE @SUBMITTEDSTATUS INT
	DECLARE @LOCKEDSTATUS INT
	DECLARE @COMPLETEDSTATUS INT
	DECLARE @BATCH_ID INT
	DECLARE @JobID INT
	SET @SUBMITTEDSTATUS =1
	SET @SYNCTODATADENTAL =2
	SET @LOCKEDSTATUS= 2
	SET @COMPLETEDSTATUS =4
	SET @BATCH_ID =0 
	SELECT  @BATCH_ID = ISNULL(batch_id,0)  FROM [batch_process_details] WHERE event_id =  @SYNCTODATADENTAL AND status= @SUBMITTEDSTATUS ORDER BY batch_id ASC

	
	IF (@BATCH_ID <> 0 )
	BEGIN
		UPDATE [batch_process_details] SET status = @LOCKEDSTATUS WHERE batch_id = @BATCH_ID
		BEGIN TRY
		DECLARE	@SWP_Ret_Value int,
				@SWP_Ret_Value1 varchar(MAX)

		BEGIN TRY
			INSERT INTO [dbo].[eclaim_report] ([StartDate],[Source],[ProcName],[StatusId],[HUser])
			VALUES (GETDATE(),'SyncDD', 'eclaim_dds_sync2',1,SYSTEM_USER);
			SET @JobID = SCOPE_IDENTITY();
			EXEC	[dbo].[eclaim_dds_sync2]
					@SWP_Ret_Value = @SWP_Ret_Value OUTPUT,
					@SWP_Ret_Value1 = @SWP_Ret_Value1 OUTPUT

			SELECT	@SWP_Ret_Value as N'@SWP_Ret_Value',
					@SWP_Ret_Value1 as N'@SWP_Ret_Value1'

			IF(@SWP_Ret_Value<0)
				BEGIN
					RAISERROR (@SWP_Ret_Value1, 16, 1 );
				END
			ELSE 
			BEGIN
				UPDATE dbo.eclaim_report SET StatusId=2 WHERE JobId=@JobID
			END

		END TRY
		BEGIN CATCH
			UPDATE dbo.eclaim_report SET StatusId=3,ErrorDetail=ERROR_MESSAGE() WHERE JobId=@JobID
		END CATCH

		BEGIN TRY
			UPDATE dbo.eclaim_report SET ProcName1='eclaim_dds_sync3',StatusId1=1 WHERE JobId=@JobID
			EXEC	[dbo].[eclaim_dds_sync3]
					@SWP_Ret_Value = @SWP_Ret_Value OUTPUT,
					@SWP_Ret_Value1 = @SWP_Ret_Value1 OUTPUT

			SELECT	@SWP_Ret_Value as N'@SWP_Ret_Value',
					@SWP_Ret_Value1 as N'@SWP_Ret_Value1'
			
			IF(@SWP_Ret_Value<0)
				BEGIN
					RAISERROR (@SWP_Ret_Value1, 16, 1 );
				END
			ELSE 
			BEGIN
				UPDATE dbo.eclaim_report SET ProcName1='eclaim_dds_sync3',StatusId1=2 WHERE JobId=@JobID 
			END

		END TRY
		BEGIN CATCH
			UPDATE dbo.eclaim_report SET ProcName1='eclaim_dds_sync3',StatusId1=3,ErrorDetail1=ERROR_MESSAGE()
					 WHERE JobId=@JobID
		END CATCH

		BEGIN TRY
			UPDATE dbo.eclaim_report SET ProcName2='eclaim_dds_sync1',StatusId2=1 WHERE JobId=@JobID
			EXEC	[dbo].[eclaim_dds_sync1]
					@SWP_Ret_Value = @SWP_Ret_Value OUTPUT,
					@SWP_Ret_Value1 = @SWP_Ret_Value1 OUTPUT

			SELECT	@SWP_Ret_Value as N'@SWP_Ret_Value',
					@SWP_Ret_Value1 as N'@SWP_Ret_Value1'
			
			IF(@SWP_Ret_Value<0)
				BEGIN
					RAISERROR (@SWP_Ret_Value1, 16, 1 );
				END
			ELSE 
			BEGIN
				UPDATE dbo.eclaim_report SET ProcName2='eclaim_dds_sync1',StatusId2=2,EndDate=GETDATE()
				 WHERE JobId=@JobID 
			END

		END TRY
		BEGIN CATCH
			UPDATE dbo.eclaim_report SET ProcName2='eclaim_dds_sync1',StatusId2=3,ErrorDetail2=ERROR_MESSAGE(),EndDate=GETDATE()
					 WHERE JobId=@JobID
		END CATCH
	END TRY
	BEGIN CATCH
		UPDATE dbo.eclaim_report SET FullErrorDetail=ERROR_MESSAGE()  WHERE JobId=@JobID
	END CATCH
	UPDATE [batch_process_details] SET status = @COMPLETEDSTATUS , completed_time =getdate() WHERE batch_id = @BATCH_ID
	END
END