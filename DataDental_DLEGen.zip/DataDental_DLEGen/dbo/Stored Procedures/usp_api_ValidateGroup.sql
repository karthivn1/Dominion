﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_ValidateGroup]
@GroupID INT,@GroupAltID Char(20),@ErrorMsg nVarchar(50) out
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
BEGIN TRY
	SET NOCOUNT ON;

DECLARE @gID INT=0;

IF @GroupID>0
BEGIN
SET @ErrorMsg='';
			IF NOT EXISTS(SELECT 
				g.group_id
		        FROM [group] g(nolock), group_status gs(nolock)
				WHERE g.group_id=@GroupID  and g.group_id = gs.group_id )
				BEGIN
				  SET @ErrorMsg='Group could not be found with the given criteria ';
				  RETURN @gID
				END

				 SELECT @gID=g.group_id FROM [group] g(nolock), group_status gs(nolock)
				 WHERE g.group_id=@GroupID and g.group_id = gs.group_id

			END
			ELSE IF LEN(@GroupAltID)>0
			BEGIN

			IF NOT EXISTS (SELECT 
				g.group_id FROM [group] g(nolock), group_status gs(nolock)
				WHERE g.alt_id=@GroupAltID AND g.group_id = gs.group_id)
				 BEGIN
				     SET @ErrorMsg='Group could not be found with the given criteria ';
					RETURN @gID
				 END
				  SELECT @gID=g.group_id FROM [group] g(nolock), group_status gs(nolock)
				  WHERE g.alt_id=@GroupAltID AND g.group_id = gs.group_id
			END

RETURN @gID
END TRY
BEGIN CATCH
THROW;
END CATCH

END