﻿CREATE PROCEDURE [dbo].[dlp_bu_dep_elig]
@a_batch_id INT ,
@a_sub_sir_id INT ,
@a_sub_id INT ,
@a_mb_gr_pl_id INT

/*
Modified Date : 05/06/1999
Modified By : Wee Tan
Reason :
Modified Date : 09/15/1999
Modified By : Wee Tan
Reason : having mulitple record in
rlmbrt when dep is added/reinstated
before sub's most current rate effective date.
So, if it is, raise error out (377 for new add,
378 for reinstate)
Modified Date : 06/15/00
Modified By : Ameeta
Reason : Added new action_code "RI", "PA"
*/
AS
BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
DECLARE @n_error_no INT;
DECLARE @n_isam_error INT;
DECLARE @n_error_descr VARCHAR(64);
DECLARE @def_group_id INT;
DECLARE @def_plan_id INT;
DECLARE @def_facility_id INT;
DECLARE @n_member_id INT;
DECLARE @n_ffs_plan INT;
DECLARE @n_sub_id INT;
DECLARE @n_sub_alt_id CHAR(20);
DECLARE @n_sub_group_id INT;
DECLARE @n_sub_plan_id INT;
DECLARE @n_sub_facility_id INT;
DECLARE @n_sub_plan_eff DATE;
DECLARE @n_sub_plan_term DATE;
DECLARE @n_sub_fac_eff DATE;
DECLARE @n_sub_action_code CHAR(2);
DECLARE @n_sub_key CHAR(2);
DECLARE @n_sub_type CHAR(2);
DECLARE @n_sub_dls_status CHAR(1);
DECLARE @s_has_deps_err CHAR(1);
DECLARE @s_has_dep_err CHAR(1);
DECLARE @s_proc_name VARCHAR(14);
DECLARE @s_sir_def_name VARCHAR(14);
DECLARE @i_fatal INT;
DECLARE @i_member_id INT;
DECLARE @i_sub_id INT;
DECLARE @n_mb_gr_pl_id INT;
DECLARE @n_rlplfc_id INT;
DECLARE @n_facility_id INT;
DECLARE @n_rlplfc_eff DATE;
DECLARE @n_rlplfc_exp DATE;
DECLARE @n_alt_id CHAR(20);
DECLARE @n_count INT;
DECLARE @n_eff_date DATE;
DECLARE @n_exp_date DATE;
DECLARE @n_action_code CHAR(2);
DECLARE @n_sir_status CHAR(1);
DECLARE @n_tmp_term_date DATE;
DECLARE @n_rate_code CHAR(2);
DECLARE @num_fac_count INT;
DECLARE @n_eff_rt_date DATE;
DECLARE @d_eff_gr_pl DATE;
DECLARE @d_eff_date DATE;
DECLARE @d_exp_date DATE;
DECLARE @new_member_id INT;
DECLARE @new_group_id INT;
DECLARE @new_plan_id INT;
DECLARE @as_facility_id INT;
DECLARE @as_action_code CHAR(2);
DECLARE @as_member_id INT;
DECLARE @as_sub_id INT;
DECLARE @as_plan_eff_date DATE;
DECLARE @as_plan_term_date DATE;
DECLARE @as_fac_eff_date DATE;
DECLARE @n_change_address CHAR(2);
DECLARE @temp_fac INT;

DECLARE @n_dep_count INT;
DECLARE @i_sp_id INT;
DECLARE @i_sir_def_id INT
DECLARE @n_lookup_ssn_alt CHAR(1);
DECLARE @n_has_facility_id CHAR(1);
DECLARE @n_new_mb_w_fc_id CHAR(1);
DECLARE @n_multiple_gp CHAR(1);
DECLARE @n_add_to_cl_fc CHAR(1);
DECLARE @n_calculate_rc CHAR(1);
DECLARE @n_has_address CHAR(1);
DECLARE @n_has_plan_eff CHAR(1);
DECLARE @n_has_fac_eff CHAR(1);
DECLARE @n_has_s_plan_term CHAR(1);
DECLARE @n_has_d_plan_term CHAR(1);
DECLARE @d_process_eff_dt DATE;
DECLARE @d_process_exp_dt DATE;
DECLARE @d_process_eff_per DATE;
DECLARE @d_process_exp_per DATE;
DECLARE @i_sub_age INT;
DECLARE @n_sub_age CHAR(11);
DECLARE @i_config_id INT;
DECLARE @t_sir_id INT;
DECLARE @t_sub_sir_id INT;
DECLARE @t_subscriber CHAR(2);
DECLARE @t_alt_id CHAR(20);
DECLARE @t_ssn CHAR(11);
DECLARE @t_sub_ssn CHAR(11);
DECLARE @t_sub_alt_id CHAR(20);
DECLARE @t_member_code CHAR(2);
DECLARE @t_last_name CHAR(15);
DECLARE @t_first_name CHAR(15);
DECLARE @t_middle_init CHAR(1);
DECLARE @t_date_of_birth DATE;
DECLARE @t_student_flag CHAR(1);
DECLARE @t_disable_flag CHAR(1);
DECLARE @t_cobra_flag CHAR(1);
DECLARE @t_address1 CHAR(30);
DECLARE @t_address2 CHAR(30);
DECLARE @t_city CHAR(30);
DECLARE @t_state CHAR(2);
DECLARE @t_zip CHAR(5);
DECLARE @t_zipx CHAR(4);
DECLARE @t_home_phone CHAR(10);
DECLARE @t_home_ext CHAR(4);
DECLARE @t_work_phone CHAR(10);
DECLARE @t_work_ext CHAR(4);
DECLARE @t_rate_code CHAR(2);
DECLARE @t_plan_eff_date DATE;
DECLARE @t_plan_term_date DATE;
DECLARE @t_fac_eff_date DATE;
DECLARE @t_group_id INT;
DECLARE @t_plan_id INT;
DECLARE @t_facility_id INT;
DECLARE @t_def_key CHAR(2);
DECLARE @t_type CHAR(2);
DECLARE @t_sub_id INT;
DECLARE @t_member_id INT;
DECLARE @t_src_id CHAR(20);
DECLARE @n_process_count INT;
DECLARE @n_succ_count INT;
--DECLARE @cDepSir CURSOR;
DECLARE @cDepSir TABLE
(
id INT IDENTITY ,
dls_sir_id INT ,
dls_sub_sir_id INT ,
member_flag CHAR(2) ,
alt_id CHAR(20) ,
ssn CHAR(11) ,
sub_ssn CHAR(11) ,
sub_alt_id CHAR(20) ,
member_code CHAR(3) ,
last_name CHAR(15) ,
first_name CHAR(15) ,
middle_init CHAR(1) ,
date_of_birth DATE ,
student_flag CHAR(1) ,
disable_flag CHAR(1) ,
cobra_flag CHAR (1),
address1 CHAR (30),
address2 CHAR (30),
city CHAR(20) ,
[state] CHAR(2) ,
zip CHAR(5) ,
zipx CHAR(4) ,
home_phone CHAR(10) ,
home_ext CHAR(5) ,
work_phone CHAR (10),
work_ext CHAR(5) ,
rate_code CHAR(2) ,
plan_eff_date DATE ,
plan_term_date DATE ,
facility_eff_date DATE ,
dls_group_id INT ,
dls_plan_id INT ,
facility_id INT ,
def_key CHAR(2) ,
[type] CHAR(2) ,
source_id CHAR(20) ,
member_id INT ,
group_id INT ,
plan_id INT
);
DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par0 DATE;
DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par1 DATE;
DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par2 DATE;
DECLARE @SWV_func_DL_LOG_ACTION_par13 DATE;
DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par3 DATE;
DECLARE @SWV_func_DL_LOG_ACTION_par16 DATE;
DECLARE @SWV_func_DL_LOG_ACTION_par17 DATE;
DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par4 DATE;
DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par5 DATE;

SET NOCOUNT ON;
SET @i_sp_id = 0 ;
SET @i_sir_def_id = 0 ;
SET @n_lookup_ssn_alt = '' 
SET @n_has_facility_id = '' 
SET @n_new_mb_w_fc_id = '' 
SET @n_multiple_gp = '' 
SET @n_add_to_cl_fc = ''
SET @n_calculate_rc = '' 
SET @n_has_address = '' 
SET @n_has_plan_eff = '' 
SET @n_has_fac_eff = '' 
SET @n_has_s_plan_term = '' 
SET @n_has_d_plan_term = '' 
SET @d_process_eff_dt = NULL 
SET @d_process_exp_dt = NULL 
SET @d_process_eff_per =NULL 
SET @d_process_exp_per = NULL 
SET @i_sub_age = 0 
SET @n_sub_age = '' 
SET @i_config_id = 0 
SET @t_sir_id = 0 
SET @t_sub_sir_id = 0 
SET @t_subscriber = '' 
SET @t_alt_id = '' 
SET @t_ssn = '' 
SET @t_sub_ssn ='' 
SET @t_sub_alt_id = '' 
SET @t_member_code ='' 
SET @t_last_name = '' 
SET @t_first_name = '' 
SET @t_middle_init = '' 
SET @t_date_of_birth = NULL 
SET @t_student_flag = '' 
SET @t_disable_flag = '' 
SET @t_cobra_flag = '' 
SET @t_address1 = ''
SET @t_address2 = ''
SET @t_city = ''
SET @t_state = '' 
SET @t_zip = '' 
SET @t_zipx = '' 
SET @t_home_phone = ''
SET @t_home_ext = '' 
SET @t_work_phone = '' 
SET @t_work_ext = '' 
SET @t_rate_code = '' 
SET @t_plan_eff_date = NULL
SET @t_plan_term_date = NULL 
SET @t_fac_eff_date = NULL 
SET @t_group_id = 0 
SET @t_plan_id = 0 
SET @t_facility_id = 0 
SET @t_def_key = '' 
SET @t_type = ''
SET @t_sub_id = 0 
SET @t_member_id = 0 
SET @t_src_id = '' 
--SET @n_process_count = 0 
SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3
--SET @n_succ_count = 0 
SET @s_has_deps_err = 'N';
SET @s_proc_name = 'bu_eligibility';
SET @s_sir_def_name = 'elig';


	select @n_has_plan_eff = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_plan_eff' and  BatchId = @a_batch_id AND Module_Id = 3
	select @n_has_facility_id = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
	
	select @n_has_d_plan_term = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_d_plan_term' and  BatchId = @a_batch_id AND Module_Id = 3
	select @n_new_mb_w_fc_id = VarValue from GlobalVar(NOLOCK) where VarName = 'n_new_mb_w_fc_id' and  BatchId = @a_batch_id AND Module_Id = 3
	select @n_has_s_plan_term = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_s_plan_term' and  BatchId = @a_batch_id AND Module_Id = 3

	EXECUTE @i_sir_def_id = dbo.dl_get_sir_def_id 'elig';
	EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_eligibility';
           

SELECT @n_sub_id = dls_member_id ,
@n_sub_alt_id = alt_id ,
@n_sub_group_id = dls_group_id ,
@n_sub_plan_id = dls_plan_id ,
@n_sub_facility_id = facility_id ,
@n_sub_plan_eff = plan_eff_date ,
@n_sub_plan_term = plan_term_date ,
@n_sub_fac_eff = facility_eff_date ,
@n_sub_action_code = dls_action_code ,
@n_sub_key = def_key ,
@n_sub_type = type ,
@n_sub_dls_status = dls_status
FROM dbo.dls_elig (NOLOCK)
WHERE dls_sir_id = @a_sub_sir_id;
SET @n_dep_count = 0;

--LET i_fatal = dl_log_error(a_batch_id, i_sp_id, i_sir_def_id,
-- t_sir_id, n_isam_error);
INSERT INTO @cDepSir
( dls_sir_id ,
dls_sub_sir_id ,
member_flag ,
alt_id ,
ssn ,
sub_ssn ,
sub_alt_id ,
member_code ,
last_name ,
first_name ,
middle_init ,
date_of_birth ,
student_flag ,
disable_flag ,
cobra_flag ,
address1 ,
address2 ,
city ,
state ,
zip ,
zipx ,
home_phone ,
home_ext ,
work_phone ,
work_ext ,
rate_code ,
plan_eff_date ,
plan_term_date ,
facility_eff_date ,
dls_group_id ,
dls_plan_id ,
facility_id ,
def_key ,
type ,
source_id ,
member_id ,
group_id ,
plan_id
)
SELECT dls_sir_id ,
dls_sub_sir_id ,
member_flag ,
alt_id ,
ssn ,
sub_ssn ,
sub_alt_id ,
member_code ,
last_name ,
first_name ,
middle_init ,
date_of_birth ,
student_flag ,
disable_flag ,
cobra_flag ,
address1 ,
address2 ,
city ,
state ,
zip ,
zipx ,
home_phone ,
home_ext ,
work_phone ,
work_ext ,
rate_code ,
plan_eff_date ,
plan_term_date ,
facility_eff_date ,
dls_group_id ,
dls_plan_id ,
facility_id ,
def_key ,
type ,
source_id ,
member_id ,
group_id ,
plan_id
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_sub_sir_id = @a_sub_sir_id
AND member_flag != '00'
AND
dls_status = 'V'
--dls_status NOT IN ( 'L', 'E', 'P', 'U' );
/* SET @cDepSir = CURSOR FOR SELECT dls_sir_id, dls_sub_sir_id, member_flag, alt_id, ssn, sub_ssn,
sub_alt_id, member_code, last_name, first_name, middle_init,
date_of_birth, student_flag, disable_flag, cobra_flag,
address1, address2, city, state, zip, zipx, home_phone,
home_ext, work_phone, work_ext, rate_code, plan_eff_date,
plan_term_date, facility_eff_date, dls_group_id, dls_plan_id, facility_id,
def_key, type, source_id, member_id, group_id, plan_id
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id AND
dls_sub_sir_id = @a_sub_sir_id AND
member_flag != '00' AND
--dls_status = "V"
dls_status NOT IN('L','E','P','U');
OPEN @cDepSir;
　
FETCH NEXT FROM @cDepSir INTO @t_sir_id, @t_sub_sir_id, @t_subscriber,
@t_alt_id, @t_ssn, @t_sub_ssn, @t_sub_alt_id, @t_member_code,
@t_last_name, @t_first_name, @t_middle_init, @t_date_of_birth,
@t_student_flag, @t_disable_flag, @t_cobra_flag, @t_address1,
@t_address2, @t_city, @t_state, @t_zip, @t_zipx, @t_home_phone,
@t_home_ext, @t_work_phone, @t_work_ext, @t_rate_code,
@t_plan_eff_date, @t_plan_term_date, @t_fac_eff_date, @t_group_id,
@t_plan_id, @t_facility_id, @t_def_key, @t_type, @t_src_id,
@new_member_id, @new_group_id, @new_plan_id;
WHILE @@FETCH_STATUS = 0
*/

DECLARE @cur1_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur1_cnt = COUNT(1)
FROM @cDepSir;
--while @@FETCH_STATUS = 0
WHILE ( @cur_i <= @cur1_cnt )
BEGIN
SELECT @t_sir_id = dls_sir_id ,
@t_sub_sir_id = dls_sub_sir_id ,
@t_subscriber = member_flag ,
@t_alt_id = alt_id ,
@t_ssn = ssn ,
@t_sub_ssn = sub_ssn ,
@t_sub_alt_id = sub_alt_id ,
@t_member_code = member_code ,
@t_last_name = last_name ,
@t_first_name = first_name ,
@t_middle_init = middle_init , 
@t_date_of_birth = date_of_birth ,
@t_student_flag = student_flag ,
@t_disable_flag = disable_flag ,
@t_cobra_flag = cobra_flag ,
@t_address1 = address1 ,
@t_address2 = address2 ,
@t_city = city ,
@t_state = [state] ,
@t_zip = zip ,
@t_zipx = zipx ,
@t_home_phone = home_phone ,
@t_home_ext = home_ext ,
@t_work_phone = work_phone ,
@t_work_ext = work_ext ,
@t_rate_code = rate_code ,
@t_plan_eff_date =plan_eff_date ,
@t_plan_term_date = plan_term_date ,
@t_fac_eff_date = facility_eff_date ,
@t_group_id = group_id ,
@t_plan_id = plan_id ,
@t_facility_id = facility_id ,
@t_def_key = def_key ,
@t_type =[type],
@t_src_id = source_id ,
@new_member_id = member_id ,
@new_group_id = group_id ,
@new_plan_id = plan_id
FROM @cDepSir
WHERE id = @cur_i;
/*DECLARE #SWV_cursor_var14 CURSOR;
DECLARE #SWV_cursor_var15 CURSOR;
*/

UPDATE dbo.GlobalVar set VarValue = @t_sir_id where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_sub_sir_id where VarName = 't_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_subscriber where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_alt_id where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_ssn where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_sub_ssn where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_sub_alt_id where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_member_code where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_last_name where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_first_name where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_middle_init where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_date_of_birth where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_student_flag where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_disable_flag where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_cobra_flag where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_address1 where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_address2 where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_city where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_state where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_zip where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_zipx where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_home_phone where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_home_ext where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_work_phone where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_work_ext where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_rate_code where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_plan_eff_date where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_plan_term_date where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_fac_eff_date where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_group_id where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_plan_id where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_facility_id where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_def_key where VarName = 't_def_key' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_type where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @t_src_id where VarName = 't_src_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @new_member_id where VarName = 'new_member_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @new_group_id where VarName = 'new_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
UPDATE dbo.GlobalVar set VarValue = @new_plan_id where VarName = 'new_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3


IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var14', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var14
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var15', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var15
END

CREATE TABLE #SWV_cursor_var14 
(
id INT IDENTITY ,
mb_gr_pl_id INT
);
CREATE TABLE #SWV_cursor_var15
(
id INT IDENTITY ,
eff_rt_date DATE ,
rate_code CHAR(2)
);
BEGIN TRY
SET @as_facility_id = NULL;
SET @as_fac_eff_date = NULL;
SET @as_action_code = NULL;
SET @as_member_id = NULL;
SET @as_sub_id = NULL;
SET @as_plan_eff_date = NULL;
SET @as_plan_term_date = NULL;
SET @n_change_address = NULL;
SELECT @d_process_eff_per=VarValue FROM dbo.GlobalVar(NOLOCK) where VarName = 'd_process_eff_per' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @d_process_exp_per=VarValue FROM dbo.GlobalVar(NOLOCK) where VarName = 'd_process_exp_per' and  BatchId = @a_batch_id AND Module_Id = 3
SET @d_process_eff_dt = @d_process_eff_per;
SET @d_process_exp_dt = @d_process_exp_per
--LET as_fac_eff_date = t_fac_eff_date;
SET @n_process_count = @n_process_count + 1;

UPDATE GlobalVar
SET VarValue = @n_process_count
WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_dep_count = @n_dep_count + 1;
SET @s_has_dep_err = 'N';
EXECUTE @n_error_no = dbo.dlp_pre_check @a_batch_id,
@t_sir_id;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
UPDATE dbo.dls_elig
SET dls_status = 'E'
where dls_sir_id=@t_sir_id
-- WHERE CURRENT OF @cDepSir;
GOTO SWL_Label20;
END;
IF @n_sub_dls_status = 'E'
BEGIN
SET @n_isam_error = 500
RAISERROR('Dep''s Subscriber record has error',16,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
UPDATE dbo.dls_elig
SET dls_status = 'E'
where dls_sir_id=@t_sir_id
--WHERE CURRENT OF @cDepSir;
GOTO SWL_Label20;
END;
IF @n_has_plan_eff != 'Y'
BEGIN
SET @t_plan_eff_date = @d_process_eff_dt
END;
IF @n_has_s_plan_term != 'Y'
BEGIN
SET @t_plan_term_date = NULL ;
END;
IF @t_plan_eff_date > @d_process_eff_dt
BEGIN
SET @d_process_eff_dt = @t_plan_eff_date
END;
IF @t_fac_eff_date < @t_plan_eff_date
BEGIN
SET @t_fac_eff_date = @t_plan_eff_date
END;
/* 20130104$$ks - if def_key and type spell "FILE" then group_id and plan_id must be
* provided within file
*/
IF @t_def_key = 'FI'
AND @t_type = 'LE'
AND ( @new_group_id IS NULL
OR @new_group_id = 0
OR @new_plan_id IS NULL
OR @new_plan_id = 0
)
BEGIN
SET @n_isam_error = 999
RAISERROR('New err def_key and type = FILE but group or plan not specif ied',
16,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
/* 20130104$$ks - don't look up group and plan if def_key and type spell "FILE"
* and group_id and plan ID are provided
*/
IF @t_def_key = 'FI'
AND @t_type = 'LE'
BEGIN
SET @def_group_id = @new_group_id;
SET @def_plan_id = @new_plan_id;
SET @def_facility_id = @t_facility_id;
SET @n_error_no = 1;
END;
ELSE
BEGIN

EXECUTE dbo.dlp_group_setup @i_config_id,
@t_def_key, @t_type, @t_sir_id,
@n_error_no OUTPUT, @def_group_id OUTPUT,
@def_plan_id OUTPUT,
@def_facility_id OUTPUT;
END;
IF @n_error_no < 0
BEGIN
BEGIN
SET @n_isam_error = -(@n_error_no)
RAISERROR('No default group/plan/facility setup',16,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_process_count = @n_process_count + 1;

UPDATE GlobalVar
SET VarValue = @n_process_count
WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3

UPDATE dbo.dls_elig
SET dls_status = 'E'
where dls_sir_id=@t_sir_id
--WHERE CURRENT OF @cDepSir;
GOTO SWL_Label20;
END;
SET @n_ffs_plan = 1;
IF NOT EXISTS ( SELECT *
FROM dbo.[plan] (NOLOCK) ,
dbo.ins_opt (NOLOCK)
WHERE dbo.[plan].plan_id = @def_plan_id
AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
AND dbo.ins_opt.ins_opt_qual = 'I' )
SET @n_ffs_plan = 0;
IF @n_has_plan_eff != 'Y'
BEGIN
SET @t_plan_eff_date = @d_process_eff_dt
END;
IF @t_plan_eff_date < @n_sub_plan_eff
BEGIN
SET @t_plan_eff_date = @n_sub_plan_eff
END;
IF @t_plan_term_date IS NOT NULL
BEGIN
IF @t_plan_term_date < @t_plan_eff_date
BEGIN
SET @n_isam_error = 400
RAISERROR('Dep plan term before effective',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
END;
--$$ks-new-error
IF @new_member_id IS NULL
SET @new_member_id = 0;
IF ( ( @a_sub_id IS NOT NULL
AND @a_sub_id > 0
)
AND ( @new_member_id > 0 )
)
IF ( NOT EXISTS ( SELECT member_id
FROM dbo.member (NOLOCK)
WHERE member_id = @new_member_id
AND family_id = @a_sub_id )
)
BEGIN
SET @n_isam_error = 304
RAISERROR('New error',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_sub_action_code = 'SA'
--$$ks-new-error - need to check if new_member_id > 0 and create error can't have existing
-- dependent with new subscriber
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT, @n_member_id OUTPUT,
@n_sub_id OUTPUT;

SET @as_member_id = @n_member_id;
SET @as_sub_id = @a_sub_id;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
--What if n_count were 2, what should happen? It should, I would
--think, raise the same exception of -746, 304 as given just below
--when n_count is one.
IF ( @n_count = 2 )
BEGIN
SET @n_isam_error = 304
RAISERROR('Existing dependent with New Subscriber',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_count = 1
BEGIN
SET @n_isam_error = 304
RAISERROR('Existing dependent with New Subscriber',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_count = 0
BEGIN
IF @t_plan_term_date IS NULL
BEGIN
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_ffs_plan = 0
BEGIN
IF @n_new_mb_w_fc_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
SET @as_facility_id = @def_facility_id;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
IF @n_sub_facility_id != @t_facility_id
BEGIN
---CH001
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
ELSE
BEGIN
SET @as_facility_id = @def_facility_id;
----CH001
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@as_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
ELSE
SET @as_facility_id = NULL;
END;
ELSE
BEGIN
SET @n_isam_error = 303
RAISERROR('New Dependent with Term date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @s_has_dep_err != 'Y'
BEGIN
SET @as_action_code = 'DA';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id, @as_action_code,
@t_plan_eff_date;
END;
END;
END;
IF @n_sub_action_code = 'PC'
/* 20131220$$ks - allow input of actual member ID from file
*/
BEGIN
IF @new_member_id > 0
BEGIN
SET @n_count = 1;
SET @n_member_id = @new_member_id;
SET @n_sub_id = @a_sub_id;
END;
ELSE
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT,
@n_member_id OUTPUT,
@n_sub_id OUTPUT;
END;
SET @as_member_id = @n_member_id;
SET @as_sub_id = @n_sub_id;
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
IF @n_count = 0
--(new dependent)
BEGIN
IF @t_plan_term_date IS NULL
BEGIN
IF @n_ffs_plan = 0
BEGIN
IF @n_new_mb_w_fc_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id =@n_sub_facility_id ;
END;
IF @n_sub_facility_id != @t_facility_id
BEGIN
SET @as_facility_id = @t_facility_id;
----CH001
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
0;
IF @n_error_no < 0
SET @as_facility_id = @n_sub_facility_id;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
END;
IF @s_has_dep_err = 'N'
BEGIN
SET @as_action_code = 'DA';
-----CH001
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
ELSE
BEGIN
SET @n_isam_error = 320
RAISERROR('New Dependent with termination date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
END;
IF ( @n_count = 1
OR @n_count = 2
)
BEGIN
--existing dependent
/* DECLARE #SWV_cursor_var1 CURSOR;
DECLARE #SWV_cursor_var2 CURSOR;
*/
IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var1', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var1
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var2', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var2
END


CREATE TABLE #SWV_cursor_var1
(
id INT IDENTITY ,
rlplfc_id INT ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
CREATE TABLE #SWV_cursor_var2
(
id INT IDENTITY ,
rlplfc_id INT ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
IF @n_sub_id <> @a_sub_id
BEGIN
SET @n_isam_error = 321
RAISERROR('Dep has different family_id',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @SWV_func_DLP_BU_DEP_ELIG_MB_par0 =@t_plan_eff_date;
EXECUTE dbo.dlp_bu_dep_elig_mb @n_count,
@n_error_no, @as_action_code,
@n_member_id, @t_src_id,
@a_batch_id, @t_sir_id,
@SWV_func_DLP_BU_DEP_ELIG_MB_par0,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
IF @t_plan_term_date IS NULL--(going be in the sub new plan)
BEGIN
EXECUTE dbo.dlp_check_address @a_batch_id,
@t_sir_id, 'N',
@n_member_id,
@n_error_no OUTPUT,
@n_change_address OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
SET @s_has_dep_err = 'Y';
END;
ELSE
IF @n_change_address LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_change_address,
@t_plan_eff_date;
SET @as_action_code = @n_change_address;
END;
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NOT NULL
BEGIN
IF @n_sub_facility_id != @t_facility_id
BEGIN
SET @as_facility_id = @t_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@as_facility_id,
@def_plan_id,
@t_plan_eff_date,
0;
IF @n_error_no < 0
SET @as_facility_id = @n_sub_facility_id;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
END;
ELSE
BEGIN
SET @n_rlplfc_id = NULL;
SET @n_facility_id = NULL;
SET @n_eff_date = NULL;
SET @n_exp_date = NULL;
/*NEED TO TEST*/
INSERT
INTO #SWV_cursor_var1
(
rlplfc_id ,
facility_id ,
eff_date ,
exp_date
)
SELECT
rlplfc_id ,
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @a_mb_gr_pl_id
AND member_id = @n_member_id
AND exp_date IS NULL
ORDER BY eff_date DESC ,
exp_date; 
/* SET #SWV_cursor_var1 = CURSOR FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @a_mb_gr_pl_id AND
member_id = @n_member_id AND
exp_date IS NULL
ORDER BY eff_date DESC,exp_date;
OPEN #SWV_cursor_var1;
FETCH NEXT FROM #SWV_cursor_var1 INTO @n_rlplfc_id,
@n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @cur2_cnt INT ,
@cur2_i INT;
SET @cur2_i = 1;
--Get the no. of records for the cursor
SELECT
@cur2_cnt = COUNT(1)
FROM
#SWV_cursor_var1;
--while @@FETCH_STATUS = 0
WHILE ( @cur2_i <= @cur2_cnt )
BEGIN
SELECT
@n_rlplfc_id = rlplfc_id ,
@n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM
#SWV_cursor_var1
WHERE
id = @cur2_i;
GOTO SWL_Label21;
/*FETCH NEXT FROM #SWV_cursor_var1 INTO @n_rlplfc_id,
@n_facility_id,
@n_eff_date,
@n_exp_date;*/
SET @cur2_i = @cur2_i
+ 1;
END;
SWL_Label21:
--CLOSE #SWV_cursor_var1;
IF @n_rlplfc_id IS NULL
BEGIN
INSERT
INTO #SWV_cursor_var2
(
rlplfc_id ,
facility_id ,
eff_date ,
exp_date
)
SELECT
rlplfc_id ,
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @a_mb_gr_pl_id
AND member_id = @n_member_id
ORDER BY eff_date DESC ,
exp_date DESC;
/*
SET #SWV_cursor_var2 = CURSOR FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @a_mb_gr_pl_id AND
member_id = @n_member_id
ORDER BY eff_date DESC,exp_date DESC;
OPEN #SWV_cursor_var2;
FETCH NEXT FROM #SWV_cursor_var2 INTO @n_rlplfc_id,
@n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @cur3_cnt INT ,
@cur3_i INT;
SET @cur3_i = 1;
--Get the no. of records for the cursor
SELECT
@cur3_cnt = COUNT(1)
FROM
#SWV_cursor_var2;
--while @@FETCH_STATUS = 0
WHILE ( @cur3_i <= @cur3_cnt )
BEGIN
SELECT
@n_rlplfc_id = rlplfc_id ,
@n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM
#SWV_cursor_var2
WHERE
id = @cur3_i;
GOTO SWL_Label22;
/*FETCH NEXT FROM #SWV_cursor_var2 INTO @n_rlplfc_id,
@n_facility_id,
@n_eff_date,
@n_exp_date;*/
SET @cur3_i = @cur3_i
+ 1;
END;
SWL_Label22:
--CLOSE #SWV_cursor_var2;
END;
IF @n_rlplfc_id IS NULL
SET @as_facility_id = @n_sub_facility_id;
ELSE
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@n_facility_id,
@def_plan_id,
@t_plan_eff_date,
0;
IF @n_error_no <= 0
SET @as_facility_id = @n_sub_facility_id;
ELSE
SET @as_facility_id = @n_facility_id;
END;
END;
END;
ELSE
SET @as_facility_id = NULL;
IF @s_has_dep_err != 'Y'
BEGIN
SET @as_action_code = 'PC';
SET @as_plan_eff_date =@t_plan_eff_date;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@as_plan_eff_date;
END;
END;
ELSE
IF ( @as_action_code IS NULL
OR @as_action_code = ''
)
BEGIN
SET @as_action_code = 'GI';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@as_plan_eff_date;
END;
END;
END;
IF @n_sub_action_code = 'ST'
/* 20131220$$ks - allow input of actual member ID from file
*/
BEGIN
IF @new_member_id > 0
BEGIN
SET @n_count = 1;
SET @n_member_id = @new_member_id;
SET @n_sub_id = @a_sub_id;
END;
ELSE
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT,
@n_member_id OUTPUT,
@n_sub_id OUTPUT;
END;
SET @as_member_id = @n_member_id;
SET @as_sub_id = @a_sub_id;
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
IF @n_count = 0
BEGIN
SET @n_isam_error = 350
RAISERROR('New Dependent with terminated Sub',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF ( @n_count = 1
OR @n_count = 2
)
BEGIN
--DECLARE #SWV_cursor_var3 CURSOR;

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var3', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var3
END

CREATE TABLE #SWV_cursor_var3
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
IF @n_sub_id != @a_sub_id
BEGIN
SET @n_isam_error = 351
RAISERROR('Dependent sub is not in the same family',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @SWV_func_DLP_BU_DEP_ELIG_MB_par1 =@t_plan_eff_date;
EXECUTE dbo.dlp_bu_dep_elig_mb @n_count,
@n_error_no, @as_action_code,
@n_member_id, @t_src_id,
@a_batch_id, @t_sir_id,
@SWV_func_DLP_BU_DEP_ELIG_MB_par1,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
EXECUTE dbo.dlp_check_address @a_batch_id,
@t_sir_id, 'N', @n_member_id,
@n_error_no OUTPUT,
@n_change_address OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
SET @s_has_dep_err = 'Y';
END;
ELSE
IF @n_change_address LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_change_address,
@t_plan_eff_date;
SET @as_action_code = @n_change_address;
END;
SELECT @n_mb_gr_pl_id = mb_gr_pl_id
FROM dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @n_sub_id
AND group_id = @n_sub_group_id
AND plan_id = @n_sub_plan_id
AND eff_gr_pl <= @n_sub_plan_eff
AND ( exp_gr_pl > @n_sub_plan_eff
OR exp_gr_pl IS NULL
);

IF @n_mb_gr_pl_id IS NULL
BEGIN
SET @n_isam_error = 352
RAISERROR('Missing Sub''s active group/plan record',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @n_facility_id = NULL;
SET @n_eff_date = NULL;
INSERT INTO #SWV_cursor_var3
( facility_id ,
eff_date ,
exp_date
)
SELECT DISTINCT
facility_id ,
eff_date ,
exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date <= @t_plan_eff_date
AND ( exp_date > @t_plan_eff_date
OR exp_date IS NULL
)
ORDER BY 2 DESC ,
3;
/*
SET #SWV_cursor_var3 = CURSOR FOR SELECT DISTINCT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
member_id = @n_member_id AND
eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
ORDER BY 2 DESC,3;
OPEN #SWV_cursor_var3;
FETCH NEXT FROM #SWV_cursor_var3 INTO @n_facility_id,
@n_eff_date, @n_exp_date;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @cur4_cnt INT ,
@cur4_i INT;
SET @cur4_i = 1;
--Get the no. of records for the cursor
SELECT @cur4_cnt = COUNT(1)
FROM #SWV_cursor_var3;
--while @@FETCH_STATUS = 0
WHILE ( @cur4_i <= @cur4_cnt )
BEGIN
SELECT @n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM #SWV_cursor_var3
WHERE id = @cur4_i;
GOTO SWL_Label23;
/*FETCH NEXT FROM #SWV_cursor_var3 INTO @n_facility_id,
@n_eff_date, @n_exp_date;*/
SET @cur4_i = @cur4_i + 1;
END;
SWL_Label23:
--CLOSE #SWV_cursor_var3;
IF @n_eff_date IS NULL
-- new dependent on a terminated subscriber
BEGIN
IF @t_plan_term_date IS NULL
BEGIN
IF @t_plan_eff_date < @n_sub_plan_term
BEGIN
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
SET @as_facility_id = @t_facility_id;
IF @n_sub_facility_id != @t_facility_id
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
ELSE
SET @as_facility_id = @def_facility_id;
END;
IF @s_has_dep_err != 'Y'
BEGIN
SET @as_action_code = 'DR';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
ELSE
BEGIN
SET @n_isam_error = 353
RAISERROR('Dep active after subscriber term date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
END;
ELSE
BEGIN

IF @t_plan_term_date < @t_plan_eff_date
BEGIN
SET @n_isam_error = 357
RAISERROR('Dep plan term date before effective date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @t_plan_term_date = @t_plan_eff_date
BEGIN
SET @n_isam_error = 358
RAISERROR('New dependent is active and term on same date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @t_plan_term_date > @n_sub_plan_term
BEGIN
SET @t_plan_term_date = @n_sub_plan_term;
END;
IF @t_plan_term_date = @n_sub_plan_term
BEGIN
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
SET @as_facility_id = @t_facility_id;
IF @n_sub_facility_id != @t_facility_id
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
ELSE
SET @as_facility_id = @def_facility_id;
END;
IF @s_has_dep_err = 'N'
BEGIN
SET @as_action_code = 'DR';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
END;
END;
ELSE
IF @n_exp_date IS NULL
BEGIN
IF @t_plan_term_date IS NOT NULL
BEGIN
SET @as_plan_term_date = @t_plan_term_date;
SET @t_plan_eff_date = @n_eff_date;
SET @as_fac_eff_date = @n_eff_date;
IF @t_plan_term_date > @n_sub_plan_term
BEGIN
SET @n_isam_error = 359
RAISERROR('Dep term after subscriber term date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
END;
ELSE
BEGIN
SET @as_plan_term_date = @n_sub_plan_term;
SET @t_plan_term_date = @n_sub_plan_term
END;
IF @t_plan_eff_date < @n_eff_date
BEGIN
SET @as_plan_eff_date = @n_eff_date;
SET @t_plan_eff_date = @n_eff_date;
END;

IF @t_plan_term_date < @t_plan_eff_date
BEGIN
SET @n_isam_error = 361
RAISERROR('Dep term date is before effective date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @s_has_dep_err != 'Y'
BEGIN
SET @as_action_code = 'MT';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_term_date;
END;
END;
ELSE
BEGIN
IF @t_plan_eff_date < @n_eff_date
BEGIN
SET @t_plan_eff_date = @n_eff_date
END;
SET @t_member_id = @n_member_id 

UPDATE GlobalVar SET VarValue = @t_member_id WHERE VarName ='t_member_id' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @as_action_code = 'GI';
EXECUTE dbo.dlp_gi_check @t_sir_id,
@n_has_address,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
IF @n_error_no < 0
SET @s_has_dep_err = 'N';
IF @s_has_dep_err != 'Y'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
END;
END;
IF @n_sub_action_code = 'SR'
OR @n_sub_action_code = 'PA'
OR @n_sub_action_code = 'RI'
BEGIN
IF @t_plan_term_date IS NOT NULL
BEGIN
SET @n_isam_error = 117
RAISERROR('Terminated Dependent with new sub',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
/* 20131220$$ks - allow input of actual member ID from file
*/
IF @new_member_id > 0
BEGIN
SET @n_count = 1;
SET @n_member_id = @new_member_id;
SET @n_sub_id = @a_sub_id;
END;
ELSE
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT,
@n_member_id OUTPUT,
@n_sub_id OUTPUT;
END;
SET @as_member_id = @n_member_id;
SET @as_sub_id = @a_sub_id;
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
IF @n_count = 0
BEGIN
IF @n_ffs_plan = 0
BEGIN
IF @n_new_mb_w_fc_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
SET @as_facility_id = @n_sub_facility_id;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
IF @n_sub_facility_id != @as_facility_id
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@as_facility_id,
@n_sub_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
SET @as_action_code = 'DA';
END;
ELSE
SET @as_action_code = 'DA';
END;
ELSE
BEGIN
SET @as_facility_id = @def_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@def_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
SET @as_action_code = 'DA';
END;
END;
ELSE
BEGIN
SET @as_facility_id = NULL;
SET @as_action_code = 'DA';
END;
IF @s_has_dep_err = 'N'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id, @as_action_code,
@t_plan_eff_date;
END;
END;
IF ( @n_count = 1
OR @n_count = 2
)
BEGIN
/* DECLARE #SWV_cursor_var4 CURSOR;
DECLARE #SWV_cursor_var5 CURSOR;
DECLARE #SWV_cursor_var6 CURSOR; */

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var4', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var4
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var5', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var5
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var6', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var6
END

CREATE TABLE #SWV_cursor_var4
(
id INT IDENTITY ,
mb_gr_pl_id INT ,
eff_gr_pl DATE
);
CREATE TABLE #SWV_cursor_var5
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE
);
CREATE TABLE #SWV_cursor_var6
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
IF @n_sub_id != @a_sub_id
BEGIN
SET @n_isam_error = 125
RAISERROR('Dependent has different sub id',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @SWV_func_DLP_BU_DEP_ELIG_MB_par2 = @t_plan_eff_date;
EXECUTE dbo.dlp_bu_dep_elig_mb @n_count,
@n_error_no, @as_action_code,
@n_member_id, @t_src_id,
@a_batch_id, @t_sir_id,
@SWV_func_DLP_BU_DEP_ELIG_MB_par2,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
EXECUTE dbo.dlp_check_address @a_batch_id,
@t_sir_id, 'N', @n_member_id,
@n_error_no OUTPUT,
@n_change_address OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
SET @s_has_dep_err = 'Y';
END;
ELSE
IF @n_change_address LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_change_address,
@t_plan_eff_date;
SET @as_action_code = @n_change_address;
END;
SET @n_mb_gr_pl_id = NULL;
INSERT INTO #SWV_cursor_var4
( mb_gr_pl_id ,
eff_gr_pl
)
SELECT mb_gr_pl_id ,
eff_gr_pl
FROM dbo.rlmbgrpl (NOLOCK)
WHERE group_id = @def_group_id
AND plan_id = @def_plan_id
AND member_id = @n_sub_id
ORDER BY eff_gr_pl DESC;
/*
SET #SWV_cursor_var4 = CURSOR FOR SELECT mb_gr_pl_id, eff_gr_pl
FROM dbo.rlmbgrpl (NOLOCK)
WHERE group_id = @def_group_id AND
plan_id = @def_plan_id AND
member_id = @n_sub_id
ORDER BY eff_gr_pl DESC;
OPEN #SWV_cursor_var4;
FETCH NEXT FROM #SWV_cursor_var4 INTO @n_mb_gr_pl_id,
@d_eff_gr_pl;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @cur5_cnt INT ,
@cur5_i INT;
SET @cur5_i = 1;
--Get the no. of records for the cursor
SELECT @cur5_cnt = COUNT(1)
FROM #SWV_cursor_var4;
--while @@FETCH_STATUS = 0
WHILE ( @cur5_i <= @cur5_cnt )
BEGIN
SELECT @n_mb_gr_pl_id=mb_gr_pl_id ,
@d_eff_gr_pl=eff_gr_pl
FROM #SWV_cursor_var4
WHERE id = @cur5_i;
GOTO SWL_Label24;
/* FETCH NEXT FROM #SWV_cursor_var4 INTO @n_mb_gr_pl_id,
@d_eff_gr_pl; */
SET @cur5_i = @cur5_i + 1;
END;
SWL_Label24:
--CLOSE #SWV_cursor_var4;
SET @n_facility_id = NULL;
SET @d_eff_date = NULL;
SET @d_exp_date = NULL;
IF @n_mb_gr_pl_id IS NOT NULL
/*Modified to get the lastest facility as of "05/07/99"*/
BEGIN
INSERT INTO #SWV_cursor_var5
( facility_id ,
eff_date
)
SELECT
facility_id ,
eff_date
FROM dbo.rlplfc (NOLOCK)
WHERE member_id = @n_member_id
AND mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_date IS NULL
ORDER BY eff_date DESC;
/* SET #SWV_cursor_var5 = CURSOR FOR SELECT facility_id, eff_date
FROM dbo.rlplfc (NOLOCK)
WHERE member_id = @n_member_id AND
mb_gr_pl_id = @n_mb_gr_pl_id AND
exp_date IS NULL
ORDER BY eff_date DESC;
OPEN #SWV_cursor_var5;
FETCH NEXT FROM #SWV_cursor_var5 INTO @n_facility_id,
@d_eff_date;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @cur6_cnt INT ,
@cur6_i INT;
SET @cur6_i = 1;
--Get the no. of records for the cursor
SELECT @cur6_cnt = COUNT(1)
FROM #SWV_cursor_var5;
--while @@FETCH_STATUS = 0
WHILE ( @cur6_i <= @cur6_cnt )
BEGIN
SELECT
@n_facility_id = facility_id ,
@d_eff_date = eff_date
FROM #SWV_cursor_var5
WHERE id = @cur6_i;
GOTO SWL_Label25;
/* FETCH NEXT FROM #SWV_cursor_var5 INTO @n_facility_id,
@d_eff_date; */
SET @cur6_i = @cur6_i
+ 1;
END;
SWL_Label25:
-- CLOSE #SWV_cursor_var5;
IF @d_eff_date IS NULL
BEGIN
INSERT
INTO #SWV_cursor_var6
(
facility_id ,
eff_date ,
exp_date
)
SELECT
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
member_id = @n_member_id
AND mb_gr_pl_id = @n_mb_gr_pl_id
ORDER BY eff_date DESC ,
exp_date DESC;
/* SET #SWV_cursor_var6 = CURSOR FOR SELECT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE member_id = @n_member_id AND
mb_gr_pl_id = @n_mb_gr_pl_id
ORDER BY eff_date DESC,exp_date DESC;
OPEN #SWV_cursor_var6;
FETCH NEXT FROM #SWV_cursor_var6 INTO @n_facility_id,
@d_eff_date,
@d_exp_date;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @cur7_cnt INT ,
@cur7_i INT;
SET @cur7_i = 1;
--Get the no. of records for the cursor
SELECT
@cur7_cnt = COUNT(1)
FROM #SWV_cursor_var6;
--while @@FETCH_STATUS = 0
WHILE ( @cur7_i <= @cur7_cnt )
BEGIN
SELECT
@n_facility_id=facility_id ,
@d_eff_date=eff_date ,
@d_exp_date=exp_date
FROM
#SWV_cursor_var6
WHERE
id = @cur7_i;
GOTO SWL_Label26;
/* FETCH NEXT FROM #SWV_cursor_var6 INTO @n_facility_id,
@d_eff_date, */
SET @cur7_i = @cur7_i
+ 1;
END;
SWL_Label26:
-- CLOSE #SWV_cursor_var6;
END;
IF @n_facility_id IS NOT NULL
--LET as_fac_eff_date = d_eff_date;
SET @as_facility_id = @n_facility_id;
END;
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
IF @as_facility_id IS NULL
SET @as_facility_id = @n_sub_facility_id;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
END;
ELSE
IF @as_facility_id IS NULL
SET @as_facility_id = @def_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id, @as_facility_id,
@n_sub_plan_id,
@t_plan_eff_date, 0;
IF @n_error_no < 0
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@def_facility_id,
@n_sub_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
SET @as_facility_id = @def_facility_id;
END;
END;
ELSE
SET @as_facility_id = NULL;
IF @s_has_dep_err = 'N'
BEGIN
IF @n_sub_action_code = 'PA'
SET @as_action_code = 'PA';
ELSE
IF @n_sub_action_code = 'RI'
SET @as_action_code = 'RI';
ELSE
SET @as_action_code = 'DR';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id, @as_action_code,
@t_plan_eff_date;
END;
END;
END;
IF @n_sub_action_code LIKE 'G[1-7]' ESCAPE '\'
OR @n_sub_action_code = 'GI'
OR @n_sub_action_code = 'MU'
/* 20131220$$ks - allow input of actual member ID from file 
*/
BEGIN
IF @new_member_id > 0
BEGIN
SET @n_count = 1;
SET @n_member_id = @new_member_id;
SET @n_sub_id = @a_sub_id;
END;
ELSE
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT,
@n_member_id OUTPUT,
@n_sub_id OUTPUT;
END;
SET @as_member_id = @n_member_id;
SET @as_sub_id = @n_sub_id;
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
IF @n_count = 0
BEGIN
/* DECLARE @SWV_cursor_var7 CURSOR;
DECLARE #SWV_cursor_var8 CURSOR;
*/

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var7', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var7
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var8', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var8
END


CREATE TABLE #SWV_cursor_var7
(
id INT IDENTITY ,
mb_gr_pl_id INT
);
CREATE TABLE #SWV_cursor_var8
(
id INT IDENTITY ,
eff_rt_date DATE ,
rate_code CHAR(2)
);
IF @t_plan_term_date IS NOT NULL
BEGIN
SET @n_isam_error = 373
RAISERROR('New dependent with termination date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @n_mb_gr_pl_id = NULL;

INSERT INTO #SWV_cursor_var7
( mb_gr_pl_id
)
SELECT mb_gr_pl_id
FROM dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @n_sub_id
AND group_id = @def_group_id
AND plan_id = @def_plan_id
AND eff_gr_pl <= @t_plan_eff_date
AND ( exp_gr_pl > @t_plan_eff_date
OR exp_gr_pl IS NULL
);


/* SET #SWV_cursor_var7 = CURSOR FOR SELECT mb_gr_pl_id FROM
dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @n_sub_id AND
group_id = @def_group_id AND
plan_id = @def_plan_id AND
eff_gr_pl <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
(exp_gr_pl > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_gr_pl IS NULL);
OPEN #SWV_cursor_var7;
FETCH NEXT FROM #SWV_cursor_var7 INTO @n_mb_gr_pl_id;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur8_cnt INT ,
@cur8_i INT;
SET @cur8_i = 1;
--Get the no. of records for the cursor
SELECT @cur8_cnt = COUNT(1)
FROM #SWV_cursor_var7;
--while @@FETCH_STATUS = 0
WHILE ( @cur8_i <= @cur8_cnt )
BEGIN
SELECT @n_mb_gr_pl_id = mb_gr_pl_id
FROM #SWV_cursor_var7
WHERE id = @cur8_i;
GOTO SWL_Label27;
/* FETCH NEXT FROM #SWV_cursor_var7 INTO @n_mb_gr_pl_id;*/
SET @cur8_i = @cur8_i + 1;
END;
SWL_Label27:
-- CLOSE #SWV_cursor_var7;

INSERT INTO #SWV_cursor_var8
( eff_rt_date ,
rate_code
)
SELECT eff_rt_date ,
rate_code
FROM dbo.rlmbrt (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_rt_date IS NULL
--and eff_rt_date <= t_fac_eff_date and
--(exp_rt_date > t_fac_eff_date or exp_rt_date is null)
ORDER BY eff_rt_date DESC;

/* SET #SWV_cursor_var8 = CURSOR FOR SELECT eff_rt_date, rate_code
FROM dbo.rlmbrt (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_rt_date IS NULL
--and eff_rt_date <= t_fac_eff_date and
--(exp_rt_date > t_fac_eff_date or exp_rt_date is null)
ORDER BY eff_rt_date DESC;
OPEN #SWV_cursor_var8;
FETCH NEXT FROM #SWV_cursor_var8 INTO @n_eff_rt_date,
@n_rate_code;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur9_cnt INT ,
@cur9_i INT;
SET @cur9_i = 1;
--Get the no. of records for the cursor
SELECT @cur9_cnt = COUNT(1)
FROM #SWV_cursor_var8;

--while @@FETCH_STATUS = 0
WHILE ( @cur9_i <= @cur9_cnt )
BEGIN

SELECT @n_eff_rt_date = eff_rt_date ,
@n_rate_code = rate_code
FROM #SWV_cursor_var8
WHERE id = @cur9_i;
GOTO SWL_Label28;
/* FETCH NEXT FROM #SWV_cursor_var8 INTO @n_eff_rt_date,
@n_rate_code; */
SET @cur9_i = @cur9_i + 1;
END;
SWL_Label28:
-- CLOSE #SWV_cursor_var8;
IF ( @n_rate_code IS NULL
OR @n_rate_code = ''
)
BEGIN
SET @n_isam_error = 372
RAISERROR('No active Subscriber Rate code',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
/* Add By: Wee
can't add dependent before rate effective date
*/

IF @n_eff_rt_date > @t_plan_eff_date
BEGIN
SET @n_isam_error = 377
RAISERROR('Can''t add dependent before sub''s rate effective date',16,
1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_ffs_plan = 0
BEGIN
IF @n_new_mb_w_fc_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
SET @as_facility_id = @n_sub_facility_id;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
IF @n_sub_facility_id != @t_facility_id
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
SET @as_action_code = 'DA';
END;
END;
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'DA';
END;
END;
ELSE
SET @as_action_code = 'DA';
IF @s_has_dep_err = 'N'
BEGIN
SET @as_action_code = 'DA';
SET @SWV_func_DL_LOG_ACTION_par13 = @t_plan_eff_date;
EXECUTE @n_error_no=dbo.dl_log_action @a_batch_id,
@t_sir_id, 'DA',
@SWV_func_DL_LOG_ACTION_par13;
END;
END;
IF ( @n_count = 1
OR @n_count = 2
)
BEGIN
SET @SWV_func_DLP_BU_DEP_ELIG_MB_par3 = @t_plan_eff_date;
EXECUTE dbo.dlp_bu_dep_elig_mb @n_count,
@n_error_no, @as_action_code,
@n_member_id, @t_src_id,
@a_batch_id, @t_sir_id,
@SWV_func_DLP_BU_DEP_ELIG_MB_par3,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
BEGIN
/* DECLARE #SWV_cursor_var9 CURSOR;
DECLARE #SWV_cursor_var10 CURSOR;
DECLARE #SWV_cursor_var11 CURSOR;
DECLARE #SWV_cursor_var12 CURSOR;
DECLARE #SWV_cursor_var13 CURSOR;
*/

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var9', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var9
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var10', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var10
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var11', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var11
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var12', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var12
END

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var13', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var13
END


DECLARE @SWV_get_xfer_date DATE;
CREATE TABLE #SWV_cursor_var9
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
CREATE TABLE #SWV_cursor_var10
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
CREATE TABLE #SWV_cursor_var11 
(
id INT IDENTITY ,
eff_rt_date DATE ,
rate_code CHAR(2)
);
CREATE TABLE #SWV_cursor_var12
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
CREATE TABLE #SWV_cursor_var13 
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
IF @n_sub_id != @a_sub_id
BEGIN
SET @n_isam_error = 125
RAISERROR('Dep''s has different sub',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
EXECUTE dbo.dlp_check_address @a_batch_id,
@t_sir_id, 'N', @n_member_id,
@n_error_no OUTPUT,
@n_change_address OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
SET @s_has_dep_err = 'Y';
END;
ELSE
IF @n_change_address LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_change_address,
@t_plan_eff_date;
SET @as_action_code = @n_change_address;
END;
SELECT @n_mb_gr_pl_id = mb_gr_pl_id
FROM dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @n_sub_id
AND group_id = @n_sub_group_id
AND plan_id = @n_sub_plan_id
AND eff_gr_pl <= @n_sub_plan_eff
AND ( exp_gr_pl > @n_sub_plan_eff
OR exp_gr_pl IS NULL
);
IF @n_mb_gr_pl_id IS NULL
BEGIN
SET @n_isam_error = 107
RAISERROR('No Active Subscriber Group/plan',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_ffs_plan = 0
BEGIN
SELECT @n_count = COUNT(DISTINCT facility_id)
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date <= @t_plan_eff_date
AND ( exp_date > @t_plan_eff_date
OR exp_date IS NULL
);
IF @n_count > 1
BEGIN
SET @n_isam_error = 116
RAISERROR('Multiple Active Dep''s fac record',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
END;
IF @t_plan_term_date IS NOT NULL
/* $$KS - why are we not terminating if eff = term???
** Comment out for now - DL5.0
IF t_plan_eff_date = t_plan_term_date THEN
*/
BEGIN
IF @t_plan_eff_date > @t_plan_term_date
BEGIN
SET @t_member_id = @n_member_id 

UPDATE GlobalVar SET VarValue = @t_member_id WHERE VarName ='t_member_id' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @as_action_code = 'GI';
SET @n_sir_status = 'P';
EXECUTE dbo.dlp_gi_check @t_sir_id,
@n_has_address,
@n_error_no OUTPUT,
@n_action_code OUTPUT;
IF @n_error_no < 0
SET @s_has_dep_err = 'E';
IF ( @n_action_code IS NOT NULL
AND @n_action_code <> ''
)
SET @as_action_code = @n_action_code;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_action_code,
@t_plan_eff_date;
END;
ELSE
BEGIN
SET @n_facility_id = NULL;
SET @n_eff_date = NULL;

INSERT
INTO #SWV_cursor_var9
(
facility_id ,
eff_date ,
exp_date
)
SELECT DISTINCT
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date <= @t_plan_term_date
AND ( exp_date > @t_plan_term_date
OR exp_date IS NULL
)
ORDER BY 2 DESC ,
3;
/* SET #SWV_cursor_var9 = CURSOR FOR SELECT DISTINCT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
member_id = @n_member_id AND
eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_term_date)) AND
(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_term_date)) OR exp_date IS NULL)
ORDER BY 2 DESC,3;
OPEN #SWV_cursor_var9;
FETCH NEXT FROM #SWV_cursor_var9 INTO @n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur10_cnt INT ,
@cur10_i INT;
SET @cur10_i = 1;
--Get the no. of records for the cursor
SELECT
@cur10_cnt = COUNT(1)
FROM
#SWV_cursor_var9;
--while @@FETCH_STATUS = 0
WHILE ( @cur10_i <= @cur10_cnt )
BEGIN
SELECT
@n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM
#SWV_cursor_var9
WHERE
id = @cur10_i;
GOTO SWL_Label29;
/* FETCH NEXT FROM #SWV_cursor_var9 INTO @n_facility_id,
@n_eff_date,
@n_exp_date; */
SET @cur10_i = @cur10_i
+ 1;
END;
SWL_Label29:
-- CLOSE #SWV_cursor_var9;
IF @n_eff_date IS NULL
BEGIN
SET @n_tmp_term_date = DATEADD(DAY,-1,@t_plan_term_date);
INSERT
INTO #SWV_cursor_var10
(
facility_id ,
eff_date ,
exp_date
)
SELECT DISTINCT
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date <= @n_tmp_term_date
AND ( exp_date > @n_tmp_term_date OR exp_date IS NULL
)
ORDER BY 2 DESC ,
3;

/* SET #SWV_cursor_var10 = CURSOR FOR SELECT DISTINCT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date <= @n_tmp_term_date AND
(exp_date > @n_tmp_term_date OR exp_date IS NULL)
ORDER BY 2 DESC,3;
OPEN #SWV_cursor_var10;
FETCH NEXT FROM #SWV_cursor_var10 INTO @n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur11_cnt INT ,
@cur11_i INT;
SET @cur11_i = 1;
--Get the no. of records for the cursor
SELECT
@cur11_cnt = COUNT(1)
FROM
#SWV_cursor_var10;
--while @@FETCH_STATUS = 0
WHILE ( @cur11_i <= @cur11_cnt )
BEGIN
SELECT
@n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM
#SWV_cursor_var10
WHERE
id = @cur11_i;
GOTO SWL_Label30;
/* FETCH NEXT FROM #SWV_cursor_var10 INTO @n_facility_id,
@n_eff_date,
@n_exp_date; */
SET @cur11_i = @cur11_i
+ 1;
END;
SWL_Label30:
-- CLOSE #SWV_cursor_var10;
END;
IF @n_eff_date IS NULL
BEGIN
SET @n_isam_error = 119
RAISERROR('Dep has no active facility record',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
ELSE
SET @as_facility_id = @n_facility_id;
IF @t_plan_term_date < @n_eff_date
BEGIN
SET @n_isam_error = 118
RAISERROR('Terminate before active facility date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_sub_plan_term IS NOT NULL
BEGIN
IF @t_plan_term_date = @n_sub_plan_term
BEGIN
SET @t_member_id =@n_member_id ;
UPDATE GlobalVar SET VarValue = @t_member_id WHERE VarName ='t_member_id' AND  BatchId = @a_batch_id AND Module_Id = 3
SET @n_action_code = 'GI';
SET @n_sir_status = 'P';
EXECUTE dbo.dlp_gi_check @t_sir_id,
@n_has_address,
@n_error_no OUTPUT,
@n_action_code OUTPUT;
IF @n_error_no < 0
--LET n_sir_status = "E";
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
ELSE
BEGIN
IF @t_plan_eff_date < @n_eff_date
BEGIN
SET @t_plan_eff_date = @n_eff_date;
END;
IF @n_exp_date IS NULL
BEGIN
SET @as_action_code = 'MT';
SET @SWV_func_DL_LOG_ACTION_par16 = @t_plan_term_date;
EXECUTE @n_error_no=dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@SWV_func_DL_LOG_ACTION_par16;
END;
ELSE
BEGIN
IF @t_plan_term_date = @n_exp_date
BEGIN
SET @t_member_id = @n_member_id ;
UPDATE GlobalVar SET VarValue = @t_member_id WHERE VarName ='t_member_id' AND  BatchId = @a_batch_id AND Module_Id = 3
SET @as_action_code = 'GI';
EXECUTE dbo.dlp_gi_check @t_sir_id,
@n_has_address,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
IF @s_has_dep_err != 'Y'
BEGIN
SET @SWV_func_DL_LOG_ACTION_par17 = @t_plan_eff_date;
EXECUTE @n_error_no=dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@SWV_func_DL_LOG_ACTION_par17;
END;
END;
ELSE
BEGIN
SET @n_isam_error = 111
RAISERROR('Dependent get terminated on diff date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
END;
END;
END;
END;
ELSE
--t_plan_term_date is null
BEGIN
INSERT INTO #SWV_cursor_var11
( eff_rt_date ,
rate_code
)
SELECT
eff_rt_date ,
rate_code
FROM
dbo.rlmbrt (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_rt_date IS NULL
--and eff_rt_date <= t_plan_eff_date and
--(exp_rt_date > t_plan_eff_date or exp_rt_date is null)
ORDER BY eff_rt_date DESC;
/* SET #SWV_cursor_var11 = CURSOR FOR SELECT eff_rt_date, rate_code
FROM dbo.rlmbrt (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_rt_date IS NULL
--and eff_rt_date <= t_plan_eff_date and
--(exp_rt_date > t_plan_eff_date or exp_rt_date is null)
ORDER BY eff_rt_date DESC;
OPEN #SWV_cursor_var11;
FETCH NEXT FROM #SWV_cursor_var11 INTO @n_eff_rt_date,
@n_rate_code;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur12_cnt INT ,
@cur12_i INT;
SET @cur12_i = 1;
--Get the no. of records for the cursor
SELECT @cur12_cnt = COUNT(1)
FROM #SWV_cursor_var11;
--while @@FETCH_STATUS = 0
WHILE ( @cur12_i <= @cur12_cnt )
BEGIN
SELECT
@n_eff_rt_date = eff_rt_date ,
@n_rate_code = rate_code
FROM
#SWV_cursor_var11
WHERE
id = @cur12_i;
GOTO SWL_Label31;
/* FETCH NEXT FROM #SWV_cursor_var11 INTO @n_eff_rt_date,
@n_rate_code; */
SET @cur12_i = @cur12_i
+ 1;
END;
SWL_Label31:
-- CLOSE #SWV_cursor_var11;
IF ( @n_rate_code IS NULL
OR @n_rate_code = ''
)
BEGIN
SET @n_isam_error = 372
RAISERROR('No active Subscriber Rate code to do facility change',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SELECT @num_fac_count = num_facil
FROM dbo.pl_rat (NOLOCK)
WHERE rate_code = @n_rate_code;
IF @num_fac_count IS NULL
BEGIN
SET @n_isam_error = 274
RAISERROR('Invalid Rate Code',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @n_facility_id = NULL;
SET @n_eff_date = NULL;
INSERT INTO #SWV_cursor_var12
( facility_id ,
eff_date ,
exp_date
)
SELECT DISTINCT
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND exp_date IS NULL
ORDER BY 2 DESC ,
3 DESC;
/* SET #SWV_cursor_var12 = CURSOR FOR SELECT DISTINCT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
member_id = @n_member_id AND
exp_date IS NULL
ORDER BY 2 DESC,3 DESC;
OPEN #SWV_cursor_var12;
FETCH NEXT FROM #SWV_cursor_var12 INTO @n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur13_cnt INT ,
@cur13_i INT;
SET @cur13_i = 1;
--Get the no. of records for the cursor
SELECT @cur13_cnt = COUNT(1)
FROM #SWV_cursor_var12;
--while @@FETCH_STATUS = 0
WHILE ( @cur13_i <= @cur13_cnt )
BEGIN
SELECT
@n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM
#SWV_cursor_var12
WHERE
id = @cur13_i; 
GOTO SWL_Label32;
/*FETCH NEXT FROM #SWV_cursor_var12 INTO @n_facility_id,
@n_eff_date,
@n_exp_date; */
SET @cur13_i = @cur13_i
+ 1;
END;
SWL_Label32:
-- CLOSE #SWV_cursor_var12;
IF @n_eff_date IS NULL
BEGIN
SET @n_facility_id = NULL;
SET @n_eff_date = NULL;
SET @n_exp_date = NULL;
INSERT
INTO #SWV_cursor_var13
(
facility_id ,
eff_date ,
exp_date
)
SELECT DISTINCT
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
ORDER BY 2 DESC ,
3 DESC;
/*
SET #SWV_cursor_var13 = CURSOR FOR SELECT DISTINCT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
member_id = @n_member_id
ORDER BY 2 DESC,3 DESC;
OPEN #SWV_cursor_var13;
FETCH NEXT FROM #SWV_cursor_var13 INTO @n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur14_cnt INT ,
@cur14_i INT;
SET @cur14_i = 1;
--Get the no. of records for the cursor
SELECT
@cur14_cnt = COUNT(1)
FROM
#SWV_cursor_var13;
--while @@FETCH_STATUS = 0
WHILE ( @cur14_i <= @cur14_cnt )
BEGIN
SELECT
@n_facility_id = facility_id ,
@n_eff_date = eff_date ,
@n_exp_date = exp_date
FROM
#SWV_cursor_var13
WHERE
id = @cur14_i;
GOTO SWL_Label33;
/* FETCH NEXT FROM #SWV_cursor_var13 INTO @n_facility_id,
@n_eff_date,
@n_exp_date; */
SET @cur14_i = @cur14_i
+ 1;
END;
SWL_Label33:
-- CLOSE #SWV_cursor_var13;
END;
IF @n_eff_date IS NOT NULL
IF @n_exp_date IS NULL
--continuing dependent
BEGIN
SET @as_fac_eff_date = @n_eff_date;
SET @t_plan_eff_date = @n_eff_date;
SET @as_facility_id = @n_facility_id;
SET @t_member_id = @n_member_id;
UPDATE GlobalVar SET VarValue = @t_member_id WHERE VarName ='t_member_id' AND  BatchId = @a_batch_id AND Module_Id = 3
--LET as_action_code = "GI";
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @as_facility_id = @n_facility_id;
SET @as_action_code = 'GI';
END;
ELSE
BEGIN
IF @n_facility_id != @t_facility_id
AND @t_fac_eff_date >= @n_eff_date
BEGIN
SET @as_facility_id = @t_facility_id;
IF @t_facility_id != @n_sub_facility_id
BEGIN
IF @num_fac_count = 1
BEGIN
SET @n_isam_error = 375
RAISERROR('Number of fc count > rate''s fc',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_fac_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_action_code = 'FX';
SET @as_fac_eff_date = @t_fac_eff_date;
END;
END;
ELSE
BEGIN
SET @as_action_code = 'FX';
SET @as_fac_eff_date = @t_fac_eff_date;
END;
END;
END;
END;
IF @s_has_dep_err = 'N'
BEGIN
IF ( @as_action_code IS NULL
OR @as_action_code = ''
)
SET @as_action_code = 'GI';
IF @as_action_code NOT LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
IF @as_action_code = 'FX'
BEGIN
EXECUTE dbo.get_xfer_date @n_facility_id,
@t_facility_id,
@n_eff_date,
@t_fac_eff_date,
@SWV_get_xfer_date OUTPUT;
SET @t_fac_eff_date = @SWV_get_xfer_date;
END;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_fac_eff_date;
END;
END;
END;
ELSE
--if member record exists as of plan_eff_date, but
-- has expiration record. Then reinstate as
-- of termination date
BEGIN
IF @t_plan_eff_date > @n_exp_date
BEGIN
SET @as_fac_eff_date = @t_plan_eff_date;
SET @as_plan_eff_date = @t_plan_eff_date;
SET @t_fac_eff_date = @t_plan_eff_date;
END;
ELSE
BEGIN
SET @as_fac_eff_date = @n_exp_date;
SET @as_plan_eff_date = @n_exp_date;
SET @t_plan_eff_date = @n_exp_date;
SET @t_fac_eff_date = @n_exp_date;
END;
SET @as_action_code = 'DR';
IF @n_eff_rt_date > @t_plan_eff_date
BEGIN
SET @n_isam_error = 378
RAISERROR('Can''t reinstate dependent before sub rate effective date',
0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @as_facility_id = @n_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@as_facility_id,
@def_plan_id,
@t_plan_eff_date,
0;
IF @n_error_no < 0
BEGIN
SET @as_facility_id = @def_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@def_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
IF @t_facility_id != @n_sub_facility_id
BEGIN
IF @num_fac_count = 1
BEGIN
SET @n_isam_error = 375
RAISERROR('Number of fc count > rate''s fc',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
END;
ELSE
BEGIN
SET @as_facility_id = @n_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@as_facility_id,
@def_plan_id,
@t_plan_eff_date,
0;
IF @n_error_no < 0
BEGIN
SET @as_facility_id = @def_facility_id;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@def_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
END;
END;
END;
ELSE
SET @as_facility_id = NULL;
IF @s_has_dep_err = 'N'
BEGIN
IF ( @as_action_code IS NULL
OR @as_action_code = ''
)
SET @as_action_code = 'GI';
IF @as_action_code NOT LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_fac_eff_date;
END;
END;
END;
ELSE
-- dependent with member record but no facility,(with diff group/plan)
BEGIN
IF EXISTS ( SELECT
*
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date > @t_plan_eff_date )
BEGIN
SET @n_isam_error = 236
RAISERROR('Dep is effective in the futute',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END

IF @n_eff_rt_date > @t_plan_eff_date
BEGIN
SET @n_isam_error = 378
RAISERROR('Can''t reinstate dep before sub rate effective date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @as_fac_eff_date = @t_plan_eff_date;
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id =@n_sub_facility_id;
END;
IF @n_sub_facility_id != @t_facility_id
BEGIN
IF @num_fac_count = 1
BEGIN
SET @n_isam_error = 375
RAISERROR('fc count > rate''s fc_count',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
END;
ELSE
SET @as_facility_id = NULL;
IF @s_has_dep_err = 'N'
BEGIN
SET @as_action_code = 'DR';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
END;
END;
END;
END;
/* section for sub's facility transfer */
IF @n_sub_action_code = 'FX'
/* 20131220$$ks - allow input of actual member ID from file
*/
BEGIN
IF @new_member_id > 0
BEGIN
SET @n_count = 1;
SET @n_member_id = @new_member_id;
SET @n_sub_id = @a_sub_id;
END;
ELSE
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT,
@n_member_id OUTPUT,
@n_sub_id OUTPUT;
END;
SET @as_member_id = @n_member_id;
SET @as_sub_id = @n_sub_id;
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
SET @n_mb_gr_pl_id = NULL;
INSERT INTO #SWV_cursor_var14
( mb_gr_pl_id
)
SELECT mb_gr_pl_id
FROM dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @n_sub_id
AND group_id = @def_group_id
AND plan_id = @def_plan_id
AND eff_gr_pl <= @t_plan_eff_date
AND ( exp_gr_pl > @t_plan_eff_date
OR exp_gr_pl IS NULL
);
/* SET #SWV_cursor_var14 = CURSOR FOR SELECT mb_gr_pl_id FROM
dbo.rlmbgrpl (NOLOCK)
WHERE member_id = @n_sub_id AND
group_id = @def_group_id AND
plan_id = @def_plan_id AND
eff_gr_pl <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
(exp_gr_pl > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_gr_pl IS NULL);
OPEN #SWV_cursor_var14;
FETCH NEXT FROM #SWV_cursor_var14 INTO @n_mb_gr_pl_id;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur15_cnt INT ,
@cur15_i INT;
SET @cur15_i = 1;
--Get the no. of records for the cursor
SELECT @cur15_cnt = COUNT(1)
FROM #SWV_cursor_var14;
--while @@FETCH_STATUS = 0
WHILE ( @cur15_i <= @cur15_cnt )
BEGIN
SELECT @n_mb_gr_pl_id = mb_gr_pl_id
FROM #SWV_cursor_var14
WHERE id = @cur15_i; 
GOTO SWL_Label34;
/* FETCH NEXT FROM #SWV_cursor_var14 INTO @n_mb_gr_pl_id; */
SET @cur15_i = @cur15_i + 1;
END;
SWL_Label34:
--CLOSE #SWV_cursor_var14;
IF @n_mb_gr_pl_id IS NULL
BEGIN
SET @n_isam_error = 376
RAISERROR('No active Subscriber group/plan record',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
INSERT INTO #SWV_cursor_var15
( eff_rt_date ,
rate_code
)
SELECT eff_rt_date ,
rate_code
FROM dbo.rlmbrt (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_rt_date IS NULL
--and eff_rt_date <= t_fac_eff_date and
-- (exp_rt_date > t_fac_eff_date or exp_rt_date is null)
ORDER BY eff_rt_date DESC;
/* SET #SWV_cursor_var15 = CURSOR FOR SELECT eff_rt_date, rate_code
FROM dbo.rlmbrt (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND exp_rt_date IS NULL
--and eff_rt_date <= t_fac_eff_date and
-- (exp_rt_date > t_fac_eff_date or exp_rt_date is null)
ORDER BY eff_rt_date DESC;
OPEN #SWV_cursor_var15;
FETCH NEXT FROM #SWV_cursor_var15 INTO @n_eff_rt_date,
@n_rate_code;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur16_cnt INT ,
@cur16_i INT;
SET @cur16_i = 1;
--Get the no. of records for the cursor
SELECT @cur16_cnt = COUNT(1)
FROM #SWV_cursor_var15;
--while @@FETCH_STATUS = 0
WHILE ( @cur16_i <= @cur16_cnt )
BEGIN
SELECT @n_eff_rt_date = eff_rt_date ,
@n_rate_code = rate_code
FROM #SWV_cursor_var15
WHERE id = @cur16_i;
GOTO SWL_Label35;
/* FETCH NEXT FROM #SWV_cursor_var15 INTO @n_eff_rt_date,
@n_rate_code; */
SET @cur16_i = @cur16_i + 1;
END;
SWL_Label35:
-- CLOSE #SWV_cursor_var15;
IF ( @n_rate_code IS NULL
OR @n_rate_code = ''
)
BEGIN
SET @n_isam_error = 372
RAISERROR('No active Subscriber Rate code to do facility change',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SELECT @num_fac_count = num_facil
FROM dbo.pl_rat (NOLOCK)
WHERE rate_code = @n_rate_code;
IF @num_fac_count IS NULL
BEGIN
SET @n_isam_error = 274
RAISERROR('Invalid Rate Code',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_count = 0
AND @s_has_dep_err = 'N'
BEGIN
SET @as_fac_eff_date = @t_plan_eff_date;

IF @n_eff_rt_date > @t_plan_eff_date
BEGIN
SET @n_isam_error = 377
RAISERROR('Can''t add dep before sub rate effective date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_ffs_plan = 0
BEGIN
IF @n_new_mb_w_fc_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id = @n_sub_facility_id ;
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'DA';
END;
IF @n_sub_facility_id != @t_facility_id
--IF num_fac_count > 1 THEN
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
SET @as_action_code = 'DA';
END;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
SET @as_action_code = 'DA';
END;
END;
ELSE
BEGIN
SET @as_action_code = 'DA';
SET @as_facility_id = @n_sub_facility_id;
END;
END;
ELSE
BEGIN
SET @as_facility_id = NULL;
SET @as_action_code = 'DA';
END;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id, @as_action_code,
@t_plan_eff_date;
END;
IF ( ( @n_count = 1
OR @n_count = 2
)
AND @s_has_dep_err = 'N'
)
BEGIN
/* DECLARE #SWV_cursor_var16 CURSOR;
DECLARE #SWV_cursor_var17 CURSOR;
*/

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var16', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var16
END
IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var17', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var17
END

CREATE TABLE #SWV_cursor_var16
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
CREATE TABLE #SWV_cursor_var17
(
id INT IDENTITY ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
SET @SWV_func_DLP_BU_DEP_ELIG_MB_par4 = @t_plan_eff_date;
EXECUTE dbo.dlp_bu_dep_elig_mb @n_count,
@n_error_no, @as_action_code,
@n_member_id, @t_src_id,
@a_batch_id, @t_sir_id,
@SWV_func_DLP_BU_DEP_ELIG_MB_par4,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
EXECUTE dbo.dlp_check_address @a_batch_id,
@t_sir_id, 'N', @n_member_id,
@n_error_no OUTPUT,
@n_change_address OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
SET @s_has_dep_err = 'Y';
END;
ELSE
IF @n_change_address LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_change_address,
@t_plan_eff_date;
SET @as_action_code = @n_change_address;
END;
SET @n_facility_id = NULL;
SET @n_rlplfc_eff = NULL;
SET @n_rlplfc_exp = NULL;
INSERT INTO #SWV_cursor_var16
( facility_id ,
eff_date ,
exp_date
)
SELECT facility_id ,
eff_date ,
exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND exp_date IS NULL
--eff_date <= t_fac_eff_date and
--(exp_date > t_fac_eff_date or exp_date is null)
ORDER BY eff_date DESC ,
exp_date;
/* SET #SWV_cursor_var16 = CURSOR FOR SELECT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
member_id = @n_member_id AND
exp_date IS NULL
--eff_date <= t_fac_eff_date and
--(exp_date > t_fac_eff_date or exp_date is null)
ORDER BY eff_date DESC,exp_date;
OPEN #SWV_cursor_var16;
FETCH NEXT FROM #SWV_cursor_var16 INTO @n_facility_id,
@n_rlplfc_eff, @n_rlplfc_exp;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur17_cnt INT ,
@cur17_i INT;
SET @cur17_i = 1;
--Get the no. of records for the cursor
SELECT @cur17_cnt = COUNT(1)
FROM #SWV_cursor_var16;
--while @@FETCH_STATUS = 0
WHILE ( @cur17_i <= @cur17_cnt )
BEGIN
SELECT @n_facility_id = facility_id ,
@n_rlplfc_eff = eff_date ,
@n_rlplfc_exp = exp_date
FROM #SWV_cursor_var16
WHERE id = @cur17_i;
GOTO SWL_Label36;
/* FETCH NEXT FROM #SWV_cursor_var16 INTO @n_facility_id,
@n_rlplfc_eff,
@n_rlplfc_exp; */
SET @cur17_i = @cur17_i + 1;
END;
SWL_Label36:
-- CLOSE #SWV_cursor_var16;
IF @n_rlplfc_eff IS NULL
BEGIN
SET @n_facility_id = NULL;
SET @n_rlplfc_eff = NULL;
SET @n_rlplfc_exp = NULL;
INSERT INTO #SWV_cursor_var17
( facility_id ,
eff_date ,
exp_date
)
SELECT
facility_id ,
eff_date ,
exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
ORDER BY eff_date DESC ,
exp_date DESC;
/* SET #SWV_cursor_var17 =
CURSOR FOR SELECT facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
member_id = @n_member_id
ORDER BY eff_date DESC,exp_date DESC;
OPEN #SWV_cursor_var17;
FETCH NEXT FROM #SWV_cursor_var17 INTO @n_facility_id,
@n_rlplfc_eff,
@n_rlplfc_exp;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur18_cnt INT ,
@cur18_i INT;
SET @cur18_i = 1;
--Get the no. of records for the cursor
SELECT @cur18_cnt = COUNT(1)
FROM #SWV_cursor_var17;
--while @@FETCH_STATUS = 0
WHILE ( @cur18_i <= @cur18_cnt )
BEGIN
SELECT
@n_facility_id = facility_id ,
@n_rlplfc_eff = eff_date ,
@n_rlplfc_exp = exp_date
FROM #SWV_cursor_var17
WHERE id = @cur18_i;
GOTO SWL_Label37;
/* FETCH NEXT FROM #SWV_cursor_var17 INTO @n_facility_id,
@n_rlplfc_eff,
@n_rlplfc_exp; */
SET @cur18_i = @cur18_i
+ 1;
END;
SWL_Label37:
-- CLOSE #SWV_cursor_var17;
END;
IF @t_plan_term_date IS NULL
IF @n_rlplfc_eff IS NULL
BEGIN
IF EXISTS ( SELECT
*
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @n_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date > @t_fac_eff_date )
BEGIN
SET @n_isam_error = 236
RAISERROR('Dependent is effective in the future',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END

IF @n_eff_rt_date > @t_plan_eff_date
BEGIN
SET @n_isam_error = 377
RAISERROR('Can''t add dep before sub''s rate effective date',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
--dependent rlplfc record not exists
SET @as_action_code = 'DR';
SET @as_plan_eff_date = @t_plan_eff_date;
SET @as_fac_eff_date = @t_plan_eff_date;
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id = @n_sub_facility_id ;
END;
IF @n_sub_facility_id != @t_facility_id
--IF num_fac_count > 1 THEN
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
-- LET as_fac_eff_date = t_fac_eff_date;
END;
--ELSE
--LET as_facility_id = n_sub_facility_id;
--LET as_fac_eff_date = t_fac_eff_date;
--END IF
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
--LET as_fac_eff_date = t_fac_eff_date;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
-- LET as_fac_eff_date = t_fac_eff_date;
END;
ELSE
SET @as_facility_id = NULL;
IF @s_has_dep_err != 'Y'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_fac_eff_date;
END;
END;
ELSE
IF @n_rlplfc_exp IS NOT NULL
BEGIN
IF @t_plan_eff_date > @n_rlplfc_exp
BEGIN
SET @as_fac_eff_date = @t_plan_eff_date;
SET @as_plan_eff_date = @t_plan_eff_date;
SET @t_fac_eff_date = @t_plan_eff_date;
END;
ELSE
BEGIN
SET @as_fac_eff_date = @n_rlplfc_exp;
SET @as_plan_eff_date = @n_rlplfc_exp;
SET @t_plan_eff_date =@n_rlplfc_exp;
SET @t_fac_eff_date = @n_rlplfc_exp;
END;
SET @as_action_code = 'DR';

IF @n_eff_rt_date > @t_plan_eff_date
BEGIN
SET @n_isam_error = 378
RAISERROR('Can''t reinstate dep before sub rate code effective date',16,
1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id = @n_facility_id ;
END;
IF @n_sub_facility_id != @t_facility_id
IF @num_fac_count > 1
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
-- LET as_fac_eff_date = t_fac_eff_date;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
-- LET as_fac_eff_date = t_fac_eff_date;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
END;
-- LET as_fac_eff_date = t_fac_eff_date;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
-- LET as_fac_eff_date = t_fac_eff_date;
END;
ELSE
SET @as_facility_id = NULL;
IF @s_has_dep_err != 'Y'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
ELSE
--when active rlplfc record exists for subscirber FX
BEGIN
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id = @n_facility_id ;
END;
IF @n_facility_id != @t_facility_id
--when active fc'eff date is before sir's facility effective, so
--do facility transfer as of facility effective date (05/07/99)
BEGIN
IF @t_fac_eff_date >= @n_rlplfc_eff
BEGIN
IF @n_sub_facility_id != @t_facility_id
IF @num_fac_count > 1
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_fac_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
SET @as_fac_eff_date = @t_fac_eff_date;
SET @as_action_code = 'FX';
END;
END;
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'FX';
SET @as_fac_eff_date = @t_fac_eff_date;
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
SET @as_action_code = 'FX';
SET @as_fac_eff_date = @t_fac_eff_date;
END;
END;
ELSE
IF @n_sub_facility_id != @n_facility_id
IF @num_fac_count > 1
BEGIN
SET @as_action_code = 'GI';
SET @as_facility_id = @n_facility_id;
SET @as_fac_eff_date = @n_rlplfc_eff;
END;
ELSE
BEGIN
SET @as_action_code = 'FX';
SET @as_facility_id = @n_sub_facility_id;
SET @as_fac_eff_date = @n_rlplfc_eff;
END;
ELSE
BEGIN
SET @as_fac_eff_date = @n_rlplfc_eff;
SET @as_action_code = 'GI';
SET @as_facility_id = @n_facility_id;
END;
END;
ELSE
IF @n_sub_facility_id != @n_facility_id
IF @num_fac_count > 1
BEGIN
SET @as_facility_id = @n_facility_id;
SET @as_action_code = 'GI';
SET @as_fac_eff_date = @n_rlplfc_eff;
END;
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'FX';
SET @as_fac_eff_date =@t_fac_eff_date;
END;
ELSE
BEGIN
SET @as_facility_id = @n_facility_id;
SET @as_action_code = 'GI';
SET @as_fac_eff_date = @n_rlplfc_eff;
END;
END;
ELSE
IF @n_facility_id != @n_sub_facility_id
IF @num_fac_count > 1
BEGIN
SET @as_facility_id = @n_facility_id;
SET @as_action_code = 'GI';
SET @as_fac_eff_date = @n_rlplfc_eff;
END;
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'FX';
SET @as_fac_eff_date = @t_fac_eff_date;
END;
ELSE
BEGIN
SET @as_facility_id = @n_facility_id;
SET @as_action_code = 'GI';
SET @as_fac_eff_date = @n_rlplfc_eff;
END;
END;
ELSE
BEGIN
SET @as_action_code = 'GI';
SET @as_facility_id = NULL;
END;
IF @s_has_dep_err != 'Y'
BEGIN
IF @as_action_code = 'FX'
BEGIN
EXECUTE dbo.get_xfer_date @n_facility_id,
@t_facility_id,
@n_rlplfc_eff,
@t_fac_eff_date,
@SWV_get_xfer_date OUTPUT;
SET @t_fac_eff_date = @SWV_get_xfer_date;
END;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_fac_eff_date;
END;
END;
ELSE
--when sub do facility change, but dependent term date
BEGIN
IF @t_fac_eff_date = @t_plan_term_date
BEGIN
SET @as_action_code = 'MT';
SET @as_facility_id = @n_facility_id;
SET @as_fac_eff_date = @n_rlplfc_eff;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_term_date;
END;
ELSE
BEGIN
IF @t_fac_eff_date > @t_plan_term_date
BEGIN
SET @n_isam_error = 333
RAISERROR('Dep termination date before fac eff',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
IF @n_has_facility_id = 'Y'
BEGIN
SET @as_facility_id = @t_facility_id;
IF @t_facility_id != @n_sub_facility_id
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_fac_eff_date,
0;
IF @n_error_no <= 0
SET @as_facility_id = @n_sub_facility_id;
END;
ELSE
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'FX';
EXECUTE dbo.get_xfer_date @n_facility_id,
@t_facility_id,
@n_eff_date,
@t_fac_eff_date,
@SWV_get_xfer_date OUTPUT;
SET @t_fac_eff_date = @SWV_get_xfer_date;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_fac_eff_date;
END;
SET @as_action_code = 'MT';
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_term_date;
END;
END;
END;
END;
IF @n_sub_action_code = 'GX'
/* 20131220$$ks - allow input of actual member ID from file
*/
BEGIN
IF @new_member_id > 0
BEGIN
SET @n_count = 1;
SET @n_member_id = @new_member_id;
SET @n_sub_id = @a_sub_id;
END;
ELSE
BEGIN
EXECUTE dbo.dlp_check_member @t_subscriber,
@a_batch_id, @t_sir_id, @a_sub_id,
@n_count OUTPUT,
@n_member_id OUTPUT,
@n_sub_id OUTPUT;
END;
SET @as_member_id = @n_member_id;
SET @as_sub_id = @a_sub_id;
SET @as_fac_eff_date = @t_fac_eff_date;
IF @n_count < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
IF @n_count = 0
AND @s_has_dep_err = 'N'
BEGIN
IF @n_ffs_plan = 0
BEGIN
IF @n_new_mb_w_fc_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id = @n_sub_facility_id ;
END;
IF @n_sub_facility_id != @t_facility_id
--IF num_fac_count > 1 THEN
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
SET @as_action_code = 'DA';
END;
END;
--ELSE
-- LET as_facility_id = n_sub_facility_id;
-- LET as_action_code = "DA";
--END IF
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'DA';
END;
END;
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'DA';
END;
END;
ELSE
BEGIN
SET @as_facility_id = NULL;
SET @as_action_code = 'DA';
END;
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id, @as_action_code,
@t_plan_eff_date;
END;
IF ( ( @n_count = 1
OR @n_count = 2
)
AND @s_has_dep_err = 'N'
)
BEGIN
SET @t_plan_eff_date = @n_sub_plan_eff;
SET @t_fac_eff_date = @n_sub_fac_eff;
SET @as_fac_eff_date = @t_fac_eff_date;
BEGIN

IF OBJECT_ID(N'tempdb.dbo.#SWV_cursor_var18', N'U') IS NOT NULL
BEGIN
 DROP TABLE #SWV_cursor_var18
END

--DECLARE #SWV_cursor_var18 CURSOR;
CREATE TABLE #SWV_cursor_var18
(
id INT IDENTITY ,
rlplfc_id INT ,
facility_id INT ,
eff_date DATE ,
exp_date DATE
);
IF @n_sub_id != @a_sub_id
BEGIN
SET @n_isam_error = 321
RAISERROR('Dep has different family_id',0,1);
EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 
END
SET @SWV_func_DLP_BU_DEP_ELIG_MB_par5 = @t_plan_eff_date;
EXECUTE dbo.dlp_bu_dep_elig_mb @n_count,
@n_error_no, @as_action_code,
@n_member_id, @t_src_id,
@a_batch_id, @t_sir_id,
@SWV_func_DLP_BU_DEP_ELIG_MB_par5,
@n_error_no OUTPUT,
@as_action_code OUTPUT;
EXECUTE dbo.dlp_check_address @a_batch_id,
@t_sir_id, 'N', @n_member_id,
@n_error_no OUTPUT,
@n_change_address OUTPUT;
IF @n_error_no < 0
BEGIN
SET @s_has_deps_err = 'Y';
SET @s_has_dep_err = 'Y';
END;
ELSE
IF @n_change_address LIKE 'G[1-7]'
ESCAPE '\'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@n_change_address,
@t_plan_eff_date;
SET @as_action_code = @n_change_address;
END;
IF @n_ffs_plan = 0
BEGIN
IF @n_has_facility_id = 'Y'
BEGIN
IF @t_facility_id IS NULL
BEGIN
SET @t_facility_id = @n_sub_facility_id ;
END;
IF @n_sub_facility_id != @t_facility_id
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@t_facility_id,
@def_plan_id,
@t_plan_eff_date,
1;
IF @n_error_no < 0
BEGIN
SET @s_has_dep_err = 'Y';
SET @s_has_deps_err = 'Y';
END;
ELSE
BEGIN
SET @as_facility_id = @t_facility_id;
SET @as_action_code = 'GX';
END;
END;
ELSE
BEGIN
SET @as_facility_id = @n_sub_facility_id;
SET @as_action_code = 'GX';
END;
END;
ELSE
BEGIN
SET @n_rlplfc_id = NULL;
SET @n_facility_id = NULL;
SET @n_eff_date = NULL;
SET @n_exp_date = NULL;
INSERT
INTO #SWV_cursor_var18
(
rlplfc_id ,
facility_id ,
eff_date ,
exp_date
)
SELECT
rlplfc_id ,
facility_id ,
eff_date ,
exp_date
FROM
dbo.rlplfc (NOLOCK)
WHERE
mb_gr_pl_id = @a_mb_gr_pl_id
AND member_id = @n_member_id
AND eff_date <= @t_plan_eff_date
AND ( exp_date > @t_plan_eff_date
OR exp_date IS NULL
)
ORDER BY eff_date DESC ,
exp_date;
/* SET #SWV_cursor_var18 = CURSOR FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @a_mb_gr_pl_id AND
member_id = @n_member_id AND
eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
ORDER BY eff_date DESC,exp_date;
OPEN #SWV_cursor_var18;
FETCH NEXT FROM #SWV_cursor_var18 INTO @n_rlplfc_id,
@n_facility_id,
@n_eff_date,
@n_exp_date;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur19_cnt INT ,
@cur19_i INT;
SET @cur19_i = 1;
--Get the no. of records for the cursor
SELECT
@cur19_cnt = COUNT(1)
FROM
#SWV_cursor_var18;
--while @@FETCH_STATUS = 0
WHILE ( @cur19_i <= @cur19_cnt )
BEGIN
SELECT
@n_rlplfc_id= rlplfc_id,
@n_facility_id= facility_id ,
@n_eff_date= eff_date,
@n_exp_date= exp_date
FROM
#SWV_cursor_var18
WHERE
id = @cur19_i;
GOTO SWL_Label38;
/* FETCH NEXT FROM #SWV_cursor_var18 INTO @n_rlplfc_id,
@n_facility_id,
@n_eff_date,
@n_exp_date; */
SET @cur19_i = @cur19_i
+ 1;
END;
SWL_Label38:
-- CLOSE #SWV_cursor_var18;
SET @as_action_code = 'GX';
IF @n_rlplfc_id IS NULL
SET @as_facility_id = @n_sub_facility_id;
ELSE
BEGIN
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
@t_sir_id,
@n_facility_id,
@def_plan_id,
@t_plan_eff_date,
0;
IF @n_error_no <= 0
SET @as_facility_id = @n_sub_facility_id;
ELSE
SET @as_facility_id = @n_facility_id;
END;
END;
END;
ELSE
BEGIN
SET @as_action_code = 'GX';
SET @as_facility_id = NULL;
END;
IF @s_has_dep_err != 'Y'
BEGIN
EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
@t_sir_id,
@as_action_code,
@t_plan_eff_date;
END;
END;
END;
END;
IF @s_has_dep_err = 'Y'
UPDATE dbo.dls_elig
SET dls_status = 'E' ,
dls_member_id = @as_member_id ,
dls_sub_id = @as_sub_id ,
dls_group_id = @def_group_id ,
dls_plan_id = @def_plan_id
where dls_sir_id=@t_sir_id AND
			dls_batch_id = @a_batch_id
			AND dls_sub_sir_id = @a_sub_sir_id
			AND member_flag != '00'
--WHERE CURRENT OF @cDepSir;
ELSE
UPDATE dbo.dls_elig
SET dls_group_id = @def_group_id ,
dls_plan_id = @def_plan_id ,
facility_id = @as_facility_id ,
facility_eff_date = @as_fac_eff_date ,
plan_eff_date = @t_plan_eff_date ,
plan_term_date = @t_plan_term_date ,
dls_action_code = @as_action_code ,
dls_member_id = @as_member_id ,
dls_sub_id = @as_sub_id ,
dls_status = 'P'
where dls_sir_id=@t_sir_id AND
			dls_batch_id = @a_batch_id
			AND dls_sub_sir_id = @a_sub_sir_id
			AND member_flag != '00'
--WHERE CURRENT OF @cDepSir;
END TRY
BEGIN CATCH

EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
			@t_sir_id, @n_isam_error;
		IF @i_fatal <> 1 
		BEGIN
			SET @s_has_dep_err = 'Y';
			SET @s_has_deps_err = 'Y';
		END 

		IF @s_has_dep_err = 'Y'

			UPDATE dbo.dls_elig
			SET dls_status = 'E' ,
			dls_member_id = @as_member_id ,
			dls_sub_id = @as_sub_id ,
			dls_group_id = @def_group_id ,
			dls_plan_id = @def_plan_id
			where dls_sir_id=@t_sir_id AND
			dls_batch_id = @a_batch_id
			AND dls_sub_sir_id = @a_sub_sir_id
			AND member_flag != '00'
			--WHERE CURRENT OF @cDepSir;
			ELSE
			UPDATE dbo.dls_elig
			SET dls_group_id = @def_group_id ,
			dls_plan_id = @def_plan_id ,
			facility_id = @as_facility_id ,
			facility_eff_date = @as_fac_eff_date ,
			plan_eff_date = @t_plan_eff_date ,
			plan_term_date = @t_plan_term_date ,
			dls_action_code = @as_action_code ,
			dls_member_id = @as_member_id ,
			dls_sub_id = @as_sub_id ,
			dls_status = 'P'
			where dls_sir_id=@t_sir_id AND
			dls_batch_id = @a_batch_id
			AND dls_sub_sir_id = @a_sub_sir_id
			AND member_flag != '00'

		--IF @s_has_deps_err = 'Y'

  --         RETURN -1;

--SET @n_error_no = ERROR_NUMBER();
--SET @n_isam_error = ERROR_LINE();
--SET @n_error_descr = ERROR_MESSAGE();
--RETURN 1000;
END CATCH;
SWL_Label20:
/*FETCH NEXT FROM @cDepSir INTO @t_sir_id, @t_sub_sir_id,
@t_subscriber, @t_alt_id, @t_ssn, @t_sub_ssn,
@t_sub_alt_id, @t_member_code, @t_last_name, @t_first_name,
@t_middle_init, @t_date_of_birth, @t_student_flag,
@t_disable_flag, @t_cobra_flag, @t_address1, @t_address2,
@t_city, @t_state, @t_zip, @t_zipx, @t_home_phone,
@t_home_ext, @t_work_phone, @t_work_ext, @t_rate_code,
@t_plan_eff_date, @t_plan_term_date, @t_fac_eff_date,
@t_group_id, @t_plan_id, @t_facility_id, @t_def_key,
@t_type, @t_src_id, @new_member_id, @new_group_id,
@new_plan_id;
*/
SET @cur_i = @cur_i + 1;
END;
--CLOSE @cDepSir;

IF @s_has_deps_err = 'Y'
RETURN -1;
ELSE
BEGIN
	SET @n_succ_count = @n_succ_count + @n_dep_count;
	UPDATE GlobalVar
	SET VarValue = @n_succ_count
	WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3
RETURN 1;
END;
SET NOCOUNT OFF;
END;