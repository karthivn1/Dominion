﻿CREATE PROCEDURE [dbo].[usp_dl_RunBatch]
@BatchDetailId	INT,
@BatchId INT,
@SPID	INT,
@SIRId	INT = NULL,
@DbName	 VARCHAR(10)=NULL,
@CurrentTime VARCHAR(25),
@ReturnValue INT OUTPUT,
@ReturnMessage VARCHAR(MAX) OUTPUT
AS
BEGIN
	--@CurrentTime->StartTime/Finish time
	SET @CurrentTime = FORMAT(GETDATE() , 'yyyy-MM-dd HH:mm:ss:ff');

	--IF EXISTS(SELECT * FROM dl_cfg_bat_det (NOLOCK) WHERE config_bat_id=@BatchId AND cfg_bat_det_stat='I')
	--	BEGIN
	--		RAISERROR('Already another job is in running status',16,1)
	--	END

	Declare @SpName varchar(30),@SP_type char(5)
	IF(@DbName='' OR @DbName IS NULL)
		SET @DbName=''
	BEGIN TRY
	--Get Stored procedure name by SPID
	SELECT @SpName ='dlp_'+sp_name,@SP_type = sp_type FROM dl_sp WHERE sp_id = @SPID
	print @SpName
	IF(@SP_type='BU')
	BEGIN
		EXEC @SpName @BatchId,0,@CurrentTime,@ReturnValue OUTPUT,@ReturnMessage OUTPUT
	END
	ELSE IF(@SP_type='LD')
	BEGIN
		EXEC @SpName @BatchId,@DbName,@CurrentTime
	END
	ELSE 
	BEGIN
		EXEC @SpName @BatchId,@CurrentTime,@ReturnValue OUTPUT,@ReturnMessage OUTPUT
	END
	--to get batch detail current status
	SELECT  cfg_bat_det_id AS BatchDetailId, 
			cfg_bat_det_stat as Status,
			cd.descr AS StatusDescription,
			@ReturnValue AS ReturnValue,
			@ReturnMessage AS ReturnMessage
			FROM dl_cfg_bat_det bd
	INNER JOIN stc_common_detail cd ON bd.cfg_bat_det_stat=cd.code AND cd.common_header_id=2
	WHERE bd.cfg_bat_det_id=@BatchDetailId
	IF(@ReturnValue=1)--1=Successfull batch execution 
	BEGIN
		UPDATE dl_bat_statistics SET finish_time = FORMAT(GETDATE() , 'yyyy-MM-dd HH:mm:ss:ff')	WHERE bat_statistics_id =
		(SELECT MAX(bat_statistics_id) FROM dl_bat_statistics WHERE cfg_bat_det_id = @BatchDetailId);
	END
	END TRY
	BEGIN CATCH
	BEGIN
		SET @ReturnValue =-1;
		SET @ReturnMessage = ERROR_MESSAGE();

		SELECT  cfg_bat_det_id AS BatchDetailId, 
			cfg_bat_det_stat as Status,
			cd.descr AS StatusDescription,
			@ReturnValue AS ReturnValue,
			@ReturnMessage AS ReturnMessage
			FROM dl_cfg_bat_det bd
		INNER JOIN stc_common_detail cd ON bd.cfg_bat_det_stat=cd.code AND cd.common_header_id=2
		WHERE bd.cfg_bat_det_id=@BatchDetailId

	END
	--THROW;
	END CATCH
END