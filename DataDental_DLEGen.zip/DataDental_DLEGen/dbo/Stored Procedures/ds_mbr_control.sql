﻿CREATE PROCEDURE [dbo].[ds_mbr_control] @a_oc_id INT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @ll_count INT;

        DECLARE @i_oc_id INT;
        DECLARE @i_group_id INT;
        DECLARE @s_gp_status CHAR(2);
        DECLARE @i_plan_id INT;
        DECLARE @i_fc_id INT;
        DECLARE @s_fc_status CHAR(2);
        DECLARE @i_mb_gr_pl_id INT;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @d_eff_date DATE;
        DECLARE @d_exp_date DATE;
        DECLARE @i_member_id INT;
        DECLARE @i_family_id INT;
        DECLARE @i_act_sub INT;
        DECLARE @i_act_dep INT;
        DECLARE @i_term_sub INT;
        DECLARE @i_term_dep INT;


        DECLARE @i_tot_sub INT;
        DECLARE @i_tot_dep INT;
        DECLARE @i_tot_mem INT;
        DECLARE @i_tot_act_mem INT;
        DECLARE @i_tot_act_sub INT;
        DECLARE @i_tot_act_dep INT;
        DECLARE @i_tot_term_mem INT;
        DECLARE @i_tot_term_sub INT;
        DECLARE @i_tot_term_dep INT;

        SET NOCOUNT ON;
        SET LOCK_TIMEOUT -1;
--	set explain on;
--	set debug file to "ds_control.trc";
--	trace on;


        BEGIN TRAN;
        SET @ll_count = 0;
        SELECT  @ll_count = COUNT(*)
        FROM    sysobjects
        WHERE   name = 'dt_control_sum';
        IF @ll_count > 0
            DROP TABLE dbo.dt_control_sum;


        CREATE TABLE dbo.dt_control_sum
            (
              oc_id INT ,
              active_sub INT ,
              total_sub INT ,
              active_mem INT ,
              total_mem INT
            );

        COMMIT; 
        SET @i_oc_id = @a_oc_id;

        BEGIN TRAN;

        SELECT  @i_tot_sub = COUNT(DISTINCT member_id)
        FROM    dbo.rlmbgrpl a ( NOLOCK ) ,
                dbo.[group] c ( NOLOCK )
        WHERE   c.oc_id = @a_oc_id
                AND c.group_id = a.group_id;



        SELECT  @i_tot_mem = COUNT(DISTINCT b.member_id)
        FROM    dbo.rlmbgrpl a ( NOLOCK ) ,
                dbo.rlplfc b ( NOLOCK ) ,
                dbo.[group] c ( NOLOCK )
        WHERE   c.oc_id = @a_oc_id
                AND c.group_id = a.group_id
                AND a.mb_gr_pl_id = b.mb_gr_pl_id;

        SELECT  @i_tot_act_sub = COUNT(DISTINCT member_id)
        FROM    dbo.rlmbgrpl a ( NOLOCK ) ,
                dbo.[group] c ( NOLOCK )
        WHERE   c.oc_id = @a_oc_id
                AND c.group_id = a.group_id
                AND a.exp_gr_pl IS NULL;



        SELECT  @i_tot_act_mem = COUNT(DISTINCT b.member_id)
        FROM    dbo.rlmbgrpl a ( NOLOCK ) ,
                dbo.rlplfc b ( NOLOCK ) ,
                dbo.[group] c ( NOLOCK )
        WHERE   c.oc_id = @a_oc_id
                AND c.group_id = a.group_id
                AND a.mb_gr_pl_id = b.mb_gr_pl_id
                AND a.exp_gr_pl IS NULL
                AND b.exp_date IS NULL;

        INSERT  INTO dbo.dt_control_sum
        VALUES  ( @i_oc_id, @i_tot_act_sub, @i_tot_sub, @i_tot_act_mem,
                  @i_tot_mem );

        COMMIT; 
        SET NOCOUNT OFF;

--trace off;
    END;