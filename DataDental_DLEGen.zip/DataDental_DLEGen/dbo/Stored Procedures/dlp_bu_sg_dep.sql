﻿CREATE PROCEDURE [dbo].[dlp_bu_sg_dep]
    @a_batch_id INT ,
    @a_sub_sir_id INT ,
    @a_sub_id INT ,
    @a_mbgrpl_id INT,
	@n_succ_count Int OUTPUT,
	@ReturnValue1 Int OUTPUT
    

/*
	Created Date	: 03/19/2001
	Created By	: Jacky Chang
	Reason		: Dependent Single Group Eligibility Preprocessing.
*/
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:48:48 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1











000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_descr VARCHAR(64);
        DECLARE @d_valid_error INT;
        DECLARE @d_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;



/* paramater variable*/

/*member info in sir table*/

/* 20120228$$ks - added new field optional_5 using namesuffix field*/

/* 20120228$$ks - expanded bank_account from 17 to 25 chars */

/* 20121016$$ks - added From API logic */

        DECLARE @a_error_no INT;
        DECLARE @n_dep_count INT;
        DECLARE @n_sub_alt_id CHAR(20);
        DECLARE @n_sub_rate_code CHAR(2);
        DECLARE @n_sub_gppl_eff CHAR(10);
        DECLARE @n_sub_fac_eff CHAR(10);
        DECLARE @n_sub_plan_term CHAR(10);
        DECLARE @n_sub_action_code CHAR(2);
        DECLARE @n_sub_id INT;
        DECLARE @n_sub_msg_id INT;
        DECLARE @n_sub_gp_id INT;
        DECLARE @n_sub_pl_id INT;
        DECLARE @n_sub_fc_id INT;
        DECLARE @n_sub_pd_id INT;
        DECLARE @n_sub_dls_status CHAR(1);
        DECLARE @n_rlplfc_id INT;
        DECLARE @n_fac_id INT;
        DECLARE @n_plfc_eff DATE;
        DECLARE @n_plfc_exp DATE;
        DECLARE @n_ffs_plan INT;
        DECLARE @d_ins_type CHAR(5);
        DECLARE @d_ins_opt CHAR(5);
        DECLARE @n_eff_rt_date DATE;
        DECLARE @n_rate_code CHAR(5);
        DECLARE @num_fac_count INT;
        DECLARE @n_eff_date DATE;
        DECLARE @n_exp_date DATE;
        DECLARE @s_all_dep_err CHAR(1);
        DECLARE @s_ind_dep_err CHAR(1);
        DECLARE @n_plfc_cnt INT;
        DECLARE @as_action_code CHAR(2);
        DECLARE @as_addr_action CHAR(2);
        DECLARE @as_sub_id INT;
        DECLARE @as_member_id INT;
        DECLARE @as_msg_id INT;
        DECLARE @as_gp_id INT;
        DECLARE @as_pl_id INT;
        DECLARE @as_fc_id INT;
        DECLARE @as_gpplrt_eff DATE;
        DECLARE @as_fc_eff DATE;
        DECLARE @as_term_date DATE;
        DECLARE @as_pd_id INT;
        DECLARE @as_pdcomm_eff DATE;
        DECLARE @def_fc_id INT;
        DECLARE @d_fc_state CHAR(2);
        DECLARE @n_mbgrpl_id INT;
        DECLARE @n_gr_pl_eff DATE;
        DECLARE @n_gr_pl_exp DATE;
        DECLARE @n_facility_id INT;
        DECLARE @n_count INT;

        DECLARE @n_sub_in_plan SMALLINT;

DECLARE @n_process_count integer;
--DECLARE @n_succ_count integer;
DECLARE @sg_sp_id integer;
DECLARE @sg_sir_def_id integer;
DECLARE @sg_sir_def_name varchar(14);
DECLARE @sg_proc_name varchar(14);
DECLARE @sg_config_id integer;

DECLARE @n_has_facility_id char(1);
DECLARE @n_multiple_plans char(1);
DECLARE @n_allow_pl_change char(1);
DECLARE @n_multiple_fc char(1);
DECLARE @n_allow_fc_change char(1);
DECLARE @n_def_eff_date char(10);
DECLARE @n_def_exp_date char(10);
DECLARE @n_has_term_date char(1);
DECLARE @d_def_eff_date date;
DECLARE @d_def_exp_date date;

DECLARE @s_dls_sir_id integer;
DECLARE @s_dls_sub_sir_id integer;
DECLARE @s_member_flag char(2);
DECLARE @s_alt_id char(20);
DECLARE @s_ssn char(11);
DECLARE @s_sub_ssn char(11);
DECLARE @s_sub_alt_id char(20);
DECLARE @s_member_code char(3);

DECLARE @s_optional_5 char(5);
DECLARE @s_last_name char(15);
DECLARE @s_first_name char(15);
DECLARE @s_middle_init char(1);
DECLARE @s_name_prefix char(5);
DECLARE @s_name_suffix char(5);
DECLARE @s_date_of_birth char(10);
DECLARE @s_student_flag char(1);
DECLARE @s_disable_flag char(1);
DECLARE @s_cobra_flag char(1);
DECLARE @s_msg_group_id integer;
DECLARE @s_plan_id integer;
DECLARE @s_facility_id integer;
DECLARE @s_rate_code char(2);
DECLARE @s_mb_gppl_eff_date char(10);
DECLARE @s_mb_fc_eff_date char(10);
DECLARE @s_mb_term_date char(10);

DECLARE @s_bank_account char(25);
DECLARE @s_account_type char(2);
DECLARE @s_trans_rt_nbr char(9);
DECLARE @s_transaction_code char(2);
DECLARE @s_address1 char(30);
DECLARE @s_address2 char(30);
DECLARE @s_city char(30);
DECLARE @s_state char(2);
DECLARE @s_zip char(5);
DECLARE @s_zipx char(4);
DECLARE @s_email char(250);
DECLARE @s_home_phone char(10);
DECLARE @s_home_ext char(5);
DECLARE @s_work_phone char(10);

DECLARE @s_work_ext char(5);
DECLARE @s_producer_id integer;
DECLARE @s_comm_scheme_id char(5);
DECLARE @s_pd_type char(2);
DECLARE @s_license_number char(9);
DECLARE @s_selling_period char(1);
DECLARE @s_pdcomm_eff_date char(10);
DECLARE @t_new_ssn char(11);
DECLARE @t_src_id char(20);
DECLARE @t_subnew_ssn char(11);
DECLARE @t_subsrc_id char(20);
DECLARE @t_ext_id_col char(20);
DECLARE @s_msg_group_alt_id char(20);
DECLARE @s_plan_dsp_name char(30);
DECLARE @s_facility_alt_id char(20);
DECLARE @s_producer_alt_id char(20);

DECLARE @from_api smallint;
DECLARE @api_mbr_id integer;
DECLARE @api_sub_id integer;
DECLARE @api_plan_id integer;
DECLARE @api_fc_id integer;
DECLARE @api_msg_id integer;
DECLARE @api_grp_id integer; 

       
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @v_Null INT;	--Subscriber in plan.  This is a value returned by
								--dlp_mbgrpl_info() which this particular procedure
								--should ignore because this procedure deals with
								--dependents.


        SET NOCOUNT ON;
        --SET @n_process_count =0;
        
        --SET @n_succ_count =0;
        SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1

        SET @sg_sp_id =0;
        
        SET @sg_sir_def_id =0;
        
        SET @sg_sir_def_name ='';
        
        SET @sg_proc_name ='';
        
        SET @sg_config_id =0;
        
        SET @n_has_facility_id ='';
        
        SET @n_multiple_plans ='';
        
        SET @n_allow_pl_change ='';
        
        SET @n_multiple_fc ='';
        
        SET @n_allow_fc_change ='';
       
        SET @n_def_eff_date ='';
       
        SET @n_def_exp_date ='';
        
        SET @n_has_term_date ='';
        
        SET @d_def_eff_date =NULL;
        
        
        SET @d_def_exp_date =NULL;
        
        SET @s_dls_sir_id =0;
        
        SET @s_dls_sub_sir_id =0;
        
        SET @s_member_flag ='';
        
        SET @s_alt_id ='';
        
        SET @s_ssn ='';
        
        SET @s_sub_ssn ='';
        
        SET @s_sub_alt_id ='';
        
        SET @s_member_code ='';
        
        SET @s_optional_5 ='';
        
        SET @s_last_name ='';
        
        SET @s_first_name ='';
        
        SET @s_middle_init ='';
        
        SET @s_name_prefix ='';
        
        SET @s_name_suffix ='';
        
        SET @s_date_of_birth ='';
        
        SET @s_student_flag ='';
        
        SET @s_disable_flag ='';
        
        SET @s_cobra_flag ='';
        
        SET @s_msg_group_id =0;
        
        SET @s_plan_id =0;
        
        SET @s_facility_id =0;
        
        SET @s_rate_code ='';
        
        SET @s_mb_gppl_eff_date ='';
        
        SET @s_mb_fc_eff_date ='';
        
        SET @s_mb_term_date ='';
        
        SET @s_bank_account ='';
        
        SET @s_account_type ='';
        
        SET @s_trans_rt_nbr ='';
        
        SET @s_transaction_code ='';
        
        SET @s_address1 ='';

SET @s_address2 ='';
        
        SET @s_city ='';
        
        SET @s_state ='';
        
        SET @s_zip ='';
        
     SET @s_zipx ='';
       
        SET @s_email ='';
        
        SET @s_home_phone ='';
       
        SET @s_home_ext ='';
        
        SET @s_work_phone ='';
        
        SET @s_work_ext ='';
        
        SET @s_producer_id =0;
        
        SET @s_comm_scheme_id ='';
        
        SET @s_pd_type ='';
        
        SET @s_license_number ='';
        
        SET @s_selling_period ='';
        
        SET @s_pdcomm_eff_date ='';
        
        SET @t_new_ssn ='';
        
        SET @t_src_id ='';
        
        SET @t_subnew_ssn ='';
        
        SET @t_subsrc_id ='';
        
        SET @t_ext_id_col ='';
        
        SET @s_msg_group_alt_id ='';
        
        SET @s_plan_dsp_name ='';
        
        SET @s_facility_alt_id ='';
        
        SET @s_producer_alt_id ='';
        
        SET @from_api =0;
		
		       
        SET @api_mbr_id =0;
      
        SET @api_sub_id =0;
       
        SET @api_plan_id =0;
        
        SET @api_fc_id =0;
        
        SET @api_msg_id =0;
       
        SET @api_grp_id =0;
        
        SET @n_count = 0;
        SET @s_all_dep_err = 'N';
        SET @n_dep_count = 0;
        SET @sg_proc_name = 'bu_elig_sg' ;
        
        SET @sg_sir_def_name = 'elig_sg' ;
       
        SET @n_sub_in_plan = NULL;

		SELECT  @from_api = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @api_msg_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'api_msg_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @api_grp_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'api_grp_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @api_sub_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'api_sub_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @api_mbr_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'api_mbr_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @api_plan_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'api_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @api_fc_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'api_fc_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @sg_sp_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'sg_sp_id' and  BatchId = @a_batch_id AND Module_Id = 1
		SELECT  @sg_sir_def_id = VarValue FROM  dbo.GlobalVar(NOLOCK) where VarName = 'sg_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 1
			

        SELECT  @n_sub_alt_id = alt_id ,
                @n_sub_rate_code = rate_code ,
                @n_sub_gppl_eff = mb_gppl_eff_date ,
                @n_sub_fac_eff = mb_fc_eff_date ,
                @n_sub_plan_term = mb_term_date ,
                @n_sub_action_code = dls_action_code ,
                @n_sub_id = dls_member_id ,
                @n_sub_msg_id = dls_msg_id ,
                @n_sub_gp_id = dls_group_id ,
                @n_sub_pl_id = dls_plan_id ,
                @n_sub_fc_id = dls_facility_id ,
                @n_sub_pd_id = dls_producer_id ,
                @n_sub_dls_status = dls_status
        FROM    dbo.dls_sg_member (NOLOCK)
        WHERE   dls_batch_id = @a_batch_id
                AND dls_sir_id = @a_sub_sir_id;
       

/* 20120228$$ks - added new field optional_5 using namesuffix field* /
/ * 20121016$$ks - added From API logic 
 * get dependents Member ID and FC ID from dep record if from_api equals 1 
 */
        SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id, dls_sub_sir_id, member_flag, alt_id, ssn, sub_ssn,
	sub_alt_id, member_code, namesuffix, last_name, first_name, middle_init,
	date_of_birth, student_flag, disable_flag, cobra_flag,
	msg_group_id, plan_id, facility_id, rate_code,
	mb_gppl_eff_date, mb_fc_eff_date, mb_term_date, bank_account,
	account_type, transit_route_nbr, transaction_code, address1,
	address2, city, state, zip, zipx, home_phone, home_ext,
	work_phone, work_ext, email, producer_id, comm_scheme_id, pd_type,
	license_number, selling_period, pdcomm_eff_date, msg_alt_id,plan_dsp_name,
	fc_alt_id, prod_alt_id, new_ssn, source_id, subnew_ssn,
	subsource_id, ext_id_col, dls_member_id, dls_facility_id

   FROM dbo.dls_sg_member (NOLOCK)
   WHERE dls_batch_id = @a_batch_id
   AND dls_sub_sir_id = @a_sub_sir_id
   AND member_flag != '00'
   AND dls_status NOT IN('L','E','P','U');
        OPEN @SWV_cursor_var1;
        FETCH NEXT FROM @SWV_cursor_var1 INTO @s_dls_sir_id, @s_dls_sub_sir_id,
            @s_member_flag, @s_alt_id, @s_ssn, @s_sub_ssn, @s_sub_alt_id,
            @s_member_code, @s_optional_5, @s_last_name, @s_first_name,
            @s_middle_init, @s_date_of_birth, @s_student_flag, @s_disable_flag,
            @s_cobra_flag, @s_msg_group_id, @s_plan_id, @s_facility_id,
            @s_rate_code, @s_mb_gppl_eff_date, @s_mb_fc_eff_date,
            @s_mb_term_date, @s_bank_account, @s_account_type, @s_trans_rt_nbr,
            @s_transaction_code, @s_address1, @s_address2, @s_city, @s_state,
           @s_zip, @s_zipx, @s_home_phone, @s_home_ext, @s_work_phone,
            @s_work_ext, @s_email, @s_producer_id, @s_comm_scheme_id,
            @s_pd_type, @s_license_number, @s_selling_period,
            @s_pdcomm_eff_date, @s_msg_group_alt_id, @s_plan_dsp_name,
            @s_facility_alt_id, @s_producer_alt_id, @t_new_ssn, @t_src_id,
            @t_subnew_ssn, @t_subsrc_id, @t_ext_id_col, @api_mbr_id,
            @api_fc_id;
        WHILE @@FETCH_STATUS = 0
            BEGIN
                BEGIN

					UPDATE dbo.GlobalVar set VarValue = @s_member_flag where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_mb_gppl_eff_date where VarName = 's_mb_gppl_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_mb_fc_eff_date where VarName = 's_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_mb_term_date where VarName = 's_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @from_api where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_msg_group_id where VarName = 's_msg_group_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_dls_sir_id where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_first_name where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_last_name where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 1	
					UPDATE dbo.GlobalVar set VarValue = @s_date_of_birth where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_msg_id where VarName = 'api_msg_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_grp_id where VarName = 'api_grp_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_sub_id where VarName = 'api_sub_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_mbr_id where VarName = 'api_mbr_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_plan_id where VarName = 'api_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_fc_id where VarName = 'api_fc_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_alt_id where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_ssn where VarName = 's_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_sub_ssn where VarName = 's_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_sub_alt_id where VarName = 's_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_member_code where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 1
					
               		UPDATE dbo.GlobalVar set VarValue = @s_bank_account where VarName = 's_bank_account' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_account_type where VarName = 's_account_type' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_trans_rt_nbr where VarName = 's_trans_rt_nbr' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_transaction_code where VarName = 's_transaction_code' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_plan_id where VarName = 's_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_student_flag where VarName = 's_student_flag' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_disable_flag where VarName = 's_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_cobra_flag where VarName = 's_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 1

					UPDATE dbo.GlobalVar set VarValue = @s_address1 where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_address2 where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_zip where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_city where VarName = 's_city' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_state where VarName = 's_state' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_home_phone where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_home_ext where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_work_phone where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_work_ext where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_email where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 1

					UPDATE dbo.GlobalVar set VarValue = @s_producer_id where VarName = 's_producer_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_pd_type where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_license_number where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_selling_period where VarName = 's_selling_period' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_pdcomm_eff_date where VarName = 's_pdcomm_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_comm_scheme_id where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 1

					DECLARE @SWV_cursor_var3 CURSOR;
                    DECLARE @SWV_cursor_var4 CURSOR;
                    DECLARE @SWV_cursor_var7 CURSOR;
                    DECLARE @SWV_cursor_var8 CURSOR;
                    DECLARE @SWV_cursor_var9 CURSOR;
                    DECLARE @SWV_cursor_var10 CURSOR;
                    DECLARE @SWV_cursor_var11 CURSOR;
                    DECLARE @SWV_cursor_var12 CURSOR;
                    BEGIN TRY
                        SET @a_error_no = 330;
                        SET @s_ind_dep_err = 'N';
                        
						SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                        SET @n_process_count = @n_process_count + 1;
						UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                       
                        SET @n_dep_count = @n_dep_count + 1;
                        SET @d_ins_opt = NULL;
                        SET @as_action_code = NULL;
                        SET @as_sub_id = NULL;
                        SET @as_member_id = NULL;
                        SET @as_msg_id = NULL;
                        SET @as_gp_id = NULL;
                        SET @as_pl_id = NULL;
                        SET @as_fc_id = NULL;
                        SET @as_gpplrt_eff = NULL;
                        SET @as_fc_eff = NULL;
                        SET @as_term_date = NULL;
                        SET @as_pd_id = NULL;
                        SET @as_pdcomm_eff = NULL;
	--  created new procedure with code seperated from dlp_valid_sg
                        EXECUTE  @d_valid_error = dbo.dlp_sg_precheck @a_batch_id ;
                        IF @d_valid_error < 0
                            BEGIN
                                SET @s_all_dep_err = 'Y';
                                SET @s_ind_dep_err = 'Y';
                            END;
	
                        
                        IF @from_api = 1  -- This var is set in dlp_bu_sg_member
                            BEGIN
                                
             IF @api_mbr_id IS NULL
                                    BEGIN
                                        SET @api_mbr_id =0;
                                        
                                    END;
		
                              
                                IF @api_fc_id IS NULL
                                    BEGIN
                                        SET @api_fc_id =0;
                                        
                                    END;
		
                               
                                SET @s_facility_id = @api_fc_id;
                                
                            END;
	
  EXECUTE dbo.dlp_valid_sgdep @a_batch_id, @n_sub_id,
                            @n_sub_msg_id, @n_sub_gp_id, @n_sub_pl_id,
          @n_sub_action_code, @d_valid_error OUTPUT,
                            @d_error_descr OUTPUT, @as_action_code OUTPUT,
                            @as_sub_id OUTPUT, @as_member_id OUTPUT,
                            @as_msg_id OUTPUT, @as_gp_id OUTPUT,
                            @as_pl_id OUTPUT, @as_fc_id OUTPUT,
                            @as_gpplrt_eff OUTPUT, @as_fc_eff OUTPUT,
                            @as_term_date OUTPUT, @s_rate_code OUTPUT;
                        IF @d_valid_error < 0
                            BEGIN
                                IF @d_valid_error <> 50000
                                    SET @d_error_descr = CAST(@d_valid_error AS VARCHAR)
                                        + ':' + @d_error_descr;
                                RAISERROR(@d_error_descr,16,1);
                                GOTO SWL_Label13;
                            END;
                        ELSE
                            IF @d_valid_error = 0
                                BEGIN
                                    SET @s_all_dep_err = 'Y';
                                    SET @s_ind_dep_err = 'Y';
                                END;
                        IF @as_gpplrt_eff IS NULL
                            BEGIN
                                
                                SET @as_gpplrt_eff = CONVERT(DATE, CONVERT(VARCHAR, @d_def_eff_date));
                            END;
	
                        IF @as_fc_eff IS NULL
                            BEGIN
                                
                                SET @as_fc_eff = CONVERT(DATE, CONVERT(VARCHAR, @d_def_eff_date));
                            END;
	
                        
                        IF ( @s_rate_code IS NULL
                            )
                            OR @s_rate_code = ''
                            BEGIN
                                SET @s_rate_code = @n_sub_rate_code  ;
                                
                            END;
	
                        IF @n_sub_dls_status = 'E'
						BEGIN
                            RAISERROR('Dep''s Subscriber record has error',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 300;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
	
                        SET @n_ffs_plan = 1;
                        IF NOT EXISTS ( SELECT  *
      FROM    dbo.[plan] (NOLOCK) ,
                                                dbo.ins_opt (NOLOCK)
                                        WHERE   dbo.[plan].plan_id = @as_pl_id
                                                AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                                AND dbo.ins_opt.ins_opt_qual = 'I' )
                            SET @n_ffs_plan = 0;
	
                        SELECT  @d_ins_opt = ins_opt ,
                                @d_ins_type = ins_type
                        FROM    dbo.[plan] (NOLOCK)
          WHERE   plan_id = @as_pl_id;
                        
                        IF @d_ins_type = 'D' -- UNKNOWN FACILITY FOR DENTAL FACILITY
                            BEGIN
                                SET @def_fc_id = 1;
                                SET @d_fc_state = 'UK';
                            END;
                        ELSE -- UNKNOWN FACILITY FOR VISION FACILITY
                            BEGIN
                                SET @def_fc_id = 2;
                                SET @d_fc_state = 'UK';
                            END;
	
                        IF @s_ind_dep_err = 'N'
                            BEGIN
                  IF @as_sub_id IS NOT NULL
                                    AND @n_sub_id IS NOT NULL
                                    AND @as_sub_id <> @n_sub_id
									BEGIN
                                    RAISERROR('Dependent belongs to a different Subscriber',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 310;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
		
    IF @as_msg_id IS NOT NULL
                          AND @n_sub_msg_id IS NOT NULL
                                    AND @as_msg_id <> @n_sub_msg_id
									BEGIN
                                    RAISERROR('Dependent belongs to a different MSG',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 311;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
		
                                IF @as_gp_id IS NOT NULL
                                    AND @n_sub_gp_id IS NOT NULL
                                    AND @as_gp_id <> @n_sub_gp_id
									BEGIN
                                    RAISERROR('Dependent belongs to a different SG',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 312;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
		
                                IF @as_pl_id IS NOT NULL
                                    AND @n_sub_pl_id IS NOT NULL
                                    AND @as_pl_id <> @n_sub_pl_id
									BEGIN
                                    RAISERROR('Dependent belongs to a different Plan',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 313;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
		
                                IF @as_pd_id IS NOT NULL
                                    AND @n_sub_pd_id IS NOT NULL
                                    AND @as_pd_id <> @n_sub_pd_id
									BEGIN
                                    RAISERROR('Dependent belongs to a different PD',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 314;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
		
                               
                                IF ( @n_sub_rate_code IS NOT NULL
                                     
                                   )
                                    AND ( @s_rate_code IS NOT NULL
                                         
                                        )
                                    AND @n_sub_rate_code <> @s_rate_code
									BEGIN
                                    RAISERROR('Dependent belongs to a different RC',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 315;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
		
                                IF @as_fc_id IS NOT NULL
                                    BEGIN
                                        SET @n_plfc_cnt = 0;
                                        SELECT  @n_plfc_cnt = COUNT(*)
                                        FROM    dbo.rlplfc (NOLOCK)
                                        WHERE   mb_gr_pl_id = @a_mbgrpl_id
                                                AND member_id = @as_member_id
                                                AND facility_id = @as_fc_id
                                              AND eff_date <= @as_fc_eff
                                                AND ( exp_date IS NULL
                                                      OR @as_fc_eff < exp_date
                                                    );
                                        IF @n_plfc_cnt > 1
										BEGIN
                                            RAISERROR('Dependent is in multiple DDS HMO/RFS Facility',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 316;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
                                    END;
                                ELSE
                                    BEGIN
                                        SET @n_plfc_cnt = 0;
                                        SELECT  @n_plfc_cnt = COUNT(*)
                                        FROM    dbo.rlplfc (NOLOCK)
                                        WHERE   mb_gr_pl_id = @a_mbgrpl_id
                                                AND member_id = @as_member_id
                                                AND facility_id IS NULL
                                                AND eff_date <= @as_fc_eff
                                                AND ( exp_date IS NULL
                                                      OR @as_fc_eff < exp_date
    );
                                        IF @n_plfc_cnt > 1
										BEGIN
                                            RAISERROR('Dependent is in multiple DDS PPO Plans',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 317;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
                                    END;
		
                                IF @as_term_date IS NULL--(going be in the sub new plan)
                                    BEGIN
                                        EXECUTE dbo.dlp_check_sg_addr @a_batch_id,
                                            'Y', 0, @n_error_no OUTPUT,
                                            @as_addr_action OUTPUT;
                        IF @n_error_no < 0
                                            BEGIN
                                                SET @s_all_dep_err = 'Y';
                                                SET @s_ind_dep_err = 'Y';
                                            END;
                                        ELSE
                                            IF @as_action_code = 'MU'
                                                IF @as_addr_action LIKE 'G[1-7]'
                                                    ESCAPE '\'
                                                    BEGIN
                                                        
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                            @s_dls_sir_id,
                                                            @as_addr_action,
           @as_gpplrt_eff;
      END;
						--LET as_action_code = as_addr_action; --20131021$$ks dep addr recs??
					
				
                                    END;
                            END;
	 -- no errors
                        IF @s_ind_dep_err = 'N'
		-- Action code is DA
                            BEGIN
                                IF @as_action_code = 'DA'
                                    BEGIN
                                        IF @n_sub_action_code = 'ST'
                                            BEGIN
                                                SET @s_all_dep_err = 'Y';
                       SET @s_ind_dep_err = 'Y';
												BEGIN
                                                RAISERROR('New Dependent with terminated Sub',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 350;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
                                            END;
                                        ELSE
                                            BEGIN
                                                SET @n_rate_code = '';
                                                IF @as_term_date IS NOT NULL
												BEGIN
                                                    RAISERROR('New Dependent with Term date',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 303;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
                                            END;
			 -- 20131027$$ks - stop test here and check if any errors
                                        IF @s_ind_dep_err != 'Y'
                                            BEGIN 
				/* 20131006$$ks - added PA to logic below
				 * 20131027$$ks -- DA allowed with the following sub_action_codes
				 * 	SA, PC, SR, RI, PA, MU, GI, Gn, FX
				 * 	SA, PC, SR, RI, PA will not have active rlmgrpl records in DB
				 * 	
				 */
                                                DECLARE @SWV_cursor_var2 CURSOR;
                                                IF @n_sub_action_code NOT IN (
                                                    'SA', 'PC', 'SR', 'RI',
                                                    'PA' )
                                                    BEGIN
                                                        EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                            @as_pl_id,
                  @n_sub_id,
                                                            @as_gpplrt_eff,
                                                            'N',
                                                            @n_count OUTPUT,
                                                            @n_mbgrpl_id OUTPUT,
                                                            @n_sub_gp_id OUTPUT,
                                                            @n_sub_pl_id OUTPUT,
                                                            @n_sub_in_plan OUTPUT,
                                                            @n_gr_pl_eff OUTPUT,
                                            @n_gr_pl_exp OUTPUT;
                                                 IF @n_count <> 1
						--more than 1 record found
													BEGIN
                                                            RAISERROR('Sub is active in multiple Group and Plan',0,1);
															EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 240;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                               SET @SWV_cursor_var2 = CURSOR  FOR SELECT eff_rt_date, rate_code 
                       FROM dbo.rlmbrt (NOLOCK)
                        WHERE mb_gr_pl_id = @n_mbgrpl_id
                        AND exp_rt_date IS NULL
                        ORDER BY eff_rt_date DESC;
                                                        OPEN @SWV_cursor_var2;
                                                        FETCH NEXT FROM @SWV_cursor_var2 INTO @n_eff_rt_date,
                                                            @n_rate_code;
                                                        WHILE @@FETCH_STATUS = 0
                                      BEGIN
                                                              GOTO SWL_Label14;
                                                              FETCH NEXT FROM @SWV_cursor_var2 INTO @n_eff_rt_date,
                                                              @n_rate_code;
                                                            END;
                                                        SWL_Label14:
                                                        CLOSE @SWV_cursor_var2;
                                                        IF ( @n_rate_code IS NULL
                                                             OR @n_rate_code = ''
                                                           )
														   BEGIN
                                                            RAISERROR('No active Subscriber Rate code',0,1);
															EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 614;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                        IF @n_eff_rt_date > @as_gpplrt_eff
														BEGIN
                                                            RAISERROR('Can''t add dep before sub''s rate eff date',0,1);
															EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 377;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                        IF @n_gr_pl_exp < @as_gpplrt_eff
														BEGIN
                                                            RAISERROR('New Dependent with terminated Sub',0,1);
															EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 350;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                        
                                                        IF @n_has_facility_id = 'Y'
                                                            BEGIN
                                                              
                                                              IF @s_facility_id IS NULL
                                                              AND @n_sub_fc_id IS NOT NULL
                                                              BEGIN
                                                              SET @s_facility_id = @n_sub_fc_id;
                                                             
                                                              END;
                                                            END;
                           END;
                                                ELSE
                                                    IF @n_sub_gppl_eff > @as_gpplrt_eff
													BEGIN
                                                        RAISERROR('New Dependent effective before new Sub',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 350;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
				
                                                IF @n_ffs_plan = 0
                                                    BEGIN
                                                        SELECT
                                                              @num_fac_count = num_facil
                                                        FROM  dbo.pl_rat (NOLOCK)
                                                        WHERE rate_code = @n_rate_code;
												 IF @@rowcount = 0
                                                 SELECT
                                                    @num_fac_count = NULL;
                                                        IF ( @num_fac_count = 1 )
                                                            SET @as_fc_id = @n_sub_fc_id;
                                                        ELSE
                                                            BEGIN
                                                              
                                                              SET @as_fc_id = @s_facility_id;
                                                            END;
					
                                                        
                                                        IF @s_facility_id IS NULL
                                                            SET @as_fc_id = @def_fc_id;
					
                                                        
                                                        IF @n_sub_fc_id != @s_facility_id
                                                            BEGIN
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @s_facility_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              1;
                                                              IF @n_error_no < 0
                                                              BEGIN
                                                              SET @s_all_dep_err = 'Y';
                                                              SET @s_ind_dep_err = 'Y';
                                                              END;
                                                            END;
					
                                                        IF @n_error_no < 0
                                         BEGIN
                                                              SET @s_all_dep_err = 'Y';
                                                              SET @s_ind_dep_err = 'Y';
                                                            END;
                                                    END;
				
                                                IF @n_ffs_plan <> 0
                                                    SET @as_fc_id = NULL;
				
                                                IF @s_ind_dep_err = 'N'
                                                    BEGIN
                                                        SET @as_action_code = 'DA';
                                                        
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                            @s_dls_sir_id,
                                                            @as_action_code,
  @as_gpplrt_eff;
                                                    END;
				
   END;
            END;
		
                      IF @as_action_code = 'MT'
                                    IF @n_sub_action_code = 'SA'
                                        BEGIN
                                            SET @s_all_dep_err = 'Y';
                                            SET @s_ind_dep_err = 'Y';
											BEGIN
                                            RAISERROR('Existing dependent with New Subscriber',0,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 305;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
                                        END;
       ELSE
                                        BEGIN
                                            IF @n_sub_id != @a_sub_id
											BEGIN
                                                RAISERROR('Dependent sub is not in the same family',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 351;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
				
                                            IF @n_sub_action_code = 'ST'
                                                IF @as_term_date > @n_sub_plan_term
												BEGIN
                                                    RAISERROR('Dep term after subscriber term date',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 359;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
				
                                            SET @n_mbgrpl_id = NULL;
                                            EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                @as_pl_id, @n_sub_id,
                                                @as_gpplrt_eff, 'N',
                                                @n_count OUTPUT,
                                                @n_mbgrpl_id OUTPUT,
                                                @n_sub_gp_id OUTPUT,
                                                @n_sub_pl_id OUTPUT,
                                                @n_sub_in_plan OUTPUT,
                                                @n_gr_pl_eff OUTPUT,
                                                @n_gr_pl_exp OUTPUT;
                                            IF @n_count > 1 --more than 1 record found
											BEGIN
                                                RAISERROR('Subscriber is active in multiple Group and Plan',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 240;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
				
                                            IF @n_count = 0
											BEGIN
                                                RAISERROR('Can''t find active subscriber to Group Plan',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 223;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
				
                                            SET @SWV_cursor_var3 = CURSOR  FOR SELECT eff_rt_date, rate_code 
            FROM dbo.rlmbrt (NOLOCK)
                     WHERE mb_gr_pl_id = @n_mbgrpl_id
                     AND exp_rt_date IS NULL
                     ORDER BY eff_rt_date DESC;
                                            OPEN @SWV_cursor_var3;
            FETCH NEXT FROM @SWV_cursor_var3 INTO @n_eff_rt_date,
                                                @n_rate_code;
                 WHILE @@FETCH_STATUS = 0
                                         BEGIN
                                                    GOTO SWL_Label15;
                                                    FETCH NEXT FROM @SWV_cursor_var3 INTO @n_eff_rt_date,
                                                        @n_rate_code;
                                                END;
        SWL_Label15:
    CLOSE @SWV_cursor_var3;
                                            IF ( @n_rate_code IS NULL
                                                 OR @n_rate_code = ''
                                               )
											   BEGIN
                                                RAISERROR('No active Subscriber Rate code',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 614;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
				
                                            SET @n_rlplfc_id = NULL;
                                            SET @n_facility_id = NULL;
                                            SET @n_eff_date = NULL;
                                            SET @n_exp_date = NULL;

											
                                            SET @SWV_cursor_var4 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
					
                     FROM dbo.rlplfc (NOLOCK)
                     WHERE mb_gr_pl_id = @n_mbgrpl_id
                     AND member_id = @as_member_id
                     AND exp_date IS NULL
                     ORDER BY eff_date DESC,exp_date;
                                            OPEN @SWV_cursor_var4;
                                            FETCH NEXT FROM @SWV_cursor_var4 INTO @n_rlplfc_id,
                                                @n_facility_id, @n_eff_date,
											  @n_exp_date;
												WHILE @@FETCH_STATUS = 0
                                                BEGIN
                                                    GOTO SWL_Label16;
                                                    FETCH NEXT FROM @SWV_cursor_var4 INTO @n_rlplfc_id,
                                                        @n_facility_id,
                                                        @n_eff_date,
                                                        @n_exp_date;
                                                END;
                                            SWL_Label16:
                                            CLOSE @SWV_cursor_var4;
                                            IF @n_eff_date IS NULL
											BEGIN
                                                RAISERROR('Dep has no active facility record',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 616;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
                                            ELSE
                                                SET @as_fc_id = @n_facility_id;
				
                                            IF @as_term_date < @n_eff_date
											BEGIN
                                                RAISERROR('Terminate before active facility date',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 617;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
				
                                            IF @n_exp_date IS NULL
                                                BEGIN
                                                    SET @as_gpplrt_eff = @n_eff_date;
                                                    SET @as_fc_eff = @n_eff_date;
                                                    IF @as_gpplrt_eff < @n_eff_date
                      SET @as_gpplrt_eff = @n_eff_date;
					
                                                    IF @as_term_date < @as_gpplrt_eff
													BEGIN
                                                        RAISERROR('Dep term date is before effective date',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 361;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    IF @s_ind_dep_err != 'Y'
                                                        BEGIN
                                SET @as_action_code = 'MT';
                                                            
                                                            EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_term_date;
                                                        END;
                                                END;
                                            ELSE
                                                BEGIN
                                                    SET @as_action_code = 'MU'; -- 20121018$$ks was GI chgd to MU
                                                    IF @s_ind_dep_err != 'Y'
                                                        BEGIN
                                                            
                                                            EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_gpplrt_eff;
                                                        END;
                                                END;
                                        END;
			
		
		/* 20131101$$ks -- added Reinstate to possible action codes
		 */
                                IF @as_action_code IN ( 'MU', 'PA', 'RI' )
                                    IF @n_sub_action_code = 'SA'
                                        BEGIN
                                            SET @s_all_dep_err = 'Y';
                                            SET @s_ind_dep_err = 'Y';
											BEGIN
										   RAISERROR('Existing dependent with New Subscriber',0,1);
											   EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 305;
												 IF @i_fatal <> 1 
												 BEGIN
						 							SET @s_all_dep_err = 'Y';
						 							SET @s_ind_dep_err = 'Y';
												 END ;
										END
                                        END;
										ELSE
                                        BEGIN
                                            IF @n_sub_id != @a_sub_id
											BEGIN
                                                RAISERROR('Dependent sub is not in the same family',0,1);
												EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 351;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
				
			--LET as_action_code = "GI";
 IF @n_ffs_plan = 0
                                                BEGIN
                                                    
                                                    IF @n_has_facility_id = 'Y'
                                                        BEGIN
                                                           
                  IF @s_facility_id IS NOT NULL
                                                   AND @s_facility_id != 0
                                                              BEGIN
                                                              
                                                              IF @n_sub_fc_id != @s_facility_id
      BEGIN
                              
                                                              SET @as_fc_id = @s_facility_id;
                                                          
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              0;
                                                              IF @n_error_no < 0
                                                              SET @as_fc_id = @n_sub_fc_id;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                         
                                                              SET @as_fc_id = @s_facility_id;
                                                              END;
                                                              END;
                                                            ELSE
                                                              SET @as_fc_id = @n_sub_fc_id;
                                                        END;
                                                    ELSE
                                                        BEGIN
                                                            SET @v_Null = 0;
                                                        END;
					--LET as_fc_id = def_fc_id;
                                                END;
                                            ELSE
                                                SET @as_fc_id = NULL;
				
				/* 20131101$$ks -- added Reinstate to possible action codes
				 */
                                            IF @as_action_code IN ( 'PA', 'RI' ) --verify fc then log action
                                                BEGIN
                                                   
                                                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                        @s_dls_sir_id,
                                                        @as_action_code,
                                                        @as_gpplrt_eff;
                                                END;
				
   IF @as_action_code = 'MU'
            AND @n_sub_action_code = 'PC'
                                                BEGIN
                                                    DECLARE @SWV_cursor_var5 CURSOR;
                                                    DECLARE @SWV_cursor_var6 CURSOR;
                                                    SET @n_rlplfc_id = NULL;
                                                    SET @n_facility_id = NULL;
                                                    SET @n_eff_date = NULL;
           SET @n_exp_date = NULL;
                                                    SET @SWV_cursor_var5 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
						
                        FROM dbo.rlplfc (NOLOCK)
     WHERE mb_gr_pl_id = @a_mbgrpl_id
                        AND member_id = @as_member_id
                        AND exp_date IS NULL
            ORDER BY eff_date DESC,exp_date;
                                                    OPEN @SWV_cursor_var5;
                                                    FETCH NEXT FROM @SWV_cursor_var5 INTO @n_rlplfc_id,
                                       @n_facility_id,
                                 @n_eff_date,
                                                        @n_exp_date;
                                                    WHILE @@FETCH_STATUS = 0
                                                        BEGIN
                                                            GOTO SWL_Label17;
                                                            FETCH NEXT FROM @SWV_cursor_var5 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                        END;
                                                    SWL_Label17:
                                                    CLOSE @SWV_cursor_var5;
                                                    IF @n_rlplfc_id IS NULL
                                                        BEGIN
                                                            SET @SWV_cursor_var6 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
							
                           FROM dbo.rlplfc (NOLOCK)
                           WHERE mb_gr_pl_id = @a_mbgrpl_id
                           AND member_id = @as_member_id
                           ORDER BY eff_date DESC,exp_date DESC;
                                                            OPEN @SWV_cursor_var6;
                                                            FETCH NEXT FROM @SWV_cursor_var6 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                            WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label18;
                                                              FETCH NEXT FROM @SWV_cursor_var6 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                              END;
                                                            SWL_Label18:
                                                            CLOSE @SWV_cursor_var6;
                               END;
					
     IF @as_fc_id IS NULL
                                                        AND @n_ffs_plan = 0
                                                        IF @n_rlplfc_id IS NULL
                                                            SET @as_fc_id = @n_sub_fc_id;
                                                        ELSE
                                                            BEGIN
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                 @s_dls_sir_id,
                                      @n_facility_id,
                                                              @as_pl_id,
                                              @as_gpplrt_eff,
                                                              0;
                  IF @n_error_no <= 0
                                               SET @as_fc_id = @n_sub_fc_id;
                                                              ELSE
    SET @as_fc_id = @n_facility_id;
                                                            END;
						
					
                                 IF @s_ind_dep_err != 'Y'
                                                        BEGIN
                                                            SET @as_action_code = 'PC';
                                                            
                                                            EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_gpplrt_eff;
                                                        END;
					
                                                END;
				
                                            IF @as_action_code = 'MU'
                                                BEGIN
                                                    SET @n_mbgrpl_id = NULL;
                                                    EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                        @as_pl_id, @n_sub_id,
                                                        @as_gpplrt_eff, 'N',
                                                        @n_count OUTPUT,
                                                        @n_mbgrpl_id OUTPUT,
                                                        @n_sub_gp_id OUTPUT,
                                                        @n_sub_pl_id OUTPUT,
                                                        @n_sub_in_plan OUTPUT,
                                                        @n_gr_pl_eff OUTPUT,
                                                        @n_gr_pl_exp OUTPUT;
                                                    IF @n_count <> 1
						--more than 1 record found
													BEGIN
                                                        RAISERROR('Subscriber is active in multiple Group and Plan',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 240;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    SET @SWV_cursor_var7 = CURSOR  FOR SELECT eff_rt_date, rate_code 
                        FROM dbo.rlmbrt (NOLOCK)
                        WHERE mb_gr_pl_id = @n_mbgrpl_id
                        AND exp_rt_date IS NULL
                        ORDER BY eff_rt_date DESC;
                                                    OPEN @SWV_cursor_var7;
                                                    FETCH NEXT FROM @SWV_cursor_var7 INTO @n_eff_rt_date,
    @n_rate_code;
                                                    WHILE @@FETCH_STATUS = 0
          BEGIN
     GOTO SWL_Label19;
                                                            FETCH NEXT FROM @SWV_cursor_var7 INTO @n_eff_rt_date,
                                                              @n_rate_code;
                                                        END;
                                                    SWL_Label19:
                                                    CLOSE @SWV_cursor_var7;
                                                    IF ( @n_rate_code IS NULL
                                                         OR @n_rate_code = ''
)
													   BEGIN
                                                        RAISERROR('No active Subscriber Rate code',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 614;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    IF ( @n_rate_code IS NOT NULL
                               AND @n_rate_code <> ''
                                                       )
                                                        BEGIN
                                                            SELECT
                                                              @num_fac_count = num_facil
                                                            FROM
                                                              dbo.pl_rat (NOLOCK)
                                                            WHERE
                                                              rate_code = @n_rate_code;
                                                            IF @@rowcount = 0
                                                              SELECT
                                                              @num_fac_count = NULL;
                                                        END;
					
                                                    IF @num_fac_count IS NULL
													BEGIN
                                                        RAISERROR('Invalid Rate Code',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 274;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    SET @n_rlplfc_id = NULL;
                                                    SET @n_facility_id = NULL;
                                                    SET @n_eff_date = NULL;
                                                    SET @n_exp_date = NULL;
                                                    SET @SWV_cursor_var8 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
						
                        FROM dbo.rlplfc (NOLOCK)
                        WHERE mb_gr_pl_id = @n_mbgrpl_id
                        AND member_id = @as_member_id
                        AND exp_date IS NULL
                        ORDER BY eff_date DESC,exp_date;
                                                    OPEN @SWV_cursor_var8;
                                                    FETCH NEXT FROM @SWV_cursor_var8 INTO @n_rlplfc_id,
                                                        @n_facility_id,
                                                        @n_eff_date,
                                                        @n_exp_date;
                                                    WHILE @@FETCH_STATUS = 0
                                                        BEGIN
                                                            GOTO SWL_Label20;
                                                            FETCH NEXT FROM @SWV_cursor_var8 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                        END;
                                                    SWL_Label20:
                                                    CLOSE @SWV_cursor_var8;
                                                    IF @n_eff_date IS NULL
   BEGIN
                                                            SET @n_facility_id = NULL;
                                                            SET @n_eff_date = NULL;
                                                         SET @SWV_cursor_var9 = CURSOR  FOR SELECT DISTINCT rlplfc_id, facility_id, eff_date, exp_date
							
                           FROM dbo.rlplfc (NOLOCK)
          WHERE mb_gr_pl_id = @n_mbgrpl_id
AND member_id = @as_member_id
                           AND eff_date <= @as_gpplrt_eff
               AND (exp_date >= @as_gpplrt_eff OR exp_date IS NULL)
							-- 20131108$$ks - chg exp_date > to exp_date >=
							--	20121018$$ks	ORDER BY 2 desc, 3
                           ORDER BY eff_date DESC,exp_date;
                                                            OPEN @SWV_cursor_var9;
                                                            FETCH NEXT FROM @SWV_cursor_var9 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                            WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label21;
                                                              FETCH NEXT FROM @SWV_cursor_var9 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                              END;
                                                            SWL_Label21:
                                                            CLOSE @SWV_cursor_var9;
                                                        END;
					
                                                    IF @n_exp_date IS NULL
                                                        BEGIN
                                                            IF @n_sub_gppl_eff < @as_gpplrt_eff
                                                              SET @as_gpplrt_eff = @n_sub_gppl_eff;
						
                                                            IF @as_gpplrt_eff < @n_eff_date
                                                              SET @as_gpplrt_eff = @n_eff_date;
						
                                                            IF @s_ind_dep_err = 'N'
                                                              BEGIN
                                                              IF @n_sub_action_code = 'PA'
                                                              SET @as_action_code = 'PA';
                                                              ELSE
                                                              IF @n_sub_action_code = 'RI'
                                                              SET @as_action_code = 'RI';
                                                              ELSE
                                                              IF @n_eff_date IS NULL
								/* 20121018$$ks - Sub exists but no Dep record in rlplfc = Plan Add */
                                                              SET @as_action_code = 'PA'; -- 20121018$$ks - was RI and commented out
								
							
                                                              IF @as_action_code <> 'MU' -- already logged above
                                  BEGIN
                                                              
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                        @s_dls_sir_id,
                                                              @as_action_code,
  @as_gpplrt_eff;
         END;
                                                              END;
                                          END;
                                                    ELSE
                                                        BEGIN
                                          IF @n_sub_action_code = 'ST'
                                             IF @as_gpplrt_eff < @n_sub_plan_term
															  BEGIN
                                                  RAISERROR('Dep active after subscriber term date',0,1);
															  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 353;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
							
						
                                                            IF @s_ind_dep_err = 'N'
                                                              BEGIN
                                                              SET @as_action_code = 'DR'; -- chg from RI to DR 
                                                           
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_gpplrt_eff;
                                                              END;
                                                        END;
                                                END;
				
                                            IF @as_action_code = 'MU'
                                                BEGIN
                                                    SET @n_mbgrpl_id = NULL;
                                                    EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                        @as_pl_id, @n_sub_id,
                                                        @as_gpplrt_eff, 'N',
                                                        @n_count OUTPUT,
                                                        @n_mbgrpl_id OUTPUT,
                                                        @n_sub_gp_id OUTPUT,
                                                        @n_sub_pl_id OUTPUT,
                                                        @n_sub_in_plan OUTPUT,
                                                        @n_gr_pl_eff OUTPUT,
                                                        @n_gr_pl_exp OUTPUT;
                                                    IF @n_count <> 1 --more than 1 record found
													BEGIN
                                                        RAISERROR('Subscriber is active in multiple Group and Plan',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 240;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    SET @SWV_cursor_var10 = CURSOR  FOR SELECT eff_rt_date, rate_code 
                        FROM dbo.rlmbrt (NOLOCK)
                        WHERE mb_gr_pl_id = @n_mbgrpl_id
                        AND eff_rt_date IS NULL
                        ORDER BY eff_rt_date DESC;
                                                    OPEN @SWV_cursor_var10;
                                                    FETCH NEXT FROM @SWV_cursor_var10 INTO @n_eff_rt_date,
                                                        @n_rate_code;
                                                    WHILE @@FETCH_STATUS = 0
                                                        BEGIN
         GOTO SWL_Label22;
        FETCH NEXT FROM @SWV_cursor_var10 INTO @n_eff_rt_date,
                                                              @n_rate_code;
                              END;
                                SWL_Label22:
      CLOSE @SWV_cursor_var10;
       IF ( @n_rate_code IS NULL
                                                         OR @n_rate_code = ''
                                    )
													   BEGIN
                                                        RAISERROR('No active Subscriber Rate code',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 614;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    IF ( @n_rate_code IS NOT NULL
                                                         AND @n_rate_code <> ''
                                                       )
                                                        BEGIN
                                                            SELECT
                                                              @num_fac_count = num_facil
                                                            FROM
                                                              dbo.pl_rat (NOLOCK)
                                                            WHERE
                                                              rate_code = @n_rate_code;
                                                            IF @@rowcount = 0
                                                              SELECT
                                                              @num_fac_count = NULL;
                                                        END;
					
                                                    IF @num_fac_count IS NULL
													BEGIN
                                                        RAISERROR('Invalid Rate Code',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 274;
						 IF @i_fatal <> 1 
						 BEGIN
						 	SET @s_all_dep_err = 'Y';
						 	SET @s_ind_dep_err = 'Y';
						 END ;
						END
					
                                                    SET @n_rlplfc_id = NULL;
                                                    SET @n_facility_id = NULL;
                                                    SET @n_eff_date = NULL;
                                                    SET @n_exp_date = NULL;
                                                    SET @SWV_cursor_var11 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
						
                        FROM dbo.rlplfc (NOLOCK)
                        WHERE mb_gr_pl_id = @n_mbgrpl_id
                        AND member_id = @as_member_id
                        AND exp_date IS NULL
                        ORDER BY eff_date DESC,exp_date;
                                                    OPEN @SWV_cursor_var11;
                                                    FETCH NEXT FROM @SWV_cursor_var11 INTO @n_rlplfc_id,
                                                        @n_facility_id,
                                                        @n_eff_date,
                                                        @n_exp_date;
                                                    WHILE @@FETCH_STATUS = 0
                                                        BEGIN
                                                            GOTO SWL_Label23;
                                                            FETCH NEXT FROM @SWV_cursor_var11 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                   @n_exp_date;
                                                        END;
                                                    SWL_Label23:
                                                    CLOSE @SWV_cursor_var11;
               IF @n_eff_date IS NULL
                                                        BEGIN
 SET @n_facility_id = NULL;
                                                            SET @n_eff_date = NULL;
                                                      SET @SWV_cursor_var12 = CURSOR  FOR SELECT DISTINCT rlplfc_id, facility_id, eff_date, exp_date
							
                        FROM dbo.rlplfc (NOLOCK)
                           WHERE mb_gr_pl_id = @n_mbgrpl_id
                           AND member_id = @as_member_id
                           AND eff_date <= @as_gpplrt_eff
                           AND (exp_date > @as_gpplrt_eff OR exp_date IS NULL)
                           ORDER BY 2 DESC,3;
                                                            OPEN @SWV_cursor_var12;
                                                            FETCH NEXT FROM @SWV_cursor_var12 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                            WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label24;
                                                              FETCH NEXT FROM @SWV_cursor_var12 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
                                                              END;
                                                            SWL_Label24:
                                                            CLOSE @SWV_cursor_var12;
                                                        END;
					
                                                    IF @n_ffs_plan = 0
                                                        BEGIN
                                                            IF @n_sub_action_code = 'FX' --20131021$$ks only all chg if num_fc = 1
                                                              IF @num_fac_count = 1
                                                              BEGIN
                                                              SET @s_facility_id = @n_sub_fc_id ;
                                                              -- dep must be same as sub
                                                              IF @n_sub_fc_id != @n_facility_id
                                                              SET @as_action_code = 'FX';
                                                              END;
							
						
                                                           
                                                            IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                                              
                                                              IF @s_facility_id IS NULL
                                                              BEGIN
                                                              SET @s_facility_id = @n_facility_id;
                                                             
                                                              END;
							
                                                             
                                     IF @n_facility_id != @s_facility_id
                                                              IF @as_fc_eff >= @n_eff_date
                                                              BEGIN
                                                              
     IF @n_sub_fc_id != @s_facility_id
                                IF @num_fac_count > 1
                                                   BEGIN
                                 
                             
 EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                          @s_facility_id,
                                                              @as_pl_id,
                                                              @as_fc_eff, 1;
                                                              IF @n_error_no < 0
                                                              BEGIN
                                                              SET @s_ind_dep_err = 'Y';
                                                              SET @s_all_dep_err = 'Y';
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                            
                                                              SET @as_fc_id = @s_facility_id;
                                                              SET @as_action_code = 'FX';
                                                              END;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              SET @as_fc_id = @n_sub_fc_id;
                                                              SET @as_action_code = 'FX';
                                                              END;
										
                                                              ELSE
                                                              BEGIN
                                                             
                                                              SET @as_fc_id = @s_facility_id;
                                                              SET @as_action_code = 'FX';
                                                              END;
                                                              END;
                                                              ELSE
                                                              IF @n_sub_fc_id != @n_facility_id
                                                              IF @num_fac_count > 1 -- Dont force FC Chg
                                                              BEGIN
                                                              SET @as_action_code = 'MU'; -- $$ks GI to MU
                                                              SET @as_fc_id = @n_facility_id;
                                                              SET @as_fc_eff = @n_eff_date;
                                                              END;
                                                              ELSE -- RC only allows mbrs to be in same FC
                                                              BEGIN
                                                              SET @as_action_code = 'FX';
                                                              SET @as_fc_id = @n_sub_fc_id;
                                                              SET @as_fc_eff = @n_eff_date;
                                                              END;
										
       ELSE -- Sub FC same as current Dep FC
                                                              BEGIN
                                                              SET @as_fc_eff = @n_eff_date;
                                                              SET @as_action_code = 'MU';
      SET @as_fc_id = @n_facility_id;
             END;
									
								
                                              ELSE
     IF @n_sub_fc_id != @n_facility_id
                                       IF @num_fac_count > 1
                                                              BEGIN
                SET @as_fc_id = @n_facility_id;
                                                              SET @as_action_code = 'MU';
                                                              SET @as_fc_eff = @n_eff_date;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              SET @as_fc_id = @n_sub_fc_id;
                                                              SET @as_action_code = 'FX';
                                                              END;
									
                                                              ELSE
                                                              BEGIN
                                                              SET @as_fc_id = @n_facility_id;
                                                              SET @as_action_code = 'MU';
                                                              SET @as_fc_eff = @n_eff_date;
                                                              END;
								
                                                              END;
                                                            ELSE
                                                              IF @n_facility_id != @n_sub_fc_id
                                                              IF @num_fac_count > 1
                                                              BEGIN
                                                              SET @as_fc_id = @n_facility_id;
                                                              SET @as_action_code = 'MU';
                                                              SET @as_fc_eff = @n_eff_date;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              SET @as_fc_id = @n_sub_fc_id;
                                                              SET @as_action_code = 'FX';
         SET @as_fc_eff = @as_fc_eff;
                                                              END;
								
                                                              ELSE
                                                              BEGIN
                                                              SET @as_fc_id = @n_facility_id;
                                                              SET @as_action_code = 'MU';
                                                              SET @as_fc_eff = @n_eff_date;
                                                              END;
							
                                                        END;
                                                    ELSE
                                                        BEGIN
                                                            SET @as_action_code = 'MU';
                                                            SET @as_fc_id = NULL;
                                                    END;
					
                                                    IF @s_ind_dep_err != 'Y'
                          BEGIN
                                                            IF @as_action_code = 'FX'
                                                              EXECUTE dbo.get_xfer_date @n_facility_id,
@as_fc_id,
                     @n_eff_date,
                                                              @as_fc_eff,
                                           @as_fc_eff OUTPUT;
						
                                                  
                                                            EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
  @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_fc_eff;
                                                        END;
                                                END;
                                        END;
			
                            END;
	
                        IF @s_ind_dep_err = 'Y'
                            UPDATE  dbo.dls_sg_member
                            SET     dls_status = 'E' ,
                                    dls_member_id = @as_member_id ,
                                    dls_subscriber_id = @as_sub_id ,
                                    dls_msg_id = @as_msg_id ,
                                    dls_group_id = @as_gp_id ,
                                    dls_plan_id = @as_pl_id ,
                                    rate_code = @s_rate_code ,
                                    dls_facility_id = @as_fc_id ,
                                    dls_action_code = @as_action_code
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sir_id = @s_dls_sir_id;
                        ELSE
                            UPDATE  dbo.dls_sg_member
                            SET     dls_status = 'P' ,
                                    dls_member_id = @as_member_id ,
                                    dls_subscriber_id = @as_sub_id ,
                                    dls_msg_id = @as_msg_id ,
                                    dls_group_id = @as_gp_id ,
                                    dls_plan_id = @as_pl_id ,
                                    rate_code = @s_rate_code ,
                                    dls_facility_id = @as_fc_id ,
                                    dls_action_code = @as_action_code
                            WHERE   dls_batch_id = @a_batch_id
           AND dls_sir_id = @s_dls_sir_id;
                    END TRY
                    BEGIN CATCH
                        SET @n_error_no = ERROR_NUMBER();
                        SET @n_isam_error = ERROR_LINE();
                        SET @n_error_descr = ERROR_MESSAGE();
						SET @ReturnValue1 = -1
                       -- RETURN -1;
                    END CATCH;
                END;
                SWL_Label13:
                FETCH NEXT FROM @SWV_cursor_var1 INTO @s_dls_sir_id,
                    @s_dls_sub_sir_id, @s_member_flag, @s_alt_id, @s_ssn,
                    @s_sub_ssn, @s_sub_alt_id, @s_member_code, @s_optional_5,
                    @s_last_name, @s_first_name, @s_middle_init,
                    @s_date_of_birth, @s_student_flag, @s_disable_flag,
                    @s_cobra_flag, @s_msg_group_id, @s_plan_id, @s_facility_id,
                    @s_rate_code, @s_mb_gppl_eff_date, @s_mb_fc_eff_date,
                    @s_mb_term_date, @s_bank_account, @s_account_type,
                    @s_trans_rt_nbr, @s_transaction_code, @s_address1,
                    @s_address2, @s_city, @s_state, @s_zip, @s_zipx,
                    @s_home_phone, @s_home_ext, @s_work_phone, @s_work_ext,
					@s_email, @s_producer_id, @s_comm_scheme_id, @s_pd_type,
                    @s_license_number, @s_selling_period, @s_pdcomm_eff_date,
                    @s_msg_group_alt_id, @s_plan_dsp_name, @s_facility_alt_id,
                    @s_producer_alt_id, @t_new_ssn, @t_src_id, @t_subnew_ssn,
              @t_subsrc_id, @t_ext_id_col, @api_mbr_id, @api_fc_id;
            END;
        CLOSE @SWV_cursor_var1;
        IF @s_all_dep_err = 'Y'
		BEGIN
		
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
		SET @n_succ_count = @n_succ_count + @n_dep_count;
		UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1

                SET @ReturnValue1 = -1
            RETURN -1;
			END
   ELSE
            BEGIN
            
				SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                SET @n_succ_count = @n_succ_count + @n_dep_count;
				UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1

                SET @ReturnValue1 = 1
                RETURN 1;
            END;
        SET NOCOUNT OFF;
    END;