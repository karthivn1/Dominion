﻿CREATE PROCEDURE [dbo].[dlp_chk_facility]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_facility_id INT ,
    @a_plan_id INT ,
    @a_as_of_date DATE ,
    @a_log_error INT
    
AS
    BEGIN


        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);

        DECLARE @d_eff_date DATE;
        DECLARE @d_exp_date DATE;
        DECLARE @d_fc_net_id INT;
        DECLARE @d_net_id INT;
        DECLARE @d_ovr_ride CHAR(1);
        DECLARE @d_status CHAR(2);
        DECLARE @d_net_fc_id INT;
        DECLARE @n_count INT;
        DECLARE @d_nnm_date DATE;
        DECLARE @s_ins_opt CHAR(3);
	
        DECLARE @i_fatal INT;

	DECLARE @i_sp_id integer;
	DECLARE @i_sir_def_id integer;
	DECLARE @n_add_to_cl_fc char(1);
       

        SET NOCOUNT ON;
        SET @i_sp_id = 0;
       
        SET @i_sir_def_id = 0;
        
        SET @n_add_to_cl_fc = 'N';

		SELECT @i_sp_id = a.sp_id,@i_sir_def_id = a.sir_def
		FROM dl_cfg_bat_det a(NOLOCK) 
		INNER JOIN dl_sp b (NOLOCK) ON a.sp_id=b.sp_id
		WHERE config_bat_id=@a_batch_id 
		AND b.sp_display='Preprocess'
      
        BEGIN TRY
            
            IF @a_facility_id IS NULL
                BEGIN
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.[plan] (NOLOCK) ,
                                            dbo.ins_opt (NOLOCK)
                                    WHERE   dbo.[plan].plan_id = @a_plan_id
                                            AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                            AND dbo.ins_opt.ins_opt_qual = 'I' )
						BEGIN
						SET @n_return_code = 189
                        RAISERROR('Facility ID missing from client file',16,1);
						RETURN
						END
                END;
            ELSE
                BEGIN
                    SELECT  @s_ins_opt = ins_opt
                    FROM    dbo.[plan] (NOLOCK)
                    WHERE   plan_id = @a_plan_id;
                    
                END;
	
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.facility (NOLOCK)
                            WHERE   fc_id = @a_facility_id )
				BEGIN 
				SET @n_return_code = 404
				 RAISERROR('Invalid facility ID',16,1);
				 RETURN
				END
	
            SELECT DISTINCT
                    @d_net_id = net_id ,
                    @d_net_fc_id = net_fc_id ,
                    @d_ovr_ride = ovr_ride
            FROM    dbo.net_facility (NOLOCK)
            WHERE   fc_id = @a_facility_id
                    AND
			--con_type in ("HMO", "RFS") and 
                    con_type = @s_ins_opt
                    AND eff_date <= @a_as_of_date
                    AND ( exp_date IS NULL
                          OR exp_date > @a_as_of_date
                        );
            
            IF ( @d_net_fc_id IS NULL )
			BEGIN 
			SET @n_return_code = 199
                RAISERROR('Network/facility association not found',16,1);
				RETURN
			END
	
            SELECT DISTINCT
                    @d_eff_date = eff_date
            FROM    dbo.net_plans (NOLOCK)
            WHERE   subsys_code = 'NT'
                    AND fc_net_id = @d_net_id
                    AND plan_id = @a_plan_id
                    AND eff_date <= @a_as_of_date
                    AND ( exp_date IS NULL
                          OR exp_date > @a_as_of_date
                        );
           
            IF ( @d_eff_date IS NULL )
			BEGIN
			SET @n_return_code = 192
                RAISERROR('Network/plan assoication not found ',16,1);
				RETURN
				END
	
            IF @d_ovr_ride = 'Y'
                BEGIN
                    SELECT  @d_nnm_date = nnm_date ,
                            @d_eff_date = eff_date ,
                 @d_exp_date = exp_date
                   FROM    dbo.fc_plans (NOLOCK)
     WHERE   net_facility = @d_net_fc_id
   AND ovr_ride = 'Y'
                            AND plan_id = @a_plan_id
                            AND eff_date <= @a_as_of_date
        AND ( exp_date IS NULL
                   OR exp_date > @a_as_of_date
                          );
                   
				-- ameeta added on 06/07/00  above 2 lines date validation 	
                    IF @d_nnm_date IS NOT NULL
                        IF @d_nnm_date <= @a_as_of_date
						BEGIN
						SET @n_return_code = 193
                            RAISERROR('Facility does not accept new member',16,1);
							RETURN
							END

			
		
                    IF @d_exp_date IS NOT NULL
                        IF ( @d_eff_date <= @a_as_of_date
                             OR @d_exp_date = @d_eff_date
                           )
						   BEGIN
						   SET @n_return_code =196
                            RAISERROR('Facility does not accept this plan',16,1);
							RETURN
						END
			
                END;

				
	
            SELECT  @d_eff_date = eff_date ,
                    @d_status = status
            FROM    dbo.fcstat (NOLOCK)
            WHERE   facility_id = @a_facility_id
                    AND eff_date <= @a_as_of_date
                    AND ( exp_date IS NULL
                          OR exp_date > @a_as_of_date
                        );

			
           

            IF ( @d_eff_date IS NULL )
			BEGIN
			SET @n_return_code = 194
                RAISERROR('Facility has no status as of eff_date',16,1);
		RETURN
						END
	
            IF @d_status = 'TR'
			BEGIN
			SET @n_return_code = 198
                RAISERROR('Facility is terminated',16,1);
				RETURN
			END
            ELSE
                IF ( @d_status NOT IN ( 'AC', 'UF' ) )
                    IF @d_status = 'CL'
                        BEGIN
                           
                            IF @n_add_to_cl_fc = 'Y'
                                BEGIN
                                    SET @a_log_error = 1;
									BEGIN
									SET @n_return_code = 195
                                    RAISERROR('Facility is closed for new member',0,1);
									EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
										@a_sir_id, @n_return_code
									--RETURN
									END
                                END;
                            ELSE
							BEGIN
							SET @n_return_code = 197
                                RAISERROR('Facility is closed for new member',16,1);
								RETURN
								END
                        END;
	--trace off;
	
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_code = ERROR_NUMBER();
           -- SET @n_return_code = ERROR_LINE();
            SET @n_error_desc = ERROR_MESSAGE();
			IF @a_log_error = 1 
			BEGIN
			EXEC @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id,
				@a_sir_id, @n_return_code
				IF @i_fatal <> 1 
				BEGIN
					return -1;
				END ;
			END
			ELSE
			return -1;
			
        END CATCH;
        SET NOCOUNT OFF;

	
	--set debug file to "/tmp/dlp_chk_facility.trc";
	--trace on;
	
    END;