﻿CREATE PROCEDURE [dbo].[dlp_fc_count]
    @a_mb_gr_pl_id INT ,
    @a_sir_id INT ,
    @a_eff_date DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT
    
	

-- 11/22/96
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:12:12 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);

        DECLARE @n_count INT;
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_num_facil INT;
        DECLARE @n_exp_rt_date DATE;
        DECLARE @n_facility_id INT;
        DECLARE @SWV_error INT;
        DECLARE @SWV_cursor_var1 CURSOR;

--trace off;

        DECLARE @SWV_cursor_var2 CURSOR;

        SET NOCOUNT ON;
        SET LOCK_TIMEOUT -1;

        SET @n_count = 0;

        IF EXISTS ( SELECT  *
                    FROM    dbo.[plan] (NOLOCK) ,
                            dbo.ins_opt (NOLOCK) ,
                            dbo.rlmbgrpl (NOLOCK)
                    WHERE   dbo.rlmbgrpl.mb_gr_pl_id = @a_mb_gr_pl_id
                            AND dbo.[plan].plan_id = dbo.rlmbgrpl.plan_id
                            AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                            AND dbo.ins_opt.ins_opt_qual = 'I' )
            BEGIN
                SET @SWP_Ret_Value = 1;
                RETURN;
            END;


        SET @n_rate_code = NULL;

        SET @SWV_cursor_var1 = CURSOR  FOR SELECT rate_code, exp_rt_date
	
   FROM dbo.rlmbrt (NOLOCK)
   WHERE mb_gr_pl_id = @a_mb_gr_pl_id AND
   eff_rt_date <= @a_eff_date AND
		(exp_rt_date > @a_eff_date OR exp_rt_date IS NULL)
   ORDER BY 2 DESC;
        OPEN @SWV_cursor_var1;
        FETCH NEXT FROM @SWV_cursor_var1 INTO @n_rate_code, @n_exp_rt_date;
        WHILE @@FETCH_STATUS = 0
            BEGIN
                GOTO SWL_Label2;
                FETCH NEXT FROM @SWV_cursor_var1 INTO @n_rate_code,
                    @n_exp_rt_date;
            END;
        SWL_Label2:
        CLOSE @SWV_cursor_var1;

        IF ( (@n_rate_code IS NULL
             OR @n_rate_code = '')
           )
            BEGIN
                SET @SWP_Ret_Value = -1;
                RETURN;
            END;


        SELECT  @n_num_facil = num_facil
        FROM    dbo.pl_rat (NOLOCK)
        WHERE   rate_code = @n_rate_code;
        SELECT  @SWV_error = @@ERROR;
        IF ( @SWV_error = 0 )
            BEGIN
                IF @@rowcount = 0
                    BEGIN
                        SELECT  @n_num_facil = NULL;
                        SELECT  @SWV_error = @@ERROR;
                    END;
                IF ( @SWV_error = 0 )
                    BEGIN
                        IF @n_num_facil IS NULL
                            BEGIN
                                SET @SWP_Ret_Value = -1;
                                RETURN;
                            END;
                        SET @n_count = 0;
                        SET @SWV_cursor_var2 = CURSOR  FOR SELECT DISTINCT rf.facility_id
		
         FROM dbo.rlplfc rf (NOLOCK), dbo.fcstat fs (NOLOCK)
         WHERE rf.mb_gr_pl_id = @a_mb_gr_pl_id
         AND rf.eff_date <= @a_eff_date
         AND (rf.exp_date > @a_eff_date OR rf.exp_date IS NULL)
         AND rf.facility_id = fs.facility_id
         AND NOT (fs.eff_date <= @a_eff_date AND
			(fs.exp_date > @a_eff_date OR fs.exp_date IS NULL)
         AND fs.status = 'UF') UNION SELECT DISTINCT ts.facility_id
         FROM dbo.dls_elig ts (NOLOCK), dbo.fcstat fs (NOLOCK)
         WHERE ts.dls_sir_id = @a_sir_id
         AND ts.dls_action_code IN('DA','DR')
         AND ts.facility_id = fs.facility_id
         AND ts.plan_eff_date <= @a_eff_date
         AND NOT (fs.eff_date <= @a_eff_date AND
				(fs.exp_date > @a_eff_date OR fs.exp_date IS NULL)
         AND fs.status = 'UF')
         AND ts.dls_status = 'P';
                        OPEN @SWV_cursor_var2;
                        FETCH NEXT FROM @SWV_cursor_var2 INTO @n_facility_id;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                SET @n_count = @n_count + 1;
                                FETCH NEXT FROM @SWV_cursor_var2 INTO @n_facility_id;
                            END;
                        CLOSE @SWV_cursor_var2;
                        IF @n_count > @n_num_facil
                            BEGIN
                                SET @SWP_Ret_Value = -1;
                                RETURN;
                            END;
                        SET @SWP_Ret_Value = @n_count;
                        RETURN;
                    END;
            END;
        IF ( @SWV_error <> 0 )
            BEGIN
                SET @n_error_no = @SWV_error;
                SET @n_isam_error = ERROR_LINE();
                SET @n_error_text = 'MSSQLServer error: ' + STR(@SWV_error);
                SET @SWP_Ret_Value = -1;
                RETURN;
            END;
        SET NOCOUNT OFF;



--set debug file to "/tmp/dlp_fc_count.trc";
--trace on;

    END;