﻿CREATE PROCEDURE [dbo].[dlp_mbaddr]
    @p_batch_id INT ,
    @p_sir_id INT ,
    @p_member_id INT ,
    @p_addr1 VARCHAR(30) ,
    @p_addr2 VARCHAR(30) ,
    @p_city VARCHAR(30) ,
    @p_state VARCHAR(2) ,
    @p_zip VARCHAR(10) ,
    @p_home_phone CHAR(10) ,
    @p_home_ext CHAR(4) ,
    @p_work_phone CHAR(10) ,
    @p_work_ext CHAR(4)
    



-- DATE: 12/04/96

--	CALL tl_log_error(p_sir_id, n_return_code) RETURNING n_fatal;
--	CALL dl_log_error(p_batch_id, i_sp_id, i_sir_def_id, p_sir_id, n_return_code) RETURNING n_fatal;
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:21:21 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1



000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).

*/

        DECLARE @d_address_id INT;
        DECLARE @d_zip VARCHAR(5);
        DECLARE @d_city VARCHAR(30);
        DECLARE @d_state VARCHAR(2);
        DECLARE @d_county VARCHAR(20);

        DECLARE @n_fatal INT;
        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);
        DECLARE @n_mail CHAR(1);
        DECLARE @d_severity CHAR(1);
        DECLARE @n_zip INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @SWV_cursor_var1 CURSOR;
		DECLARE @error_code INT;
        SET NOCOUNT ON;
        SET @i_sp_id = 0;
       
        SET @i_sir_def_id = 0 ;
       
--	if n_fatal != 1 then
--		return -n_return_code;
--	end if
        BEGIN TRY
		

            SET @n_mail = 'N';
            SET @d_city = NULL;
            SET @d_county = NULL;
            SET @d_state = NULL;
            IF @p_member_id IS NULL
			BEGIN
			SET @error_code=301
                RAISERROR('Member ID is NULL',16,1);
			END

            SET @n_zip = 1;
            IF ( ( @p_zip IS NULL
                   OR @p_zip = ''
                 )
                 OR LEN(@p_zip) = 0
               )
                BEGIN
				SET @error_code=302
                    RAISERROR('Member zip is NULL',16,1);
                    SET @n_zip = 0;
                    SET @n_mail = 'Y';
                END;

            IF ( @p_addr1 IS NULL
                 OR @p_addr1 = ''
               )
                OR LEN(@p_addr1) = 0
				BEGIN
				SET @error_code=307
                RAISERROR('Member Address1 is NULL',16,1);
				END

            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.member (NOLOCK)
                            WHERE   member_id = @p_member_id )
							BEGIN
							SET @error_code=308
                RAISERROR('Member does not exist by member id',16,1);
				END

            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.address (NOLOCK)
                            WHERE   subsys_code = 'MB'
                                    AND sys_rec_id = @p_member_id
                                    AND addr_type = 'L' )
                BEGIN
                    IF @n_zip = 1
                        BEGIN
                            IF LEN(@p_zip) > 5
                                SET @d_zip = SUBSTRING(@p_zip, 1, 5);
                            ELSE
                                SET @d_zip = @p_zip;
		
                            SET @SWV_cursor_var1 = CURSOR  FOR SELECT city, county, state_code
			
            FROM dbo.usa_zip (NOLOCK)
            WHERE zip_code = @d_zip;
                            OPEN @SWV_cursor_var1;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @d_city,
                                @d_county, @d_state;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    IF @d_city = @p_city
                                        GOTO SWL_Label2;
                                    FETCH NEXT FROM @SWV_cursor_var1 INTO @d_city,
                                        @d_county, @d_state;
 END;
                            SWL_Label2:
                            CLOSE @SWV_cursor_var1;
                            IF ( (@d_city IS NULL
                                 OR @d_city = '')
                               )
                                OR ( (@d_county IS NULL
                                     OR @d_county = '')
                                   )
                                OR ( (@d_state IS NULL
                                     OR @d_state = '')
                                   )
                                BEGIN
								SET @error_code=309
                                    RAISERROR('Member address Zip is not recognized by DataDental',0,1);
                                    SET @d_city = @p_city;
                                    SET @d_county = NULL;
                                    SET @d_state = @p_state;
                                    SET @n_mail = 'Y';
                                END;
                        END;
                    ELSE
                        BEGIN
                            SET @d_city = @p_city;
                            SET @d_county = NULL;
                            SET @d_state = @p_state;
                        END;
	
                    INSERT  INTO dbo.address
                            ( subsys_code ,
                              sys_rec_id ,
                              addr_type ,
                              addr1 ,
                              addr2 ,
                              city ,
                              country ,
                              county ,
                              state ,
                              zip ,
                              mail
                            )
                    VALUES  ( 'MB' ,
                              @p_member_id ,
                              'L' ,
                              @p_addr1 ,
                              @p_addr2 ,
                              @d_city ,
                              'USA' ,
                              @d_county ,
                              @d_state ,
                              @p_zip ,
                              @n_mail
                            );
                END;

            SELECT  @d_address_id = address_id
            FROM    dbo.address (NOLOCK)
            WHERE   subsys_code = 'MB'
                    AND sys_rec_id = @p_member_id
                    AND addr_type = 'L';
           
            IF @d_address_id IS NULL
			BEGIN
			SET @error_code=604
                RAISERROR('Failed to retrieve DB updates',16,1);
			END

            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.mbr_phone (NOLOCK)
                            WHERE   address_id = @d_address_id )
                INSERT  INTO dbo.mbr_phone
                        ( address_id ,
                          home_phone ,
                          home_ext ,
                          work_phone ,
                          work_ext
                        )
                VALUES  ( @d_address_id ,
                          @p_home_phone ,
                          @p_home_ext ,
                          @p_work_phone ,
                          @p_work_ext
                        );


--trace off;

            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_code = ERROR_NUMBER();
            --SET @n_return_code = ERROR_LINE();
			SET @n_return_code = @error_code;
			RETURN -@n_return_code;
			
            --SET @n_error_desc = ERROR_MESSAGE();
            --SELECT  @d_severity = severity
            --FROM    dbo.dl_sp_error (NOLOCK)
            --WHERE   sp_id = @i_sp_id
            --        AND error_no = @n_return_code;
           
            --IF @d_severity = 'F'
                --RETURN -@n_return_code;
        END CATCH;
        SET NOCOUNT OFF;


--set debug file to "/tmp/dlp_mbaddr.trc";
--trace on;

    END;