﻿CREATE PROCEDURE [dbo].[dlp_add_sg_plan]
    @ad_sub_eff_gr_pl DATE ,
    @ai_sub_plan_id INT ,
    @ai_master_sg_id INT ,
    @ai_group_id INT ,
    @as_h_user CHAR(15) ,
    @ad_h_datetime DATETIME ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:01:01 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;   
        DECLARE @i_isam_error INT;  
        DECLARE @s_error_text VARCHAR(64);  

        DECLARE @i_rel_gppl_id INT;
        DECLARE @s_gp_rate_code CHAR(2);
        DECLARE @i_method INT;
        DECLARE @i_age_lb INT;
        DECLARE @i_age_ub INT;
        DECLARE @dc_prm_amt MONEY;
        DECLARE @s_cap_dol_pct CHAR(1);
        DECLARE @dc_cap_dol MONEY;
        DECLARE @dc_cap_pct DECIMAL(6, 2);

        DECLARE @rec_count INT;
        DECLARE @ielig_opt INT;
        DECLARE @ielig_opt_bill INT;
        DECLARE @ielig_opt_cap INT;

        DECLARE @i_gppl_cat_id INT;
        DECLARE @ms_i_rel_gppl_id INT;
        DECLARE @ms_i_gppl_cat_id INT;
        DECLARE @ms_s_cat_name CHAR(50);
        DECLARE @ms_i_wait_period INT;
        DECLARE @ms_s_list_name CHAR(50);

        DECLARE @i_gppl_benfit_id INT;
        DECLARE @ms_i_gppl_ben_id INT;
        DECLARE @ms_s_benefit_cat CHAR(50);
        DECLARE @ms_i_benefit_per INT;

/*--------------------------------------------------------------------
   Handle WARNING & NON FATAL ERROR:
---------------------------------------------------------------------*/
        SET NOCOUNT ON;
        BEGIN TRY
            SET LOCK_TIMEOUT -1;
            BEGIN
                BEGIN TRY
                    SELECT  @ms_i_rel_gppl_id = rel_gppl_id ,
                            @ielig_opt = elig_opt ,
                            @ielig_opt_bill = elig_opt_dtl_bill ,
                            @ielig_opt_cap = elig_opt_dtl_cap
                    FROM    dbo.rel_gppl (NOLOCK)
                    WHERE   group_id = @ai_master_sg_id
                            AND plan_id = @ai_sub_plan_id
                            AND exp_date IS NULL;
                    IF @@rowcount = 0
                        SELECT  @ms_i_rel_gppl_id = NULL ,
                                @ielig_opt = NULL ,
                                @ielig_opt_bill = NULL ,
                                @ielig_opt_cap = NULL;
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rel_gppl (NOLOCK)
                                    WHERE   group_id = @ai_group_id
                                            AND plan_id = @ai_sub_plan_id )
                        INSERT  INTO dbo.rel_gppl
                                ( group_id ,
                                  plan_id ,
                                  eff_date ,
                                  exp_date ,
                                  h_datetime ,
                                  h_user ,
                                  elig_opt ,
                                  elig_opt_dtl_bill ,
                                  elig_opt_dtl_cap
                                )
                        VALUES  ( @ai_group_id ,
                                  @ai_sub_plan_id ,
                                  @ad_sub_eff_gr_pl ,
                                  NULL ,
                                  @ad_h_datetime ,
                                  @as_h_user ,
                                  @ielig_opt ,
                                  @ielig_opt_bill ,
                                  @ielig_opt_cap
                                );
	
 SELECT  @i_rel_gppl_id = rel_gppl_id
                    FROM    dbo.rel_gppl (NOLOCK)
                    WHERE   group_id = @ai_group_id
                            AND plan_id = @ai_sub_plan_id;
                    IF @@rowcount = 0
                        SELECT  @i_rel_gppl_id = NULL;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
                    RAISERROR('Failed to insert Group Plan record.',16,1);
                END CATCH;
            END;
            BEGIN
	
	/* Next 3 lines removed- was creating duplicate entries category
		when MS had category change and SG eff date fell before date change * /
	/ * $$ks12-21-2000
			or 
				(eff_date > ad_sub_eff_gr_pl and
				(exp_date > eff_date or exp_date is null)))
	*/
		
                DECLARE @SWV_cursor_var1 CURSOR;
                DECLARE @SWV_cursor_var2 CURSOR;
                BEGIN TRY
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT gppl_cat_id, cat_name, waiting_period
        	
            FROM   dbo.gppl_cat (NOLOCK)
            WHERE  rel_gppl_id = @ms_i_rel_gppl_id
            AND ((eff_date <= @ad_sub_eff_gr_pl AND
			(exp_date > @ad_sub_eff_gr_pl OR exp_date IS NULL)));
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @ms_i_gppl_cat_id,
                        @ms_s_cat_name, @ms_i_wait_period;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            INSERT  INTO dbo.gppl_cat
                                    ( rel_gppl_id ,
                                      cat_name ,
                                      waiting_period ,
                                      eff_date ,
                                      exp_date
                                    )
                            VALUES  ( @i_rel_gppl_id ,
                                      @ms_s_cat_name ,
                                      @ms_i_wait_period ,
                                      @ad_sub_eff_gr_pl ,
                                      NULL
                                    );
		
                            SELECT  @i_gppl_cat_id = gppl_cat_id
                            FROM    dbo.gppl_cat (NOLOCK)
                            WHERE   rel_gppl_id = @i_rel_gppl_id
                                    AND cat_name = @ms_s_cat_name
                                    AND eff_date = @ad_sub_eff_gr_pl;
                            IF @@rowcount = 0
                                SELECT  @i_gppl_cat_id = NULL;
                            SET @SWV_cursor_var2 = CURSOR  FOR SELECT list_name
			
               FROM dbo.gppl_cat_d (NOLOCK)
               WHERE gppl_cat_id = @ms_i_gppl_cat_id;
                            OPEN @SWV_cursor_var2;
                            FETCH NEXT FROM @SWV_cursor_var2 INTO @ms_s_list_name;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    INSERT  INTO dbo.gppl_cat_d
                                            ( gppl_cat_id ,
                                              list_name ,
                                              eff_date ,
                                              exp_date
                                            )
                                    VALUES  ( @i_gppl_cat_id ,
                                              @ms_s_list_name ,
                                              @ad_sub_eff_gr_pl ,
                                              NULL
                                            );
                                    FETCH NEXT FROM @SWV_cursor_var2 INTO @ms_s_list_name;
                                END;
                            CLOSE @SWV_cursor_var2;
           FETCH NEXT FROM @SWV_cursor_var1 INTO @ms_i_gppl_cat_id,
                                @ms_s_cat_name, @ms_i_wait_period;
                        END;
                    CLOSE @SWV_cursor_var1;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
                    RAISERROR('Failed to insert Group Plan Category record.',16,1);
                END CATCH;
            END;
            BEGIN
	
	/* Next 3 lines removed- was creating duplicate entries for rate codes
		when MS had rate change and SG eff date fell before date change * /
	/ * $$ks12-21-2000
			or 
				(eff_date > ad_sub_eff_gr_pl and
				(exp_date > eff_date or exp_date is null)))
	*/

                DECLARE @SWV_cursor_var3 CURSOR;
                BEGIN TRY
                    SET @SWV_cursor_var3 = CURSOR  FOR SELECT rate_code, method, age_lb, age_ub, prm_amt,
			cap_dol_pct, cap_dol, cap_pct
	
            FROM dbo.rel_gppl rel (NOLOCK), dbo.group_cap_rate gcr (NOLOCK)
            WHERE rel.rel_gppl_id = gcr.rel_gppl_id AND
            gcr.group_id = @ai_master_sg_id AND
            gcr.plan_id = @ai_sub_plan_id AND
		(gcr.eff_date <= @ad_sub_eff_gr_pl) AND
		(gcr.exp_date > @ad_sub_eff_gr_pl OR gcr.exp_date IS NULL) AND
		(rel.eff_date <= @ad_sub_eff_gr_pl) AND
		(rel.exp_date > @ad_sub_eff_gr_pl OR rel.exp_date IS NULL);
                    OPEN @SWV_cursor_var3;
                    FETCH NEXT FROM @SWV_cursor_var3 INTO @s_gp_rate_code,
                        @i_method, @i_age_lb, @i_age_ub, @dc_prm_amt,
                        @s_cap_dol_pct, @dc_cap_dol, @dc_cap_pct;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            INSERT  INTO dbo.group_cap_rate
                                    ( rel_gppl_id ,
                                      group_id ,
                                      plan_id ,
                                      rate_code ,
                                      method ,
                                      age_lb ,
                                      age_ub ,
                                      prm_amt ,
                                      cap_dol_pct ,
                                      cap_dol ,
                                      cap_pct ,
                                      eff_date ,
                                      exp_date ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @i_rel_gppl_id ,
                                      @ai_group_id ,
                                      @ai_sub_plan_id ,
                                      @s_gp_rate_code ,
                                      @i_method ,
                                      @i_age_lb ,
                                      @i_age_ub ,
                                      @dc_prm_amt ,
                                      @s_cap_dol_pct ,
                                      @dc_cap_dol ,
                                      @dc_cap_pct ,
                                      @ad_sub_eff_gr_pl ,
                                      NULL ,
                                      @ad_h_datetime ,
                                      @as_h_user
                                    );
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @s_gp_rate_code,
                                @i_method, @i_age_lb, @i_age_ub, @dc_prm_amt,
                                @s_cap_dol_pct, @dc_cap_dol, @dc_cap_pct;
                        END;
                    CLOSE @SWV_cursor_var3;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
        SET @s_error_text = ERROR_MESSAGE();
                    RAISERROR('Failed to insert Group Cap Rate record.',16,1);
                END CATCH;


--	Anil. 05/18/01. QA-31908.
--	Duplicate records are inserted in group_cap_rate for SG. Added
--	rel_gppl table to the SQL below.

            END;
            BEGIN
                DECLARE @SWV_cursor_var4 CURSOR;
                DECLARE @SWV_cursor_var5 CURSOR;
                BEGIN TRY
                    SET @SWV_cursor_var4 = CURSOR  FOR SELECT gppl_benefit_id, benefit_category, benefit_period
			
            FROM   dbo.gppl_benefit (NOLOCK)
            WHERE  rel_gppl_id = @ms_i_rel_gppl_id
            AND ((eff_date <= @ad_sub_eff_gr_pl AND
			(exp_date > @ad_sub_eff_gr_pl OR exp_date IS NULL)));
                    OPEN @SWV_cursor_var4;
                    FETCH NEXT FROM @SWV_cursor_var4 INTO @ms_i_gppl_ben_id,
                        @ms_s_benefit_cat, @ms_i_benefit_per;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            INSERT  INTO dbo.gppl_benefit
                                    ( rel_gppl_id ,
                                      benefit_category ,
                                      benefit_period ,
                                      eff_date ,
                                      exp_date
                                    )
                            VALUES  ( @i_rel_gppl_id ,
                                      @ms_s_benefit_cat ,
                                      @ms_i_benefit_per ,
                                      @ad_sub_eff_gr_pl ,
                                      NULL
                                    );
		
                            SELECT  @i_gppl_benfit_id = gppl_benefit_id
                            FROM    dbo.gppl_benefit (NOLOCK)
                            WHERE   rel_gppl_id = @i_rel_gppl_id
                                    AND benefit_category = @ms_s_benefit_cat
                                    AND eff_date = @ad_sub_eff_gr_pl;
                            IF @@rowcount = 0
                                SELECT  @i_gppl_benfit_id = NULL;
                            SET @SWV_cursor_var5 = CURSOR  FOR SELECT list_name
		
               FROM #gppl_benefit_d
               WHERE gppl_benefit_id = @ms_i_gppl_ben_id;
                            OPEN @SWV_cursor_var5;
                            FETCH NEXT FROM @SWV_cursor_var5 INTO @ms_s_list_name;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    INSERT  INTO #gppl_benefit_d
                                            ( gppl_benefit_id ,
                                              list_name ,
                                              eff_date ,
                                              exp_date
                                            )
                                    VALUES  ( @i_gppl_benfit_id ,
                                              @ms_s_list_name ,
                                              @ad_sub_eff_gr_pl ,
                                              NULL
                                            );
                                    FETCH NEXT FROM @SWV_cursor_var5 INTO @ms_s_list_name;
                                END;
                            CLOSE @SWV_cursor_var5;
                            FETCH NEXT FROM @SWV_cursor_var4 INTO @ms_i_gppl_ben_id,
                                @ms_s_benefit_cat, @ms_i_benefit_per;
                        END;
                    CLOSE @SWV_cursor_var4;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
                    RAISERROR('Failed to insert Group Plan Next Benefit record.',16,1);
                END CATCH;
            END;
            SET @SWP_Ret_Value = @i_rel_gppl_id;
            SET @SWP_Ret_Value1 = 'Group Plan is added.';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = @i_error_no;
            SET @SWP_Ret_Value1 = @s_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;