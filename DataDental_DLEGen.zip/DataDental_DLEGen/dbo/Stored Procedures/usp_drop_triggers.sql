﻿CREATE PROCEDURE [dbo].[usp_drop_triggers]
AS
BEGIN

DECLARE @query NVARCHAR(MAX)=N''

SELECT @query+=N'DROP TRIGGER [dbo].['+ name+']'+CHAR(10)
FROM sys.triggers (nolock)

EXEC (@query)

END