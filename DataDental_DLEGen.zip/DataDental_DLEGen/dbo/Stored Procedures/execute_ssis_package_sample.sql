﻿CREATE procedure [dbo].[execute_ssis_package_sample]
@a_batch_id INT ,
@a_db_name CHAR(128) ,
@a_start_time char(22)
as
begin
	Declare @execution_id bigint
		 
	EXEC [SSISDB].[catalog].[create_execution] @package_name=N'pkgDL_Actlog.dtsx', @folder_name=N'DataLoad', @project_name=N'prjData_Load', @use32bitruntime=0, @execution_id=@execution_id OUTPUT --@reference_id=1 ,
 
	EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=30, @parameter_name=N'prBatchid', @parameter_value=@a_batch_id 
	EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=30, @parameter_name=N'prDB_Name', @parameter_value=@a_db_name 
	EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id,  @object_type=30, @parameter_name=N'prstart_time', @parameter_value=@a_start_time 

	EXEC [SSISDB].[catalog].[start_execution] @execution_id  
end