﻿
CREATE PROCEDURE  [dbo].[usp_ecl_MassClaimSearch]
@SearchParam VARCHAR(max),
@PageSize INT,
@SkipRows INT,
@TotalRows INT OUTPUT
AS
BEGIN
	
	DECLARE @selectCount NVARCHAR(max),
			@COUNT INT
	
	DECLARE @QUERY VARCHAR(MAX)=
			'SELECT eclaim_id					    AS EclaimId, 
					status							AS Status, 
					RTRIM(LTRIM(error_code))		AS ErrorCode, 
					RTRIM(LTRIM(alt_id))			AS AltId, 
                    RTRIM(LTRIM(document_no))		AS DocNo, 
					RTRIM(LTRIM(received_date))		AS ReceivedDate, 
					RTRIM(LTRIM(file_name))			AS FileName, 
					dls_batch_id					AS BatchId, 
					RTRIM(LTRIM(pat_f_name))		AS PatientFirstName, 
					RTRIM(LTRIM(pat_mi))			AS PatientMidName, 
					RTRIM(LTRIM(pat_l_name))		AS PatientLastName, 
					RTRIM(LTRIM(pat_tax_id))		AS PatientSSN, 
					RTRIM(LTRIM(pat_alt_id))		AS PatientAltId, 
                    RTRIM(LTRIM(pat_source_id))		AS PatientSourceId, 
					RTRIM(LTRIM(pat_addr1))			AS PatientAddress1, 
					RTRIM(LTRIM(pat_addr2))			AS PatientAddress2, 
					RTRIM(LTRIM(pat_city))			AS PatientCity, 
                    RTRIM(LTRIM(pat_state))			AS PatientState, 
					RTRIM(LTRIM(pat_zip))			AS PatientZip, 
					RTRIM(LTRIM(pat_country))		AS PatientCountry, 
					RTRIM(LTRIM(patient_id))		AS PatientMemberId, 
                    RTRIM(LTRIM(pcp_name))			AS PCP, 
					RTRIM(LTRIM(pcp_np_id))			AS PCPNPId, 
					RTRIM(LTRIM(pcp_alt_id))		AS PCPAltId, 
					RTRIM(LTRIM(pcp_id))			AS PatientFacilityId, 
                    RTRIM(LTRIM(sub_f_name))		AS SubFirstName,
					RTRIM(LTRIM(sub_mi))			AS SubMidName, 
					RTRIM(LTRIM(sub_l_name))		AS SubLastName, 
					RTRIM(LTRIM(sub_tax_id))		AS SubSSN, 
					RTRIM(LTRIM(sub_alt_id))		AS SubAltId,
					RTRIM(LTRIM(sub_source_id))		AS SubSourceId,
					RTRIM(LTRIM(sub_addr1))			AS SubAddress1, 
					RTRIM(LTRIM(sub_addr2))			AS SubAddress2, 
                    RTRIM(LTRIM(sub_city))			AS SubCity, 
					RTRIM(LTRIM(sub_state))			AS SubState, 
					RTRIM(LTRIM(sub_zip))			AS SubZip, 
					RTRIM(LTRIM(sub_country))		AS SubCountry, 
					RTRIM(LTRIM(subscriber_id))		AS SubMemberId, 
					RTRIM(LTRIM(group_alt_id))		AS GroupAltId, 
					RTRIM(LTRIM(group_name))		AS GroupName, 
					RTRIM(LTRIM(group_id))			AS GroupId, 
                    RTRIM(LTRIM(plan_dsp_name))		AS PlanName, 
					RTRIM(LTRIM(plan_id))			AS PlanId, 
					RTRIM(LTRIM(ins_type))			AS InsType, 
					RTRIM(LTRIM(plan_type))			AS PlanType, 
                    RTRIM(LTRIM(pv_np_id))			AS ProviderNPId, 
					RTRIM(LTRIM(pv_alt_id))			AS ProviderAltId, 
					RTRIM(LTRIM(pv_f_name))			AS ProviderFirstName, 
					RTRIM(LTRIM(pv_mi))				AS ProviderMidName, 
					RTRIM(LTRIM(pv_l_name))			AS ProviderLastName,
					RTRIM(LTRIM(pv_tax_id))			AS ProviderTaxId, 
					RTRIM(LTRIM(pv_addr1))			AS ProviderAddress1,
                    RTRIM(LTRIM(pv_addr2))			AS ProviderAddress2, 
					RTRIM(LTRIM(pv_city))			AS ProviderCity, 
					RTRIM(LTRIM(pv_state))			AS ProviderState, 
					RTRIM(LTRIM(pv_zip))			AS ProviderZip, 
					RTRIM(LTRIM(pv_country))		AS ProviderCountry, 
					RTRIM(LTRIM(pv_lic_state))		AS LicensingState, 
					RTRIM(LTRIM(pv_id))				AS ProviderId, 
					RTRIM(LTRIM(contr_fc_name))		AS ContrFacilityName, 
					RTRIM(LTRIM(contr_fc_np_id))	AS ContrNPId, 
					RTRIM(LTRIM(contr_fc_alt_id))	AS ContrAltId, 
					RTRIM(LTRIM(contr_fc_id))		AS ContrFacilityId, 
                    RTRIM(LTRIM(x_rays_rqd))		AS XRayRequired, 
					RTRIM(LTRIM(emergency_switch))	AS EmergencySwitch, 
					RTRIM(LTRIM(preauth_switch))	AS PreAuthSwitch, 
                    RTRIM(LTRIM(pay_prv_switch))	AS PayPrvSwitch, 
					RTRIM(LTRIM(special_deal_flg))	AS SpecialDeal, 
					RTRIM(LTRIM(hmo_claim_type))	AS HMOClaimType, 
                    RTRIM(LTRIM(speciality_type))	AS SpecialityType,
					RTRIM(LTRIM(remarks))			AS Remarks,
					RTRIM(LTRIM(ud_1))				AS UD1, 
					RTRIM(LTRIM(ud_2))				AS UD2, 
                    RTRIM(LTRIM(ud_3))				AS UD3,
					RTRIM(LTRIM(ud_4))				AS UD4,
					RTRIM(LTRIM(ud_5))				AS UD5, 
					RTRIM(LTRIM(config_name))		AS DloadConfigName,
					RTRIM(LTRIM(dls_status))		AS DataLoadStatus,
					dds_claim_id					AS DataDentalId,
					sync_status						AS SyncStatus,
					convert(varchar(12),sync_dt ,101)	AS SyncDate
					FROM eclaim_h 
					WHERE '+@SearchParam 
		
		SET  @QUERY = @QUERY+'			
		ORDER BY eclaim_id
		OFFSET '+CAST(@SkipRows AS varchar)+' ROWS
		FETCH NEXT '+CAST(@PageSize AS varchar)+' ROWS ONLY OPTION (RECOMPILE);'
	    exec (@QUERY)
		SET @selectCount =' SELECT @count = COUNT(eclaim_id) FROM eclaim_h WHERE '+@SearchParam 
		EXECUTE sp_executesql @selectCount, N'@count int OUTPUT',@count=@COUNT output
		SET @TotalRows = @COUNT 
END