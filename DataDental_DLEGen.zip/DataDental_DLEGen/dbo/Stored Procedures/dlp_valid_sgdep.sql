﻿CREATE PROCEDURE [dbo].[dlp_valid_sgdep]
    @a_batch_id INT ,
    @a_sub_id INT ,
    @a_msg_id INT ,
    @a_group_id INT ,
    @a_plan_id INT ,
    @a_action_code CHAR(2) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(2) = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT ,
    @SWP_Ret_Value4 INT = NULL OUTPUT ,
    @SWP_Ret_Value5 INT = NULL OUTPUT ,
    @SWP_Ret_Value6 INT = NULL OUTPUT ,
    @SWP_Ret_Value7 INT = NULL OUTPUT ,
    @SWP_Ret_Value8 INT = NULL OUTPUT ,
    @SWP_Ret_Value9 DATE = NULL OUTPUT ,
    @SWP_Ret_Value10 DATE = NULL OUTPUT ,
    @SWP_Ret_Value11 DATE = NULL OUTPUT ,
    @SWP_Ret_Value12 CHAR(2) = NULL OUTPUT
    
 
/* 20121005$$ks - split up valid_sg so that subscriber is processed by dlp_valid_sg
 *    and dependents are processed by dlp_valid_sgdep
 * The original dlp_valid_sg was Overkill when dealing with the dependents
 * We already know who our subscriber is, we can verify that the dependent does not
 * belong to a different subscriber by alt_id but otherwise we should rely on the
 * Sub values in the subscriber record
 * /

/ * error variable */
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:25:25 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;





        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);

        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @n_error_count INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @d_int_test INT;
        DECLARE @mb_count INT;
        DECLARE @sub_count INT;
        DECLARE @dep_count INT;
        DECLARE @gp_count INT;
        DECLARE @n_g1 INT;
        DECLARE @n_g2 INT;
        DECLARE @n_g4 INT;
        DECLARE @has_producer CHAR(1);
        DECLARE @ls_mid_month CHAR(1);
        DECLARE @i_elig_opt SMALLINT;

        DECLARE @dds_last_name VARCHAR(15);
        DECLARE @dds_first_name VARCHAR(15);
        DECLARE @dds_middle_init CHAR(1);
        DECLARE @dds_name_prefix CHAR(5);
        DECLARE @dds_name_suffix CHAR(5);
        DECLARE @dds_date_of_birth DATE;
        DECLARE @d_last_name VARCHAR(15);
        DECLARE @d_first_name VARCHAR(15);
        DECLARE @d_date_of_birth DATE;

        DECLARE @d_msg_id INT;
        DECLARE @d_bill_type CHAR(2);
        DECLARE @d_gp_state CHAR(2);
        DECLARE @d_mbgrpl_id INT;
        DECLARE @d_ins_opt CHAR(3);
        DECLARE @d_ins_type CHAR(2);
        DECLARE @d_net_id INT;
        DECLARE @d_netfc_id INT;
        DECLARE @d_ovr_ride CHAR(1);
        DECLARE @d_netfc_eff DATE;
        DECLARE @d_netfc_exp DATE;
        DECLARE @d_np_id INT;
        DECLARE @d_np_eff DATE;
        DECLARE @d_np_exp DATE;
        DECLARE @d_zip_id INT;
        DECLARE @d_city CHAR(30);
        DECLARE @d_state CHAR(2);
        DECLARE @d_county CHAR(30);
        DECLARE @d_mb_age INT;
        DECLARE @d_fc_state CHAR(2);
        DECLARE @d_comm_scheme_id INT;
        DECLARE @fcpl_nnm_date DATE;
        DECLARE @fcpl_eff_date DATE;
        DECLARE @fcpl_exp_date DATE;
        DECLARE @as_sub_id INT;
        DECLARE @as_mb_id INT;
        DECLARE @as_msg_id INT;
        DECLARE @as_gp_id INT;
        DECLARE @as_pl_id INT;
        DECLARE @as_fc_id INT;
        DECLARE @as_gpplrt_eff DATE;
        DECLARE @as_fc_eff DATE;
        DECLARE @as_term_date DATE;
 DECLARE @as_pd_id INT;
        DECLARE @as_pdcomm_eff DATE;
        DECLARE @as_action_code CHAR(2);
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_eff_rt_date DATE;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @temp_action_code CHAR(2);
        DECLARE @t_member_id INT;
        DECLARE @t_alt_id CHAR(20);
        DECLARE @sg_sp_id INT
	DECLARE @sg_sir_def_id INT
	DECLARE @sg_sir_def_name varchar(14)
	DECLARE @sg_proc_name varchar(14)
	DECLARE @sg_config_id INT
	DECLARE @n_has_facility_id char(1)
	DECLARE @n_multiple_plans char(1)
	DECLARE @n_allow_pl_change char(1)
	DECLARE @n_multiple_fc char(1)
	DECLARE @n_allow_fc_change char(1)
	DECLARE @n_def_eff_date char(10)
	DECLARE @n_def_exp_date char(10)
	DECLARE @n_has_term_date char(1)
	DECLARE @d_def_eff_date date
	DECLARE @d_def_exp_date date
	DECLARE @s_dls_sir_id INT
	DECLARE @s_dls_sub_sir_id INT
	DECLARE @s_member_flag char(2)
	DECLARE @s_alt_id char(20)
	DECLARE @s_ssn char(11)
	DECLARE @s_sub_ssn char(11)
	DECLARE @s_sub_alt_id char(20)
	DECLARE @s_member_code char(3)
	DECLARE @s_last_name char(15)
	DECLARE @s_first_name char(15)
	DECLARE @s_middle_init char(1)
	DECLARE @s_name_prefix char(5)
	DECLARE @s_name_suffix char(5)
	DECLARE @s_date_of_birth char(10)
	DECLARE @s_student_flag char(1)
	DECLARE @s_disable_flag char(1)
	DECLARE @s_cobra_flag char(1)
	DECLARE @s_msg_group_id INT
	DECLARE @s_plan_id INT
	DECLARE @s_facility_id INT
	DECLARE @s_rate_code char(2)
	DECLARE @s_mb_gppl_eff_date char(10)
	DECLARE @s_mb_fc_eff_date char(10)
	DECLARE @s_mb_term_date char(10)
	DECLARE @s_bank_account char(25)
	DECLARE @s_account_type char(2)
	DECLARE @s_trans_rt_nbr char(9)
	DECLARE @s_transaction_code char(2)
	DECLARE @s_address1 char(30)
	DECLARE @s_address2 char(30)
	DECLARE @s_city char(30)
	DECLARE @s_state char(2)
	DECLARE @s_zip char(5)
	DECLARE @s_zipx char(4)
	DECLARE @s_home_phone char(10)
	DECLARE @s_home_ext char(5)
	DECLARE @s_work_phone char(10)
	DECLARE @s_work_ext char(5)
	DECLARE @s_email char(250)
	DECLARE @s_producer_id INT
	DECLARE @s_comm_scheme_id char(5)
	DECLARE @s_pd_type char(2)
	DECLARE @s_license_number char(9)
	DECLARE @s_selling_period char(1)
	DECLARE @s_pdcomm_eff_date char(10)
	DECLARE @t_new_ssn char(11)
	DECLARE @t_src_id char(20)
	DECLARE @t_subnew_ssn char(11)
	DECLARE @t_subsrc_id char(20)
	DECLARE @t_ext_id_col char(20)
	DECLARE @n_ffs_plan INT
	DECLARE @s_msg_group_alt_id char(20)
	DECLARE @s_plan_dsp_name char(30)
	DECLARE @s_facility_alt_id char(20)
	DECLARE @s_producer_alt_id char(20)
	DECLARE @from_api smallint
	DECLARE @api_mbr_id INT
	DECLARE @api_sub_id INT
	DECLARE @api_plan_id INT
	DECLARE @api_fc_id INT
	DECLARE @api_msg_id INT
	DECLARE @api_grp_id INT

        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;
        DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @SWV_cursor_var4 CURSOR;

        SET NOCOUNT ON;
        SET @sg_sp_id = 0 
    
        SET @sg_sir_def_id = 0 
     
        SET @sg_sir_def_name = '' 
       
        SET @sg_proc_name = '' 
  
        SET @sg_config_id = 0 
      
        SET @n_has_facility_id = '' 
       
        SET @n_multiple_plans = '' 
     
        SET @n_allow_pl_change = '' 
   
        SET @n_multiple_fc = '' 
   
        SET @n_allow_fc_change = '' 
      
        SET @n_def_eff_date = '' 
    
        SET @n_def_exp_date = '' 
    
        SET @n_has_term_date = '' 
 
        SET @d_def_eff_date = NULL 
     
        SET @d_def_exp_date = NULL 
     
        SET @s_dls_sir_id = 0 
  
        SET @s_dls_sub_sir_id = 0 
     
        SET @s_member_flag = '' 
      
        SET @s_alt_id = '' 
       
        SET @s_ssn = '' 
  
        SET @s_sub_ssn = '' 

        SET @s_sub_alt_id = '' 
    
        SET @s_member_code = '' 
  
        SET @s_last_name = '' 
    
 SET @s_first_name = '' 

        SET @s_middle_init = '' 
    
        SET @s_name_prefix = '' 
  
        SET @s_name_suffix = '' 

        SET @s_date_of_birth = '' 
     
        SET @s_student_flag = '' 
      
        SET @s_disable_flag = '' 

        SET @s_cobra_flag = '' 
  
        SET @s_msg_group_id = 0 

        SET @s_plan_id = 0 
    
        SET @s_facility_id = 0 
 
        SET @s_rate_code = '' 
     
        SET @s_mb_gppl_eff_date = '' 

        SET @s_mb_fc_eff_date = '' 
      
        SET @s_mb_term_date = '' 
      
        SET @s_bank_account = '' 
      
        SET @s_account_type = '' 
 
        SET @s_trans_rt_nbr = '' 
   
        SET @s_transaction_code = '' 
   
        SET @s_address1 = '' 
   
        SET @s_address2 = '' 
    
        SET @s_city = '' 
   
        SET @s_state = '' 

        SET @s_zip = '' 
      
        SET @s_zipx = '' 
     
        SET @s_home_phone = '' 
        
        SET @s_home_ext = '' 
 
        SET @s_work_phone = '' 
 
        SET @s_work_ext = '' 
     
        SET @s_email = '' 
  
        SET @s_producer_id = 0 
      
        SET @s_comm_scheme_id = '' 
   
        SET @s_pd_type = '' 
   
        SET @s_license_number = '' 
      
        SET @s_selling_period = '' 
   
        SET @s_pdcomm_eff_date = '' 
     
        SET @t_new_ssn = '' 
   
        SET @t_src_id = '' 
       
        SET @t_subnew_ssn = '' 

        SET @t_subsrc_id = '' 
       
        SET @t_ext_id_col = '' 
       
        SET @n_ffs_plan = 0 
   
        SET @s_msg_group_alt_id = '' 
        
        SET @s_plan_dsp_name = '' 
     
        SET @s_facility_alt_id = '' 
    
        SET @s_producer_alt_id = '' 
       
        SET @from_api = 0 
     
        SET @api_mbr_id = 0 

        SET @api_sub_id = 0 
      
        SET @api_plan_id = 0 
     
        SET @api_fc_id = 0 
      
        SET @api_msg_id = 0 
 
        SET @api_grp_id = 0 
 
        BEGIN TRY
            
            SET @s_error = 'N';
            SET @mb_count = 0;
            SET @sub_count = 0;
            SET @dep_count = 0;
            SET @a_error_no = 0;
	/* 20131005$$ks - set subscribers value to sub related fields 
	 */
            SET @as_sub_id = @a_sub_id;
            SET @as_msg_id = @a_msg_id;
            SET @as_gp_id = @a_group_id;
            SET @as_pl_id = @a_plan_id;
            SET @as_mb_id = NULL;
            SET @as_fc_id = NULL;
            SET @as_gpplrt_eff = NULL;
            SET @as_fc_eff = NULL;
            SET @as_term_date = NULL;
            SET @as_pd_id = NULL;
            SET @as_pdcomm_eff = NULL;
            SET @as_action_code = NULL;
            SET @temp_action_code = NULL;
            SET @has_producer = NULL;
            SET @n_g1 = 0;
            SET @n_g2 = 0;
            SET @n_g4 = 0;

			

SELECT @sg_sp_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'sg_sp_id' and  BatchId = @a_batch_id AND Module_Id = 1			
SELECT @sg_sir_def_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'sg_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @sg_sir_def_name 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'sg_sir_def_name' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @sg_proc_name 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'sg_proc_name' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @sg_config_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'sg_config_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_has_facility_id 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_facility_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_multiple_plans 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_multiple_plans' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_allow_pl_change 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_allow_pl_change' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_multiple_fc 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_multiple_fc' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_allow_fc_change 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_allow_fc_change' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_def_eff_date		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_def_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_def_exp_date		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_def_exp_date 		' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_has_term_date		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_term_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @d_def_eff_date		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'd_def_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @d_def_exp_date		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'd_def_exp_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_dls_sir_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_dls_sub_sir_id 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_member_flag 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_alt_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_ssn 				=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_sub_ssn 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_sub_alt_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_member_code 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_last_name 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_first_name 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_middle_init 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_middle_init' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_name_prefix 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_name_prefix' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_name_suffix 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_name_suffix' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_date_of_birth 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_student_flag 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_student_flag' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_disable_flag 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_cobra_flag 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_msg_group_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_msg_group_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_plan_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_facility_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_facility_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_rate_code 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_mb_gppl_eff_date 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_mb_gppl_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_mb_fc_eff_date	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_mb_term_date 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_bank_account 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_bank_account' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_account_type 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_account_type' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_trans_rt_nbr 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_trans_rt_nbr' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_transaction_code 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_transaction_code' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_address1 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_address2 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_city 				=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_city' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_state 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_state' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_zip 				=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_zipx 				=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_zipx' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_home_phone 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_home_ext 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_work_phone 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_work_ext 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_email 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_producer_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_producer_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_comm_scheme_id 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_pd_type 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_license_number	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_selling_period 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_selling_period' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_pdcomm_eff_date 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_pdcomm_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @t_new_ssn 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 't_new_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @t_src_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 't_src_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @t_subnew_ssn 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 't_subnew_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @t_subsrc_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 't_subsrc_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @t_ext_id_col 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 't_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @n_ffs_plan 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'n_ffs_plan' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_msg_group_alt_id 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_msg_group_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_plan_dsp_name 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_plan_dsp_name' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_facility_alt_id 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_facility_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @s_producer_alt_id 	=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 's_producer_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @from_api 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @api_mbr_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'api_mbr_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @api_sub_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'api_sub_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @api_plan_id 		=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'api_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @api_fc_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'api_fc_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @api_msg_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'api_msg_id' and  BatchId = @a_batch_id AND Module_Id = 1
SELECT @api_grp_id 			=VarValue	from dbo.GlobalVar(NOLOCK) where VarName = 'api_grp_id' and  BatchId = @a_batch_id AND Module_Id = 1

--select @api_mbr_id
--SELECT @from_api

/* 20131004$$ks Removed code already tested in dlp_sg_precheck
 */
            
            IF ( @s_member_flag = '00' )
                BEGIN
                    SET @s_error_descr = 'Member Flag must not be 00 to be processed by valid_sgdep';
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_error_descr;
                    SET @SWP_Ret_Value2 = @as_action_code;
                    SET @SWP_Ret_Value3 = @as_sub_id;
                    SET @SWP_Ret_Value4 = @as_mb_id;
                    SET @SWP_Ret_Value5 = @as_msg_id;
                    SET @SWP_Ret_Value6 = @as_gp_id;
                    SET @SWP_Ret_Value7 = @as_pl_id;
                    SET @SWP_Ret_Value8 = @as_fc_id;
                    SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                    SET @SWP_Ret_Value10 = @as_fc_eff;
                    SET @SWP_Ret_Value11 = @as_term_date;
                    
                    SET @SWP_Ret_Value12 = @s_rate_code;
                    RETURN;
                END;
	
            
            SET @d_date_of_birth = @s_date_of_birth 
            SET @d_mb_age = YEAR(CONVERT(DATE, GETDATE())) - YEAR(@d_date_of_birth);
            
            IF @from_api = 1
   BEGIN
  
                    SET @as_sub_id = @api_sub_id;
                    
                    SET @as_mb_id = @api_mbr_id;
                    IF @as_sub_id = 0
                        SET @sub_count = 0;
                    ELSE
                        SET @sub_count = 1;
		
                    IF @as_mb_id = 0
                        SET @mb_count = 0;
                    ELSE
                        SET @mb_count = 1;
                END;
	--select @as_mb_id
	/* 20131004$$ks CODE MOVED FROM BELOW
	 * Before looking for member lets verify that 
	 * dates, msg, plan and facility (if needed) are valid
	 */
          
            IF ( @s_mb_gppl_eff_date IS NULL
                 OR @s_mb_gppl_eff_date = ''
               )
                OR LEN(@s_mb_gppl_eff_date) = 0
				BEGIN
                RAISERROR('Tape Member Group Plan Rate Eff Date is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 52;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
				END ;
            ELSE
                BEGIN
                    SET @a_error_no = 53;
                 
                    SET @as_gpplrt_eff = @s_mb_gppl_eff_date 
                END;
	
            
            IF ( @s_mb_fc_eff_date IS NULL
                 OR @s_mb_fc_eff_date = ''
               )
                OR LEN(@s_mb_fc_eff_date) = 0
				BEGIN
                RAISERROR('Tape Member Facility Eff Date is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 62;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
            ELSE
                BEGIN
                    SET @a_error_no = 63;
               
                    SET @as_fc_eff = @s_mb_fc_eff_date 
                END;
	
            
            IF ( @s_mb_term_date IS NOT NULL
                 AND @s_mb_term_date <> ''
               )
                OR LEN(@s_mb_term_date) > 0
                BEGIN
                    SET @a_error_no = 76;
              
                    SET @as_term_date = @s_mb_term_date 
                END;
	
            
            IF @from_api = 1
                BEGIN
                    
                    SET @s_msg_group_id = @api_msg_id 
               
                    IF @api_grp_id > 0
                        BEGIN
                 
                            IF @api_msg_id = @api_grp_id
                                BEGIN
                                    SET @api_grp_id = 0 
                            
                                END;
                            ELSE
                                IF EXISTS ( SELECT  group_id
                                            FROM    dbo.[group] (NOLOCK)
                                            WHERE   group_type = 'SG'
                                                    AND group_parent = @api_msg_id
                                                    AND group_id = @api_grp_id )
                                    BEGIN
                               
                                        SET @as_gp_id = @api_grp_id;
                                    END;
				
                        END;
                END;
	
            
            IF @s_msg_group_id IS NULL
                OR @s_msg_group_id = 0
				BEGIN
                RAISERROR('Tape Master Single Group ID is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 34
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
            ELSE
                BEGIN
                
                    IF @s_msg_group_id != @a_msg_id -- sub and dep not same msg?
					begin
                        RAISERROR('Missing Master Single Group by Group ID',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 36
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
                    ELSE
                        SET @as_msg_id = @a_msg_id;
                END;
	
            
            IF @from_api = 1
                BEGIN
                    
                    SET @s_plan_id = @api_plan_id 
                    
                END;
	
            
            IF @s_plan_id IS NULL
                OR @s_plan_id = 0
				BEGIN
                RAISERROR('Tape Plan ID is missing',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 42
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
            ELSE
	-- the logic below validates the plan_id and 
	-- sets as_pl_id, d_ins_opt, d_ins_type, ls_mid_month, i_elig_opt
                BEGIN
                    
                    IF @s_plan_id != @a_plan_id
					BEGIN
                        RAISERROR('Missing Plan record by Plan ID on the tape',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 44
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
		
                    SET @a_error_no = 43;
                    SELECT  @as_pl_id = plan_id ,
                            @d_ins_opt = ins_opt ,
                            @d_ins_type = ins_type
                    FROM    dbo.[plan] (NOLOCK)
                    WHERE   plan_id = @s_plan_id;
                  
                    IF @as_pl_id IS NULL
					BEGIN
                        RAISERROR('Missing Plan record by Plan ID on the tape',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 44
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
		
                    SET @ls_mid_month = 'N';
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT b.elig_opt 
         FROM dbo.rel_gppl b  (NOLOCK)
         WHERE b.group_id = @as_msg_id
         AND b.plan_id = @as_pl_id AND exp_date IS NULL;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_elig_opt;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            IF @i_elig_opt = 0
                                BEGIN
                                    SET @ls_mid_month = 'N';
                                    GOTO SWL_Label2;
                                END;
                            ELSE
                                BEGIN
                                    SET @ls_mid_month = 'Y';
                                    GOTO SWL_Label2;
                                END;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_elig_opt;
                        END;
                    SWL_Label2:
                    CLOSE @SWV_cursor_var1;
                END;
	
            
            IF @from_api = 1
                BEGIN
                    
                    SET @s_facility_id = @api_fc_id 
                    
                END;
	
	/* since dep can be in different FC validate FC value 
	 */
            IF ( @d_ins_opt IS NOT NULL
                 AND @d_ins_opt <> ''
               )
                AND @d_ins_opt IN ( 'HMO', 'RFS' )
                BEGIN
                    
                    SET @as_fc_id = @s_facility_id;
                END;
	

            IF @ls_mid_month = 'N'
                AND ( DATEPART(DAY, @s_mb_gppl_eff_date) != 1
                      OR DATEPART(DAY, @s_mb_fc_eff_date) != 1
                    )
					BEGIN
                RAISERROR('Group/plan does not allow mid month dates',0,1);
				EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 134
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
	
            IF ( @as_fc_id IS NOT NULL
                 AND @as_fc_id > 0
               )
                BEGIN
                    IF EXISTS ( SELECT  *
       FROM    dbo.fcstat (NOLOCK)
                                WHERE   facility_id = @as_fc_id
                                        AND status = 'AC'
                                        AND eff_date > @as_fc_eff
                                        AND exp_date IS NULL )
										BEGIN
                        RAISERROR('Tape Mbr FC EffDate is before DDS FC status eff date',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 65;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
		
                    IF EXISTS ( SELECT  *
                                FROM    dbo.fcstat  (NOLOCK)
                                WHERE   facility_id = @as_fc_id
                                        AND status = 'TR'
                                        AND eff_date <= @as_fc_eff
                                        AND ( exp_date IS NULL
                                              OR @as_fc_eff < exp_date
                                            ) )
											BEGIN
                        RAISERROR('Tape Mbr FC Effective Date is in Terminate Status',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 66;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
                END;
	
/* 20131003$$ks - END of MOVED CODE
 * at this point we should have the 
 * correct as_msg_id, as_pl_id 
 * and valid group plan and fc effective dates
 */

      
            IF @api_sub_id = 0
                OR @api_mbr_id = 0
                OR @from_api = 0 --allow DL to verify new Dep
	/* will also be true if from_api = 0 */
                BEGIN
                    SET @sub_count = 0;
                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT member_id, family_id, last_name, first_name, middle_init, date_of_birth
			
         FROM dbo.member  (NOLOCK)
         WHERE alt_id = @s_alt_id AND member_id != family_id;
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @as_mb_id,
                        @as_sub_id, @dds_last_name, @dds_first_name,
                        @dds_middle_init, @dds_date_of_birth;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
						--select @mb_count
                            SET @mb_count = @mb_count + 1;
                            SET @dep_count = @dep_count + 1;
                            FETCH NEXT FROM @SWV_cursor_var2 INTO @as_mb_id,
                                @as_sub_id, @dds_last_name, @dds_first_name,
                                @dds_middle_init, @dds_date_of_birth;
                        END;
                    CLOSE @SWV_cursor_var2;

					--select @mb_count

                    IF @mb_count = 1
                        BEGIN
                     
                            IF @dds_last_name <> @s_last_name
							BEGIN
                                RAISERROR('Last Name mismatch for existing member',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 150;
							IF @i_fatal <> 1 
								SET @s_error = 'Y';
								END
			
                   
                            IF @dds_first_name <> @s_first_name
							BEGIN
                                RAISERROR('First Name mismatch for existing member',0,1);
								EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 151;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
			
                            IF @d_date_of_birth != '01/01/1900'
                                AND @d_date_of_birth <> @dds_date_of_birth
				--RAISE EXCEPTION -746, 152, "Date of Birth mismatch for existing member";
                                SET @n_g1 = 1;
                        END;
		
                    IF @mb_count > 1
                        BEGIN
                            SET @a_error_no = 5;
                            SET @mb_count = 0;
                  SET @dep_count = 0;
                            SET @SWV_cursor_var3 = CURSOR  FOR SELECT member_id, family_id 
            FROM dbo.member  (NOLOCK)
            WHERE alt_id = @s_alt_id
            AND member_id != family_id
            AND last_name = @s_last_name
            AND first_name = @s_first_name
            AND ((date_of_birth = @d_date_of_birth
            AND @d_date_of_birth != '01/01/1900'
            AND date_of_birth != '01/01/1900')
            OR (@d_date_of_birth = '01/01/1900' OR date_of_birth = '01/01/1900'));
                            OPEN @SWV_cursor_var3;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @as_mb_id,
                                @as_sub_id;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    SET @mb_count = @mb_count + 1;
                                    SET @dep_count = @dep_count + 1;
                                    FETCH NEXT FROM @SWV_cursor_var3 INTO @as_mb_id,
                                        @as_sub_id;
                                END;
                            CLOSE @SWV_cursor_var3;
                        END;
		
                    IF ( @mb_count > 1 )
                        IF @a_sub_id > 0
                            BEGIN
                                SET @as_sub_id = @a_sub_id;
                                SET @SWV_cursor_var4 = CURSOR  FOR SELECT member_id, family_id 
               FROM dbo.member  (NOLOCK)
               WHERE alt_id = @s_alt_id
               AND member_id != family_id
               AND family_id = @a_sub_id
               AND last_name = @s_last_name
               AND first_name = @s_first_name;
                                OPEN @SWV_cursor_var4;
                                FETCH NEXT FROM @SWV_cursor_var4 INTO @as_mb_id,
                                    @as_sub_id;
                                WHILE @@FETCH_STATUS = 0
                               BEGIN
                                        SET @mb_count = @mb_count + 1;
                                        SET @dep_count = @dep_count + 1;
                                        FETCH NEXT FROM @SWV_cursor_var4 INTO @as_mb_id,
                                            @as_sub_id;
                                    END;
                                CLOSE @SWV_cursor_var4;
                            END;
			
		
                    IF ( @mb_count > 1 )
					BEGIN
                        RAISERROR('Found more than one member in the database matching Alt, First + Last + DOB',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 604;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
		
                    IF @a_sub_id = 0
                        AND @mb_count = 1
						BEGIN
                        RAISERROR('Unable to identify DD Subscriber for the Dependent',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 180;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
                    ELSE
                        IF NOT EXISTS ( SELECT  *
                                        FROM    dbo.dls_sg_member  (NOLOCK)
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND member_flag = '00'
                                                AND alt_id = sub_alt_id
                                                AND alt_id = @s_sub_alt_id )
												BEGIN
                            RAISERROR('Unable to identify DD or SIR Sub for the Dependent',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 180;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
			
                END;
	 -- not from_api - get member IDs
            
            SET @d_last_name = @s_last_name;
      
            SET @d_first_name = @s_first_name;
	/* 20131026$$ks - dependent exists so action depends on what is happening with subscriber
	 *	DR, RI, FX  action for Dep is determined in bu_sg_dep
	 * DR for dep means to reinstate to active sub-gr-plan
	 * if sub action is RI then we dep action is also RI
	 */
            IF @mb_count = 1
                BEGIN
                    SET @as_gp_id = @a_group_id;
		 -- 20131026$$ks - we need to review RI code 
                    IF @a_action_code = 'PA'
                        SET @as_action_code = 'PA';
                    ELSE
                        IF @a_action_code = 'RI'
                            SET @as_action_code = 'RI';
                        ELSE
                            SET @as_action_code = 'MU';
                END;
            ELSE
                IF @mb_count = 0
                    BEGIN
                        IF ( @as_term_date IS NOT NULL )
						BEGIN
                            RAISERROR('Member Term Date should be blank if new member',0,1);
							EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 76;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
		
                        SET @as_action_code = 'DA';
		/* 20131003$$ks - Member does not exist return with pertanent info 
		 */
                        IF @s_error = 'Y'
                            BEGIN
                                SET @SWP_Ret_Value = 0;
                                SET @SWP_Ret_Value1 = NULL;
                                SET @SWP_Ret_Value2 = @as_action_code;
                                SET @SWP_Ret_Value3 = @as_sub_id;
                                SET @SWP_Ret_Value4 = @as_mb_id;
                                SET @SWP_Ret_Value5 = @as_msg_id;
                                SET @SWP_Ret_Value6 = @as_gp_id;
                                SET @SWP_Ret_Value7 = @as_pl_id;
                                SET @SWP_Ret_Value8 = @as_fc_id;
                                SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                                SET @SWP_Ret_Value10 = @as_fc_eff;
                                SET @SWP_Ret_Value11 = @as_term_date;
                            
                                SET @SWP_Ret_Value12 = @s_rate_code;
                                RETURN;
                            END;
                        ELSE
                            BEGIN
                                SET @SWP_Ret_Value = 1;
                                SET @SWP_Ret_Value1 = NULL;
                                SET @SWP_Ret_Value2 = @as_action_code;
            SET @SWP_Ret_Value3 = @as_sub_id;
                                SET @SWP_Ret_Value4 = @as_mb_id;
                                SET @SWP_Ret_Value5 = @as_msg_id;
                                SET @SWP_Ret_Value6 = @as_gp_id;
                                SET @SWP_Ret_Value7 = @as_pl_id;
                                SET @SWP_Ret_Value8 = @as_fc_id;
                                SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                                SET @SWP_Ret_Value10 = @as_fc_eff;
                                SET @SWP_Ret_Value11 = @as_term_date;
                               SET @SWP_Ret_Value12 = @s_rate_code;
                                RETURN;
                            END;
                    END;	 
	/********** Term logic *************/
            IF @as_term_date IS NOT NULL
                BEGIN
                    IF @ls_mid_month = 'N'
                        AND DATEPART(DAY, @as_term_date) != 1
						BEGIN
                        RAISERROR('Member Term Date must be 1st of month',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 135;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
						END
		
                    SET @d_mbgrpl_id = 0;
                    SELECT @d_mbgrpl_id = mb_gr_pl_id
          FROM    dbo.rlmbgrpl  (NOLOCK)
                    WHERE   member_id = @as_sub_id
                            AND group_id = @as_gp_id
                            AND plan_id = @as_pl_id
                            AND eff_gr_pl <= @as_term_date
                            AND ( exp_gr_pl IS NULL );
                   
                    IF ( @d_mbgrpl_id IS NULL
                         OR @d_mbgrpl_id = 0
                       )
                        OR EXISTS ( SELECT  *
                                    FROM    dbo.rlplfc  (NOLOCK)
                                    WHERE   mb_gr_pl_id = @d_mbgrpl_id
                                            AND facility_id = @as_fc_id
                                            AND ( @as_term_date < eff_date
                                                  OR exp_date < @as_term_date
                                                ) )
												BEGIN
                        RAISERROR('Member Term Date is not valid in current status',0,1);
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @sg_sp_id, @sg_sir_def_id, @s_dls_sir_id, 81;
				IF @i_fatal <> 1 
					SET @s_error = 'Y';
					END
		
                    SET @as_action_code = 'MT';
                END;
	
	
--trace off;
            IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = @as_action_code;
                    SET @SWP_Ret_Value3 = @as_sub_id;
                    SET @SWP_Ret_Value4 = @as_mb_id;
                    SET @SWP_Ret_Value5 = @as_msg_id;
                    SET @SWP_Ret_Value6 = @as_gp_id;
                    SET @SWP_Ret_Value7 = @as_pl_id;
                    SET @SWP_Ret_Value8 = @as_fc_id;
                    SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                    SET @SWP_Ret_Value10 = @as_fc_eff;
                    SET @SWP_Ret_Value11 = @as_term_date;
                    
                    SET @SWP_Ret_Value12 = @s_rate_code;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = NULL;
                    SET @SWP_Ret_Value2 = @as_action_code;
                    SET @SWP_Ret_Value3 = @as_sub_id;
                    SET @SWP_Ret_Value4 = @as_mb_id;
                    SET @SWP_Ret_Value5 = @as_msg_id;
                    SET @SWP_Ret_Value6 = @as_gp_id;
                    SET @SWP_Ret_Value7 = @as_pl_id;
                    SET @SWP_Ret_Value8 = @as_fc_id;
                    SET @SWP_Ret_Value9 = @as_gpplrt_eff;
                    SET @SWP_Ret_Value10 = @as_fc_eff;
                    SET @SWP_Ret_Value11 = @as_term_date;
                    
                    SET @SWP_Ret_Value12 = @s_rate_code;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
     SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            SET @SWP_Ret_Value2 = @as_action_code;
            SET @SWP_Ret_Value3 = @as_sub_id;
            SET @SWP_Ret_Value4 = @as_mb_id;
            SET @SWP_Ret_Value5 = @as_msg_id;
            SET @SWP_Ret_Value6 = @as_gp_id;
            SET @SWP_Ret_Value7 = @as_pl_id;
            SET @SWP_Ret_Value8 = @as_fc_id;
            SET @SWP_Ret_Value9 = @as_gpplrt_eff;
            SET @SWP_Ret_Value10 = @as_fc_eff;
            SET @SWP_Ret_Value11 = @as_term_date;
            
            SET @SWP_Ret_Value12 = @s_rate_code;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


--set debug file to "/tmp/dlp_valid_sgdep.trc";
--trace on;

    END;