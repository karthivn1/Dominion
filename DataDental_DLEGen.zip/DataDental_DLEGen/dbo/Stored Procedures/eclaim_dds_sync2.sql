﻿CREATE PROCEDURE [dbo].[eclaim_dds_sync2]
    @AsOfDate DATE = '1900-01-01' ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 04:48:48 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        SET NOCOUNT ON;
        IF @AsOfDate = '1900-01-01'
            SET @AsOfDate = CONVERT(DATE, GETDATE());
        SET @SWP_Ret_Value = 1;
        SET @SWP_Ret_Value1 = 'sync2 skipped';
        RETURN;
        SET NOCOUNT OFF;

    END;