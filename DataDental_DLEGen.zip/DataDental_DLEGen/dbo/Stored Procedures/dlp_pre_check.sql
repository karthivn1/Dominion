﻿CREATE PROCEDURE [dbo].[dlp_pre_check]
    @a_batch_id INT ,
    @a_sir_id INT
    

-- DATE: 12/03/96
AS
    BEGIN
/* 
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @n_pre_error CHAR(1);
        DECLARE @n_lookup_ssn_alt char(1);
		DECLARE @n_has_facility_id char(1);
		DECLARE @n_has_multiple_gp char(1);
		DECLARE @n_add_to_cl_fc char(1);
		DECLARE @n_has_rate_code char(1);
		DECLARE @n_has_address char(1);
		DECLARE @n_sub_age char(11);
		DECLARE @n_has_plan_eff char(1);
		DECLARE @n_has_fac_eff char(1);
		DECLARE @n_has_s_plan_term char(1);
		DECLARE @n_has_d_plan_term char(1);
		DECLARE @d_process_eff_dt date;
		DECLARE @d_process_exp_dt date;
		DECLARE @i_sub_age int;
		DECLARE @s_sub_age char(11);
		DECLARE @i_sp_id int;
		DECLARE @i_sir_def_id int;
		DECLARE @t_sir_id			int;
		DECLARE @t_sub_sir_id		int;
		DECLARE @t_subscriber		char(2);
		DECLARE @t_alt_id			char(20);
		DECLARE @t_sub_ssn			char(11);
		DECLARE @t_ssn				char(11);
		DECLARE @t_sub_alt_id		char(20);
		DECLARE @t_member_id		int;
		DECLARE @t_sub_id			INT;
		DECLARE @t_group_id			INT;
		DECLARE @t_member_code	char(2);
		DECLARE @t_plan_id			INT;
		DECLARE @t_facility_id		INT;
		DECLARE @t_type				char(2);
		DECLARE @t_def_key				char(2);
		DECLARE @t_last_name		char(15);
		DECLARE @t_first_name		char(15);
		DECLARE @t_middle_init		char(1);
		DECLARE @t_date_of_birth		date;
		DECLARE @t_student_flag		char(1);
		DECLARE @t_disable_flag		char(1);
		DECLARE @t_cobra_flag		char(1);
		DECLARE @t_action_code		char(2);
		DECLARE @t_address1		char(30);
		DECLARE @t_address2		char(30);
		DECLARE @t_city				char(30);
		DECLARE @t_state				char(2);
		DECLARE @t_zip				char(5);
		DECLARE @t_zipx				char(4);
		DECLARE @t_home_phone		char(10);
		DECLARE @t_home_ext		char(4);
		DECLARE @t_work_phone		char(10);
		DECLARE @t_work_ext			char(4);
		DECLARE @t_rate_code		char(2);
		DECLARE @t_plan_eff_date	date;
		DECLARE @t_plan_term_date	date;
		DECLARE @t_fac_eff_date		date;
		DECLARE @t_status			char(1);


        SET NOCOUNT ON;
        SET @n_lookup_ssn_alt = '';
        
        SET @n_has_facility_id = '';
        
        SET @n_has_multiple_gp = '';
        
        SET @n_add_to_cl_fc = '';
        
        SET @n_has_rate_code = '';
        
        SET @n_has_address = '';
        
        SET @n_sub_age = '';
        
        SET @n_has_plan_eff = '';
        
        SET @n_has_fac_eff = '';
        
        SET @n_has_s_plan_term = '';
        
        SET @n_has_d_plan_term = '';
        
        SET @d_process_eff_dt = NULL;
        
        SET @d_process_exp_dt = NULL;
        
        SET @i_sub_age = 0;
        
        SET @s_sub_age = '';
        
        SET @i_sp_id = 0;
        
        SET @i_sir_def_id = 0;
        
        SET @t_sir_id = 0;
        
        SET @t_sub_sir_id = 0;
        
        SET @t_subscriber = '';
        
        SET @t_alt_id = '';
        
        SET @t_sub_ssn = '';
        
        SET @t_ssn = '';
        
        SET @t_sub_alt_id = '';
        
        SET @t_member_id = 0;
        
        SET @t_sub_id = 0;
        
        SET @t_group_id = 0;
        
        SET @t_member_code = '';
        
        SET @t_plan_id = 0;
        
        SET @t_facility_id = 0;
        
        SET @t_type = '';
        
        SET @t_def_key = '';
        
        SET @t_last_name = '';
        
        SET @t_first_name = '';
        
        SET @t_middle_init = '';
        
        SET @t_date_of_birth = NULL;
        
        SET @t_student_flag = '';
        
        SET @t_disable_flag = '';
        
        SET @t_cobra_flag = '';
        
        SET @t_action_code = '';
        
        SET @t_address1 = '';
        
        SET @t_address2 = '';
        
        SET @t_city = '';
        
        SET @t_state = '';
        
        SET @t_zip = '';
        
        SET @t_zipx = '';
        
        SET @t_home_phone = '';
        
        SET @t_home_ext = '';
        
        SET @t_work_phone = '';
        
        SET @t_work_ext = '';
        
        SET @t_rate_code = '';
        
        SET @t_plan_eff_date = NULL;
        
        SET @t_plan_term_date = NULL;
        
        SET @t_fac_eff_date = NULL;
        
        SET @t_status = '';
        
        BEGIN TRY
			SELECT @n_lookup_ssn_alt = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_lookup_ssn_alt' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_sub_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_plan_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_plan_term_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_fac_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_facility_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_def_key = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_def_key' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @t_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 3
			select @i_sir_def_id = VarValue from GlobalVar(NOLOCK) where  VarName = 'i_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @i_sp_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'i_sp_id' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @n_has_plan_eff = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_plan_eff' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @n_has_d_plan_term = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_d_plan_term' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @n_has_s_plan_term = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_s_plan_term' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @n_has_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
			SELECT @n_has_fac_eff = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_has_fac_eff' and  BatchId = @a_batch_id AND Module_Id = 3

            SET @n_pre_error = 'N';
        
            IF @t_sub_sir_id IS NULL
			BEGIN
			set @n_isam_error = 10
                RAISERROR('Missing Sub SIR ID',16,1);
				END
	
        
            IF ( @t_ssn IS NULL
                 --OR @t_ssn = ''
               )
			   BEGIN
			   set @n_isam_error = 1
                RAISERROR('Missing SSN in client file',16,1);
				END
	
            
            IF ( @t_last_name IS NULL
                -- OR @t_last_name = ''
               )
			   BEGIN
			   set @n_isam_error = 2
                RAISERROR('Missing Last Name in client file',16,1);
				END
	
            
            IF ( @t_first_name IS NULL
                 --OR @t_first_name = ''
               )
			   BEGIN
			   set @n_isam_error = 3
                RAISERROR('Missing First Name in client file',16,1);
				END
	
            
            IF ( @t_sub_ssn IS NULL
                 --OR @t_sub_ssn = ''
               )
			   BEGIN
			   set @n_isam_error = 14
                RAISERROR('Missing Subscriber''s SSN in client file',16,1);
				END
	
            
            IF ( @t_alt_id IS NULL
                 --OR @t_alt_id = ''
               )
			   BEGIN
			   set @n_isam_error = 20
                RAISERROR('Missing Alternate ID in client file',16,1);
				END
	
            
            IF ( @t_sub_alt_id IS NULL
                 --OR @t_sub_alt_id = ''
               )
			   BEGIN
			   set @n_isam_error = 21
                RAISERROR('Missing Sub''s alternate id in client file',16,1);
				END
	
            
            IF @t_date_of_birth IS NOT NULL
		--RAISE EXCEPTION -746, 22, "Missing Date of birth in client file";
                BEGIN
                    
                    IF @t_date_of_birth = '01/01/1900'
					BEGIN
						set @n_isam_error = 18
                        RAISERROR('Invalid Date of birth in client file',0,1);
						EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
						 @i_sir_def_id, @t_sir_id, @n_isam_error;
						END
                END;
            ELSE
			BEGIN
			   set @n_isam_error = 22
                RAISERROR('Missing date of birth in client file',16,1);
				END
	
            
            IF ( @t_def_key IS NULL
                 --OR @t_def_key = ''
               )
                OR ( @t_type IS NULL
                    -- OR @t_type = ''
                   )
				   BEGIN
			   set @n_isam_error = 23
                RAISERROR('Missing Key or Type in client file',16,1);
				END
	
            
            IF ( @t_member_code IS NULL
                 --OR @t_member_code = ''
               )
			   BEGIN
			   set @n_isam_error =19
                RAISERROR('Missing Member Code in client file',16,1);
				END
	
            
            IF @t_subscriber = '00'
                BEGIN
                    
                    IF @t_member_code NOT IN ( '10', '20' )
                        OR @t_alt_id != @t_sub_alt_id
						BEGIN
			   set @n_isam_error = 26
                        RAISERROR('Sub must have same alt_id and sub_alt_id',16,1);
						END
		
                    
                    IF @n_has_plan_eff = 'Y'
                        BEGIN
                            
                            IF @t_plan_eff_date IS NULL

                          BEGIN
								  set @n_isam_error = 11
								  SET @t_plan_eff_date = @d_process_eff_dt;
                                    RAISERROR('Missing Plan Effective Date in client file',0,1);
									EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
									@i_sir_def_id, @t_sir_id, @n_isam_error;
                                    
                                END;
                            ELSE
                                BEGIN
                                    
						 IF @t_plan_eff_date = '01/01/1900'
                                        BEGIN
										set @n_isam_error = 15
										 SET @t_plan_eff_date = @d_process_eff_dt;
									RAISERROR('Invalid Plan Effective Date in client',0,1);
									EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
								@i_sir_def_id, @t_sir_id, @n_isam_error;
                                        END;
                                END;
                        END;
                    ELSE
                        BEGIN
                            
                            SET @t_plan_eff_date = @d_process_eff_dt;
                            
                        END;
		
                    
                    IF @n_has_rate_code = 'Y'
                        BEGIN
                    
                            IF ( @t_rate_code IS NULL
                                -- OR @t_rate_code = ''
                               )
							   BEGIN
								set @n_isam_error = 9
                                RAISERROR('Missing Rate Code in client file',16,1);
								END
                        END;
                    ELSE
                        BEGIN
                            SET @t_rate_code = NULL;
                            
                        END;

                    IF @n_has_fac_eff = 'Y'
                        BEGIN
                            
                            IF @t_fac_eff_date IS NULL
                                BEGIN
								
								set @n_isam_error = 33
                                    SET @t_fac_eff_date = @d_process_eff_dt;
                                    RAISERROR('Missing Facility Effective Date',0,1);
									EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
									@i_sir_def_id, @t_sir_id, @n_isam_error;
                        END;
                            ELSE
                                BEGIN
                                    
                                    IF @t_fac_eff_date = '01/01/1900'
                                        BEGIN
										set @n_isam_error = 17
										SET @t_fac_eff_date = @d_process_eff_dt;
                                            RAISERROR('Invalid Facility Effective Date',0,1);                                        
											EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @t_sir_id, @n_isam_error;
                                        END;
                                END;
                        END;
                    ELSE
                        BEGIN
                            
                            SET @t_fac_eff_date = @d_process_eff_dt;
                            
                        END;
		
                    
                    IF @n_has_s_plan_term = 'Y'
                        BEGIN
                    
                            IF @t_plan_term_date IS NOT NULL
                                BEGIN
                    
                                    IF @t_plan_term_date = '01/01/1900'
                                        BEGIN
										set @n_isam_error = 16
										SET @t_plan_term_date = @d_process_exp_dt;
                                            RAISERROR('Invalid Plan termination date',0,1);
											EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
												@i_sir_def_id, @t_sir_id, @n_isam_error;
                                            
                                        END;
                                END;
                        END;
                    ELSE
                        BEGIN
                            SET @t_plan_term_date = NULL;
                            
                        END;
                END;
            ELSE
		/* 20120803$$ks - blank alt ID is OK if coming from API */
                BEGIN
                    
                    IF @t_member_code NOT IN ( '30', '40', '50', '70' )
                        OR ( @n_lookup_ssn_alt != 'Z'
                             AND @t_alt_id = @t_sub_alt_id
                           )
						   BEGIN
						   set @n_isam_error = 27
                        RAISERROR('Dependent can''t have alt_id same as sub_alt_id',16,1);
						END
		
                    
                    IF @n_has_plan_eff = 'Y'
                        BEGIN
                            
  IF @t_plan_eff_date IS NULL
              BEGIN
								set @n_isam_error = 11
								 SET @t_plan_eff_date = @d_process_eff_dt;
                                    RAISERROR('Missing Dependent plan effective date',0,1);
									EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
						 @i_sir_def_id, @t_sir_id, @n_isam_error;
                                    
                                END;
                            ELSE
                                BEGIN
                                    
                                    IF @t_plan_eff_date = '01/01/1900'
                                        BEGIN
										set @n_isam_error = 15
										 SET @t_plan_eff_date = @d_process_eff_dt;
                                            RAISERROR('Invalid Plan Effective date',0,1);
											EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
											@i_sir_def_id, @t_sir_id, @n_isam_error;
                                        END;
                                END;
                        END;
		
                    
                    IF @n_has_d_plan_term = 'Y'
                        BEGIN
                    
                            IF @t_plan_term_date IS NOT NULL
                                BEGIN
                    
                                    IF @t_plan_term_date = '01/01/1900'
   BEGIN
										set @n_isam_error = 16
										 SET @t_plan_term_date = @d_process_exp_dt;
                                            RAISERROR('Invalid Plan termination date',0,1);
											EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
											@i_sir_def_id, @t_sir_id, @n_isam_error;
                                        END;
                                END;
                        END;
                    ELSE
                        BEGIN
                            SET @t_plan_term_date = NULL;
                            
                        END;
		
                    
                    IF @n_has_fac_eff = 'Y'
                        BEGIN
                    
                            IF @t_fac_eff_date IS NOT NULL
                                BEGIN
                    
                                    IF @t_plan_term_date = '01/01/1900'
                                        BEGIN
										set @n_isam_error = 17
										SET @t_fac_eff_date = @d_process_eff_dt;
                                            RAISERROR('Invalid Facility Effective Date',0,1);
											EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
						 @i_sir_def_id, @t_sir_id, @n_isam_error;
                                        END;
                                END;
                            ELSE
                                BEGIN
								set @n_isam_error = 32
								SET @t_fac_eff_date = @d_process_eff_dt;
                                    RAISERROR('Missing Facility Effective Date',0,1);
									EXECUTE dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @t_sir_id, @n_isam_error;
                                END;
                        END;
                    ELSE
                        BEGIN
                            
                            SET @t_fac_eff_date = @d_process_eff_dt;
                            
                        END;
                END;
	
            IF @n_pre_error = 'Y'
                RETURN -1;
	
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            --SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            
            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
                @i_sir_def_id, @t_sir_id, @n_isam_error;
            IF @i_fatal <> 1
                SET @n_pre_error = 'Y';
        END CATCH;
        SET NOCOUNT OFF;

    END;