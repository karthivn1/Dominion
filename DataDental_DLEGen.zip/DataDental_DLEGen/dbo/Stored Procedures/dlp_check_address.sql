﻿CREATE PROCEDURE [dbo].[dlp_check_address]
@a_batch_id INT ,
@a_sir_id INT ,
@a_new_member CHAR(1) ,
@i_member_id INT ,
@SWP_Ret_Value INT = NULL OUTPUT ,
@SWP_Ret_Value1 CHAR(2) = NULL OUTPUT 

AS
BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
DECLARE @i_error_no INT;
DECLARE @i_isam_error INT;
DECLARE @s_error_descr VARCHAR(64);
DECLARE @a_error_no INT;
DECLARE @i_fatal INT;
DECLARE @s_found_error CHAR(1);
DECLARE @i_zip_id INT;
DECLARE @s_city VARCHAR(30);
DECLARE @s_state CHAR(2);
DECLARE @i_zip INT;
DECLARE @s_addr1 CHAR(30);
DECLARE @s_addr2 CHAR(30);
DECLARE @s_zip CHAR(5);
DECLARE @s_zipx CHAR(4);
DECLARE @n_action_code CHAR(2);
DECLARE @n_g1 INT;
DECLARE @n_g2 INT;
DECLARE @n_g4 INT;
DECLARE @n_city CHAR(30);
DECLARE @n_county CHAR(15);
DECLARE @n_state_code CHAR(2);
DECLARE @n_count INT;
DECLARE @n_home_phone CHAR(10);
DECLARE @n_home_ext CHAR(5);
DECLARE @n_work_phone CHAR(10);
DECLARE @n_work_ext CHAR(5);
DECLARE @s_last_name CHAR(15);
DECLARE @d_date_of_birth DATE;
DECLARE @s_paperless CHAR(1);
DECLARE @n_email CHAR(100);
DECLARE @i_address_id INT;
DECLARE @d_addr1 CHAR(30);
DECLARE @i_sp_id integer ;
DECLARE @i_sir_def_id integer ;
DECLARE @ls_process_date char(10) ;
DECLARE @ld_process_date date ;
DECLARE @n_lookup_ssn_alt char(1) ;
DECLARE @n_has_facility_id char(1) ;
DECLARE @n_has_multiple_gp char(1) ;
DECLARE @n_add_to_cl_fc char(1) ;
DECLARE @n_has_rate_code char(1) ;
DECLARE @n_has_address char(1) ;
DECLARE @n_sub_age char(11) ;
DECLARE @n_has_plan_eff char(1) ;
DECLARE @n_has_fac_eff char(1) ;
DECLARE @n_has_s_plan_term char(1) ;
DECLARE @n_has_d_plan_term char(1) ;
DECLARE @d_process_date date ;
DECLARE @i_sub_age integer ;
DECLARE @s_sub_age char(11) ;
DECLARE @t_sir_id integer ;
DECLARE @t_sub_sir_id integer ;
DECLARE @t_subscriber char(2) ;
DECLARE @t_alt_id char(20) ;
DECLARE @t_ssn char(11) ;
DECLARE @t_sub_ssn char(11) ;
DECLARE @t_sub_alt_id char(20) ;
DECLARE @t_member_code char(2) ;
DECLARE @t_last_name char(15) ;
DECLARE @t_first_name char(15) ;
DECLARE @t_middle_init char(1) ;
DECLARE @t_date_of_birth date ;
DECLARE @t_student_flag char(1) ;
DECLARE @t_disable_flag char(1) ;
DECLARE @t_cobra_flag char(1) ;
DECLARE @t_address1 char(30) ;
DECLARE @t_address2 char(30) ;
DECLARE @t_city char(30) ;
DECLARE @t_state char(2) ;
DECLARE @t_zip char(5) ;
DECLARE @t_zipx char(4) ;
DECLARE @t_home_phone char(10) ;
DECLARE @t_home_ext char(4) ;
DECLARE @t_work_phone char(10) ;
DECLARE @t_work_ext char(4) ;
DECLARE @t_rate_code char(2) ;
DECLARE @t_plan_eff_date date ;
DECLARE @t_plan_term_date date ;
DECLARE @t_fac_eff_date date ;
DECLARE @t_group_id integer ;
DECLARE @t_plan_id integer ;
DECLARE @t_facility_id integer ;
DECLARE @t_def_key char(2) ;
DECLARE @t_type char(2) ;
DECLARE @t_sub_id integer ;
DECLARE @t_member_id integer ;
DECLARE @t_paperless char(1) ;
DECLARE @t_email char(100) ;
--DECLARE @SWV_cursor_var1 CURSOR;
--DECLARE @SWV_cursor_var2 CURSOR;
--DECLARE @SWV_cursor_var3 CURSOR;
DECLARE @v_Null INT;
SET NOCOUNT ON;
SET @i_sp_id = 0; 
SET @i_sir_def_id = 0; 
SET @ls_process_date =''; 
SET @ld_process_date = NULL; 
SET @n_lookup_ssn_alt =''; 
SET @n_has_facility_id =''; 
SET @n_has_multiple_gp =''; 
SET @n_add_to_cl_fc =''; 
SET @n_has_rate_code =''; 
SET @n_has_address =''; 
SET @n_sub_age =''; 
SET @n_has_plan_eff =''; 
SET @n_has_fac_eff =''; 
SET @n_has_s_plan_term =''; 
SET @n_has_d_plan_term =''; 
SET @d_process_date = NULL; 
SET @i_sub_age = 0; 
SET @s_sub_age =''; 
SET @t_sir_id = 0; 
SET @t_sub_sir_id = 0; 
SET @t_subscriber =''; 
SET @t_alt_id =''; 
SET @t_ssn =''; 
SET @t_sub_ssn =''; 
SET @t_sub_alt_id =''; 
SET @t_member_code =''; 
SET @t_last_name =''; 
SET @t_first_name =''; 
SET @t_middle_init =''; 
SET @t_date_of_birth = NULL; 
SET @t_student_flag =''; 
SET @t_disable_flag =''; 
SET @t_cobra_flag =''; 
SET @t_address1 =''; 
SET @t_address2 =''; 
SET @t_city =''; 
SET @t_state =''; 
SET @t_zip =''; 
SET @t_zipx =''; 
SET @t_home_phone =''; 
SET @t_home_ext =''; 
SET @t_work_phone =''; 
SET @t_work_ext =''; 
SET @t_rate_code =''; 
SET @t_plan_eff_date = NULL; 
SET @t_plan_term_date = NULL; 
SET @t_fac_eff_date = NULL; 
SET @t_group_id = 0; 
SET @t_plan_id = 0; 
SET @t_facility_id = 0; 
SET @t_def_key =''; 
SET @t_type =''; 
SET @t_sub_id = 0; 
SET @t_member_id = 0; 
SET @t_paperless =''; 
SET @t_email ='';
BEGIN TRY

EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_eligibility';

SET @n_has_address = dbo.dl_get_param_value(@a_batch_id,@i_sp_id,'Has Address')

SELECT @t_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_term_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_fac_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_facility_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_def_key = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_def_key' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @i_sir_def_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'i_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @i_sp_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'i_sp_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_email = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_email' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_paperless = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_paperless' and  BatchId = @a_batch_id AND Module_Id = 3

EXECUTE @i_sir_def_id = dbo.dl_get_sir_def_id 'elig';

--IF EXISTS (SELECT 'X' FROM dbo.dls_elig 
--	WHERE dls_batch_id = @a_batch_id
--	AND dls_sir_id = @t_sir_id
--	AND ISNULL(address1,'')<>''
--)
--BEGIN
--	SELECT @s_addr1 = addr1
--	FROM dbo.[address] (NOLOCK)
--	WHERE subsys_code = 'GP'
--	AND sys_rec_id = @t_group_id
--	AND addr_type = 'L';

--	UPDATE dbo.dls_elig
--	SET address1 = @s_addr1 
--	WHERE dls_batch_id = @a_batch_id
--	AND dls_sir_id = @t_sir_id;
--END
SET @s_found_error = 'N';
-- IF n_has_address = "N" and a_new_member = "N" THEN
-- Return 1, null;
-- END IF;
SET @i_zip_id = NULL; 
SET @s_city = NULL; 
SET @n_city = NULL; 
SET @n_county = NULL; 
SET @n_state_code = NULL; 
IF @a_new_member = 'Y'
BEGIN
IF @n_has_address = 'Y'
BEGIN

IF ( @t_address1 IS NOT NULL
)
AND LEN(@t_address1) > 0
BEGIN
IF ( @t_zip IS NULL
)
BEGIN
SET @a_error_no = 201
RAISERROR('Missing Zip Code in client file',0,1)
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
end
ELSE
/* logic to allow multiple cities with same zipcode-05052004ks */
BEGIN
/*
SET @SWV_cursor_var1 = CURSOR FOR SELECT zip_id, city, state_code
FROM dbo.usa_zip (NOLOCK)
WHERE zip_code = @t_zip;
OPEN @SWV_cursor_var1;
FETCH NEXT FROM @SWV_cursor_var1 INTO @i_zip_id,
@s_city, @s_state;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var1 TABLE
(
id INT IDENTITY ,
zip_id INT, city char(30), state_code char (2)
);
INSERT INTO @SWV_cursor_var1
( zip_id, city, state_code
)
SELECT zip_id, city, state_code
FROM dbo.usa_zip (NOLOCK)
WHERE zip_code = @t_zip;
DECLARE @cur1_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur1_cnt = COUNT(1)
FROM @SWV_cursor_var1;
WHILE ( @cur_i <= @cur1_cnt )
BEGIN
SELECT @i_zip_id = zip_id, @s_city = city, @s_state = state_code
FROM @SWV_cursor_var1
WHERE id = @cur_i;

IF UPPER(@s_city) = UPPER(@t_city)
GOTO SWL_Label4;
--FETCH NEXT FROM @SWV_cursor_var1 INTO @i_zip_id, @s_city, @s_state;
SET @cur_i = @cur_i + 1;
END;
SWL_Label4:
--CLOSE @SWV_cursor_var1;
IF @i_zip_id IS NULL
begin
SET @a_error_no = 202
RAISERROR('Zip Code is not recognized by DataDental',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
end
ELSE
BEGIN
IF ( ( @t_city IS NOT NULL
)
AND LEN(@t_city) > 0
)
AND UPPER(@t_city) != UPPER(@s_city)
BEGIN
SET @a_error_no = 203
RAISERROR('Given city name mismatch according to the zip code',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END
IF ( ( @t_city IS NOT NULL
)
AND LEN(@t_city) > 0
)
AND @t_city != @s_city
BEGIN
SET @t_city = @s_city;
END; -- case differences
IF ( ( @t_state IS NOT NULL
AND @t_state <> ''
)
AND LEN(@t_state) > 0
)
AND @t_state <> @s_state
BEGIN
SET @t_state = @s_state;
END;
-- 20160106$$ks RAISE EXCEPTION -746, 204, "Given state mismatches according to zip";
-- 20160106$$ks if city and zipcode match usa_zip, then use usa_zip's state
END;
END;
IF @s_found_error = 'Y'
BEGIN
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = NULL;
RETURN;
END;
ELSE
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = NULL;
RETURN;
END;
END;
SET @a_error_no = 250
RAISERROR('Missing Address, but substitude with Group Locaiton',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END;
SELECT @s_addr1 = addr1 ,
@s_addr2 = addr2 ,
@s_city = city ,
@s_state = [state] ,
@s_zip = SUBSTRING(zip, 1, 5) ,
@s_zipx = SUBSTRING(zip, 6, 4)
FROM dbo.[address] (NOLOCK)
WHERE subsys_code = 'GP'
AND sys_rec_id = @t_group_id
AND addr_type = 'L';
IF ( @s_addr1 IS NULL
OR @s_addr1 = ''
)
BEGIN
SET @a_error_no = 210
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = NULL;
RAISERROR('Missing Group Location Address',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';;
END;
ELSE
BEGIN
UPDATE dbo.dls_elig
SET address1 = @s_addr1 ,
address2 = @s_addr2 ,
city = @s_city ,
[state] = @s_state ,
zip = @s_zip ,
zipx = @s_zipx
WHERE dls_batch_id = @a_batch_id
AND dls_sir_id = @t_sir_id;
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = NULL;
RETURN;
END;
END;
ELSE
BEGIN
SET @n_action_code = NULL;
SET @n_g1 = 0;
SET @n_g2 = 0;
SET @n_g4 = 0;
--existing member address checking
-- 20120521$$ks - add paperless logic
-- g1 = 1 DOB or PaperlessSW
SELECT @s_last_name = last_name ,
@d_date_of_birth = date_of_birth ,
@s_paperless = paperless
FROM dbo.member (NOLOCK)
WHERE member_id = @i_member_id;
IF ( @s_last_name IS NULL
)
BEGIN
SET @a_error_no = 251
RAISERROR('Internal - Null member_id',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END
IF @t_date_of_birth IS NOT NULL
AND @t_date_of_birth != '01/01/1900'
AND @d_date_of_birth != @t_date_of_birth
SET @n_g1 = 1;
IF ( @t_paperless IS NOT NULL
)
AND LEN(@t_paperless) > 0
BEGIN
IF @t_paperless != @s_paperless
SET @n_g1 = 1;
END;
IF @t_subscriber != '00'
IF @n_g1 > 0
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = 'G1';
RETURN;
END;
ELSE
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = NULL;
RETURN;
END;
IF @n_has_address != 'Y'
IF @n_g1 > 0
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = 'G1';
RETURN;
END;
ELSE
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = NULL;
RETURN;
END;
SELECT @i_address_id = address_id ,
@s_addr1 = addr1 ,
@s_addr2 = addr2 ,
@s_city = city ,
@s_state = [state] ,
@s_zip = zip
FROM dbo.[address] (NOLOCK)
WHERE subsys_code = 'MB'
AND sys_rec_id = @i_member_id
AND addr_type = 'L';
IF @i_address_id IS NOT NULL
BEGIN
IF ( @t_address1 IS NOT NULL
)
IF ( @s_addr1 IS NOT NULL
)
BEGIN
IF @s_addr1 != @t_address1
SET @n_g2 = 1;
END;
ELSE
SET @n_g2 = 1;
IF @n_g2 = 0
BEGIN
IF ( @t_address2 IS NOT NULL
AND @t_address2 <> ''
)
IF ( @s_addr2 IS NOT NULL
)
BEGIN
IF @s_addr2 != @t_address2
SET @n_g2 = 1;
END;
ELSE
SET @n_g2 = 1;
END;
IF ( @t_zip IS NOT NULL
)
BEGIN
IF ( @s_zip IS NOT NULL
)
AND @s_zip != @t_zip
BEGIN
/*
SET @SWV_cursor_var2 = CURSOR FOR SELECT city, county, state_code
FROM dbo.usa_zip (NOLOCK)
WHERE zip_code = @t_zip;
OPEN @SWV_cursor_var2;
FETCH NEXT FROM @SWV_cursor_var2 INTO @n_city,
@n_county, @n_state_code;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var2 TABLE
(
id INT IDENTITY ,
city char(30), county char(20), state_code char(2)
);
INSERT INTO @SWV_cursor_var2
( city, county, state_code
)
SELECT city, county, state_code
FROM dbo.usa_zip (NOLOCK)
WHERE zip_code = @t_zip;

DECLARE @cur2_cnt INT ,
@cur2_i INT;
SET @cur2_i = 1;
--Get the no. of records for the cursor
SELECT @cur2_cnt = COUNT(1)
FROM @SWV_cursor_var2;
WHILE ( @cur2_i <= @cur2_cnt )
BEGIN
SELECT @n_city = city,@n_county = county, @n_state_code = state_code
FROM @SWV_cursor_var2
WHERE id = @cur2_i;
IF @n_city = @t_city
GOTO SWL_Label5;

--FETCH NEXT FROM @SWV_cursor_var2 INTO @n_city, @n_county, @n_state_code;
SET @cur2_i = @cur2_i + 1;
END;
SWL_Label5:
--CLOSE @SWV_cursor_var2;

IF ( (@n_city IS NULL
)
)
OR ( (@n_state_code IS NULL
)
)
OR ( (@n_county IS NULL
)
)
BEGIN
SET @a_error_no = 280
RAISERROR('Zip code is not recognized by DD',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END
END;
END;
SELECT @n_count = COUNT(*)
FROM dbo.mbr_phone (NOLOCK)
WHERE address_id = @i_address_id;
IF @n_count > 1
BEGIN
SET @a_error_no = 282
RAISERROR('Multiple Member Phone Records',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END
IF @n_count = 1
BEGIN
SELECT @n_home_phone = home_phone ,
@n_home_ext = home_ext ,
@n_work_phone = work_phone ,
@n_work_ext = work_ext ,
@n_email = email
FROM dbo.mbr_phone (NOLOCK)
WHERE address_id = @i_address_id;
IF @n_g4 = 0
IF ( @n_home_phone IS NULL
)
BEGIN
IF ( @t_home_phone IS NOT NULL
)
SET @n_g4 = 1;
END;
ELSE
BEGIN
IF ( @t_home_phone IS NOT NULL

)
BEGIN
IF @n_home_phone != @t_home_phone
SET @n_g4 = 1;
ELSE
BEGIN
IF ( @t_home_ext IS NOT NULL
)
BEGIN
IF ( @n_home_ext IS NULL
)
OR @n_home_ext != @t_home_ext
SET @n_g4 = 1;
END;
END;
END;
END;
IF @n_g4 = 0
IF ( @n_work_phone IS NULL
)
BEGIN
IF ( @t_work_phone IS NOT NULL
)
SET @n_g4 = 1;
END;
ELSE
BEGIN
IF ( @t_work_phone IS NOT NULL
)
BEGIN
IF @t_work_phone != @n_work_phone
SET @n_g4 = 1;
ELSE
BEGIN
IF ( @t_work_ext IS NOT NULL
)
BEGIN
IF ( @n_work_ext IS NULL
)
OR @n_work_ext != @t_work_ext
SET @n_g4 = 1;
END;
END;
END;
END;
IF @n_g4 = 0
BEGIN
IF ( @t_email IS NOT NULL
)
BEGIN
IF ( @n_email IS NOT NULL
)
AND @t_email != @n_email
SET @n_g4 = 1;
END;
END;
END;
ELSE
BEGIN
/*
SET @SWV_cursor_var3 = CURSOR FOR SELECT city, county, state_code
FROM dbo.usa_zip (NOLOCK)
WHERE zip_code = @t_zip;
OPEN @SWV_cursor_var3;
FETCH NEXT FROM @SWV_cursor_var3 INTO @n_city,
@n_county, @n_state_code;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var3 TABLE
(
id INT IDENTITY ,
city char(30), county char (20), state_code char(2)
);
INSERT INTO @SWV_cursor_var3
( city, county, state_code
)
SELECT city, county, state_code
FROM dbo.usa_zip (NOLOCK)
WHERE zip_code = @t_zip;
DECLARE @cur3_cnt INT ,
@cur3_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur3_cnt = COUNT(1)
FROM @SWV_cursor_var3;
WHILE ( @cur3_i <= @cur3_cnt )
BEGIN
SELECT @n_city = city, @n_county = county, @n_state_code = state_code
FROM @SWV_cursor_var3
WHERE id = @cur3_i;
IF @n_city = @t_city
GOTO SWL_Label6;
--FETCH NEXT FROM @SWV_cursor_var3 INTO @n_city, @n_county, @n_state_code;
SET @cur3_i = @cur3_i + 1;
END;
SWL_Label6:
--CLOSE @SWV_cursor_var3;
IF ( (@n_city IS NULL
)
)
OR ( (@n_county IS NULL
)
)
OR ( (@n_state_code IS NULL
)
)
BEGIN
SET @a_error_no = 290
RAISERROR('zip code is not recognized by DD',0,1);
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END
SET @n_g2 = 1;
IF NOT ( ( @t_home_phone IS NULL)OR ( @t_work_phone IS NULL))
SET @n_g4 = 1;
END;
END;
ELSE
BEGIN
SET @v_Null = 0;
END;
IF @s_found_error = 'N'
BEGIN

SET @n_g4 = @n_g4 * 4 + @n_g2 * 2 + @n_g1;

IF @n_g4 > 0
SET @n_action_code = CONCAT('G', @n_g4);

SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = @n_action_code;
RETURN;
END;
ELSE
BEGIN
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = NULL;
RETURN;
END;
END;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
SET @i_isam_error = ERROR_LINE();
SET @s_error_descr = ERROR_MESSAGE();

EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @a_error_no;
IF @i_fatal <> 1
SET @s_found_error = 'Y';
END CATCH;
SET NOCOUNT OFF;
--trace off;
　
--set debug file to "/tmp/addr.trc";
--trace on;
END;