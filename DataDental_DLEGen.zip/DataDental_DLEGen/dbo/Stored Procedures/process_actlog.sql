﻿
CREATE PROCEDURE [dbo].[process_actlog]
    @eClaimID INT ,
    @EffDate DATETIME ,
    @hUser CHAR(20) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(100) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:36:36 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1




000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;
        DECLARE @ActMastID INT;
        DECLARE @ddClaimID INT;
        DECLARE @LogDate DATE;
        DECLARE @LogTime TIME(2);

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            
--set debug file to 'proc_act.trc';
--trace on;

            SET @LogDate = CONVERT(DATE, @EffDate);
            SET @LogTime = CAST(@EffDate AS TIME(0))
--- Does this record already exist? 
            SELECT  @ddClaimID = dds_claim_id
            FROM    dbo.eclaim_h (NOLOCK)
            WHERE   eclaim_id = @eClaimID; 
            
            IF @ddClaimID = 0
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = 'Claim not found';
                    RETURN;
                END;

            SELECT  @ActMastID = act_mast_id
            FROM    dbo.act_mast a ( NOLOCK ) ,
                    dbo.mod_def m ( NOLOCK )
            WHERE   m.mod_id = a.mod_id
                    AND m.subsys_code = 'CL'
                    AND m.menu_opt = 'edit_clm'; 
           
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.act_log (NOLOCK)
                            WHERE   sub_sys = 'CL'
                                    AND event_sys_id = @ddClaimID
                                    AND act_mast_id = @ActMastID
                                    AND log_user = @hUser
                                    AND log_date = @LogDate
                                    AND log_time = @LogTime
                                    AND reason_code = 'EC' )
                BEGIN
                    INSERT  INTO dbo.act_log
                            ( sub_sys ,
                              act_mast_id ,
                              event_sys_id ,
                              reason_code ,
                              log_user ,
                              log_date ,
                              log_time
                            )
                    VALUES  ( 'CL' ,
                              @ActMastID ,
                              @ddClaimID ,
                              'EC' ,
                              @hUser ,
                              @LogDate ,
                              @LogTime
                            );
	
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = 'Log entry inserted';
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = 'Log entry not inserted';
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
      RETURN;
        END CATCH;
        SET NOCOUNT OFF;


-----------------------------------------------------------------------
    END;