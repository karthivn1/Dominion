﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_UpdateClaimValidation '','',20171570000003,'',''
-- =============================================
CREATE PROC [dbo].[usp_api_UpdateClaimValidation] 
@CPRN INT,@ClaimID INT,@ClaimNo decimal(20),@ClaimAltID Char(40),@ClaimDocNo Char(20)
AS
BEGIN

IF OBJECT_ID('tempdb..#tempErrorTable') IS NOT NULL
    DROP TABLE #tempErrorTable

IF OBJECT_ID('tempdb..#tempClaim') IS NOT NULL
    DROP TABLE #tempClaim


Create table #tempErrorTable(ID int identity(1,1),ErrorName nvarchar(50),ErrorDesc nvarchar(1000))	
Create Table #tempClaim(ClaimID INT,ClaimNo decimal(25),ClaimAltID char(20),ClaimDocNo char(20),claim_status nVarchar(50)) 

BEGIN TRY

---claim Validations
IF @CPRN>0
BEGIN
IF EXISTS(Select claim_id From claim_h Where preauth_number=@CPRN)
BEGIN
	INSERT INTO #tempClaim
	Select claim_id,claim_no,alt_id,document_no,claim_status From claim_h	
	Where preauth_number=@CPRN
END
END

ELSE IF @ClaimID>0
BEGIN
IF EXISTS(Select claim_id From claim_h Where claim_id=@ClaimID)
BEGIN
	INSERT INTO #tempClaim
	Select claim_id,claim_no,alt_id,document_no,claim_status From claim_h	
	Where claim_id=@ClaimID
END
END


ELSE IF @ClaimNo>0
BEGIN
IF EXISTS(Select claim_id From claim_h Where claim_no= CAST(@ClaimNo AS float))
BEGIN
	INSERT INTO #tempClaim
	Select claim_id,claim_no,alt_id,document_no,claim_status From claim_h	
	Where claim_no=CAST(@ClaimNo AS float)
END
END


ELSE IF len(@ClaimDocNo)>0
BEGIN
IF EXISTS(Select claim_id From claim_h Where document_no=@ClaimDocNo)
BEGIN
	INSERT INTO #tempClaim
	Select claim_id,claim_no,alt_id,document_no,claim_status From claim_h	
	Where document_no=@ClaimDocNo
END
END


ELSE IF len(@ClaimAltID)>0
BEGIN
IF EXISTS(Select claim_id From claim_h Where alt_id=@ClaimAltID)
BEGIN
	INSERT INTO #tempClaim
	Select claim_id,claim_no,alt_id,document_no,claim_status From claim_h	
	Where alt_id=@ClaimAltID
END
END

IF NOT EXISTS(Select ClaimID From #tempClaim)
BEGIN
  INSERT INTO #tempErrorTable Values ('Claim','Claim could not be found with the given criteria');
  RAISERROR ('User Validation Faild',16,1);

END
IF NOT EXISTS(Select ClaimID From #tempClaim Where claim_status='In Process')
BEGIN
  INSERT INTO #tempErrorTable Values ('Claim','Claim process completed cannot be updated');
  RAISERROR ('User Validation Faild',16,1);
END 

IF NOT EXISTS(Select mb.mb_gr_pl_id
	From #tempClaim t
	join  claim_h c on c.claim_id=t.ClaimID
	join rlmbgrpl mb on mb.mb_gr_pl_id=c.mbgrpl_id where mb.mb_gr_pl_id>0)
	BEGIN

		DECLARE @cID INT=0;
		Select @cID=ClaimID From #tempClaim 

		INSERT INTO #tempErrorTable Values ('Claim','Unable to get member/grp/plan info for ID:' + @cID );
		RAISERROR ('User Validation Faild',16,1);
	END

IF NOT EXISTS(Select  r.rlplfc_id
	From #tempClaim t
	join  claim_h c on c.claim_id=t.ClaimID
	join rlplfc r on r.rlplfc_id=c.rlplfc_id where  r.rlplfc_id>0)
	BEGIN

		DECLARE @PatPlanFcID INT=0;
		Select  @PatPlanFcID=c.rlplfc_id
		From #tempClaim t
		join  claim_h c on c.claim_id=t.ClaimID

		INSERT INTO #tempErrorTable Values ('Claim','Unable to get Patient/AssignFC info for ID:' + @PatPlanFcID);
		RAISERROR ('User Validation Faild',16,1);
	END


--service info

--Select cd.claim_id,cd.claim_d_id,cd.d_proc_code,cd.[status],cd.svc_beg,cd.submitted_amt
--	From #tempClaim t
--	join  claim_h c on c.claim_id=t.ClaimID
--	join rlmbgrpl mb on mb.mb_gr_pl_id=c.mbgrpl_id
--	join rlplfc r on r.rlplfc_id=c.rlplfc_id
--	join claim_d cd on cd.claim_id=c.claim_id
--	----------------------------------------------------------------------------------


--Select *
--	From #tempClaim t
--	join claim_pc pc on t.ClaimID=pc.claim_id
--    JOIN clm_process_codes CPC on CPC.clm_proc_code_id=pc.process_code_id
--	Where  pc.deassigned_at is null
	
	--select *From claim_pc


--Select mb.member_id, mb.group_id, mb.plan_id,  
--				mb.eff_gr_pl, mb.exp_gr_pl,(select count(*) from sgp_pend where sgp_pend.mb_gr_pl_id = mb.mb_gr_pl_id and cancel_datetime is null) as pend  
--				from rlmbgrpl mb 
--				Join claim_h c on c.mbgrpl_id=mb.mb_gr_pl_id
--				join rlplfc r on r.rlplfc_id=c.rlplfc_id
--				join claim_d CD on CD.claim_id=c.claim_id
--				join claim_pc pc on pc.claim_d_id=CD.claim_d_id
--				JOIN clm_process_codes CPC on CPC.clm_proc_code_id=pc.process_code_id
--				JOIN #tempClaim t on t.ClaimID=c.claim_id
--				Where pc.deassigned_at is null
Select ErrorName AS ErrorType,ErrorDesc AS ErrorMsg From #tempErrorTable

Select ClaimID ,ClaimNo as ClaimNum,ClaimAltID,ClaimDocNo as ClaimDocNum from #tempClaim

END TRY
BEGIN CATCH

IF ERROR_MESSAGE()='User Validation Faild'
BEGIN
  Select ErrorName AS ErrorType,ErrorDesc AS ErrorMsg From #tempErrorTable
END
ELSE 
 THROW; 

END CATCH

END