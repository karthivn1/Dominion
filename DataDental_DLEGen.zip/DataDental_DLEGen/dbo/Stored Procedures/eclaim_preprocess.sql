﻿CREATE PROCEDURE [dbo].[eclaim_preprocess]
    @ID INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:33:33 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;
        DECLARE @HCnt INT;
        DECLARE @DCnt INT;
        DECLARE @NoDateCnt INT;
        DECLARE @NumErrors INT;
        DECLARE @DT DATETIME2(0);
        DECLARE @TD DATE;
        DECLARE @eClaimID INT;
        DECLARE @ALTID CHAR(20);
        DECLARE @DocNo CHAR(15);
        DECLARE @STAT INT;
        DECLARE @ErrCode CHAR(10);
        DECLARE @PreAuth CHAR(1);
        DECLARE @Emerg CHAR(1);
        DECLARE @PVNPID CHAR(10);
        DECLARE @PVAltID CHAR(20);
        DECLARE @PVFName CHAR(20);
        DECLARE @PVMI CHAR(1);
        DECLARE @PVLName CHAR(30);
        DECLARE @PVTaxID CHAR(9);
        DECLARE @PVAddr1 CHAR(30);
        DECLARE @PVAddr2 CHAR(30);
        DECLARE @PVCity CHAR(20);
        DECLARE @PVState CHAR(2);
        DECLARE @PVZIP CHAR(10);
        DECLARE @PVCountry CHAR(3);
        DECLARE @PVLicState CHAR(2);
        DECLARE @PVID CHAR(20);
        DECLARE @PaySw CHAR(1);
        DECLARE @FCName CHAR(50);
        DECLARE @FCNPID CHAR(10);
        DECLARE @FCAltID CHAR(20);
        DECLARE @FCID CHAR(20);
        DECLARE @PatFName CHAR(20);
        DECLARE @PatMI CHAR(1);
        DECLARE @PatLName CHAR(30);
        DECLARE @PatTaxID CHAR(11);
        DECLARE @PatAltID CHAR(20);
        DECLARE @PatSrcID CHAR(20);
        DECLARE @PatAddr1 CHAR(30);
        DECLARE @PatAddr2 CHAR(30);
        DECLARE @PatCity CHAR(20);
        DECLARE @PatState CHAR(2);
        DECLARE @PatZIP CHAR(10);
        DECLARE @PatCountry CHAR(3);
        DECLARE @PatID CHAR(20);
        DECLARE @PCPName CHAR(50);
        DECLARE @PCPNPID CHAR(10);
        DECLARE @PCPAltID CHAR(20);
        DECLARE @PCPID CHAR(20);
        DECLARE @SubFName CHAR(20);
        DECLARE @SubMI CHAR(1);
        DECLARE @SubLName CHAR(30);
        DECLARE @SubTaxID CHAR(11);
        DECLARE @SubAltID CHAR(20);
        DECLARE @SubSrcID CHAR(20);
        DECLARE @SubAddr1 CHAR(30);
        DECLARE @SubAddr2 CHAR(30);
        DECLARE @SubCity CHAR(20);
        DECLARE @SubState CHAR(2);
        DECLARE @SubZIP CHAR(10);
        DECLARE @SubCountry CHAR(3);
        DECLARE @SubID CHAR(20);
        DECLARE @GrpAltID CHAR(20);
        DECLARE @GrpName CHAR(50);
        DECLARE @GrpID CHAR(20);
        DECLARE @PlanName CHAR(30);
        DECLARE @PlanID CHAR(20);
        DECLARE @InsType CHAR(1);
        DECLARE @PlanType CHAR(3);
        DECLARE @XRays CHAR(1);
        DECLARE @ReceivedDate CHAR(10);
        DECLARE @SpecDeal CHAR(1);
        DECLARE @ClaimType CHAR(2);
        DECLARE @SpecType CHAR(2);
        DECLARE @sRemarks VARCHAR(100);
        DECLARE @ConfigName VARCHAR(50);
        DECLARE @LinkNo INT;
        DECLARE @RetVal INT;
        DECLARE @RetVal2 INT;
        DECLARE @Msg CHAR(64);
        DECLARE @SvcDate DATE;
        DECLARE @sSvcDate CHAR(10);
        DECLARE @DetID INT;
        DECLARE @CDT CHAR(5);
        DECLARE @Tooth CHAR(2);
        DECLARE @Surf CHAR(5);
        DECLARE @QD CHAR(5);
        DECLARE @COB DECIMAL(16, 2);
        DECLARE @SUBM DECIMAL(16, 2);
        DECLARE @ProcType CHAR(1);
        DECLARE @SWV_cursor_var1 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY--SET DEBUG has no equivalent in MSSQL
--set debug file to '/tmp/eclaim_preprocess.trc';

--TRACE statement has no equivalent in MSSQL
--trace on;

            SET LOCK_TIMEOUT 30000;
            SET @DT = GETDATE(); 
            SET @TD = CONVERT(DATE, @DT); 
            SELECT  @eClaimID = dbo.eclaim_h.eclaim_id ,
                    @ALTID = dbo.eclaim_h.alt_id ,
                    @DocNo = dbo.eclaim_h.document_no ,
                    @STAT = dbo.eclaim_h.status ,
                    @ErrCode = dbo.eclaim_h.error_code ,
                    @PreAuth = dbo.eclaim_h.preauth_switch ,
                    @Emerg = dbo.eclaim_h.emergency_switch ,
                    @PVNPID = dbo.eclaim_h.pv_np_id ,
                    @PVAltID = dbo.eclaim_h.pv_alt_id ,
                    @PVFName = dbo.eclaim_h.pv_f_name ,
                    @PVMI = dbo.eclaim_h.pv_mi ,
                    @PVLName = dbo.eclaim_h.pv_l_name ,
                    @PVTaxID = dbo.eclaim_h.pv_tax_id ,
                    @PVAddr1 = dbo.eclaim_h.pv_addr1 ,
                    @PVAddr2 = dbo.eclaim_h.pv_addr2 ,
                    @PVCity = dbo.eclaim_h.pv_city ,
                    @PVState = dbo.eclaim_h.pv_state ,
                    @PVZIP = dbo.eclaim_h.pv_zip ,
                    @PVCountry = dbo.eclaim_h.pv_country ,
                    @PVLicState = dbo.eclaim_h.pv_lic_state ,
                    @PVID = dbo.eclaim_h.pv_id ,
                    @PaySw = dbo.eclaim_h.pay_prv_switch ,
                    @FCName = dbo.eclaim_h.contr_fc_name ,
                    @FCNPID = dbo.eclaim_h.contr_fc_np_id ,
                    @FCAltID = dbo.eclaim_h.contr_fc_alt_id ,
                    @FCID = dbo.eclaim_h.contr_fc_id ,
                    @PatFName = dbo.eclaim_h.pat_f_name ,
                    @PatMI = dbo.eclaim_h.pat_mi ,
                    @PatLName = dbo.eclaim_h.pat_l_name ,
                    @PatTaxID = dbo.eclaim_h.pat_tax_id ,
                    @PatAltID = dbo.eclaim_h.pat_alt_id ,
                    @PatSrcID = dbo.eclaim_h.pat_source_id ,
                    @PatAddr1 = dbo.eclaim_h.pat_addr1 ,
                    @PatAddr2 = dbo.eclaim_h.pat_addr2 ,
                    @PatCity = dbo.eclaim_h.pat_city ,
                    @PatState = dbo.eclaim_h.pat_state ,
                    @PatZIP = dbo.eclaim_h.pat_zip ,
                    @PatCountry = dbo.eclaim_h.pat_country ,
                    @PatID = dbo.eclaim_h.patient_id ,
                    @PCPName = dbo.eclaim_h.pcp_name ,
                    @PCPNPID = dbo.eclaim_h.pcp_np_id ,
                    @PCPAltID = dbo.eclaim_h.pcp_alt_id ,
                    @PCPID = dbo.eclaim_h.pcp_id ,
                    @SubFName = dbo.eclaim_h.sub_f_name ,
                    @SubMI = dbo.eclaim_h.sub_mi ,
                    @SubLName = dbo.eclaim_h.sub_l_name ,
                    @SubTaxID = dbo.eclaim_h.sub_tax_id ,
                    @SubAltID = dbo.eclaim_h.sub_alt_id ,
                    @SubSrcID = dbo.eclaim_h.sub_source_id ,
                    @SubAddr1 = dbo.eclaim_h.sub_addr1 ,
                    @SubAddr2 = dbo.eclaim_h.sub_addr2 ,
                    @SubCity = dbo.eclaim_h.sub_city ,
                    @SubState = dbo.eclaim_h.sub_state ,
                    @SubZIP = dbo.eclaim_h.sub_zip ,
                    @SubCountry = dbo.eclaim_h.sub_country ,
                    @SubID = dbo.eclaim_h.subscriber_id ,
                    @GrpAltID = dbo.eclaim_h.group_alt_id ,
                    @GrpName = dbo.eclaim_h.group_name ,
                    @GrpID = dbo.eclaim_h.group_id ,
                    @PlanName = dbo.eclaim_h.plan_dsp_name ,
                    @PlanID = dbo.eclaim_h.plan_id ,
                    @InsType = dbo.eclaim_h.ins_type ,
                    @PlanType = dbo.eclaim_h.plan_type ,
                    @ReceivedDate = dbo.eclaim_h.received_date ,
                    @SpecDeal = dbo.eclaim_h.special_deal_flg ,
                    @ClaimType = dbo.eclaim_h.hmo_claim_type ,
                    @SpecType = dbo.eclaim_h.speciality_type
            FROM    dbo.eclaim_h (NOLOCK)
            WHERE   eclaim_id = @ID
                    AND status = 12  -- Needs Preprocessing
                    AND dds_claim_id = 0;
            IF @@rowcount = 0
                SELECT  @eClaimID = NULL ,
                        @ALTID = NULL ,
                        @DocNo = NULL ,
                        @STAT = NULL ,
                        @ErrCode = NULL ,
                        @PreAuth = NULL ,
                        @Emerg = NULL ,
                        @PVNPID = NULL ,
                        @PVAltID = NULL ,
                        @PVFName = NULL ,
                        @PVMI = NULL ,
                        @PVLName = NULL ,
                        @PVTaxID = NULL ,
                        @PVAddr1 = NULL ,
                        @PVAddr2 = NULL ,
                        @PVCity = NULL ,
                        @PVState = NULL ,
                        @PVZIP = NULL ,
                        @PVCountry = NULL ,
                        @PVLicState = NULL ,
                        @PVID = NULL ,
                        @PaySw = NULL ,
                        @FCName = NULL ,
                        @FCNPID = NULL ,
                        @FCAltID = NULL ,
                        @FCID = NULL ,
                        @PatFName = NULL ,
                        @PatMI = NULL ,
                        @PatLName = NULL ,
                        @PatTaxID = NULL ,
                        @PatAltID = NULL ,
                        @PatSrcID = NULL ,
                        @PatAddr1 = NULL ,
                        @PatAddr2 = NULL ,
                        @PatCity = NULL ,
                        @PatState = NULL ,
                        @PatZIP = NULL ,
                        @PatCountry = NULL ,
                        @PatID = NULL ,
                        @PCPName = NULL ,
                        @PCPNPID = NULL ,
                        @PCPAltID = NULL ,
                        @PCPID = NULL ,
                        @SubFName = NULL ,
                        @SubMI = NULL ,
                        @SubLName = NULL ,
                        @SubTaxID = NULL ,
                        @SubAltID = NULL ,
                        @SubSrcID = NULL ,
                        @SubAddr1 = NULL ,
                        @SubAddr2 = NULL ,
                        @SubCity = NULL ,
                        @SubState = NULL ,
                        @SubZIP = NULL ,
                        @SubCountry = NULL ,
                        @SubID = NULL ,
                        @GrpAltID = NULL ,
                        @GrpName = NULL ,
                        @GrpID = NULL ,
                        @PlanName = NULL ,
                        @PlanID = NULL ,
                        @InsType = NULL ,
                        @PlanType = NULL ,
                        @ReceivedDate = NULL ,
                        @SpecDeal = NULL ,
                        @ClaimType = NULL ,
                        @SpecType = NULL; -- This may change when updates are allowed

            IF @eClaimID IS NULL
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT('eClaim ID: ', @ID,
                                                 'cannot be processed');
                    RETURN;
                END;

            IF LEN(@ReceivedDate) = 0
                SET @ReceivedDate = @TD;

	-- Get AsOf Date
            SELECT  @sSvcDate = MIN(svc_date)
            FROM    dbo.eclaim_d (NOLOCK)
            WHERE   eclaim_id = @ID;
            IF @@rowcount = 0
                SELECT  @sSvcDate = NULL;
            IF ( @sSvcDate IS NULL
                 OR @sSvcDate = ''
               )
                SET @SvcDate = @TD;
            ELSE
                SET @SvcDate = CONVERT(DATE, @sSvcDate);

	-- Determine Group ID
            IF LEN(@GrpID) = 0
                OR ( @GrpID IS NULL
                     OR @GrpID = ''
                   )
                OR @GrpID = 0
                BEGIN
                    SET @GrpID = NULL;
                    IF LEN(@GrpAltID) > 0
                        BEGIN
                            EXECUTE dbo.getgroupbyalt @GrpAltID,
                                @RetVal OUTPUT, @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @GrpID = @RetVal;
                        END;
	
                    IF ( @GrpID IS NULL
                         OR @GrpID = ''
                       )
                        IF LEN(@GrpName) > 0
                            BEGIN
                                EXECUTE dbo.getgroupbyname @GrpName,
                                    @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @GrpID = @RetVal;
                            END;
		
	
                    IF ( @GrpID IS NULL
                         OR @GrpID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NGROUP' ,
                                    status = 0 ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @eClaimID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find Group information';
                            RETURN;
                        END;
                END;

            IF LEN(@PlanID) = 0
                OR @PlanID = 0
                OR ( @PlanID IS NULL
                     OR @PlanID = ''
                   )
                BEGIN
                    SET @PlanID = NULL;
                    IF LEN(@PlanName) > 0
                        BEGIN
                            EXECUTE dbo.getplanbyname @PlanName,
                                @RetVal OUTPUT, @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @PlanID = @RetVal;
                        END;
	
                    IF ( @PlanID IS NULL
                         OR @PlanID = ''
                       ) -- see if group has only 1 valid plan
                        BEGIN
                            IF @InsType = ''
                                SET @InsType = 'D';
		
                            EXECUTE dbo.getplan_grptyp @GrpID, @InsType,
                                @SvcDate, @RetVal OUTPUT, @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @PlanID = @RetVal;
                        END;
                END;

            IF ( @PlanID IS NULL
                 OR @PlanID = ''
               )
---  plan is still null see if you can determine Sub without it!
                BEGIN
                    IF LEN(@SubID) = 0
                        OR @SubID = 0
                        OR ( @SubID IS NULL
                             OR @SubID = ''
                           )
                        BEGIN
                            SET @SubID = NULL;
                            IF LEN(@SubSrcID) > 0
                                BEGIN
                                    EXECUTE dbo.getsubpl_srcgrptyp @SubSrcID,
                                        @GrpID, @InsType, @SvcDate,
                                        @RetVal OUTPUT, @RetVal2 OUTPUT,
                                        @Msg OUTPUT;
                                    IF @RetVal > 0
                                        SET @SubID = @RetVal;
			
                                    IF @RetVal2 > 0
                                        SET @PlanID = @RetVal2;
                                END;
                        END;
	
                    IF ( @SubID IS NULL
                         OR @SubID = ''
                       )
                        IF LEN(@SubTaxID) > 0
                            BEGIN
                                EXECUTE dbo.getsubpl_taxgrptyp @SubTaxID,
                                    @GrpID, @InsType, @SvcDate, @RetVal OUTPUT,
                                    @RetVal2 OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @SubID = @RetVal;
			
                                IF @RetVal2 > 0
                                    SET @PlanID = @RetVal2;
                            END;
		
	
                    IF ( @SubID IS NULL
                         OR @SubID = ''
                       )
                        IF LEN(@SubAltID) > 0
                            BEGIN
                                EXECUTE dbo.getsubpl_altgrptyp @SubTaxID,
                                    @GrpID, @InsType, @SvcDate, @RetVal OUTPUT,
                                    @RetVal2 OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @SubID = @RetVal;
			
                                IF @RetVal2 > 0
                                    SET @PlanID = @RetVal2;
                            END;
		
	
                    IF ( @SubID IS NULL
                         OR @SubID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NSUB' ,
                                    status = 0 ,
                                    group_id = @GrpID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @ID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find Plan information';
                            RETURN;
                        END;
	
                    IF ( @PlanID IS NULL
                         OR @PlanID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NPLAN' ,
                                    status = 0 ,
                                    group_id = @GrpID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @ID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find Plan information';
                            RETURN;
                        END;
                END;

--Now lets identify Sub from group and plan
            IF LEN(@SubID) = 0
                OR @SubID = 0
                OR ( @SubID IS NULL
                     OR @SubID = ''
                   )
                BEGIN
                    SET @SubID = NULL;
                    IF LEN(@SubSrcID) > 0
                        BEGIN
                            EXECUTE dbo.getsub_srcgrppln @SubSrcID, @GrpID,
                                @PlanID, @RetVal OUTPUT, @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @SubID = @RetVal;
                        END;
	
                    IF ( @SubID IS NULL
                         OR @SubID = ''
                       )
                        IF LEN(@SubTaxID) > 0
                            BEGIN
                                EXECUTE dbo.getsub_taxgrppln @SubTaxID, @GrpID,
                                    @PlanID, @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @SubID = @RetVal;
                            END;
		
	
                    IF ( @SubID IS NULL
                         OR @SubID = ''
                       )
                        IF LEN(@SubAltID) > 0
                            BEGIN
                                EXECUTE dbo.getsub_altgrppln @SubAltID, @GrpID,
                                    @PlanID, @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @SubID = @RetVal;
                            END;
		
	
                    IF ( @SubID IS NULL
                         OR @SubID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NSUB' ,
                                    status = 0 ,
                                    group_id = @GrpID ,
                                    plan_id = @PlanID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @ID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find Sub information';
                            RETURN;
                        END;
                END;

--- At this point we should have group, plan and subscriber ids
--- get patient info
            IF LEN(@PatID) = 0
                OR @PatID = 0
                OR ( @PatID IS NULL
                     OR @PatID = ''
                   )
                BEGIN
                    SET @PatID = NULL;
                    IF LEN(@PatSrcID) > 0
                        BEGIN
                            EXECUTE dbo.getpat_srcgrpplnsb @PatSrcID, @GrpID,
                                @PlanID, @SubID, @RetVal OUTPUT, @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @PatID = @RetVal;
                        END;
	
                    IF ( @PatID IS NULL
                         OR @PatID = ''
                       )
                        IF LEN(@PatTaxID) > 0
                            BEGIN
                                EXECUTE dbo.getpat_taxgrpplnsb @PatTaxID,
                                    @GrpID, @PlanID, @SubID, @RetVal OUTPUT,
                                    @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @PatID = @RetVal;
                            END;
		
	
                    IF ( @PatID IS NULL
                         OR @PatID = ''
                       )
                        IF LEN(@PatAltID) > 0
                            BEGIN
                                EXECUTE dbo.getpat_altgrpplnsb @PatAltID,
                                    @GrpID, @PlanID, @SubID, @RetVal OUTPUT,
                                    @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @PatID = @RetVal;
                            END;
		
	
                    IF ( @PatID IS NULL
                         OR @PatID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NPAT' ,
                                    status = 0 ,
                                    group_id = @GrpID ,
                                    plan_id = @PlanID ,
                                    subscriber_id = @SubID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @ID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find Patient information';
                            RETURN;
                        END;
                END;

            IF @PlanID > 0
                EXECUTE dbo.getplaninfo @PlanID, @RetVal OUTPUT,
                    @PlanName OUTPUT, @InsType OUTPUT, @PlanType OUTPUT;

            IF @PlanID <= 0
                OR @RetVal <= 0
                BEGIN
                    UPDATE  dbo.eclaim_h
                    SET     error_code = 'N???' ,
                            status = 0 ,
                            group_id = @GrpID ,
                            subscriber_id = @SubID ,
                            patient_id = @PatID ,
                            h_user = ORIGINAL_LOGIN() ,
                            h_datetime = GETDATE()
                    WHERE   eclaim_id = @ID;
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = 'Lost Plan info!!';
                    RETURN;
                END; --- This should never happen!!

            IF @PlanType = 'HMO' -- Need to get PCP info
                IF LEN(@PCPID) = 0
                    OR ( @PCPID IS NULL
                         OR @PCPID = ''
                       )
                    OR @PCPID = 0
                    BEGIN
                        SET @PCPID = NULL;
                        IF LEN(@PCPNPID) > 0
                            BEGIN
                                EXECUTE dbo.getfc_npid @PCPNPID,
                                    @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @PCPID = @RetVal;
                            END;
		
                        IF ( @PCPID IS NULL
                             OR @PCPID = ''
                           )
                            IF LEN(@PCPAltID) > 0
                                BEGIN
                                    EXECUTE dbo.getfc_altid @PCPAltID,
                                        @RetVal OUTPUT, @Msg OUTPUT;
                                    IF @RetVal > 0
                                        SET @PCPID = @RetVal;
                                END;
			
		
                        IF ( @PCPID IS NULL
                             OR @PCPID = ''
                           ) -- try to get from data already determined
                            BEGIN
                                EXECUTE dbo.getpcp_subpatgrppl @SubID, @PatID,
                                    @GrpID, @PlanID, @SvcDate, @RetVal OUTPUT,
                                    @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @PCPID = @RetVal;
                            END;
		
                        IF ( @PCPID IS NULL
                             OR @PCPID = ''
                           )
                            BEGIN
                                UPDATE  dbo.eclaim_h
                                SET     error_code = 'NPCP' ,
                                        status = 0 ,
                                        group_id = @GrpID ,
                                        plan_id = @PlanID ,
                                        subscriber_id = @SubID ,
                                        patient_id = @PatID ,
                                        h_user = ORIGINAL_LOGIN() ,
                                        h_datetime = GETDATE()
                                WHERE   eclaim_id = @ID;
                                SET @SWP_Ret_Value = -1;
                                SET @SWP_Ret_Value1 = 'Cannot find PCP information';
                                RETURN;
                            END;
                    END;
	

            IF ( LEN(@FCID) = 0
                 OR ( @FCID IS NULL
                      OR @FCID = ''
                    )
                 OR @FCID = 0
               )
                AND ( LEN(@FCNPID) > 0
                      OR LEN(@FCAltID) > 0
                    )
	 -- FC optional only search if key value is populated
                BEGIN
                    SET @FCID = NULL;
                    IF LEN(@FCNPID) > 0
                        BEGIN
                            EXECUTE dbo.getfc_npid @FCNPID, @RetVal OUTPUT,
                                @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @FCID = @RetVal;
                        END;
	
                    IF ( @FCID IS NULL
                         OR @FCID = ''
                       )
                        IF LEN(@FCAltID) > 0
                            BEGIN
                                EXECUTE dbo.getfc_altid @FCAltID,
                                    @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @FCID = @RetVal;
                            END;
		
	
                    IF ( @FCID IS NULL
                         OR @FCID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NFC' ,
                                    status = 0 ,
                                    group_id = @GrpID ,
                                    plan_id = @PlanID ,
                                    subscriber_id = @SubID ,
                                    patient_id = @PatID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @ID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find Facility information';
                            RETURN;
                        END;
                END;

            IF ( LEN(@PVID) = 0
                 OR ( @PVID IS NULL
                      OR @PVID = ''
                    )
                 OR @PVID = 0
               )
                AND ( LEN(@PVNPID) > 0
                      OR LEN(@PVAltID) > 0
                      OR LEN(@PVTaxID) > 0
                    )
 -- PV is optional only search if key value is populated
                BEGIN
                    SET @PVID = NULL;
                    IF LEN(@PVNPID) > 0
                        BEGIN
                            EXECUTE dbo.getpv_npid @PVNPID, @RetVal OUTPUT,
                                @Msg OUTPUT;
                            IF @RetVal > 0
                                SET @PVID = @RetVal;
                        END;
	
                    IF ( @PVID IS NULL
                         OR @PVID = ''
                       )
                        IF LEN(@PVAltID) > 0
                            BEGIN
                                EXECUTE dbo.getpv_altid @PVAltID,
                                    @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @PVID = @RetVal;
                            END;
		
	
                    IF ( @PVID IS NULL
                         OR @PVID = ''
                       )
                        IF LEN(@PVTaxID) > 0
                            BEGIN
                                EXECUTE dbo.getpv_taxid @PVTaxID,
                                    @RetVal OUTPUT, @Msg OUTPUT;
                                IF @RetVal > 0
                                    SET @PVID = @RetVal;
                            END;
		
	
                    IF ( @PVID IS NULL
                         OR @PVID = ''
                       )
                        BEGIN
                            UPDATE  dbo.eclaim_h
                            SET     error_code = 'NPV' ,
                                    status = 0 ,
                                    group_id = @GrpID ,
                                    plan_id = @PlanID ,
                                    subscriber_id = @SubID ,
                                    patient_id = @PatID ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_id = @ID;
                            SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = 'Cannot find provider information';
                            RETURN;
                        END;
                END;

-- Now lets validate service lines
            SELECT  @DCnt = COUNT(*)
            FROM    dbo.eclaim_d
            WHERE   eclaim_id = @ID
                    AND error_code != 'IGNORE';
            SELECT  @NoDateCnt = COUNT(*)
            FROM    dbo.eclaim_d (NOLOCK)
            WHERE   eclaim_id = @ID
                    AND error_code != 'IGNORE'
                    AND ( ( svc_date IS NULL
                            OR svc_date = ''
                          )
                          OR LEN(svc_date) = 0
                        );
            IF @NoDateCnt > 0
                AND @NoDateCnt != @DCnt
                BEGIN
                    UPDATE  dbo.eclaim_h
                    SET     status = 0 ,
                            error_code = 'PREAUTHERR' ,
                            pv_id = @PVID ,
                            contr_fc_id = @FCID ,
                            patient_id = @PatID ,
                            pcp_id = @PCPID ,
                            subscriber_id = @SubID ,
                            group_id = @GrpID ,
                            plan_id = @PlanID ,
                            ins_type = @InsType ,
                            plan_type = @PlanType ,
                            h_user = ORIGINAL_LOGIN() ,
                            h_datetime = GETDATE()
                    WHERE   eclaim_id = @ID;
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = 'Some service lines have dates and others dont';
                    RETURN;
                END;

            IF @NoDateCnt > 0
                SET @PreAuth = 'Y';
            ELSE
                SET @PreAuth = 'N';

            SET @NumErrors = 0;
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_d_id, svc_date, d_proc_code, tooth_no, surface,
	     quad, cob_amt, submitted_amt
	  
      FROM dbo.eclaim_d (NOLOCK) WHERE eclaim_id = @ID AND error_code != 'IGNORE';
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @DetID, @SvcDate, @CDT,
                @Tooth, @Surf, @QD, @COB, @SUBM;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    SET @ProcType = NULL;
                    SET @ErrCode = '';
                    SELECT  @ProcType = relates_to
                    FROM    dbo.plx_dent_proc (NOLOCK)
                    WHERE   d_proc_code = @CDT;
                    IF @@rowcount = 0
                        SELECT  @ProcType = NULL;
                    IF ( @ProcType IS NULL
                         OR @ProcType = ''
                       )
                        SET @ErrCode = 'BADPROC';
	
                    IF @ProcType = 'P'
                        BEGIN
                            UPDATE  dbo.eclaim_d
                            SET     error_code = 'OK' ,
                                    h_user = ORIGINAL_LOGIN() ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_d_id = @DetID;
                            GOTO SWL_Label2;
                        END;
	
                    IF @ProcType = 'T'
                        IF ( @Tooth IS NULL
                             OR @Tooth = ''
                           )
                            OR LEN(@Tooth) = 0
                            SET @ErrCode = 'TOOTH';
		
	
                    IF @ProcType = 'S'
                        BEGIN
                            IF ( @Tooth IS NULL
                                 OR @Tooth = ''
                               )
                                OR LEN(@Tooth) = 0
                                SET @ErrCode = 'TOOTH';
		
                            IF ( @Surf IS NULL
                                 OR @Surf = ''
                               )
                                OR LEN(@Surf) = 0
                                SET @ErrCode = 'SURF';
                        END;
	
                    IF @ProcType = 'Q'
                        IF ( @QD IS NULL
                             OR @QD = ''
                           )
                            OR LEN(@QD) = 0
                            SET @ErrCode = 'QUAD';
		
	
                    IF @ErrCode = ''
                        SET @ErrCode = 'OK';
                    ELSE
                        SET @NumErrors = @NumErrors + 1;
	
                    UPDATE  dbo.eclaim_d
                    SET     error_code = @ErrCode ,
                            h_user = ORIGINAL_LOGIN() ,
                            h_datetime = GETDATE()
                    WHERE   eclaim_d_id = @DetID;
                    SWL_Label2:
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @DetID, @SvcDate,
                        @CDT, @Tooth, @Surf, @QD, @COB, @SUBM;
                END;
            CLOSE @SWV_cursor_var1;
            IF @NumErrors > 0
                SET @ErrCode = 'PART';
            ELSE
                SET @ErrCode = '';

            UPDATE  dbo.eclaim_h
            SET     status = 0 ,
                    error_code = @ErrCode ,
                    pv_id = @PVID ,
                    contr_fc_id = @FCID ,
                    patient_id = @PatID ,
                    pcp_id = @PCPID ,
                    subscriber_id = @SubID ,
                    group_id = @GrpID ,
                    plan_id = @PlanID ,
                    ins_type = @InsType ,
                    plan_type = @PlanType ,
                    h_user = ORIGINAL_LOGIN() ,
                    h_datetime = GETDATE()
            WHERE   eclaim_id = @ID;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = 'Process Complete';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

----------------------------------------------------------------------

    END;