﻿CREATE PROCEDURE [dbo].[dlp_member]
    @a_batch_id INT ,
    @a_tl_sir_id INT ,
    @a_has_address CHAR(1) ,
    @a_user CHAR(20) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 DATETIME = NULL OUTPUT
    
	

-- DATE: 12/04/96


--	IF tl_log_error(t_tl_sir_id, n_return_code) != 0 THEN
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:23:23 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

















000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_ext_id CHAR(20);
        DECLARE @n_ext_id_col CHAR(20);
        DECLARE @n_ext_id_type INT;
        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);
        DECLARE @d_address_id INT;
        DECLARE @n_fatal INT;
        DECLARE @n_count INT;
        DECLARE @n_tmp_zip CHAR(9);

DECLARE @t_tl_sir_id		integer;
DECLARE @t_tl_sub_sir_id	integer;
DECLARE @t_subscriber		char(2);
DECLARE @t_alt_id			char(20);
DECLARE @t_sub_ssn		char(11);
DECLARE @t_new_ssn		char(11);
DECLARE @t_subnew_ssn		char(11);
DECLARE @t_ssn			char(11);
DECLARE @t_sub_alt_id		char(20);
DECLARE @t_src_id		char(20);
DECLARE @t_subsrc_id		char(20);
DECLARE @t_member_id	integer;
DECLARE @t_sub_id			integer;
DECLARE @t_group_id		integer;
DECLARE @t_member_code	char(2);
DECLARE @t_plan_id		integer;
DECLARE @t_facility_id		integer;
DECLARE @t_type			char(2);
DECLARE @t_last_name		char(15);
DECLARE @t_first_name		char(15);
DECLARE @t_middle_init		char(1);
DECLARE @t_date_of_birth	date;
DECLARE @t_student_flag	char(1);
DECLARE @t_disable_flag	char(1);
DECLARE @t_cobra_flag		char(1);
DECLARE @t_action_code	char(2);
DECLARE @t_address1		char(30);
DECLARE @t_address2		char(30);
DECLARE @t_city			char(30);
DECLARE @t_state			char(2);
DECLARE @t_zip			char(5);
DECLARE @t_zipx			char(4);
DECLARE @t_home_phone	char(10);
DECLARE @t_home_ext		char(4);
DECLARE @t_work_phone	char(10);
DECLARE @t_work_ext		char(4);
DECLARE @t_rate_code		char(2);
DECLARE @t_plan_eff_date	date;
DECLARE @t_plan_term_date	date;
DECLARE @t_rate_eff_date	date;
DECLARE @t_status			char(1);
DECLARE @t_paperless		char(1);
DECLARE @t_email			char(100);
DECLARE @t_ext_id_col		char(20);
DECLARE @t_def_ext_id_col char(20);
DECLARE @t_def_ext_id_type integer ;

DECLARE @n_msi	integer;
DECLARE @msi_upper integer;
DECLARE @n_datetime	datetime2(2)

   
	-- Unexpected database error
	
--	END IF
        SET NOCOUNT ON;
        SET @t_tl_sir_id =0;
       
        SET @t_tl_sub_sir_id =0;
       
        SET @t_subscriber ='';
        
        SET @t_alt_id ='';
     
        SET @t_sub_ssn ='';
        
        SET @t_new_ssn ='';
     
        SET @t_subnew_ssn ='';
       
        SET @t_ssn ='';
       
        SET @t_sub_alt_id ='';
       
        SET @t_src_id ='';
       
        SET @t_subsrc_id ='';
     
        SET @t_member_id =0;
       
        SET @t_sub_id =0;
        
        SET @t_group_id =0;
       
        SET @t_member_code ='';
       
        SET @t_plan_id =0;
       
        SET @t_facility_id =0;
     
        SET @t_type ='';
        
        SET @t_last_name ='';
        
        SET @t_first_name ='';
       
        SET @t_middle_init ='';
      
        SET @t_date_of_birth = NULL;
       
        SET @t_student_flag ='';
     
        SET @t_disable_flag ='';
     
        SET @t_cobra_flag ='';
        
        SET @t_action_code ='';
       
        SET @t_address1 ='';
      
        SET @t_address2 ='';
  
        SET @t_city ='';
       
        SET @t_state ='';
       
        SET @t_zip ='';
     
        SET @t_zipx ='';
      
        SET @t_home_phone ='';
 
SET @t_home_ext ='';
 
       SET @t_work_phone ='';
     
        SET @t_work_ext ='';
     
        SET @t_rate_code ='';
   
        SET @t_plan_eff_date = NULL;
      
        SET @t_plan_term_date = NULL;
     
        SET @t_rate_eff_date = NULL;
       
        SET @t_status ='';
    
        SET @t_paperless ='';
       
        SET @t_email ='';
       
        SET @t_ext_id_col ='';
       
        SET @t_def_ext_id_col ='';
     
        SET @t_def_ext_id_type =0;
    
        SET @n_msi =0;
       
        SET @msi_upper =0;
       
        SET @n_datetime = NULL;
       
        BEGIN TRY
           
		    SELECT @t_tl_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_tl_sir_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_tl_sub_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_tl_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 4
			
			SELECT @t_member_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_facility_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 4

			SELECT @t_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_action_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_action_code' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_plan_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_plan_term_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @n_datetime = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_datetime' and  BatchId = @a_batch_id AND Module_Id = 4
			
			SELECT @t_status = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_status' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_new_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_new_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_subnew_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subnew_ssn' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_src_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_src_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_subsrc_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subsrc_id' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_ext_id_col = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_def_ext_id_col = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_def_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @n_msi = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_def_ext_id_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_def_ext_id_type' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_email = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_email' and  BatchId = @a_batch_id AND Module_Id = 4
			SELECT @t_paperless = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_paperless' and  BatchId = @a_batch_id AND Module_Id = 4

			

            IF ( ( @t_last_name IS NULL
                   OR @t_last_name = ''
                 )
                 OR LEN(@t_last_name) = 0
               )
                RAISERROR('Null Last Name',16,1);

           
            IF ( ( @t_first_name IS NULL
                   OR @t_first_name = ''
                 )
                 OR LEN(@t_first_name) = 0
               )
                RAISERROR('Null First Name',16,1);


--if (t_alt_id is null or length(t_alt_id) = 0) then
--	RAISE EXCEPTION -746, 203, "Null member alt_id";
--end if

--if (t_sub_alt_id is null or length(t_sub_alt_id) = 0) then
--	RAISE EXCEPTION -746, 204, "Null family alt_id";
--end if

            
            IF ( ( @t_sub_ssn IS NULL
                   OR @t_sub_ssn = ''
                 )
                 OR LEN(@t_sub_ssn) = 0
               )
                RAISERROR('Null subscriber''s SSN',16,1);

           
            IF ( ( @t_member_code IS NULL
                   OR @t_member_code = ''
                 )
                 OR LEN(@t_member_code) = 0
               )
                RAISERROR('Null member code',16,1);

          
            IF ( @t_date_of_birth IS NULL )
                RAISERROR('Null member date of birth',16,1);

            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.mbr_code (NOLOCK)
                            WHERE   @t_member_code = mbr_code )
                RAISERROR('Invalid member code',16,1);

          
            IF ( (@t_disable_flag IS NULL
                 OR @t_disable_flag = '')
               )
                BEGIN
                    SET @t_disable_flag = 'N';
                   
                END;
            ELSE
                BEGIN
                    
                    IF @t_disable_flag NOT IN ( 'Y', 'N' )
                        BEGIN
                            SET @t_disable_flag = 'N' ;
                            
                        END;
                END;

           
            IF ( (@t_student_flag IS NULL
                 OR @t_student_flag = '')
               )
                BEGIN
                    SET @t_student_flag = 'N' ;
                   
                END;
            ELSE
                BEGIN
                 
                    IF @t_student_flag NOT IN ( 'Y', 'N' )
                        BEGIN
                            SET @t_student_flag = 'N';
                           
                        END;
                END;

           
            IF ( ( @t_ext_id_col IS NULL
                   OR @t_ext_id_col = ''
          )
                 OR LEN(@t_ext_id_col) = 0
               )
                BEGIN
              
                    SET @t_ext_id_col = @t_def_ext_id_col;
 
               SET @n_ext_id_type = @t_def_ext_id_type;
                END;
            ELSE
 BEGIN
                 SELECT  @n_ext_id_type = int_1
                    FROM    dbo.typ_table_exp t (NOLOCK)
                    WHERE   t.subsys_code = 'MB'
                            AND t.tab_name = 'ext_id_type'
                            AND t.str_1 = @t_ext_id_col; 
 
                END;

           
            IF ( (@t_paperless IS NOT NULL
            AND @t_paperless <> '')
               )
                BEGIN
                  
                    IF ( @t_paperless = '1'
                         OR @t_paperless = 'y'
                       )
                        BEGIN
                            SET @t_paperless = 'Y' ;
                          
                        END;
	
                  
                    IF ( @t_paperless = '0'
                         OR @t_paperless = 'n'
                       )
                        BEGIN
                            SET @t_paperless = 'N';
                          
                        END;
	
                    
                    IF @t_paperless NOT IN ( 'Y', 'N' )
                        BEGIN
                            SET @t_paperless = 'N' ;
                           
                        END;
                END;
            ELSE -- is null
                BEGIN
                    SET @t_paperless = 'N' ;
                    
                END;

           
            IF @t_subscriber = '00'
                BEGIN
                    
                    IF @t_member_code NOT IN ( '10', '20' )
                        OR @t_alt_id != @t_sub_alt_id
                        RAISERROR('Mismatched member code, alt_id',16,1);

                    IF @t_ext_id_col = 'new_ssn'
                        BEGIN
                           
                            SET @n_ext_id = @t_subnew_ssn;
                        END;
                    ELSE
                        BEGIN
                         
                  IF @t_ext_id_col = 'alt_id'
                                BEGIN
                                
                                    SET @n_ext_id = @t_sub_alt_id;
                                END;
                            ELSE
                                BEGIN
                                  
                                    IF @t_ext_id_col = 'source_id'
                                        BEGIN
                                            
                                            SET @n_ext_id = @t_subsrc_id;
                                        END;
                                    ELSE
                                        BEGIN
                                           
                                            IF @t_ext_id_col = 'member_id'
                                                SET @n_ext_id = '-1';
                                      ELSE
               RAISERROR('Invalid External ID value',16,1);
                                        END;
                                END;
                        END;
                END;
            ELSE

	/*20120803$$ks - do not require alt_id if none is provided (API change) */
                BEGIN
                  
                    IF @t_member_code NOT IN ( '30', '40', '50', '70' )
                        OR ( @t_alt_id != ''
                             AND @t_sub_alt_id != ''
                             AND @t_alt_id = @t_sub_alt_id
                           )
                        RAISERROR('Mismatched member code, alt_id',16,1);
	
                    
                    IF @t_sub_id IS NULL
		-- only will get subscriber id if subscriber is also new sub.
                        BEGIN
                            SELECT  @n_count = COUNT(*)
                           FROM    dbo.member (NOLOCK)
       WHERE   member_ssn = @t_ssn
                                    AND member_id = family_id;
                     IF @n_count > 1
                                RAISERROR('Dependent has multiple subscribers by SSN',16,1);
                        END;
	
                    SELECT  @t_sub_id = m.member_id ,
                            @n_ext_id_type = m.ext_id_type ,
                            @n_ext_id_col = t.str_1
                    FROM    dbo.member m (NOLOCK),
                            dbo.typ_table_exp t (NOLOCK)
                    WHERE   m.member_ssn = @t_sub_ssn
                            AND m.member_id = family_id
                            AND t.subsys_code = 'MB'
                            AND t.tab_name = 'ext_id_type'
                            AND t.int_1 = m.ext_id_type; 
                  
                    IF @t_sub_id IS NULL
                        RAISERROR('Dependent''s subscriber not found by SSN',16,1);
	
                    IF @t_ext_id_col != @n_ext_id_col --Sub has diff type as sys default
                        BEGIN
                            SET @t_ext_id_col = @n_ext_id_col ;
                         
                        END;
	
                   
                    IF @t_ext_id_col = 'new_ssn'
                        BEGIN
                            
                            SET @n_ext_id = @t_new_ssn;
                        END;
                    ELSE
                        BEGIN
                          
                            IF @t_ext_id_col = 'alt_id'
                                BEGIN
                                  
                                    SET @n_ext_id = @t_alt_id;
                                END;
                            ELSE
                                BEGIN
                                  
                                    IF @t_ext_id_col = 'source_id'
                                        BEGIN
                                           
                                            SET @n_ext_id = @t_src_id;
                                      END;
                                    ELSE
                                        BEGIN
                                          
                                            IF @t_ext_id_col = 'member_id'
                                                SET @n_ext_id = '-1';
                                            ELSE
                                                RAISERROR('Invalid External ID value',16,1);
                                        END;
                                END;
                        END;
                END;

            IF @t_subscriber = '00'
	/*
	Only allow one unique individual in the member table as a subscriber.
	This one, unique individual can become associated with one or more group-plan
	combinations as well as with one or more group-plan combinations offered for
	different clients (such as both the clients, NRHA and KP, as one hypothetical
	example).
	*/
                BEGIN
                    SELECT  @t_member_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_ssn = @t_sub_ssn
                            AND last_name = @t_last_name
                            AND first_name = @t_first_name
                            AND member_code IN ( '10', '20' );
                   
                END;
            ELSE
	/*
	A unique individual is allowed to be in the member table as a dependent
	even if this individual already exists in the member table as a subscriber.
	
	A unique individual is allowed to be in the member table as a dependent
	more than once.  But, for all such entries in the member table, the
	family_id should be unique.  Because the input SIR file-like record
	does not have a concept of subscriber's member_id (or dependent's family_id),
	we look at the subscriber's SSN to see if it already exists as a parent
	of this potential new dependent.  This appears to be a valid way to proceed
	because every row in the member table always has .member_ssn populated,
	and the same goes for field .family_id.
	* /
	
	/ *
	It is difficult for me to fool DataLoad into creating a "DA" (dependent add)
	situation when the dependent already exists in the member table and is
	associated with a particular subscriber.  So, one can test the SQL in
	stand-alone mode using informix dbaccess and the following script which tests
	for a son:
	First name:      'Autaaaaq'
	Middle Initial:  'S'
	Last name:       'Maticaaaap'
	Date of Birth:   '02/01/1998'

	And, if you change the line to this:
	
	and member_sub.member_ssn = '001-42-0918'
	
	which at this time is an SSN which is not in our system, the query will
	return a count of zero.
	
	But, if you change it to this:
	
	and member_sub.member_ssn = '001-01-0065'
	
	the query will return count as one, because this son as a dependent is
	already a dependent for father with SSN of 001-01-0065.
	
	select count(*)
	from member as member_dep, member as member_sub
	where
	member_dep.family_id = member_sub.member_id
	and member_sub.member_id = member_sub.family_id
	and member_dep.member_id != member_sub.member_id
	and member_sub.member_ssn = '001-01-0065'
	and member_dep.member_ssn = '001-01-0064'
	and member_dep.last_name = 'Maticaaaap'
	and member_dep.first_name = 'Autaaaaq'
	and member_dep.member_code not in ('10', '20')
	and member_dep.date_of_birth = '02/01/1998'
	;
	*/
                BEGIN
                    DECLARE @loc_count INT;
                    SET @loc_count = NULL;
                   
                    IF ( (@t_sub_ssn IS NOT NULL
                         )
                       )
                        BEGIN
                            SELECT  @loc_count = COUNT(*)
                            FROM    dbo.member AS member_dep (NOLOCK) ,
                                    dbo.member AS member_sub (NOLOCK)
                            WHERE   member_dep.family_id = member_sub.member_id
                                    AND member_sub.member_id = member_sub.family_id
                                    AND member_dep.member_id != member_sub.member_id
                                    AND member_sub.member_ssn = @t_sub_ssn
                                    AND member_dep.member_ssn = @t_ssn
                                    AND member_dep.last_name = @t_last_name
                                    AND member_dep.first_name = @t_first_name
			/*
						Esayas would like to see the test for the middle initial removed.
						This often results in the same unique dependent being added as a
						dependent to the same subscriber more than once, simply because
						the middle initial is absent or it is the incorrect middle initial.
						
						and (
							((t_middle_init is null OR length(t_middle_init) = 0)
							and (length(member_dep.middle_init) = 0 OR member_dep.middle_init is null))
							OR (t_middle_init is not null and member_dep.middle_init = t_middle_init)
							)
			 */
                                    AND member_dep.member_code NOT IN ( '10',
                                                              '20' )
                                    AND member_dep.date_of_birth = @t_date_of_birth;
                            IF ( @loc_count IS NULL
                                 OR @loc_count = 0
                               )
                                BEGIN
                                    SET @t_member_id = NULL;
                                    
                                END;	--No records were found.
                            ELSE
                                BEGIN
               SET @t_member_id =0;
                                    
          END;	--Some non-null value.  This dependent already exists in a
										--relationship with the given subscriber.
			
                     END;
                    ELSE
                        BEGIN
			/*
				Since the member table always has the SSN fields populated,
				it would probably be more accurate simply to throw an illegal state
				exception here if t_sub_ssn was SQL NULL.
			 * /
				
			/ *
				Raising an exception would be more to the point here.  Need to
				determine what code to use.  For instance, code "212" is already
				in use.  I've used code zero, as this is a generic user defined
				exception.
			 */
				
                            RAISERROR('IllegalStateException:  dlp_member():  t_sub_ssn cannot be SQL NULL',16,1);
                        END;
		
                END;

           
            IF @t_member_id IS NOT NULL
--	RAISE EXCEPTION -746, 212, "Member already exists";
/* 20131222$$ks - member may have been added by previous SA for diff Grp-Plan
 * need to get member_id and return to main program
 */
                BEGIN
                   
                    IF @t_subscriber = '00'
                 BEGIN
                            SET @t_sub_id = NULL;
                            
                            SELECT  @t_sub_id = m.member_id
                            FROM    dbo.member m (NOLOCK)
                            WHERE   m.member_ssn = @t_sub_ssn
                                    AND m.member_id = family_id
/* 20160107$$ks  ssn, lname, fname, mbrcode and dob should be sufficient - alt might differ
 *		and ((m.alt_id is not null and m.alt_id != "" 
 *			and t_alt_id is not null and t_alt_id != "" and m.alt_id = t_alt_id)
 */
                                    AND m.last_name = @t_last_name
                                    AND m.first_name = @t_first_name
                                    AND m.date_of_birth = @t_date_of_birth
                                    AND m.member_code = @t_member_code;
                                                       
                            SET @t_member_id = @t_sub_id;
                           
       END;
                    ELSE  -- dependent
                        BEGIN
                            SELECT  @t_member_id = member_dep.member_id
                            FROM    dbo.member AS member_dep (NOLOCK),
                                    dbo.member AS member_sub (NOLOCK)
                            WHERE   member_dep.family_id = member_sub.member_id
                                    AND member_sub.member_id = member_sub.family_id
                                    AND member_dep.member_id != member_sub.member_id
                                    AND member_sub.member_ssn = @t_sub_ssn
                                    AND member_dep.member_ssn = @t_ssn
                                    AND member_dep.last_name = @t_last_name
                                    AND member_dep.first_name = @t_first_name
                                    AND member_dep.member_code NOT IN ( '10',
                                                              '20' )
                                    AND member_dep.date_of_birth = @t_date_of_birth;
                           
                        END;
	
                    
                    IF @t_member_id IS NOT NULL
                        BEGIN
                            SET @SWP_Ret_Value = 1;
                           
                            SET @SWP_Ret_Value1 = @n_msi + 1;
                           
                            SET @SWP_Ret_Value2 = @n_datetime;
							
							update dbo.GlobalVar set VarValue =@t_sub_id where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
							update dbo.GlobalVar set VarValue =@t_member_id where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4
							update dbo.GlobalVar set VarValue =@SWP_Ret_Value1 where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4
						RETURN;
                        END;
  ELSE
                        BEGIN
                            SET @SWP_Ret_Value = -1;
                          
                            SET @SWP_Ret_Value1 = @n_msi;
                            
                            SET @SWP_Ret_Value2 = @n_datetime;
                            RETURN;
                        END;
       END;


--UPDATE sysdatetime SET msi = msi + 1;
          
            SET @n_msi = @n_msi + 1;
            
            IF @t_subscriber = '00'
       BEGIN
      
                    IF ( @t_subsrc_id IS NULL
                         
                       )
                        BEGIN
                            SET @t_subsrc_id ='';
                          
                        END;
	
                   
                    IF ( @t_subnew_ssn IS NULL
                        
                       )
                        BEGIN
                            SET @t_subnew_ssn ='';
                          
                        END;
	
                    INSERT  INTO dbo.member
                            ( family_id ,
                              alt_id ,
                              member_code ,
                              first_name ,
                              middle_init ,
                              last_name ,
                              date_of_birth ,
                              member_ssn ,
                              oed ,
                              disable_flag ,
                              student_flag ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user ,
                              ext_id_type ,
                              new_ssn ,
                              source_id ,
                              paperless
                            )
                    VALUES  ( 0 ,
                              @t_alt_id ,
                              @t_member_code ,
                              @t_first_name ,
                              @t_middle_init ,
                              @t_last_name ,
                              @t_date_of_birth ,
                              @n_ext_id ,
                              @t_plan_eff_date ,
                              @t_disable_flag ,
                              @t_student_flag ,
                              'SA' ,
                              'SA' ,
                              @n_msi ,
                              @n_datetime ,
                              @a_user ,
                              @n_ext_id_type ,
                              @t_subnew_ssn ,
                              @t_subsrc_id ,
                              @t_paperless
                            );
	
                    SELECT  @t_member_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   h_msi = @n_msi;
                    
                    SET @t_sub_id = @t_member_id;

                    UPDATE  dbo.member
                    SET     family_id = @t_member_id
                    WHERE   member_id = @t_member_id;


                    
                    IF @t_ext_id_col = 'member_id'
                        BEGIN
                           
                            SET @n_ext_id = @t_sub_id;

                            UPDATE  dbo.member
                            SET     member_ssn = @t_ssn--@n_ext_id
                            WHERE   member_id = @t_member_id;
                        END;
	
                    IF @a_has_address = 'Y'
                        BEGIN
                            
                            IF ( @t_zipx IS NULL
                                 
              )
                                OR LEN(@t_zipx) = 0
                           BEGIN
                                  
                              SET @n_tmp_zip = @t_zip;
                                END;
                            ELSE
                                BEGIN

                      SET @n_tmp_zip = @t_zip + @t_zipx;
               END;
		
                          
          EXECUTE  @n_return_code = dbo.dlp_mbaddr @a_batch_id,
                                       @t_tl_sir_id,
                          @t_member_id,
                                                              @t_address1,
                                                              @t_address2,
                                                              @t_city,
															  @t_state,
                                                              @n_tmp_zip,
                                                              @t_home_phone,
                                                              @t_home_ext,
                                                              @t_work_phone,
                                                              @t_work_ext;
                            IF @n_return_code < 0
                                BEGIN
                                    SET @SWP_Ret_Value = @n_return_code;
                                    SET @SWP_Ret_Value1 = NULL;
                                    SET @SWP_Ret_Value2 = NULL;
                                    RETURN;
                                END;
		
                            SET @d_address_id = 0;
                            SELECT  @d_address_id = address_id
                            FROM    dbo.address (NOLOCK)
                            WHERE   subsys_code = 'MB'
                                    AND sys_rec_id = @t_member_id
                                    AND addr_type = 'L';
                           
		 
		 -- When all procedures calling dlp_mbaddr are modified then move code below to dlp_mbaddr
                           
                            IF ( ( @t_email IS NOT NULL
                                   
                        )
                                 AND LEN(@t_email) > 0
                               )
         IF EXISTS ( SELECT  *
                                            FROM    dbo.mbr_phone (NOLOCK)
                                            WHERE   address_id = @d_address_id )
                                    UPDATE  dbo.mbr_phone
                                    SET     email = @t_email
                                    WHERE   address_id = @d_address_id;
			
                        END;
                END;
            ELSE
                BEGIN
                   
                    IF ( @t_src_id IS NULL
                         
                       )
                        BEGIN
                            SET @t_src_id ='';
                           
                        END;
	
                    
                    IF ( @t_new_ssn IS NULL
                         
                       )
                        BEGIN
                            SET @t_new_ssn ='';
                          
                        END;
	
                    INSERT  INTO dbo.member
                            ( family_id ,
                              alt_id ,
                              member_code ,
                              first_name ,
                              middle_init ,
                              last_name ,
                              date_of_birth ,
                              member_ssn ,
                              oed ,
                              disable_flag ,
                              student_flag ,
                              action_code ,
                              h_action ,
                              h_msi ,
                h_datetime ,
                              h_user ,
           ext_id_type ,
                              new_ssn ,
                           source_id ,
                              paperless
                    )
                    VALUES  ( @t_sub_id ,
							@t_alt_id ,
							 @t_member_code ,
						 @t_first_name ,
                             @t_middle_init ,
                             @t_last_name ,
                              @t_date_of_birth ,
                             -- @n_ext_id ,
							 @t_ssn,
                              @t_plan_eff_date ,
                              @t_disable_flag ,
                              @t_student_flag ,
                              'DA' ,
                              'DA' ,
                              @n_msi ,
                              @n_datetime ,
                              @a_user ,
                              @n_ext_id_type ,
                              @t_new_ssn ,
                              @t_src_id ,
                              @t_paperless
                            );
	
                    SELECT  @t_member_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   h_msi = @n_msi;
                   
                END;


--trace off;

            SET @SWP_Ret_Value = 1;
            
            SET @SWP_Ret_Value1 = @n_msi;
            
            SET @SWP_Ret_Value2 = @n_datetime;
			
			update dbo.GlobalVar set VarValue =@t_sub_id where VarName = 't_sub_id' and  BatchId = @a_batch_id AND Module_Id = 4
			update dbo.GlobalVar set VarValue =@t_member_id where VarName = 't_member_id' and  BatchId = @a_batch_id AND Module_Id = 4
			update dbo.GlobalVar set VarValue =@n_msi where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 4

			
            RETURN;
        END TRY
        BEGIN CATCH
            SET @SWP_Ret_Value = -200;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


--set debug file to "/tmp/tl_member.trc";
--trace on;

--LET n_msi = NULL;
--LET n_datetime = NULL;

    END;