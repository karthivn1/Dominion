﻿CREATE PROCEDURE [dbo].[delete_tables_dle_gen]
    
AS
    BEGIN

-----------Child---------------

        DELETE  FROM dc_bat_proc;

        DELETE  FROM dc_bat_sp;

        DELETE  FROM dc_batch_trace;

        DELETE  FROM dc_log_error;

        DELETE  FROM dc_bat_sp_parm;

        DELETE  FROM dc_sp_parm;

        DELETE  FROM dc_proc_det;

        DELETE  FROM dc_report_arg;

        DELETE  FROM dc_sir_tree;

        DELETE  FROM dc_sp_call;

        DELETE  FROM dc_sp_cond;

        DELETE  FROM dc_sp_tab;

        DELETE  FROM dc_tab_col;

        DELETE  FROM dc_tab_idx;

        DELETE  FROM dl_bat_statistics;

        DELETE  FROM dl_config_bat;

        DELETE  FROM dl_config_job_det;

        DELETE  FROM dl_config_param;

        DELETE  FROM dl_job_def_det;

        DELETE  FROM dl_job_sup_sir;

        DELETE  FROM dl_log_error;

        DELETE  FROM dl_log_error_h;

        DELETE  FROM dl_sir_col;

        DELETE  FROM dl_sir_idx;

        DELETE  FROM dl_sp_sir;

        DELETE  FROM dl_sir_sup_d;

        DELETE  FROM dl_sp_error;

        DELETE  FROM dl_cfg_bat_param;

        DELETE  FROM report_arglist;

        DELETE  FROM stc_common_detail;

        DELETE  FROM stc_user_access;

        DELETE  FROM stc_user_group;


---------------parent----------------

        DELETE  FROM dc_sp_error;

        DELETE  FROM dc_sp;

        DELETE  FROM dc_sir_top;

        DELETE  FROM dl_appl_option;

        DELETE  FROM dl_module;

        DELETE  FROM dl_config;

        DELETE  FROM dl_job_def;

        DELETE  FROM dl_sir_def;

        DELETE  FROM dl_sp;

        DELETE  FROM dl_sir_sup_h;

        DELETE  FROM dl_sp_param;


----------------grand parent-------------

        DELETE  FROM dc_batch;

        DELETE  FROM dc_parm_type;

        DELETE  FROM dc_proc;

        DELETE  FROM dc_report;

        DELETE  FROM dc_sp_type;

        DELETE  FROM dc_tab;

        DELETE  FROM dc_tab_idx_type;

        DELETE  FROM dl_appl;

        DELETE  FROM dl_cfg_bat_det;

        DELETE  FROM reports;

        DELETE  FROM stc_common_header;

        DELETE  FROM stc_user;


------------Remaining list-----------

        DELETE  FROM dls_fee_sched;

        DELETE  FROM stc_sys_opt;

        DELETE  FROM jk_eclaim_h;

        DELETE  FROM eclaim_h_hist;

        DELETE  FROM dls_actlog;

        DELETE  FROM stc_syslog;

        DELETE  FROM dc_upd_error;

        DELETE  FROM dt_billing;

        DELETE  FROM dt_control1;

        DELETE  FROM dt_control2;

        DELETE  FROM dt_facility;

        DELETE  FROM dt_fc_addr;

        DELETE  FROM dls_utilization;

        DELETE  FROM dt_fc_assoc;

        DELETE  FROM eclaim_matrix;

        DELETE  FROM dt_fc_certified;

        DELETE  FROM dt_fc_cont;

        DELETE  FROM dt_fc_hours;

        DELETE  FROM dt_fc_language;

        DELETE  FROM eclaim_dds_matrix;

        DELETE  FROM dt_group;

        DELETE  FROM dt_group_address;

        DELETE  FROM dt_group_cap_rate;

        DELETE  FROM dt_group_contact;

        DELETE  FROM dt_group_gfee_amt;

        DELETE  FROM dt_group_pdcomm;

        DELETE  FROM dt_main_control;

        DELETE  FROM dl_action;

        DELETE  FROM dt_mb_addr;

        DELETE  FROM dt_member;

        DELETE  FROM dls_pv_assoc;

        DELETE  FROM dt_mb_notes;

        DELETE  FROM pbcatvld;

        DELETE  FROM dt_net_facility;

        DELETE  FROM eclaim_dl_error;

        DELETE  FROM dt_pd;

        DELETE  FROM dls_sg_member;

        DELETE  FROM dt_pd_address;

        DELETE  FROM pbcatedt;

        DELETE  FROM dt_pd_contact;

        DELETE  FROM eclaim_d;

        DELETE  FROM dt_pdl_d;

        DELETE  FROM dt_providers;

        DELETE  FROM dt_pv_addr;

        DELETE  FROM dt_pv_cont;

        DELETE  FROM dt_pv_hours;

        DELETE  FROM dt_pv_license;

        DELETE  FROM dt_pv_sanction;

        DELETE  FROM dt_rel_gppl;

        DELETE  FROM dt_rlpdpd;

        DELETE  FROM dls_fee_zip;

        DELETE  FROM dt_rlpdpl;

        DELETE  FROM pbcatfmt;

        DELETE  FROM dt_sg_pdcomm;

        DELETE  FROM dt_claim_d;

        DELETE  FROM dt_claim_h;

        DELETE  FROM dt_claim_r;

        DELETE  FROM t_eclaim_d;

        DELETE  FROM dt_griev_act;

        DELETE  FROM larry;

        DELETE  FROM dt_grievances;

        DELETE  FROM dlsp_eg_group_plan;

        DELETE  FROM dt_group_aliases;

        DELETE  FROM raw_grid_d;

        DELETE  FROM eclaim_h;

        DELETE  FROM dls_ssn;

        DELETE  FROM raw_grid_h;

        DELETE  FROM dc_action_type;

        DELETE  FROM pbcattbl;

        DELETE  FROM dls_elig;

        DELETE  FROM t_eclaim_h;

        DELETE  FROM eclaim_status;

        DELETE  FROM dc_bat_cond;

        DELETE  FROM dlc_member;

        DELETE  FROM dc_ent_hist;

        DELETE  FROM script_status;

        DELETE  FROM eclaim_letters;

        DELETE  FROM eclaim_d_hist;

        DELETE  FROM sg_temp;

        DELETE  FROM dls_lockbox;

        DELETE  FROM pbcatcol;

        DELETE  FROM dls_fac_net;

        DELETE  FROM jk_eclaim_d;

    END;