﻿CREATE PROCEDURE [dbo].[InsertTagProcdure]
       @TagID int, 
       @Value nvarchar(200), 
       @TagCount nvarchar(200) 
AS
IF NOT EXISTS (SELECT NULL FROM Tag
                WHERE @TagID = @TagID)
BEGIN
    INSERT INTO 
        Tag 
        (TagID,Value,TagCount) 
        VALUES 
        (@TagID,@Value,@TagCount)
END