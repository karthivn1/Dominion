﻿CREATE PROCEDURE [dbo].[get_xfer_date]
    @FCOut INT ,
    @FCIn INT ,
    @GPFEffDate DATE ,
    @XferDate DATE ,
    @SWP_Ret_Value DATE = NULL OUTPUT
    

/* 
** This stored procedure determines the correct transfer date when a member is transferring
** from an "unknown FC" to a regular PCP
* /
/ * 20140827$$ks - did not take into account that the FC may not have been active as of the 
 * earlier date
 */
--------Error Variables ---------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr CHAR(80);
        DECLARE @s_err_rtn_text CHAR(80);
        DECLARE @i_isam_error INT;

-------Counters and processing variables -----------------------------------------
        DECLARE @i_error_count INT;
        DECLARE @i_total_count INT;
        DECLARE @i_init_count INT;
        DECLARE @i_count INT;
        DECLARE @i_fatal INT;
        DECLARE @i_succ_count INT;
        DECLARE @c_cur_err_flag CHAR(1);
        DECLARE @InTrans SMALLINT;
        DECLARE @SUser CHAR(10);
        DECLARE @CurrDT DATETIME2(0);

------------Variable Types --------------------------------------------------------
        DECLARE @EffDate DATE;
        DECLARE @FCEffDate DATE;
        DECLARE @CurrCalYear DATE;

        DECLARE @DesigID INT;

-----exception handling---------------------------------------------------------
 -- error converting text param values to correct type


 -- intrpt - server or user terminated --
        SET NOCOUNT ON;
        BEGIN TRY
           
            SET @CurrDT = GETDATE();
            SET @SUser = 'get_xfer_date' + ORIGINAL_LOGIN(); 
            SET @i_total_count = 0;
            SET @i_succ_count = 0;
            SET @i_error_count = 0;
            SET @a_error_no = 0;
            SET @InTrans = 0;
            SET @c_cur_err_flag = 'F';
            SET @DesigID = 0;

/* We are only interested in transfers from an "unknown FC" 
 * All other combinations return the XferDate passed into the procedure
 */

            SELECT  @DesigID = desig_id
            FROM    dbo.desig (NOLOCK)
            WHERE   subsys_code = 'FC'
                    AND desig_name = 'Holding Facility';
            
            IF @DesigID IS NULL
                SET @DesigID = 0;

            IF @DesigID = 0
                RAISERROR('Designation not found ''Holding Facility''',16,1);


/* FC transferring from is not Holding FC */
            IF NOT EXISTS ( SELECT  sys_rec_id
                            FROM    dbo.dd_desig (NOLOCK)
                            WHERE   subsys_code = 'FC'
                                    AND sys_rec_id = @FCOut
                                    AND desig_id = @DesigID )
                BEGIN
                    SET @SWP_Ret_Value = @XferDate;
                    RETURN;
                END;


/* Now we know that the from FC is Holding 
 */
            SET @CurrCalYear = CONVERT(DATE, CONCAT('01/01/',
                                                    YEAR(CONVERT(DATE, GETDATE()))));
            IF @GPFEffDate < @CurrCalYear
                SET @EffDate = @CurrCalYear;
            ELSE
                SET @EffDate = @GPFEffDate;

            SELECT  @FCEffDate = nf.eff_date
            FROM    dbo.net_facility nf ( NOLOCK ) ,
                    dbo.network n ( NOLOCK ) ,
                    dbo.fcstat f ( NOLOCK )
            WHERE nf.fc_id = f.facility_id
                    AND nf.net_id = n.net_id
                    AND nf.con_type = 'HMO'
                    AND n.con_type = 'P'
                    AND nf.fc_id = @FCOut
                    AND nf.exp_date IS NULL
                    AND f.exp_date IS NULL
                    AND f.status IN ( 'AC', 'CL' )
                    AND n.exp_date IS NULL;
           
            IF @FCEffDate > @EffDate
                SET @EffDate = @FCEffDate;

            SET @SWP_Ret_Value = @EffDate;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            IF @InTrans = 1
                
	
            SET @SWP_Ret_Value = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF; 

--TRACE OFF;


--------------------------------------------------------------------------------

--SET DEBUG FILE TO  '/tmp/get_xfer_date.trc';
--TRACE ON;

--set explain on;
    END;