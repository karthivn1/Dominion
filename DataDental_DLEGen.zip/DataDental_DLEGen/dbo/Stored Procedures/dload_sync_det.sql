﻿CREATE PROCEDURE [dbo].[dload_sync_det]
    @eClaimID INT ,
    @BatchID INT ,
    @ALTID CHAR(20) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    


-- Modified 08/11/04 by JMK @ Dominion
-- eclaim modification D:5.3.03
-- 1. Changed trace file name
-- 2. Corrected SQL "Select error_code, status_to_assign, level..."
--    to get DataLoad error code.
--    2 tables were being used.  3 tables are needed.
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:01:01 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1











000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @DT DATETIME2(0);
        DECLARE @TmpDT VARCHAR(20);	
        DECLARE @i_isam_error INT;
        DECLARE @ClaimID INT;
        DECLARE @DetID INT;
        DECLARE @SirID INT;
        DECLARE @HdrError CHAR(10);
        DECLARE @ErrCode CHAR(10);
        DECLARE @HdrStatus SMALLINT;	
        DECLARE @eClaimStatus SMALLINT;	
        DECLARE @SEV CHAR(1);	
        DECLARE @DLStatus CHAR(1);	
        DECLARE @RecCount SMALLINT;	
        DECLARE @LVL SMALLINT;	
        DECLARE @ErrID INT;	
        DECLARE @ErrNo INT;
      --  DECLARE @SWV_cursor_var1 CURSOR;
      --  DECLARE @SWV_cursor_var2 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        
           

--set debug file to 'dload_sync_det.trc';
--trace on;

            SET @DT = GETDATE(); 
            SET @TmpDT = ''; 
            
            SET @HdrError = '';
            SET @HdrStatus = 3;
            SET @RecCount = 0;
            SET @DLStatus = '';
            SET @DetID = 0;
            SET @SirID = 0;
            SELECT  @RecCount = COUNT(DISTINCT dls_status)
            FROM    dbo.dls_utilization (NOLOCK)
            WHERE   alt_id = @ALTID
                    AND dls_batch_id = @BatchID;  -- All records should have the same status

            IF @RecCount > 1
			BEGIN
                UPDATE  dbo.eclaim_h
                SET     sync_status = 9 ,
                        sync_dt = GETDATE(),
						status = 3
                WHERE   eclaim_id = @eClaimID;

				SET @SWP_Ret_Value = 1;
				SET @SWP_Ret_Value1 = 'Status Updated'
			RETURN
			END

            SELECT DISTINCT
                    @DLStatus = dls_status
            FROM    dbo.dls_utilization (NOLOCK)
            WHERE   alt_id = @ALTID
                    AND dls_batch_id = @BatchID;
           
            IF @DLStatus != 'U'
                AND @DLStatus != 'E'
				AND EXISTS(select dls_batch_id from dls_utilization(NOLOCK) where dls_batch_id = @BatchID
							and dls_status = 'U')
                BEGIN
                    UPDATE  dbo.eclaim_h
                    SET     dls_status = @DLStatus ,
                            sync_status = 1 ,
                            sync_dt = GETDATE(),
							status = 3
                    WHERE   eclaim_id = @eClaimID;
                    
					SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = 'Status Updated';
                    RETURN;
                END;
 
/* Only want to process claims uploaded into DataDental or Errored */
            IF @DLStatus = 'U'
                BEGIN
                    SELECT  @ClaimID = claim_id
                    FROM    dbo.claim_h (NOLOCK)
                    WHERE   alt_id = @ALTID; 
                    
                    IF ( @ClaimID IS NULL
                         OR @ClaimID = 0
                       )
                        UPDATE  dbo.eclaim_h
                        SET     sync_status = 10 ,
               sync_dt = GETDATE()
                        WHERE eclaim_id = @eClaimID;
                    ELSE
                        UPDATE  dbo.eclaim_h
                        SET     dds_claim_id = @ClaimID ,
                                sync_status = 1 ,
                                sync_dt = GETDATE() ,
                                dls_status = 'U'
                        WHERE   eclaim_id = @eClaimID;
	
                    
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = 'Claim entered into DataDental';
                    RETURN;
                END;

/* Now only errors exist to process */
           /*
		    SET @SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_d_id, dls_sir_id 
      FROM dbo.eclaim_d (NOLOCK) WHERE eclaim_id = @eClaimID;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @DetID, @SirID;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  eclaim_d_id INT ,
                  dls_sir_id INT
                );

            INSERT  INTO @SWV_cursor_var1
                    ( eclaim_d_id ,
                      dls_sir_id 
					)
                    SELECT  eclaim_d_id ,
                            dls_sir_id
                    FROM    dbo.eclaim_d (NOLOCK)
                    WHERE   eclaim_id = @eClaimID;

            DECLARE @cur1_cnt INT ,
                @cur1_i INT;

            SET @cur1_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;

            WHILE ( @cur1_i <= @cur1_cnt )
                BEGIN
                    SELECT  @DetID = eclaim_d_id ,
                            @SirID = dls_sir_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur1_i;

                    SELECT  @RecCount = COUNT(DISTINCT lg.error_no)
                    FROM    dbo.dl_log_error lg ( NOLOCK ) ,
                            dbo.dl_sp_error err ( NOLOCK )
                    WHERE   lg.sp_id = err.sp_id
                            AND lg.error_no = err.error_no
                            AND dls_sir_id = @SirID
                            AND err.severity = 'F';
                    IF @RecCount = 0
                        BEGIN
                            UPDATE  dbo.eclaim_d
                            SET     error_code = 'OK' ,
                                    h_user = SYSTEM_USER ,
                                    h_datetime = GETDATE()
                            WHERE   eclaim_d_id = @DetID;
                            GOTO SWL_Label3;
                        END;
	
	/* Get Fatal error if exists */
                   /*
				    SET @SWV_cursor_var2 = CURSOR  FOR SELECT err.sp_error_id, err.error_no, err.severity, lg.created_time
		
         FROM dbo.dl_log_error lg (NOLOCK), dbo.dl_sp_error err (NOLOCK)
         WHERE lg.sp_id = err.sp_id
         AND lg.error_no = err.error_no
         AND dls_sir_id = @SirID
         ORDER BY lg.created_time DESC;
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @ErrID, @ErrNo, @SEV,
                        @TmpDT;
                    WHILE @@FETCH_STATUS = 0
					*/
					IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
					DROP TABLE #SWV_cursor_var2

                    CREATE TABLE #SWV_cursor_var2
                        (
                          id INT IDENTITY ,
                          sp_error_id INT ,
                          error_no INT ,
                          severity CHAR ,
                          created_time VARCHAR(22)
                        );

                    INSERT  INTO #SWV_cursor_var2
                            ( sp_error_id ,
                              error_no ,
   severity ,
                              created_time 
					        )
                            SELECT  err.sp_error_id ,
									err.error_no ,
									err.severity ,
                                    lg.created_time
                 FROM    dbo.dl_log_error lg ( NOLOCK ) ,
						dbo.dl_sp_error err ( NOLOCK )
                         WHERE   lg.sp_id = err.sp_id
                                    AND lg.error_no = err.error_no
                                    AND dls_sir_id = @SirID
                            ORDER BY lg.created_time DESC;

                    DECLARE @cur2_cnt INT ,
                        @cur2_i INT;

                    SET @cur2_i = 1;

					--Get the no. of records for the cursor
                    SELECT  @cur2_cnt = COUNT(1)
                    FROM    #SWV_cursor_var2;

                    WHILE ( @cur2_i <= @cur2_cnt )
                        BEGIN
                            SELECT  @ErrID = sp_error_id ,
                                    @ErrNo = error_no ,
                                    @SEV = severity ,
                                    @TmpDT = created_time
                            FROM    #SWV_cursor_var2
                            WHERE   id = @cur2_i;

                            GOTO SWL_Label4;
                            /*
							FETCH NEXT FROM @SWV_cursor_var2 INTO @ErrID,
                                @ErrNo, @SEV, @TmpDT;
								*/
                            SET @cur2_i = @cur2_i + 1;
                        END;
                    SWL_Label4:
                    --CLOSE @SWV_cursor_var2;
                    SELECT  @RecCount = COUNT(*)
                    FROM    dbo.eclaim_dl_error dle ( NOLOCK ) ,
                            dbo.eclaim_matrix m ( NOLOCK )
                    WHERE   dle.matrix_id = m.matrix_id
                            AND dle.sp_error_id = @ErrID;
                    IF @RecCount = 0
                        OR @RecCount > 1
                        BEGIN
                            UPDATE  dbo.eclaim_d
                            SET     error_code = 'UNDLU' ,
                                    h_datetime = GETDATE() ,
                                    h_user = SYSTEM_USER
                            WHERE   eclaim_d_id = @DetID;
                            GOTO SWL_Label3;
                        END;
	

	-- Modified 08/11/04 by JMK @ Dominion (D:5.3.03)
	
                    SELECT  @ErrCode = error_code ,
                            @eClaimStatus = status_to_assign ,
                            @LVL = [level]
                    FROM    dbo.eclaim_dl_error dle ( NOLOCK ) ,
                            dbo.eclaim_matrix m ( NOLOCK ) ,
                            dbo.dl_sp_error dl ( NOLOCK )
                    WHERE   dle.sp_error_id = dl.sp_error_id
                            AND dle.matrix_id = m.matrix_id
--            and dl.error_no = ErrID; --20100709$$ks  this points error Number to ID
                            AND dl.sp_error_id = @ErrID;
                    


	-- End of modification D:5.3.03

                    IF @LVL = 1 -- Service line level error 
                        BEGIN
                            UPDATE  dbo.eclaim_d
                            SET     error_code = @ErrCode ,
                                    h_datetime = GETDATE() ,
                                    h_user = SYSTEM_USER
                            WHERE   eclaim_d_id = @DetID;
                            IF @HdrError = ''
                                BEGIN
                                    SET @HdrError = 'PART';
                                    SET @HdrStatus = @eClaimStatus;
								 END;
                        END;
                    ELSE
					 BEGIN
                            UPDATE  dbo.eclaim_d
                            SET     error_code = 'OK' ,
                                    h_datetime = GETDATE() ,
           h_user = SYSTEM_USER
                            WHERE   eclaim_d_id = @DetID;
                            SET @HdrError = @ErrCode;
                            SET @HdrStatus = @eClaimStatus;
					END;
                    SWL_Label3:
                   -- FETCH NEXT FROM @SWV_cursor_var1 INTO @DetID, @SirID;
                    SET @cur1_i = @cur1_i + 1;
                END;
           -- CLOSE @SWV_cursor_var1;

--if HdrError != "" then
            UPDATE  dbo.eclaim_h
            SET     error_code = @HdrError ,
                    status = @HdrStatus ,
                    h_user = SYSTEM_USER,
                    h_datetime = GETDATE() ,
                    sync_status = 1 ,
                    sync_dt = GETDATE() ,
                    dls_status = @DLStatus
            WHERE   eclaim_id = @eClaimID;
--end if;
            
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = 'DataLoad-eClaim Sync Completed';
            RETURN;
        
        SET NOCOUNT OFF;

    END;