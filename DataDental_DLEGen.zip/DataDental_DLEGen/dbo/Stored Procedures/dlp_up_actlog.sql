﻿CREATE PROCEDURE [dbo].[dlp_up_actlog]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
	
	

-------------------------------------------------------------------------------------
--
--		Procedure:	dlp_up_actlog
--		Created:	08/21/2001
--		Author:		Ameeta Mahendra
--		Purpose:	Perform update processing on DataDental actlog_docs table 
---------------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @li_tt_prcs_cnt INT;
        DECLARE @li_prcs_gd_cnt INT;
        DECLARE @li_prcs_bad_cnt INT;
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @n_error_text CHAR(64);
        DECLARE @s_error_found CHAR(1);

        DECLARE @ls_user CHAR(20);
        DECLARE @n_date DATE;
        DECLARE @n_time TIME(0);
        DECLARE @d_date DATE;
        DECLARE @t_time CHAR(12);

        DECLARE @n_isam_error INT;
        DECLARE @n_error_no INT;
        DECLARE @n_fatal INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_pre_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @t_del_sir INT;

        DECLARE @i_sir_id INT;
        DECLARE @s_source CHAR(1);
        DECLARE @s_subsys_code CHAR(2); 
        DECLARE @i_sysrec_id INT;
        DECLARE @s_reason_code CHAR(2);
        DECLARE @i_act_mast_id INT;
        --DECLARE @cactlogSir CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;

        SET NOCOUNT ON;
        BEGIN TRY
             
            
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'up_actlog';
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
                RAISERROR('Invalid SP name',16,1);
	
            EXECUTE @i_pre_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_actlog';
            IF @i_pre_sp_id IS NULL
                OR @i_pre_sp_id <= 0
                RAISERROR('Invalid Preprocess Procedure Name',16,1);
	
            SET @i_sir_def_id = dbo.dl_get_sir_def_id('actlog');
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
                RAISERROR('Invalid DSIR table name',16,1);
	
            SET @d_date = CONVERT(DATE, GETDATE());
            SET @ls_user = CONCAT('dl', @a_batch_id);
            EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
                @n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @n_error_text OUTPUT;
            IF @n_error_no <= 0
                BEGIN
                    SET @n_error_text = CAST(-746 AS VARCHAR) + ':'
                        + @n_error_text;
                    RAISERROR(@n_error_text,16,1);
                END;

            SET @n_in_transaction = 'N';
            SET @t_time = GETDATE();
            SET @li_tt_prcs_cnt = 0;
            SET @li_prcs_gd_cnt = 0;
            SET @li_prcs_bad_cnt = 0;
            /*
			SET @cactlogSir = CURSOR  FOR SELECT dls_sir_id,  subsys_code, sysrec_id, reason_code , dls_act_mast_id,
	act_date, act_time
	
      FROM dbo.dls_actlog (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'P';
            OPEN @cactlogSir;
            FETCH NEXT FROM @cactlogSir INTO @i_sir_id, @s_subsys_code,
                @i_sysrec_id, @s_reason_code, @i_act_mast_id, @n_date, @n_time;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cactlogSir_cursor_var1 TABLE
 (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                  subsys_code CHAR ,
                  sysrec_id INT ,
                  reason_code CHAR ,
                  dls_act_mast_id INT ,
                  act_date DATE ,
                  act_time TIME
                );

            INSERT  INTO @cactlogSir_cursor_var1
                    ( dls_sir_id ,
                      subsys_code ,
                      sysrec_id ,
                      reason_code ,
                      dls_act_mast_id ,
                      act_date ,
                      act_time
                    )
                    SELECT  dls_sir_id ,
                            subsys_code ,
                            sysrec_id ,
                            reason_code ,
                            dls_act_mast_id ,
                            act_date ,
                            act_time
                    FROM    dbo.dls_actlog (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'P';

            DECLARE @cur2_cnt INT ,
                @cur2_i INT;
            SET @cur2_i = 1;
           
            SELECT  @cur2_cnt = COUNT(1)
            FROM    @cactlogSir_cursor_var1;
            WHILE ( @cur2_i <= @cur2_cnt )
                BEGIN
                    BEGIN
                        SELECT  @i_sir_id = dls_sir_id ,
                                @s_subsys_code = subsys_code ,
                                @i_sysrec_id = sysrec_id ,
                                @s_reason_code = reason_code ,
                                @i_act_mast_id = dls_act_mast_id ,
                                @n_date = act_date ,
                                @n_time = act_time
                        FROM    @cactlogSir_cursor_var1
                        WHERE   id = @cur2_i;
					
                        --DECLARE @SWV_cursor_var1 CURSOR;
                        BEGIN TRY

                            /*
							SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id 
               FROM dbo.dls_actlog (NOLOCK)
               WHERE dls_batch_id = @a_batch_id AND
               dls_sir_id = @i_sir_id;
                            OPEN @SWV_cursor_var1;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @t_del_sir;
                            WHILE @@FETCH_STATUS = 0
							*/
                            DECLARE @SWV_cursor_var1 TABLE
                                (
                                  id INT IDENTITY ,
                                  dls_sir_id INT
                                );

                            INSERT  INTO @SWV_cursor_var1
                                    ( dls_sir_id
                                    )
                                    SELECT  dls_sir_id
                                    FROM    dbo.dls_actlog (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @i_sir_id;

                            DECLARE @cur1_cnt INT ,
                                @cur1_i INT;

                            SET @cur1_i = 1;

    --Get the no. of records for the cursor
                            SELECT  @cur1_cnt = COUNT(1)
                            FROM    @SWV_cursor_var1;

                            WHILE ( @cur1_i <= @cur1_cnt )
                                BEGIN
                                    SELECT  @t_del_sir = dls_sir_id
                                    FROM    @SWV_cursor_var1
                                    WHERE   id = @cur1_i;

                                    EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                        @t_del_sir, @i_sp_id,
                                        @n_error_no OUTPUT,
                                        @n_error_text OUTPUT;
       --FETCH NEXT FROM @SWV_cursor_var1 INTO @t_del_sir;
                                    SET @cur1_i = @cur1_i + 1;
                                END;
                            --CLOSE @SWV_cursor_var1;
                            
                            SET @li_tt_prcs_cnt = @li_tt_prcs_cnt + 1;
                            SET @s_error_found = 'N';
                            SET @n_error_no = 100;	--insert failed.
                            IF @n_date IS NULL
                                AND @n_time IS NULL
                                BEGIN
                                    SET @n_date = @d_date;
                                    SET @n_time = @t_time;
                                END;
	
                            IF @n_date IS NULL
                                SET @n_date = @d_date;
	
                            IF @n_time IS NULL
                                SET @n_time = DATEADD(HOUR,
                                                      DATEPART(HOUR,
                                                              '00:00:00'),
                                                      DATEADD(MINUTE,
                                                              DATEPART(MINUTE,
                                                              '00:00:00'),
                                                              DATEADD(SECOND,
                                                              DATEPART(SECOND,
                                                              '00:00:00'),
                                                              '1900-01-01 00:00:00')));
	
                            INSERT  INTO dbo.act_log
                                    ( sub_sys ,
                                      act_mast_id ,
                                      event_sys_id ,
                                      action_code ,
                                      reason_code ,
                                      log_user ,
                                      log_date ,
                                      log_time
                                    )
                            VALUES  ( @s_subsys_code ,
                                      @i_act_mast_id ,
                                      @i_sysrec_id ,
                                      NULL ,
                                      @s_reason_code ,
                                      @ls_user ,
                                      @n_date ,
                                      @n_time
                                    );
	
                            SET @li_prcs_gd_cnt = @li_prcs_gd_cnt + 1;
                            UPDATE  dbo.dls_actlog
                            SET     dls_status = 'U'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sir_id = @i_sir_id;
                            
                        END TRY
                        BEGIN CATCH
                            SET @n_error_no = ERROR_NUMBER();
                            SET @n_isam_error = ERROR_LINE();
                            SET @n_error_text = ERROR_MESSAGE();
                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @i_sir_id, 1000;
                            SET @s_error_found = 'Y';
                            UPDATE  dbo.dls_actlog
                            SET     dls_status = 'E'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sir_id = @i_sir_id;
                        END CATCH;
                    END;
                    /*
					FETCH NEXT FROM @cactlogSir INTO @i_sir_id, @s_subsys_code,
                        @i_sysrec_id, @s_reason_code, @i_act_mast_id, @n_date,
                        @n_time;
						*/
          SET @cur2_i = @cur2_i + 1;
                END;
            --CLOSE @cactlogSir;
            SET @SWV_func_DL_UPD_STATISTICS_par0 = @li_tt_prcs_cnt
                - @li_prcs_gd_cnt;
            EXECUTE dbo.dl_upd_statistics @i_statistics_id, @li_tt_prcs_cnt,
                @li_prcs_gd_cnt, @SWV_func_DL_UPD_STATISTICS_par0,
                @SWV_dl_upd_statistics OUTPUT;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@li_tt_prcs_cnt,
                                                 ' Failed to update statistics');
                    RETURN;
                END;

            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @a_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Final Process for Batch ',
                                         @a_batch_id, ' is completed');
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            IF @n_in_transaction = 'Y'
                
	
            SET @SWP_Ret_Value = @n_error_no;
            SET @SWP_Ret_Value1 = @n_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;
--trace off;



--	set debug file to "/tmp/dlp_up_actlog.trc";
--	trace on;
--	set explain on;

    END;