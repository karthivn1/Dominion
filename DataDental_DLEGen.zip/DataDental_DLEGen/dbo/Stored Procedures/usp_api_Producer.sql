﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_Producer]
@ProdID INT,@ProdAltID Char(20) out,@ProdType char(2) out,@ErrorMsg nVarchar(50) out
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
BEGIN TRY
	SET NOCOUNT ON;

DECLARE @pID INT=0;

 IF @ProdID>0
BEGIN

IF NOT EXISTS(Select pd.producer_id,pd.alt_id,pdstat.producer_type 
				From pd, pdstat  Where pd.producer_id = pdstat.producer_id 
					  and pdstat.exp_date is null  
					  and pd.producer_id = @ProdID )
	BEGIN
	    SET @ErrorMsg='Unable to get Producer from Database for ID: ' + @ProdID;
	    RETURN @pID
	END
		   Select @pID=pd.producer_id,@ProdAltID=pd.alt_id,@ProdType=pdstat.producer_type 
				From pd, pdstat  Where pd.producer_id = pdstat.producer_id 
					  and pdstat.exp_date is null  
					  and pd.producer_id = @ProdID 


END
ELSE IF LEN(@ProdAltID)>0
BEGIN
   IF NOT EXISTS( Select pd.producer_id,pd.alt_id,pdstat.producer_type 
				From pd, pdstat  Where pd.producer_id = pdstat.producer_id 
					  and pdstat.exp_date is null and pd.alt_id =@ProdAltID )
	BEGIN
	   SET @ErrorMsg='Producer could not be found with the given identifier ';
	   RETURN @pID
	END
	    Select @pID=pd.producer_id,@ProdAltID=pd.alt_id,@ProdType=pdstat.producer_type 
				From pd, pdstat  Where pd.producer_id = pdstat.producer_id 
					  and pdstat.exp_date is null  
					 and pd.alt_id =@ProdAltID 
			  
END
 --needs to take the plan_id>0 and check the options FFS-->PPO
 --select *from [plan]
 
--PRINT 'ProdID' + @pID + 'ProdAltID' + @ProdAltID + 'ProdType' + @ProdType

RETURN @pID
END TRY
BEGIN CATCH
THROW;
END CATCH

END