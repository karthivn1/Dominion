﻿CREATE PROCEDURE [dbo].[dlp_al_sg_member]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT 
	


/*
04/01/2005 modified procedure to populate ID's based on Alt ID or 
populate Alt ID's based on ID's. This is the only procedure using 
Alt ID for master single group, Facility, Producer and Plan. 
All procedures following will be using ID values. Errors if perfect
match is not found based on information provided
*/
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:07:07 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1








000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).

*/

        DECLARE @do_trace BIT;

--error variable
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(18);
        DECLARE @s_proc_name CHAR(18);
        DECLARE @a_error_no INT;


        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @i_count INT;


        DECLARE @s_error CHAR(1);
        DECLARE @t_sir_id INT;
        DECLARE @t_sub_sir_id INT;
        DECLARE @t_sub_alt_id CHAR(20);
        DECLARE @t_alt_id CHAR(20);
        DECLARE @t_member_flag CHAR(2);
        DECLARE @t_ssn CHAR(11);
        DECLARE @t_sub_ssn CHAR(11);
        DECLARE @t_paperless CHAR(1);
        DECLARE @n_paperless CHAR(5);
        DECLARE @t_student_flag CHAR(1);
        DECLARE @t_disable_flag CHAR(1);
        DECLARE @t_city CHAR(30);
        DECLARE @t_state CHAR(2);
        DECLARE @t_zip CHAR(5);
        DECLARE @t_selling_period CHAR(1);
        DECLARE @t_producer_id INT;
        DECLARE @t_producer_alt CHAR(20);
        DECLARE @t_msg_id INT;
        DECLARE @t_msg_alt CHAR(20);
        DECLARE @t_plan_id INT;
        DECLARE @t_plan_dsp_name CHAR(30);
        DECLARE @t_fc_id INT;
        DECLARE @t_fc_alt CHAR(20);
        DECLARE @t_dls_status CHAR(1);
        DECLARE @test_ssn CHAR(11);
        DECLARE @n_mb_ssn CHAR(11);
        DECLARE @n_mb_sub_ssn CHAR(11);
        DECLARE @n_sub_sir_id INT;
        DECLARE @d_city CHAR(30);
        DECLARE @d_state CHAR(2);
        DECLARE @n_process_count INT;
        DECLARE @n_sub_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @n_al_count INT;
        DECLARE @n_count INT;
        DECLARE @i_delete_id INT;
        DECLARE @s_sub_alt_id CHAR(20);
/* 20131103$$ks added check for pend
 */
        DECLARE @t_pend_yn CHAR(1);
        DECLARE @true CHAR(1)='t';
        DECLARE @false CHAR(1)='f';
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_config_id INT;
        DECLARE @s_create_ssn char(1);
        DECLARE @SWV_dl_get_sp_id INT;
		DECLARE @created_by CHAR(15)
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @cSIR CURSOR;
        --DECLARE @SWV_cursor_var4 CURSOR;
        DECLARE @SWV_cursor_var1 TABLE
            (
              id INT IDENTITY ,
              sub_alt_id CHAR(20) ,
              dls_sir_id INT
            );
        DECLARE @cSIR TABLE
            (
              id INT IDENTITY ,
              dls_sub_sir_id INT ,
              dls_sir_id INT ,
              sub_alt_id CHAR(20) ,
              ssn CHAR(11) ,
              sub_ssn CHAR(11) ,
              producer_id INT ,
              prod_alt_id CHAR(20) ,
              msg_group_id INT ,
              msg_alt_id CHAR(20) ,
           plan_dsp_name CHAR(30)
);

  DECLARE @SWV_cursor_var4 TABLE
            (
              id INT IDENTITY ,
              dls_sub_sir_id INT ,
              dls_sir_id INT ,
              sub_alt_id CHAR(20)
            );

        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;
        DECLARE @v_Null INT;
        SET NOCOUNT ON;
     
        
        SET @i_sp_id = 0;
       
        SET @i_sir_def_id = 0;
        
        SET @i_config_id = 0;
       
        SET @s_create_ssn = '';
        
        BEGIN TRY
            
            --SET @do_trace = @true;
			SET @do_trace = 1;
            IF ( @do_trace = 1 )
                BEGIN--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/dlp_al_sg_member_" || a_batch_id || ".trc";

	--TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;

            BEGIN
                DECLARE @currentDateAndTime DATETIME;
                DECLARE @userSessionId INT;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "dlp_al_sg_member():  Entered.";
                        SET @v_Null = 0;
                    END;
	
                SET @currentDateAndTime = GETDATE();
                SET @userSessionId = @@spid;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "a_batch_id = " || a_batch_id;

		--TRACE statement has no equivalent in MSSQL
--trace "a_start_time = " || a_start_time;
                        SET @v_Null = 0;
                    END;
	
            END;
             
            SET @n_in_transaction = 'N';
            
            SET @s_proc_name = 'al_sg_member';
            SET @s_sir_def_name = 'sg_member';
            SET @a_error_no = 0;
            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @a_batch_id, @s_proc_name

            SET @i_sp_id =@SWV_dl_get_sp_id ;
           
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;
           
		   SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id

            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      --ORIGINAL_LOGIN() ,
					  @created_by,
                      @a_start_time
                    );

            SELECT  @i_statistics_id = MAX(bat_statistics_id)
			FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            
            
            SET @s_create_ssn = dbo.dl_get_param_value(@a_batch_id,
                                                            @i_sp_id,
                                                            'Create SSN') ;
          
            IF ( @s_create_ssn IS NULL
                 OR @s_create_ssn = ''
               )
			   BEGIN
			   SET @a_error_no = 0
					EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					IF @i_fatal <> 1 
						SET @s_error = 'Y';
						RAISERROR('Missing Flag for Creating SSN',16,1);
					
				END
            ELSE
                BEGIN
                    
                    IF @s_create_ssn NOT IN ( 'Y', 'N' )
					BEGIN
					 SET @a_error_no = 0
						EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
					RAISERROR('Invalid flag for creating ssn',16,1);
					END
                END;

            SET @n_sub_count = 0;
            SET @n_process_count = 0;
			SET @n_succ_count = 0;
            IF EXISTS ( SELECT  'X'
              FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @a_batch_id
                                AND sp_id = @i_sp_id )
                BEGIN
                   /* SET @SWV_cursor_var1 = CURSOR  FOR SELECT sub_alt_id, dls_sir_id 
         FROM dbo.dls_sg_member (NOLOCK)
         WHERE dls_batch_id = @a_batch_id AND dls_status = 'V';
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @s_sub_alt_id,
                        @i_delete_id;
                    WHILE @@FETCH_STATUS = 0
					*/
                    INSERT  INTO @SWV_cursor_var1
                            ( sub_alt_id ,
                              dls_sir_id
                            )
                            SELECT  sub_alt_id ,
                                    dls_sir_id
                            FROM    dbo.dls_sg_member (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V';

                    DECLARE @cur1_cnt INT ,
                        @cur_i INT;

                    SET @cur_i = 1;

					--Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
                    WHILE ( @cur_i <= @cur1_cnt )
                        BEGIN
                            SELECT  @s_sub_alt_id = sub_alt_id ,
                                    @i_delete_id = dls_sir_id
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur_i; 

                            
                            EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                @i_delete_id, @i_sp_id, @i_error_no OUTPUT,
                                @s_error_descr OUTPUT;
                            UPDATE  dbo.dls_sg_member
                            SET     dls_status = 'L'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V'
                                    AND sub_alt_id = @s_sub_alt_id;
                            -- FETCH NEXT FROM @SWV_cursor_var1 INTO @s_sub_alt_id,@i_delete_id;
                            SET @cur_i = @cur_i + 1;
                        END;
                    -- CLOSE @SWV_cursor_var1;
                END;

/* 20130929$$ks - Added plan_dsp_name to select so we can allow 
	multiple member entries as long as they are unique by group and plan
 */
            INSERT  INTO @cSIR
                    ( dls_sub_sir_id ,
                      dls_sir_id ,
                      sub_alt_id ,
                      ssn ,
					sub_ssn ,
                      producer_id ,
                      prod_alt_id ,
                      msg_group_id ,
                      msg_alt_id ,
                      plan_dsp_name
                    )
                    SELECT  dls_sir_id ,
                            dls_sir_id ,
                            sub_alt_id ,
                            ssn ,
                            sub_ssn ,
                            producer_id ,
                            prod_alt_id ,
                            msg_group_id ,
                            msg_alt_id ,
                            plan_dsp_name
                    FROM    dbo.dls_sg_member (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'L'
                            AND member_flag = '00';
	   
           /* SET @cSIR = CURSOR  FOR SELECT dls_sir_id, dls_sir_id, sub_alt_id, ssn, sub_ssn, producer_id,
	prod_alt_id, msg_group_id, msg_alt_id, plan_dsp_name
	
      FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'L' AND member_flag = '00';
OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_sub_sir_id, @t_sub_alt_id,
                @t_ssn, @t_sub_ssn, @t_producer_id, @t_producer_alt, @t_msg_id,
                @t_msg_alt, @t_plan_dsp_name;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @cur2_cnt INT ,
                @cur2_i INT;

            SET @cur2_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur2_cnt = COUNT(1)
            FROM    @cSIR;
					
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur2_i <= @cur2_cnt )
                BEGIN
                    BEGIN
                        SELECT  @t_sir_id = dls_sub_sir_id ,
                                @t_sub_sir_id = dls_sir_id ,
                                @t_sub_alt_id = sub_alt_id ,
                                @t_ssn = ssn ,
                                @t_sub_ssn = sub_ssn ,
                                @t_producer_id = producer_id ,
                                @t_producer_alt = prod_alt_id ,
                                @t_msg_id = msg_group_id ,
                                @t_msg_alt = msg_alt_id ,
                                @t_plan_dsp_name = plan_dsp_name
                        FROM    @cSIR
                        WHERE   id = @cur2_i;

                      --   DECLARE #SWV_cursor_var2 CURSOR;
					  IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
					DROP TABLE #SWV_cursor_var2

                        CREATE TABLE #SWV_cursor_var2
                            (
                              id INT IDENTITY ,
                              dls_sir_id INT ,
                              alt_id CHAR(20) ,
                              member_flag CHAR(2) ,
                              sub_alt_id CHAR(20) ,
                              dls_status CHAR(1) ,
                              nameprefix CHAR(5) ,
                              ssn CHAR(11) ,
                              sub_ssn CHAR (11),
                              student_flag CHAR ,
                              disable_flag CHAR ,
                              city CHAR(20) ,
                              state CHAR(2) ,
                              zip CHAR(5) ,
                              selling_period CHAR(1) ,
                              msg_group_id INT ,
                              msg_alt_id CHAR(20) ,
                              plan_id INT ,
                              plan_dsp_name CHAR(30) ,
                              facility_id INT ,
                              fc_alt_id CHAR(20) ,
                              pend_yn CHAR(1)
                            );

                        BEGIN TRY
                            SET @s_error = 'N';
                            SET @n_sub_sir_id = @t_sub_sir_id;
                            IF @n_in_transaction = 'N'
                              BEGIN
                                    
                SET @n_in_transaction = 'Y';
                                END;
	
                           
                            IF @s_create_ssn = 'Y'
                                IF ( @t_sub_ssn IS NULL
                                     OR @t_sub_ssn = ''
                                   )
                                    AND ( @t_ssn IS NULL
                                          OR @t_ssn = ''
                                        )
                                    BEGIN
                                        SELECT  @n_count = COUNT(*)
                                        FROM    dbo.member (NOLOCK)
                                        WHERE   alt_id = @t_sub_alt_id;
        IF @n_count > 1
										BEGIN
										 SET @a_error_no = 1
                                            RAISERROR('Multiple member records found with same alt_id',16,1);
											EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
											
										END
                                        ELSE
                                         BEGIN
SELECT  @n_mb_ssn = member_ssn
           FROM dbo.member (NOLOCK)
                                      WHERE   alt_id = @t_sub_alt_id;
                                               
                                                IF ( @n_mb_ssn IS NULL
                                                     OR @n_mb_ssn = ''
                                                   )
                                                    BEGIN
                                                        SELECT
                                                              @test_ssn = MAX(ssn)
                                                        FROM  dbo.dls_ssn (NOLOCK);
                                                       
                                                        EXECUTE dbo.dlp_gen_ssn @a_batch_id,
                                                            @a_start_time,
                                                            @n_mb_ssn OUTPUT;
                                                    END;
				
                                                SET @n_mb_sub_ssn = @n_mb_ssn;
                                                IF ( @n_mb_sub_ssn IS NULL
                                                     OR @n_mb_sub_ssn = ''
                                                   )
												   BEGIN
												    SET @a_error_no = 3
                                                    RAISERROR('Cannot find SSN when Create SSN flag is on',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
													
												  END
                                            END;
                                    END;
                                ELSE
                                    IF ( @t_sub_ssn IS NULL
                                         OR @t_sub_ssn = ''
                                       )
                                        BEGIN
                                            SET @n_mb_sub_ssn = @t_ssn;
                                            SET @n_mb_ssn = @t_ssn;
                                        END;
                                    ELSE
                                        IF ( @t_ssn IS NULL
                                             OR @t_ssn = ''
                                           )
                                            BEGIN
                                                SET @n_mb_sub_ssn = @t_sub_ssn;
                                                SET @n_mb_ssn = @t_sub_ssn;
                                            END;
                                        ELSE
                                            BEGIN
                                                SET @n_mb_sub_ssn = @t_sub_ssn;
                                                SET @n_mb_ssn = @t_ssn;
                                            END;
				
			
		
	
                            SET @n_sub_count = @n_sub_count + 1;
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.dls_sg_member (NOLOCK)
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND alt_id = @t_sub_alt_id
                                                AND member_flag = '00'
                                                AND msg_alt_id = @t_msg_alt
                              AND plan_dsp_name = @t_plan_dsp_name
                                                AND dls_sir_id != @n_sub_sir_id )
								BEGIN
								 SET @a_error_no = 10
									RAISERROR('Same alt_id for different subscriber',0,1);
									EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
								END
	
                            IF @s_error = 'N'
                                BEGIN
                                    SET @a_error_no = 31;
                                    IF ( @t_producer_id IS NULL )
                                        SET @t_producer_id = 0;
		
                                    IF ( @t_producer_id = 0
                  AND ( ( @t_producer_alt IS NULL
          OR @t_producer_alt = ''
 )
                 OR LEN(@t_producer_alt) = 0
                                             )
                                       )
                                        BEGIN
                                            SET @v_Null = 0;
                                        END;
			--RAISE EXCEPTION -746,0,"PRODUCER NOT MANDATORY NOW";
                                    ELSE
                                        IF ( @t_producer_id > 0
                                             AND ( ( @t_producer_alt IS NOT NULL
                                                     AND @t_producer_alt <> ''
                                                   )
                                                   AND LEN(@t_producer_alt) > 0
                                                 )
                                           )
                                            BEGIN
                                                SET @n_count = 0;
                                                SELECT  @n_count = COUNT(*)
                                                FROM    dbo.pd (NOLOCK)
                                                WHERE   alt_id = @t_producer_alt
                                                        AND producer_id = @t_producer_id;
                                                IF ( @n_count = 0 )
												BEGIN
												 SET @a_error_no = 27
                                                    RAISERROR('PROD NOT found based on ID and Alt ID',0,1);
													EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
												END
                                            END;
                                        ELSE
                                            IF ( ( @t_producer_alt IS NOT NULL
                                                   AND @t_producer_alt <> ''
                                                 )
                                                 AND LEN(@t_producer_alt) > 0
                                               )
                                                BEGIN
                                                    SET @n_count = 0;
                                                    SET @a_error_no = 28;
                                                    SELECT  @n_count = COUNT(*)
                                                    FROM    dbo.pd (NOLOCK)
                                     WHERE   alt_id = @t_producer_alt;
                                                    IF ( @n_count = 0 )
													BEGIN
													 SET @a_error_no = 28
                                 RAISERROR('PRODUCER NOT found based on Alt ID',0,1);
														EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
													END
                                                    ELSE
                                                        IF ( @n_count > 1 )
                              BEGIN
                   SET @a_error_no = 29;
															  BEGIN
															   SET @a_error_no = 29
																  RAISERROR('Multiple Pds found based on Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                                                            END;
                                                    SELECT  @t_producer_id = producer_id
                                                    FROM    dbo.pd (NOLOCK)
                                                    WHERE   alt_id = @t_producer_alt; 
                                                   
                                                END;
                                            ELSE
                                                IF ( @t_producer_id > 0 )
                                                    BEGIN
                                                        SET @a_error_no = 30;
SELECT
                          @t_producer_id = producer_id ,
                  @t_producer_alt = alt_id
          FROM  dbo.pd (NOLOCK)
       WHERE producer_id = @t_producer_id; 
                  
         IF ( @t_producer_id = 0 )
														BEGIN
														 SET @a_error_no = 30
                                                            RAISERROR('Producer not found based on ID',0,1);
															EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
														END
				
                                                        IF ( (@t_producer_alt IS NULL
                                                             OR @t_producer_alt = '')
                                                           )
                                                            SET @t_producer_alt = '';
                                                    END;
		
                                    UPDATE  dbo.dls_sg_member
                                    SET     producer_id = @t_producer_id ,
                                            prod_alt_id = @t_producer_alt
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;

											
                                    INSERT  INTO #SWV_cursor_var2
                                            ( dls_sir_id ,
                                              alt_id ,
                                              member_flag ,
                                              sub_alt_id ,
                                              dls_status ,
                                              nameprefix ,
                                              ssn ,
                                              sub_ssn ,
                                              student_flag ,
                                              disable_flag ,
                                              city ,
                                              state ,
											  zip ,
                                              selling_period ,
                                              msg_group_id ,
                                              msg_alt_id ,
                                              plan_id ,
                                              plan_dsp_name ,
                                              facility_id ,
                                              fc_alt_id ,
                                              pend_yn
                                            )
                                            SELECT  dls_sir_id ,
                                                    alt_id ,
                                                    member_flag ,
                                                    sub_alt_id ,
                                              dls_status ,
													nameprefix ,
                                                    ssn ,
                                                    sub_ssn ,
                                                    student_flag ,
                                                    disable_flag ,
                                                    city ,
                                                    state ,
                                                    zip ,
                                                    selling_period ,
                                                    msg_group_id ,
                                                    msg_alt_id ,
                                                    plan_id ,
                                                    plan_dsp_name ,
                                                    facility_id ,
                                                    fc_alt_id ,
                                                    pend_yn
                                            FROM    dbo.dls_sg_member (NOLOCK)
                                         WHERE   ISNULL(dls_batch_id,'') = ISNULL(@a_batch_id,'')
                                    AND ISNULL(sub_alt_id,'') = ISNULL(@t_sub_alt_id,'')
			  --$$20130929$$ks
                                              AND ISNULL(msg_alt_id,'') = ISNULL(@t_msg_alt,'')
               AND ISNULL(plan_dsp_name,'') = ISNULL(@t_plan_dsp_name,'')
                                AND dls_status NOT IN (
                                                    'V', 'E', 'P', 'U' ) 
			  --	dls_status = "L" 
                                            ORDER BY member_flag;
											
											
                                 /*   SET #SWV_cursor_var2 = CURSOR  FOR SELECT dls_sir_id, alt_id, member_flag, sub_alt_id, dls_status,
			 nameprefix, ssn, sub_ssn, student_flag, disable_flag, city, state,
			 zip, selling_period , msg_group_id, msg_alt_id,
			 plan_id, plan_dsp_name, facility_id, fc_alt_id, pend_yn
			 
                  FROM dbo.dls_sg_member (NOLOCK) WHERE dls_batch_id = @a_batch_id
                  AND sub_alt_id = @t_sub_alt_id 
			  --$$20130929$$ks
                  AND msg_alt_id = @t_msg_alt
                  AND plan_dsp_name = @t_plan_dsp_name
                  AND dls_status NOT IN('V','E','P','U') 
			  --	dls_status = "L" 
                  ORDER BY member_flag;
                                    OPEN #SWV_cursor_var2;
                                    FETCH NEXT FROM #SWV_cursor_var2 INTO @t_sir_id,
                                        @t_alt_id, @t_member_flag,
                                        @t_sub_alt_id, @t_dls_status,
                                        @n_paperless, @t_ssn, @t_sub_ssn,
                                        @t_student_flag, @t_disable_flag,
                                        @t_city, @t_state, @t_zip,
                                        @t_selling_period, @t_msg_id,
                                        @t_msg_alt, @t_plan_id,
                                        @t_plan_dsp_name, @t_fc_id, @t_fc_alt,
                                        @t_pend_yn;
                                    WHILE @@FETCH_STATUS = 0 
									*/
                                    DECLARE @cur3_cnt INT ,
                                        @cur3_i INT;

                                    SET @cur3_i = 1;

					--Get the no. of records for the cursor
                                    SELECT  @cur3_cnt = COUNT(1)
                                    FROM    #SWV_cursor_var2;
					
					--while @@FETCH_STATUS = 0
                                    WHILE ( @cur3_i <= @cur3_cnt )
                                        BEGIN
                                           BEGIN
                 BEGIN TRY

                                                    SELECT  @t_sir_id = dls_sir_id ,
															@t_alt_id = alt_id ,
                                                            @t_member_flag = member_flag ,
                                                            @t_sub_alt_id = sub_alt_id ,
                                                            @t_dls_status = dls_status ,
                                                            @n_paperless = nameprefix ,
                                                            @t_ssn = ssn ,
                                                            @t_sub_ssn = sub_ssn ,
                                                            @t_student_flag = student_flag ,
                                                            @t_disable_flag = disable_flag ,
                                                            @t_city = city ,
                                                            @t_state = state ,
                                                            @t_zip = zip ,
															 @t_selling_period = selling_period ,
														  @t_msg_id = msg_group_id ,
															 @t_msg_alt = msg_alt_id ,
																	  @t_plan_id = plan_id ,
																	  @t_plan_dsp_name = plan_dsp_name ,
																					@t_fc_id = facility_id ,
															  @t_fc_alt = fc_alt_id ,
														  @t_pend_yn = pend_yn
													FROM    #SWV_cursor_var2
                                                    WHERE   id = @cur3_i;

                                                    SET @n_process_count = @n_process_count + 1;
                                                    BEGIN
                                                        
                                                        IF @s_create_ssn = 'Y'
                                                            BEGIN
                                                              IF @t_member_flag != '00'
                                                              IF ( @t_sub_ssn IS NULL
                                                              OR @t_sub_ssn = ''
                                                              )
                                                              AND ( @t_ssn IS NULL
                                                              OR @t_ssn = ''
                                                              )
                                                              BEGIN
                                                              SELECT @n_count = COUNT(*)
                                                              FROM     dbo.member (NOLOCK)
                                                              WHERE
                                                              alt_id = @t_alt_id;
                                                              IF @n_count > 1
															  BEGIN
															   SET @a_error_no = 2
																  RAISERROR('Multi Dep recs based on alt_id',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
						
                                                              SELECT
                                                              @n_mb_ssn = member_ssn
                                                              FROM
                                                              dbo.member (NOLOCK)
                                                              WHERE
                                                 alt_id = @t_alt_id;
                                                              
                                                              IF ( @n_mb_ssn IS NULL
                                                              OR @n_mb_ssn = ''
                                       )
                                                              SET @n_mb_ssn = @n_mb_sub_ssn;
                                                              END;
                                                              ELSE
                                                              IF ( @t_ssn IS NULL
                                                              OR @t_ssn = ''
                                                              )
                                                              SET @n_mb_ssn = @n_mb_sub_ssn;
                                                              ELSE
                                                              SET @n_mb_ssn = @t_ssn;
						
					
				
                                                              UPDATE
                                                        dbo.dls_sg_member
                                                              SET
                                               sub_ssn = @n_mb_sub_ssn ,
                                                              ssn = @n_mb_ssn
                                                 WHERE
                     dls_batch_id = @a_batch_id
                                                           AND dls_sir_id = @t_sir_id;
        END;
			 -- create_ssn = "Y"
     END;
                          BEGIN
          IF ( @t_msg_id = 0
                                                             AND ( ( @t_msg_alt IS NULL
                                                              OR @t_msg_alt = ''
                                                              )
                                                              OR LEN(@t_msg_alt) = 0
                                                              )
                                                           )
                                                            BEGIN
                                                              SET @a_error_no = 12;
                                                              RAISERROR('M Single group info is missing in Tape',0,1);
															  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
                                                            END;
                                                        ELSE
                                    IF ( @t_msg_id > 0
                                                              AND ( ( @t_msg_alt IS NOT NULL
                                                              AND @t_msg_alt <> ''
                                                              )
                                                              AND LEN(@t_msg_alt) > 0
                                                              )
                                                              )
                                                              BEGIN
                                                              SET @n_count = 0;
                                                              SET @a_error_no = 13;
                                                              
															  SELECT
                                                              @n_count = COUNT(*)
                                                              FROM dbo.[group] (NOLOCK)
                                                              WHERE alt_id = @t_msg_alt
                                                              AND group_id = @t_msg_id
                                                              AND group_type = 'MS';
                                                              IF ( @n_count = 0 )
															  BEGIN
															   SET @a_error_no = 13
																  RAISERROR('MSG not found base on ID and Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                                                              END;
                                                            ELSE
                                                              IF ( ( @t_msg_alt IS NOT NULL
                                                              AND @t_msg_alt <> ''
                                                              )
                                                              AND LEN(@t_msg_alt) > 0
                                                              )
                                                              BEGIN
                                                              SET @a_error_no = 14;
                                                             SELECT
                                                              @n_count = COUNT(*)
                                                        FROM
                                                              dbo.[group] (NOLOCK)
                                    WHERE
                                                              alt_id = @t_msg_alt
                                                              AND group_type = 'MS';
                            IF ( @n_count = 0 )
															  BEGIN
															   SET @a_error_no = 14
																RAISERROR('MSG not found based on Alt ID',0,1);
																EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                                                  ELSE
                            IF ( @n_count > 1 )
                                 BEGIN
         SET @a_error_no = 15;
															  BEGIN
															   SET @a_error_no = 15
																  RAISERROR('Multiple MSG found based on Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                                                              END;
                                                              SELECT
                                                              @t_msg_id = group_id
                                                              FROM
                                                              dbo.[group] (NOLOCK)
                                                              WHERE
                                                              alt_id = @t_msg_alt
             AND group_type = 'MS';
                                                             
                                                              END;
                                                              ELSE
                                                              IF ( @t_msg_id > 0 )
                                                              BEGIN
                                                              SET @a_error_no = 16;
                                                              SELECT
                                                              @t_msg_id = group_id ,
                                                              @t_msg_alt = alt_id
                                                              FROM
                                                              dbo.[group] (NOLOCK)
                                                             WHERE
                                                              group_id = @t_msg_id
                                                              AND group_type = 'MS';
                                                            
														IF ( @t_msg_id = 0 )
														BEGIN
														 SET @a_error_no = 16
                                            RAISERROR('MSG not found based on ID',0,1);
															  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
														END
					
                                                              IF ( (@t_msg_alt IS NULL
                                                              OR @t_msg_alt = '')
                                                              )
                                                              SET @t_msg_alt = '';
                                                              END;
			
                                                    END;
                                                    BEGIN
                                                        IF ( @t_plan_id = 0
                                                             AND ( ( @t_plan_dsp_name IS NULL
                                                              OR @t_plan_dsp_name = ''
                                                              )
               OR LEN(@t_plan_dsp_name) = 0
                                                              )
                                                           )
                           BEGIN
                                                              SET @a_error_no = 17;
                                                              RAISERROR('Plan information is missing in Tape',0,1);
															  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
                                                            END;
                                                        ELSE
                                                            IF ( @t_plan_id > 0
  AND ( ( @t_plan_dsp_name IS NOT NULL
                                                              AND @t_plan_dsp_name <> ''
                                                              )
     AND LEN(@t_plan_dsp_name) > 0
                                                  )
           )
                   BEGIN
                    SET @n_count = 0;
															SET @a_error_no = 18;
                                                              SELECT
                                                              @n_count = COUNT(*)
                                                              FROM
                                                              dbo.[plan] (NOLOCK)
                                                              WHERE
                                                              plan_dsp_name = @t_plan_dsp_name
                                                              AND plan_id = @t_plan_id;
                                                              IF ( @n_count = 0 )
															  BEGIN
															   SET @a_error_no = 18
																  RAISERROR('Plan not found based ID and Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                                                              END;
                                                            ELSE
                                                              IF ( ( @t_plan_dsp_name IS NOT NULL
                                                              AND @t_plan_dsp_name <> ''
                                                              )
                                                              AND LEN(@t_plan_dsp_name) > 0
                                                              )
                                                              BEGIN
                                                              SELECT
             @n_count = COUNT(*)
                                                              FROM
                            dbo.[plan] (NOLOCK)
            WHERE
                                                              plan_dsp_name = @t_plan_dsp_name;
                                                              IF ( @n_count = 0 )
                                                              BEGIN
                                                              SET @a_error_no = 19;
																  RAISERROR('Plan not found based on Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
                                                              END;
                                                              ELSE
                                                              IF ( @n_count > 1 )
                                                              BEGIN
                                                              SET @a_error_no = 20;
																  RAISERROR('Multi Plans found based on Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
                                            END;
                                                              SELECT
                                                              @t_plan_id = plan_id
                                           FROM
                                                              dbo.[plan] (NOLOCK)
                                                              WHERE
                                       plan_dsp_name = @t_plan_dsp_name; 
                                                             
                                                      END;
                                                              ELSE
                                                           IF ( @t_plan_id > 0 )
                                                              BEGIN
             SET @a_error_no = 21;
    SELECT
                         @t_plan_id = plan_id ,
                                                              @t_plan_dsp_name = plan_dsp_name
              FROM
                                                              dbo.[plan] (NOLOCK)
                            WHERE
                                                           plan_id = @t_plan_id; 
                                                         
                                                              IF ( @t_plan_id = 0 )
															  BEGIN
															   SET @a_error_no = 21
																RAISERROR('Plan not found based on ID',0,1);
																EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
					
                                                              IF ( (@t_plan_dsp_name IS NULL
                                                              OR @t_plan_dsp_name = '')
                                                              )
                                                              SET @t_plan_dsp_name = '';
                                                              END;
			
                                                    END;
                                                    BEGIN
                                                        IF ( @t_fc_id = 0
                                                             AND ( ( @t_fc_alt IS NULL
                                                              OR @t_fc_alt = ''
                                      )
                                                              OR LEN(@t_fc_alt) = 0
                                                            )
                                                           )
                                                            BEGIN
																SET @v_Null = 0;
                                                            END;
			 --RAISE EXCEPTION -746,12,"Facility information is missing in Tape";
                                                        ELSE
                                                            IF ( @t_fc_id > 0
                                                              AND ( ( @t_fc_alt IS NOT NULL
                                                              AND @t_fc_alt <> ''
                                                              )
                                                              AND LEN(@t_fc_alt) > 0
                                                              )
                                                              )
                                                              BEGIN
                                                              SET @n_count = 0;
                                                              SET @a_error_no = 22;
                                                              SELECT
                                     @n_count = COUNT(*)
                                                              FROM
                                                              dbo.facility (NOLOCK)
                         WHERE
                                                              alt_id = @t_fc_alt
                                                              AND fc_id = @t_fc_id;
IF ( @n_count = 0 )
															  BEGIN
															   SET @a_error_no = 22
																  RAISERROR('FC not found based on ID and Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                     END;
                                                            ELSE
                                                    IF ( ( @t_fc_alt IS NOT NULL
                                                              AND @t_fc_alt <> ''
                                                              )
             AND LEN(@t_fc_alt) > 0
                                                              )
                                                BEGIN
SET @a_error_no = 24;
                                                              SELECT
                                                              @n_count = COUNT(*)
                        FROM
                                                              dbo.facility (NOLOCK)
                                  WHERE
     alt_id = @t_fc_alt;
          IF ( @n_count = 0 )
															  BEGIN
															   SET @a_error_no = 24
																  RAISERROR('Facility not found based on Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
                                                              ELSE
                                                              IF ( @n_count > 1 )
                                                              BEGIN
                                                              SET @a_error_no = 25;
																  RAISERROR('Multi FC found based on Alt ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
                                                              END;
                                                              SELECT
                                                     @t_fc_id = fc_id
                               FROM
                                                              dbo.facility (NOLOCK)
                                                              WHERE
																alt_id = @t_fc_alt;
                                                      
                                                              END;
                                                              ELSE
                                                              IF ( @t_fc_id > 0 )
                                                              BEGIN
                                                              SET @a_error_no = 26;
                                                              SELECT
                                                              @t_fc_id = fc_id ,
                                                              @t_fc_alt = alt_id
                                                              FROM
                                                              dbo.facility (NOLOCK)
                                                              WHERE
                                                              fc_id = @t_fc_id; 
                                                             
                                                              IF ( @t_fc_id = 0 )
															  BEGIN
															   SET @a_error_no = 26
																  RAISERROR('Facility not found based on ID',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
					
                                                              IF ( (@t_fc_alt IS NULL
                                                              OR @t_fc_alt = '')
                       )
                                                              SET @t_fc_alt = '';
                                                              END;
			
                                                        UPDATE
                                                              dbo.dls_sg_member
 SET   plan_id = @t_plan_id ,
                                                              plan_dsp_name = @t_plan_dsp_name ,
                                                              facility_id = @t_fc_id ,
                                                    fc_alt_id = @t_fc_alt ,
                                                              msg_group_id = @t_msg_id ,
                   msg_alt_id = @t_msg_alt
                                                        WHERE dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
 END;
                    IF ( @t_pend_yn IS NULL
       OR @t_pend_yn = ''
                                                       )
          SET @t_pend_yn = '';
			
                                                    IF @t_pend_yn IN ( 'y',
                                                              '1' )
                                                  SET @t_pend_yn = 'Y';
                     ELSE
                                                        IF @t_pend_yn IN ( 'n',
                                                           '0' )
                                                            SET @t_pend_yn = 'N';
                                                    IF @t_pend_yn NOT IN ( '',
                                                              'Y', 'N' )
															  BEGIN
															   SET @a_error_no = 200
																RAISERROR('Invalid pend value',0,1);
																EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
														END
			
                                                    UPDATE  dbo.dls_sg_member
                       SET     pend_yn = @t_pend_yn
                                                    WHERE   dls_batch_id = @a_batch_id
                                                            AND dls_sir_id = @t_sir_id;
                   SET @a_error_no = 20;
                                                    IF ( (@t_student_flag IS NULL
                                                         OR @t_student_flag = '')
                                                       )
                                                        OR LEN(@t_student_flag) = 0
                                                        UPDATE
                                                              dbo.dls_sg_member
                                                        SET   student_flag = 'N'
                                                        WHERE dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
			
                                                    SET @a_error_no = 21;
			---20120528$$ks - added clean up logic for paperless switch
                                                    IF ( ( @n_paperless IS NOT NULL
                                                           AND @n_paperless <> ''
                            )
                                                         AND @n_paperless NOT IN (
                                                         'Y', 'N' )
                                                       )
                     BEGIN
   SET @t_paperless = NULL;
                                                            IF @n_paperless = 0
                                                              OR @n_paperless = 'n'
                                                              SET @t_paperless = 'N';
				
                                                            IF @n_paperless = 0
                                                              OR @n_paperless = 'y'
                                        SET @t_paperless = 'Y';
				
                                                            UPDATE
                                                              dbo.dls_sg_member
                               SET
                                                              nameprefix = @t_paperless
                                                            WHERE
               dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
                                                        END;
			
                                                    SET @a_error_no = 30;
     IF ( (@t_disable_flag IS NULL
                                                         OR @t_disable_flag = '')
                                              )
 OR LEN(@t_disable_flag) = 0
      UPDATE
                                                              dbo.dls_sg_member
                                                        SET   disable_flag = 'N'
                                                        WHERE dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
			
                                                    BEGIN
 -- DECLARE @SWV_cursor_var3 CURSOR;
                                                        DECLARE @SWV_cursor_var3 TABLE
                                                            (
                                   id INT IDENTITY ,
                                                               city CHAR(30) ,
                                                              state_code CHAR(2)
                                                            );
     IF ( (@t_zip IS NOT NULL
                                                             AND @t_zip <> '')
     )
                                                            AND LEN(@t_zip) > 0
                                                            BEGIN
                                                              SET @a_error_no = 40;
                                                              SET @d_city = NULL;
			 -- for out of loop test
			
                                                              INSERT
                                                              INTO @SWV_cursor_var3
                                                              (
                                                              city ,
                                                              state_code
                                                              )
                                                              SELECT
                                                              city ,
                                                              state_code
                                                              FROM
                                                              dbo.usa_zip (NOLOCK)
                                                              WHERE
      zip_code = SUBSTRING(@t_zip,
                                                              1, 5);

                                                          /*    SET @SWV_cursor_var3 = CURSOR  FOR SELECT city, state_code  FROM dbo.usa_zip (NOLOCK)
                                 WHERE zip_code = SUBSTRING(@t_zip,1,5);
                                              OPEN @SWV_cursor_var3;
                                                              FETCH NEXT FROM @SWV_cursor_var3 INTO @d_city,
                  @d_state;
                                                              WHILE @@FETCH_STATUS = 0
															  */
                                                              DECLARE @cur4_cnt INT ,
                                                              @cur4_i INT;

                                                              SET @cur4_i = 1;

					--Get the no. of records for the cursor
                                                              SELECT
                                            @cur4_cnt = COUNT(1)
                                                              FROM
                                                              @SWV_cursor_var3;
					
					--while @@FETCH_STATUS = 0
                                                              WHILE ( @cur4_i <= @cur4_cnt )
                                                              BEGIN
                                                              SELECT
                               @d_city = city ,
                                                              @d_state = state_code
                                                             FROM
                                                              @SWV_cursor_var3
                                                              WHERE
                                        id = @cur4_i;
                                                              IF ( ( @t_city IS NULL
                                 OR @t_city = ''
                                                              )
  OR ( ( @t_city IS NOT NULL
                                                              AND @t_city <> ''
                                                              )
  AND LEN(@t_city) = 0
                                                              )
                                                              )
                                                              GOTO SWL_Label2;
				
                                                              IF ( @t_city IS NOT NULL
                                                              AND @t_city <> ''
                                                              )
                                          IF @d_city = @t_city
                                                              GOTO SWL_Label2;
					
				
                                                              SET @d_city = NULL;
                                                              /*FETCH NEXT FROM @SWV_cursor_var3 INTO @d_city,
                                                              @d_state;*/
                                                              SET @cur4_i = @cur4_i
                                                              + 1;
                                                              END;
                                                              SWL_Label2:
                                     --CLOSE @SWV_cursor_var3;
                                                              IF ( ( ( @d_city IS NULL
                                                              OR @d_city = ''
                                                              )
                                                        OR ( ( @d_city IS NOT NULL
                                                              AND @d_city <> ''
                                                              )
                                                              AND LEN(@d_city) = 0
                     )
                                                              )
                                                              OR ( ( @d_state IS NULL
                                                              OR @d_state = ''
                                                     )
                                                              OR ( ( @d_state IS NOT NULL
                                                              AND @d_state <> ''
                                                              )
                                                      AND LEN(@d_state) = 0
                                                              )
                                                              )
                                   )
															  BEGIN
															   SET @a_error_no = 40
																  RAISERROR('Error in ZIPCODE information',0,1);
																  EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id, @i_sir_def_id, @t_sir_id, @a_error_no;
					  IF @i_fatal <> 1 
						SET @s_error = 'Y';
															  END
				
                                                              SET @a_error_no = 50;
                                                              IF ( ( ( @t_city IS NULL
                                                  OR @t_city = ''
                                                              )
                      OR ( ( @t_city IS NOT NULL
                                                              AND @t_city <> ''
                                         )
                                                              AND LEN(@t_city) = 0
                                                              )
                                                              )
                                                            AND ( @d_city IS NOT NULL
             AND @d_city <> ''
)
                                                              )
                                                              UPDATE
                                                      dbo.dls_sg_member
                                                              SET
                                                              city = @d_city
                                                              WHERE
                                                              dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
				
                                                              SET @a_error_no = 60;
                         IF ( ( ( @t_state IS NULL
                                                              OR @t_state = ''
                                                              )
                                                              OR ( ( @t_state IS NOT NULL
                                                              AND @t_state <> ''
                                                          )
                                                              AND LEN(@t_state) = 0
                                                              )
                                                              )
                                     AND ( @d_state IS NOT NULL
                AND @d_state <> ''
                                                              )
                                                              )
                                                              UPDATE
                                    dbo.dls_sg_member
                                                              SET
                                                              state = @d_state
                                                              WHERE
                                                              dls_batch_id = @a_batch_id
                                          AND dls_sir_id = @t_sir_id;
                                                            END;
			
                                                    END;
                                                    SET @a_error_no = 70;
                                          IF ( (@t_selling_period IS NULL
                                                         OR @t_selling_period = '')
                                                       )
                                                        OR LEN(@t_selling_period) = 0
                                                 UPDATE
                                                              dbo.dls_sg_member
                                                        SET   selling_period = 'N'
                                     WHERE dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
			
                                                    IF @s_error = 'Y'
                                                        UPDATE
                                                              dbo.dls_sg_member
                                                    SET   dls_status = 'E' ,
                                                              dls_sub_sir_id = @n_sub_sir_id
														WHERE dls_batch_id = @a_batch_id
                                                              AND sub_alt_id = @t_sub_alt_id
                                                              AND msg_alt_id = @t_msg_alt  --$$20130929$$ks
                                                              AND plan_dsp_name = @t_plan_dsp_name;
                              ELSE
                                                        BEGIN
											SET @n_succ_count = @n_succ_count+ 1;
                                                            UPDATE
                                  dbo.dls_sg_member
                                                            SET
                                                              dls_status = 'V' ,
                              dls_sub_sir_id = @n_sub_sir_id
                                                            WHERE
                                                              dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @t_sir_id;
                                                        END;
                                                END TRY
                                                BEGIN CATCH
                                                    SET @i_error_no = ERROR_NUMBER();
                                                    SET @i_isam_error = ERROR_LINE();
                                                    SET @s_error_descr = ERROR_MESSAGE();
                                                    
                                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                   @i_sp_id,
                                                        @i_sir_def_id,
                                                        @t_sir_id,
                                                        @a_error_no;
													IF @i_fatal <> 1
                                                        SET @s_error = 'Y';
											IF @s_error='Y'
											BEGIN
														  
													UPDATE  dbo.dls_sg_member
													SET     dls_status = 'E' ,
															dls_sub_sir_id = @n_sub_sir_id
													WHERE   dls_batch_id = @a_batch_id
															AND dls_sir_id = @t_sir_id;
										END
												
                                                END CATCH;
                                            END;
                                           /* FETCH NEXT FROM #SWV_cursor_var2 INTO @t_sir_id,
                                                @t_alt_id, @t_member_flag,
                        @t_sub_alt_id, @t_dls_status,
                                                @n_paperless, @t_ssn,
                                                @t_sub_ssn, @t_student_flag,
                                                @t_disable_flag, @t_city,
                  @t_state, @t_zip,
                                                @t_selling_period, @t_msg_id,
                                                @t_msg_alt, @t_plan_id,
                                                @t_plan_dsp_name, @t_fc_id,
                                                @t_fc_alt, @t_pend_yn; */
                                           SET @cur3_i = @cur3_i + 1;
                                        END;
                                    --CLOSE #SWV_cursor_var2;
                         END;
                            ELSE
                                BEGIN
                                   SET @n_process_count = @n_process_count + 1;
                                    UPDATE  dbo.dls_sg_member
                                    SET     dls_status = 'E' ,
                                            dls_sub_sir_id = @n_sub_sir_id
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
	
                            IF @n_in_transaction = 'Y'
							BEGIN
                                    
                                    SET @n_in_transaction = 'N';
							 END;
	
                            IF @n_sub_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
										tot_fail_rec = @n_process_count - @n_succ_count
								WHERE   bat_statistics_id = @i_statistics_id;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
  SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                            
                                            SET @n_in_transaction = 'N';
                                        END;
			
                                    IF @i_error_no <> 50000
SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
									RETURN
                                END;
		
                            
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @a_error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';

								IF @s_error='Y'
											BEGIN
													SET @n_process_count = @n_process_count + 1;
														  
													UPDATE  dbo.dls_sg_member
													SET     dls_status = 'E' ,
															dls_sub_sir_id = @n_sub_sir_id
													WHERE   dls_batch_id = @a_batch_id
															AND dls_sir_id = @t_sir_id;
										END
								
                        END CATCH;
                    END;
                    /*
					FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_sub_sir_id,
                        @t_sub_alt_id, @t_ssn, @t_sub_ssn, @t_producer_id,
                        @t_producer_alt, @t_msg_id, @t_msg_alt,
                        @t_plan_dsp_name;
						*/
                    SET @cur2_i = @cur2_i + 1;
                END;
            -- CLOSE @cSIR;
            INSERT  INTO @SWV_cursor_var4
                    ( dls_sub_sir_id ,
                     dls_sir_id ,
                      sub_alt_id
			        )
                    SELECT  dls_sub_sir_id ,
                            dls_sir_id ,
                            sub_alt_id
                    FROM    dbo.dls_sg_member (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND member_flag != '00'
                            AND dls_status = 'L'
                            AND dls_sir_id NOT IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dl_log_error (NOLOCK)
                            WHERE   config_bat_id = @a_batch_id
                                    AND sp_id = @i_sp_id
                                    AND sir_def_id = @i_sir_def_id );

           /* SET @SWV_cursor_var4 = CURSOR  FOR SELECT dls_sub_sir_id, dls_sir_id, sub_alt_id
	
      FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND
      member_flag != '00' AND dls_status = 'L'
      AND dls_sir_id NOT IN(SELECT dls_sir_id FROM
      dbo.dl_log_error (NOLOCK) WHERE config_bat_id = @a_batch_id AND
      sp_id = @i_sp_id AND sir_def_id = @i_sir_def_id);
            OPEN @SWV_cursor_var4;
            FETCH NEXT FROM @SWV_cursor_var4 INTO @t_sub_sir_id, @t_sir_id,
                @t_sub_alt_id;
            WHILE @@FETCH_STATUS = 0 */

            DECLARE @cur5_cnt INT ,
                @cur5_i INT;

            SET @cur5_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur5_cnt = COUNT(1)
       FROM    @SWV_cursor_var4;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur5_i <= @cur5_cnt )
                BEGIN
                 SELECT  @t_sub_sir_id = dls_sub_sir_id ,
                            @t_sir_id = dls_sir_id ,
                            @t_sub_alt_id = sub_alt_id
                    FROM    @SWV_cursor_var4
WHERE   id = @cur5_i;

                    SET @n_process_count = @n_process_count + 1;
                    
                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                        @i_sp_id, @i_sir_def_id, @t_sir_id, 11;
                    /*FETCH NEXT FROM @SWV_cursor_var4 INTO @t_sub_sir_id,
                        @t_sir_id, @t_sub_alt_id; */
                    SET @cur5_i = @cur5_i + 1;
                END;
            --CLOSE @SWV_cursor_var4;
            SET @SWV_func_DL_UPD_STATISTICS_par0 = @n_process_count
                - @n_succ_count;
            EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @SWV_func_DL_UPD_STATISTICS_par0

            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                                   + @n_error_count ),
                                         ' Failed to update statistics');
                    RETURN;
                END;

            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            IF @n_in_transaction = 'N'
                BEGIN
                    
                    SET @n_in_transaction = 'Y';
                END;

            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish After-load process for Batch ',
                                         @a_batch_id);
      RETURN;

            IF ( @do_trace = 1 )
                BEGIN--TRACE statement has no equivalent in MSSQL
--trace off;
                    SET @v_Null = 0;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = @s_error_descr;

			--INSERT INTO ErrorTable (ObjectName,ErrorNo,ErrorLine,ErrorDesc)
			--Select OBJECT_NAME(@@PROCID),@i_error_no,@i_isam_error,@s_error_descr

            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;