﻿CREATE PROC [dbo].[usp_ecl_GetEclaimsForSubmitToDL]
AS
BEGIN
	DECLARE @EVENT_ID INT,
			@BATCH_SUBMITTED_STATUS INT=1,
			@BATCH_LOCKED_STATUS INT=2,
			@BATCH_INPROGRESS_STATUS INT=3,
			@ECLAIM_JOB_RUNNING_STATUS INT=1
	SET @EVENT_ID = (SELECT event_id FROM batch_event_master where event_module='EC' and event_type='SubmitToDataload');
	SELECT eclaim_h.config_name AS ConfigName,   
        count(*) AS EclaimsCount,
        dl_config.config_descr AS ConfigDesc,   
        0 AS BatchId,
        --1 ,   
        dl_config.config_id AS ConfigId
		FROM eclaim_h(NOLOCK) LEFT OUTER JOIN dl_config(NOLOCK) ON
		eclaim_h.config_name = dl_config.config_name
		WHERE(eclaim_h.status = 1) AND
			(eclaim_h.config_name <> '')
		GROUP BY eclaim_h.config_name,   
				dl_config.config_descr,   
				dl_config.config_id

	SELECT  ecl_rp.StatusId	  AS  StatusId,
			ecl_st.StatusDescr AS  StatusDescription,
			StartDate		  AS  StartDate,
			EndDate			  AS  EndDate,
			Parameters		  AS Parameters,
			ReturnValue		  AS ReturnValue,
			ErrorDetail		  AS  ErrorDetail,
			HUser			  AS  HUser
	FROM eclaim_report ecl_rp(NOLOCK)
	LEFT OUTER JOIN eclaim_report_status ecl_st ON ecl_rp.StatusId=ecl_st.StatusId 					  
	WHERE Source='SubmitToDL' ORDER BY StartDate DESC

	IF NOT EXISTS(SELECT batch_id FROM batch_process_details WHERE event_id=@EVENT_ID AND status IN(@BATCH_SUBMITTED_STATUS,@BATCH_LOCKED_STATUS,@BATCH_INPROGRESS_STATUS))
	BEGIN 
		SELECT COUNT(*) FROM eclaim_report(NOLOCK) WHERE Source='SubmitToDL' AND StatusId=@ECLAIM_JOB_RUNNING_STATUS
	END
	ELSE SELECT 1
END