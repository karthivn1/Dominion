﻿CREATE PROCEDURE [dbo].[dl_clean_curr_err]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_sp_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);

        SET NOCOUNT ON;
        BEGIN TRY
            INSERT  INTO dbo.dl_log_error_h
                    ( config_bat_id ,
                      sp_id ,
                      sir_def_id ,
                      dls_sir_id ,
                      error_no ,
                      corrected ,
                      created_by ,
                      created_time
                    )
                    SELECT  config_bat_id ,
                            sp_id ,
                            sir_def_id ,
                            dls_sir_id ,
                            error_no ,
                            corrected ,
                            created_by ,
                            created_time
                    FROM    dbo.dl_log_error (NOLOCK)
                    WHERE   config_bat_id = @a_batch_id
                            AND dls_sir_id = @a_sir_id
                            AND sp_id = @a_sp_id;
            DELETE  FROM dbo.dl_log_error
            WHERE   config_bat_id = @a_batch_id
                    AND dls_sir_id = @a_sir_id
                    AND sp_id = @a_sp_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = 'Done with clean error records';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = 'Error during cleaning error records';
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;