﻿CREATE PROCEDURE [dbo].[dlp_valid_fcnet]
    @a_batch_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT ,
    @SWP_Ret_Value4 DATE = NULL OUTPUT ,
    @SWP_Ret_Value5 DATE = NULL OUTPUT ,
    @SWP_Ret_Value6 DATE = NULL OUTPUT
    


/*error variable*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;

        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);

        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT; 
        DECLARE @s_batch_status CHAR(1);

        DECLARE @n_error_no INT; 
        DECLARE @n_error_text VARCHAR(64);
 
        DECLARE @n_al_count INT;
        DECLARE @i_zip_id INT;
        DECLARE @fcnet_sir_def_name char(18) ;
		DECLARE @fcnet_proc_name char(18) ;
		DECLARE @i_sp_id INT;
		DECLARE @i_sir_def_id INT;
		DECLARE @i_config_id INT;
		DECLARE @n_def_eff_date char(10) ;
		DECLARE @d_def_eff_date date ;
		DECLARE @n_def_exp_date char(10) ;
		DECLARE @d_def_exp_date date ;
		DECLARE @n_has_term_date char(1) ;
		DECLARE @n_net_id INT;
		DECLARE @t_sir_id INT;
		DECLARE @fc_alt_id char(40) ;
		DECLARE @t_fc_type char(2) ;
		DECLARE @t_fc_name char(50) ;
		DECLARE @t_fc_status char(2) ;
		DECLARE @t_fc_stat_eff_date char(10) ;
		DECLARE @t_fc_stat_exp_date char(10) ;
		DECLARE @t_fc_state char(2) ;
		DECLARE @t_fc_license char(9) ;
		DECLARE @t_fc_lrenew_dt char(10) ;
		DECLARE @fc_vendor_id char(40) ;
		DECLARE @t_fc_tax_id char(9) ;
		DECLARE @t_tin char(1) ;
		DECLARE @t_fc_area char(11) ;
		DECLARE @t_fc_rep char(20) ;
		DECLARE @t_fc_source char(2) ;
		DECLARE @t_phone_elig char(1) ;
		DECLARE @t_fax_elig char(1) ;
		DECLARE @t_print_dir char(1) ;
		DECLARE @t_fc_mst_con_dt char(10) ;
		DECLARE @t_emergency_phone char(14) ;
		DECLARE @t_em_phone_ext char(5) ;
		DECLARE @t_emg_contact_type char(2) ;
		DECLARE @t_legal_entity char(2) ;
		DECLARE @t_fc_tax_name char(50) ;
		DECLARE @t_pnrx char(1) ;
		DECLARE @t_no2 char(1) ;
		DECLARE @t_hndacs char(1) ;
		DECLARE @t_fc_capacity char(11) ;
		DECLARE @t_fc_warn char(9) ;
		DECLARE @t_fc_no_new char(9) ;
		DECLARE @t_fc_max_enrl char(11) ;
		DECLARE @t_fc_opr_tory char(11) ;
		DECLARE @fc_parent_id char(40) ;
		DECLARE @t_barrier_c char(10) ;
		DECLARE @t_fc_cur_enrl char(11) ;
		DECLARE @t_next_cap_date char(10) ;
		DECLARE @t_net_id char(20) ;
		DECLARE @t_contract_type char(3) ;
		DECLARE @t_net_fc_eff_date char(10) ;
		DECLARE @t_ovr_ride char(1) ;
		DECLARE @t_net_fc_exp_date char(10) ;
		DECLARE @t_addr_type char(2) ;
		DECLARE @t_addr1 char(30) ;
		DECLARE @t_addr2 char(30) ;
		DECLARE @t_zipcode char(10) ;
		DECLARE @t_city char(30) ;
		DECLARE @t_state char(2) ;
		DECLARE @t_county char(20) ;
		DECLARE @t_country char(3) ;
		DECLARE @t_mail char(1) ;
		DECLARE @t_con_type char(2) ;
		DECLARE @t_con_lname char(15) ;
		DECLARE @t_con_fname char(10) ;
		DECLARE @t_title char(25) ;
		DECLARE @t_phone1 char(14) ;
		DECLARE @t_ext1 char(5) ;
		DECLARE @t_phone2 char(14) ;
		DECLARE @t_ext2 char(5) ;
		DECLARE @t_fax char(14) ;
		DECLARE @i_fc_id INT;
		DECLARE @as_action_code char(2) ;
		DECLARE @as_fc_stat_eff date ;
		DECLARE @as_fc_net_eff date ;
		DECLARE @as_fc_net_exp date ;
		DECLARE @d_fc_stat_eff_date date ;
		DECLARE @d_fc_lrenew_dt date ;
		DECLARE @d_fc_area INT;
		DECLARE @d_fc_rep INT;
		DECLARE @d_fc_mst_con_dt date ;
		DECLARE @d_fc_capacity INT;
		DECLARE @d_fc_warn NUMERIC(5,2) ;
		DECLARE @d_fc_no_new NUMERIC(5,2) ;
		DECLARE @d_fc_max_enrl INT;
		DECLARE @d_fc_opr_tory INT;
		DECLARE @d_barrier_c NUMERIC(6,2);
		DECLARE @d_fc_cur_enrl INT;
		DECLARE @d_next_cap_date date ;
		DECLARE @d_net_id INT;
		DECLARE @d_net_fc_eff_date date ;
		DECLARE @d_net_fc_exp_date date ;
		DECLARE @d_zip INT;
		DECLARE @d_phone_err char(1) ;
		DECLARE @d_phone1 INT;
		DECLARE @d_ext1 INT;
		DECLARE @d_phone2 INT;
		DECLARE @d_ext2 INT;
		DECLARE @d_fax INT;
		DECLARE @n_process_count INT; 
		DECLARE @n_error_count INT; 
		DECLARE @n_succ_count INT;
        DECLARE @SWV_dl_get_sp_id INT;
        --DECLARE @SWV_cursor_var1 CURSOR;



        SET NOCOUNT ON;
        SET @fcnet_sir_def_name = 'fac_net' ;
      
        SET @fcnet_proc_name = 'bu_fac_net' ;
       
        SET @i_sp_id = 0 ;
      
        SET @i_sir_def_id = 0 ;
     
        SET @i_config_id = 0 ;
       
        SET @n_def_eff_date = '' ;
     
        SET @d_def_eff_date = NULL ;
       
        SET @n_def_exp_date = '' ;
       
        SET @d_def_exp_date = NULL ;
        
        SET @n_has_term_date = '' ;
       
        SET @n_net_id = 0 ;
      
        SET @t_sir_id = 0 ;
      
        SET @fc_alt_id = '' ;

        SET @t_fc_type = '' ;
       
        SET @t_fc_name = '' ;
     
        SET @t_fc_status = '' ;
       
        SET @t_fc_stat_eff_date = '' ;
       
        SET @t_fc_stat_exp_date = '' ;
       
        SET @t_fc_state = '' ;
      
        SET @t_fc_license = '' ;
    
        SET @t_fc_lrenew_dt = '' ;
     
        SET @fc_vendor_id = '' ;
  
        SET @t_fc_tax_id = '' ;
      
        SET @t_tin = '' ;
       
        SET @t_fc_area = '' ;
   
        SET @t_fc_rep = '' ;
    
        SET @t_fc_source = '' ;
        
        SET @t_phone_elig = '' ;
     
        SET @t_fax_elig = '' ;

        SET @t_print_dir = '' ;

        SET @t_fc_mst_con_dt = '' ;
     
        SET @t_emergency_phone = '' ;
     
        SET @t_em_phone_ext = '' ;
     
        SET @t_emg_contact_type = '' ;

        SET @t_legal_entity = '' ;

        SET @t_fc_tax_name = '' ;
    
        SET @t_pnrx = '' ;
    
     SET @t_no2 = '' ;
     
        SET @t_hndacs = '' ;
    
        SET @t_fc_capacity = '' ;
     
        SET @t_fc_warn = '' ;

        SET @t_fc_no_new = '' ;
    
        SET @t_fc_max_enrl = '' ;
      
        SET @t_fc_opr_tory = '' ;
 
        SET @fc_parent_id = '' ;
 
        SET @t_barrier_c = '' ;
    
        SET @t_fc_cur_enrl = '' ;

        SET @t_next_cap_date = '' ;
     
        SET @t_net_id = '' ;
     
        SET @t_contract_type = '' ;
  
        SET @t_net_fc_eff_date = '' ;
     
        SET @t_ovr_ride = '' ;

        SET @t_net_fc_exp_date = '' ;
     
        SET @t_addr_type = '' ;
      
        SET @t_addr1 = '' ;
   
        SET @t_addr2 = '' ;

        SET @t_zipcode = '' ;
    
        SET @t_city = '' ;
      
        SET @t_state = '' ;
   
        SET @t_county = '' ;
   
        SET @t_country = '' ;
       
        SET @t_mail = '' ;
      
        SET @t_con_type = '' ;
   
        SET @t_con_lname = '' ;
    
        SET @t_con_fname = '' ;
      
        SET @t_title = '' ;
      
        SET @t_phone1 = '' ;
     
        SET @t_ext1 = '' ;
  
        SET @t_phone2 = '' ;
     
        SET @t_ext2 = '' ;
     
        SET @t_fax = '' ;
     
        SET @i_fc_id = 0 ;
       
        SET @as_action_code = '' ;
        
        SET @as_fc_stat_eff = NULL ;
    
        SET @as_fc_net_eff = NULL ;
     
        SET @as_fc_net_exp = NULL ;
      
        SET @d_fc_stat_eff_date = NULL ;

        SET @d_fc_lrenew_dt = NULL ;
   
        SET @d_fc_area = 0 ;
     
        SET @d_fc_rep = 0 ;
      
        SET @d_fc_mst_con_dt = NULL ;
     
        SET @d_fc_capacity = 0 ;
      
        SET @d_fc_warn = 0 ;
        
        SET @d_fc_no_new = 0 ;
      
        SET @d_fc_max_enrl = 0 ;
   
        SET @d_fc_opr_tory = 0 ;
    
        SET @d_barrier_c = 0 ;
  
        SET @d_fc_cur_enrl = 0 ;
       
        SET @d_next_cap_date = NULL ;
  
        SET @d_net_id = 0 ;
     
        SET @d_net_fc_eff_date = NULL ;
      
        SET @d_net_fc_exp_date = NULL ;
     
        SET @d_zip = 0 ;

        SET @d_phone_err = '' ;
     
        SET @d_phone1 = 0 ;
    
        SET @d_ext1 = 0 ;
     
        SET @d_phone2 = 0 ;
  
        SET @d_ext2 = 0 ;
   
        SET @d_fax = 0 ;
    
        SET @n_process_count = 0 ;
  
        SET @n_error_count = 0 ;
       
        SET @n_succ_count = 0 ;

	
      
        BEGIN TRY
            
			SELECT @t_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @fc_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_type' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_name' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_stat_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_stat_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_state' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_license = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_license' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_lrenew_dt = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_lrenew_dt' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_tax_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_tax_id' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_tin = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_tin' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_area = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_area' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_rep = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_rep' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_source = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_source' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_phone_elig = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_phone_elig' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fax_elig = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fax_elig' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_print_dir = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_print_dir' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_mst_con_dt = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_mst_con_dt' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_emergency_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_emergency_phone' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_em_phone_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_em_phone_ext' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_emg_contact_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_emg_contact_type' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_legal_entity = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_legal_entity' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_tax_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_tax_name' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_pnrx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_pnrx' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_no2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_no2' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_hndacs = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_hndacs' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_capacity = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_capacity' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_warn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_warn' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_no_new = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_no_new' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_max_enrl = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_max_enrl' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_opr_tory = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_opr_tory' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_barrier_c = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_barrier_c' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fc_cur_enrl = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fc_cur_enrl' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_next_cap_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_next_cap_date' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_net_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_net_id' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_contract_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_contract_type' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_net_fc_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_net_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_ovr_ride = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ovr_ride' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_net_fc_exp_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_net_fc_exp_date' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_addr_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_addr_type' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_addr1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_addr1' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_addr2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_addr2' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_zipcode = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipcode' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_county = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_county' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_country = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_country' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_mail = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_mail' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_con_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_con_type' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_con_lname = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_con_lname' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_con_fname = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_con_fname' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_title = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_title' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_phone1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_phone1' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_ext1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ext1' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_phone2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_phone2' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_ext2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ext2' and  BatchId = @a_batch_id AND Module_Id = 6
			SELECT @t_fax = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fax' and  BatchId = @a_batch_id AND Module_Id = 6


            SET @s_error = 'N';
            SET @a_error_no = 0;
            SET @as_fc_stat_eff = NULL ;
            
            SET @as_fc_net_eff = NULL ;
            
            SET @as_fc_net_exp = NULL ;
            
            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @a_batch_id, @fcnet_proc_name
            SET @i_sp_id = @SWV_dl_get_sp_id ;
            
			

            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
			BEGIN
			set @i_error_no = 0
			RAISERROR('Invalid SP Name',16,1);
			RETURN
			END
   
           
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@fcnet_sir_def_name) ;
            
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
			BEGIN
			set @i_error_no = 0
            RAISERROR('Invalid SIR TABLE Definition',16,1);
			RETURN
			END
   
            
            IF ( @fc_alt_id IS NULL
                 
               )
                OR LEN(@fc_alt_id) = 0
			BEGIN
			set @i_error_no = 10
               RAISERROR('Facility Alt ID is missing',16,1);
			RETURN
			END
            ELSE
                BEGIN
               IF EXISTS ( SELECT  *
                                FROM    dbo.dls_fac_net (NOLOCK)
                                WHERE   dls_batch_id = @a_batch_id
                                        AND alt_id = @fc_alt_id
                                        AND dls_source = 'F'
                                        AND dls_sir_id <> @t_sir_id )
					BEGIN
					set @i_error_no = 11
                        RAISERROR('Duplicate Facility Alt ID found in SIR file',16,1);
					RETURN
					END
      
                    SET @i_fc_id = NULL ;
                    
                    SET @a_error_no = 12;
                    SELECT  @i_fc_id = fc_id
              FROM    dbo.facility (NOLOCK)
                    WHERE   alt_id = @fc_alt_id;
                    
                   
                END;
   
            
            IF ( @t_fc_type IS NULL
			
               )
                OR LEN(@t_fc_type) = 0
			BEGIN
			set @i_error_no = 20
			                RAISERROR('Facility Type is missing',16,1);
			RETURN
			END
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'FC'
                                        AND tab_name = 'facility'
                                        AND code = @t_fc_type )
BEGIN
set @i_error_no = 21
                    RAISERROR('Invalid Facility Type',16,1);
RETURN
END
      
   
            
            IF ( @t_fc_name IS NULL
                
               )
                OR LEN(@t_fc_name) = 0
BEGIN
set @i_error_no = 30
                RAISERROR('Facility Name is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    
                    IF @i_fc_id IS NOT NULL
                        AND NOT EXISTS ( SELECT *
                                         FROM   dbo.facility (NOLOCK)
                                         WHERE  fc_id = @i_fc_id
                                                AND fc_name = @t_fc_name )
				BEGIN
				set @i_error_no = 31
                        RAISERROR('Facility Name from SIR is not the same as in DataDental',0,1);
						EXECUTE  dbo.usp_dl_log_error @a_batch_id,@i_sp_id,@i_sir_def_id,@t_sir_id, @i_error_no;
					
					END
                END;
   
          
            IF ( @t_fc_stat_eff_date IS NULL
                 
               )
                OR LEN(@t_fc_stat_eff_date) = 0
                BEGIN
				set @i_error_no = 40
                    RAISERROR('Facility Status Effective Date is missing',16,1);
                   
                    SET @as_fc_stat_eff = @d_def_eff_date;
                    RETURN
                END;
            ELSE
                BEGIN
                    SET @a_error_no = 41;
                    
                    SET @d_fc_stat_eff_date = CAST(@t_fc_stat_eff_date AS DATE) ;
                    
                    IF DATEPART(DAY,@d_fc_stat_eff_date) <> 1
BEGIN
set @i_error_no = 42
                        RAISERROR('Facility Status Effective Date is not first of the month',16,            1);
RETURN
END
      
                    
                    SET @as_fc_stat_eff = @d_fc_stat_eff_date;
                    
                END;
   
            
            IF ( @t_fc_state IS NULL
                 OR @t_fc_state = ''
               )
                OR LEN(@t_fc_state) = 0
BEGIN
set @i_error_no = 50
                RAISERROR('Facility State Code is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    
                    IF @t_fc_state = 'UK'
BEGIN
set @i_error_no = 51
                        RAISERROR('Facility State Code cannot be UK (unknown)',16,1);
RETURN
END
                    ELSE
                        IF NOT EXISTS ( SELECT  *
                                        FROM    dbo.state (NOLOCK)
                                        WHERE   code = @t_fc_state )
BEGIN
set @i_error_no = 52
                            RAISERROR('Invalid Facility State Code',16,1);
RETURN
END
                END;
   
            
            IF ( @t_fc_lrenew_dt IS NOT NULL
                 AND @t_fc_lrenew_dt <> ''
               )
                OR LEN(@t_fc_lrenew_dt) > 0
                BEGIN
                    SET @a_error_no = 60;
                    
                    SET @d_fc_lrenew_dt = @t_fc_lrenew_dt ;
                    
                    IF DATEPART(DAY,@d_fc_lrenew_dt) <> 1
BEGIN
set @i_error_no = 61
                        RAISERROR('Facility License Renewal Date is not first of the month',16,            1);
RETURN
END
            END;
   
          
            IF ( @fc_vendor_id IS NOT NULL
                 AND @fc_vendor_id <> ''
               )
                OR LEN(@fc_vendor_id) > 0
                IF NOT EXISTS ( SELECT  *
        FROM    dbo.vendor (NOLOCK)
                                WHERE   v_type = 'FC'
                                        AND alt_id = @fc_vendor_id )
BEGIN
set @i_error_no = 65
                    RAISERROR('Given vendor alt_id does not exist in Vendor table',16,1);
RETURN
END
      
   
            
            IF ( @t_fc_tax_id IS NULL
                 OR @t_fc_tax_id = ''
               )
                OR LEN(@t_fc_tax_id) = 0
BEGIN
set @i_error_no = 70
                RAISERROR('Facility Tax ID is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                   
                    IF LEN(@t_fc_tax_id) <> 9
BEGIN
set @i_error_no = 71
                        RAISERROR('Facility Tax ID must be 9 digit long',16,1);
RETURN
END
                END;
   
            
            IF ( @t_tin IS NULL
                 
               )
                OR LEN(@t_tin) = 0
BEGIN
set @i_error_no = 75
                RAISERROR('Facility TIN is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    
                    IF @t_tin NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 76
                        RAISERROR('Invalid Facility TIN',16,1);
RETURN
END
    END;
   
           
            IF ( @t_fc_area IS NOT NULL
                 AND @t_fc_area <> ''
               )
                OR LEN(@t_fc_area) > 0
                BEGIN
                    SET @a_error_no = 80;
                    
                    SET @d_fc_area = @t_fc_area ;
                    
                    IF NOT EXISTS ( SELECT  *
                                 FROM    dbo.area_desc (NOLOCK)
                             WHERE   area_id = @d_fc_area )
BEGIN
set @i_error_no = 81
                        RAISERROR('Invalid Facility Area Code value',16,1);
RETURN
END
                END;
   
            
            IF ( @t_fc_rep IS NOT NULL
                 AND @t_fc_rep <> ''
               )
                OR LEN(@t_fc_rep) > 0
                BEGIN
                    SET @a_error_no = 85;
                    
                    SET @d_fc_rep = @t_fc_rep ;
                    
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.representative (NOLOCK)
                                    WHERE   subsys_code = 'FC'
                                            AND rep_id = @d_fc_rep )
BEGIN
set @i_error_no = 86
                        RAISERROR('Invalid Facility Representative value',16,1);
RETURN
END
                END;
   
            
            IF ( @t_fc_source IS NOT NULL
                 AND @t_fc_source <> ''
               )
                OR LEN(@t_fc_source) > 0
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'FC'
                                        AND tab_name = 'source'
                                        AND code = @t_fc_source )
BEGIN
set @i_error_no = 88
                    RAISERROR('Invalid Marketing Information Source',16,1);
RETURN
END
      
   
            
            IF ( @t_phone_elig IS NOT NULL
                 AND @t_phone_elig <> ''
               )
                OR LEN(@t_phone_elig) > 0
                BEGIN
                    
                    IF @t_phone_elig NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 90
                        RAISERROR('Invalid Phone Eligibility Flag',16,1);
RETURN
END
                END;
   
            
            IF ( @t_fax_elig IS NOT NULL
                 AND @t_fax_elig <> ''
               )
                OR LEN(@t_fax_elig) > 0
                BEGIN
                   
                    IF @t_fax_elig NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 91
                        RAISERROR('Invalid Fax Eligibility Flag',16,1);
RETURN
END
                END;
   
            
            IF ( @t_print_dir IS NOT NULL
                 AND @t_print_dir <> ''
               )
                OR LEN(@t_print_dir) > 0
                BEGIN
                   
                  IF @t_print_dir NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 92
                        RAISERROR('Invalid Print Facility Directory Flag',16,1);
RETURN
END
                END;
   
            
            IF ( @t_fc_mst_con_dt IS NOT NULL
     AND @t_fc_mst_con_dt <> ''
               )
                OR LEN(@t_fc_mst_con_dt) > 0
                BEGIN
                    SET @a_error_no = 93;
                   
                    SET @d_fc_mst_con_dt = @t_fc_mst_con_dt ;
                    
                    IF DATEPART(DAY,@d_fc_mst_con_dt) <> 1
BEGIN
set @i_error_no = 94
                        RAISERROR('Date Master Contract Signed is not first of the month',16,1);
RETURN
END
                END;
   
           
            IF ( @t_emg_contact_type IS NOT NULL
                 AND @t_emg_contact_type <> ''
               )
                OR LEN(@t_emg_contact_type) > 0
                BEGIN
       IF NOT EXISTS ( SELECT  *
                   FROM    dbo.typ_table (NOLOCK)
                                    WHERE   subsys_code = 'FC'
                                            AND tab_name = 'contact'
           AND code = @t_emg_contact_type )
BEGIN
set @i_error_no = 95
                        RAISERROR('Invalid Emergency Contact Type',16,1);
RETURN
END
      
                    
                    IF ( @t_emergency_phone IS NOT NULL
                         AND @t_emergency_phone <> ''
                       )
                        AND @t_emg_contact_type <> 'OF'
BEGIN
set @i_error_no = 96
                        RAISERROR('Emergency Contact Type must by Office if Emergency Phone is provided',16,1);
RETURN
END
                END;
   
           
            IF ( @t_legal_entity IS NOT NULL
                 AND @t_legal_entity <> ''
               )
                OR LEN(@t_legal_entity) > 0
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'FC'
                                        AND tab_name = 'fc_legal_entity'
                                        AND code = @t_legal_entity )
BEGIN
set @i_error_no = 97
                    RAISERROR('Invalid Legal Entity Type',16,1);
RETURN
END
      
   
           
            IF ( @t_fc_tax_name IS NULL
                 OR @t_fc_tax_name = ''
               )
                OR LEN(@t_fc_tax_name) = 0
BEGIN
set @i_error_no = 101
                RAISERROR('Facility Federal Tax Name is missing',16,1);
RETURN
END
   
            
            IF ( @t_pnrx IS NOT NULL
                 AND @t_pnrx <> ''
               )
                OR LEN(@t_pnrx) > 0
                BEGIN
                   
                    IF @t_pnrx NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 98
                        RAISERROR('Invalid Panorex Used Flag',16,1);
RETURN
END
                END;
   
            
            IF ( @t_no2 IS NOT NULL
                 AND @t_no2 <> ''
               )
                OR LEN(@t_no2) > 0
                BEGIN
                    
                    IF @t_no2 NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 99
                        RAISERROR('Invalid Nitrous Oxide Used Flag',16,1);
RETURN
END
                END;
   
            
            IF ( @t_hndacs IS NOT NULL
   AND @t_hndacs <> ''
               )
                OR LEN(@t_hndacs) > 0
                BEGIN
                   
                    IF @t_hndacs NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 100
                        RAISERROR('Invalid Handicap Access Flag',16,1);
RETURN
END
                END;
  
            
            IF ( @t_fc_capacity IS NOT NULL
                 AND @t_fc_capacity <> ''
               )
                OR LEN(@t_fc_capacity) > 0
                BEGIN
                    SET @a_error_no = 102;
                    
                    SET @d_fc_capacity = @t_fc_capacity ;
                    
                END;
 
            
            IF ( @t_fc_warn IS NOT NULL
AND @t_fc_warn <> ''
               )
                OR LEN(@t_fc_warn) > 0
                BEGIN
SET @a_error_no = 103;
                    
                    SET @d_fc_warn = @t_fc_warn ;
                    
                END;
   
            
            IF ( @t_fc_no_new IS NOT NULL
                 AND @t_fc_no_new <> ''
               )
                OR LEN(@t_fc_no_new) > 0
                BEGIN
                    SET @a_error_no = 104;
                    
                    SET @d_fc_no_new = @t_fc_no_new ;
                    
                END;
   
            
            IF ( @t_fc_max_enrl IS NOT NULL
                 AND @t_fc_max_enrl <> ''
               )
       OR LEN(@t_fc_max_enrl) > 0
                BEGIN
                  SET @a_error_no = 105;
                    
                    SET @d_fc_max_enrl = @t_fc_max_enrl ;
                    
                END;
   
            
            IF ( @t_fc_opr_tory IS NOT NULL
                 AND @t_fc_opr_tory <> ''
               )
                OR LEN(@t_fc_opr_tory) > 0
                BEGIN
                    SET @a_error_no = 106;
                    
                    SET @d_fc_opr_tory = @t_fc_opr_tory ;
                    
                END;
 
            
            IF ( @t_barrier_c IS NOT NULL
                 AND @t_barrier_c <> ''
               )
                OR LEN(@t_barrier_c) > 0
                BEGIN
                    SET @a_error_no = 107;
                    
                    SET @d_barrier_c = @t_barrier_c ;
                    
                END;
   
            
            IF ( @t_fc_cur_enrl IS NOT NULL
                 AND @t_fc_cur_enrl <> ''
               )
                OR LEN(@t_fc_cur_enrl) > 0
                BEGIN
                    SET @a_error_no = 108;
                    
                    SET @d_fc_cur_enrl = @t_fc_cur_enrl ;
                    
                END;
   
            
            IF ( @fc_parent_id IS NOT NULL
                 AND @fc_parent_id <> ''
               )
                OR LEN(@fc_parent_id) > 0
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.facility (NOLOCK)
                                WHERE   alt_id = @fc_parent_id )
                    AND NOT EXISTS ( SELECT *
                                     FROM   dbo.dls_fac_net (NOLOCK)
                                     WHERE  dls_batch_id = @a_batch_id
                                            AND alt_id = @fc_parent_id )
BEGIN
set @i_error_no = 118
                    RAISERROR('Cannot find matching facility by Facility Parent ID',16,1);
RETURN
END
      
   
            
            IF ( @t_next_cap_date IS NULL
                 OR @t_next_cap_date = ''
               )
                OR LEN(@t_next_cap_date) = 0
BEGIN
set @i_error_no = 109
                RAISERROR('Facility Next Cap Effective Date is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    SET @a_error_no = 110;
                    
                    SET @d_next_cap_date = @t_next_cap_date ;
                    
  IF DATEPART(DAY,@d_next_cap_date) <> 1
BEGIN
set @i_error_no =111
                        RAISERROR('Facility Next Cap Effective Date is not first of the month',            16,1);
RETURN
END
                END;
   
            
            IF ( @t_net_fc_eff_date IS NOT NULL
                 AND @t_net_fc_eff_date <> ''
               )
                OR LEN(@t_net_fc_eff_date) > 0
                BEGIN
                    SET @a_error_no = 125;
                   
                    SET @d_net_fc_eff_date = @t_net_fc_eff_date ;
                    
                    IF DATEPART(DAY,@d_net_fc_eff_date) <> 1
BEGIN
set @i_error_no = 126
                        RAISERROR('Facility Network Effective Date from the tape is not first of the month',16,1);
RETURN
END
      
         
            IF @d_net_fc_eff_date < @d_fc_stat_eff_date
BEGIN
set @i_error_no = 127
                        RAISERROR('Facility Network Effective Date is before Facility Status Effective Date',16,1);
RETURN
END
      
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.network (NOLOCK)
                                    WHERE   eff_date <= @d_net_fc_eff_date
                                           AND ( exp_date IS NULL
                                                  OR @d_net_fc_eff_date < exp_date
                                                ) )
BEGIN
set @i_error_no = 128
                        RAISERROR('Network is not active at incoming Facility Network Effective Date',            16,1);
RETURN
END
      
                    
                    SET @as_fc_net_eff =@d_net_fc_eff_date ;
                    
                END;
  ELSE    -- t_net_fc_eff_date is missing from the tape
                BEGIN
BEGIN
set @i_error_no = 124
                    RAISERROR('Network Facility Effective Date is missing.  Will use default date',0,1);
					EXECUTE  dbo.usp_dl_log_error @a_batch_id,@i_sp_id,@i_sir_def_id,@t_sir_id, @i_error_no;

END
                    
                    SET @as_fc_net_eff = @d_def_eff_date;
       
                END;
   
            
            IF ( @t_net_id IS NULL
                 OR @t_net_id = ''
               )
                OR LEN(@t_net_id) = 0
BEGIN
set @i_error_no = 112
                RAISERROR('Network ID from the tape is missing',16,1);
RETURN
END
            ELSE 
-- $$KS20050128 - do not force specific network
                BEGIN
                    SELECT  @d_net_id = net_id
                    FROM    dbo.network (NOLOCK)
                    WHERE   alt_id = @t_net_id; 
                    
                    
--      let a_error_no = 113;
--      let d_net_id = t_net_id; 
--      IF d_net_id <> n_net_id THEN
--        RAISE EXCEPTION -746, 114, 
-- "Network ID from the tape is different from the DL GUI setting";
--      END IF
--      IF not exists (select * from network where net_id = d_net_id) THEN
                    
                    IF @d_net_id IS NULL
BEGIN
set @i_error_no = 115
                        RAISERROR('Network ID from the tape not existed in DataDental',16,1);
RETURN
END
      
                    IF EXISTS ( SELECT  *
                                FROM    dbo.net_facility (NOLOCK)
                                WHERE   net_id <> @d_net_id
                                        AND fc_id = @i_fc_id
                                        AND con_type = 'PPO'
                                        AND ( ( exp_date IS NULL
                                                AND eff_date <= @as_fc_net_eff
                                              )
                                              OR ( exp_date IS NOT NULL
                                                   AND @as_fc_net_eff < exp_date
                                                 )
                                            ) )
			BEGIN
			set @i_error_no = 116
                        RAISERROR('Facility cannot be in different PPO Network at the given time', 0,1);

				EXECUTE  dbo.usp_dl_log_error @a_batch_id,@i_sp_id,@i_sir_def_id,@t_sir_id, @i_error_no;
			END
      
                    IF EXISTS ( SELECT  *
         FROM    dbo.net_facility (NOLOCK)
                                WHERE   net_id = @d_net_id
                                        AND fc_id = @i_fc_id
                                        AND con_type = 'PPO'
                                        AND @as_fc_net_eff < eff_date )
BEGIN
set @i_error_no = 117
                        RAISERROR('Tape Facility Network Effective Date is before DataDental record',       16,1);
RETURN
END
                END;
   
            
            IF ( @t_contract_type IS NULL
                 OR @t_contract_type = ''
               )
                OR LEN(@t_contract_type) = 0
BEGIN
set @i_error_no = 120
                RAISERROR('Network Facility Contract Type is missing',16,1);
RETURN
END
            ELSE
                BEGIN
      
                    IF @t_contract_type <> 'PPO'
BEGIN
set @i_error_no = 121
                        RAISERROR('Facility Contract Type must be PPO',16,1);
RETURN
END
END;
   
            
    IF ( @t_ovr_ride IS NOT NULL
                 AND @t_ovr_ride <> ''
               )
                OR LEN(@t_ovr_ride) > 0
                BEGIN
                    
                    IF @t_ovr_ride NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 130
                        RAISERROR('Invalid Facility Network Override Switch value',16,1);
RETURN
END
                END;
   
            
            IF ( @t_net_fc_exp_date IS NOT NULL
                 AND @t_net_fc_exp_date <> ''
               )
                OR LEN(@t_net_fc_exp_date) > 0
                BEGIN
                    SET @a_error_no = 135;
                    
                    SET @d_net_fc_exp_date = CAST(@t_net_fc_exp_date AS DATE);
                    
                    IF DATEPART(DAY,@d_net_fc_exp_date) <> 1
BEGIN
set @i_error_no = 136
                        RAISERROR('Facility Network Expiration Date from the tape is not first of the month',16,1);
RETURN
END
      
                    
                    IF  @d_net_fc_exp_date < @d_net_fc_eff_date
BEGIN
set @i_error_no = 137
                        RAISERROR('Facility Network Expiration Date is before Facility Network Effective Date',16,1);
RETURN
END
      
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.network (NOLOCK)
                                    WHERE   eff_date <= @d_net_fc_exp_date
                                            AND ( exp_date IS NULL
                                                  OR @d_net_fc_exp_date < exp_date
                                                ) )
BEGIN
set @i_error_no = 138
                        RAISERROR('Network is not active at incoming Facility Network Expiration Date',            16,1);
RETURN
END
      
                   
                    IF @n_has_term_date = 'Y'
                        BEGIN
                            
                            SET @as_fc_net_exp = @d_net_fc_exp_date ;
                            
 END;
                END;
   
          
            IF @n_has_term_date = 'N'
                OR @as_fc_net_exp IS NULL
                BEGIN
                    
                    SET @as_fc_net_exp = @d_def_exp_date ;
                    
                END;
        
            
            IF ( @t_addr_type IS NULL
                 OR @t_addr_type = ''
               )
                OR LEN(@t_addr_type) = 0
BEGIN
set @i_error_no = 140
                RAISERROR('Facility Address Type is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                
                    IF @t_addr_type <> 'L'
BEGIN
set @i_error_no = 141
                        RAISERROR('Facility Address Type must be for Location',16,1);
RETURN
END
                END;
   
            
    IF ( @t_addr1 IS NULL
                 OR @t_addr1 = ''
               )
                OR LEN(@t_addr1) = 0
BEGIN
set @i_error_no = 145
                RAISERROR('Facility Address Line 1 is missing',16,1);
RETURN
END
   
            
            IF ( @t_zipcode IS NULL
                 OR @t_zipcode = ''
               )
                OR LEN(@t_zipcode) = 0
BEGIN
set @i_error_no = 150
                RAISERROR('Facility Address Zip Code is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    
                    IF NOT ( LEN(@t_zipcode) = 5
                             OR LEN(@t_zipcode) = 9
                           )
  BEGIN
  set @i_error_no = 151
                        RAISERROR('Facility Address Zip Code must be 5 or 9 digits long',16,1);
RETURN
END
      
                SET @a_error_no = 152;
                    
                 SET @d_zip = @t_zipcode ;
                    
                    SET @d_zip = SUBSTRING(@t_zipcode, 1, 5) ;
                   
      --CHANGE for handling multiple cities per zip
                    SET @i_zip_id = 0;

/*
                   SET @SWV_cursor_var1 = CURSOR  FOR SELECT zip_id
           
         FROM dbo.usa_zip (NOLOCK)
         WHERE zip_code = @d_zip
         ORDER BY 1;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_zip_id;
                    WHILE @@FETCH_STATUS = 0
*/
                    DECLARE @SWV_cursor_var1 TABLE
                        (
                          id INT IDENTITY ,
                          zip_id INT
                        );
                    INSERT  INTO @SWV_cursor_var1
                            ( zip_id
                            )
                   SELECT  zip_id
                            FROM    dbo.usa_zip (NOLOCK)
                            WHERE   zip_code = @d_zip
                            ORDER BY 1;

                    DECLARE @cur1_cnt INT ,
                        @cur1_i INT;
                    SET @cur1_i = 1;
    --Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;
                    WHILE ( @cur1_i <= @cur1_cnt )
     BEGIN
                            SELECT  @i_zip_id = zip_id
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur1_i;
                            GOTO SWL_Label2;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_zip_id;
                            SET @cur1_i = @cur1_i + 1;
                        END;
                    SWL_Label2:
                    --CLOSE @SWV_cursor_var1;
      --IF not exists (select * from usa_zip where zip_code = 
      --t_zipcode[1,5]) THEN
                    IF @i_zip_id IS NULL
BEGIN
set @i_error_no = 153
                        RAISERROR('Facility Address Zip Code is not in the USA_ZIP table',16,1);
RETURN
END
                END;
   
            
            IF ( @t_mail IS NOT NULL
                 AND @t_mail <> ''
               )
                OR LEN(@t_mail) > 0
                BEGIN
                    
                    IF @t_mail NOT IN ( 'Y', 'N' )
BEGIN
set @i_error_no = 155
                        RAISERROR('Invalid Facility Address Undeliverable Mail Indicator value',            16,1);
RETURN
END
                END;
   
            
            IF ( @t_con_type IS NULL
                 OR @t_con_type = ''
               )
                OR LEN(@t_con_type) = 0
BEGIN
set @i_error_no = 160
                RAISERROR('Facility Contact Type is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    
                    IF @t_con_type <> 'OF'
BEGIN
set @i_error_no = 161
                        RAISERROR('Facility Contact Type must be for Office',16,1);
RETURN
END
        END;
   
            
            IF ( @t_phone1 IS NULL
                 OR @t_phone1 = ''
              )
                OR LEN(@t_phone1) = 0
BEGIN
set @i_error_no = 170
                RAISERROR('Facility Contact Phone 1 is missing',16,1);
RETURN
END
            ELSE
                BEGIN
                    
                    IF LEN(@t_phone1) <> 10
BEGIN
set @i_error_no = 171
                        RAISERROR('Facility Contact Phone 1 must be 10 digits long',16,1);
RETURN
END
      
                    SET @d_phone_err = 'N' ;
                    
                    SET @a_error_no = 172;
                    
                    SET @d_phone1 = SUBSTRING(@t_phone1, 1, 3) ;
                    
                    IF @d_phone1 < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                    SET @a_error_no = 172;
                    
                    SET @d_phone1 = SUBSTRING(@t_phone1, 4, 3) ;
                 
                    IF @d_phone1 < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                           
                        END;
      
                 SET @a_error_no = 172;
             
                    SET @d_phone1 = SUBSTRING(@t_phone1, 7, 4) ;
            
                    IF @d_phone1 < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                 
                    IF @d_phone_err = 'Y'
BEGIN
set @i_error_no = 172
                        RAISERROR('Error in Facility Contact Phone 1',16,1);
RETURN
END
                END;
   
            
     IF ( @t_ext1 IS NOT NULL
                 AND @t_ext1 <> ''
               )
                OR LEN(@t_ext1) > 0
                BEGIN
                    SET @a_error_no = 175;
                    
                    SET @d_ext1 = SUBSTRING(@t_ext1, 1, 5) ;
                   
                    IF @d_ext1 < 0
BEGIN
set @i_error_no = 175
                        RAISERROR('Error in Facility Contact Phone Extension 1',16,1);
RETURN
END
      
 
                    IF LEN(@t_ext1) > 5
BEGIN
set @i_error_no = 176
                        RAISERROR('Facility Contact Phone Extension 1 is more than 5 digits long',            16,1);
RETURN
END
                END;
   
            
            IF ( @t_phone2 IS NOT NULL
                 AND @t_phone2 <> ''
               )
                OR LEN(@t_phone2) > 0
                BEGIN
                   
                    IF LEN(@t_phone2) <> 10
BEGIN
set @i_error_no = 181
                        RAISERROR('Facility Contact Phone 2 must be 10 digits long',16,1);
RETURN
END
      
                    SET @d_phone_err = 'N' ;
                    
                    SET @a_error_no = 182;
                    
                    SET @d_phone2 = SUBSTRING(@t_phone2, 1, 3) ;
                   
                    IF @d_phone2 < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                    SET @a_error_no = 182;
                    
                    SET @d_phone2 = SUBSTRING(@t_phone2, 4, 3) ;
                    
                    IF @d_phone2 < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                    SET @a_error_no = 182;
                    
                    SET @d_phone2 = SUBSTRING(@t_phone2, 7, 4) ;
                   
                    IF @d_phone2 < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                    
      END;
      
          
IF @d_phone_err = 'Y'
BEGIN
set @i_error_no = 182
                        RAISERROR('Error in Facility Contact Phone 2',16,1);
RETURN
END
                END;
   
            
            IF ( @t_ext2 IS NOT NULL
                 AND @t_ext2 <> ''
               )
                OR LEN(@t_ext2) > 0
                BEGIN
                    SET @a_error_no = 185;
                    
                    SET @d_ext2 = SUBSTRING(@t_ext2, 1, 5) ;
                    
                    IF @d_ext2 < 0
BEGIN
set @i_error_no = 185
                        RAISERROR('Error in Facility Contact Phone Extension 2',16,1);
RETURN
END
      
                    
                    IF LEN(@t_ext2) > 5
BEGIN
set @i_error_no = 186
                        RAISERROR('Facility Contact Phone Extension 2 is more than 5 digits long',            16,1);
RETURN
END
                END;
   
            
            IF ( @t_fax IS NOT NULL
                 AND @t_fax <> ''
               )
                OR LEN(@t_fax) > 0
                BEGIN
                                        IF LEN(@t_fax) <> 10
BEGIN
set @i_error_no = 191
                        RAISERROR('Facility Contact Fax must be 10 digits long',16,1);
RETURN
END
      
                    SET @d_phone_err = 'N' ;
                   
                    SET @a_error_no = 192;
      
                    SET @d_fax = SUBSTRING(@t_fax, 1, 3) ;
                   
                    IF @d_fax < 0
                    BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                    SET @a_error_no = 192;
                   
                    SET @d_fax = SUBSTRING(@t_fax, 4, 3) ;
                   
              IF @d_fax < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                    SET @a_error_no = 192;
                    
        SET @d_fax = SUBSTRING(@t_fax, 7, 4) ;
                   
                    IF @d_fax < 0
                        BEGIN
                            SET @d_phone_err = 'Y' ;
                            
                        END;
      
                    
                    IF @d_phone_err = 'Y'
					BEGIN
					set @i_error_no = 192
                        RAISERROR('Error in Facility Contact Fax',16,1);
					RETURN
					END
                END;
   


--trace off;

            IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = NULL;
                    
                    SET @SWP_Ret_Value2 = @i_fc_id;
                    
                    SET @SWP_Ret_Value3 = @d_net_id;
                    
                    SET @SWP_Ret_Value4 = @as_fc_stat_eff;
                  
                    SET @SWP_Ret_Value5 = @as_fc_net_eff;
                    
                    SET @SWP_Ret_Value6 = @as_fc_net_exp;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = NULL;
                    
                    SET @SWP_Ret_Value2 = @i_fc_id;
                    
                    SET @SWP_Ret_Value3 = @d_net_id;
                    
                    SET @SWP_Ret_Value4 = @as_fc_stat_eff;
                    
                    SET @SWP_Ret_Value5 = @as_fc_net_eff;
                    
                    SET @SWP_Ret_Value6 = @as_fc_net_exp;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH

		IF ERROR_NUMBER() = 50000
		BEGIN

		EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
												@i_sp_id,
                                   @i_sir_def_id,
              @t_sir_id, @i_error_no;

		END
		IF @i_fatal <> 1 
		     SET @s_error = 'Y';

	   IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = 0;
                    SET @SWP_Ret_Value1 = NULL;
                    
                    SET @SWP_Ret_Value2 = @i_fc_id;
                    
                    SET @SWP_Ret_Value3 = @d_net_id;
                    
                    SET @SWP_Ret_Value4 = @as_fc_stat_eff;
                  
                    SET @SWP_Ret_Value5 = @as_fc_net_eff;
                    
                    SET @SWP_Ret_Value6 = @as_fc_net_exp;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = NULL;
                    
                    SET @SWP_Ret_Value2 = @i_fc_id;
                    
                    SET @SWP_Ret_Value3 = @d_net_id;
                    
                    SET @SWP_Ret_Value4 = @as_fc_stat_eff;
                    
                    SET @SWP_Ret_Value5 = @as_fc_net_eff;
                    
                    SET @SWP_Ret_Value6 = @as_fc_net_exp;
                    RETURN;
                END;

            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            --SET @SWP_Ret_Value = 0;
            --SET @SWP_Ret_Value1 = @s_error_descr;
            
            --SET @SWP_Ret_Value2 = @i_fc_id;
            
            --SET @SWP_Ret_Value3 = @d_net_id;
            
            --SET @SWP_Ret_Value4 = @as_fc_stat_eff;
            
            --SET @SWP_Ret_Value5 = @as_fc_net_eff;
            
            --SET @SWP_Ret_Value6 = @as_fc_net_exp;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


--set debug file to "/tmp/dlp_valid_fcnet.trc";
--trace on;
    END;