﻿CREATE PROCEDURE [dbo].[dlp_ut_get_clm_no]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 FLOAT = NULL OUTPUT
    


------------------------------------------------------------------------------
--
--            Procedure:   dlp_ut_get_clm_no
--
--            Created:     02/01/1999 
--           Author:      Kim Nguyen, Gene Albers
--
-- Purpose:  This SP retrieves a unique claim no to be used in the Data Dental
--           table claim_h when processing Electronic Claims.  This proc 
--           the update phase of the Utilization Extension, a DataLoad Product
--           of STC
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @claim_date DATE;
        DECLARE @jan1_date DATE;
        DECLARE @cur_counter INT;
        DECLARE @num_places SMALLINT;
        DECLARE @ClmStr VARCHAR(16);
        DECLARE @dc_claim_no FLOAT;
        DECLARE @ctr_len INT;
        DECLARE @ijan1 INT;
        DECLARE @date_str CHAR(10);
        DECLARE @jan1_int INT;
        DECLARE @today_int INT;
        DECLARE @jul_days INT;
        DECLARE @yearstr CHAR(4);
        DECLARE @jul_str CHAR(3);
        DECLARE @num_zeroes INT;
        DECLARE @strctr VARCHAR(16);
        DECLARE @zero_str VARCHAR(16);
        DECLARE @i INT;

-----exception handling--------------------------------------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            SET @date_str = CONVERT(CHAR, GETDATE(),110);;
			SET @yearstr = SUBSTRING(@date_str, 7, 4);
			SET @date_str = STUFF(@date_str, 1, 2, '01');
			SET @date_str = STUFF(@date_str, 4, 2, '01');
			SET @jan1_date = CAST(@date_str AS DATE);
            SET @jan1_int = DATEDIFF(DAY, '1899-12-31', @jan1_date);
            SET @today_int = DATEDIFF(DAY, '1899-12-31',
                                      CONVERT(DATE, GETDATE()));
            SET @jul_days = ( @today_int - @jan1_int ) + 1;

--ensures length is 3 chars
            IF @jul_days >= 100
                SET @jul_str = @jul_days;
            ELSE
                IF @jul_days >= 10
                    SET @jul_str = CONCAT('0', @jul_days);
                ELSE
                    SET @jul_str = CONCAT('00', @jul_days);

            SET @strctr = NULL;
            SET @cur_counter = 0;
            SET @num_places = 0;
            SET @num_zeroes = 0;
            SET @ctr_len = 0;
            SET @zero_str = '';
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.claim_num_gen (NOLOCK)
                            WHERE   descr = 'CurrentClaim' )
                RAISERROR('Error',16,1);


-- sample format of claim no is:  19990450000054

            SELECT  @claim_date = [date] ,
                    @cur_counter = counter ,
                    @num_places = counter_size
            FROM    dbo.claim_num_gen  (NOLOCK)
            WHERE   descr = 'CurrentClaim';
           
            IF @claim_date IS NULL
                BEGIN
                    SET @cur_counter = 1;
                    UPDATE  dbo.claim_num_gen
                    SET     [date] = CONVERT(DATE, GETDATE()) ,
                            counter = @cur_counter
                    WHERE   descr = 'CurrentClaim';
                END;
            ELSE
                IF @claim_date <> CONVERT(DATE, GETDATE())
                    BEGIN
                        SET @cur_counter = 1;
                        UPDATE  dbo.claim_num_gen
                        SET     [date] = CONVERT(DATE, GETDATE()) ,
                                counter = @cur_counter
                        WHERE   descr = 'CurrentClaim';
                    END;
                ELSE
                    BEGIN
           IF @cur_counter > 0
                            SET @cur_counter = @cur_counter + 1;
                        ELSE
                            SET @cur_counter = 1;
   
                        UPDATE  dbo.claim_num_gen
                        SET     counter = @cur_counter
                        WHERE   descr = 'CurrentClaim';
                    END;

            SET @strctr = @cur_counter;
            SET @ctr_len = LEN(@strctr);
            IF @num_places > 0
                SET @num_zeroes = @num_places - @ctr_len;
            ELSE
                BEGIN
                    UPDATE  dbo.claim_num_gen
                    SET     counter_size = 7
                    WHERE   descr = 'CurrentClaim';
                    SET @num_zeroes = 7 - @ctr_len;
                END;

            IF @num_zeroes > 0
                BEGIN
                    SET @zero_str = '0';
                    SET @i = 1;
                    WHILE @i <= @num_zeroes - 1
                        BEGIN
                            SET @zero_str = @zero_str + '0';  
                            SET @i = @i + 1;
                        END;
                END;

            SET @ClmStr = @yearstr + @jul_str + @zero_str + @strctr;
            SET @dc_claim_no = @ClmStr;
            SET @SWP_Ret_Value = NULL;
            SET @SWP_Ret_Value1 = @dc_claim_no;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;




-- Calc julian date
    END;