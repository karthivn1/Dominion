﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_GetDSIRFacNet]
	-- Add the parameters for the stored procedure here
	@dsirBatchId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT [dls_sir_id] 
                 ,[dls_batch_id]
				 ,LTRIM(RTRIM([alt_id])) AS [alt_id]
                 ,LTRIM(RTRIM([fc_type]))                AS [fc_type]
                 ,LTRIM(RTRIM([fc_name]))                AS [fc_name]
                 ,LTRIM(RTRIM([fc_stat_eff_date]))                AS [fc_stat_eff_date]
                 ,LTRIM(RTRIM([fc_state]))                AS [fc_state]
                 ,LTRIM(RTRIM([fc_license]))                AS [fc_license]
                 ,LTRIM(RTRIM([fc_lrenew_dt]))                AS [fc_lrenew_dt]
                 ,LTRIM(RTRIM([vendor_id]))                AS [vendor_id]
                 ,LTRIM(RTRIM([fc_tax_id]))                AS [fc_tax_id]
                 ,LTRIM(RTRIM([tin]))                AS [tin]
                 ,LTRIM(RTRIM([fc_area]))                AS [fc_area]
                 ,LTRIM(RTRIM([fc_rep]))                AS [fc_rep]
                 ,LTRIM(RTRIM([fc_source]))                AS [fc_source]
                 ,LTRIM(RTRIM([phone_elig]))                AS [phone_elig]
                 ,LTRIM(RTRIM([fax_elig]))                AS [fax_elig]
                 ,LTRIM(RTRIM([print_dir]))                AS [print_dir]
                 ,LTRIM(RTRIM([fc_mst_con_dt]))                AS [fc_mst_con_dt]
                 ,LTRIM(RTRIM([emergency_phone]))                AS [emergency_phone]
                 ,LTRIM(RTRIM([em_phone_ext]))                AS [em_phone_ext]
                 ,LTRIM(RTRIM([emg_contact_type]))                AS [emg_contact_type]
                 ,LTRIM(RTRIM([legal_entity]))                AS [legal_entity]
                 ,LTRIM(RTRIM([fc_tax_name]))                AS [fc_tax_name]
                 ,LTRIM(RTRIM([pnrx]))                AS [pnrx]
                 ,LTRIM(RTRIM([no2]))                AS [no2]
                 ,LTRIM(RTRIM([hndacs]))                AS [hndacs]
                 ,LTRIM(RTRIM([fc_capacity]))                AS [fc_capacity]
                 ,LTRIM(RTRIM([fc_warn]))                AS [fc_warn]
                 ,LTRIM(RTRIM([fc_no_new]))                AS [fc_no_new]
                 ,LTRIM(RTRIM([fc_max_enrl]))                AS [fc_max_enrl]
                 ,LTRIM(RTRIM([fc_opr_tory]))                AS [fc_opr_tory]
                 ,LTRIM(RTRIM([parent_id]))                AS [parent_id]
                 ,LTRIM(RTRIM([barrier_c]))                AS [barrier_c]
                 ,LTRIM(RTRIM([fc_cur_enrl]))                AS [fc_cur_enrl]
                 ,LTRIM(RTRIM([next_cap_date]))                AS [next_cap_date]
                 ,LTRIM(RTRIM([net_id]))                AS [net_id]
                 ,LTRIM(RTRIM([contract_type]))                AS [contract_type]
                 ,LTRIM(RTRIM([net_fc_eff_date]))                AS [net_fc_eff_date]
                 ,LTRIM(RTRIM([ovr_ride]))                AS [ovr_ride]
                 ,LTRIM(RTRIM([net_fc_exp_date]))                AS [net_fc_exp_date]
                 ,LTRIM(RTRIM([addr_type]))                AS [addr_type]
                 ,LTRIM(RTRIM([addr1]))                AS [addr1]
                 ,LTRIM(RTRIM([addr2]))                AS [addr2]
                 ,LTRIM(RTRIM([zip]))                AS [zip]
                 ,LTRIM(RTRIM([city]))                AS [city]
                 ,LTRIM(RTRIM([state]))                AS [state]
                 ,LTRIM(RTRIM([county]))                AS [county]
                 ,LTRIM(RTRIM([country]))                AS [country]
                 ,LTRIM(RTRIM([mail]))                AS [mail]
                 ,LTRIM(RTRIM([con_type]))                AS [con_type]
                 ,LTRIM(RTRIM([con_lname]))                AS [con_lname]
                 ,LTRIM(RTRIM([con_fname]))                AS [con_fname]
                 ,LTRIM(RTRIM([title]))                AS [title]
                 ,LTRIM(RTRIM([phone1]))                AS [phone1]
                 ,LTRIM(RTRIM([ext1]))                AS [ext1]
                 ,LTRIM(RTRIM([phone2]))                AS [phone2]
                 ,LTRIM(RTRIM([ext2]))                AS [ext2]
                 ,LTRIM(RTRIM([fax]))                AS [fax]
                 ,[dls_facility_id]           
                 ,[dls_network_id]            
                 ,LTRIM(RTRIM([dls_action_code]))                AS [dls_action_code]
                 ,LTRIM(RTRIM([dls_status]))                AS [dls_status]
                 ,LTRIM(RTRIM([dls_source]))                AS [dls_source]
        FROM [dbo].[dls_fac_net]
            WHERE dls_batch_id = @dsirBatchId
END