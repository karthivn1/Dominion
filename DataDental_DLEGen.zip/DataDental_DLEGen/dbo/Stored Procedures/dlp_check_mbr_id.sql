﻿CREATE PROCEDURE [dbo].[dlp_check_mbr_id]
@p_batch_id INT ,
@p_sir_id INT ,
@p_member_id INT

/* 20140817$$ks 
* This program validates the member_id against the DataDental member file to be sure member_id provided to DataLoad was not a typo!
*/
AS
BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
DECLARE @i_error_no INT;
DECLARE @i_isam_error INT;
DECLARE @s_error_descr VARCHAR(64);
DECLARE @i_fatal INT;
DECLARE @tmpint INT;
/* define local variables
*/
DECLARE @l_match_cnt SMALLINT; 
DECLARE @l_alt_match BIT; 
DECLARE @l_src_match BIT;
DECLARE @l_member_id INT;
DECLARE @l_family_id INT;
DECLARE @l_member_code CHAR(2);
DECLARE @l_last_name CHAR(15);
DECLARE @l_first_name CHAR(15);
DECLARE @l_mi CHAR(1); 
DECLARE @l_dob DATE;
DECLARE @l_new_ssn CHAR(11);
DECLARE @l_addr1 CHAR(30);
DECLARE @l_phone CHAR(10);
declare @t_member_code char(2) ;
declare @t_last_name char(15) ;
declare @t_first_name char(15) ;
declare @t_middle_init char(1) ;
declare @t_date_of_birth date ;
declare @t_new_ssn char(11) ;
declare @t_address1 char(30) ;
declare @t_home_phone char(10) ;
declare @new_alt_id char(20) ;
declare @new_src_id char(20) ;
declare @new_cover_code char(40) ;
SET NOCOUNT ON;
SET @t_member_code = '';
SET @t_last_name = '';
SET @t_first_name = '';
SET @t_middle_init = '';
SET @t_date_of_birth = NULL;
SET @t_new_ssn = '';
SET @t_address1 = '';
SET @t_home_phone = '';
SET @new_alt_id = '';
SET @new_src_id = '';
SET @new_cover_code = '';
SET @l_member_id = NULL;

select @t_last_name = VarValue from GlobalVar(NOLOCK) where  VarName = 't_last_name' and  BatchId = @p_batch_id AND Module_Id = 3
select @t_first_name = VarValue from GlobalVar(NOLOCK) where  VarName = 't_first_name' and  BatchId = @p_batch_id AND Module_Id = 3
select @t_date_of_birth = VarValue from GlobalVar(NOLOCK) where  VarName = 't_date_of_birth' and  BatchId = @p_batch_id AND Module_Id = 3
select @t_new_ssn = VarValue from GlobalVar(NOLOCK) where  VarName = 't_new_ssn' and  BatchId = @p_batch_id AND Module_Id = 3

SELECT DISTINCT
@l_member_id = member_id ,
@l_family_id = family_id ,
@l_dob = date_of_birth ,
@l_last_name = last_name ,
@l_first_name = first_name ,
@l_new_ssn = new_ssn
FROM dbo.member m ( NOLOCK )
WHERE m.member_id = @p_member_id;

	IF ( @l_member_id IS NOT NULL
	AND @l_member_id > 0
	AND @l_member_id = @p_member_id
	)
	BEGIN
			IF ( ( @l_last_name = @t_last_name )
			OR ( @l_first_name = @t_first_name )
			OR ( @l_dob = CONVERT(DATE, CONVERT(VARCHAR, @t_date_of_birth)) )
			OR ( @t_new_ssn = @l_new_ssn )
			)
				RETURN 1;
			ELSE
			RETURN -1;
	END;
	ELSE
	RETURN -1;
SET NOCOUNT OFF;
END;