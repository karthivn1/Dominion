﻿-- =============================================
-- Author:		Uthayan.S
-- Create date: 14 Dec 2016
-- Description:	Configuration copy
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_CopyConfiguration]
	-- Add the parameters for the stored procedure here
	@configurationId int,
	@configName varchar(50),
	@createdBy char(15)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @NewconfigId int;

	DECLARE @curr_time VARCHAR(23);
    DECLARE @curr_time1 VARCHAR(23);
    DECLARE @curr_time2 VARCHAR(23);

	 SET @curr_time = GETDATE();
        SET @curr_time1 = SUBSTRING(@curr_time, 12, 11);
        SET @curr_time2 = CONVERT(VARCHAR, CONVERT(DATE, GETDATE())) + ' '
            + @curr_time1;

	SELECT @curr_time2 = FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:ff');

    -- Insert statements for procedure here
	INSERT INTO dl_config
	SELECT dl_config.module_id,   
         @configName,   
         dl_config.config_descr,   
         dl_config.job_def_id,   
         dl_config.config_contact_ln,   
         dl_config.config_contact_fn,   
         dl_config.config_contact_pho,   
         dl_config.config_cont_ph_ext,   
         dl_config.config_cont_email,   
         dl_config.config_status,   
         dl_config.config_icon,   
         @createdBy,   
         @curr_time2  
    FROM dl_config  
   WHERE dl_config.config_id = @configurationId    
   SELECT @NewconfigId=SCOPE_IDENTITY()

INSERT INTO dl_config_job_det
SELECT   @NewconfigId,   
         dl_config_job_det.sp_id,   
         dl_config_job_det.tolerance,   
         @createdBy,   
         @curr_time2 
FROM dl_config_job_det  
WHERE dl_config_job_det.config_id = @configurationId   

INSERT INTO dl_config_param
 SELECT  @NewconfigId,   
         dl_config_param.sp_param_id,   
         dl_config_param.config_param_value,   
         @createdBy,   
         @curr_time2
    FROM dl_config_param,   
         dl_sp,   
         dl_sp_param  
   WHERE ( dl_sp_param.sp_id = dl_sp.sp_id ) and  
         ( dl_sp_param.sp_param_id = dl_config_param.sp_param_id ) and  
         ( ( dl_config_param.config_id = @configurationId ) )    

INSERT INTO dlsp_eg_group_plan
SELECT   @NewconfigId,   
         dlsp_eg_group_plan.group_id,   
         dlsp_eg_group_plan.plan_id,   
         dlsp_eg_group_plan.facility_id,   
         dlsp_eg_group_plan.def_key,   
         dlsp_eg_group_plan.type,   
		 @createdBy,   
         @curr_time2  
FROM dlsp_eg_group_plan  
WHERE dlsp_eg_group_plan.config_id = @configurationId


 --SELECT stc_user_access.user_access_id,   
 --        stc_user_access.usersl_id,   
 --        stc_user_access.sys_opt_id,   
 --        stc_user_access.eff_date,   
 --        stc_user_access.exp_date,   
 --        stc_user_access.created_by,   
 --        stc_user_access.created_time,   
 --        stc_sys_opt.sys_opt_id,   
 --        stc_sys_opt.sys_opt_type,   
 --        stc_sys_opt.sys_id,   
 --        stc_sys_opt.sys_access_type,   
 --        stc_sys_opt.created_by,   
 --        stc_sys_opt.created_time  
 --   FROM stc_user_access,   
 --        stc_sys_opt  
 --  WHERE ( stc_user_access.sys_opt_id = stc_sys_opt.sys_opt_id ) and  
 --        ( ( stc_sys_opt.sys_opt_type = 'CF' ) AND  
 --        ( stc_sys_opt.sys_id = @configurationId ) )  
INSERT INTO stc_user_access (usersl_id,sys_opt_id,eff_date,exp_date,created_by,created_time) 
SELECT A.usersl_id,   
         C.sys_opt_id,   
         A.eff_date,   
         A.exp_date,                                    
         @createdBy,  
         @curr_time2   
FROM stc_user_access A
INNER JOIN stc_sys_opt B on A.sys_opt_id = B.sys_opt_id and B.sys_id=@configurationId and B.sys_opt_type='CF'
INNER JOIN stc_sys_opt C on B.sys_access_type= C.sys_access_type and  C.sys_id=@NewconfigId and C.sys_opt_type='CF'
WHERE C.sys_opt_id is not null  

END