﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_elig_dep_term]
@a_batch_id INT ,
@a_sub_sir_id INT ,
@a_mb_gr_pl_id INT ,
@a_load_period DATE

-- Modification: support multi_group and multi_plan
AS
BEGIN
DECLARE @n_error_no INT;
DECLARE @n_isam_error INT;
DECLARE @n_error_text CHAR(64);
DECLARE @n_fatal INT;
DECLARE @n_batch_id INT;
DECLARE @n_family_id INT;
DECLARE @n_dls_elig_id INT;
DECLARE @n_tl_sub_sir_id INT;
DECLARE @n_subscriber CHAR(1);
DECLARE @n_alt_id CHAR(20);
DECLARE @n_sub_ssn CHAR(11);
DECLARE @n_ssn CHAR(11);
DECLARE @n_sub_alt_id CHAR(20);
DECLARE @n_member_id INT;
DECLARE @n_sub_id INT;
DECLARE @n_group_id INT;
DECLARE @n_member_code CHAR(3);
DECLARE @n_plan_id INT;
DECLARE @n_facility_id INT;
DECLARE @n_key CHAR(2);
DECLARE @n_type CHAR(2);
DECLARE @n_last_name CHAR(15);
DECLARE @n_first_name CHAR(15);
DECLARE @n_middle_init CHAR(1);
DECLARE @n_date_of_birth DATE;
DECLARE @n_student_flag CHAR(1);
DECLARE @n_disable_flag CHAR(1);
DECLARE @n_cobra_flag CHAR(1);
DECLARE @n_action_code CHAR(2);
DECLARE @n_rate_code CHAR(2);
DECLARE @n_plan_eff_date DATE;
DECLARE @n_plan_term_date DATE;
DECLARE @n_rate_eff_date DATE;
DECLARE @n_sub_action_code CHAR(2);
DECLARE @new_dls_sir_id INT;
DECLARE @n_process_count INT;
DECLARE @n_succ_count INT;
--DECLARE @SWV_cursor_var1 CURSOR;
--DECLARE @SWV_cursor_var2 CURSOR;
SET NOCOUNT ON;
SET @new_dls_sir_id = 0
--SET @n_process_count = 0
--SET @n_succ_count = 0 
SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3
BEGIN TRY
SELECT @n_batch_id = dls_batch_id ,
@n_family_id = dls_member_id ,
@n_group_id = dls_group_id ,
@n_plan_id = dls_plan_id ,
@n_sub_action_code = dls_action_code
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_sir_id = @a_sub_sir_id;
IF @n_sub_action_code IN ( 'GX', 'PC', 'SR' )
RETURN 1;
IF @n_family_id IS NULL
RETURN 1;
IF @n_group_id IS NULL
OR @n_plan_id IS NULL
RETURN -1;
DELETE FROM dbo.dls_elig
WHERE dls_batch_id = @a_batch_id
AND dls_sub_sir_id = @a_sub_sir_id
AND member_flag != '00'
AND dls_source = 'A';
/*SET @SWV_cursor_var1 = CURSOR FOR SELECT DISTINCT member_id
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @a_mb_gr_pl_id
AND member_id != @n_family_id
AND exp_date IS NULL
AND NOT EXISTS(SELECT * FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @n_batch_id
AND dls_sub_sir_id = @a_sub_sir_id
AND dls_sir_id != @a_sub_sir_id
AND dls_member_id = dbo.rlplfc.member_id);
OPEN @SWV_cursor_var1;
FETCH NEXT FROM @SWV_cursor_var1 INTO @n_member_id;
WHILE @@FETCH_STATUS = 0*/
DECLARE @SWV_cursor_var1 TABLE
(
id INT IDENTITY ,
member_id INT 
);
INSERT INTO @SWV_cursor_var1
( member_id
)
SELECT DISTINCT member_id
FROM dbo.rlplfc (NOLOCK)
WHERE mb_gr_pl_id = @a_mb_gr_pl_id
AND member_id != @n_family_id
AND exp_date IS NULL
AND NOT EXISTS(SELECT * FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @n_batch_id
AND dls_sub_sir_id = @a_sub_sir_id
AND dls_sir_id != @a_sub_sir_id
AND dls_member_id = dbo.rlplfc.member_id);
DECLARE @cur1_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur1_cnt = COUNT(1)
FROM @SWV_cursor_var1;
WHILE ( @cur_i <= @cur1_cnt )
BEGIN
SELECT @n_member_id=member_id
FROM @SWV_cursor_var1
WHERE id = @cur_i;
SELECT @n_ssn = member_ssn ,
@n_last_name = last_name ,
@n_first_name = first_name ,
@n_middle_init = middle_init ,
@n_sub_id = family_id ,
@n_alt_id = alt_id ,
@n_member_code = member_code ,
@n_date_of_birth = date_of_birth ,
@n_student_flag = student_flag ,
@n_disable_flag = disable_flag
FROM dbo.member (NOLOCK)
WHERE member_id = @n_member_id;
/* SET @SWV_cursor_var2 = CURSOR FOR SELECT rf.eff_date, rf.facility_id
FROM dbo.rlplfc rf (NOLOCK)
WHERE rf.member_id = @n_member_id
AND rf.mb_gr_pl_id = @a_mb_gr_pl_id
AND rf.exp_date IS NULL;
OPEN @SWV_cursor_var2;
FETCH NEXT FROM @SWV_cursor_var2 INTO @n_plan_eff_date,
@n_facility_id;
WHILE @@FETCH_STATUS = 0*/
DECLARE @SWV_cursor_var2 TABLE
(
id INT IDENTITY ,
eff_date date, facility_id int
);
INSERT INTO @SWV_cursor_var2
( eff_date, facility_id
)
SELECT rf.eff_date, rf.facility_id
FROM dbo.rlplfc rf (NOLOCK)
WHERE rf.member_id = @n_member_id
AND rf.mb_gr_pl_id = @a_mb_gr_pl_id
AND rf.exp_date IS NULL;
DECLARE @cur2_cnt INT ,
@cur2_i INT;
SET @cur2_i = 1;
--Get the no. of records for the cursor
SELECT @cur2_cnt = COUNT(1)
FROM @SWV_cursor_var2;
WHILE ( @cur2_i <= @cur2_cnt )
BEGIN
SELECT @n_plan_eff_date=eff_date, @n_facility_id=facility_id
FROM @SWV_cursor_var2
WHERE id = @cur2_i;
IF @n_plan_eff_date > @a_load_period
SET @n_plan_term_date = @n_plan_eff_date;
ELSE
SET @n_plan_term_date = @a_load_period;
INSERT INTO dbo.dls_elig
( dls_sub_sir_id ,
dls_batch_id ,
member_flag ,
alt_id ,
ssn ,
sub_ssn ,
sub_alt_id ,
member_code ,
last_name ,
first_name ,
middle_init ,
date_of_birth ,
student_flag ,
disable_flag ,
plan_eff_date ,
plan_term_date ,
facility_eff_date ,
dls_group_id ,
dls_plan_id ,
facility_id ,
def_key ,
type ,
dls_member_id ,
dls_sub_id ,
dls_action_code ,
dls_status ,
dls_source
)
VALUES ( @a_sub_sir_id ,
@n_batch_id ,
'09' ,
@n_alt_id ,
@n_ssn ,
@n_ssn ,
@n_alt_id ,
@n_member_code ,
@n_last_name ,
@n_first_name ,
@n_middle_init ,
@n_date_of_birth ,
@n_student_flag ,
@n_disable_flag ,
@n_plan_eff_date ,
@n_plan_term_date ,
@n_plan_eff_date ,
@n_group_id ,
@n_plan_id ,
@n_facility_id ,
'DF' ,
'DF' ,
@n_member_id ,
@n_sub_id ,
'MT' ,
'P' ,
'A'
);
EXECUTE @n_error_no = dbo.dl_log_action @n_batch_id,
@new_dls_sir_id, 'MT', @n_plan_term_date;

SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3

SET @n_process_count = @n_process_count + 1;
SET @n_succ_count = @n_succ_count + 1;

UPDATE GlobalVar
SET VarValue = @n_process_count
WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 3

UPDATE GlobalVar
SET VarValue = @n_succ_count
WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 3

/*FETCH NEXT FROM @SWV_cursor_var2 INTO @n_plan_eff_date,
@n_facility_id;*/
SET @cur2_i = @cur2_i + 1;
END;
-- CLOSE @SWV_cursor_var2;
--FETCH NEXT FROM @SWV_cursor_var1 INTO @n_member_id;
SET @cur_i = @cur_i + 1;
END;
-- CLOSE @SWV_cursor_var1;
--trace off;
RETURN 1;
END TRY
BEGIN CATCH
RETURN -100;
END CATCH;
SET NOCOUNT OFF;
　
--set debug file to "/tmp/dlp_elig_dep_term.trc";
--trace on;
--set explain on;
END;