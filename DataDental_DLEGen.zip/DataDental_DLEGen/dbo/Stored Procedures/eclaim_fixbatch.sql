﻿CREATE PROCEDURE [dbo].[eclaim_fixbatch]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(80) = NULL OUTPUT ,
    @SWP_Ret_Value2 VARCHAR(80) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:28:28 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);

        DECLARE @eClaimID INT;
        DECLARE @eClaimStatus INT;
        DECLARE @eClaimErrorCode CHAR(10);
        DECLARE @eClaimhuser CHAR(20);
        DECLARE @eClaimhdatetime DATETIME;

        DECLARE @UpdateCount INT;
        DECLARE @NoMatchCount INT;
        DECLARE @NewErrorCode CHAR(10);
        DECLARE @AltID CHAR(20);
        DECLARE @DocNo CHAR(15);
        DECLARE @PVID INT;
        DECLARE @FCID INT;
        DECLARE @PlanID INT;
        DECLARE @GroupID INT;
        DECLARE @SubID INT;
        DECLARE @PatID INT;
        DECLARE @HMOType CHAR(2);
        DECLARE @SWV_cursor_var1 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            SET LOCK_TIMEOUT 30000;

--set debug file to 'fixeclaim.trc';
--trace on;

            SET @UpdateCount = 0;
            SET @NoMatchCount = 0;
            SET @NewErrorCode = '';
            BEGIN TRAN;
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT alt_id, doc_no, pv_id, fc_id, hmo_type, plan_id, group_id,
	patient_id, sub_id
	  
      FROM #eclaim_ks;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @AltID, @DocNo, @PVID, @FCID,
                @HMOType, @PlanID, @GroupID, @PatID, @SubID;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    SET @NewErrorCode = '';
                    UPDATE  dbo.eclaim_h
                    SET     document_no = @DocNo ,
                            pv_id = @PVID ,
                            contr_fc_id = @FCID ,
                            hmo_claim_type = @HMOType ,
                            plan_id = @PlanID ,
                            group_id = @GroupID ,
                            patient_id = @PatID ,
                            subscriber_id = @SubID ,
                            status = 1 ,
                            h_user = 'fix_clms' ,
                            h_datetime = GETDATE()
                    WHERE   alt_id = @AltID;
                    SET @UpdateCount = @UpdateCount + 1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @AltID, @DocNo,
                        @PVID, @FCID, @HMOType, @PlanID, @GroupID, @PatID,
                        @SubID;
                END;
            CLOSE @SWV_cursor_var1;
            COMMIT;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('eClaims fix Completed. ',
                                         'Total number of records updated was: ',
                                         @UpdateCount, '.');
            SET @SWP_Ret_Value2 = CONCAT('Of the total, ', @NoMatchCount,
                                         ' records did not have a new matching error code.');
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            SET @SWP_Ret_Value2 = '';
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


----------------------------------------------------------------------
    END;