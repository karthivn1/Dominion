﻿CREATE PROCEDURE [dbo].[dlp_up_sg_mbship] @a_batch_id INT
    

/*
	Created Date	: 05/09/2001 
	Created By	: Jacky Chang 
	Reason		: Single Group Update -  MEMBERSHIP.
*/
--error variable
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:02:02 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1







000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_fatal INT;
        DECLARE @t_temp_action_code CHAR(2);
        DECLARE @tot_msi INT;
      	--Subscriber in plan.
        DECLARE @ls_user CHAR(20);
        DECLARE @ls_datetime DATE;
        DECLARE @li_rlmbrt_id INT;
        DECLARE @li_mb_gr_pl_id INT;
        DECLARE @n_dep_msi INT;
        DECLARE @d_mb_gr_pl_id INT;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @n_ffs_plan INT;
        DECLARE @s_ins_opt CHAR(3);
        DECLARE @n_new_eff_date DATE;
        DECLARE @s_group_type CHAR(2);
        DECLARE @s_bill_type CHAR(2);
        DECLARE @i_new_sg_id INT;
        DECLARE @s_sg_err CHAR(64);
        DECLARE @s_status_code CHAR(1);
        DECLARE @s_account_name CHAR(25);
        DECLARE @sg_ach_err INT;
        DECLARE @t_member_id INT;
        DECLARE @t_zip VARCHAR(9);
        DECLARE @d_address_id INT;
        DECLARE @d_rlplfc_id INT;
        DECLARE @r_facility_id INT;
        DECLARE @d_plfc_eff_date DATE;
        DECLARE @tmp_plfc_eff_date DATE;
        DECLARE @d_plfc_exp_date DATE;
        DECLARE @d_eff_rt_date DATE;
        DECLARE @d_pdcomm_eff DATE;
        DECLARE @BilToDate DATE;
        DECLARE @d_date_of_birth DATE;
        DECLARE @d_rlmbrt_id INT;
        DECLARE @d_mbrt_eff_date DATE;
        DECLARE @dummy_act_code CHAR(2);
        DECLARE @d_curr_rate_code CHAR(2);
        DECLARE @i_rel_gppl_id INT;
        DECLARE @t_sir_id		INT;
		DECLARE @sg_bu_sp_id	INT;
		DECLARE @sg_up_sp_id	INT;
		DECLARE @sg_sir_def_id	INT;
		DECLARE @t_sub_sir_id	INT;
		DECLARE @t_action_date	date;
		DECLARE @n_msi		INT;
		DECLARE @msi_num		INT;
		DECLARE @msi_num1		INT;
		DECLARE @msi_upper		INT;
		DECLARE @n_datetime	datetime;
		DECLARE @s_dls_sir_id	INT;
		DECLARE @s_dls_batch_id	INT;
		DECLARE @s_dls_sub_sir_id	INT;
		DECLARE @s_member_flag	char(2);
		DECLARE @s_alt_id		char(20);
		DECLARE @s_ssn		char(11);
		DECLARE @s_sub_ssn		char(11);
		DECLARE @s_sub_alt_id	char(20);
		DECLARE @s_member_code	char(3);
		DECLARE @s_last_name	char(15);
		DECLARE @s_first_name	char(15);
		DECLARE @s_middle_init	char(1);
		DECLARE @s_name_prefix char(5);
		DECLARE @s_name_suffix char(5);
		DECLARE @s_date_of_birth	char(10);
		DECLARE @s_student_flag	char(1);
		DECLARE @s_disable_flag	char(1);
		DECLARE @s_cobra_flag	char(1);
		DECLARE @s_msg_group_id	INT;
		DECLARE @s_plan_id		INT;
		DECLARE @s_facility_id	INT;
		DECLARE @s_rate_code	char(2);
		DECLARE @s_mb_gppl_eff	char(10);
		DECLARE @s_mb_fc_eff_date	char(10);
		DECLARE @s_mb_term_date	char(10);
		DECLARE @s_bank_account	char(25);
		DECLARE @s_account_type	char(2);
		DECLARE @s_tr_nbr		char(9);
		DECLARE @s_trans_code	char(2);
		DECLARE @s_address1	char(30);
		DECLARE @s_address2	char(30);
		DECLARE @s_city		char(30);
		DECLARE @s_state		char(2);
		DECLARE @s_zip 		char(5);
		DECLARE @s_zipx 		char(4);
		DECLARE @s_home_phone	char(10);
		DECLARE @s_home_ext 	char(5);
		DECLARE @s_work_phone	char(10);
		DECLARE @s_work_ext	char(5);
		DECLARE @s_email		char(250);
		DECLARE @s_producer_id	INT;
		DECLARE @s_comm_scheme_id 	char(5);
		DECLARE @s_pd_type		char(2);
		DECLARE @s_license_number	char(9);
		DECLARE @s_selling_period	char(1);
		DECLARE @s_pdcomm_eff	char(10);
		DECLARE @s_dls_mb_id	INT;
		DECLARE @s_dls_sub_id	INT;
		DECLARE @s_dls_msg_id	INT;
		DECLARE @s_dls_group_id	INT;
		DECLARE @s_dls_plan_id	INT;
		DECLARE @s_dls_fc_id	INT;
		DECLARE @s_dls_pd_id	INT;
		DECLARE @s_dls_act_code	char(2);
		DECLARE @s_msg_group_alt_id char(20);
		DECLARE @s_plan_dsp_name char(30);
		DECLARE @s_facility_alt_id char(20);
		DECLARE @s_producer_alt_id char(20);
		DECLARE @s_new_ssn char(11);
		DECLARE @s_src_id char(20);
		DECLARE @s_subnew_ssn char(11);
		DECLARE @t_subsrc_id char(20);
		DECLARE @t_ext_id_col char(20);
		DECLARE @from_api smallint;
		DECLARE @s_sub_in_plan		smallint;
        DECLARE @SWV_dlp_sg_gi_update INT;
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;
        DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @SWV_func_DLP_REIN_SG_GROUP_par0 DATE;
        DECLARE @SWV_func_DLP_ADD_SG_PLAN_par0 DATE;
        DECLARE @SWV_cursor_var4 CURSOR;
        DECLARE @SWV_func_DLP_REIN_SG_GROUP_par1 DATE;
        DECLARE @SWV_func_DLP_REIN_SG_GROUP_par2 DATE;
        DECLARE @SWV_cursor_var5 CURSOR;
        DECLARE @SWV_cursor_var6 CURSOR;
        DECLARE @SWV_cursor_var7 CURSOR;
        DECLARE @SWV_cursor_var8 CURSOR;
        DECLARE @SWV_cursor_var9 CURSOR;
        DECLARE @SWV_cursor_var10 CURSOR;
        DECLARE @SWV_func_DLP_ADD_SG_PLAN_par1 DATE;
        DECLARE @SWV_cursor_var11 CURSOR;
        DECLARE @v_Null INT;
		DECLARE @error_no INT
		DECLARE @created_by CHAR(8)
        SET NOCOUNT ON;

		SELECT @created_by = LEFT(created_by,8) FROM dl_config_bat(NOLOCK) WHERE config_bat_id = @a_batch_id
        SET @t_sir_id = 0;
   
        SET @sg_bu_sp_id = 0;
       
        SET @sg_up_sp_id = 0;
		EXECUTE @sg_up_sp_id=dbo.dl_get_sp_id @a_batch_id, 'up_sg_member'
		           
        SET @sg_sir_def_id = 0;
		SET @sg_sir_def_id = dbo.dl_get_sir_def_id('sg_member');
  
        SET @t_sub_sir_id = 0;
     
        SET @t_action_date = NULL;
     
        SET @n_msi = 0;
  
        SET @msi_num = 0;
 
        SET @msi_num1 = 0;
    
        SET @msi_upper = 0;
  
        SET @n_datetime = NULL;
     
        SET @s_dls_sir_id = 0;
     
        SET @s_dls_batch_id = 0;

        SET @s_dls_sub_sir_id = 0;
   
        SET @s_member_flag = '';

        SET @s_alt_id = '';
   
        SET @s_ssn = '';
        
        SET @s_sub_ssn = '';
  
        SET @s_sub_alt_id = '';
      
        SET @s_member_code = '';
    
        SET @s_last_name = '';
  
        SET @s_first_name = '';
       
        SET @s_middle_init = '';

        SET @s_name_prefix = '';

        SET @s_name_suffix = '';
   
        SET @s_date_of_birth = '';
  
        SET @s_student_flag = '';
    
        SET @s_disable_flag = '';
   
        SET @s_cobra_flag = '';
   
        SET @s_msg_group_id = 0;
  
        SET @s_plan_id = 0;
      
        SET @s_facility_id = 0;

        SET @s_rate_code = '';
   
        SET @s_mb_gppl_eff = '';
  
   SET @s_mb_fc_eff_date = ''
   --EXECUTE SWPCrtGlVar 's_mb_fc_eff_date'
   --EXECUTE SWPAddGlVar 's_mb_fc_eff_date',@s_mb_fc_eff_date
   --SET @s_mb_term_date = ''
   --EXECUTE SWPCrtGlVar 's_mb_term_date'
   --EXECUTE SWPAddGlVar 's_mb_term_date',@s_mb_term_date
        SET @s_bank_account = '';
   
        SET @s_account_type = '';
    
        SET @s_tr_nbr = '';
      
        SET @s_trans_code = '';
   
        SET @s_address1 = '';
    
        SET @s_address2 = '';

        SET @s_city = '';
   
        SET @s_state = '';
  
        SET @s_zip = '';
 
        SET @s_zipx = '';
        
        SET @s_home_phone = '';
    
        SET @s_home_ext = '';
        
        SET @s_work_phone = '';
       
        SET @s_work_ext = '';

        SET @s_email = '';
 
      SET @s_producer_id = 0;
  
        SET @s_comm_scheme_id = '';
    
        SET @s_pd_type = '';

SET @s_license_number = '';

      SET @s_selling_period = '';
     
        SET @s_pdcomm_eff = '';

        SET @s_dls_mb_id = 0;

  SET @s_dls_sub_id = 0;

SET @s_dls_msg_id = 0;
  
        SET @s_dls_group_id = 0;
    
        SET @s_dls_plan_id = 0;
     
        SET @s_dls_fc_id = 0;
     
        SET @s_dls_pd_id = 0;
     
        SET @s_dls_act_code = '';
      
        SET @s_msg_group_alt_id = '';

        SET @s_plan_dsp_name = '';
     
        SET @s_facility_alt_id = '';
   
        SET @s_producer_alt_id = '';
     
        SET @s_new_ssn = '';
      
        SET @s_src_id = '';
    
        SET @s_subnew_ssn = '';
    
        SET @t_subsrc_id = '';
    
        SET @t_ext_id_col = '';
   
        SET @from_api = 0;
  
        SET @s_sub_in_plan = NULL;
      
        BEGIN TRY
            
            SET @ls_user = CONCAT('dl', @a_batch_id);
            SET @ls_datetime = CONVERT(DATE, CONVERT(DATE, GETDATE()));

/* 20121018$$ks - altID is only required for new members
 * existing members in DataDental may not have been assigned and Alt ID
 * When this is run from the SG API we already have looked up the member_id for both
 * subscriber and dependent therefore only require alt_id to be populated if this is a 
 * new member
 */
 
  
			  select @n_msi=VarValue from GlobalVar(NOLOCK) where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2
			  
			select @msi_upper=VarValue from GlobalVar(NOLOCK) where VarName = 'msi_upper' and  BatchId = @a_batch_id AND Module_Id = 2

            SELECT @s_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 2
			
			SELECT @s_dls_act_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_act_code' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @from_api = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_dls_msg_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_msg_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_dls_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_plan_id' and  BatchId = @a_batch_id AND Module_Id = 2
			--SELECT @s_dls_act_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_act_code' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @t_action_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_action_date' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_dls_mb_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_src_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_src_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_dls_fc_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_fc_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_member_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_middle_init' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 2

			SELECT @s_dls_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_dls_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_sub_in_plan = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_sub_in_plan' and  BatchId = @a_batch_id AND Module_Id = 2
			select @s_mb_fc_eff_date=VarValue from GlobalVar(NOLOCK) where VarName = 's_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 2
			select @s_mb_term_date=VarValue from GlobalVar(NOLOCK) where VarName = 's_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 2
			select @t_sub_sir_id=VarValue from GlobalVar(NOLOCK) where VarName = 's_dls_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
			select @s_dls_sir_id=VarValue from GlobalVar(NOLOCK) where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @t_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
			
			

			
     IF ( @s_alt_id IS NULL
                 OR @s_alt_id = ''
               )
                OR LEN(@s_alt_id) = 0
                BEGIN
                    
                    IF ( @s_dls_act_code IN ( 'DA', 'SA' )
                         OR @from_api = 0
                       )
					   BEGIN
					   SET @error_no=401
					RAISERROR('Member alt_id is NULL',0,1);
					EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no; 
						END
                  ELSE
      BEGIN
                            SET @s_alt_id = '';
                            
                        END;
                END;

        
            IF @s_dls_msg_id IS NULL
			BEGIN
			SET @error_no=402
                RAISERROR('Group id is NULL',0,1);
				EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
						END

            
            IF @s_dls_plan_id IS NULL
			BEGIN
			SET @error_no=403
                RAISERROR('Plan id is NULL',0,1);
			EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
						END

            
            IF ( @s_dls_act_code IS NULL
                 OR @s_dls_act_code = ''
               )
                OR LEN(@s_dls_act_code) = 0
				BEGIN
				SET @error_no=404
                RAISERROR('Action code is NULL',0,1);
				EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
						END

/* 20131027$$ks - Added DR - Dep Reinstate to list 
 */
            
            IF @s_dls_act_code NOT IN ( 'DR', 'DA', 'FX', 'MT', 'NC', 'PA',
                                        'PC', 'RI', 'RC', 'SA', 'PC', 'RC',
                                        'MU', 'ST', 'GA', 'GR' )
                AND @s_dls_act_code NOT LIKE 'G[1-7]' ESCAPE '\'
				BEGIN
				SET @error_no=406
                RAISERROR('Invalid action code',0,1);
				EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END

            
            IF @s_dls_act_code LIKE 'G[1-7]' ESCAPE '\'
                BEGIN
                    
                    EXECUTE @SWV_dlp_sg_gi_update = dbo.dlp_sg_gi_update @s_dls_sir_id,@s_dls_act_code;

                    RETURN @SWV_dlp_sg_gi_update
                END;

            
            IF ( @t_action_date) IS NULL
			BEGIN
			SET @error_no=405
                RAISERROR('Member''s action_date is NULL',0,1);
			EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END

            
            IF @s_dls_act_code IN ( 'PA', 'PC', 'RI', 'RC', 'SA' )
                BEGIN
                    
                    IF ( @s_rate_code IS NULL
                         OR @s_rate_code = ''
                       )
                        OR LEN(@s_rate_code) = 0
						BEGIN
						SET @error_no=407
                        RAISERROR('Rate code is NULL',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    IF (@t_action_date) IS NULL
					BEGIN
					SET @error_no=408
          RAISERROR('Subscriber''s rate eff_date is NULL',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                END;

 
            IF @s_dls_act_code IN ( 'ST', 'MT', 'RI', 'RC', 'PA' )
                BEGIN
                    
                    IF @s_dls_mb_id IS NULL
					BEGIN
					SET @error_no=413
                        RAISERROR('Member ID is NULL',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    IF @s_dls_sub_id IS NULL
					BEGIN
					SET @error_no=414
                        RAISERROR('Member subscriber ID is NULL',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                END;

            IF @s_dls_act_code IN ( 'ST', 'MT', 'RC' )
                BEGIN
                    SET @d_mb_gr_pl_id = NULL;
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
	
         FROM dbo.rlmbgrpl (NOLOCK)
         WHERE member_id = @s_dls_sub_id
         AND group_id = @s_dls_group_id
         AND plan_id = @s_dls_plan_id
         AND eff_gr_pl <= @t_action_date
AND (exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
         ORDER BY 2 DESC,3;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @d_mb_gr_pl_id,
                        @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label12;
             FETCH NEXT FROM @SWV_cursor_var1 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                        END;
                    SWL_Label12:
                    CLOSE @SWV_cursor_var1;
                    IF @d_mb_gr_pl_id IS NULL
BEGIN
 
                            IF @s_dls_act_code = 'MT'
                                BEGIN
                                    
                                    IF (@t_action_date) = CONVERT(DATE, @s_mb_term_date)
                                RETURN 1;
                                END;
								SET @error_no=416
                            RAISERROR('Subscriber has no active group/plan',0,1);
							EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
                        END;
                END;

-------------------------------------------
            
            IF ( @s_dls_act_code = 'MU' )
                BEGIN
                    UPDATE  dbo.member
                    SET     new_ssn = @s_ssn ,
                            alt_id = @s_alt_id , 
	--	source_id = s_src_id, 
                            last_name = @s_last_name ,
                 first_name = @s_first_name ,
                            middle_init = @s_middle_init ,
                            date_of_birth = CAST(@s_date_of_birth AS DATE) ,
                            member_code = @s_member_code ,
                            action_code = 'GI' ,
                            h_datetime = GETDATE() ,
                            h_user = @ls_user
                    WHERE   member_id = @s_dls_mb_id;
	/* 20131029$$ks - only update source ID if new value is not blank
	 */
                    
                    IF @s_src_id != ''
                        UPDATE  dbo.member
                        SET     source_id = @s_src_id
                        WHERE   member_id = @s_dls_mb_id
                                AND source_id != @s_src_id;
	
---- Update external ID if necessary!
                    SELECT  @t_ext_id_col = str_1 
                    FROM  dbo.typ_table_exp t ( NOLOCK ) ,
       dbo.member m ( NOLOCK )
     WHERE   m.ext_id_type = t.int_1
            AND t.subsys_code = 'MB'
                            AND t.tab_name = 'ext_id_type'
                            AND m.member_id = @s_dls_mb_id; 
                    
                   
                    IF @t_ext_id_col = 'new_ssn'
                        UPDATE  dbo.member
                        SET     member_ssn = new_ssn
                        WHERE   member_id = @s_dls_mb_id;
                    ELSE
                        BEGIN
    
                            IF @t_ext_id_col = 'alt_id'
                                UPDATE  dbo.member
                                SET     member_ssn = alt_id
                                WHERE   member_id = @s_dls_mb_id;
                            ELSE
  BEGIN
                                 
                                    IF @t_ext_id_col = 'source_id'
                                        UPDATE  dbo.member
                                        SET     member_ssn = source_id
                                        WHERE   member_id = @s_dls_mb_id;
                                END;
                        END;
                END;

--update action_code to GI, AR#4961
-------------------------------------------
            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.[plan] (NOLOCK) ,
                                    dbo.ins_opt (NOLOCK)
                            WHERE   dbo.[plan].plan_id = @s_dls_plan_id
                                    AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                    AND dbo.ins_opt.ins_opt_qual = 'I' )
                BEGIN
                    SET @n_ffs_plan = 0;
              SELECT  @s_ins_opt = ins_opt
                    FROM    dbo.[plan]  (NOLOCK)
                WHERE   plan_id = @s_dls_plan_id;
                    
                END;
            ELSE
                SET @n_ffs_plan = 1;

            
            IF @s_dls_act_code IN ( 'MT', 'ST' )
   IF @n_ffs_plan = 0
               BEGIN
      
                        IF @s_dls_fc_id IS NULL
						BEGIN
						SET @error_no=415
                            RAISERROR('No Facility ID specified',0,1);
							EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                    END;
   

            
            IF @s_dls_act_code IN ( 'DR', 'DA', 'FA', 'FX', 'RI', 'SA', 'PC',
                                    'PA' )
                BEGIN
                    
                    SET @n_new_eff_date = (@t_action_date);
                    IF @n_ffs_plan = 0
                        BEGIN
                    
                            IF @s_dls_fc_id IS NULL
							BEGIN
							SET @error_no=415
                                RAISERROR('No Facility ID specified',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                        END;
                END;

            SELECT  @s_group_type = group_type ,
                    @s_bill_type = bill_type
            FROM    dbo.[group]  (NOLOCK)
            WHERE   group_id = @s_dls_msg_id;
            
            IF @s_group_type <> 'MS'
			BEGIN
			SET @error_no=420
                RAISERROR('Invalid Group Type for MSG ID',0,1);
				EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END

            
            IF @s_dls_act_code = 'ST'
-- TERMINATING  A SUB WILL TERMINATE THE SG AS WELL if SG has only one plan
-- TERM EXISTING RLMBGRPL MODULE:
   BEGIN
                    
                    IF ( @s_member_flag <> '00' )
					BEGIN
					SET @error_no=425
                        RAISERROR('Dependent with ST action code.',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
				END
	
                    IF @d_mb_gr_pl_id IS NULL
					BEGIN
					SET @error_no=613
                        RAISERROR('Missing RLMBGRPL record (ST)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    IF ( @d_exp_gr_pl IS NOT NULL )
					BEGIN
					SET @error_no=426
                        RAISERROR('Subscriber ST on a terminated group/plan',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
            
                    IF ( @s_mb_term_date < @d_eff_gr_pl )
					BEGIN
					SET @error_no=427
              RAISERROR('Subscriber ST before group/plan is active',0,1);
			  EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                  

                    SET @n_msi = @n_msi + 1;
                    
					
                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=724
                        RAISERROR('MSI number exceeds maximum allocated number(ST)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	 
----------Updating Group Status for Single Group
                    IF ( ( SELECT   COUNT(*)
                           FROM     dbo.rlmbgrpl  (NOLOCK)
                           WHERE    group_id = @s_dls_group_id
                                    AND exp_gr_pl IS NULL
                         ) = 1 )
                        BEGIN
                            UPDATE  dbo.group_status
                            SET     exp_date = CAST(@s_mb_term_date AS DATE) ,
                                    h_datetime = @ls_datetime ,
                                    h_user = @ls_user
                            WHERE   group_id = @s_dls_group_id
                                    AND exp_date IS NULL;
                            INSERT  INTO dbo.group_status
                                    ( group_id ,
                                      group_status ,
                                      reason_code ,
                                      eff_date ,
                                      h_datetime ,
                                      h_action ,
                                      h_user
                                    )
          VALUES  ( @s_dls_group_id ,
                                      'T1' ,
                         'DF' ,
                                      @s_mb_term_date ,
                                      @ls_datetime ,
                                      'ST' ,
     @ls_user
        );
       END;
	
----
                    UPDATE  dbo.rlmbgrpl
                    SET     h_msi = @n_msi ,
                            exp_gr_pl = CAST(@s_mb_term_date AS DATE) ,
                            action_code = 'ST' ,
                            h_action = action_code ,
                            h_user = @ls_user ,
                            h_datetime = @ls_datetime
          WHERE   mb_gr_pl_id = @d_mb_gr_pl_id;

                    IF EXISTS ( SELECT  *
                                FROM    dbo.rlmbgrpl  (NOLOCK)
                                WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                   AND exp_gr_pl IS NULL )
										BEGIN
										SET @error_no=614
                        RAISERROR('Error in RLMBGRPL termination (ST)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_1',@s_dls_sub_id,@created_by;
                END;

            
            IF @s_dls_act_code = 'MT'
               BEGIN
                    
                    IF ( @s_member_flag = '00' )
					BEGIN
					SET @error_no=428
                        RAISERROR('Subscriber with MT action code.',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    IF ( @d_exp_gr_pl IS NOT NULL )
                        BEGIN
                          
                            IF ( @s_mb_term_date = @d_exp_gr_pl )
                          RETURN 1;
		
                           
                            IF ( @s_mb_term_date > @d_exp_gr_pl )
							BEGIN
							SET @error_no=429
                                RAISERROR('Dependent MT after subscriber''s terminated',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                        END;
                    ELSE
                        BEGIN
                           
                            IF ( @s_mb_term_date < @d_eff_gr_pl )
							BEGIN
							SET @error_no=431
                          RAISERROR('Dependent MT termed before sub''s group/plan is active',0,1);
						  EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                        END;
	
-- TERM OLD RLPLFC MODULE:
/* 20131122$$ks - if I am terminating dependent do I care if they are in the same FC as the
 * SIR has sent?
 */
 --	if n_ffs_plan = 0 then
                    SELECT  @d_rlplfc_id = rlplfc_id
     FROM    dbo.rlplfc  (NOLOCK)
                    WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                            AND member_id = @s_dls_mb_id
--		and facility_id = s_dls_fc_id -- removed reference to facility
                            AND eff_date <= @s_mb_term_date
                            AND exp_date IS NULL;
                    
/*	else
 * 	select rlplfc_id
 * 	into d_rlplfc_id
 * 	from rlplfc
 * 	where mb_gr_pl_id = d_mb_gr_pl_id
 * 	and member_id = s_dls_mb_id
 * 	and facility_id is null
 * 	and eff_date <= s_mb_term_date
 * 	and exp_date is null;
 * end if
 */
                    IF @d_rlplfc_id IS NULL
					BEGIN
					SET @error_no=616
                        RAISERROR('Missing RLPLFC record (MT)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    SET @n_msi = @n_msi + 1;
                   
                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=725
                        RAISERROR('MSI number exceeds maximum allocated number (MT)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    UPDATE  dbo.rlplfc
                    SET     exp_date = (@t_action_date) ,
                            action_code = 'MT' ,
                            h_action = action_code ,
                            h_user = @ls_user ,
                            h_datetime = @ls_datetime
  WHERE   rlplfc_id = @d_rlplfc_id;
             IF EXISTS ( SELECT  *
                    FROM    dbo.rlplfc  (NOLOCK)
           WHERE   rlplfc_id = @d_rlplfc_id
               AND exp_date IS NULL )
										BEGIN
										SET @error_no=617
                        RAISERROR('Error in RLPLFC termination (MT)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2',
                        @s_dls_sub_id,@created_by;
                END;

            
            IF @s_dls_act_code = 'RC'
-- TERM OLD AND ADD NEW RLMBRT MODULE:
                BEGIN
                    
                    IF @s_member_flag <> '00'
					BEGIN
					SET @error_no=451
                        RAISERROR('Dependent with RC',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    IF ( (@t_action_date) < @d_eff_gr_pl )
					BEGIN
					SET @error_no=453
                        RAISERROR('RC before subscriber''s group/plan eff_gr_pl',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    IF ( @d_exp_gr_pl IS NOT NULL )
                        BEGIN
                          
                            IF ( (@t_action_date) >= @d_exp_gr_pl )
							BEGIN
							SET @error_no=454
                                RAISERROR('RC after subscriber''s group/plan expired',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                        END;
	
                    SET @d_rlmbrt_id = NULL;
                    SET @d_curr_rate_code = NULL;
                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT rlmbrt_id, rate_code, eff_rt_date
		
         FROM dbo.rlmbrt  (NOLOCK)
         WHERE mb_gr_pl_id = @d_mb_gr_pl_id
		--and rate_code <> s_rate_code
         AND eff_rt_date <= @t_action_date
         AND (exp_rt_date > @t_action_date OR exp_rt_date IS NULL)
         ORDER BY 2 DESC;
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @d_rlmbrt_id,
                        @d_curr_rate_code, @d_mbrt_eff_date;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label13;
                            FETCH NEXT FROM @SWV_cursor_var2 INTO @d_rlmbrt_id,
                                @d_curr_rate_code, @d_mbrt_eff_date;
                        END;
                    SWL_Label13:
                    CLOSE @SWV_cursor_var2;
                    IF @d_rlmbrt_id IS NULL
					BEGIN
					SET @error_no=627
                        RAISERROR('Missing RLMBRT PRIOR RATE CODE record (RC)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    IF (@t_action_date) < @d_mbrt_eff_date
                        BEGIN
                            SET @t_action_date = CONVERT(Date, @d_mbrt_eff_date);
							UPDATE GlobalVar SET VarValue = @t_action_date where VarName = 't_action_date' and  BatchId = @a_batch_id AND Module_Id = 2
                        END;
	
                 SET @dummy_act_code = NULL;
                    IF ( ( SELECT   rate_num_depend
                           FROM     dbo.pl_rat  (NOLOCK)
                           WHERE    rate_code = @s_rate_code
                         ) - ( SELECT   rate_num_depend
           FROM     dbo.pl_rat  (NOLOCK)
                               WHERE    rate_code = @d_curr_rate_code
   ) ) >= 0
                        SET @dummy_act_code = 'DA';
      ELSE
      SET @dummy_act_code = 'MT';
	
                    
                    SET @n_msi = @n_msi + 1;
               
                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=728
                        RAISERROR('MSI number exceeds maximum allocated number (RC)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    UPDATE  dbo.rlmbrt
                    SET     exp_rt_date = (@t_action_date) ,
action_code = @dummy_act_code ,
                       h_msi = @n_msi ,
                            h_action = 'RC' ,
                            h_user = @ls_user ,
                  h_datetime = @ls_datetime
             WHERE   rlmbrt_id = @d_rlmbrt_id;
                    
                    SET @n_msi = @n_msi + 1;

					UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2

                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=729
                        RAISERROR('MSI number exceeds maximum allocated number (RC)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    INSERT  INTO dbo.rlmbrt
                            ( mb_gr_pl_id ,
                              rate_code ,
                              eff_rt_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
          )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @s_rate_code ,
                              (@t_action_date) ,
                              @dummy_act_code ,
                              @dummy_act_code ,
                              @n_msi ,
                              @ls_datetime ,
                              @ls_user
                            );
	
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rlmbrt  (NOLOCK)
                                    WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                            AND rate_code = @s_rate_code )
											BEGIN
											SET @error_no=628
                        RAISERROR('Error in RLMBRT creation (RC)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                END;

            
            IF @s_dls_act_code = 'GA'
-- ADD INTO GROUP MODULE:
                BEGIN
                    EXECUTE dlp_up_add_sg @a_batch_id,@i_new_sg_id OUTPUT, @s_sg_err OUTPUT

                    IF @i_new_sg_id < 0
					BEGIN
					SET @error_no=505
                        RAISERROR('Failed to add Single Group',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
					END
                    ELSE
                        IF @i_new_sg_id = 0
						BEGIN
						SET @error_no=506
                            RAISERROR('Single Group record already existed',0,1);
							EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
						END
                    SET @s_dls_group_id = @i_new_sg_id;

                    UPDATE GlobalVar SET VarValue = @s_dls_group_id where VarName = 's_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
-- ADD INTO ACH MICRO MODULE:
--	if s_bill_type = "AH" then 
                   
                    EXECUTE  @n_error_no = dbo.dlp_up_add_micr @a_batch_id,
      @t_sir_id,
                       @s_dls_group_id,
                                                              'BI';
                    IF ( @n_error_no < 0 )
					BEGIN
					SET @error_no=515
				   RAISERROR('Error in MICR creation (SA)',0,1);
				   EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
					END
		
--	end if
-- UPDATE SIR BATCH INFO AND SEE IF NEED TO LOAD PRODUCER COMMISSION
                    UPDATE  dbo.dls_sg_member
                    SET     dls_group_id = @s_dls_group_id
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @s_dls_sir_id;

							update dls_sg_member 
							set dls_group_id = @s_dls_group_id
							where dls_batch_id = @a_batch_id 
							and dls_sub_sir_id = @s_dls_sir_id;
                                
                    IF @s_dls_pd_id IS NOT NULL
                        AND ( @s_pdcomm_eff IS NOT NULL
                              AND @s_pdcomm_eff <> ''
                            )
                        BEGIN
                   
                            SET @d_pdcomm_eff = CAST(@s_pdcomm_eff AS DATE);
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.group_pdcomm  (NOLOCK)
                                            WHERE   group_id = @s_dls_group_id
             AND plan_id = @s_dls_plan_id
                        AND prod_id = @s_dls_pd_id )
                                BEGIN
                                    EXECUTE @n_fatal = dbo.dlp_up_sg_pdcomm @a_batch_id,
                                        @d_pdcomm_eff;
                                    IF @n_fatal < 0
									BEGIN
									SET @error_no=521
                                        RAISERROR('Error in Single Group PDCOMM Update (SA)',0,1);
										EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
									END
                                END;
                            ELSE
							BEGIN
							SET @error_no=522
                                RAISERROR('Existing Group Producer Commission record for new SG ID (SA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
								END
                        END;
                END;

            
            IF @s_dls_act_code = 'SA'
-- ADD INTO GROUP MODULE:
                BEGIN
				EXECUTE dlp_up_add_sg @a_batch_id,@i_new_sg_id OUTPUT, @s_sg_err OUTPUT
                    IF @i_new_sg_id < 0
					BEGIN
					SET @error_no=505
                        RAISERROR('Failed to add Single Group',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                    ELSE
                        IF @i_new_sg_id = 0
						BEGIN
						SET @error_no=506
                            RAISERROR('Single Group record already existed',0,1);
							EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                    SET @s_dls_group_id = @i_new_sg_id;
                   UPDATE GlobalVar SET VarValue = @s_dls_group_id where VarName = 's_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
-- ADD INTO ACH MICRO MODULE:
--	if s_bill_type = "AH" then 
                
                    EXECUTE  @n_error_no = dbo.dlp_up_add_micr @a_batch_id,
                      @t_sir_id,
               @s_dls_group_id,
                'BI';
                    IF ( @n_error_no < 0 )
					BEGIN
					SET @error_no=515
                  RAISERROR('Error in MICR creation (SA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
--	end if
-- ADD INTO MEMBER MODULE:
			 EXECUTE dbo.dlp_sg_add_member @a_batch_id, @t_sir_id, 'Y',
                        @ls_user, @t_member_id OUTPUT, @n_msi OUTPUT,
                        @ls_datetime OUTPUT;
			  
                    IF @t_member_id IS NULL
                        OR @t_member_id = 0
						BEGIN
						SET @error_no=515
                        RAISERROR('Error in MEMBER creation (SA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                    ELSE
                        IF @t_member_id < 0 /* t_member_id has error message */
                            BEGIN
                                SET @t_member_id = @t_member_id * -1;
								BEGIN
								SET @error_no=@t_member_id
                                RAISERROR('Error in MEMBER creation (SA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                            END;
		
	
                    SET @s_dls_sub_id = @t_member_id;
                    					
                    SET @s_dls_mb_id = @t_member_id;

                    UPDATE GlobalVar SET VarValue = @s_dls_sub_id where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
					UPDATE GlobalVar SET VarValue = @s_dls_mb_id where VarName = 's_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2

					
					
-- ADD INTO GP PL RT FC MODULE:
	--msi from member add
	/*
	LET n_msi = n_msi + 1;
	if n_msi > msi_upper then
		RAISE EXCEPTION -746, 510, "msi number exceeded the maximum located number";
	end if
	*/
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rlmbgrpl
                                    WHERE   member_id = @s_dls_sub_id
                                            AND group_id = @s_dls_group_id
								AND plan_id = @s_dls_plan_id )

								begin 

														
                        INSERT  INTO dbo.rlmbgrpl
                                ( member_id ,
      group_id ,
                                  plan_id ,
                                 sub_in_plan ,
                                  eff_gr_pl ,
                                  action_code ,
         h_action ,
                                  h_msi ,
                                  h_datetime ,
								 h_user
                                )
                        VALUES  ( @s_dls_sub_id ,
                                  @s_dls_group_id ,
                                  @s_dls_plan_id ,
                                  @s_sub_in_plan ,
                                  @t_action_date ,
                                  'SA' ,
                                  'SA' ,
                                  @n_msi ,
                                  @ls_datetime ,
                                  @ls_user
                                );
	end
                    SELECT @d_mb_gr_pl_id = mb_gr_pl_id
                    FROM    dbo.rlmbgrpl  (NOLOCK)
                    WHERE   member_id = @s_dls_sub_id
                            AND group_id = @s_dls_group_id
                            AND plan_id = @s_dls_plan_id
                            AND h_msi = @n_msi;
                   
                    IF @d_mb_gr_pl_id IS NULL
					BEGIN
					SET @error_no=518
                       RAISERROR('Error in RLMBGRPL creation (SA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    INSERT  INTO dbo.rlmbrt
       ( mb_gr_pl_id ,
                          rate_code ,
                              eff_rt_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
          @s_rate_code ,
                              (@t_action_date) ,
                              'SA' ,
                              'SA' ,
                              @n_msi ,
                              @ls_datetime ,
                              @ls_user
                            );
	
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rlmbrt  (NOLOCK)
                                    WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                            AND rate_code = @s_rate_code )
											BEGIN
											SET @error_no=519
                        RAISERROR('Error in RLMBRT creation (SA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    SET @d_plfc_eff_date = @s_mb_fc_eff_date;
                    
                    IF @d_plfc_eff_date < (@t_action_date)
                        BEGIN
                            
                            SET @d_plfc_eff_date = (@t_action_date);
                        END;
					
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @s_dls_mb_id ,
                              @s_dls_fc_id ,
                              @d_plfc_eff_date ,
                              'SA' ,
                              'SA' ,
                              @n_msi ,
     @ls_datetime ,
     @ls_user
                            );
	
        IF NOT EXISTS ( SELECT  *
               FROM    dbo.rlplfc (NOLOCK)
            WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
     AND member_id = @s_dls_mb_id
      AND h_msi = @n_msi )
											BEGIN
											SET @error_no=520
                        RAISERROR('Error in RLPLFC creation (SA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                   
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'admenu_1',
                        @s_dls_sub_id,@created_by;
						
						SELECT @s_dls_group_id=VarValue from dbo.GlobalVar where VarName = 's_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
-- UPDATE SIR BATCH INFO AND SEE IF NEED TO LOAD PRODUCER COMMISSION

                    UPDATE  dbo.dls_sg_member
                    SET     dls_member_id = @s_dls_mb_id ,
                            dls_subscriber_id = @s_dls_sub_id ,
                            dls_group_id = @s_dls_group_id
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @s_dls_sir_id;

               update dls_sg_member 
			set dls_subscriber_id = @s_dls_sub_id,
				dls_group_id = @s_dls_group_id
			where dls_batch_id = @a_batch_id 
			and dls_sub_sir_id = @s_dls_sir_id;
    
                    IF @s_dls_pd_id IS NOT NULL
        AND ( @s_pdcomm_eff IS NOT NULL
             AND @s_pdcomm_eff <> ''
      )
                        BEGIN

                           SET @d_pdcomm_eff = CAST(@s_pdcomm_eff AS DATE);
                            IF NOT EXISTS ( SELECT  *
                  FROM   dbo.group_pdcomm  (NOLOCK)
                                            WHERE   group_id = @s_dls_group_id
                                                    AND plan_id = @s_dls_plan_id
                                                    AND prod_id = @s_dls_pd_id )
                                BEGIN
                                    EXECUTE @n_fatal = dbo.dlp_up_sg_pdcomm @a_batch_id,
                                        @d_pdcomm_eff;
                                    IF @n_fatal < 0
									BEGIN
									SET @error_no=521
                                        RAISERROR('Error in Single Group PDCOMM Update (SA)',0,1);
										EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                                END;
                            ELSE
							BEGIN
							SET @error_no=522
                                RAISERROR('Existing Group Producer Commission record for new SG ID (SA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                        END;
                END;

            
            IF @s_dls_act_code = 'DA'
                BEGIN
                    
                    SET @d_date_of_birth = CAST(@s_date_of_birth AS DATE);
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.member (NOLOCK)
                                    WHERE   member_id = @s_dls_sub_id )
									BEGIN
									SET @error_no=523
                        RAISERROR('Subscriber ID is missing in DDS (DA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
/*	20131018$$ks - removed test because member existing can happen if 
 *	adding dependent to 2 plans in the same batch
 * dlp_sg_add_member has code to find existing dependent and return member_id as if
 * dependent was entered
 *
 * elif exists ( select * from member where family_id = s_dls_sub_id
 * and member_ssn = s_ssn and last_name = s_last_name and first_name = 
 * s_first_name and member_code not in ("10", "20") and ((date_of_birth = 
 * d_date_of_birth and d_date_of_birth != "01/01/1900" and 
 * date_of_birth != "01/01/1900") or (d_date_of_birth = "01/01/1900" or 
 * date_of_birth = "01/01/1900")) ) then
 *		RAISE EXCEPTION -746, 524, "Dependent already exists in system (DA)";
 */
	
-- ADD INTO MEMBER MODULE:
                   
                    EXECUTE dbo.dlp_sg_add_member @a_batch_id, @t_sir_id, 'Y',
                        @ls_user, @t_member_id OUTPUT, @n_msi OUTPUT,
                        @ls_datetime OUTPUT;
              IF @t_member_id IS NULL
                        OR @t_member_id <= 0
						BEGIN
						SET @error_no=515
    RAISERROR('Error in MEMBER creation (SA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    SET @s_dls_mb_id = @t_member_id;
                     UPDATE GlobalVar SET VarValue = @s_dls_mb_id  where VarName = 's_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2
-- ADD INTO RLPLFC MODULE:

                   SET @SWV_cursor_var3 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
		
        FROM dbo.rlmbgrpl  (NOLOCK)
         WHERE member_id = @s_dls_sub_id
         AND group_id = @s_dls_group_id
         AND plan_id = @s_dls_plan_id
  AND (eff_gr_pl <= @t_action_date
         AND (exp_gr_pl <= @t_action_date OR exp_gr_pl IS NULL))
         ORDER BY 2 DESC,3;
                    OPEN @SWV_cursor_var3;
    FETCH NEXT FROM @SWV_cursor_var3 INTO @d_mb_gr_pl_id,
                        @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label14;
                            FETCH NEXT FROM @SWV_cursor_var3 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                        END;
                    SWL_Label14:
                    CLOSE @SWV_cursor_var3;
                    IF @d_mb_gr_pl_id IS NULL
					BEGIN
					SET @error_no=526
                        RAISERROR('Missing RLMBGRPL record (DA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
         
                    SET @d_plfc_eff_date = @s_mb_fc_eff_date;
                   
                    IF @d_plfc_eff_date < (@t_action_date)
                        BEGIN
                            
                            SET @d_plfc_eff_date = (@t_action_date);
                        END;

					
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
							eff_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @s_dls_mb_id ,
                              @s_dls_fc_id ,
                              @d_plfc_eff_date ,
                              'DA' ,
                              'DA' ,
                              @n_msi ,
                              @ls_datetime ,
                              @ls_user
                            );
	
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rlplfc (NOLOCK)
                                    WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                            AND member_id = @s_dls_mb_id
                                            AND h_msi = @n_msi )
											BEGIN
											SET @error_no=527
                        RAISERROR('Error in RLPLFC creation (DA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                 
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'admenu_2',
                        @s_dls_sub_id,@created_by;
-- UPDATE SIR BATCH INFO
                    UPDATE  dbo.dls_sg_member
                    SET     dls_member_id = @s_dls_mb_id ,
                            dls_subscriber_id = @s_dls_sub_id
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @s_dls_sir_id;
                END;

            
            IF @s_dls_act_code = 'PA'
-- ADD INTO GP PL RT FC MODULE:
                BEGIN
                    
                    IF @s_member_flag = '00'
                        BEGIN

						IF EXISTS ( SELECT  *
                                        FROM    dbo.rlmbgrpl (NOLOCK)
        WHERE  member_id = @s_dls_sub_id
                                AND group_id = @s_dls_group_id
                                                AND plan_id = @s_dls_plan_id
 AND ( eff_gr_pl <= (@t_action_date)
             AND ( exp_gr_pl > (@t_action_date)
                                                            OR exp_gr_pl IS NULL
                      )
                            ) )
													BEGIN
													SET @error_no=640
                                RAISERROR('Incoming Plan already exists in RLMBGRPL (PA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
							END
		
                            
                            SET @SWV_func_DLP_REIN_SG_GROUP_par0 = (@t_action_date);
                            EXECUTE dbo.dlp_rein_sg_group @SWV_func_DLP_REIN_SG_GROUP_par0,
                                @s_dls_group_id, @ls_user, @ls_datetime,
                                @n_error_no OUTPUT, @s_sg_err OUTPUT;
                            IF @n_error_no < 0
							BEGIN
							SET @error_no=900
                                RAISERROR('New error here - could not reopen group for SG ',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
							END
		
                            
                            SET @n_msi = @n_msi + 1;

                           UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2

                            IF @n_msi > @msi_upper
							BEGIN
							SET @error_no=726
                                RAISERROR('MSI number exceeds maximum allocated number (PA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            
                            SET @SWV_func_DLP_ADD_SG_PLAN_par0 = (@t_action_date);
                            EXECUTE dbo.dlp_add_sg_plan @SWV_func_DLP_ADD_SG_PLAN_par0,
                                @s_dls_plan_id, @s_dls_msg_id, @s_dls_group_id,
                                @ls_user, @ls_datetime, @i_rel_gppl_id OUTPUT,
                                @s_sg_err OUTPUT;
                            IF ( @i_rel_gppl_id < 1 )
							BEGIN
							SET @error_no=900
                                RAISERROR('Unable to add Plan to SG',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
						END
		

						
                            INSERT  INTO dbo.rlmbgrpl
                                    ( member_id ,
                                      group_id ,
                                      plan_id ,
									sub_in_plan ,
                                      eff_gr_pl ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @s_dls_sub_id ,
                                      @s_dls_group_id ,
                                      @s_dls_plan_id ,
                                      @s_sub_in_plan ,
                                      @t_action_date ,
                                      'PA' ,
                                      'PA' ,
                                      @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                                    );
		
                            SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl  (NOLOCK)
                            WHERE   h_msi = @n_msi;
                            
                            IF @d_mb_gr_pl_id IS NULL
							BEGIN
							SET @error_no=618
                                RAISERROR('Error in RLMBGRPL creation (PA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
INSERT  INTO dbo.rlmbrt
                                    ( mb_gr_pl_id ,
                          rate_code ,
                           eff_rt_date ,
action_code ,
       h_action ,
                                      h_msi ,
                                      h_datetime ,
              h_user
              )
         VALUES  ( @d_mb_gr_pl_id ,
  @s_rate_code ,
                                      (@t_action_date) ,
                                      'PA' ,
                                      'PA' ,
                  @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                                    );
		
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.rlmbrt  (NOLOCK)
                                            WHERE   h_msi = @n_msi )
											BEGIN
											SET @error_no=619
                                RAISERROR('Error in RLMBRT creation (PA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            
                            SET @d_plfc_eff_date = @s_mb_fc_eff_date;
                           
                            IF @d_plfc_eff_date < (@t_action_date)
                                BEGIN
                                    
                                    SET @d_plfc_eff_date = (@t_action_date);
                                END;
		
		
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @s_dls_mb_id ,
                                      @s_dls_fc_id ,
                           @d_plfc_eff_date ,
                                      'PA' ,
                                      'SA' ,
                                      @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                                    );
		
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.rlplfc  (NOLOCK)
                                            WHERE   h_msi = @n_msi )
											 BEGIN
											 SET @error_no=620
                                RAISERROR('Error in RLPLFC creation (PA)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                           
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_2',
                                @s_dls_mb_id,@created_by;
                        END;
                    ELSE -- dependent only
                        BEGIN
                            IF NOT EXISTS ( SELECT  *
                                 FROM    dbo.member  (NOLOCK)
                                            WHERE   member_id = @s_dls_mb_id )
											BEGIN
											SET @error_no=461
                                RAISERROR('PA with no existing member record',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
							END
		
                            SET @d_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var4 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
			
            FROM dbo.rlmbgrpl  (NOLOCK)
            WHERE member_id = @s_dls_sub_id AND
            group_id = @s_dls_group_id AND
            plan_id = @s_dls_plan_id AND
				(eff_gr_pl <= @t_action_date AND
				(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
            ORDER BY 2 DESC,3;
                            OPEN @SWV_cursor_var4;
                            FETCH NEXT FROM @SWV_cursor_var4 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
GOTO SWL_Label15;
                      FETCH NEXT FROM @SWV_cursor_var4 INTO @d_mb_gr_pl_id,
                                        @d_eff_gr_pl, @d_exp_gr_pl;
                                END;
                            SWL_Label15:
                            CLOSE @SWV_cursor_var4;
                            IF ( @d_mb_gr_pl_id IS NULL )
							BEGIN
							SET @error_no=466
                                RAISERROR('Dependent PA with no active subscriber''s group/plan',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            
                            SET @d_plfc_eff_date = @s_mb_fc_eff_date;
                           
                            IF @d_plfc_eff_date < (@t_action_date)
                                BEGIN
                                    
                                    SET @d_plfc_eff_date = (@t_action_date);
                                END;
		
                            IF EXISTS ( SELECT  *
                                        FROM    dbo.rlplfc  (NOLOCK)
                                        WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                      AND member_id = @s_dls_mb_id
                                                AND ( ( eff_date <= (@t_action_date)
                                                        AND ( exp_date > (@t_action_date)
                     OR exp_date IS NULL
                                                            )
                                                      )
                                                      OR ( eff_date > (@t_action_date)
                                                           AND ( exp_date > eff_date
                                                              OR exp_date IS NULL
                                                              )
                                                         )
                                       ) )
													BEGIN
													SET @error_no=468
                                RAISERROR('Dependent PA with active facility',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            
                            SET @n_msi = @n_msi + 1;
                            
							UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2

                            IF @n_msi > @msi_upper
							BEGIN
							SET @error_no=510
                                RAISERROR('msi number exceeded the maximum located number',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            INSERT  INTO dbo.rlplfc
                                ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                    eff_date ,
     action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                           h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @s_dls_mb_id ,
                                      @s_dls_fc_id ,
                                      @d_plfc_eff_date ,
                                      @s_dls_act_code ,
                                      @s_dls_act_code ,
                                      @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                                    );
		
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2',
            @s_dls_mb_id,@created_by;
                        END;
                END;

          
            IF @s_dls_act_code = 'GR'
                BEGIN
                   
     IF @s_member_flag = '00'
		--REINSTATE EXITING SINGLE GROUP 
                 BEGIN
                           
 SET @SWV_func_DLP_REIN_SG_GROUP_par1 = (@t_action_date);
     EXECUTE dbo.dlp_rein_sg_group @SWV_func_DLP_REIN_SG_GROUP_par1,
                                @s_dls_group_id, @ls_user, @ls_datetime,
                                @n_error_no OUTPUT, @s_sg_err OUTPUT;
							IF @n_error_no < 0
							BEGIN
							SET @error_no=900
                                RAISERROR('New error here - could not reopen group for SG ',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
							END
                        END;
                END;

	----------------------------------------------------------------------
	
            
   IF @s_dls_act_code = 'RI'
                BEGIN
                    
                    IF @s_member_flag = '00'
	--REINSTATE A SUBSCRIBER WOULD REINSTATE THE SINGLE GROUP AS WELL
	-- ADD INTO GP PL RT FC MODULE:
                        BEGIN
                            SELECT  @d_mb_gr_pl_id = MAX(mb_gr_pl_id)
                            FROM    dbo.rlmbgrpl  (NOLOCK)
                            WHERE   member_id = @s_dls_sub_id
                                    AND group_id = @s_dls_group_id
                                    AND plan_id = @s_dls_plan_id;
                            
                            SELECT  @d_eff_gr_pl = eff_gr_pl ,
                                    @d_exp_gr_pl = exp_gr_pl
                            FROM    dbo.rlmbgrpl  (NOLOCK)
                WHERE   mb_gr_pl_id = @d_mb_gr_pl_id;
                           
                            IF @d_mb_gr_pl_id IS NULL
							BEGIN
							SET @error_no=629
                                RAISERROR('Existing RLMBGRPL record not found (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                            ELSE
                                IF @d_exp_gr_pl IS NULL
								BEGIN
								SET @error_no=630
                                    RAISERROR('Existing RLMBGRPL record is still active (RI)',0,1);
									EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                            
                IF (@t_action_date) < @d_exp_gr_pl
                                BEGIN
    SET @t_action_date = CONVERT(Date, @d_exp_gr_pl);
                                  
                                END;
		
  
                            SET @n_msi = @n_msi + 1;
      
						   UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2

                            IF @n_msi > @msi_upper
							BEGIN
							SET @error_no=730
                                RAISERROR('MSI number exceeds maximum allocated number (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		 
		--Update SG status to A4
                           
                            SET @SWV_func_DLP_REIN_SG_GROUP_par2 = (@t_action_date);
                            EXECUTE dbo.dlp_rein_sg_group @SWV_func_DLP_REIN_SG_GROUP_par2,
                                @s_dls_group_id, @ls_user, @ls_datetime,
                                @n_error_no OUTPUT, @s_sg_err OUTPUT;
                            IF @n_error_no < 0
							BEGIN
							SET @error_no=900
                                RAISERROR('New error here - could not reopen group for SG ',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
		----------------------------------------------------------------------
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @s_dls_sub_id
                                                    AND group_id = @s_dls_group_id
                                                    AND plan_id = @s_dls_plan_id
                                                    AND eff_gr_pl <= (@t_action_date)
                                                    AND ( exp_gr_pl IS NULL
       OR (@t_action_date) < exp_gr_pl
                                                        ) )
     INSERT  INTO dbo.rlmbgrpl
                                        ( member_id ,
                                          group_id ,
                 plan_id ,
     sub_in_plan ,
                    eff_gr_pl ,
                                          action_code ,
                                          h_action ,
                                          h_msi ,
                                          h_datetime ,
                                          h_user
           )
                                VALUES  ( @s_dls_sub_id ,
                                          @s_dls_group_id ,
                                          @s_dls_plan_id ,
                                          @s_sub_in_plan ,
                            (@t_action_date) ,
                                          'RI' ,
                                          'RI' ,
                                          @n_msi ,
                                          @ls_datetime ,
                                          @ls_user
              );
		
                            ELSE
							BEGIN
							SET @error_no=448
                                RAISERROR('RI with active subscriber''s group/plan',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl (NOLOCK)
                            WHERE   h_msi = @n_msi;
              
                       IF @d_mb_gr_pl_id IS NULL
							BEGIN
							SET @error_no=631
                                RAISERROR('Error in RLMBGRPL creation (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            INSERT  INTO dbo.rlmbrt
                                    ( mb_gr_pl_id ,
       rate_code ,
                               eff_rt_date ,
                             action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                                     h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @s_rate_code ,
                                      (@t_action_date) ,
                                      'RI' ,
                                      'RI' ,
                                      @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                                    );
		
                            IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.rlmbrt  (NOLOCK)
                                            WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                                    AND rate_code = @s_rate_code )
													BEGIN
													SET @error_no=632
                                RAISERROR('Error in RLMBRT creation (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                           
                            SET @d_plfc_eff_date = @s_mb_fc_eff_date;
                           
                            IF @d_plfc_eff_date < (@t_action_date)
                                BEGIN
                                 
                                    SET @d_plfc_eff_date = (@t_action_date);
                                END;
		
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
          h_datetime ,
                                      h_user
                                    )
VALUES  ( @d_mb_gr_pl_id ,
  @s_dls_mb_id ,
                                      @s_dls_fc_id ,
                @d_plfc_eff_date ,
          'RI' ,
                             'RI' ,
                                      @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                                    );
		
                            SET @d_rlplfc_id = NULL;
                            SELECT  @d_rlplfc_id = rlplfc_id
                            FROM    dbo.rlplfc  (NOLOCK)
                            WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @s_dls_mb_id
                                    AND h_msi = @n_msi;
                           
          IF ( @d_rlplfc_id IS NULL )
		  BEGIN
		  SET @error_no=633
                                RAISERROR('Error in RLPLFC creation (SUB RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                           
                            EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id,
                                @s_dls_mb_id, 'N', @n_error_no OUTPUT,
                                @n_error_text OUTPUT;
                            IF ( @n_error_no < 0 )
							BEGIN
							SET @error_no=999
    RAISERROR('new error message here',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
							END
		
EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id,
                 @d_rlplfc_id, 'Y', @n_error_no OUTPUT,
                                @n_error_text OUTPUT;
                            IF ( @n_error_no < 0 )
							BEGIN
							SET @error_no=999
                                RAISERROR('new error message here',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_6',
                                @s_dls_sub_id,@created_by;
                        END;
                    ELSE   -- s_member_flag <> "00"
		-- ADD INTO RLPLFC MODULE:
                        BEGIN
                            SET @d_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var5 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl, h_msi
		 
            FROM dbo.rlmbgrpl  (NOLOCK)
            WHERE member_id = @s_dls_sub_id
            AND group_id = @s_dls_group_id
            AND plan_id = @s_dls_plan_id
            AND (eff_gr_pl <= @t_action_date
            AND (exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
            ORDER BY 2 DESC,3;
                            OPEN @SWV_cursor_var5;
                            FETCH NEXT FROM @SWV_cursor_var5 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl, @n_dep_msi;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    GOTO SWL_Label16;
                                    FETCH NEXT FROM @SWV_cursor_var5 INTO @d_mb_gr_pl_id,
                                        @d_eff_gr_pl, @d_exp_gr_pl, @n_dep_msi;
          END;
                            SWL_Label16:
                            CLOSE @SWV_cursor_var5;
                            IF @d_mb_gr_pl_id IS NULL
							BEGIN
							SET @error_no=634
                                RAISERROR('Existing RLMBGRPL record not found (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
   
                            IF (@t_action_date) < @d_eff_gr_pl
                                BEGIN
                                    SET @t_action_date = CONVERT(Date, @d_eff_gr_pl);
                                  
                                END;
		
                          
                            IF @d_exp_gr_pl IS NOT NULL
                    AND (@t_action_date) < @d_exp_gr_pl
                                BEGIN
                                    SET @t_action_date = CONVERT(Date, @d_exp_gr_pl);
  
                                END;
		
                      SET @d_rlplfc_id = NULL;
	
/* 20131120$$ks - in a family reinstate the rlplfc record would not exist.
 *  as long as there dep does not have an active record for the new group-plan,
 * just add new record
 * 	if (s_dls_fc_id is null or s_dls_fc_id = 0) then 
 * 		select max(rlplfc_id) into d_rlplfc_id
 * 		  from rlplfc where mb_gr_pl_id = d_mb_gr_pl_id
 * 			and member_id = s_dls_mb_id and facility_id is null;
 * 	else
 * 		select max(rlplfc_id) into d_rlplfc_id from rlplfc
 * 		 where mb_gr_pl_id = d_mb_gr_pl_id and member_id = s_dls_mb_id
 * 			and facility_id = s_dls_fc_id;
 * 	end if
 *  Copied logic below from DL/EG reinstate dep
 */

          IF EXISTS ( SELECT  *
                                        FROM    dbo.rlplfc  (NOLOCK)
                                        WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                          AND member_id = @s_dls_mb_id
                                                AND ( ( eff_date <= (@t_action_date)
                AND ( exp_date > (@t_action_date)
                                           OR exp_date IS NULL
                                                            )
                                              )
                                                      OR ( eff_date > (@t_action_date)
                                 AND ( exp_date > eff_date
                                                              OR exp_date IS NULL
                                                              )
                                                         )
                                                    ) )
													BEGIN
													SET @error_no=635
                                RAISERROR('Need New Error - Existing RLPLFC record found (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		

/* 20131121$$ks - existing record will not be found for Family reinstate!
 * 	* select max(rlplfc_id) into d_rlplfc_id
 * 	*   from rlplfc
 * 	*   where mb_gr_pl_id = d_mb_gr_pl_id
 * 	* 	 and member_id = s_dls_mb_id;
 * 	* if d_rlplfc_id is null then
 * 	* --	RAISE EXCEPTION -746, 635, "Existing RLPLFC record not found (RI)";
 * 	* else
 * 	* 	let d_plfc_eff_date = null;
 * 	* 	let d_plfc_exp_date = null;
 * 	* 	select eff_date, exp_date into d_plfc_eff_date, d_plfc_exp_date
 * 	* 	  from rlplfc
 * 	* 	 where rlplfc_id = d_rlplfc_id;
 * 	* 	if t_action_date < d_plfc_eff_date then
 * 	* 		let t_action_date = d_plfc_eff_date;
 * 	* 	end if
 * 	* 	if d_plfc_exp_date is null then
 * 	* 		RAISE EXCEPTION -746, 636, "Existing RLPLFC record is still active (RI)";
 * 	* 	elif t_action_date < d_plfc_exp_date then
 * 	* 		let t_action_date = d_plfc_exp_date;
 * 	* 	end if
 * 	* end if
 * 	* let d_plfc_eff_date = s_mb_fc_eff_date; 
 * 	* if d_plfc_eff_date < t_action_date then 
 * 		let d_plfc_eff_date = t_action_date; 
 *		 end if 
 * /
/ * 20131120$$ks - for reinstate of family need to use sub's msi number
 */
	--let n_msi = n_msi + 1; 
                        
                            IF @n_msi > @msi_upper
							BEGIN
							SET @error_no=731
                                RAISERROR('MSI number exceeds maximum allocated number (RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
             INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
 h_msi ,
                                      h_datetime ,
                                h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                    @s_dls_mb_id ,
                          @s_dls_fc_id ,
          @d_plfc_eff_date ,
             'RI' ,
                                      'RI' ,
                        @n_dep_msi ,
                                      @ls_datetime ,
                              @ls_user
                                    );
		
                            SET @d_rlplfc_id = NULL;
                            SELECT  @d_rlplfc_id = rlplfc_id
             FROM    dbo.rlplfc (NOLOCK)
                            WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                    AND member_id = @s_dls_mb_id
                                   AND h_msi = @n_dep_msi;

                            IF ( @d_rlplfc_id IS NULL )
							BEGIN
							SET @error_no=637
                                RAISERROR('Error in RLPLFC creation (DEP RI)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
             
                            EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id,
                            @s_dls_mb_id, 'N', @n_error_no OUTPUT,
                                @n_error_text OUTPUT;
                            IF ( @n_error_no < 0 )
							BEGIN
							SET @error_no=999
                                RAISERROR('new error message here',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id,
                                @d_rlplfc_id, 'Y', @n_error_no OUTPUT,
                                @n_error_text OUTPUT;
                            IF ( @n_error_no < 0 )
							BEGIN
							SET @error_no=999
                                RAISERROR('new error message here',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2',
                                @s_dls_mb_id,@created_by;
                        END;
                END;

            
            IF @s_dls_act_code = 'DR' -- reinstating dep to existing sub-group-plan
                BEGIN
                    SET @d_mb_gr_pl_id = NULL;
                    SET @SWV_cursor_var6 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
		
         FROM dbo.rlmbgrpl  (NOLOCK)
         WHERE member_id = @s_dls_sub_id AND
         group_id = @s_dls_group_id AND
         plan_id = @s_dls_plan_id AND
			(eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL))
         ORDER BY 2 DESC,3;
                    OPEN @SWV_cursor_var6;
                    FETCH NEXT FROM @SWV_cursor_var6 INTO @d_mb_gr_pl_id,
                        @d_eff_gr_pl, @d_exp_gr_pl;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label17;
                            FETCH NEXT FROM @SWV_cursor_var6 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl, @d_exp_gr_pl;
                        END;
                    SWL_Label17:
                    CLOSE @SWV_cursor_var6;
                    IF @d_mb_gr_pl_id IS NULL
					BEGIN
					SET @error_no=634
                        RAISERROR('Existing RLMBGRPL record not found (RI)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END	
                    
                    IF (@t_action_date) < @d_eff_gr_pl
                        BEGIN
                            SET @t_action_date = CONVERT(DATE, @d_eff_gr_pl);
                            
                        END;
	
                    SET @d_rlplfc_id = NULL;
                    IF EXISTS ( SELECT  *
                                FROM    dbo.rlplfc (NOLOCK)
                                WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                        AND member_id = @s_dls_mb_id
                                        AND ( ( eff_date <= (@t_action_date)
    AND ( exp_date > (@t_action_date)
 OR exp_date IS NULL
                                                    )
                                              )
                    OR ( eff_date > (@t_action_date)
                                                   AND ( exp_date > eff_date
                                                         OR exp_date IS NULL
                                               )
                            )
 ) )
											BEGIN
											SET @error_no=635
                        RAISERROR('Need New Error - Existing RLPLFC record found (RI)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                   
                    SET @n_msi = @n_msi + 1;
                   
                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=731
                        RAISERROR('MSI number exceeds maximum allocated number (RI)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    INSERT  INTO dbo.rlplfc
                            ( mb_gr_pl_id ,
       member_id ,
         facility_id ,
                              eff_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
      h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @s_dls_mb_id ,
                              @s_dls_fc_id ,
                              @d_plfc_eff_date ,
                   'DA' ,
                              'DA' ,
                              @n_msi ,
                              @ls_datetime ,
                              @ls_user
     );
	
                    SET @d_rlplfc_id = NULL;
                    SELECT  @d_rlplfc_id = rlplfc_id
                    FROM    dbo.rlplfc  (NOLOCK)
                    WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                            AND member_id = @s_dls_mb_id
                            AND h_msi = @n_msi;
     
                    IF ( @d_rlplfc_id IS NULL )
					BEGIN
					SET @error_no=637
                        RAISERROR('Error in RLPLFC creation (DEP RI)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    EXECUTE dbo.mb_add_cat_opt @d_mb_gr_pl_id, @s_dls_mb_id,
                        'N', @n_error_no OUTPUT, @n_error_text OUTPUT;
                    IF ( @n_error_no < 0 )
					BEGIN
					SET @error_no=999
                        RAISERROR('new error message here',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    EXECUTE dbo.tiered_benefit @d_mb_gr_pl_id, @d_rlplfc_id,
                        'Y', @n_error_no OUTPUT, @n_error_text OUTPUT;
                    IF ( @n_error_no < 0 )
					BEGIN
					SET @error_no=999
                        RAISERROR('new error message here',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                   
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'temenu_2',
                        @s_dls_mb_id,@created_by;
                END;

            
            IF @s_dls_act_code = 'FX'
-- TERM OLD AND ADD NEW RLPLFC MODULE:
	/*
	select mb_gr_pl_id 
	into d_mb_gr_pl_id 
	from rlmbgrpl 
	where member_id = s_dls_sub_id 
	and group_id = s_dls_group_id 
	and plan_id = s_dls_plan_id 
	and exp_gr_pl is null;
	*/
                BEGIN
                  SET @d_mb_gr_pl_id = NULL;
            SET @SWV_cursor_var7 = CURSOR  FOR SELECT eff_gr_pl, exp_gr_pl, mb_gr_pl_id
		
         FROM dbo.rlmbgrpl  (NOLOCK)
         WHERE member_id  = @s_dls_sub_id AND
         group_id = @s_dls_group_id AND
   plan_id = @s_dls_plan_id AND
    eff_gr_pl <= @t_action_date AND
			(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
         ORDER BY eff_gr_pl DESC;
                    OPEN @SWV_cursor_var7;
                    FETCH NEXT FROM @SWV_cursor_var7 INTO @d_eff_gr_pl,
              @d_exp_gr_pl, @d_mb_gr_pl_id;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            GOTO SWL_Label18;
                            FETCH NEXT FROM @SWV_cursor_var7 INTO @d_eff_gr_pl,
                                @d_exp_gr_pl, @d_mb_gr_pl_id;
                        END;
                    SWL_Label18:
                    CLOSE @SWV_cursor_var7;
                    IF @d_mb_gr_pl_id IS NULL
					BEGIN
					SET @error_no=610
                        RAISERROR('Missing RLMBGRPL record (FX)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    IF @d_exp_gr_pl IS NOT NULL
					BEGIN
					SET @error_no=603
                        RAISERROR('Subscriber already expired',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    SET @d_plfc_exp_date = NULL;
                   
                    SET @d_plfc_eff_date = (@t_action_date);
                    SET @r_facility_id = NULL;
                    SET @SWV_cursor_var8 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
	
         FROM dbo.rlplfc  (NOLOCK)
         WHERE mb_gr_pl_id = @d_mb_gr_pl_id
         AND member_id = @s_dls_mb_id
	--and facility_id <> s_dls_fc_id
        AND eff_date <= @d_plfc_eff_date
         AND (exp_date IS NULL OR @d_plfc_eff_date < exp_date)
         ORDER BY eff_date DESC;
                    OPEN @SWV_cursor_var8;
                    FETCH NEXT FROM @SWV_cursor_var8 INTO @d_rlplfc_id,
                        @r_facility_id, @tmp_plfc_eff_date, @d_plfc_exp_date;
             WHILE @@FETCH_STATUS = 0
                        BEGIN
              GOTO SWL_Label19;
                            FETCH NEXT FROM @SWV_cursor_var8 INTO @d_rlplfc_id,
                                @r_facility_id, @tmp_plfc_eff_date,
                                @d_plfc_exp_date;
                        END;
                    SWL_Label19:
                    CLOSE @SWV_cursor_var8;
                    IF @d_rlplfc_id IS NULL
					BEGIN
					SET @error_no=611
                        RAISERROR('Missing RLPLFC record (FX)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    IF ( @r_facility_id IS NULL )
					BEGIN
					SET @error_no=601
                        RAISERROR('Member doesn''t have active facility/plan',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    IF ( @r_facility_id = @s_dls_fc_id )
					BEGIN
					SET @error_no=602
                        RAISERROR('Member current facility_id is the same as the one needed to change to.',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    SET @n_msi = @n_msi + 1;

                  UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2

                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=723
                        RAISERROR('msi number exceeded the maximum allocated number(FX)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
        
                    IF @d_plfc_exp_date IS NULL
              UPDATE  dbo.rlplfc
                        SET     exp_date = @d_plfc_eff_date ,
      action_code = 'FU' ,
                                h_msi = @n_msi ,
                                h_action = action_code ,
                                h_user = @ls_user ,
                                h_datetime = @ls_datetime
                        WHERE   rlplfc_id = @d_rlplfc_id;
                    ELSE
                        IF @d_plfc_eff_date < @d_plfc_exp_date
                            SET @d_plfc_eff_date = @d_plfc_exp_date;
                    
                    SET @n_msi = @n_msi + 1;
                    
                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=732
                        RAISERROR('msi number exceeded the maximum allocated number(FX)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    INSERT  INTO dbo.rlplfc
        ( mb_gr_pl_id ,
                             member_id ,
                              facility_id ,
                        eff_date ,
                              action_code ,
                              h_action ,
                              h_msi ,
                             h_datetime ,
               h_user
                           )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @s_dls_mb_id ,
                              @s_dls_fc_id ,
                              @d_plfc_eff_date ,
                              'FU' ,
                              'FU' ,
                              @n_msi ,
                              @ls_datetime ,
                              @ls_user
                            );
	
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rlplfc
                                    WHERE   h_msi = @n_msi )
									BEGIN
									SET @error_no=612
                        RAISERROR('Error in RLPLFC creation (FX)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_2',
                        @s_dls_mb_id,@created_by;
                END;

            
            IF @s_dls_act_code = 'FA'
-- ADD INTO RLPLFC MODULE:
                BEGIN
                    SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                    FROM  dbo.rlmbgrpl
                    WHERE   member_id = @s_dls_sub_id
                            AND group_id = @s_dls_group_id
                            AND plan_id = @s_dls_plan_id
                            AND exp_gr_pl IS NULL;
                   
                    IF @d_mb_gr_pl_id IS NULL
					BEGIN
					SET @error_no=528
                        RAISERROR('Missing RLMBGRPL record (FA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    
                    SET @d_plfc_eff_date = (@t_action_date);
                   
                    SET @n_msi = @n_msi + 1;
               
                    IF @n_msi > @msi_upper
					BEGIN
					SET @error_no=722
                        RAISERROR('msi number exceeded the maximum allocated number (FA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                    INSERT  INTO dbo.rlplfc
             ( mb_gr_pl_id ,
                              member_id ,
                              facility_id ,
                              eff_date ,
                         action_code ,
                              h_action ,
   h_msi ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @d_mb_gr_pl_id ,
                              @s_dls_mb_id ,
                              @s_dls_fc_id ,
                              @d_plfc_eff_date ,
                              'F1' ,
                              'F1' ,
                              @n_msi ,
                              @ls_datetime ,
                              @ls_user
                            );
	
                    IF NOT EXISTS ( SELECT  *
                                    FROM    dbo.rlplfc
                                    WHERE   h_msi = @n_msi )
									BEGIN
									SET @error_no=529
                        RAISERROR('Error in RLPLFC creation (FA)',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                END;

            
            IF @s_dls_act_code = 'PC'
-- TERM EXISTING GP PL RECORD AND ADD NEW GP PL RT FC MODULE:
                BEGIN
                    
                    IF ( @s_member_flag IS NULL
                         OR @s_member_flag = ''
                       )
					   BEGIN
					   SET @error_no=530
                        RAISERROR('Member Flag value is null, action - PC.',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
  
                    
                    IF (@t_action_date) IS NULL
					BEGIN
					SET @error_no=531
                        RAISERROR('Action Date is null, action - PC.',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
  
                    
                    IF @s_dls_mb_id IS NULL
					BEGIN
					SET @error_no=533
                        RAISERROR('Member Id is null, action - PC.',0,1);
						EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
  
  
                    IF @s_member_flag = '00'
                   BEGIN
                         
                            IF @s_dls_sub_id IS NULL
							BEGIN
							SET @error_no=535
                                RAISERROR('Subscriber Id is null, action - PC.',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                        
                            IF @s_dls_group_id IS NULL
							BEGIN
							SET @error_no=536
                                RAISERROR('Group Id is null, action - PC.',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                       
							IF @s_dls_plan_id IS NULL
							BEGIN
							SET @error_no=537
                                RAISERROR('Plan Id is null, action - PC.',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                          
                            IF ( @s_rate_code IS NULL
                                 OR @s_rate_code = ''
          )
							   BEGIN
							   SET @error_no=538
                     RAISERROR('Rate Code is null, action - PC.',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            
                            IF ( @s_mb_gppl_eff IS NULL
                                 OR @s_mb_gppl_eff = ''
                               )
							   BEGIN
							   SET @error_no=539
                                RAISERROR('Plan Effective Date is null, action - PC.',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            SET @d_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var9 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl
	
            FROM dbo.rlmbgrpl  (NOLOCK)
            WHERE member_id = @s_dls_sub_id
            AND group_id = @s_dls_group_id
            AND eff_gr_pl <= @t_action_date
            AND (exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
            ORDER BY eff_gr_pl DESC;
                           OPEN @SWV_cursor_var9;
                            FETCH NEXT FROM @SWV_cursor_var9 INTO @d_mb_gr_pl_id,
                                @d_eff_gr_pl;
                            WHILE @@FETCH_STATUS = 0
   BEGIN
                                    GOTO SWL_Label20;
                                    FETCH NEXT FROM @SWV_cursor_var9 INTO @d_mb_gr_pl_id,
                                        @d_eff_gr_pl;
                                END;
                            SWL_Label20:
                            CLOSE @SWV_cursor_var9;
                            IF @d_mb_gr_pl_id IS NULL
                                BEGIN
                                    SET @v_Null = 0;
                                END;
	--	RAISE EXCEPTION -746, 621, "Existing Active RLMBGRPL record not found (PC)";
	
	/* 20131114$$ks - term may have already happened */
                            IF @d_mb_gr_pl_id IS NOT NULL
                                BEGIN
                                   
                                    IF (@t_action_date) < @d_eff_gr_pl
                                        BEGIN
          SET @t_action_date = CONVERT(DATE, @d_eff_gr_pl);
                                           
                                        END;
		
                                    SET @li_rlmbrt_id = NULL;
                                    SET @SWV_cursor_var10 = CURSOR  FOR SELECT eff_rt_date, rlmbrt_id
               FROM dbo.rlmbrt  (NOLOCK)
               WHERE mb_gr_pl_id = @d_mb_gr_pl_id AND eff_rt_date <= @t_action_date
               AND (exp_rt_date > @t_action_date OR exp_rt_date IS NULL)
               ORDER BY eff_rt_date DESC;
                                    OPEN @SWV_cursor_var10;
                       FETCH NEXT FROM @SWV_cursor_var10 INTO @d_eff_rt_date,
             @li_rlmbrt_id;
                                    WHILE @@FETCH_STATUS = 0
                                        BEGIN
                                            GOTO SWL_Label21;
                                   FETCH NEXT FROM @SWV_cursor_var10 INTO @d_eff_rt_date,
                      @li_rlmbrt_id;
                              END;
                                    SWL_Label21:
                                    CLOSE @SWV_cursor_var10;
                                    IF @li_rlmbrt_id IS NULL
									BEGIN
									SET @error_no=542
                   RAISERROR('Subscriber doesn''t have active rate_code, action - PC',0,1);
										EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
		
            
                                    SET @n_msi = @n_msi + 1;
    
                                    IF @n_msi > @msi_upper
									BEGIN
									SET @error_no=727
                                        RAISERROR('MSI number exceeds maximum allocated number (PC)',0,1);
										EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
                                END;
	
                           
                            SET @SWV_func_DLP_ADD_SG_PLAN_par1 = (@t_action_date);
                            EXECUTE dbo.dlp_add_sg_plan @SWV_func_DLP_ADD_SG_PLAN_par1,
                                @s_dls_plan_id, @s_dls_msg_id, @s_dls_group_id,
                                @ls_user, @ls_datetime, @i_rel_gppl_id OUTPUT,
                                @s_sg_err OUTPUT;
                            IF ( @i_rel_gppl_id < 1 )
							BEGIN
							SET @error_no=900
                                RAISERROR('Unable to add Plan to SG',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            IF @d_mb_gr_pl_id IS NOT NULL
                                UPDATE  dbo.rlmbgrpl
                                SET     exp_gr_pl = (@t_action_date) ,
                                        action_code = 'PC' ,
                                        h_msi = @n_msi ,
                            h_action = @s_dls_act_code ,
                                        h_user = @ls_user ,
                                        h_datetime = @ls_datetime
                                WHERE   mb_gr_pl_id = @d_mb_gr_pl_id
                                        AND exp_gr_pl IS NULL;
	 
                          
                            SET @n_msi = @n_msi + 1;
                           
                            IF @n_msi > @msi_upper
							BEGIN
							SET @error_no=733
                                RAISERROR('MSI number exceeds maximum allocated number (PC)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.rlmbgrpl  (NOLOCK)
                                            WHERE   member_id = @s_dls_sub_id
                                                    AND group_id = @s_dls_group_id
                                                    AND plan_id = @s_dls_plan_id )
                                INSERT  INTO dbo.rlmbgrpl
                                        ( member_id ,
                      group_id ,
                                          plan_id ,
                                          sub_in_plan ,
                                          eff_gr_pl ,
                                          action_code ,
										h_action ,
                                          h_msi ,
                                          h_datetime ,
                                          h_user
                                    )
                                VALUES  ( @s_dls_sub_id ,
                                          @s_dls_group_id ,
                                          @s_dls_plan_id ,
         @s_sub_in_plan ,
         (@t_action_date) ,
                                          'PC' ,
                                     'PC' ,
       @n_msi ,
                                          @ls_datetime ,
                                          @ls_user
                               );
	
                            ELSE
							BEGIN
							SET @error_no=632
           RAISERROR('Incoming Plan already exists in RLMBGRPL (PC)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
      SELECT  @d_mb_gr_pl_id = mb_gr_pl_id
                            FROM    dbo.rlmbgrpl  (NOLOCK)
           WHERE   member_id = @s_dls_sub_id
                                    AND group_id = @s_dls_group_id
                                    AND plan_id = @s_dls_plan_id
                                    AND eff_gr_pl = (@t_action_date)
                                    AND action_code = 'PC'
                                    AND h_msi = @n_msi;
                            
                            IF @d_mb_gr_pl_id IS NULL
							BEGIN
							SET @error_no=623
                                RAISERROR('Error in RLMBGRPL creation (PC)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            
                            SET @d_plfc_eff_date = @s_mb_fc_eff_date;
                           
                            IF @d_plfc_eff_date < (@t_action_date)
                                BEGIN
                                   
                                    SET @d_plfc_eff_date = (@t_action_date);
                                END;
	
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_action ,
                                      h_msi ,
                                      h_datetime ,
                          h_user
                                    )
                      VALUES  ( @d_mb_gr_pl_id ,
                                      @s_dls_mb_id ,
                                      @s_dls_fc_id ,
                                      @d_plfc_eff_date ,
                                      'PC' ,
                                      'PC' ,
                                      @n_msi ,
                                      @ls_datetime ,
                                      @ls_user
                       );
	
   IF NOT EXISTS ( SELECT  *
                                            FROM    dbo.rlplfc  (NOLOCK)
								WHERE   h_msi = @n_msi )
								BEGIN
								SET @error_no=625
                                RAISERROR('Error in RLPLFC creation (PC)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            INSERT  INTO dbo.rlmbrt
                                    ( mb_gr_pl_id ,
                       rate_code ,
                                      eff_rt_date ,
                                      action_code ,
                         h_action ,
                                      h_msi ,
                                      h_datetime ,
                                      h_user
                                    )
                            VALUES  ( @d_mb_gr_pl_id ,
                                      @s_rate_code ,
                                      (@t_action_date) ,
    'PC' ,
                     'PC' ,
                                      @n_msi ,
             @ls_datetime ,
                                      @ls_user
                                    );
	
        IF NOT EXISTS ( SELECT  *
                                FROM    dbo.rlmbrt  (NOLOCK)
                     WHERE   h_msi = @n_msi )
											BEGIN
											SET @error_no=624
                                RAISERROR('Error in RLMBRT creation (PC)',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_3',
                                @s_dls_sub_id,@created_by;
END;
           ELSE
                        BEGIN
                            SET @li_mb_gr_pl_id = NULL;
                            SET @SWV_cursor_var11 = CURSOR  FOR SELECT eff_gr_pl, h_msi, mb_gr_pl_id
			
            FROM dbo.rlmbgrpl  (NOLOCK)
            WHERE member_id = @s_dls_sub_id AND
            group_id = @s_dls_group_id AND
            plan_id = @s_dls_plan_id AND
            eff_gr_pl <= @t_action_date AND
				(exp_gr_pl > @t_action_date OR exp_gr_pl IS NULL)
            ORDER BY eff_gr_pl DESC;
                            OPEN @SWV_cursor_var11;
                            FETCH NEXT FROM @SWV_cursor_var11 INTO @d_eff_gr_pl,
                                @n_dep_msi, @li_mb_gr_pl_id;
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
                                    GOTO SWL_Label22;
                                    FETCH NEXT FROM @SWV_cursor_var11 INTO @d_eff_gr_pl,
                                        @n_dep_msi, @li_mb_gr_pl_id;
                                END;
                            SWL_Label22:
                            CLOSE @SWV_cursor_var11;
                            IF @li_mb_gr_pl_id IS NULL
							BEGIN
							SET @error_no=550
                                RAISERROR('can''t retrieve valid group plan, action - PC',0,1);
								EXEC @n_fatal = usp_dl_log_error @a_batch_id, @sg_up_sp_id, @sg_sir_def_id, 
						@t_sub_sir_id, @error_no;
					IF @n_fatal <> 1  
					RETURN -@error_no;
			END
	
                            INSERT  INTO dbo.rlplfc
                                    ( mb_gr_pl_id ,
                                      member_id ,
                                      facility_id ,
                                      eff_date ,
                                      action_code ,
                                      h_datetime ,
                                      h_msi ,
               h_action ,
                                      h_user
                                    )
                            VALUES  ( @li_mb_gr_pl_id ,
                                      @s_dls_mb_id ,
                                      @s_dls_fc_id ,
                                      (@t_action_date) ,
                                      'PC' ,
                                      @n_datetime ,
                                      @n_dep_msi ,
                                    'PC' ,
                        @ls_user
                                    );
	
                            
                            EXECUTE dbo.dlp_elig_actv_log 'MB', 'upmenu_3',
                                @s_dls_sub_id,@created_by;
                        END;
                END;

--trace off;
            RETURN 1;
        END TRY
        BEGIN CATCH
		
		IF ERROR_NUMBER() =50000
		EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                               @sg_up_sp_id, @sg_sir_def_id, @t_sub_sir_id,
                                @error_no;
            RETURN -200;

        END CATCH;
        SET NOCOUNT OFF;

--set debug file to "/tmp/dlp_up_sg_mb.trc";
--trace on;
--set explain on;
    END;