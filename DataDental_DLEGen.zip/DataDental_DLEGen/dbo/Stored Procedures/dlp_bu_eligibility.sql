﻿CREATE PROCEDURE [dbo].[dlp_bu_eligibility]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 11:03:03 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1





000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @do_trace BIT;
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;


        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);


        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @n_error_count INT;

--For a description of table dls_elig, field dls_status--see dlp_ld_eligibility.sql.
        DECLARE @s_dls_status CHAR(1);
        DECLARE @i_count INT;

-- paramater variable

-- member info in sir table


        DECLARE @n_mb_count INT;
        DECLARE @n_member_id INT;
        DECLARE @new_member_id INT;
        DECLARE @new_group_id INT;
        DECLARE @new_plan_id INT;
        DECLARE @n_sub_id INT;
        DECLARE @n_rel_gppl_id INT;
        DECLARE @n_gppl_eff_date DATE;
        DECLARE @n_gppl_exp_date DATE;
        DECLARE @s_change_address CHAR(2);
        DECLARE @d_gp_eff_date DATE;
        DECLARE @d_gp_exp_date DATE;
        DECLARE @d_gppl_eff DATE;
        DECLARE @d_gppl_exp DATE;
        DECLARE @n_mb_gr_pl_id INT;
        DECLARE @n_group_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_sub_in_plan SMALLINT;
        DECLARE @n_eff_gr_pl DATE;
        DECLARE @n_exp_gr_pl DATE;
        DECLARE @n_eff_date DATE;
        DECLARE @n_exp_date DATE;
        DECLARE @i_dent_cnt INT;
        DECLARE @i_vision_cnt INT;
        DECLARE @n_facility_id INT;
        DECLARE @n_count_future INT;
        DECLARE @n_count_gp INT;
        DECLARE @n_rlplfc_id INT;

        DECLARE @as_member_id INT;
        DECLARE @as_sub_id INT;
        DECLARE @as_facility_id INT;
        DECLARE @as_action_code CHAR(2);
        DECLARE @as_plan_eff_date DATE;
        DECLARE @as_plan_term_date DATE;
        DECLARE @n_change_address CHAR(2);
        DECLARE @as_fac_eff_date DATE;
        DECLARE @s_change_dep_pc CHAR(1);
        DECLARE @d_fc_eff DATE;
        DECLARE @d_fc_exp DATE;
        DECLARE @t_del_sir INT;
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_eff_rt_date DATE;
/* 20131221$$ks - clean up logic - dlp_chk_facility needs to know if it should log error
 */
        DECLARE @n_log_err INT;



        DECLARE @n_sub_count INT;

        DECLARE @s_sub_error CHAR(1);
        DECLARE @i_return_value INT;
        DECLARE @def_group_id INT;
        DECLARE @def_plan_id INT;
        DECLARE @def_facility_id INT;
        DECLARE @n_bu_count INT;
        DECLARE @n_count INT;
        DECLARE @d_valid_status INT;

        DECLARE @s_batch_status CHAR(1);
        DECLARE @s_transfer_dep_gp CHAR(1);
        DECLARE @s_clean_err CHAR(1);
        DECLARE @t_temp_sir_id INT;
        DECLARE @t_temp_sir INT;
        DECLARE @i_error_count INT;
        DECLARE @s_version_no CHAR(6);

        DECLARE @i_elig_opt INT;
 
		DECLARE @true CHAR(1);
		DECLARE @false CHAR (1);
		DECLARE @s_sir_def_name char(14);
		DECLARE @s_proc_name char(14);
		DECLARE @i_sp_id int;
		DECLARE @i_sir_def_id int;
		DECLARE @ls_process_eff_dt char(10);
		DECLARE @ls_process_exp_dt char(10);
		DECLARE @n_lookup_ssn_alt char(1);
		DECLARE @n_new_mb_w_fc_id char(1);
		DECLARE @n_has_facility_id char(1);
		DECLARE @n_has_multiple_gp char(1);
		DECLARE @n_add_to_cl_fc char(1);
		DECLARE @n_has_rate_code char(1);
		DECLARE @n_has_address char(1);
		DECLARE @n_sub_age char(11);
		DECLARE @n_has_plan_eff char(1);
		DECLARE @n_has_s_plan_term char(1);
		DECLARE @n_has_d_plan_term char(1);
		DECLARE @n_has_fac_eff char(1);
		DECLARE @d_process_eff_dt date;
		DECLARE @d_process_exp_dt date;
		DECLARE @d_process_eff_per date;
		DECLARE @d_process_exp_per date;
		DECLARE @i_sub_age INT;
		DECLARE @s_sub_age char(11);
		DECLARE @t_sir_id INT;
		DECLARE @t_sub_sir_id INT;
		DECLARE @t_subscriber char(2);
		DECLARE @t_alt_id char(20);
		DECLARE @t_ssn char(11);
		DECLARE @t_sub_ssn char(11);
		DECLARE @t_sub_alt_id char(20);
		DECLARE @t_member_code char(2);
		DECLARE @t_last_name char(15);
		DECLARE @t_first_name char(15);
		DECLARE @t_middle_init char(1);
		DECLARE @t_date_of_birth date;
		DECLARE @t_student_flag char(1);
		DECLARE @t_disable_flag char(1);
		DECLARE @t_cobra_flag char(1);
		DECLARE @t_address1 char(30);
		DECLARE @t_address2 char(30);
		DECLARE @t_city char(30);
		DECLARE @t_state char(2);
		DECLARE @t_zip char(5);
		DECLARE @t_zipx char(4);
		DECLARE @t_home_phone char(10);
		DECLARE @t_home_ext char(4);
		DECLARE @t_work_phone char(10);
		DECLARE @t_work_ext char(4);
		DECLARE @t_rate_code char(2);
		DECLARE @t_plan_eff_date date;
		DECLARE @t_plan_term_date date;
		DECLARE @t_fac_eff_date date;
		DECLARE @t_group_id INT;
		DECLARE @t_plan_id INT;
		DECLARE @t_facility_id INT;
		DECLARE @t_def_key char(2);
		DECLARE @t_type char(2);
		DECLARE @t_sub_id INT;
		DECLARE @t_member_id INT;
		DECLARE @t_new_ssn char(11);
		DECLARE @t_src_id char(20);
		DECLARE @t_subnew_ssn char(11);
		DECLARE @t_subsrc_id char(20);
		DECLARE @t_ext_id_col char(20);
		DECLARE @t_paperless char(1);
		DECLARE @t_email char(100);
		DECLARE @t_sub_in_plan smallint;
		DECLARE @n_ffs_plan INT;
		DECLARE @n_process_count int;
		DECLARE @n_succ_count int;
		DECLARE @ls_mid_month	char(1);
		DECLARE @i_config_id int;

        DECLARE @SWV_dl_get_sp_id INT;
        DECLARE @SWV_dl_get_sir_def_id INT;
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @cSIR CURSOR;
        DECLARE @SWV_func_DLP_BU_DEP_ELIG_MB_par0 DATE;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par0 DATE;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par1 DATE;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par2 DATE;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par4 DATE;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par5 DATE;
        DECLARE @SWV_func_DLP_PLAN_XFER_par0 DATE;
        DECLARE @SWV_func_DLP_PLAN_XFER_par1 DATE;
        DECLARE @SWV_func_DLP_MBGRPL_INFO_par6 DATE;
        DECLARE @SWV_func_DLP_ELIG_DEP_PLCH_par0 DATE;
        DECLARE @SWV_func_DLP_ELIG_TFR_DEP_par0 DATE;
        DECLARE @SWV_func_DLP_ELIG_DEP_TERM_par0 DATE;
        DECLARE @SWV_func_DLP_ELIG_SUB_TERM_par0 DATE;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @v_Null INT;

        SET NOCOUNT ON;

		 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 3 AND BatchId = @a_batch_id )
		BEGIN
	
				INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id])
				SELECT N'd_process_eff_per',				N'', @a_batch_id, 3
				UNION ALL SELECT N'd_process_exp_per',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_d_plan_term',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_fac_eff',			N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_facility_id',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_multiple_gp',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_plan_eff',			N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_rate_code',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_has_s_plan_term',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_lookup_ssn_alt',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_new_mb_w_fc_id',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_process_count',		N'', @a_batch_id, 3
				UNION ALL SELECT N'n_sub_age',				N'', @a_batch_id, 3
				UNION ALL SELECT N'n_succ_count',			N'', @a_batch_id, 3
				UNION ALL SELECT N'new_group_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N'new_member_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N'new_plan_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_address1',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_address2',				N'', @a_batch_id, 3
				UNION ALL SELECT N'i_sp_id',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_alt_id',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_city',					N'', @a_batch_id, 3
				UNION ALL SELECT N't_cobra_flag',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_date_of_birth',		N'', @a_batch_id, 3
				UNION ALL SELECT N't_def_key',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_disable_flag',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_email',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_ext_id_col',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_fac_eff_date',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_facility_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_first_name',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_group_id',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_home_ext',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_home_phone',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_last_name',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_member_code',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_member_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_middle_init',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_new_ssn',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_paperless',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_plan_eff_date',		N'', @a_batch_id, 3
				UNION ALL SELECT N't_plan_id',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_plan_term_date',		N'', @a_batch_id, 3
				UNION ALL SELECT N't_rate_code',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_sir_id',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_src_id',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_ssn',					N'', @a_batch_id, 3
				UNION ALL SELECT N't_state',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_student_flag',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_sub_alt_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_sub_in_plan',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_sub_sir_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_sub_ssn',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_subnew_ssn',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_subscriber',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_subsrc_id',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_type',					N'', @a_batch_id, 3
				UNION ALL SELECT N't_work_ext',				N'', @a_batch_id, 3
				UNION ALL SELECT N't_work_phone',			N'', @a_batch_id, 3
				UNION ALL SELECT N't_zip',					N'', @a_batch_id, 3
				UNION ALL SELECT N't_zipx',					N'', @a_batch_id, 3
				UNION ALL SELECT N'i_sir_def_id',			N'', @a_batch_id, 3
				
								
		END

        SET @true = 't'
        
        SET @false = 'f';
        
        SET @s_sir_def_name = '';
        
        SET @s_proc_name = '';
        
        SET @i_sp_id = 0
        
        SET @i_sir_def_id = 0
        
        SET @ls_process_eff_dt = ''
        
        SET @ls_process_exp_dt = ''
    
        SET @n_lookup_ssn_alt = ''
        
        SET @n_new_mb_w_fc_id = ''
        
        SET @n_has_facility_id = ''
        
        SET @n_has_multiple_gp = ''
        
        SET @n_add_to_cl_fc = ''
        
	SET @n_has_rate_code = ''
       
        SET @n_has_address = ''
        
        SET @n_sub_age = ''
        
        SET @n_has_plan_eff = ''
        
        SET @n_has_s_plan_term = ''
        
        SET @n_has_d_plan_term = ''
        
        SET @n_has_fac_eff = ''
        
        SET @d_process_eff_dt = NULL
        
        SET @d_process_exp_dt = NULL
 
	SET @d_process_eff_per = NULL
        
        SET @d_process_exp_per = NULL
        
        SET @i_sub_age = 0
        
        SET @s_sub_age = ''
        
        SET @i_config_id = 0
   
        SET @t_sir_id = 0
        
        SET @t_sub_sir_id = 0
        
        SET @t_subscriber = ''
        
        SET @t_alt_id = ''
        
        SET @t_ssn = ''
        
        SET @t_sub_ssn = ''
        
        SET @t_sub_alt_id = ''
        
        SET @t_member_code = ''
        
        SET @t_last_name = ''
        
        SET @t_first_name = ''
        
        SET @t_middle_init = ''
        
        SET @t_date_of_birth = NULL
        
        SET @t_student_flag = ''
        
        SET @t_disable_flag = ''
        
        SET @t_cobra_flag = ''
        
        SET @t_address1 = ''
        
        SET @t_address2 = ''
        
        SET @t_city = ''
        
        SET @t_state = ''
        
        SET @t_zip = ''
        
        SET @t_zipx = ''
        
        SET @t_home_phone = ''
        
        SET @t_home_ext = ''
        
        SET @t_work_phone = ''
        
        SET @t_work_ext = ''
        
        SET @t_rate_code = ''
        
        SET @t_plan_eff_date = NULL
        
        SET @t_plan_term_date = NULL
        
        SET @t_fac_eff_date = NULL
        
        SET @t_group_id = 0
        
        SET @t_plan_id = 0
        
        SET @t_facility_id = 0
        
        SET @t_def_key = ''
        
        SET @t_type = ''
        
        SET @t_sub_id = 0
        
        SET @t_member_id = 0
        
        SET @t_new_ssn = ''
        
        SET @t_src_id = ''
        
        SET @t_subnew_ssn = ''
        
        SET @t_subsrc_id = ''
        
        SET @t_ext_id_col = ''
        
        SET @t_paperless = ''
        
        SET @t_email = ''
        
        SET @t_sub_in_plan = NULL
        
        SET @n_ffs_plan = 0
        
        SET @n_process_count = 0
		UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND BatchId = @a_batch_id AND Module_Id = 3
		
        
        SET @n_succ_count = 0
        UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND BatchId = @a_batch_id AND Module_Id = 3

        SET @ls_mid_month = 'N';
        
        IF EXISTS ( SELECT  *
                    FROM    tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#dls_elig_temp')
                            AND xtype = 'U' )
            DROP TABLE #dls_elig_temp;
        CREATE TABLE #dls_elig_temp ( dls_sub_temp_id INT ); 
        BEGIN TRY
          --BEGIN TRAN
            SET @do_trace = 0;

            IF @@SERVERNAME = 'ddsecho'
                BEGIN
            
                    SET @do_trace = 1;
                END;

            IF ( @do_trace = 1 )
                BEGIN--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/dlp_bu_eligibility_dev_" || a_batch_id || ".trc";

	--TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;
	--set explain on;

            BEGIN -- 1
                DECLARE @currentDateAndTime DATETIME;
                DECLARE @userSessionId INT;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "dlp_bu_eligibility():  Entered.";
                        SET @v_Null = 0;
                    END;
	
        SET @currentDateAndTime = GETDATE();
                SET @userSessionId = @@spid;
                IF ( @do_trace = 1 )
                    BEGIN--TRACE statement has no equivalent in MSSQL
--trace "a_batch_id = " || a_batch_id;

		--TRACE statement has no equivalent in MSSQL
--trace "a_sir_id = " || a_sir_id;

		--TRACE statement has no equivalent in MSSQL
--trace "a_start_time = " || a_start_time;
SET @v_Null = 0;
 END;
	
END; -- 1

           --COMMIT; 
            
            SET @s_proc_name = 'bu_eligibility';
  
     SET @s_sir_def_name = 'elig';
            
            SELECT  @i_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
            
            
            EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_eligibility';
            SET @i_sp_id = @SWV_dl_get_sp_id;
			
            UPDATE dbo.GlobalVar set VarValue = @i_sp_id where VarName = 'i_sp_id' and BatchId = @a_batch_id AND Module_Id = 3

            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Invalid SP Name',16,1);
				END

            EXECUTE @SWV_dl_get_sir_def_id = dbo.dl_get_sir_def_id 'elig';
            SET @i_sir_def_id = @SWV_dl_get_sir_def_id;
            
			UPDATE dbo.GlobalVar set VarValue = @i_sir_def_id where VarName = 'i_sir_def_id' and BatchId = @a_batch_id AND Module_Id = 3
			
			    IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Invalid SIR TABLE Definition',16,1);
				END
            IF ( @do_trace = 1 )
                BEGIN--TRACE statement has no equivalent in MSSQL
--trace "i_sp_id = " || i_sp_id;

	--TRACE statement has no equivalent in MSSQL
--trace "i_sir_def_id = " || i_sir_def_id;
                    SET @v_Null = 0;
                END;


/* 20131221$$ks -- moved 'get parameter' logic to new procedure
 * this procedure is getting too big to store in informix
 */
            
            EXECUTE dbo.dlp_bu_elig_parms @a_batch_id, @i_sp_id, @i_config_id,
                @n_error_no OUTPUT, @n_error_text OUTPUT;
            IF @n_error_no < 0
                BEGIN
				SET @a_error_no = @n_error_no
                    SET @n_error_text = CAST( -746 AS VARCHAR) + ':'+ @n_error_text;
                    RAISERROR(@n_error_text,16,1);
                END;

				select @n_has_plan_eff = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_plan_eff' and BatchId = @a_batch_id AND Module_Id = 3
				select @n_has_facility_id = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_facility_id' and BatchId = @a_batch_id AND Module_Id = 3
				
				select @n_has_d_plan_term = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_d_plan_term' and BatchId = @a_batch_id AND Module_Id = 3
				select @n_sub_age = VarValue from GlobalVar(NOLOCK) where VarName = 'n_sub_age' and BatchId = @a_batch_id AND Module_Id = 3
				select @n_has_rate_code = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_rate_code' and BatchId = @a_batch_id AND Module_Id = 3
				select @n_has_multiple_gp = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_multiple_gp' and BatchId = @a_batch_id AND Module_Id = 3
				select @n_new_mb_w_fc_id = VarValue from GlobalVar(NOLOCK) where VarName = 'n_new_mb_w_fc_id' and BatchId = @a_batch_id AND Module_Id = 3
				select @n_has_s_plan_term = VarValue from GlobalVar(NOLOCK) where VarName = 'n_has_s_plan_term' and BatchId = @a_batch_id AND Module_Id = 3

            IF ( @n_sub_age IS NULL
                 )
                BEGIN
                    SET @i_sub_age = 0
            
                END;
            ELSE
                BEGIN
                    SET @s_error_descr = 'Invalid Number for Subscriber Age';
                    SET @a_error_no = 10;
            
                    SET @i_sub_age = @n_sub_age;
                    
                END;

            
            EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
                @n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_descr OUTPUT;
            IF @n_error_no <= 0
			BEGIN
				SET @a_error_no = 0
        RAISERROR('(Internal) error when creating statistics',16,1);
			END
SET @n_process_count = 0
            
SET @n_sub_count = 0;
            SET @n_succ_count = 0
            
            SET @s_clean_err = 'N';
            IF @a_sir_id > 0
                BEGIN
                    SELECT  @a_sir_id = dls_sub_sir_id
                    FROM    dbo.dls_elig (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
					AND dls_sir_id = @a_sir_id;
                    
                    UPDATE  dbo.dls_elig
                    SET     dls_status = 'V'
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sub_sir_id = @a_sir_id;
                    DELETE  FROM dbo.dl_action
                    WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                        AND dls_sir_id IN (
     SELECT  dls_sir_id
                     FROM    dbo.dls_elig (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @a_sir_id );
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id  FROM dbo.dls_elig (NOLOCK)
         WHERE dls_batch_id = @a_batch_id AND dls_sub_sir_id = @a_sir_id
         AND dls_source = 'F';
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @t_del_sir;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            
                            EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                @t_del_sir, @i_sp_id, @n_error_no OUTPUT,
                                @n_error_text OUTPUT;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @t_del_sir;
                        END;
                    CLOSE @SWV_cursor_var1;
					 DEALLOCATE @SWV_cursor_var1
                END;
            ELSE
	/* 20131218$$ks - the logic below does not make sense to me
	 * we test if there are records for batch where status = "P"
	 * then we put all the records from batch into temp table where status = "V"
	 * then we scroll through temp table and set the records with key in temp to 
	 * status = "V" (which we it already is).
	 * I am changing logic to get records that have "P" status and reset them to "V"
	 */
                BEGIN
					
                    IF EXISTS ( SELECT  *
                                FROM    dbo.dls_elig (NOLOCK)
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_status = 'P' )
                        BEGIN -- 2
                            DECLARE @SWV_cursor_var2 CURSOR;
                            BEGIN TRY
                                DELETE  FROM #dls_elig_temp;
                                INSERT  INTO #dls_elig_temp
                                        ( dls_sub_temp_id
                                        )
                                        SELECT DISTINCT
                                                dls_sub_sir_id
                                        FROM    dbo.dls_elig (NOLOCK)
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND dls_status = 'P';
	--				dls_status = "V";

                                CREATE INDEX dls_elig_temp1 ON #dls_elig_temp 
                                (dls_sub_temp_id);
                                SET @SWV_cursor_var2 = CURSOR  FOR SELECT dls_sub_temp_id  FROM #dls_elig_temp;
                                OPEN @SWV_cursor_var2;
                                FETCH NEXT FROM @SWV_cursor_var2 INTO @t_temp_sir_id;
                                WHILE @@FETCH_STATUS = 0
                                    BEGIN
                                        UPDATE  dbo.dls_elig
                                        SET     dls_status = 'V'
									 WHERE dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @t_temp_sir_id;
								FETCH NEXT FROM @SWV_cursor_var2 INTO @t_temp_sir_id;
                                    END;
                                CLOSE @SWV_cursor_var2;
								DEALLOCATE @SWV_cursor_var2
                                DROP TABLE #dls_elig_temp;

                        -- COMMIT TRAN 
						 END TRY
							
     BEGIN CATCH
							--If @@TRANCOUNT > 0 
							--ROLLBACK

                                SET @n_error_no = ERROR_NUMBER();
                                SET @i_isam_error = ERROR_LINE();
								SET @s_error_descr = ERROR_MESSAGE();
								DELETE  FROM #dls_elig_temp;
                                DROP TABLE #dls_elig_temp;

                            END CATCH;
							END; -- 2
								
								IF EXISTS ( SELECT  *
                                FROM    dbo.dl_action (NOLOCK)
                                WHERE  batch_id = @a_batch_id
                                        AND dls_sir_id IN (
                                        SELECT  dls_sir_id
                                        FROM    dbo.dls_elig (NOLOCK)
                                        WHERE   dls_batch_id = @a_batch_id
                                                AND dls_status = 'V' ) )
						DELETE  FROM dbo.dl_action
                        WHERE   batch_id = @a_batch_id
                                AND process_status = 'N'
                                AND dls_sir_id IN (
                                SELECT  dls_sir_id
                                FROM    dbo.dls_elig (NOLOCK)
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_status = 'V' );
	
                    IF EXISTS ( SELECT  *
                                FROM    dbo.dl_log_error (NOLOCK)
                                WHERE   config_bat_id = @a_batch_id
                                        AND sp_id = @i_sp_id )
                        SET @s_clean_err = 'Y';
                END;

				--select @n_process_count = COUNT(*) FROM dbo.dls_elig (NOLOCK)
    --  WHERE dls_batch_id = @a_batch_id AND dls_status = 'V'
    --  AND ((@a_sir_id > 0 AND dls_sub_sir_id = @a_sir_id) OR (@a_sir_id = 0 AND dls_sir_id > 0)); 
-- 20120726$$ks - added paperless and email variables
 /* 20131220$$ks - added member_id to possible input variables
  */

            SET @cSIR = CURSOR  FOR SELECT dls_sir_id, dls_sub_sir_id, member_flag, alt_id, ssn, sub_ssn,
			sub_alt_id, member_code, last_name, first_name, middle_init,
			date_of_birth, student_flag, disable_flag, cobra_flag,
			address1, address2, city, state, zip, zipx, home_phone,
			home_ext, work_phone, work_ext, rate_code, plan_eff_date,
			plan_term_date, facility_eff_date, dls_group_id, dls_plan_id,
			facility_id, def_key, type, new_ssn, source_id, subnew_ssn,
			subsource_id, ext_id_col, paperless, email, sub_in_plan,
			member_id, group_id, plan_id
	
      FROM dbo.dls_elig (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND member_flag = '00' AND dls_status = 'V'
      AND ((@a_sir_id > 0 AND dls_sub_sir_id = @a_sir_id) OR (@a_sir_id = 0 AND dls_sir_id > 0));
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_sub_sir_id, @t_subscriber,
                @t_alt_id, @t_ssn, @t_sub_ssn, @t_sub_alt_id, @t_member_code,
                @t_last_name, @t_first_name, @t_middle_init, @t_date_of_birth,
                @t_student_flag, @t_disable_flag, @t_cobra_flag, @t_address1,
                @t_address2, @t_city, @t_state, @t_zip, @t_zipx, @t_home_phone,
                @t_home_ext, @t_work_phone, @t_work_ext, @t_rate_code,
                @t_plan_eff_date, @t_plan_term_date, @t_fac_eff_date,
                @t_group_id, @t_plan_id, @t_facility_id, @t_def_key, @t_type,
                @t_new_ssn, @t_src_id, @t_subnew_ssn, @t_subsrc_id,
       @t_ext_id_col, @t_paperless, @t_email, @t_sub_in_plan,
                @new_member_id, @new_group_id, @new_plan_id;
            WHILE @@FETCH_STATUS = 0
                BEGIN
 
					UPDATE dbo.GlobalVar set VarValue = @t_sir_id where VarName = 't_sir_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_sub_sir_id where VarName = 't_sub_sir_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_subscriber where VarName = 't_subscriber' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_alt_id where VarName = 't_alt_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_ssn where VarName = 't_ssn' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_sub_ssn where VarName = 't_sub_ssn' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_sub_alt_id where VarName = 't_sub_alt_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_member_code where VarName = 't_member_code' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_last_name where VarName = 't_last_name' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_first_name where VarName = 't_first_name' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_middle_init where VarName = 't_middle_init' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_date_of_birth where VarName = 't_date_of_birth' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_student_flag where VarName = 't_student_flag' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_disable_flag where VarName = 't_disable_flag' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_cobra_flag where VarName = 't_cobra_flag' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_address1 where VarName = 't_address1' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_address2 where VarName = 't_address2' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_city where VarName = 't_city' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_state where VarName = 't_state' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_zip where VarName = 't_zip' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_zipx where VarName = 't_zipx' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_home_phone where VarName = 't_home_phone' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_home_ext where VarName = 't_home_ext' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_work_phone where VarName = 't_work_phone' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_work_ext where VarName = 't_work_ext' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_rate_code where VarName = 't_rate_code' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_plan_eff_date where VarName = 't_plan_eff_date' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_plan_term_date where VarName = 't_plan_term_date' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_fac_eff_date where VarName = 't_fac_eff_date' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_group_id where VarName = 't_group_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_plan_id where VarName = 't_plan_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_facility_id where VarName = 't_facility_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_def_key where VarName = 't_def_key' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_type where VarName = 't_type' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_new_ssn where VarName = 't_new_ssn' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_src_id where VarName = 't_src_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_subnew_ssn where VarName = 't_subnew_ssn' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_subsrc_id where VarName = 't_subsrc_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_ext_id_col where VarName = 't_ext_id_col' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_paperless where VarName = 't_paperless' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_email where VarName = 't_email' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @t_sub_in_plan where VarName = 't_sub_in_plan' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @new_member_id where VarName = 'new_member_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @new_group_id where VarName = 'new_group_id' and BatchId = @a_batch_id AND Module_Id = 3
					UPDATE dbo.GlobalVar set VarValue = @new_plan_id where VarName = 'new_plan_id' and BatchId = @a_batch_id AND Module_Id = 3
					
				DECLARE @SWV_cursor_var3 CURSOR;
				DECLARE @SWV_dlp_elig_cal_age INT;
                        DECLARE @SWV_dlp_bu_elig_subnpl SMALLINT;
                        BEGIN TRY
          -- BEGIN TRAN;
           IF ( @do_trace = 1 )
                                BEGIN--TRACE statement has no equivalent in MSSQL
--trace "t_sub_sir_id = " || t_sub_sir_id;
            SET @v_Null = 0;
                                END;
	
                            
                            IF ( @t_sub_in_plan IS NOT NULL )
                                BEGIN
                                    
                                    IF ( @t_sub_in_plan < 0
                                         OR @t_sub_in_plan > 1
                                       )
                                        BEGIN
                                            SET @t_sub_in_plan = 1;
                                            
                                  END;	--The default is one.
                                END;
                            ELSE
                                BEGIN
                                    SET @t_sub_in_plan = 1;
                                    
                                END;
	
                            SET @s_sub_error = 'N';
                            SET @s_change_dep_pc = 'N';
                            SET @s_transfer_dep_gp = 'N';

							SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND BatchId = @a_batch_id AND Module_Id = 3
                            
                            SET @n_process_count = @n_process_count + 1;

							UPDATE GlobalVar
							SET VarValue = @n_process_count
							WHERE VarName ='n_process_count' AND BatchId = @a_batch_id AND Module_Id = 3
                            
                            SET @n_sub_count = @n_sub_count + 1;
                            SET @as_plan_term_date = NULL;
                            SET @as_facility_id = NULL;
       SET @as_action_code = NULL;
                            SET @as_plan_eff_date = NULL;
                            SET @n_change_address = NULL;
                            SET @as_fac_eff_date = NULL;
                            SET @as_member_id = NULL;
                            SET @as_sub_id = NULL;
                            SET @n_sub_id = NULL;
                            SET @n_member_id = NULL;
                            SET @n_mb_gr_pl_id = NULL;

                            SELECT @d_process_eff_per = VarValue from dbo.GlobalVar where VarName = 'd_process_eff_per' and BatchId = @a_batch_id AND Module_Id = 3
							
                            SET @d_process_eff_dt = @d_process_eff_per;
                                                        
                            SET @d_process_exp_dt = @d_process_exp_per;
                            
                            SET @n_rate_code = NULL;
                            SET @n_eff_rt_date = NULL;
                            IF @s_clean_err = 'Y'
                                BEGIN
									
                                    UPDATE  dbo.dls_elig
                                    SET     dls_status = 'V'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sub_sir_id = @t_sub_sir_id;
										
                                    SET @SWV_cursor_var3 = CURSOR  FOR SELECT dls_sir_id  FROM dbo.dls_elig (NOLOCK)
                  WHERE dls_batch_id = @a_batch_id AND dls_sub_sir_id = @t_sub_sir_id
                  AND dls_source = 'F';
                                    OPEN @SWV_cursor_var3;
                                    FETCH NEXT FROM @SWV_cursor_var3 INTO @t_del_sir;
                              WHILE @@FETCH_STATUS = 0
                                        BEGIN
                                            
                  EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                                @t_del_sir, @i_sp_id,
                                                @n_error_no OUTPUT,
                                                @n_error_text OUTPUT;
                                            FETCH NEXT FROM @SWV_cursor_var3 INTO @t_del_sir;
                               END;
         CLOSE @SWV_cursor_var3;
									DEALLOCATE @SWV_cursor_var3;
       END;
	

	--delete the dependent records that bring in from application

                  IF EXISTS ( SELECT  *
                                        FROM    dbo.dls_elig (NOLOCK)
                                   WHERE   dls_batch_id = @a_batch_id
                                                AND dls_sub_sir_id = @t_sub_sir_id
                                                AND dls_source = 'A' )
                 DELETE  FROM dbo.dls_elig
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sub_sir_id = @t_sub_sir_id
                                        AND dls_source = 'A';
	
                            
                            EXECUTE @n_error_no = dbo.dlp_pre_check @a_batch_id,
                                @t_sir_id;

								
                            IF @n_error_no < 0

                                SET @s_sub_error = 'Y';
	
                            
                            IF @n_has_plan_eff != 'Y'
                                BEGIN
                                    
                                    SET @t_plan_eff_date = @d_process_eff_dt;
									UPDATE dbo.GlobalVar set VarValue = @t_plan_eff_date where VarName = 't_plan_eff_date' and BatchId = @a_batch_id AND Module_Id = 3
                                    
                                END;
	
                            
                            IF @n_has_s_plan_term != 'Y'
                                BEGIN
                SET @t_plan_term_date = NULL
                               
  END;
	
         
                IF @t_def_key = 'FI'
                                AND @t_type = 'LE'
                                BEGIN
                                    SET @ls_mid_month = 'Y';
                                    
                                END; -- allow mid-month as long as group-plan in file allows it
	
                            
                            IF @ls_mid_month = 'N'
                                BEGIN
                                    
                                    IF DATEPART(DAY,@t_plan_eff_date) != 1
									BEGIN
									SET @a_error_no = 175
                                        RAISERROR('Plan Effective date has to be 1st of month',0,1);
										EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
									END
                                    
                                    IF DATEPART(DAY,@t_plan_term_date) != 1
									BEGIN
									SET @a_error_no = 176
                                        RAISERROR('Plan Term date has to 1st of month',0,1);
										EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
@a_error_no;
										 IF @i_fatal <> 1
                       SET @s_sub_error = 'Y';
									END
                                    
                                    IF DATEPART(DAY,@t_fac_eff_date) != 1
									BEGIN
									SET @a_error_no = 177
                                        RAISERROR('Facility Effective date has to be 1st of month',0,1);
										EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
									END
                                END;
	
                            
                            
                            IF @t_plan_eff_date > @d_process_eff_dt
                                BEGIN
                                    
                                    SET @d_process_eff_dt = @t_plan_eff_date;
       
            END;
	
              
               
                            IF CONVERT(DATE, CONVERT(VARCHAR, @t_fac_eff_date)) < @t_plan_eff_date
                                BEGIN
                                    
                                    SET @t_fac_eff_date = @t_plan_eff_date;
									UPDATE dbo.GlobalVar set VarValue = @t_fac_eff_date where VarName = 't_fac_eff_date' and BatchId = @a_batch_id AND Module_Id = 3
                                    
                                END;
	
                            
                            IF @t_def_key = 'FI'
                                AND @t_type = 'LE'
                                AND ( @new_group_id IS NULL
                                      OR @new_group_id = 0
                      OR @new_plan_id IS NULL
            OR @new_plan_id = 0
 )
									BEGIN
									SET @a_error_no = 999
                                RAISERROR('New err def_key and type = FILE but group or plan not specified',0,1);
								EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
								END
	
                            
							IF @t_def_key = 'FI'
                                AND @t_type = 'LE'
                   BEGIN
         SET @def_group_id = @new_group_id;
                        SET @def_plan_id = @new_plan_id;
                                    
                                    SET @def_facility_id = @t_facility_id;
                                    SET @i_return_value = 1;
                                END;
                            ELSE
                                BEGIN
                                    
                                    
                       EXECUTE dbo.dlp_group_setup @i_config_id,
                                        @t_def_key, @t_type, @t_sir_id,
                                        @i_return_value OUTPUT,
                                        @def_group_id OUTPUT,
                                        @def_plan_id OUTPUT,
                                        @def_facility_id OUTPUT;
                                END;
	
                            IF @i_return_value <= 0
							BEGIN
							SET @a_error_no = -(@i_return_value)
							RAISERROR('No default setup for group/plan/facility',0,1);
								EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
								END
	--		CALL dlp_set_family_err(a_batch_id, t_sub_sir_id) returning n_error_no;
	--		COMMIT WORK;
	--		CONTINUE FOREACH;
	
                        IF @s_sub_error = 'N'
                                BEGIN
                                    SET @t_group_id = @def_group_id;
									UPDATE dbo.GlobalVar set VarValue = @t_group_id where VarName = 't_group_id' and BatchId = @a_batch_id AND Module_Id = 3
                                    
                                    SET @t_plan_id = @def_plan_id;
UPDATE dbo.GlobalVar set VarValue = @t_plan_id where VarName = 't_plan_id' and BatchId = @a_batch_id AND Module_Id = 3
                                                                        
                                    SET @as_plan_eff_date = @t_plan_eff_date;
                                    
                                    
                                    SET @as_fac_eff_date = @t_fac_eff_date;
                                    
                                    SET @as_plan_term_date = @t_plan_term_date;
                                    SET @n_ffs_plan = 1;

									
                                    
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.[plan] (NOLOCK) ,
                                                            dbo.ins_opt (NOLOCK)
                                                    WHERE   dbo.[plan].plan_id = @def_plan_id
                               AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                                            AND dbo.ins_opt.ins_opt_qual = 'I' )
         BEGIN
                                            SET @n_ffs_plan = 0
                                            
                                        END;
		

		/* 12212013$$ks - add the ability for IT to 'tell' DL which member_id to use
		 * or if the member does not exist - only lookup member if the new_member_id value 
		 * is null
		 * > 0 do not look up - just use this ID
		 * = 0 do not look up - member does not exist
		 * NULL - process as normal
		 */
		
	  /* 20160106$$ks Need to verify that new_member_id has at least one field 
		* in common with the record IT says it is the same as */
                                    IF ISNULL(@new_member_id,0) = 0 -- IS NULL
                                        BEGIN
                                            
                                            EXECUTE dbo.dlp_check_member 'Y',
         @a_batch_id, @t_sir_id, 0,
      @n_mb_count OUTPUT,
 @n_member_id OUTPUT,
                            @n_sub_id OUTPUT;
       END;
                                ELSE
                                        IF @new_member_id > 0
                                         BEGIN
                                       
                                                EXECUTE @n_error_no = dbo.dlp_check_mbr_id @a_batch_id,@t_sir_id, @new_member_id;
                                                IF ( @n_error_no < 1 )
												BEGIN
												SET @a_error_no = 0
                                                    RAISERROR('sub''s member_id provided does not match against alt, src or SSN values of that member',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
													END
                                                ELSE
                                                    BEGIN
                                                        SET @n_mb_count = 1;
                                                        SET @n_member_id = @new_member_id;
                                                        SET @n_sub_id = @new_member_id;
   END;
       END;
   ELSE
         IF @new_member_id = 0
                                                BEGIN
               SET @n_mb_count = 0;
                                                    SET @n_member_id = NULL;
                                                    SET @n_sub_id = NULL;
                                                END;
                                            ELSE
                                 BEGIN
       SET @n_mb_count = @new_member_id; -- not null, not 0 not > than 0: must be neg numb
                                                    SET @n_member_id = NULL;
                                                    SET @n_sub_id = NULL;
                                                END;
		
                                    SET @as_member_id = @n_member_id;
                                    SET @as_sub_id = @n_sub_id;
                                    IF @n_mb_count < 0
                                        SET @s_sub_error = 'Y';
		
                                    IF @n_mb_count = 0
                                        BEGIN
                                            
                                            EXECUTE dbo.dlp_check_address @a_batch_id,
                                                @t_sir_id, 'Y', 0,
                                                @n_error_no OUTPUT,
                                                @s_change_address OUTPUT;
                                            IF @n_error_no < 0
                                                SET @s_sub_error = 'Y';
		 	
                  
 IF @i_sub_age > 0
        BEGIN
                                                    DECLARE @Date Date
													SET @Date =  GETDATE()
                                                    EXECUTE @SWV_dlp_elig_cal_age = dbo.dlp_elig_cal_age @t_date_of_birth,@Date;
                                SET @n_sub_age = @SWV_dlp_elig_cal_age;
                                      
                                                    
                                                    
                                                    IF @n_sub_age < @i_sub_age
													BEGIN
													SET @a_error_no = 170

                                                        RAISERROR('Subscriber age is less than defined age',0,1);
														EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
         @a_error_no;
										 IF @i_fatal <> 1
 SET @s_sub_error = 'Y';
														END
             END;
		 	
                
                                        IF @t_plan_term_date IS NOT NULL
											BEGIN
											SET @a_error_no = 172
              RAISERROR('New subscriber with plan term date',0,1);
			  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
												END
			
                                            BEGIN -- 3
											
           DECLARE @SWV_cursor_var4 CURSOR;
                                                DECLARE @SWV_cursor_var5 CURSOR;
 SET @d_gp_eff_date = NULL;
                                SET @d_gp_exp_date = NULL;
                                 SET @SWV_cursor_var4 = CURSOR  FOR SELECT eff_date, exp_date 
                        FROM dbo.group_status (NOLOCK)
                        WHERE group_id = @def_group_id AND group_status = 'A4'
                     AND exp_date IS NULL
                  ORDER BY eff_date DESC;
                                   OPEN @SWV_cursor_var4;
                                                FETCH NEXT FROM @SWV_cursor_var4 INTO @d_gp_eff_date,
                                                    @d_gp_exp_date;
                                      WHILE @@FETCH_STATUS = 0
                                                    BEGIN
   GOTO SWL_Label24;
     FETCH NEXT FROM @SWV_cursor_var4 INTO @d_gp_eff_date,
                @d_gp_exp_date;
         END;
                                                SWL_Label24:
                CLOSE @SWV_cursor_var4;
                                                IF @d_gp_eff_date IS NULL
												BEGIN
												SET @a_error_no = 100
                                                    RAISERROR('Group is not active group',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
													END
	 		
                                                IF NOT EXISTS ( SELECT
                                                              *
                                                              FROM
                                                              dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                              group_id = @def_group_id
                                                              AND plan_id = @def_plan_id )
															  BEGIN
															  SET @a_error_no = 139
                                                    RAISERROR('Group is not associated with the default plan',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
													END
		 	
                                                SET @d_gppl_eff = NULL;
                                                SET @d_gppl_exp = NULL;
                                                SET @SWV_cursor_var5 = CURSOR  FOR SELECT eff_date, exp_date 
                        FROM dbo.rel_gppl (NOLOCK)
                        WHERE group_id = @def_group_id AND plan_id = @def_plan_id
                 AND (eff_date <= @t_plan_eff_date AND exp_date IS NULL)
                        ORDER BY eff_date DESC;
						
                                                OPEN @SWV_cursor_var5;
                           FETCH NEXT FROM @SWV_cursor_var5 INTO @d_gppl_eff,
                                                 @d_gppl_exp;
                            WHILE @@FETCH_STATUS = 0
                                 BEGIN
													
                                                        GOTO SWL_Label25;
                                                        FETCH NEXT FROM @SWV_cursor_var5 INTO @d_gppl_eff,
                                                            @d_gppl_exp;
                                                    END;
                                                SWL_Label25:
                                                CLOSE @SWV_cursor_var5;
        IF @d_gppl_eff IS NULL
												BEGIN
												SET @a_error_no = 103
                                                    RAISERROR('No activ Subscriber''s group/plan',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
												END
                                                
                                                IF @n_ffs_plan = 0
                  BEGIN
                                                        
                                                        IF @def_facility_id IS NULL
                                                            AND @t_facility_id IS NULL
                                  BEGIN
  SELECT
                                                              @def_facility_id = MAX(dbo.facility.fc_id)
           FROM
                         dbo.facility (NOLOCK) ,
                                                              dbo.fcstat (NOLOCK) ,
                                                              dbo.[plan] (NOLOCK)
                                                              WHERE
                                                              dbo.[plan].plan_id = @def_plan_id
                                                              AND dbo.fcstat.facility_id = dbo.facility.fc_id
                                                              AND ( dbo.fcstat.eff_date <= @t_plan_eff_date
                                                              AND ( dbo.fcstat.exp_date IS NULL
                                                              OR dbo.fcstat.exp_date > @t_plan_eff_date
                                                              )
                                                              )
                                                              AND dbo.fcstat.status = 'UF'
                                                              AND dbo.[plan].ins_type = dbo.facility.fc_type;
                                                              
                                                              IF @def_facility_id IS NULL
															  BEGIN
															  SET @a_error_no = 999
                                                              RAISERROR('Cannot find Unknown facility for HMO plan',16,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
                                                            END;
				
                                                        
                                                        IF @n_new_mb_w_fc_id = 'Y'
                                                            BEGIN
                                                              
                                                     IF @t_facility_id IS NULL
					--	RAISE EXCEPTION -746, 104, "Missing Subscriber's Facility ID";
  BEGIN
                      SET @t_facility_id = @def_facility_id;
                      
                END;
					
        
                                                              SET @as_facility_id = @t_facility_id;
            END;
                    ELSE
                                                            SET @as_facility_id = @def_facility_id;
			 	
				/* 20131221$$ks removed multiple chk_fc above and do it once here
				 */
                                                        
                         
   EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
         @t_sir_id,
                 @as_facility_id,
              @def_plan_id,
                       @t_plan_eff_date,
                                                            1;
                                      IF @n_error_no < 0
                                                            SET @s_sub_error = 'Y';
                                                    END;
			
                                                IF @s_sub_error = 'N'
        BEGIN
                                               SET @as_action_code = 'SA';
                                                    
  
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                              @t_sir_id,
                         @as_action_code,
                                  @t_plan_eff_date;
                            END;
			
     END;
                                        END; -- 3
		  -- END OF "IF n_mb_count = 0 THEN"
		  
                                    IF ( @n_mb_count = 1
                                         OR @n_mb_count = 2
                                       )
			
			/* the dlp_bu_dep_elig_mb function logs the action (MU) if member info changes
			 */
                                        BEGIN
                                            
                                            
                                            SET @SWV_func_DLP_BU_DEP_ELIG_MB_par0 = @t_plan_eff_date;
                                            EXECUTE dbo.dlp_bu_dep_elig_mb @n_mb_count,
                                                @n_error_no, @as_action_code,
                                                @n_member_id, @t_src_id,
                                                @a_batch_id, @t_sir_id,
                                                @SWV_func_DLP_BU_DEP_ELIG_MB_par0,
                                                @n_error_no OUTPUT,
                                                @as_action_code OUTPUT;
                                            
                                            IF @t_plan_term_date IS NULL
			--existing subscriber
                                                BEGIN
                                                    
                                                    EXECUTE dbo.dlp_check_address @a_batch_id,
                                                        @t_sir_id, 'N',
                                                        @n_member_id,
                                                        @n_error_no OUTPUT,
                                                        @n_change_address OUTPUT;
                                                    IF @n_error_no < 0
                                                        SET @s_sub_error = 'Y';
                                                    ELSE
 IF @n_change_address LIKE 'G[1-7]'
                                                            ESCAPE '\'
                             BEGIN
               
                   
         EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                            @t_sir_id,
                                              @n_change_address,
                                    @t_plan_eff_date;
                                        SET @as_action_code = @n_change_address;
              END;
					
				
 BEGIN -- 4
				
			--Whenever dlp_mbgrpl_info() is called, 
			-- and sub-gr-plan is found then also call dlp_bu_elig_subnpl().
				
     DECLARE @SWV_cursor_var6 CURSOR;
                                                        DECLARE @SWV_cursor_var7 CURSOR;
                         DECLARE @SWV_get_xfer_date DATE;
   DECLARE @SWV_cursor_var8 CURSOR;
                                                DECLARE @SWV_cursor_var9 CURSOR;
                                                        DECLARE @SWV_cursor_var10 CURSOR;
                                                        DECLARE @SWV_cursor_var11 CURSOR;
                                                        DECLARE @SWV_cursor_var12 CURSOR;
                                                        DECLARE @SWV_cursor_var13 CURSOR;
                DECLARE @SWV_cursor_var14 CURSOR;
                                                        DECLARE @SWV_cursor_var15 CURSOR;
                                                      DECLARE @SWV_cursor_var16 CURSOR;
                                                        DECLARE @SWV_cursor_var17 CURSOR;
     DECLARE @SWV_cursor_var18 CURSOR;
                                   DECLARE @SWV_cursor_var19 CURSOR;
                            DECLARE @SWV_cursor_var20 CURSOR;
             DECLARE @SWV_cursor_var21 CURSOR;
                                                        DECLARE @SWV_cursor_var22 CURSOR;
                                                        DECLARE @SWV_cursor_var23 CURSOR;
                                                        
                                                        SET @SWV_func_DLP_MBGRPL_INFO_par0 = @d_process_eff_dt;
                                                        EXECUTE dbo.dlp_mbgrpl_info @def_group_id,
                                                            @def_plan_id,
                                                            @n_member_id,
                                                            @SWV_func_DLP_MBGRPL_INFO_par0,
                                                            'N',
                                                            @n_count OUTPUT,
                                                            @n_mb_gr_pl_id OUTPUT,
                                                            @n_group_id OUTPUT,
                                                            @n_plan_id OUTPUT,
                                                            @n_sub_in_plan OUTPUT,
                                                            @n_eff_gr_pl OUTPUT,
                                                            @n_exp_gr_pl OUTPUT;
                                                        IF @n_count = 0
                                                            BEGIN
                                                              
                                                              SET @SWV_func_DLP_MBGRPL_INFO_par1 = @t_plan_eff_date;
                                                              EXECUTE dbo.dlp_mbgrpl_info @def_group_id,
                                      @def_plan_id,
                                       @n_member_id,
           @SWV_func_DLP_MBGRPL_INFO_par1,
                                              'N',
                                                   @n_count OUTPUT,
                                                              @n_mb_gr_pl_id OUTPUT,
                                                  @n_group_id OUTPUT,
           @n_plan_id OUTPUT,
            @n_sub_in_plan OUTPUT,
   @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
                                                  IF @n_count > 1
															  BEGIN
															  SET @a_error_no = 105
															  RAISERROR('multiple member/group/plan records',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                             SET @s_sub_error = 'Y';
																END
                                                              IF @n_count = 1
                                                              BEGIN
															 IF @n_exp_gr_pl IS NOT NULL
															 BEGIN
															 SET @a_error_no = 134
                                                              RAISERROR('Subscriber is expired in DataDental',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
						
                                                    
                                                              EXECUTE dbo.dlp_bu_elig_subnpl @n_count,
 @t_sub_in_plan,
                                                   @n_sub_in_plan,
                                                 @a_batch_id,
                                 @i_sp_id,
                                                              @i_sir_def_id,
                                                              @t_sub_sir_id,
                                                              @SWV_dlp_bu_elig_subnpl OUTPUT;
                                                              SET @t_sub_in_plan = @SWV_dlp_bu_elig_subnpl;
                                                              
                                                              SET @SWV_cursor_var6 = CURSOR  FOR SELECT rate_code, eff_rt_date 
                                 FROM dbo.rlmbrt (NOLOCK)
                                 WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND exp_rt_date IS NULL
                                 ORDER BY 2 DESC;
                                                              OPEN @SWV_cursor_var6;
                                                              FETCH NEXT FROM @SWV_cursor_var6 INTO @n_rate_code,
                                                              @n_eff_rt_date;
                                                              WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label26;
                                                              FETCH NEXT FROM @SWV_cursor_var6 INTO @n_rate_code,
                                                              @n_eff_rt_date;
                                                              END;
                                                              SWL_Label26:
                                                              CLOSE @SWV_cursor_var6;
                                                              IF ( @n_rate_code IS NULL
                                                              OR @n_rate_code = ''
                                                              )
															OR @n_eff_rt_date IS NULL
															BEGIN
															SET @a_error_no = 237
   RAISERROR('Sub has no active rate code',0,1);
   EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
               SET @s_sub_error = 'Y';
															  END
                                                       ELSE
          BEGIN
                             
                                       IF @n_has_rate_code != 'Y'
       BEGIN
     SET @t_rate_code = @n_rate_code;
                          
 END;
                                         END;
						
                            SET @n_facility_id = NULL;
                              SET @d_fc_exp = NULL;
                                                              SET @d_fc_eff = NULL;
                                                              SET @SWV_cursor_var7 = CURSOR  FOR SELECT facility_id, eff_date, exp_date 
                                 FROM dbo.rlplfc (NOLOCK)
                                 WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND member_id = @n_member_id
                AND (eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_fac_eff_date)) AND exp_date IS NULL)
                                 ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var7;
           FETCH NEXT FROM @SWV_cursor_var7 INTO @n_facility_id,
                                                              @d_fc_eff,
                                                              @d_fc_exp;
      WHILE @@FETCH_STATUS = 0
                                                              BEGIN
           GOTO SWL_Label27;
                                                              FETCH NEXT FROM @SWV_cursor_var7 INTO @n_facility_id,
                                                    @d_fc_eff,
                                                              @d_fc_exp;
                                                              END;
                                                              SWL_Label27:
                                                              CLOSE @SWV_cursor_var7;
                                                              IF @d_fc_eff IS NULL
															  BEGIN
															  SET @a_error_no = 235
                                                              RAISERROR('Sub is missing active facility record',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END						
                                                              
                                                              IF @n_ffs_plan = 0
                                                              BEGIN
                                                              
                                                              IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                                              
                                              IF @t_facility_id IS NOT NULL
                                                              BEGIN
                                                              
                                                              IF @n_facility_id != @t_facility_id
                                                              BEGIN
                                                              
                                                              SET @as_facility_id = @t_facility_id;
                                                              
                                                              
                                                              
                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                   @t_sir_id,
                                                             @t_facility_id,
                                                              @def_plan_id,
      @t_fac_eff_date,
                              1;
              IF @n_error_no < 0
           SET @s_sub_error = 'Y';
     ELSE
                              BEGIN
                
                                  SET @as_fac_eff_date = CONVERT(DATE, CONVERT(VARCHAR, @t_fac_eff_date));
                                                  
                                                   
             EXECUTE dbo.get_xfer_date @n_facility_id,
                                                              @t_facility_id,
                            @d_fc_eff,
                                                              @t_fac_eff_date,
                                                              @SWV_get_xfer_date OUTPUT;
                                                              SET @t_fac_eff_date = @SWV_get_xfer_date;
                                    
                                                              SET @as_action_code = 'FX';
                                                              
                      
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                     @as_action_code,
                        @t_fac_eff_date;
                                    END;
                                                   END;
                                                              ELSE
                                                              SET @as_facility_id = @n_facility_id; -- currently in this FC
                                                              END;
                                                              ELSE
                                                              SET @as_facility_id = @n_facility_id;
                                                              END;
                                                              ELSE
                                                              SET @as_facility_id = @n_facility_id;
							
                                                              IF @s_sub_error = 'N'
                                                              AND ( @as_action_code IS NULL
                                                              --OR @as_action_code = ''
                                                              )
                                                              BEGIN
                                                              SET @as_action_code = 'GI';
                                                              
                                                              
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @t_plan_eff_date;
                                                              END;
                                                              END;
                                                              END;  -- END IF of "IF n_ffs_plan = 0 THEN"
					  -- END IF of "IF n_count = 1 THEN"

        IF @n_count = 0  -- Tape Type Group, Plan, Plan Eff Date
                      BEGIN
                
                                                              SET @SWV_func_DLP_MBGRPL_INFO_par2 = @t_plan_eff_date;
                              EXECUTE dbo.dlp_mbgrpl_info @def_group_id,
   @def_plan_id,
                              @n_member_id,
              @SWV_func_DLP_MBGRPL_INFO_par2,
                       'Y',
               @n_count OUTPUT,
       @n_mb_gr_pl_id OUTPUT,
         @n_group_id OUTPUT,
   @n_plan_id OUTPUT,
                @n_sub_in_plan OUTPUT,
                                                  @n_eff_gr_pl OUTPUT,
                 @n_exp_gr_pl OUTPUT;
                                              IF @n_count = 1
															  BEGIN
															  SET @a_error_no = 135
                                      RAISERROR('Subscriber is active in future',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
SET @s_sub_error = 'Y';
															  END						
                                                              
                                                              SET @SWV_func_DLP_MBGRPL_INFO_par2 = @t_plan_eff_date;
                        EXECUTE dbo.dlp_mbgrpl_info @def_group_id,
                                                              0, @n_member_id,
                                                              @SWV_func_DLP_MBGRPL_INFO_par2,
            'N',
                                                              @n_count OUTPUT,
                                                              @n_mb_gr_pl_id OUTPUT,
                                        @n_group_id OUTPUT,
                                                              @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                              @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
                                                              IF @n_count = 0  -- Same Group, Diff Plan (NOT FOUND)
                                                              BEGIN
                                                              
                                                              SET @SWV_func_DLP_MBGRPL_INFO_par4 = @t_plan_eff_date;
                                                              EXECUTE dbo.dlp_mbgrpl_info 0,
                                                              0, @n_member_id,
                                                              @SWV_func_DLP_MBGRPL_INFO_par4,
                                                              'N',
                                                              @n_count_gp OUTPUT,
                                                              @n_mb_gr_pl_id OUTPUT,
                                                              @n_group_id OUTPUT,
                                                              @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                              @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
                                                           IF @n_count_gp = 0
                                                            BEGIN
                             
                          SET @SWV_func_DLP_MBGRPL_INFO_par5 = @t_plan_eff_date;
       EXECUTE dbo.dlp_mbgrpl_info 0,
0, @n_member_id,
                 @SWV_func_DLP_MBGRPL_INFO_par5,
       'Y',
               @n_count_future OUTPUT,
                         @n_mb_gr_pl_id OUTPUT,
@n_group_id OUTPUT,
  @n_plan_id OUTPUT,
                   @n_sub_in_plan OUTPUT,
  @n_eff_gr_pl OUTPUT,
    @n_exp_gr_pl OUTPUT;
                        IF @n_count_future = 0 --ameeta if it is SR or RI
      BEGIN
                                                              IF EXISTS ( SELECT
               *
                FROM
                                                              dbo.rlmbgrpl (NOLOCK)
                           WHERE
                          group_id = @def_group_id
                                                              AND plan_id = @def_plan_id
                                      AND member_id = @n_member_id )
         SET @as_action_code = 'RI';
                                                              ELSE
                  SET @as_action_code = 'SR';
								
SELECT
                                                              @d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                                              FROM
                                      dbo.group_status (NOLOCK)
                                                              WHERE
                               group_id = @def_group_id
                                                              AND group_status = 'A4'
                       AND exp_date IS NULL;
                                                              
                                                              IF @d_gp_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 137
                                      RAISERROR('Group is not active',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END								
                                                              
                                                              IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
                                                              RAISERROR('Group not active at Sub plan eff_date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                              IF NOT EXISTS ( SELECT
                                                              *
                                                              FROM
                                                              dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                        group_id = @def_group_id
                    AND plan_id = @def_plan_id )
															  BEGIN
															 SET @a_error_no = 139
															 RAISERROR('Missing Sub Group/Plan Association',0,1);
															 EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															 END								
        SET @d_gppl_eff = NULL;
                                                   SET @d_gppl_exp = NULL;
                                                              SET @SWV_cursor_var8 = CURSOR  FOR SELECT eff_date, exp_date 
                                FROM dbo.rel_gppl (NOLOCK)
                                          WHERE group_id = @def_group_id
AND plan_id = @def_plan_id
                                          AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date))
            AND (exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
           ORDER BY eff_date DESC,exp_date;
                                           OPEN @SWV_cursor_var8;
                                                              FETCH NEXT FROM @SWV_cursor_var8 INTO @d_gppl_eff,
       @d_gppl_exp;
                                 WHILE @@FETCH_STATUS = 0
                                                              BEGIN
         GOTO SWL_Label28;
                          FETCH NEXT FROM @SWV_cursor_var8 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
               END;
                                                 SWL_Label28:
                                                              CLOSE @SWV_cursor_var8;
                                                              IF @d_gppl_eff IS NULL
															  BEGIN
															  SET @a_error_no = 140
                                                              RAISERROR('Missing Active Grp/Plan as of Sub''s plan eff date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                         SET @n_mb_gr_pl_id = NULL;
                                                              SET @n_eff_gr_pl = NULL;
                                                              SET @SWV_cursor_var9 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl 
                                          FROM dbo.rlmbgrpl (NOLOCK)
                                          WHERE member_id = @n_member_id AND group_id = @def_group_id
                                          AND plan_id = @def_plan_id
                                          ORDER BY eff_gr_pl DESC;
                                                              OPEN @SWV_cursor_var9;
                                                              FETCH NEXT FROM @SWV_cursor_var9 INTO @n_mb_gr_pl_id,
                                                              @n_eff_gr_pl;
                                                              WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label29;
                                                              FETCH NEXT FROM @SWV_cursor_var9 INTO @n_mb_gr_pl_id,
                                                              @n_eff_gr_pl;
                                                              END;
                                                              SWL_Label29:
                                                   CLOSE @SWV_cursor_var9;
                                                              IF @n_mb_gr_pl_id IS NOT NULL
                   BEGIN
               SET @n_facility_id = NULL;
 SET @n_eff_date = NULL;
                  SET @SWV_cursor_var10 = CURSOR  FOR SELECT facility_id, eff_date 
    FROM dbo.rlplfc (NOLOCK)
                                             WHERE member_id = @n_member_id AND mb_gr_pl_id = @n_mb_gr_pl_id
         ORDER BY eff_date DESC;
                                                      OPEN @SWV_cursor_var10;
                                                              FETCH NEXT FROM @SWV_cursor_var10 INTO @n_facility_id,
             @n_eff_date;
                                              WHILE @@FETCH_STATUS = 0
                                              BEGIN
                                      GOTO SWL_Label30;
           FETCH NEXT FROM @SWV_cursor_var10 INTO @n_facility_id,
            @n_eff_date;
                  END;
                         SWL_Label30:
                                                            CLOSE @SWV_cursor_var10;
            IF @n_facility_id IS NOT NULL
                                                           SET @as_facility_id = @n_facility_id;
             END;
								
                                                              
                                        IF @n_ffs_plan = 0
								/* which FC to use? */
                                               BEGIN
                                  
                             IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                     
      IF @t_facility_id IS NULL
                                                              IF @as_facility_id IS NULL
          BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                              SET @n_log_err = 1;
                              END;
                                                              ELSE
                                                              BEGIN
                                                              
             
                                       EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @as_facility_id,
                                                              @def_plan_id,
                                                              @t_plan_eff_date,
                                                              0;
                    IF @n_error_no < 0
                                                              BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                              SET @n_log_err = 1;
                                                              END;
                                                              END;
											
              ELSE
                                                        BEGIN
                                                              
                                                              SET @as_facility_id = @t_facility_id;
                                                              SET @n_log_err = 1;
             END;
                                                         END;
                                                              ELSE
                                        BEGIN
                   IF @as_facility_id IS NOT NULL -- got from rlplfc
                                                              BEGIN
   
                 
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                       @t_sir_id,
               @as_facility_id,
                                                           @def_plan_id,
                                       @t_plan_eff_date,
                          0;
                   END;
  ELSE
                                                SET @n_error_no = -1;
										
                                                          IF @n_error_no < 0
                                                              BEGIN
                                     SET @as_facility_id = @def_facility_id;
          SET @n_log_err = 1;
                                                              END;
                                  END;
									  -- end of "IF n_has_facility_id= "Y" THEN"
                                                              
                                                     
                        EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                            @t_sir_id,
               @as_facility_id,
                                                              @def_plan_id,
                                          @t_plan_eff_date,
                                                              0;
          IF @n_error_no < 0
                                     SET @s_sub_error = 'Y';
                                                              END;
     ELSE
                    SET @as_facility_id = NULL;
								  -- end of "IF n_ffs_plan = 0 THEN"

                                                              IF @s_sub_error = 'N'
                                                  BEGIN
                                                              
                                                              
                           EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @t_plan_eff_date;
                        END;
                                                 END;
							  -- end of "IF n_count_future = 0 THEN"

                                                              IF @n_count_future > 1
                                                              BEGIN
                                                              
                                                 IF @n_has_multiple_gp != 'Y'
															  BEGIN
															  SET @a_error_no = 331
                                        RAISERROR('Subscriber can''t be in multiple group/plan',0,1);
										EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                              SET @as_action_code = 'SR';
SELECT
                                                              @d_gp_eff_date = eff_date ,
       @d_gp_exp_date = exp_date
                                                              FROM
        dbo.group_status (NOLOCK)
                                                              WHERE
                                                        group_id = @def_group_id
    AND group_status = 'A4'
      AND exp_date IS NULL;
                                                              
                                                              IF @d_gp_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 137
         RAISERROR('Group is not active',0,1);
		 EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
            
                                                              IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
               RAISERROR('Group is not active as of Sub plan eff_date',0,1);
			   EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                        IF NOT EXISTS ( SELECT
                                     *
                                                              FROM
      dbo.rel_gppl (NOLOCK)
                                              WHERE
                                                              group_id = @def_group_id
                                                              AND plan_id = @def_plan_id )
															  BEGIN 
															  SET @a_error_no = 139
                      RAISERROR('Missing Subscriber Group/Plan Association',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                          @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                              SET @d_gppl_eff = NULL;
                                          SET @d_gppl_exp = NULL;
                                                              SET @SWV_cursor_var11 = CURSOR  FOR SELECT eff_date, exp_date 
                                          FROM dbo.rel_gppl (NOLOCK)
                                          WHERE group_id = @def_group_id
       AND plan_id = @def_plan_id
                                        AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date))
                                          AND (exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
                                          ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var11;
                                                              FETCH NEXT FROM @SWV_cursor_var11 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                                                              WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label31;
     FETCH NEXT FROM @SWV_cursor_var11 INTO @d_gppl_eff,
                                           @d_gppl_exp;
                                                              END;
   SWL_Label31:
                                                    CLOSE @SWV_cursor_var11;
                                                              IF @d_gppl_eff IS NULL
															  BEGIN
															  SET @a_error_no = 140
                                                              RAISERROR('Missing Active Grp/Plan as of Sub''s plan eff date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                             @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END								
                                                              
                                                              IF @n_ffs_plan = 0
                                                              BEGIN
                                     
                                                              IF @n_has_facility_id = 'Y'
                                                              BEGIN

                                                              IF @t_facility_id IS NULL
                                                      SET @as_facility_id = @def_facility_id;
                                                      ELSE
                                                              BEGIN
                          
                   SET @as_facility_id = @t_facility_id;
            END;
         END;
     ELSE
                   SET @as_facility_id = @def_facility_id;
									
                                                              
        
                             EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                          @t_sir_id,
                               @as_facility_id,
                                                              @def_plan_id,
                                                 @t_plan_eff_date,
                              1;
       IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                                                              END;
                         ELSE
                                   SET @as_facility_id = NULL;
								
                                                              IF @s_sub_error = 'N'
                       BEGIN
          
  
 EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @t_plan_eff_date;
                                                              END;
           END;
							  -- end of "IF n_count_future > 1 THEN"

                                                              IF @n_count_future = 1
							--ameeta group transfer should be done only if group exists in dlsp_eg_group_plan
                                                              BEGIN
           IF NOT EXISTS ( SELECT
                                                              *
                                                              FROM
                                                              dbo.dlsp_eg_group_plan (NOLOCK)
                                                              WHERE
                                              group_id = @n_group_id )
                                                              SET @as_action_code = 'SR';
                ELSE
                                                              IF @n_exp_gr_pl IS NOT NULL
                    BEGIN
                                                              IF @n_exp_gr_pl > @n_eff_gr_pl
															  BEGIN
															  SET @a_error_no = 332
															RAISERROR('Subscriber future group/plan records expired',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
										
                                                        SET @as_action_code = 'GX';
                END;
       ELSE
                                                              SET @as_action_code = 'GX';
									
								
                                                              SELECT
@d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                                              FROM
       dbo.group_status (NOLOCK)
                                WHERE
                                                     group_id = @def_group_id
                       AND group_status = 'A4'
                    AND exp_date IS NULL;
                                                              
      IF @d_gp_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 137
                                           RAISERROR('Group is not active',0,1);
										   EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                 @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
              @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                              
                     IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
             RAISERROR('Group is not active as of Sub plan eff_date',0,1);
			 EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                      @a_error_no;
										 IF @i_fatal <> 1
                                 SET @s_sub_error = 'Y';
															  END
								
                                                              IF NOT EXISTS ( SELECT
                              *
                                                              FROM
                                                              dbo.rel_gppl (NOLOCK)
                                         WHERE
       group_id = @def_group_id
                                                              AND plan_id = @def_plan_id )
															  BEGIN
															  SET @a_error_no = 139
       RAISERROR('Missing Sub Group/Plan Association',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                      SET @d_gppl_eff = NULL;
               SET @d_gppl_exp = NULL;
                                                              SET @SWV_cursor_var12 = CURSOR  FOR SELECT eff_date, exp_date 
                                          FROM dbo.rel_gppl (NOLOCK)
                                          WHERE group_id = @def_group_id AND plan_id = @def_plan_id
                                          AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date))
      AND (exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
         ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var12;
                       FETCH NEXT FROM @SWV_cursor_var12 INTO @d_gppl_eff,
                                      @d_gppl_exp;
                                                              WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label32;
                                                 FETCH NEXT FROM @SWV_cursor_var12 INTO @d_gppl_eff,
                                                           @d_gppl_exp;
                                                              END;
                                                              SWL_Label32:
                CLOSE @SWV_cursor_var12;
               IF @d_gppl_eff IS NULL
															  BEGIN
															  SET @a_error_no = 140
                                                              RAISERROR('Missing Active Grp/Plan as of Sub''s plan eff date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                 @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END								
                                                              
                                                              IF @n_ffs_plan = 0
                                                              BEGIN
                                        SET @n_facility_id = NULL;
                                          SET @SWV_cursor_var13 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
										
                                             FROM dbo.rlplfc (NOLOCK)
                                       WHERE mb_gr_pl_id = @n_mb_gr_pl_id
                                            AND member_id = @n_member_id
                                             ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var13;
                                       FETCH NEXT FROM @SWV_cursor_var13 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                              @n_eff_date,
             @n_exp_date;
                                                              WHILE @@FETCH_STATUS = 0
                                                   BEGIN
                                                              GOTO SWL_Label33;
                  FETCH NEXT FROM @SWV_cursor_var13 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                @n_eff_date,
                           @n_exp_date;
END;
                                                              SWL_Label33:
                                                    CLOSE @SWV_cursor_var13;
                                        
                                                              IF @n_has_facility_id = 'Y'
                                                              BEGIN
                        
                                                              IF @t_facility_id IS NULL
                                                              IF @n_facility_id IS NOT NULL
                                                              SET @as_facility_id = @n_facility_id;
                                                              ELSE
         SET @as_facility_id = @def_facility_id;
											
              ELSE
                                                              BEGIN
         
                                         SET @as_facility_id = @t_facility_id;
     END;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                              IF @n_facility_id IS NOT NULL
                                                              SET @as_facility_id = @n_facility_id;
                                                              END;
									
  
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
          @t_sir_id,
                                                              @as_facility_id,
                                                              @def_plan_id,
                    @t_plan_eff_date,
             1;
                                                              IF @n_error_no < 0
															SET @s_sub_error = 'Y';
                                                              END;
																 ELSE
                                                              SET @as_facility_id = NULL;
								
														IF @s_sub_error = 'N'
														BEGIN
   IF @as_action_code = 'GX'
														BEGIN
																	
                                                              IF @n_has_d_plan_term = 'Y'
                                                SET @s_transfer_dep_gp = 'Y';
										
                                                              
                                                         
                              EXECUTE @n_error_no = dbo.dlp_elig_sub_xfrgp @a_batch_id,
                                               @t_sir_id,
@n_member_id,
                                                              @t_plan_eff_date;
                                                              IF @n_error_no <= 0
															  BEGIN
															  SET @a_error_no =224
                                                              RAISERROR('Fail to create sub record for group transfer',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
                                                              END;
									
                                                              
                
                                         EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                            @t_sir_id,
                                                              @as_action_code,
                                          @t_plan_eff_date;
   END;
                                                              END;  -- end of "IF s_sub_error = "N" THEN"
      END;  -- end of "IF n_count_future = 1 THEN"
						  -- end of "IF n_count_gp = 0 THEN"

                                                              IF @n_count_gp > 1
                                                 BEGIN
                                                              
                IF @n_has_multiple_gp != 'Y'
							--	RAISE EXCEPTION -746, 331, "Sub can't be in multiple group/plan";
							-- By doing this, the multiple groups/plans that the subscriber is in
							-- will all get terminated, leaving only this incoming record active
    IF NOT EXISTS ( SELECT
                            *
                                                              FROM
                              dbo.dlsp_eg_group_plan (NOLOCK)
                                                              WHERE
                                                              group_id = @n_group_id )
                  SET @as_action_code = 'SR';
                                                              ELSE
                                                         SET @as_action_code = 'GX';
								
                                                              ELSE
                                                              SET @as_action_code = 'SR';
							

							--LET as_action_code = "SR";
         SELECT
                                                              @d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                                              FROM
                                                              dbo.group_status (NOLOCK)
                                           WHERE
                                                group_id = @def_group_id
                                  AND group_status = 'A4'
                                      AND exp_date IS NULL;

                                                              IF @d_gp_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 137
                RAISERROR('Group is not active',0,1);
				EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END							
                                                              
                                                   IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
                              RAISERROR('Group not active as of Sub plan eff_date',0,1);
							  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
							  END
							
                     IF NOT EXISTS ( SELECT
                                                              *
                                                      FROM
              dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                             group_id = @def_group_id
        AND plan_id = @def_plan_id )
															  BEGIN
															  SET @a_error_no = 139
          RAISERROR('Missing Sub Group/Plan Association',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                   @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                                              SET @d_gppl_eff = NULL;
                                                              SET @d_gppl_exp = NULL;
 SET @SWV_cursor_var14 = CURSOR  FOR SELECT eff_date, exp_date 
                                       FROM dbo.rel_gppl (NOLOCK)
                                       WHERE group_id = @def_group_id
                            AND plan_id = @def_plan_id
              AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date))
    AND (exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
                                       ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var14;
                                                              FETCH NEXT FROM @SWV_cursor_var14 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                                                   WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label34;
          FETCH NEXT FROM @SWV_cursor_var14 INTO @d_gppl_eff,
                 @d_gppl_exp;
                                                              END;
                                                        SWL_Label34:
                                                              CLOSE @SWV_cursor_var14;
															IF @d_gppl_eff IS NULL
															BEGIN
															SET @a_error_no = 140
                                                              RAISERROR('Missing Active Grp/Plan as of Sub''s plan eff date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END							
                                                              
                                                              IF @n_ffs_plan = 0
											BEGIN

                                                              IF @n_has_facility_id = 'Y'
											BEGIN
                                                              
                                            IF @t_facility_id IS NOT NULL
                                                              BEGIN
                                                              
          SET @as_facility_id = @t_facility_id;
       END;
                                             ELSE
                                        SET @as_facility_id = @def_facility_id;
         END;
                               ELSE
                             SET @as_facility_id = @def_facility_id;
								
                                                              
                                      
                       EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                 @as_facility_id,
                                                              @def_plan_id,
                    @t_plan_eff_date,
      1;
                 IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                                       END;
                                                ELSE
                                           SET @as_facility_id = NULL;
							
                                                              IF @s_sub_error = 'N'
                                                BEGIN
           IF @as_action_code = 'GX'
       BEGIN
                                                              
                                                              IF @n_has_d_plan_term = 'Y'
                                                              SET @s_transfer_dep_gp = 'Y';
									
                                                              
                                           
                                                              EXECUTE @n_error_no = dbo.dlp_elig_sub_xfrgp @a_batch_id,
                            @t_sir_id,
                                                              @as_member_id,
                          @t_plan_eff_date;
                                                              IF @n_error_no <= 0
															  BEGIN
															  SET @a_error_no =224
                                                              RAISERROR('Fail to create term sub records for sub group transfer',0,1)
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                      @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
                                              
               END;
								
                                                              
                                                              
                          EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                @t_sir_id,
                                                              @as_action_code,
                                                              @t_plan_eff_date;
                                 END;
                                                              END;
						  -- END OF "IF n_count_gp >  1 THEN"

                                                              IF @n_count_gp = 1
							-- HOW TO MODIFY this
                                                              BEGIN
                                                              SET @n_mb_gr_pl_id = NULL;
                                                              SET @SWV_cursor_var15 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl
							
                  FROM dbo.rlmbgrpl (NOLOCK)
          WHERE member_id = @n_member_id AND
                                 group_id = @def_group_id AND
   plan_id = @def_plan_id
                                       ORDER BY eff_gr_pl DESC;
                 OPEN @SWV_cursor_var15;
                                                              FETCH NEXT FROM @SWV_cursor_var15 INTO @n_mb_gr_pl_id,
                                 @n_eff_gr_pl;
                  WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                     GOTO SWL_Label35;
                                                              FETCH NEXT FROM @SWV_cursor_var15 INTO @n_mb_gr_pl_id,
                                   @n_eff_gr_pl;
               END;
                                                              SWL_Label35:
                         CLOSE @SWV_cursor_var15;
                                          SET @n_facility_id = NULL;
                           IF @n_mb_gr_pl_id IS NOT NULL
                  BEGIN
       SET @SWV_cursor_var16 = CURSOR  FOR SELECT rlplfc_id, facility_id, eff_date, exp_date
								
                           FROM dbo.rlplfc (NOLOCK)
                          WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
           member_id = @n_sub_id
								--	eff_date <= n_eff_gr_pl and
								--	(exp_date > n_eff_gr_pl or exp_date is null)
                        ORDER BY eff_date DESC,exp_date;
                                                            OPEN @SWV_cursor_var16;
                                                              FETCH NEXT FROM @SWV_cursor_var16 INTO @n_rlplfc_id,
                                                              @n_facility_id,
                                                @n_eff_date,
                                                              @n_exp_date;
                                WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label36;
                                                              FETCH NEXT FROM @SWV_cursor_var16 INTO @n_rlplfc_id,
                                                              @n_facility_id,
             @n_eff_date,
                                                              @n_exp_date;
                                                          END;
          SWL_Label36:
                                                              CLOSE @SWV_cursor_var16;
                                                              END;
							
                                                              IF @n_exp_gr_pl IS NOT NULL
                                                              BEGIN
                                       
                                              IF @n_exp_gr_pl > @t_plan_eff_date
                                                              BEGIN
                                  
                                                              IF @n_has_multiple_gp != 'Y'
															  BEGIN
															  SET @a_error_no = 330
                                                     RAISERROR('Sub active with other group/plan',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
            END;
								
                                                              SET @as_action_code = 'SR';
        END;
                                                              ELSE
                                                      BEGIN
                                       
                 IF @n_has_multiple_gp != 'Y'
SET @as_action_code = 'GX';
              ELSE
                                                              SET @as_action_code = 'SR';
                                 END;
							
                                                              SELECT
                                                              @d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                                              FROM
                                                              dbo.group_status (NOLOCK)
                                                    WHERE
                                                       group_id = @def_group_id
                                                              AND group_status = 'A4'
   AND exp_date IS NULL;
                     
															 IF @d_gp_eff_date IS NULL
															 BEGIN
															 SET @a_error_no = 1.7
																RAISERROR('Group is not active',0,1);
																EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                        SET @s_sub_error = 'Y';
																END							
    
 IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
                                                              RAISERROR('Group not active as of Sub plan eff_date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                 IF NOT EXISTS ( SELECT
                                                              *
                                                              FROM
                                     dbo.rel_gppl (NOLOCK)
                                                              WHERE
                           group_id = @def_group_id
                                                              AND plan_id = @def_plan_id )
															  BEGIN
															  SET @a_error_no = 139
                                                              RAISERROR('Missing Sub Group/Plan Association',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                                       SET @d_gppl_eff = NULL;
                                                     SET @d_gppl_exp = NULL;
                                                              SET @SWV_cursor_var17 = CURSOR  FOR SELECT eff_date, exp_date
							
                                       FROM dbo.rel_gppl (NOLOCK)
              WHERE group_id = @def_group_id
                                       AND plan_id = @def_plan_id
                                       AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
							(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
                                       ORDER BY eff_date DESC,exp_date;
      OPEN @SWV_cursor_var17;
                                  FETCH NEXT FROM @SWV_cursor_var17 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                          WHILE @@FETCH_STATUS = 0
                                                  BEGIN
                                                              GOTO SWL_Label37;
                                                              FETCH NEXT FROM @SWV_cursor_var17 INTO @d_gppl_eff,
          @d_gppl_exp;
                      END;
                                             SWL_Label37:
                                                              CLOSE @SWV_cursor_var17;
                                     IF @d_gppl_eff IS NULL
															  BEGIN
															  SET @a_error_no = 140
                                                            RAISERROR('Missing Active Group/Plan as of Sub''s plan effective date',0,1);
															EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                    
    IF @n_ffs_plan = 0
                                                              BEGIN
       
                  IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                                              
                                                              IF @t_facility_id IS NULL
                                        IF @n_facility_id IS NOT NULL
                                                              BEGIN
                                   SET @as_facility_id = @n_facility_id;
                                                              
                                   
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                         @t_sir_id,
                                                              @as_facility_id,
                                                              @def_plan_id,
                                                              @t_plan_eff_date,
        0;
                                                              IF @n_error_no < 0
                  BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                              
                                                    
    EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @as_facility_id,
                                                @def_plan_id,
                                @t_plan_eff_date,
                                                              1;
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                                                              END;
                                  END;
                                                              ELSE
        BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                              
                                                              
                     EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                         @as_facility_id,
                                                              @def_plan_id,
                                                              @t_plan_eff_date,
                 1;
                                     IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                             END;
										
                                                        ELSE
                        BEGIN
                                                      
                                                       SET @as_facility_id = @t_facility_id;

                                                     
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @as_facility_id,
                   @def_plan_id,
                                                              @t_plan_eff_date,
                                                              1;
                                                IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                               END;
                 END;
 ELSE
                                                              IF @n_facility_id IS NOT NULL
       BEGIN
                                                              SET @as_facility_id = @n_facility_id;
                                                              
                                                              
     EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                    @t_sir_id,
                                                              @as_facility_id,
                                        @def_plan_id,
                                                              @t_plan_eff_date,
                                                   0;
                                                              IF @n_error_no < 0
                                                              BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                              
                 
                                                          EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
  @t_sir_id,
                                                              @def_facility_id,
                                                              @def_plan_id,
                                                              @t_plan_eff_date,
    1;
                                                              IF @n_error_no < 0
                                           SET @s_sub_error = 'Y';
                                                   END;
                                                              END;
                   ELSE
                                                              BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                         
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @def_facility_id,
                                                   @def_plan_id,
             @t_plan_eff_date,
                                                              1;
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
       END;
									
                                                      END;
                                              ELSE
                           SET @as_facility_id = NULL;
							  -- END OF "IF n_ffs_plan = 0 THEN"

        IF @s_sub_error = 'N'
								--LET as_action_code = "SR";
                                        BEGIN
                                                              IF @as_action_code = 'GX'
                                                              BEGIN
                          
															IF @n_has_d_plan_term = 'Y'
                                                              SET @s_transfer_dep_gp = 'Y';
									
                                     
     EXECUTE @n_error_no = dbo.dlp_elig_sub_xfrgp @a_batch_id,
                                                              @t_sir_id,
                                                              @as_member_id,
                              @t_plan_eff_date;
  IF @n_error_no <= 0
															  BEGIN
															  SET @a_error_no = 224
                      RAISERROR('Fail to create term sub records for sub group transfer',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                    @a_error_no;
										 IF @i_fatal <> 1
                                       SET @s_sub_error = 'Y';
															  END
                                                              END;
								
                        
                                                             EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
  @as_action_code,
                                                              @t_plan_eff_date;
                                            END;
   END;  -- END OF "IF s_sub_error = "N" THEN"
                                                              END;  -- END OF "IF n_count_gp = 1 THEN"
					  -- END OF "IF n_count = 0 THEN"
						 -- for "Same Group, Diff Plan"

                                                              IF @n_count > 1
        BEGIN
                                                              
                  IF @n_has_multiple_gp != 'Y'
															  BEGIN
															  SET @a_error_no = 136
                                                              RAISERROR('Can''t do Subscriber'' Plan Change',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
              @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
                                                              ELSE
                        BEGIN
                                                       SELECT
                                                              @d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                              FROM
                    dbo.group_status (NOLOCK)
                                                              WHERE
                                                              group_id = @def_group_id
                                                              AND group_status = 'A4'
                      AND exp_date IS NULL;
                                         
                                      IF @d_gp_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 137
                                                              RAISERROR('Group is not active',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                    @a_error_no;
										 IF @i_fatal <> 1
                                    SET @s_sub_error = 'Y';
															  END
							
                                                              
                    IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
      RAISERROR('Group is not active as of Sub plan eff_date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
             SET @s_sub_error = 'Y';
															  END
							
                                                              IF NOT EXISTS ( SELECT
                                    *
                                         FROM
                                     dbo.rel_gppl (NOLOCK)
                                                              WHERE
       group_id = @def_group_id
        AND plan_id = @def_plan_id )
											   BEGIN
											   SET @a_error_no = 139
      RAISERROR('Missing Subscriber Group/Plan Association',0,1);
	  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
               SET @d_gppl_eff = NULL;
                SET @d_gppl_exp = NULL;
                                                              SET @SWV_cursor_var18 = CURSOR  FOR SELECT eff_date, exp_date
							
                   FROM dbo.rel_gppl (NOLOCK)
                       WHERE group_id = @def_group_id
                                       AND plan_id = @def_plan_id
                                       AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
							(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
                                       ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var18;
                                                              FETCH NEXT FROM @SWV_cursor_var18 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                                     WHILE @@FETCH_STATUS = 0
    BEGIN
                                                              GOTO SWL_Label38;
                                                              FETCH NEXT FROM @SWV_cursor_var18 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
              END;
                                                              SWL_Label38:
           CLOSE @SWV_cursor_var18;
                                                              IF @d_gppl_eff IS NULL
															  BEGIN
															  SET @a_error_no = 140
                                                              RAISERROR('Missing Active Group/Plan as of Sub''s plan effective date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                   @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                           SET @s_sub_error = 'Y';
															  END
							

--  Make sure that new plan add/change is acceptable to Group's definition.
   
                             SET @SWV_func_DLP_PLAN_XFER_par0 = @t_plan_eff_date;
                                                              EXECUTE dbo.dlp_plan_xfer @n_member_id,
          @def_group_id,
                                                             @def_plan_id,
      @SWV_func_DLP_PLAN_XFER_par0,
                                                              @d_valid_status OUTPUT,
                                                              @as_action_code OUTPUT;
                             IF @d_valid_status = 0
															  BEGIN
															  SET @a_error_no = 141
                           RAISERROR('Group Insurance Count does not allow for another Plan Add',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                      IF @d_valid_status = -1
															  BEGIN
															  SET @a_error_no = 136
              RAISERROR('Ambiguous existing records.  Don''t know which record to terminate',0,1);
			  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                                              
                                IF @n_ffs_plan = 0
                                                              BEGIN
                            
                                       IF @n_has_facility_id = 'Y'
                             BEGIN
                                                              
                                                              IF @t_facility_id IS NULL
                          SET @as_facility_id = @def_facility_id;
    ELSE
                               BEGIN
                                                              
                                                              SET @as_facility_id = @t_facility_id;
                                                              END;
									
                                                              
                                                              
        EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                    @t_sir_id,
                                                              @as_facility_id,
                                              @def_plan_id,
                                                              @t_plan_eff_date,
                                                              1;
                               IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                                                              END;
                           ELSE
                                                              BEGIN
                                                              SET @as_facility_id = @def_facility_id;
                                                     
                    
      EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @as_facility_id,
                                                              @def_plan_id,
                           @t_plan_eff_date,
                                                              1;
                                                             IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                                                              END;
              END;
							
           IF @s_sub_error = 'N'
								--LET as_action_code = "SR";
                                          BEGIN
                                                              
                                                              
                                    EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                    @t_sir_id,
                                                              @as_action_code,
                                                  @t_plan_eff_date;
                                                              END;
                                                              END;
                            END;  -- END OF "IF n_has_multiple_gp != "Y" THEN"
					  -- END OF "IF n_count > 1 THEN"

                                            IF @n_count = 1
                                                              BEGIN
                                                              
                                                       IF @n_has_multiple_gp != 'Y'
BEGIN
                                               
                         IF @n_eff_gr_pl > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 150
															    RAISERROR('Current Existing Plan is effective in the future',0,1);
																EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
     SET @s_sub_error = 'Y';
																END
							
                                                              IF @n_exp_gr_pl IS NOT NULL
                                                 BEGIN
                                             
                                                              IF @n_exp_gr_pl > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 151
    RAISERROR('Current Existing Plan is expired after plan eff_date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
								
                                                              SET @as_action_code = 'SR';
                                                              END;
                                             ELSE
                         SET @as_action_code = 'PC';
                                                              END;
                                                              ELSE

-- Make sure that new plan add/change is acceptable to Group's definition.
                                                              BEGIN
                                                              
                          SET @SWV_func_DLP_PLAN_XFER_par1 = @t_plan_eff_date;
                                    EXECUTE dbo.dlp_plan_xfer @n_member_id,
                                                              @def_group_id,
                                                              @def_plan_id,
                                                              @SWV_func_DLP_PLAN_XFER_par1,
                       @d_valid_status OUTPUT,
@as_action_code OUTPUT;
                                                              IF @d_valid_status = 0
															  BEGIN
															  SET @a_error_no = 141
                RAISERROR('Group Insurance Count does not allow for another Plan Add', 16,1);
				EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
  @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
							
                                                              IF @d_valid_status = -1
															  BEGIN
															  SET @a_error_no = 136
                                                              RAISERROR('Ambiguous existing records.  Don''t know which record to terminate',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                        SET @s_sub_error = 'Y';
															  END
                                 END;
--Original code:
--							LET as_action_code = "SR";

						
                                                              SELECT
 @d_gp_eff_date = eff_date ,
                                        @d_gp_exp_date = exp_date
                                                              FROM
                                       dbo.group_status (NOLOCK)
                                                              WHERE
                                        group_id = @def_group_id
                                                              AND group_status = 'A4'
                                        AND exp_date IS NULL;
                                                              
                                                  IF @d_gp_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 137
                                                RAISERROR('Group is not active',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
						
                                
                               IF @d_gp_eff_date > @t_plan_eff_date
															  BEGIN
															  SET @a_error_no = 138
                                                RAISERROR('Group is not active as of Sub plan eff_date',16,1);
												EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                         @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
																END
                                                      IF NOT EXISTS ( SELECT
              *
             FROM
                                                              dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                              group_id = @def_group_id
   AND plan_id = @def_plan_id )
															  BEGIN
															  SET @a_error_no = 139
                                                              RAISERROR('Missing Subscriber Group/Plan Association',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                       SET @s_sub_error = 'Y';
															  END
						
                                                              SET @d_gppl_eff = NULL;
                                              SET @d_gppl_exp = NULL;
                                                              SET @SWV_cursor_var19 = CURSOR  FOR SELECT eff_date, exp_date
						
       FROM dbo.rel_gppl (NOLOCK)
                                    WHERE group_id = @def_group_id
           AND plan_id = @def_plan_id
                          AND eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) AND
						(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_eff_date)) OR exp_date IS NULL)
                                    ORDER BY eff_date DESC,exp_date;
                                                           OPEN @SWV_cursor_var19;
                                                              FETCH NEXT FROM @SWV_cursor_var19 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                               WHILE @@FETCH_STATUS = 0
                                                          BEGIN
           GOTO SWL_Label39;
     FETCH NEXT FROM @SWV_cursor_var19 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                                            END;
                                        SWL_Label39:
                                                              CLOSE @SWV_cursor_var19;
															 IF @d_gppl_eff IS NULL
															 BEGIN
															 SET @a_error_no = 140
                                                    RAISERROR('Missing Active Group/Plan as of Sub''s plan effective date',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
            @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
						
                                                      
                                 IF @n_ffs_plan = 0
                                                     BEGIN
                                                              
                                                              IF @n_has_facility_id = 'Y'
   BEGIN
                                                              
                                                IF @t_facility_id IS NULL
                                                              BEGIN
        SET @SWV_cursor_var20 = CURSOR  FOR SELECT eff_date, exp_date, facility_id
									
                                             FROM dbo.rlplfc (NOLOCK)
                     WHERE member_id = @n_member_id AND
                              mb_gr_pl_id = @n_mb_gr_pl_id
   ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var20;
                                                              FETCH NEXT FROM @SWV_cursor_var20 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                              @as_facility_id;
                                                              WHILE @@FETCH_STATUS = 0
                BEGIN
                           GOTO SWL_Label40;
                                                              FETCH NEXT FROM @SWV_cursor_var20 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                              @as_facility_id;
                END;
                                                              SWL_Label40:
                                                              CLOSE @SWV_cursor_var20;
                                                             IF @as_facility_id IS NOT NULL
                                       BEGIN
                                                              
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
          @as_facility_id,
                          @def_plan_id,
                                                              @t_plan_eff_date,
   0;
                                                              END;
                                                              ELSE
     SET @n_error_no = -1;
									
                                                              IF @n_error_no < 0
                                                              BEGIN
                                                      SET @as_facility_id = @def_facility_id;
                                                              
                                                             
                                           EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                         @t_sir_id,
                                                              @as_facility_id,
                                                          @def_plan_id,
                                                              @t_plan_eff_date,
                                                              1;
                                      IF @n_error_no < 0
        SET @s_sub_error = 'Y';
                                                END;
         END;
                                                              ELSE
                                                              BEGIN
                        
                                                              SET @as_facility_id = @t_facility_id;
                          

                                EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @as_facility_id,
      @def_plan_id,
                                                 @t_plan_eff_date,
        0;
                                                              IF @n_error_no < 0
                                     BEGIN
                                SET @as_facility_id = @def_facility_id;
                    
                                                              
                                               EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                      @t_sir_id,
                                                          @as_facility_id,
                                                              @def_plan_id,
                                                            @t_plan_eff_date,
                                                             1;
                                                              IF @n_error_no < 0
                             SET @s_sub_error = 'Y';
              END;
                                                              END;
                                                              END;
             ELSE
                                                              BEGIN
                                                              SET @d_fc_eff = NULL;
                                                              SET @d_fc_exp = NULL;
                                                              SET @SWV_cursor_var21 = CURSOR  FOR SELECT eff_date, exp_date, facility_id
								
                                          FROM dbo.rlplfc (NOLOCK)
                           WHERE member_id = @n_member_id AND
                                          mb_gr_pl_id = @n_mb_gr_pl_id AND
                   eff_date <= @t_fac_eff_date  AND
								(exp_date > @t_fac_eff_date OR exp_date IS NULL)
                                    ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var21;
                                                    FETCH NEXT FROM @SWV_cursor_var21 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                              @as_facility_id;
                                                              WHILE @@FETCH_STATUS = 0
                               BEGIN
   GOTO SWL_Label41;
                                                              FETCH NEXT FROM @SWV_cursor_var21 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                 @as_facility_id;
             END;
                                                              SWL_Label41:
                                                              CLOSE @SWV_cursor_var21;
   IF @as_facility_id IS NOT NULL
                                            BEGIN
                                                              
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                 @t_sir_id,
                                 @as_facility_id,
                                          @def_plan_id,
                                         @t_plan_eff_date,
                            0;
                                            END;
                                                              ELSE
                         SET @n_error_no = -1;
								
                                     IF @n_error_no < 0
                                                              BEGIN
   SET @as_facility_id = @def_facility_id;
                                                              
                                               ;
EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @t_sir_id,
                                                              @as_facility_id,
                                                              @def_plan_id,
                                                    @t_plan_eff_date,
  1;
                                                              IF @n_error_no < 0
             SET @s_sub_error = 'Y';
                           END;
                                                              END;
                                                  END;
                                ELSE
                                                              SET @as_facility_id = NULL;
						  -- END OF "IF n_ffs_plan = 0 THEN"

             IF @s_sub_error = 'N'
                                                              BEGIN
                                                          
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                     @as_action_code,
             @t_plan_eff_date;
                                                       END;
						
                                                              
                                                           IF @n_has_d_plan_term = 'Y'
                                                              IF @as_action_code = 'PC'
                                                              SET @s_change_dep_pc = 'Y';
								--get dep to change plan
 							
                                                              END;
                                                              END;  -- END OF "IF n_count = 1 THEN"

                                           END;  -- END OF "IF n_count = 0 THEN" for
					-- for Tape Type Group, Plan, Plan Eff Date

    ELSE -- else of "IF n_count = 0 THEN", for matching GP, PL, Process Date, and "N"
 BEGIN
                                    SET @as_plan_eff_date = @n_eff_gr_pl;
                                                              SET @as_plan_term_date = @n_exp_gr_pl;
                 IF @n_exp_gr_pl IS NULL
                                                              BEGIN
                                                              SET @SWV_cursor_var22 = CURSOR  FOR SELECT rate_code, eff_rt_date
					
                                 FROM dbo.rlmbrt (NOLOCK)
                                 WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND exp_rt_date IS NULL
                                 ORDER BY 2 DESC;
  OPEN @SWV_cursor_var22;
              FETCH NEXT FROM @SWV_cursor_var22 INTO @n_rate_code,
                                                           @n_eff_rt_date;
   WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                GOTO SWL_Label42;
                                                              FETCH NEXT FROM @SWV_cursor_var22 INTO @n_rate_code,
                                            @n_eff_rt_date;
                                                              END;
  SWL_Label42:
                                  CLOSE @SWV_cursor_var22;
                                                              IF ( @n_rate_code IS NULL
                                                              OR @n_rate_code = ''
                                                              )
                 OR @n_eff_rt_date IS NULL
															  BEGIN
															  SET @a_error_no = 237
                                                              RAISERROR('Sub has no active rate code',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
   SET @s_sub_error = 'Y';
															  END
                                                     ELSE
 BEGIN
                                                              
                                                              IF @n_has_rate_code != 'Y'
                                                              BEGIN
     SET @t_rate_code = @n_rate_code;
                                                              
                                                              END;
                                         END;
					
                    SET @as_facility_id = NULL;
                                                              SET @d_fc_eff = NULL;
       SET @d_fc_exp = NULL;
                                                              SET @SWV_cursor_var23 = CURSOR  FOR SELECT eff_date, exp_date, facility_id
					
     FROM dbo.rlplfc (NOLOCK)
                           WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
                            member_id = @n_member_id AND
                                 exp_date IS NULL
                                 ORDER BY eff_date DESC,exp_date DESC;
                                                 OPEN @SWV_cursor_var23;
       FETCH NEXT FROM @SWV_cursor_var23 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                              @as_facility_id;
                                     WHILE @@FETCH_STATUS = 0
                                                              BEGIN
                                                              GOTO SWL_Label43;
                                                              FETCH NEXT FROM @SWV_cursor_var23 INTO @d_fc_eff,
            @d_fc_exp,
     @as_facility_id;
                                                              END;
   SWL_Label43:
      CLOSE @SWV_cursor_var23;
                                                              IF @d_fc_eff IS NULL
															  BEGIN
															  SET @a_error_no = 171
                                                              RAISERROR('Subscriber has no active fc',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
              @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
					
                            SET @as_fac_eff_date = @d_fc_eff;
           
               IF @n_ffs_plan = 0
				BEGIN
				
                                                              
			IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                                              
                                                              IF @t_facility_id IS NOT NULL
           BEGIN
                
                                                              IF @as_facility_id != @t_facility_id
    BEGIN
                                    
                                                              IF @d_fc_eff <= CONVERT(DATE, CONVERT(VARCHAR, @t_fac_eff_date))
                                                              BEGIN
                                                       
                                                              
             
          EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
     @t_sir_id,
             @t_facility_id,
                  @def_plan_id,
       @t_fac_eff_date,
                                                              1;
                                             IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
                                                              ELSE
                                                              BEGIN
                                                              
SET @as_fac_eff_date = CONVERT(DATE, CONVERT(VARCHAR, @t_fac_eff_date));
                     

                                   EXECUTE dbo.get_xfer_date @as_facility_id,
                                                              @t_facility_id,
                       @d_fc_eff,
                                                              @t_fac_eff_date,
                                                              @SWV_get_xfer_date OUTPUT;
                                                              SET @t_fac_eff_date = @SWV_get_xfer_date;
                                                              
                      
                                                SET @as_facility_id = @t_facility_id;
                                          SET @as_action_code = 'FX';
                               
                                  
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @t_fac_eff_date;
                                                              END;
               END;
           END;
                                      END;
               END;
                       END;
					
                                                              IF @s_sub_error = 'N'
                                                              AND ( @as_action_code IS NULL
                                                       OR @as_action_code = ''
                              )
                                                              BEGIN
                               SET @as_action_code = 'GI';
                                                              
                                                              
              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @t_fac_eff_date;
                            END;
                                         END;
                               ELSE
															  BEGIN
															  SET @a_error_no = 164
                                                              RAISERROR('Subscriber is already terminated',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
END;  -- end of "IF n_exp_gr_pl is null THEN"

			  -- end of "IF n_count = 0 THEN", for matching GP, PL, Process Date, and "N"

                                END;
                                    END; -- 4

 ELSE--when member with plan_term_date
                                                BEGIN
                                                    
                                                  SET @SWV_func_DLP_MBGRPL_INFO_par6 = @t_plan_term_date;
                      EXECUTE dbo.dlp_mbgrpl_info @def_group_id,
                                   @def_plan_id,
                                                        @n_member_id,
                                                        @SWV_func_DLP_MBGRPL_INFO_par6,
                                                        'N', @n_count OUTPUT,      @n_mb_gr_pl_id OUTPUT,    @n_group_id OUTPUT,
                                                        @n_plan_id OUTPUT,
                                 @n_sub_in_plan OUTPUT,
                                                        @n_eff_gr_pl OUTPUT,
  @n_exp_gr_pl OUTPUT;
                                                    
     
                                                    EXECUTE dbo.dlp_bu_elig_subnpl @n_count,
                                                        @t_sub_in_plan,
                                   @n_sub_in_plan,
                                           @a_batch_id, @i_sp_id,
               @i_sir_def_id,
                                                        @t_sub_sir_id,
                                                        @SWV_dlp_bu_elig_subnpl OUTPUT;
                                              SET @t_sub_in_plan = @SWV_dlp_bu_elig_subnpl;
     
                                                    BEGIN
                                                        DECLARE @SWV_cursor_var24 CURSOR;
                                                     IF @n_count = 0
														BEGIN
														SET @a_error_no = 223
                      RAISERROR('Can''t find active subscriber to be terminated',0,1);
					  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                 @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
					  END
			
                                                    IF @n_count > 1
														BEGIN
														SET @a_error_no = 153
                                                            RAISERROR('Mulitple Existing Active Member records to be terminated',0,1);
															EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															END
			
                         
                                                        IF @t_plan_eff_date != @n_eff_gr_pl
                                                         BEGIN
   SET @t_plan_eff_date = @n_eff_gr_pl;
                                                              
                 END;
			
                           IF @n_group_id != @def_group_id
														BEGIN
														SET @a_error_no = 160
          RAISERROR('Active with different Group',0,1);
															EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															END
			
                                                        IF @n_plan_id != @def_plan_id
														BEGIN
														SET @a_error_no = 161
                     RAISERROR('Active with diffent Plan',0,1);
															EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
              @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															END
			
                                                        IF @n_exp_gr_pl IS NOT NULL
                            BEGIN
                                                              
                                      IF @n_exp_gr_pl = @t_plan_term_date
                                                              SET @as_action_code = 'GI';
                                                              ELSE
															  BEGIN
															  SET @a_error_no = 252
                         RAISERROR('Sub already terminated with diff date',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
                                                            END;
                                 ELSE
BEGIN
                                                              IF NOT EXISTS ( SELECT
                                                              *
        FROM
              dbo.rlmbrt (NOLOCK)
                                                              WHERE
                                                              mb_gr_pl_id = @n_mb_gr_pl_id
        AND eff_rt_date <= @t_plan_term_date
                                                              AND exp_rt_date IS NULL )
															  BEGIN
															  SET @a_error_no = 162
                                                              RAISERROR('No Active Subscriber Rate Code',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
               @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
				

						--	IF n_ffs_plan = 0 THEN
                                                              SET @n_eff_date = NULL;
                                                SET @n_exp_date = NULL;
                                                              SET @n_facility_id = NULL;
                                                              SET @SWV_cursor_var24 = CURSOR  FOR SELECT facility_id, eff_date , exp_date
				
                              FROM dbo.rlplfc (NOLOCK)
                              WHERE mb_gr_pl_id = @n_mb_gr_pl_id AND
                              member_id = @n_member_id AND
              eff_date <= CONVERT(DATE,CONVERT(VARCHAR,@t_plan_term_date)) AND
				(exp_date > CONVERT(DATE,CONVERT(VARCHAR,@t_plan_term_date)) OR exp_date IS NULL)
                              ORDER BY eff_date DESC,exp_date;
          OPEN @SWV_cursor_var24;
                                                              FETCH NEXT FROM @SWV_cursor_var24 INTO @n_facility_id,
                                            @n_eff_date,
                                                              @n_exp_date;
                                                              WHILE @@FETCH_STATUS = 0
                                         BEGIN
                                                              GOTO SWL_Label44;
   FETCH NEXT FROM @SWV_cursor_var24 INTO @n_facility_id,
                                                              @n_eff_date,
                                                              @n_exp_date;
    END;
                                   SWL_Label44:
 CLOSE @SWV_cursor_var24;
                                                              IF @n_eff_date IS NULL
															  BEGIN
															  SET @a_error_no = 163
                                                              RAISERROR('Subscriber has no active fac record',0,1);
															  EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
															  END
				
                                    SET @as_facility_id = @n_facility_id;
                                                              SET @as_fac_eff_date = @n_eff_date;
                  SET @as_plan_eff_date = @n_eff_gr_pl;
                                                              SET @as_action_code = 'ST';
                                                            END;
			
                                                        IF @s_sub_error = 'N'
                                              BEGIN
                                            
                                                   EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                   @t_sir_id,
          @as_action_code,
                                                              @t_plan_term_date;
                                                            END;
			
                                                    END;
                                                END;
                                        END;   --  End of "if t_plan_term_date is null"

             END;  --  End of "if n_mb_count = 1"

	  --  End of "if s_clean_err = "Y""
		
							
                            IF @s_sub_error = 'N'
                                UPDATE  dbo.dls_elig
                                SET     dls_member_id = @as_member_id ,
                                        dls_sub_id = @as_sub_id ,
                                        dls_group_id = @def_group_id ,
          dls_plan_id = @def_plan_id ,
                                        plan_eff_date = @as_plan_eff_date ,
                                        plan_term_date = @as_plan_term_date ,
                                        facility_eff_date = @as_fac_eff_date ,
                                        rate_code = @t_rate_code ,
                                        facility_id = @as_facility_id ,
               dls_action_code = @as_action_code ,
									 dls_status = 'P'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
ELSE
                                UPDATE  dbo.dls_elig
                                SET     dls_member_id = @as_member_id ,
                                        dls_sub_id = @as_sub_id ,
                                        dls_group_id = @def_group_id ,
                      dls_plan_id = @def_plan_id ,
                                        dls_status = 'E'
           WHERE   dls_batch_id = @a_batch_id
   AND dls_sir_id = @t_sir_id;
	
	-- trace "dlp_bu_eligibility():  Line 1835.";
                            
                            EXECUTE @n_error_no = dbo.dlp_bu_dep_elig @a_batch_id,@t_sub_sir_id, @n_sub_id, @n_mb_gr_pl_id;
         IF @n_error_no = 1000
                                BEGIN
								--If @@TRANCOUNT > 0 
								--ROLLBACK; 

								  -- BEGIN TRAN
                                    
                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,@i_sp_id, @i_sir_def_id, @t_sir_id,@n_error_no;
                                   --COMMIT; 
                                 GOTO SWL_Label23;
                         END;
	

	-- trace"dlp_bu_eligibility():  Line 1846.";
	--20130419$$cs
	--IF s_sub_error = "Y" or n_error_no <= 0 THEN
               IF ( @s_sub_error = 'Y' )
                                BEGIN
                                    SET @s_sub_error = 'Y';
                      
                                    EXECUTE @n_error_no = dbo.dlp_set_family_err @a_batch_id,@t_sub_sir_id;
                    END;
		--		COMMIT WORK;
		--		CONTINUE FOREACH;
	
                            IF @s_sub_error != 'Y'
                                BEGIN
                                    BEGIN
                                        IF @s_change_dep_pc = 'Y'
                                            BEGIN
                   SET @n_error_no = 1;
				--this procedure call when subscriber action code is plan change and
				--dep_plan_term option is on, then need to pull all deps info from
				--current plan who are not in the tape to transfer to the new plan

                                                

                                                SET @SWV_func_DLP_ELIG_DEP_PLCH_par0 = @t_plan_eff_date;
                                                EXECUTE @n_error_no = dbo.dlp_elig_dep_plch @a_batch_id,@n_mb_gr_pl_id,@t_sub_sir_id, @n_sub_id,@SWV_func_DLP_ELIG_DEP_PLCH_par0;
                                                IF @n_error_no <= 0
												BEGIN
												SET @a_error_no = 600
                                    RAISERROR('Failed to do dep plan change',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
													END
                                            END;
			
     IF @s_transfer_dep_gp = 'Y'
                                            BEGIN
                                                SET @n_error_no = 1;
                       
                                                
                                            SET @SWV_func_DLP_ELIG_TFR_DEP_par0 = @t_plan_eff_date;
                                                EXECUTE @n_error_no = dbo.dlp_elig_tfr_dep @a_batch_id,
                                                    @n_mb_gr_pl_id,
                                                    @t_sub_sir_id, @n_sub_id,
                                                    @SWV_func_DLP_ELIG_TFR_DEP_par0;
                                            
                                                IF @n_error_no <= 0
												BEGIN
												SET @a_error_no = -700
           RAISERROR('Failed to do dep group change',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
													END
                       END;
			
                                        
                                        IF @n_has_d_plan_term != 'Y'
                                            BEGIN
                                                SET @n_error_no = 1;
                                                
                                                
                                        SET @SWV_func_DLP_ELIG_DEP_TERM_par0 = CONVERT(DATE, CONVERT(VARCHAR, @d_process_exp_per));
               EXECUTE @n_error_no = dbo.dlp_elig_dep_term @a_batch_id,
                                                    @t_sub_sir_id,
                                                    @n_mb_gr_pl_id,
                                                    @SWV_func_DLP_ELIG_DEP_TERM_par0;
                                                    
                           IF @n_error_no <= 0
						   BEGIN
						   SET @a_error_no = 702
                                                    RAISERROR('Failed to term dependent who are not in tape',0,1);
													EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
													END
                                END;
			
			
			-- trace"dlp_bu_eligibility(): Line 1890.";
                                        SET @n_error_no = 1;
                               
                                        
                                        EXECUTE @n_error_no = dbo.dlp_elig_cal_rate @a_batch_id,
                    @t_sub_sir_id, @n_sub_id,
                                            @n_has_rate_code;
                      
                                        IF @n_error_no <= 0
										BEGIN
										SET @a_error_no = 701
                                        RAISERROR('Failed during rate code calculation',0,1);
										EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
											END
			
                                    END;

		-- trace"dlp_bu_eligibility():  Line 1898";
                                    IF @n_error_no < 0
                                        BEGIN
                                            
                                 EXECUTE @n_error_no = dbo.dlp_set_family_err @a_batch_id,
                                                @t_sub_sir_id;
                                                
                                        END;
                                END;
					
					SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND BatchId = @a_batch_id AND Module_Id = 3

                            IF @s_sub_error != 'Y'
                                BEGIN
                                    
                                    SET @n_succ_count = @n_succ_count + 1;
									
									UPDATE GlobalVar
									SET VarValue = @n_succ_count
									WHERE VarName ='n_succ_count' AND BatchId = @a_batch_id AND Module_Id = 3
       
                                END;
					
						SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND BatchId = @a_batch_id AND Module_Id = 3
						SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND BatchId = @a_batch_id AND Module_Id = 3

                            IF @n_sub_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
										tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = CAST(@n_process_count AS INT) - CAST(@n_succ_count AS INT)
                                WHERE   bat_statistics_id = @i_statistics_id;
	
                            --COMMIT; 
                        END TRY
                        BEGIN CATCH
						--If @@TRANCOUNT > 0
						--ROLLBACK

						If ERROR_NUMBER() = 50000
						BEGIN
						 EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        @a_error_no;
										 IF @i_fatal <> 1
                              SET @s_sub_error = 'Y';
						END
						ELSE
						BEGIN
                            SET @i_error_no = ERROR_NUMBER();
              SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
    SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
		
                            IF @i_error_no IN ( -244, -245, -246 )
        BEGIN
								--If @@TRANCOUNT > 0
        --     ROLLBACK; 
        --                       BEGIN TRAN;
                                    
   EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                           @i_sp_id, @i_sir_def_id, @t_sub_sir_id,
                                        1000;
                                   --COMMIT; 
                                END;
                            ELSE
                 BEGIN
                                    
                                    
                                    
                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sir_id,
                                     999;
                                    IF @i_fatal <> 1
                                        SET @s_sub_error = 'Y';
                                END;
								END

								 IF @s_sub_error = 'N'
                                UPDATE  dbo.dls_elig
                                SET     dls_member_id = @as_member_id ,
                                        dls_sub_id = @as_sub_id ,
                                        dls_group_id = @def_group_id ,
          dls_plan_id = @def_plan_id ,
                                        plan_eff_date = @as_plan_eff_date ,
          plan_term_date = @as_plan_term_date ,
                                        facility_eff_date = @as_fac_eff_date ,
                                        rate_code = @t_rate_code ,
                         facility_id = @as_facility_id ,
               dls_action_code = @as_action_code ,
									 dls_status = 'P'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
                            ELSE
                                UPDATE  dbo.dls_elig
                                SET     dls_member_id = @as_member_id ,
          dls_sub_id = @as_sub_id ,
                         dls_group_id = @def_group_id ,
                                        dls_plan_id = @def_plan_id ,
                                        dls_status = 'E'
           WHERE   dls_batch_id = @a_batch_id
   AND dls_sir_id = @t_sir_id;

								
              END CATCH;
                   
                    SWL_Label23:
                    FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_sub_sir_id,
                        @t_subscriber, @t_alt_id, @t_ssn, @t_sub_ssn,
                        @t_sub_alt_id, @t_member_code, @t_last_name,
                  @t_first_name, @t_middle_init, @t_date_of_birth,
                  @t_student_flag, @t_disable_flag, @t_cobra_flag,
@t_address1, @t_address2, @t_city, @t_state, @t_zip,
   @t_zipx, @t_home_phone, @t_home_ext, @t_work_phone,
                        @t_work_ext, @t_rate_code, @t_plan_eff_date,
                        @t_plan_term_date, @t_fac_eff_date, @t_group_id,
                        @t_plan_id, @t_facility_id, @t_def_key, @t_type,
                        @t_new_ssn, @t_src_id, @t_subnew_ssn, @t_subsrc_id,
                        @t_ext_id_col, @t_paperless, @t_email, @t_sub_in_plan,
                        @new_member_id, @new_group_id, @new_plan_id;
                END;
            CLOSE @cSIR;
            IF @a_sir_id = 0
                BEGIN
                    
     IF @n_has_s_plan_term != 'Y'
                        BEGIN
            
                            SET @SWV_func_DLP_ELIG_SUB_TERM_par0 = CONVERT(DATE, CONVERT(VARCHAR, @d_process_exp_per));
                           EXECUTE @n_error_no = dbo.dlp_elig_sub_term @a_batch_id,
                                @SWV_func_DLP_ELIG_SUB_TERM_par0;
                                
                        END;
                END;

         
	 ---Modified for conversion issue against CH001
	 --select @n_succ_count = COUNT(*) FROM dbo.dls_elig (NOLOCK)
  --    WHERE dls_batch_id = @a_batch_id AND dls_status = 'P'

            SET @i_error_count = CAST(@n_process_count AS INT)                - CAST(@n_succ_count AS INT);

		SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND BatchId = @a_batch_id AND Module_Id = 3
		SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND BatchId = @a_batch_id AND Module_Id = 3

            EXECUTE @SWV_dl_upd_statistics = dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @i_error_count;
					
					--IF  EXISTS (SELECT 'X' FROM dbo.dls_elig (NOLOCK)--Fix
					--			  WHERE dls_batch_id = @a_batch_id AND dls_source='A'
					--			  AND ((@a_sir_id > 0 AND dls_sub_sir_id = @a_sir_id) OR (@a_sir_id = 0 AND dls_sir_id > 0))
					--			)
				 -- BEGIN

					--	 SELECT @n_process_count = COUNT(*) FROM dbo.dls_elig (NOLOCK)--Fix
					--	  WHERE dls_batch_id = @a_batch_id AND dls_status <> 'L'
					--	  AND ((@a_sir_id > 0 AND dls_sub_sir_id = @a_sir_id) OR (@a_sir_id = 0 AND dls_sir_id > 0))

					--		 UPDATE  dbo.dl_bat_statistics --Fix
					--			SET     tot_record = @n_process_count ,
					--					  tot_fail_rec = CAST(@n_process_count AS INT) - CAST(@n_succ_count AS INT)
					--			WHERE   bat_statistics_id = @i_statistics_id; 
					--END
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                               + @n_error_count ),
                                                 ' Failed to update statistics');
							IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 3 AND BatchId = @a_batch_id )
							BEGIN
								DELETE FROM GlobalVar WHERE Module_Id = 3 AND BatchId = @a_batch_id
							END

                    RETURN;
   END;


            UPDATE  dbo.dl_cfg_bat_det
    SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished preprocess for Batch ',
              @a_batch_id);

			  IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 3 AND BatchId = @a_batch_id )
				BEGIN
					DELETE FROM GlobalVar WHERE Module_Id = 3 AND BatchId = @a_batch_id
				END


			-- COMMIT TRAN

   RETURN;
            IF ( @do_trace = 1 )
                BEGIN--TRACE statement has no equivalent in MSSQL
--trace off;
                    SET @v_Null = 0;
                END;
        END TRY

      BEGIN CATCH
	  IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 3 AND BatchId = @a_batch_id )
		BEGIN
			DELETE FROM GlobalVar WHERE Module_Id = 3 AND BatchId = @a_batch_id
		END

		--if @@TRANCOUNT>0
		-- ROLLBACK
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
          SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
 SET NOCOUNT OFF;

    END;