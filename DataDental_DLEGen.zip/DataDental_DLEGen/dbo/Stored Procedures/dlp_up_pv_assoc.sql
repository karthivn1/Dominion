﻿CREATE PROCEDURE [dbo].[dlp_up_pv_assoc]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
     

		/*error variable*/
AS
    BEGIN
/*

DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @pvfc_sir_def_name CHAR(18);
        DECLARE @pvfc_proc_name CHAR(18);
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);

        DECLARE @pv_sp_id INT;
        DECLARE @pv_sir_def_id INT;
        DECLARE @pv_config_id INT;
        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @s_batch_status CHAR(1);

        DECLARE @p_sir_id INT;
        DECLARE @p_alt_id CHAR(20);
        DECLARE @p_pv_tax_id CHAR(9);
        DECLARE @p_pv_np_id CHAR(10);
        DECLARE @p_pv_license CHAR(18);
        DECLARE @p_pv_lic_state CHAR(2);
        DECLARE @p_tin CHAR(1);
        DECLARE @p_pv_first_name CHAR(20);
        DECLARE @p_pv_middle_init CHAR(1);
        DECLARE @p_pv_last_name CHAR(30);
        DECLARE @p_discipline CHAR(2);
        DECLARE @p_mal_car CHAR(30);
        DECLARE @p_mal_pol_no CHAR(15);
        DECLARE @p_mal_prac CHAR(10);
        DECLARE @p_mal_amt CHAR(18);
        DECLARE @p_mal_amt_i CHAR(18);
        DECLARE @p_mal_comnt CHAR(50);
        DECLARE @p_dea_no CHAR(15);
        DECLARE @p_dea_cert_dt CHAR(10);
        DECLARE @p_dea_exp_dt CHAR(10);
        DECLARE @p_cds_no CHAR(15);
        DECLARE @p_cds_cert_dt CHAR(10);
        DECLARE @p_cds_exp_dt CHAR(10);
        DECLARE @p_cpr_cert_dt CHAR(10);
        DECLARE @p_cpr_exp_dt CHAR(10);
        DECLARE @p_prim_fc CHAR(40);
        DECLARE @p_school CHAR(50);
        DECLARE @p_grd_date CHAR(10);
        DECLARE @p_degree CHAR(4);
        DECLARE @p_ada_mbr CHAR(1);
        DECLARE @p_district_no CHAR(15);
        DECLARE @p_pv_dob CHAR(10);
        DECLARE @p_print_dir CHAR(1);
        DECLARE @p_race CHAR(2);
        DECLARE @p_gender CHAR(1);
        DECLARE @p_num_yr_prac CHAR(3);
        DECLARE @p_peer_rv CHAR(1);
        DECLARE @p_vendor_id CHAR(20);
        DECLARE @p_pv_stat_eff_date CHAR(10);
        DECLARE @p_fc_assoc_fc_id CHAR(40);
        DECLARE @p_fc_assoc_type CHAR(1);
        DECLARE @p_fc_assoc_eff CHAR(10);
        DECLARE @p_fc_assoc_exp CHAR(10);
        DECLARE @p_pv_lic_eff CHAR(10);
        DECLARE @p_pv_lic_exp CHAR(10);
        DECLARE @p_pv_addr_type CHAR(2);
        DECLARE @p_pv_addr_1 CHAR(30);
        DECLARE @p_pv_addr_2 CHAR(30);
        DECLARE @p_pv_addr_zip CHAR(10);
        DECLARE @p_pv_addr_city CHAR(30);
        DECLARE @p_pv_addr_state CHAR(2);
        DECLARE @p_pv_addr_county CHAR(20);
        DECLARE @p_pv_addr_country CHAR(3);
        DECLARE @p_pv_addr_mail CHAR(1);
        DECLARE @p_pv_con_type CHAR(2);
        DECLARE @p_pv_con_lname CHAR(15);
        DECLARE @p_pv_con_fname CHAR(10);
        DECLARE @p_pv_con_title CHAR(25);
        DECLARE @p_pv_con_phone1 CHAR(10);
        DECLARE @p_pv_con_ext1 CHAR(10);
        DECLARE @p_pv_con_phone2 CHAR(10);
        DECLARE @p_pv_con_ext2 CHAR(10);
        DECLARE @p_pv_con_fax CHAR(10);
        DECLARE @p_dds_fc_id INT;
        DECLARE @p_dds_pv_id INT;
        DECLARE @p_action_code CHAR(2);

        DECLARE @as_action_code CHAR(2);
        DECLARE @as_pv_stat_eff DATE;
        DECLARE @as_fcassoc_eff DATE;
        DECLARE @as_fcassoc_exp DATE;
  DECLARE @i_pv_id INT;
        DECLARE @pvlic_cnt INT;
        DECLARE @i_mal_prac DATE;
        DECLARE @i_mal_amt DECIMAL(16, 2);
        DECLARE @i_mal_amt_i DECIMAL(16, 2);
        DECLARE @i_dea_cert_dt DATE;
        DECLARE @i_dea_exp_dt DATE;
DECLARE @i_cds_cert_dt DATE;
        DECLARE @i_cds_exp_dt DATE;
        DECLARE @i_grd_date DATE;
        DECLARE @i_cpr_cert_dt DATE;
        DECLARE @i_cpr_exp_dt DATE;
        DECLARE @i_pv_dob DATE;
        DECLARE @i_num_yr_prac INT;
        DECLARE @i_fcstat_eff_date DATE;
        DECLARE @i_pv_stat_eff_date DATE;
        DECLARE @i_fc_id INT;
        DECLARE @i_fc_assoc_cnt INT;
        DECLARE @i_fc_assoc_eff DATE;
        DECLARE @i_pv_lic_eff DATE;
        DECLARE @i_fc_assoc_exp DATE;
        DECLARE @i_pv_lic_exp DATE;
        DECLARE @i_zip INT;
        DECLARE @i_zip_id INT;
        DECLARE @i_city CHAR(30);
        DECLARE @i_state CHAR(2);
        DECLARE @i_county CHAR(20);
        DECLARE @i_phone_err CHAR(1);
        DECLARE @i_phone1 INT;
        DECLARE @i_ext1 INT;
        DECLARE @i_phone2 INT;
        DECLARE @i_ext2 INT;
        DECLARE @i_fax INT;

        DECLARE @curr_datetime DATETIME;
        DECLARE @ls_user CHAR(20);
        DECLARE @t_action_date DATE;
        DECLARE @curr_fc_id INT;
        DECLARE @curr_pv_id INT;
        DECLARE @curr_vendor_id INT;
        DECLARE @curr_pvstat_id INT;
        DECLARE @curr_pvstat CHAR(2);
        DECLARE @curr_pvstat_eff DATE;
        DECLARE @curr_assoc_id INT;
        DECLARE @curr_assoc_type CHAR(1);
        DECLARE @curr_assoc_eff DATE;
        DECLARE @curr_assoc_exp DATE;
        DECLARE @tape_assoc_eff DATE;
        DECLARE @tape_assoc_exp DATE;
        DECLARE @tape_pvlic_eff DATE;
        DECLARE @tape_pvlic_exp DATE;

        DECLARE @d_valid_error INT;
        DECLARE @d_error_descr VARCHAR(64);
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @n_process_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @n_in_transaction CHAR(1);
        --DECLARE @cSIR CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @v_Null INT;
		DECLARE @created_by CHAR(15)

        SET NOCOUNT ON;
        BEGIN TRY
            
            SET @pvfc_proc_name = 'up_pv_assoc';
            SET @pvfc_sir_def_name = 'pv_assoc';
            EXECUTE @pv_sp_id = dbo.dl_get_sp_id @a_batch_id, @pvfc_proc_name;
            IF @pv_sp_id IS NULL
                OR @pv_sp_id <= 0
				BEGIN
				SET @a_error_no = 1
                RAISERROR('Invalid SP Name',16,1);
				RETURN
				END
	
            SET @pv_sir_def_id = dbo.dl_get_sir_def_id(@pvfc_sir_def_name);
            IF @pv_sir_def_id IS NULL
                OR @pv_sir_def_id <= 0
				BEGIN
				SET @a_error_no = 2
                RAISERROR('Invalid SIR TABLE Definition',16,1);
				RETURN
				END
	
            SELECT  @pv_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
            
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @pv_sp_id;

					SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
           
            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
         NULL ,
                      NULL ,
                      NULL ,
                     -- ORIGINAL_LOGIN() ,
					 @created_by,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            
            SET @n_process_count = 0;
            SET @n_succ_count = 0;
            SET @n_in_transaction = 'N';
            SET @ls_user = CONCAT('dl', @a_batch_id);


/*
	DELETE FROM dl_action
	WHERE batch_id = a_batch_id AND process_status = "N"
	AND dls_sir_id not in (SELECT dls_sir_id FROM dls_pv_assoc
		WHERE dls_batch_id = a_batch_id and dls_status = "P");

	DELETE FROM dl_log_error
	WHERE config_bat_id = a_batch_id AND sp_id = pv_sp_id
	AND dls_sir_id in (SELECT dls_sir_id FROM dls_pv_assoc
		WHERE dls_batch_id = a_batch_id and dls_status = "P");
*/


/*
            SET @cSIR = CURSOR  FOR SELECT  dls_sir_id, alt_id, pv_tax_id, pv_license, pv_lic_state, tin,
                pv_first_name, pv_middle_init, pv_last_name, discipline,
                mal_car, mal_pol_no, mal_prac, mal_amt, mal_amt_i, mal_comnt,
                dea_no, dea_cert_dt, dea_exp_dt, cds_no, cds_cert_dt,
                cds_exp_dt, cpr_cert_dt, cpr_exp_dt, prim_fc, school, grd_date,
                degree, ada_mbr, district_no, pv_dob, print_dir, race, gender,
                num_yr_prac, peer_rv, vendor, pv_stat_eff_date,
		fc_assoc_fc_id, fc_assoc_type, fc_assoc_eff_date,
		fc_assoc_exp_date, pv_lic_eff_date, pv_lic_exp_date,
		pv_addr_type, pv_addr_1, pv_addr_2, pv_addr_zip, pv_addr_city,
		pv_addr_state, pv_addr_county, pv_addr_country, pv_addr_mail,
--		pv_con_type,
		pv_con_lname, pv_con_fname, pv_con_title,
		pv_con_phone1, pv_con_ext1, pv_con_phone2, pv_con_ext2,
		pv_con_fax, dls_facility_id, dls_provider_id, dls_action_code
        
      FROM dbo.dls_pv_assoc (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'P';
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @p_sir_id, @p_alt_id, @p_pv_tax_id,
                @p_pv_license, @p_pv_lic_state, @p_tin, @p_pv_first_name,
                @p_pv_middle_init, @p_pv_last_name, @p_discipline, @p_mal_car,
                @p_mal_pol_no, @p_mal_prac, @p_mal_amt, @p_mal_amt_i,
                @p_mal_comnt, @p_dea_no, @p_dea_cert_dt, @p_dea_exp_dt,
                @p_cds_no, @p_cds_cert_dt, @p_cds_exp_dt, @p_cpr_cert_dt,
                @p_cpr_exp_dt, @p_prim_fc, @p_school, @p_grd_date, @p_degree,
                @p_ada_mbr, @p_district_no, @p_pv_dob, @p_print_dir, @p_race,
                @p_gender, @p_num_yr_prac, @p_peer_rv, @p_vendor_id,
                @p_pv_stat_eff_date, @p_fc_assoc_fc_id, @p_fc_assoc_type,
                @p_fc_assoc_eff, @p_fc_assoc_exp, @p_pv_lic_eff, @p_pv_lic_exp,
                @p_pv_addr_type, @p_pv_addr_1, @p_pv_addr_2, @p_pv_addr_zip,
                @p_pv_addr_city, @p_pv_addr_state, @p_pv_addr_county,
                @p_pv_addr_country, @p_pv_addr_mail,
--		p_pv_con_type,
                @p_pv_con_lname, @p_pv_con_fname, @p_pv_con_title,
                @p_pv_con_phone1, @p_pv_con_ext1, @p_pv_con_phone2,
                @p_pv_con_ext2, @p_pv_con_fax, @p_dds_fc_id, @p_dds_pv_id,
                @p_action_code;
            WHILE @@FETCH_STATUS = 0
               */
			   
            DECLARE @cSI_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                  alt_id CHAR(20) ,
                  pv_tax_id CHAR(9) ,
                  pv_license CHAR(18) ,
                  pv_lic_state CHAR(2) ,
                  tin CHAR ,
                  pv_first_name CHAR(20) ,
                  pv_middle_init CHAR ,
                  pv_last_name CHAR(30) ,
                  discipline CHAR(2) ,
                  mal_car CHAR (30),
                  mal_pol_no CHAR(15) ,
                  mal_prac CHAR(10) ,
                  mal_amt CHAR(20) ,
                  mal_amt_i CHAR(20) ,
                  mal_comnt CHAR(50) ,
                  dea_no CHAR(15) ,
                  dea_cert_dt CHAR(10) ,
                  dea_exp_dt CHAR(10) ,
                  cds_no CHAR(15) ,
                  cds_cert_dt CHAR(10) ,
  cds_exp_dt CHAR(10) ,
                  cpr_cert_dt CHAR(10) ,
                  cpr_exp_dt CHAR(10) ,
                prim_fc CHAR(40) ,
                  school CHAR(50) ,
                  grd_date CHAR(10) ,
                  degree CHAR(4) ,
                  ada_mbr CHAR(1) ,
                  district_no CHAR(15) ,
                  pv_dob CHAR(10) ,
                  print_dir CHAR ,
                  race CHAR(2) ,
                  gender CHAR ,
                  num_yr_prac CHAR(11) ,
                  peer_rv CHAR ,
                  vendor CHAR(40) ,
                  pv_stat_eff_date CHAR(10) ,
                  fc_assoc_fc_id CHAR(40) ,
                  fc_assoc_type CHAR ,
                  fc_assoc_eff_date CHAR(10) ,
                  fc_assoc_exp_date CHAR(10) ,
                  pv_lic_eff_date CHAR(10) ,
                  pv_lic_exp_date CHAR(10) ,
                  pv_addr_type CHAR(2) ,
                  pv_addr_1 CHAR(30) ,
                  pv_addr_2 CHAR(30) ,
                  pv_addr_zip CHAR(10) ,
                  pv_addr_city CHAR(30) ,
                  pv_addr_state CHAR(2) ,
                  pv_addr_county CHAR (20),
                  pv_addr_country CHAR(3) ,
                  pv_addr_mail CHAR , 
		--		pv_con_type char,
                  pv_con_lname CHAR(15) ,
                  pv_con_fname CHAR(10) ,
                  pv_con_title CHAR (25),
                  pv_con_phone1 CHAR(14) ,
                  pv_con_ext1 CHAR(5) ,
                  pv_con_phone2 CHAR(14) ,
                  pv_con_ext2 CHAR(5) ,
                  pv_con_fax CHAR(14) ,
                  dls_facility_id INT ,
                  dls_provider_id INT ,
                  dls_action_code CHAR(2)
                );

            INSERT  INTO @cSI_cursor_var1
                    ( dls_sir_id ,
                      alt_id ,
                      pv_tax_id ,
                      pv_license ,
                      pv_lic_state ,
                      tin ,
                      pv_first_name ,
                      pv_middle_init ,
                      pv_last_name ,
                      discipline ,
                      mal_car ,
                      mal_pol_no ,
                      mal_prac ,
                      mal_amt ,
                      mal_amt_i ,
                      mal_comnt ,
                      dea_no ,
                      dea_cert_dt ,
                      dea_exp_dt ,
                      cds_no ,
                      cds_cert_dt ,
                      cds_exp_dt ,
                      cpr_cert_dt ,
                      cpr_exp_dt ,
                      prim_fc ,
                      school ,
                      grd_date ,
                      degree ,
                      ada_mbr ,
                      district_no ,
                      pv_dob ,
                      print_dir ,
                      race ,
                      gender ,
                      num_yr_prac ,
                      peer_rv ,
                      vendor ,
                      pv_stat_eff_date ,
                      fc_assoc_fc_id ,
                      fc_assoc_type ,
                      fc_assoc_eff_date ,
                      fc_assoc_exp_date ,
                      pv_lic_eff_date ,
                      pv_lic_exp_date ,
                      pv_addr_type ,
                      pv_addr_1 ,
                      pv_addr_2 ,
                      pv_addr_zip ,
                      pv_addr_city ,
                      pv_addr_state ,
                      pv_addr_county ,
                      pv_addr_country ,
                      pv_addr_mail ,
--		pv_con_type,
                      pv_con_lname ,
                      pv_con_fname ,
       pv_con_title ,
                      pv_con_phone1 ,
                      pv_con_ext1 ,
                      pv_con_phone2 ,
      pv_con_ext2 ,
						pv_con_fax ,
					 dls_facility_id ,
						dls_provider_id ,
                      dls_action_code
                    )
                    SELECT  dls_sir_id ,
                            alt_id ,
                            pv_tax_id ,
                            pv_license ,
                            pv_lic_state ,
                            tin ,
                            pv_first_name ,
                            pv_middle_init ,
                            pv_last_name ,
                            discipline ,
                            mal_car ,
                            mal_pol_no ,
                            mal_prac ,
                            mal_amt ,
                            mal_amt_i ,
                            mal_comnt ,
                            dea_no ,
                            dea_cert_dt ,
                            dea_exp_dt ,
                            cds_no ,
                            cds_cert_dt ,
                            cds_exp_dt ,
                            cpr_cert_dt ,
                            cpr_exp_dt ,
                            prim_fc ,
                            school ,
                            grd_date ,
                            degree ,
                            ada_mbr ,
                            district_no ,
                            pv_dob ,
                            print_dir ,
                            race ,
                            gender ,
                            num_yr_prac ,
                            peer_rv ,
                            vendor ,
                            pv_stat_eff_date ,
                            fc_assoc_fc_id ,
                            fc_assoc_type ,
                            fc_assoc_eff_date ,
                            fc_assoc_exp_date ,
                            pv_lic_eff_date ,
                            pv_lic_exp_date ,
                            pv_addr_type ,
                            pv_addr_1 ,
                            pv_addr_2 ,
                            pv_addr_zip ,
                            pv_addr_city ,
                            pv_addr_state ,
                            pv_addr_county ,
                            pv_addr_country ,
                            pv_addr_mail ,
--		pv_con_type,
                            pv_con_lname ,
                            pv_con_fname ,
                            pv_con_title ,
                            pv_con_phone1 ,
                            pv_con_ext1 ,
                            pv_con_phone2 ,
                            pv_con_ext2 ,
                            pv_con_fax ,
                            dls_facility_id ,
                            dls_provider_id ,
                            dls_action_code
                    FROM    dbo.dls_pv_assoc (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'P';
            

            DECLARE @cur1_cnt INT ,
                @cur_i INT;
            SET @cur_i = 1;
    --Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @cSI_cursor_var1;
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
					
                    SELECT  @p_sir_id = dls_sir_id ,
                            @p_alt_id = alt_id ,
                            @p_pv_tax_id = pv_tax_id ,
                            @p_pv_license = pv_license ,
                            @p_pv_lic_state = pv_lic_state ,
                            @p_tin = tin ,
                            @p_pv_first_name = pv_first_name ,
                            @p_pv_middle_init = pv_middle_init ,
                            @p_pv_last_name = pv_last_name ,
                            @p_discipline = discipline ,
                            @p_mal_car = mal_car ,
							@p_mal_pol_no = mal_pol_no ,
                            @p_mal_prac = mal_prac ,
                            @p_mal_amt = mal_amt ,
                            @p_mal_amt_i = mal_amt_i ,
                            @p_mal_comnt = mal_comnt ,
                            @p_dea_no = dea_no ,
                            @p_dea_cert_dt = dea_cert_dt ,
                            @p_dea_exp_dt = dea_exp_dt ,
                            @p_cds_no = cds_no ,
                            @p_cds_cert_dt = cds_cert_dt ,
                            @p_cds_exp_dt = cds_exp_dt ,
                            @p_cpr_cert_dt = cpr_cert_dt ,
                            @p_cpr_exp_dt = cpr_exp_dt ,
                            @p_prim_fc = prim_fc ,
                            @p_school = school ,
                            @p_grd_date = grd_date ,
                            @p_degree = degree ,
                            @p_ada_mbr = ada_mbr ,
                            @p_district_no = district_no ,
                            @p_pv_dob = pv_dob ,
                            @p_print_dir = print_dir ,
                            @p_race = race ,
                            @p_gender = gender ,
                            @p_num_yr_prac = num_yr_prac ,
                            @p_peer_rv = peer_rv ,
                            @p_vendor_id = vendor ,
                            @p_pv_stat_eff_date = CASE WHEN ISNULL(pv_stat_eff_date ,'') <>'' then STUFF(STUFF(pv_stat_eff_date ,3,0,'/'),6,0,'/') ELSE pv_stat_eff_date  END ,
                            @p_fc_assoc_fc_id = fc_assoc_fc_id ,
                            @p_fc_assoc_type = fc_assoc_type ,
                            @p_fc_assoc_eff = CASE WHEN ISNULL(fc_assoc_eff_date,'') <>'' then STUFF(STUFF(fc_assoc_eff_date,3,0,'/'),6,0,'/') ELSE fc_assoc_eff_date END ,
                            @p_fc_assoc_exp = CASE WHEN ISNULL(fc_assoc_exp_date ,'') <>'' then STUFF(STUFF(fc_assoc_exp_date ,3,0,'/'),6,0,'/') ELSE fc_assoc_exp_date  END,
                            @p_pv_lic_eff = CASE WHEN ISNULL(pv_lic_eff_date ,'') <>'' then STUFF(STUFF(pv_lic_eff_date ,3,0,'/'),6,0,'/') ELSE pv_lic_eff_date  END  ,
                            @p_pv_lic_exp = CASE WHEN ISNULL(pv_lic_exp_date ,'') <>'' then STUFF(STUFF(pv_lic_exp_date ,3,0,'/'),6,0,'/') ELSE pv_lic_exp_date  END  ,
                            @p_pv_addr_type = pv_addr_type ,
                            @p_pv_addr_1 = pv_addr_1 ,
                            @p_pv_addr_2 = pv_addr_2 ,
                            @p_pv_addr_zip = pv_addr_zip ,
                            @p_pv_addr_city = pv_addr_city ,
                            @p_pv_addr_state = pv_addr_state ,
                            @p_pv_addr_county = pv_addr_county ,
                            @p_pv_addr_country = pv_addr_country ,
                            @p_pv_addr_mail = pv_addr_mail ,
                            @p_pv_con_lname = pv_con_lname ,
                            @p_pv_con_fname = pv_con_fname ,
                            @p_pv_con_title = pv_con_title ,
                            @p_pv_con_phone1 = pv_con_phone1 ,
                            @p_pv_con_ext1 = pv_con_ext1 ,
                            @p_pv_con_phone2 = pv_con_phone2 ,
                            @p_pv_con_ext2 = pv_con_ext2 ,
                            @p_pv_con_fax = pv_con_fax ,
                            @p_dds_fc_id = dls_facility_id ,
                            @p_dds_pv_id = dls_provider_id ,
                            @p_action_code = dls_action_code
                    FROM    @cSI_cursor_var1
                    WHERE   id = @cur_i;
                    BEGIN
					
                        --DECLARE @SWV_cursor_var1 CURSOR;
                        --DECLARE #SWV_cursor_var2 CURSOR;
           BEGIN TRY
                            IF @n_in_transaction = 'N'
                                BEGIN
               
                SET @n_in_transaction = 'Y';
                                END;
		
                            SET @s_error = 'N';
							SELECT  @curr_datetime = GETDATE()
                            FROM    dbo.sysdatetime;
		
--		ELIF p_action_code not in ("PA", "PR", "AA", "AR", "AT", "LR", "NC")
                            IF ( @p_action_code IS NULL
                                 OR @p_action_code = ''
                               )
            OR LEN(@p_action_code) = 0
					BEGIN
						SET @a_error_no = 400				
                               RAISERROR('Action Code is missing',16,1);
							RETURN
							END
                            ELSE
							
                                IF @p_action_code NOT IN ( 'PA', 'PR', 'AA',
                                                           'AR', 'AT', 'NC' )
														   BEGIN
															SET @a_error_no = 410
                                    RAISERROR('Invalid Action Code found',16,1);
									RETURN
				END
                            SET @a_error_no = 420;
                            SELECT  @t_action_date = action_date
                            FROM    dbo.dl_action (NOLOCK)
                            WHERE   batch_id = @a_batch_id
                                    AND dls_sir_id = @p_sir_id
                                    AND action_code = @p_action_code
                                    AND process_status = 'N';
                            
							IF @t_action_date IS NULL
							BEGIN
							SET @a_error_no = 430
                                RAISERROR('Missing Action Eff Date',16,1);
								RETURN
				END
		
		
/* $$ks - 20060906 - PV may have been added already by previous record
*/
		


/*
		ELIF p_action_code = "LR" THEN

				let a_error_no = 950;
				let tape_pvlic_eff = p_pv_lic_eff;

				let a_error_no = 960;
				insert into pv_license (
					pv_licid, pv_id, license, state,
					eff_date, exp_date )
				values (
					0, p_dds_pv_id, p_pv_license,
					p_pv_lic_state, tape_pvlic_eff,
					null );
*/


                            IF @p_action_code = 'PA'
                                BEGIN
                                    IF EXISTS ( SELECT  *
                                                FROM    dbo.providers (NOLOCK)
                                                WHERE   alt_id = @p_alt_id )
                                        BEGIN
                                            SELECT  @curr_pv_id = pv_id
                                            FROM    dbo.providers (NOLOCK)
                                            WHERE   alt_id = @p_alt_id;
                                            
                                        END;
--				RAISE EXCEPTION -746, 500, "PV rec found in DD for Action Code PA"; 
                                    ELSE
									
									
			-- CREATE NEW PROVIDER RECORD
                                        BEGIN
                                            SET @a_error_no = 510;

											IF @p_mal_amt=''
											SET @p_mal_amt =NULL
											
											IF @p_mal_amt_i=''
											SET @p_mal_amt_i =NULL

                                            INSERT  INTO dbo.providers
                                                    (alt_id, 
													tax_id ,
                                                      tin ,
                                                      first_name ,
                                                      middle_init ,
                                                      last_name ,
                                                      discipline ,
                                                      mal_car ,
                                                      mal_pol_no ,
           mal_prac ,
                                                      mal_amt ,
        mal_amt_i ,
   mal_comnt ,
														 dea_no ,
         dea_cert_dt ,
                                                      dea_exp_dt ,
                                                      cds_no ,
                                                      cds_cert_dt ,
                                                      cds_exp_dt ,
                                                      cpr_cert_dt ,
                                                      cpr_exp_dt ,
                                                      prim_fc ,
                                                      school ,
													grd_date ,
													  degree ,
                                                      ada_mbr ,
													 district_no ,
                                                      dob ,
                                                      print_dir ,
                                                      h_user ,
                                                      h_datetime ,
                                                      race ,
                                                      gender ,
                                                      num_yr_prac ,
                                                      peer_rv
                                                    )
                                            VALUES  (@p_alt_id, 
													@p_pv_tax_id ,
                                                      @p_tin ,
                                                      @p_pv_first_name ,
                                                      @p_pv_middle_init ,
                                                      @p_pv_last_name ,
                                                      @p_discipline ,
                                                      @p_mal_car ,
                                                      @p_mal_pol_no ,
                                                      @p_mal_prac ,
                                                      @p_mal_amt ,
                                                      @p_mal_amt_i ,
                                                      @p_mal_comnt ,
                                                      @p_dea_no ,
                                                      @p_dea_cert_dt ,
                                                      @p_dea_exp_dt ,
                                                      @p_cds_no ,
                                                      @p_cds_cert_dt ,
                                                      @p_cds_exp_dt ,
                                                      @p_cpr_cert_dt ,
                                                      @p_cpr_exp_dt ,
                                                      @p_prim_fc ,
                                                      @p_school ,
                                                      @p_grd_date ,
                                                      @p_degree ,
                                                      @p_ada_mbr ,
                                                      @p_district_no ,
                                                      @p_pv_dob ,
                                                      @p_print_dir ,
                                                      @ls_user ,
                                                      @curr_datetime ,
                                                      @p_race ,
                                                      @p_gender ,
                                                      @p_num_yr_prac ,
                                                      @p_peer_rv
                                                    );
				
                                            SELECT  @curr_pv_id = pv_id
FROM    dbo.providers (NOLOCK)
                        WHERE   alt_id = @p_alt_id;
                       
       IF @curr_pv_id IS NULL
											BEGIN
											SET @a_error_no = 510
                                                RAISERROR('Provider Insertion Error',16,1);
												RETURN
											END
				
                                            SET @a_error_no = 520;
                                            INSERT  INTO dbo.pv_status
                                                    ( pv_id ,
                                                   pv_status ,
														 eff_date ,
                                                      exp_date
																	 )
												VALUES  ( @curr_pv_id ,
																'AC' ,
                                                      @t_action_date ,
                                                      NULL
                                                    );
				
                                            IF ( @p_vendor_id IS NOT NULL
                                                 AND @p_vendor_id <> ''
                                               )
                                                BEGIN
                                                    SET @a_error_no = 530;
                                                    SELECT  @curr_vendor_id = vendor_id
                                                    FROM    dbo.vendor (NOLOCK)
                                                    WHERE   alt_id = @p_vendor_id
                                                            AND v_type = 'PV';
                                                    
                                                    IF @curr_vendor_id IS NULL
													BEGIN
														SET @a_error_no = 540
                                                        RAISERROR('Given Vendor ID without a match',0,1);
														EXECUTE dbo.usp_dl_log_error @a_batch_id,
														@pv_sp_id, @pv_sir_def_id, @p_sir_id,
														@a_error_no;
													
												END
                                                    ELSE
                                                        UPDATE
                                                              dbo.providers
                                                        SET   vendor_id = @curr_vendor_id
                                                        WHERE pv_id = @curr_pv_id;
                                                END;
				

			-- CREATE NEW PROVIDER LICENSE RECORD
                                            SET @tape_pvlic_eff = @p_pv_lic_eff;
                                            SET @tape_pvlic_exp = @p_pv_lic_exp;
                                            IF @tape_pvlic_eff IS NULL
                                                BEGIN
                                                    SET @tape_pvlic_eff = @t_action_date;
                                                    SET @tape_pvlic_exp = NULL;
                                                END;
				
                                            SET @a_error_no = 555;
                                            INSERT  INTO dbo.pv_license
                                                    ( pv_id ,
                                                      license ,
                                                      state ,
                                                      eff_date ,
                                                      exp_date
                                                    )
                                            VALUES  ( @curr_pv_id ,
                                                      @p_pv_license ,
                                                      @p_pv_lic_state ,
                                                      @tape_pvlic_eff ,
                                                      NULL
                                                    );

			-- CREATE NEW PROVIDER ADDRESS RECORD
				
                                   IF ( @p_pv_addr_type IS NOT NULL
             AND @p_pv_addr_type <> ''
                               )
    AND LEN(@p_pv_addr_type) > 0
                                                BEGIN
                      SET @a_error_no = 560;
                                                    INSERT  INTO dbo.address
                                                            ( subsys_code ,
                      sys_rec_id ,
                                  addr_type ,
      addr1 ,
         addr2 ,
                                                              zip ,
                 city ,
                                                              state ,
                                                              county ,
                                                              country ,
                                                              mail
                                                            )
                                                    VALUES  ( 'PV' ,
                                                              @curr_pv_id ,
                                                              @p_pv_addr_type ,
                                                              @p_pv_addr_1 ,
                                                              @p_pv_addr_2 ,
                                                              @p_pv_addr_zip ,
                                                              @p_pv_addr_city ,
                                                              @p_pv_addr_state ,
                                                              @p_pv_addr_county ,
                                                              @p_pv_addr_country ,
                                                              @p_pv_addr_mail
                                                            );
                                                END;
				

			-- CREATE NEW PROVIDER CONTACT RECORD
                                            IF ( @p_pv_con_phone1 IS NOT NULL
                                                 AND @p_pv_con_phone1 <> ''
                                               )
                                                BEGIN
                                                    SET @a_error_no = 570;
                                                    INSERT  INTO dbo.contact
                                                            ( subsys_code ,
                                                              sys_rec_id ,
                                                              con_type ,
                                                              fname ,
                                                              lname ,
                                                              title ,
                                                              phone1 ,
                                                              ext1 ,
                                                              phone2 ,
                                                              ext2 ,
                                                              fax ,
                                                              addr_type
                                                            )
                                                    VALUES  ( 'PV' ,
                                                              @curr_pv_id ,
                                                              NULL ,
															  @p_pv_con_fname ,
                                                              @p_pv_con_lname ,
                                                              @p_pv_con_title ,
                                                              @p_pv_con_phone1 ,
                        @p_pv_con_ext1 ,
                                   @p_pv_con_phone2 ,
                                                              @p_pv_con_ext2 ,
  @p_pv_con_fax ,
                                                              @p_pv_addr_type
                             );
         END;
                          END;
			
			-- CREATE NEW FACILITY PROVIDER ASSOCIATION RECORD
                                    IF @p_dds_fc_id IS NOT NULL
										BEGIN
                                            SET @tape_assoc_eff = @p_fc_assoc_eff;
                                            SET @tape_assoc_exp = @p_fc_assoc_exp;
                                            IF @tape_assoc_eff IS NULL
                                                BEGIN
                                                    SET @tape_assoc_eff = @t_action_date;
                                                    SET @tape_assoc_exp = NULL;
                                                END;
				
                                            SET @a_error_no = 550;
                                            INSERT  INTO dbo.fc_assoc
                                                    ( fc_id ,
                                                      pv_id ,
                                                      assoc_type ,
                                                      eff_date ,
                                                      exp_date
                                                    )
                                            VALUES  ( @p_dds_fc_id ,
                                                      @curr_pv_id ,
                                                      @p_fc_assoc_type ,
                                                      @tape_assoc_eff ,
                                                      NULL
                                                    );
                                        END;
                                END;
                            ELSE
                                IF @p_action_code = 'PR'
                                    BEGIN
                                        SET @a_error_no = 600;
                                        SELECT  @curr_pvstat_id = pv_st_id ,
                                                @curr_pvstat = pv_status ,
                                                @curr_pvstat_eff = eff_date
                                        FROM    dbo.pv_status (NOLOCK)
                                        WHERE   pv_id = @p_dds_pv_id
                                                AND exp_date IS NULL;
                                       
                                        IF @curr_pvstat <> 'AC'
                                            BEGIN
                                                IF @t_action_date < @curr_pvstat_eff
                                                    SET @t_action_date = @curr_pvstat_eff;
				
                                                SET @a_error_no = 610;

                                                UPDATE  dbo.pv_status
                                                SET     exp_date = @t_action_date
                                                WHERE   pv_st_id = @curr_pvstat_id;

                                                SET @a_error_no = 620;

                                                INSERT  INTO dbo.pv_status
                                                        ( pv_id ,
                                                          pv_status ,
                                                          eff_date ,
                                                          exp_date
                                                        )
                                                VALUES  ( @p_dds_pv_id ,
                                       'AC' ,
                                                          @t_action_date ,
                                                          NULL
                                                        );
                               END;

/* -- Like in Preprocessing,
  -- FC_ASSOC and FC STAT, PV STAT, and PV LIC relationships are irrevelent!!!

				if p_dds_fc_id is not null then
					let tape_assoc_eff = p_fc_assoc_eff;
					let tape_assoc_exp = p_fc_assoc_exp;

					if tape_assoc_eff is null then
						let tape_assoc_eff = t_action_date;
						let tape_assoc_exp = null;
					end if

					let a_error_no = 630;
					select fc_assoc_id, eff_date
					into curr_assoc_id, curr_assoc_eff
					from fc_assoc
					where fc_id = p_dds_fc_id
					and pv_id = p_dds_pv_id
					and exp_date is null;

					if tape_assoc_eff < curr_assoc_eff then
						let tape_assoc_eff = curr_assoc_eff;
						let tape_assoc_exp = null;
					end if

					if curr_assoc_id is not null then
						let a_error_no = 640;
						update fc_assoc
						set exp_date = tape_assoc_eff
						where fc_assoc_id = curr_assoc_id;
					end if

					let a_error_no = 650;
					insert into fc_assoc
					(fc_assoc_id, fc_id, pv_id,
					assoc_type, eff_date, exp_date)
					values
					(0, p_dds_fc_id, p_dds_pv_id,
					p_fc_assoc_type, tape_assoc_eff, null);
				end if
*/
                                    END;
                                ELSE
                                    IF @p_action_code = 'AA'
                                        BEGIN
                                            SET @a_error_no = 700;
                                            SET @tape_assoc_eff = @p_fc_assoc_eff;
                                            IF @tape_assoc_eff IS NULL
                                                SET @tape_assoc_eff = @t_action_date;
			
                                            IF @p_dds_fc_id IS NULL
                                                OR @p_dds_pv_id IS NULL
                                                OR ( @p_fc_assoc_type IS NULL
                                                     OR @p_fc_assoc_type = ''
                                                   )
												   BEGIN
												   SET @a_error_no = 710
                                                RAISERROR('Missing key info for Facility Association Insertion (AA)',16,                     1);
												RETURN
				END
			
                                            SET @a_error_no = 720;
											
                                            INSERT  INTO dbo.fc_assoc
                                                    ( fc_id ,
                                                      pv_id ,
                                                      assoc_type ,
                                                      eff_date ,
                                                      exp_date
                                                    )
                                            VALUES  ( @p_dds_fc_id ,
                                                      @p_dds_pv_id ,
                                                      @p_fc_assoc_type ,
                                                      @tape_assoc_eff ,
NULL
                                                    );
                                        END;
                                    ELSE
                                        IF @p_action_code = 'AR'
                                            BEGIN
                                                SET @a_error_no = 800;
                                                SET @tape_assoc_eff = @p_fc_assoc_eff;
                                                SET @tape_assoc_exp = @p_fc_assoc_exp;
                                               
											   /*
											    SET @SWV_cursor_var1 = CURSOR  FOR SELECT fc_assoc_id, assoc_type, eff_date, exp_date
			
             FROM dbo.fc_assoc
                  WHERE fc_id = @p_dds_fc_id
           AND pv_id = @p_dds_pv_id
                  ORDER BY fc_assoc_id DESC;
                                                OPEN @SWV_cursor_var1;
                           FETCH NEXT FROM @SWV_cursor_var1 INTO @curr_assoc_id,
                                        @curr_assoc_type,
        @curr_assoc_eff,
                                                    @curr_assoc_exp;
             WHILE @@FETCH_STATUS = 0
												*/
												IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
												DROP TABLE #SWV_cursor_var2

                                                CREATE TABLE #SWV_cursor_var2 
                                                    (
                                                      id INT IDENTITY ,
                                                      fc_assoc_id INT ,
                                                      assoc_type CHAR ,
                                                      eff_date DATE ,
                                                      exp_date DATE
                                                    );
                                                INSERT  INTO #SWV_cursor_var2
                                                        ( fc_assoc_id ,
                                                          assoc_type ,
                                                          eff_date ,
                                                          exp_date
                                                        )
                                                        SELECT
                                                              fc_assoc_id ,
                                                              assoc_type ,
                                                              eff_date ,
                                                              exp_date
                                                        FROM  dbo.fc_assoc
                                                        WHERE fc_id = @p_dds_fc_id
                                                              AND pv_id = @p_dds_pv_id
                                                        ORDER BY fc_assoc_id DESC;
                  

                                                DECLARE @cur2_cnt INT ,
                                                    @cur2_i INT;
                                                SET @cur2_i = 1;
    --Get the no. of records for the cursor
                                                SELECT  @cur2_cnt = COUNT(1)
                                                FROM    #SWV_cursor_var2;
                                                WHILE ( @cur2_i <= @cur1_cnt )
                                                    BEGIN
                                                        SELECT
                                                              @curr_assoc_id = fc_assoc_id ,
                                                              @curr_assoc_type = assoc_type ,
                                                              @curr_assoc_eff = eff_date ,
                                                              @curr_assoc_exp = exp_date
                                                        FROM  #SWV_cursor_var2
                                                        WHERE id = @cur2_i;
                                                        GOTO SWL_Label3;
                                                        /*
														FETCH NEXT FROM @SWV_cursor_var1 INTO @curr_assoc_id,
                                                            @curr_assoc_type,
                                                            @curr_assoc_eff,
                                                            @curr_assoc_exp;
															*/
         SET @cur2_i = @cur2_i
                                                            + 1;
                       END;
                 SWL_Label3:
                                              --  CLOSE @SWV_cursor_var1;
                                           
     SET @a_error_no = 810;
             IF ( @p_fc_assoc_exp IS NULL
                                                OR @p_fc_assoc_exp = ''
                                                   )
  IF @curr_assoc_eff <= @tape_assoc_eff
                                                AND @tape_assoc_eff < @curr_assoc_exp
                               INSERT
                                                              INTO dbo.fc_assoc
                                                              (
                                                              fc_id ,
                                                              pv_id ,
                                                              assoc_type ,
                                                              eff_date ,
                                                              exp_date
                                                              )
                                                        VALUES
                                                              (
                                                              @p_dds_fc_id ,
                                                              @p_dds_pv_id ,
                                                              @curr_assoc_type ,
                                                              @curr_assoc_exp ,
                                                              NULL
                                                              );

                                                    ELSE
                                                        IF @curr_assoc_exp <= @tape_assoc_eff
                                                            BEGIN
                                                              UPDATE
                                                              dbo.fc_assoc
                                                              SET
                                                              exp_date = @tape_assoc_eff
                                                              WHERE
                                                              fc_assoc_id = @curr_assoc_id;
                                                              INSERT
                                                              INTO dbo.fc_assoc
                                                              (
                                                              fc_id ,
                                                              pv_id ,
                                                              assoc_type ,
                                                              eff_date ,
                                                              exp_date
                       )
                                                              VALUES
                                                              (
                                                              @p_dds_fc_id ,
                                                              @p_dds_pv_id ,
                                                              @curr_assoc_type ,
                                                              @tape_assoc_eff ,
                                                              NULL
                                                              );
                                                            END;
                                                        ELSE
                                                            IF @curr_assoc_eff <= @tape_assoc_eff
                                                              AND @tape_assoc_eff < @curr_assoc_exp
                     INSERT
                                                              INTO dbo.fc_assoc
                                      (
                   fc_id ,
                  pv_id ,
                           assoc_type ,
                                         eff_date ,
                         exp_date
         )
                                                   VALUES
                                                              (
                                                              @p_dds_fc_id ,
                                                              @p_dds_pv_id ,
                                                              @curr_assoc_type ,
                                                              @curr_assoc_exp ,
                                                              NULL
                                                              );

                                                            ELSE
                                                              IF @curr_assoc_exp <= @tape_assoc_eff
                                                              BEGIN
                                                              UPDATE
                                                              dbo.fc_assoc
                                                              SET
                                                              exp_date = @tape_assoc_eff
                                                              WHERE
                                                              fc_assoc_id = @curr_assoc_id;
                                                              INSERT
                                                              INTO dbo.fc_assoc
                                                              (
                                                              fc_id ,
                                                              pv_id ,
                                                              assoc_type ,
                                                              eff_date ,
                                                              exp_date
                                                              )
                                                              VALUES
                                                              (
                                                              @p_dds_fc_id ,
                                                              @p_dds_pv_id ,
                                                              @curr_assoc_type ,
                                                              @tape_assoc_eff ,
                                       NULL
                                                              );
                                                              END;
                                            END;
                                        ELSE
                                            IF @p_action_code = 'AT'
                                                BEGIN
                                                    
													/*SET #SWV_cursor_var2 = CURSOR  FOR SELECT fc_assoc_id, eff_date, exp_date
			
                  FROM dbo.fc_assoc (NOLOCK)
                  WHERE fc_id = @p_dds_fc_id
                  AND pv_id = @p_dds_pv_id
                  ORDER BY fc_assoc_id DESC;
                                                    OPEN #SWV_cursor_var2;
                                                    FETCH NEXT FROM #SWV_cursor_var2 INTO @curr_assoc_id,
               @curr_assoc_eff,
                                           @curr_assoc_exp;
                                                    WHILE @@FETCH_STATUS = 0
    */
													   IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
														DROP TABLE #SWV_cursor_var3

     CREATE TABLE #SWV_cursor_var3
                                                        (
                                                          id INT IDENTITY ,
														 fc_assoc_id INT ,
														 eff_date DATE ,
                                                          exp_date DATE
													 );
                                                    INSERT  INTO #SWV_cursor_var3
                                                            ( fc_assoc_id ,
                                                              eff_date ,
                                                              exp_date
                                                            )
                                                            SELECT
                                                              fc_assoc_id ,
                                                              eff_date ,
                                                              exp_date
                                                            FROM
                                                              dbo.fc_assoc (NOLOCK)
                                                            WHERE
                                                              fc_id = @p_dds_fc_id
                                                              AND pv_id = @p_dds_pv_id
                                                            ORDER BY fc_assoc_id DESC;
                                                    

                                                    DECLARE @cur3_cnt INT ,
                                                        @cur3_i INT;
                                                    SET @cur3_i = 1;
    --Get the no. of records for the cursor
                                                    SELECT  @cur3_cnt = COUNT(1)
                                                    FROM    #SWV_cursor_var3;
                                                    WHILE ( @cur3_i <= @cur3_cnt )
                                                        BEGIN
                                                            SELECT
                                                              @curr_assoc_id = fc_assoc_id ,
                                                              @curr_assoc_eff = eff_date ,
                                                              @curr_assoc_exp = exp_date
                                                            FROM
                                                              #SWV_cursor_var3
                                    WHERE
                                                              id = @cur3_i;
                                                            GOTO SWL_Label4;
                                                            /*
															FETCH NEXT FROM #SWV_cursor_var2 INTO @curr_assoc_id,
                                                              @curr_assoc_eff,
                                                              @curr_assoc_exp;
															  */
                                                            SET @cur3_i = @cur3_i
                                                              + 1;
                                                        END;
                                                    SWL_Label4:
                                                    --CLOSE #SWV_cursor_var2;
                                                    IF @curr_assoc_exp IS NULL
                                                        IF @curr_assoc_eff <= @t_action_date
                                          BEGIN
                                               SET @a_error_no = 900;
                                            UPDATE
                                                              dbo.fc_assoc
                                              SET
												exp_date = @t_action_date
                    WHERE
                                                   fc_assoc_id = @curr_assoc_id;
                                                            END;
                      ELSE
                                                         BEGIN
															SET @a_error_no = 910
                    RAISERROR('Intended term date is before effective date (AT)',16,1);
                     SET @a_error_no = 900;
                                                              UPDATE
                                                              dbo.fc_assoc
                                                              SET
                                                              exp_date = @curr_assoc_eff
                                                              WHERE
                                                              fc_assoc_id = @curr_assoc_id;
															  RETURN
                                                            END;
				
                                                    ELSE
													BEGIN
													SET @a_error_no = 920
                                                        RAISERROR('Facility Provider Association record has already termed (AT)',16,1);
														RETURN
				END
                                                END;
                                            ELSE
                                                BEGIN
                                                    SET @v_Null = 0;
                                                END;
			-- p_action_code = "NC"
			-- No Action
		
                            IF @s_error = 'Y'
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'E'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    SET @n_succ_count = @n_succ_count + 1;
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'U'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
		
                            IF @n_process_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = @n_process_count
                                        - @n_succ_count
                                WHERE   bat_statistics_id = @i_statistics_id;
		
                            IF @n_in_transaction = 'Y'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'N';
                                END;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                   BEGIN
					IF @n_in_transaction = 'Y'
                                        BEGIN
   
       SET @n_in_transaction = 'N';
                              END;
				
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                   + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
			
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @pv_sp_id, @pv_sir_def_id, @p_sir_id,
                                @a_error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';

								  IF @s_error = 'Y'
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'E'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    SET @n_succ_count = @n_succ_count + 1;
                                    UPDATE  dbo.dls_pv_assoc
                                    SET     dls_status = 'U'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @p_sir_id;
                                END;

                        END CATCH;
                    END;
                  /*
				    FETCH NEXT FROM @cSIR INTO @p_sir_id, @p_alt_id,
                        @p_pv_tax_id, @p_pv_license, @p_pv_lic_state, @p_tin,
                        @p_pv_first_name, @p_pv_middle_init, @p_pv_last_name,
                        @p_discipline, @p_mal_car, @p_mal_pol_no, @p_mal_prac,
                        @p_mal_amt, @p_mal_amt_i, @p_mal_comnt, @p_dea_no,
                        @p_dea_cert_dt, @p_dea_exp_dt, @p_cds_no,
                        @p_cds_cert_dt, @p_cds_exp_dt, @p_cpr_cert_dt,
                        @p_cpr_exp_dt, @p_prim_fc, @p_school, @p_grd_date,
                        @p_degree, @p_ada_mbr, @p_district_no, @p_pv_dob,
                        @p_print_dir, @p_race, @p_gender, @p_num_yr_prac,
                        @p_peer_rv, @p_vendor_id, @p_pv_stat_eff_date,
                        @p_fc_assoc_fc_id, @p_fc_assoc_type, @p_fc_assoc_eff,
                        @p_fc_assoc_exp, @p_pv_lic_eff, @p_pv_lic_exp,
                        @p_pv_addr_type, @p_pv_addr_1, @p_pv_addr_2,
                        @p_pv_addr_zip, @p_pv_addr_city, @p_pv_addr_state,
                        @p_pv_addr_county, @p_pv_addr_country, @p_pv_addr_mail,
--		p_pv_con_type,
                        @p_pv_con_lname, @p_pv_con_fname, @p_pv_con_title,
                        @p_pv_con_phone1, @p_pv_con_ext1, @p_pv_con_phone2,
                        @p_pv_con_ext2, @p_pv_con_fax, @p_dds_fc_id,
                        @p_dds_pv_id, @p_action_code;
						*/
                    SET @cur_i = @cur_i + 1;
                END;
           -- CLOSE @cSIR;
            SET @n_error_count = @n_process_count - @n_succ_count;
            EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @n_error_count;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                                   + @n_error_count ),
                                                 ' Failed to update statistics');
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

			 UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @a_batch_id;

            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish Updating for Batch ',
       @a_batch_id);
            RETURN;
    END TRY
        BEGIN CATCH		
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            IF @n_in_transaction = 'Y'
				BEGIN
                    
                    SET @n_in_transaction = 'N';
                END;
		
           SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



	--set debug file to "/tmp/dlp_up_pv_assoc.trc";
	--trace on;

    END;