﻿-- Batch submitted through debugger: SQLQuery7.sql|7|0|C:\Users\567757\AppData\Local\Temp\~vsEA4A.sql
CREATE PROCEDURE [dbo].[dload_sync]
    @ALTID CHAR(20) = 'ALL' ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:01:01 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;
        DECLARE @RetVal INT;
        DECLARE @Msg CHAR(64);
        DECLARE @BatchID INT;
        DECLARE @ConfigName VARCHAR(50);
        DECLARE @eClaimID INT;
        DECLARE @HdrError CHAR(10);
        DECLARE @ErrCode CHAR(10);
        DECLARE @HdrStatus SMALLINT;	
        DECLARE @eClaimStatus SMALLINT;	
        DECLARE @SEV CHAR(1);	
        DECLARE @DLStatus CHAR(1);	
        DECLARE @RecCount SMALLINT;	
        DECLARE @LVL SMALLINT;	
        DECLARE @ErrID INT;	
        DECLARE @ErrNo INT; -- Submitted 	 
       -- DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @v_Null INT;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            
--set debug file to 'dloadsync.trc';
--trace on;

/*  Are we dealing with one claim or all? */
            SET @eClaimID = 0;
            SET @BatchID = 0;
            IF @ALTID = 'ALL'
                BEGIN
                    /*SET @SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_id, alt_id, dls_batch_id
		
         FROM dbo.eclaim_h (NOLOCK) WHERE dds_claim_id = 0 AND dls_batch_id != 0
         AND status = 2;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID, @ALTID,
                        @BatchID;
                    WHILE @@FETCH_STATUS = 0*/
                    DECLARE @SWV_cursor_var1 TABLE
                        (
                          id INT IDENTITY ,
                          eclaim_id INT ,
                          alt_id CHAR(20) ,
                          dls_batch_id INT
                        );

                    INSERT  INTO @SWV_cursor_var1
                            ( eclaim_id ,
                              alt_id ,
                              dls_batch_id 
					        )
                            SELECT  eclaim_id ,
                                    alt_id ,
                                    dls_batch_id
                            FROM    dbo.eclaim_h (NOLOCK)
                            WHERE   dds_claim_id = 0
                                    AND dls_batch_id != 0
                                    AND status = 2;


                    DECLARE @cur1_cnt INT ,
                        @cur1_i INT;

                    SET @cur1_i = 1;

					--Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;

                    WHILE ( @cur1_i <= @cur1_cnt )
                        BEGIN
                            SELECT  @eClaimID = eclaim_id ,
                                    @ALTID = alt_id ,
                                    @BatchID = dls_batch_id
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur1_i;

                            EXECUTE dbo.dload_sync_det @eClaimID, @BatchID,
                                @ALTID, @RetVal OUTPUT, @Msg OUTPUT;
                            
							/*FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID,
                                @ALTID, @BatchID;*/
                            SET @cur1_i = @cur1_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var1;
                END;
            ELSE
                BEGIN
                    SELECT  @eClaimID = eclaim_id ,
                            @ALTID = alt_id ,
                            @BatchID = dls_batch_id
                    FROM    dbo.eclaim_h (NOLOCK)
                    WHERE   dds_claim_id = 0
                            AND dls_batch_id != 0
                            AND status = 2 -- Submitted 	 
                            AND alt_id = @ALTID;
                    
                    IF @eClaimID = 0
                        BEGIN
                            SET @v_Null = 0;
                        END;
	-- Do nothing
                    ELSE
                        EXECUTE dbo.dload_sync_det @eClaimID, @BatchID, @ALTID,
                            @RetVal OUTPUT, @Msg OUTPUT;
                END;
 
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = 'DataLoad-eClaim Sync Completed';
			
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
			
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


----------------------------------------------------------------------

    END;