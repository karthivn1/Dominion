﻿CREATE PROC [dbo].[usp_dl_GetNewBatchInfo]
@ConfiguraionId INT
AS
BEGIN
		SELECT  dl_config_job_det.sp_id	 AS SpId,
				dl_sp.sp_display AS Process,
				dl_config_job_det.tolerance AS Tolerance,
				dl_sir_def.sir_def_id AS SirDefinitionId,
				dl_sir_def.display_name AS SirDefinitionName,
				'N' AS Status,
			'New' AS StatusDescription	
			FROM dl_config_job_det,dl_sp,dl_sir_def
			where (dl_config_job_det.sp_id=dl_sp.sp_id) and 
			(dl_sp.module_id=dl_sir_def.module_id and dl_sir_def.sir_def_id =
			(select top 1 sir_def_id from dl_sir_def where module_id=dl_sp.module_id) )
			and dl_config_job_det.config_id=@ConfiguraionId

	DECLARE @monthStartDate varchar(128) = '$todaymm/01/yyyy$'
	DECLARE @today varchar(128)='$today$'
	DECLARE @month varchar(2) = LEFT(CONVERT(varchar(20), GETDATE(), 101), 2)
	DECLARE @year varchar(4) = DATEPART(yyyy,getdate())

	SELECT  sp.sp_display AS SpName,
			spm.param_name			AS ParameterName,
			cp.sp_param_id			AS SpParameterId,
			CASE WHEN cp.config_param_value=@monthStartDate THEN @month+'/01/'+@year
				 WHEN cp.config_param_value=@today THEN  CONVERT(VARCHAR(10),GETDATE(),101) 
				 ELSE cp.config_param_value
			END	AS BatchParameterValue
			FROM dl_config_param cp
	INNER JOIN dl_sp_param spm ON cp.sp_param_id=spm.sp_param_id
	INNER JOIN dl_sp sp ON spm.sp_id=sp.sp_id
	WHERE cp.config_id=@ConfiguraionId

	SELECT stc_user.usersl_id as UsersListId,   
            stc_user.user_id as  UserId,   
            stc_user.userfname as FirstName,   
            stc_user.userlname as LastName,   
            stc_user.user_type as  UserType,   
            stc_user.user_descr as Description,   
            stc_user.eff_date as EffectiveDate,   
            stc_user.exp_date as ExpiryDate,   
            stc_user.created_by as CreatedBy,   
            stc_user.created_time as CreatedTime  
    FROM stc_user  
    WHERE (stc_user.usersl_id not in (2,4) ) 

-- select user_tbl.usersl_id as UsersListId,
--		                                                    user_tbl.user_id as UserId,
--		                                                    user_tbl.first_name as FirstName,
--		                                                    user_tbl.last_name as LastName,
--		                                                    'U' as UserType,
--		                                                    '' as Description,
--		                                                    user_tbl.eff_date as EffectiveDate,
--		                                                    user_tbl.exp_date as ExpiryDate,
--		                                                    user_tbl.h_user as CreatedBy,
--		                                                    user_tbl.h_datetime as CreatedTime
--                                                    from user_tbl
--													union 

--select group_tbl.groupsl_id as UsersListId,
--		                                                        group_tbl.group_id as UserId,
--		                                                        group_tbl.fname as FirstName,
--		                                                        group_tbl.lname as LastName,
--		                                                        'G' as UserType,
--		                                                        group_tbl.descr as Description,
--		                                                        group_tbl.eff_date as EffectiveDate,
--		                                                        group_tbl.exp_date as ExpiryDate,
--		                                                        group_tbl.h_user as CreatedBy,
--		                                                        group_tbl.h_datetime as CreatedTime
--                                                        from group_tbl where group_tbl.type='DL'
END