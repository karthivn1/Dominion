﻿CREATE procedure [dbo].[usp_ecl_StatusHistory]
@EclaimId int
as
begin
  SELECT eclaim_id AS EclaimId,   
         status AS Status,   
         eff_date AS EffDate,   
         exp_date AS ExpDate,   
         h_user AS HUser  
    FROM eclaim_status(NOLOCK)  
   WHERE eclaim_id = @EclaimId 
   ORDER BY h_user DESC
end