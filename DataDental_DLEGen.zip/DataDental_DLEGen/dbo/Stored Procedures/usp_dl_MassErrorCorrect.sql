﻿CREATE PROC [dbo].[usp_dl_MassErrorCorrect]
@BatchId INT,
@User VARCHAR(15),
@CurrentTime VARCHAR(22),
@Severity CHAR(1)=NULL,
@CommitAfter INT=NULL,
@P_ErrorNo INT = NULL,
@P_SPID	INT=NULL,
@P_Count INT OUTPUT
AS
BEGIN
SET NOCOUNT ON;
DECLARE @MinErrorId INT,@ErrorNo INT,
		@MaxErrorId INT,
		@ToUpdateErrorId INT,
		@LL_To_Update INT,
		@SIRDefId INT,
		@dlsTableName varchar(max),
		@DynamicQuery NVARCHAR(MAX),
		@CUR_COUNT INT,
		@Min_dls_sir_id INT,
		@Max_dls_sir_id INT,
		@SirIdToUpdate INT,
		@IncrementValue INT,
		@SPID INT,
		@Query NVARCHAR(MAX)
		DECLARE @SWV_cursor_var1 TABLE
			(
				id INT IDENTITY ,
				error_no INT ,
				sp_id INT,
				sir_def_id INT 
				);
		
IF(@CommitAfter=0 OR @CommitAfter IS NULL)
	BEGIN
		SET @LL_To_Update=1000
	END 
ELSE 
	BEGIN
		SET @LL_To_Update=@CommitAfter
	END 
	
SET @Query='SELECT DISTINCT dl_sp_error.error_no, dl_sp_error.sp_id, dl_log_error.sir_def_id
			FROM dl_log_error,	dl_sp_error 
			WHERE	( dl_log_error.error_no = dl_sp_error.error_no ) AND
					(dl_log_error.sp_id = dl_sp_error.sp_id) AND  
					(dl_log_error.corrected = ''N'') AND  
					(dl_log_error.config_bat_id='+CAST(@BatchId AS VARCHAR)+') ';

IF(@Severity='F')
		SET @Query=@Query+' AND (dl_sp_error.severity = '''+@Severity+''') ';
ELSE IF(@Severity='W')
		SET @Query=@Query+' AND (dl_sp_error.severity = '''+@Severity+''') ';
ELSE IF(@P_ErrorNo>0)
		SET @Query=@Query+' AND ( dl_log_error.error_no ='+CAST(@P_ErrorNo AS VARCHAR)+') 
							AND (dl_log_error.sp_id ='+CAST(@P_SPID AS VARCHAR)+')';

		INSERT INTO @SWV_cursor_var1 (error_no,sp_id,sir_def_id)
		EXEC (@Query)
		IF(@Severity='F' AND (SELECT COUNT(1) FROM @SWV_cursor_var1)=0)
				RAISERROR('Invalid action~All the error records with fatal severity corrected already, nothing have been changed.',16,1);
		ELSE IF(@Severity='W' AND (SELECT COUNT(1) FROM @SWV_cursor_var1)=0)
				RAISERROR('Invalid action~All the error records with warning severity corrected already, nothing have been changed.',16,1);

	SELECT  @CUR_COUNT = COUNT(1) FROM @SWV_cursor_var1;
	SET @IncrementValue = 1;
	SET @P_Count=0;
	WHILE (@CUR_COUNT>=@IncrementValue)
		BEGIN
			SELECT @ErrorNo=error_no,@SPID=sp_id FROM @SWV_cursor_var1 WHERE id=@IncrementValue;
			SELECT @MinErrorId = min(dl_log_error.log_error_id),@MaxErrorId= max(dl_log_error.log_error_id)
			 FROM dl_log_error
			WHERE ( dl_log_error.corrected = 'N' ) AND
					( dl_log_error.config_bat_id = @BatchId ) AND
					( dl_log_error.error_no = @ErrorNo ) AND
					( dl_log_error.sp_id = @SPID);

		WHILE (@MinErrorId<=@MaxErrorId) 
			BEGIN
				SET @ToUpdateErrorId=@MinErrorId+@LL_To_Update
				BEGIN TRAN;
					BEGIN TRY; 
						UPDATE dl_log_error  
							SET corrected = 'Y',   
							 corrected_by = @User,   
							 corrected_time = @CurrentTime
						 WHERE ( dl_log_error.log_error_id >= @MinErrorId ) AND  
			 					 ( dl_log_error.log_error_id < @ToUpdateErrorId ) AND   
								 ( dl_log_error.config_bat_id = @BatchId ) AND  
								 ( dl_log_error.corrected = 'N' ) AND  
								 ( dl_log_error.error_no = @ErrorNo ) AND
								 ( dl_log_error.sp_id = @SPID);
								 SET @P_Count=@P_Count+1;--TO GET TOTAL PROCESSED RECORDS 
						COMMIT TRAN;
					END TRY
					BEGIN CATCH
						ROLLBACK TRAN;
					END CATCH
				SET @MinErrorId=@ToUpdateErrorId;
			END
		
			SET @IncrementValue=@IncrementValue+1;
		END
		SET @IncrementValue = 1;
		WHILE (@CUR_COUNT>=@IncrementValue)
		BEGIN
		SELECT @ErrorNo=error_no,@SPID=sp_id,@SIRDefId=sir_def_id FROM @SWV_cursor_var1 WHERE id=@IncrementValue;
			SELECT @Min_dls_sir_id=min(dl_log_error.dls_sir_id), @Max_dls_sir_id=max(dl_log_error.dls_sir_id)
				 FROM dl_log_error  
				 WHERE ( dl_log_error.sp_id = @SPID ) AND  
     					 ( dl_log_error.config_bat_id = @BatchId ) AND  
					  ( dl_log_error.error_no = @ErrorNo );
		WHILE (@Min_dls_sir_id <= @Max_dls_sir_id)
			BEGIN
				SET @SirIdToUpdate=@Min_dls_sir_id+@LL_To_Update
					SELECT @dlsTableName=dl_sir_def.sir_def_name  
						FROM dl_sir_def  
						WHERE dl_sir_def.sir_def_id = @SIRDefId;
					SET @dlsTableName='dls_'+LTRIM(RTRIM(@dlsTableName));
					SET @DynamicQuery='UPDATE ' + @dlsTableName + ' SET dls_status = ''V'' WHERE ' + @dlsTableName +   '.dls_batch_id =   ' + CAST(@BatchId AS VARCHAR) +   
					' AND '+  @dlsTableName +   '.dls_status not in (''L'',''V'',''U'') AND   '  +@dlsTableName +   '.dls_sir_id in ( SELECT DISTINCT dl_log_error.dls_sir_id   ' 
					  +'FROM dl_log_error WHERE dl_log_error.sp_id =   ' + CAST(@SPID AS VARCHAR)+   '  AND  '+ 
					  ' dl_log_error.error_no =' + CAST(@ErrorNo AS VARCHAR) +   '  AND   '+'
					dl_log_error.config_bat_id =' +CAST( @BatchId AS VARCHAR)+   '  AND   '+'
					dls_sir_id >=   ' + CAST(@Min_dls_sir_id AS VARCHAR) +   '  AND   '+' 
					dls_sir_id <    ' + CAST(@SirIdToUpdate AS VARCHAR) +   '  AND   ' +'
					dl_log_error.corrected = ''Y'' ) ; ';
					BEGIN TRAN;
					BEGIN TRY
						EXEC (@DynamicQuery)
						COMMIT TRAN;
					END TRY
					BEGIN CATCH
						ROLLBACK TRAN;
					END CATCH
				
				SET @Min_dls_sir_id=@SirIdToUpdate
			END
			SET @IncrementValue=@IncrementValue+1;
		END
SET NOCOUNT OFF;
END