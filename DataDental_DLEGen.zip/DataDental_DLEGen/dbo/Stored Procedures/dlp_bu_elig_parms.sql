﻿CREATE PROCEDURE [dbo].[dlp_bu_elig_parms]
    @a_batch_id INT ,
    @a_sp_id INT ,
    @a_config_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(100) = NULL OUTPUT
    
	
/* 20131221$$ks - dlp_bu_eligibility has gotten too big 
 * this is the first procedure to be 'out sourced' from the procedure!
 * $$ks - new error messages are required for the parameter logic
 */
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @n_error_count INT;

        DECLARE @i_count INT;

-- paramater variable


        DECLARE @i_elig_opt INT;
        DECLARE @ls_process_eff_dt char(10);
		DECLARE @ls_process_exp_dt char(10);
		DECLARE @n_lookup_ssn_alt char(1);
		DECLARE @n_new_mb_w_fc_id char(1);
		DECLARE @n_has_facility_id char(1);
		DECLARE @n_has_multiple_gp char(1);
		DECLARE @n_add_to_cl_fc char(1);
		DECLARE @n_has_rate_code char(1);
		DECLARE @n_has_address char(1);
		DECLARE @n_sub_age char(11);
		DECLARE @n_has_plan_eff char(1);
		DECLARE @n_has_s_plan_term char(1);
		DECLARE @n_has_d_plan_term char(1);
		DECLARE @n_has_fac_eff char(1);
		DECLARE @d_process_eff_dt date;
		DECLARE @d_process_exp_dt date;
		DECLARE @d_process_eff_per date;
		DECLARE @d_process_exp_per date;
		DECLARE @i_sub_age int;
		DECLARE @s_sub_age char(11);
		DECLARE @ls_mid_month  char(1);
      --  DECLARE @SWV_cursor_var1 CURSOR;

        SET NOCOUNT ON;
        SET @ls_process_eff_dt = '';
        
        SET @ls_process_exp_dt = '';
        
        SET @n_lookup_ssn_alt = '';
        
        SET @n_new_mb_w_fc_id = '';
        
        SET @n_has_facility_id = '';
        
        SET @n_has_multiple_gp = '';
        
        SET @n_add_to_cl_fc = '';
        
        SET @n_has_rate_code = '';
        
        SET @n_has_address = '';
        
        SET @n_sub_age = '';
        
        SET @n_has_plan_eff = '';
        
        SET @n_has_s_plan_term = '';
        
        SET @n_has_d_plan_term = '';
        
        SET @n_has_fac_eff = '';
        
        SET @d_process_eff_dt = NULL;
        
        SET @d_process_exp_dt = NULL;
        
        SET @d_process_eff_per = NULL;
        
        SET @d_process_exp_per = NULL;
        
        SET @i_sub_age = 0;
        
        SET @s_sub_age = '';
        
        SET @ls_mid_month = 'N';
        
        BEGIN TRY
            SET @n_lookup_ssn_alt = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'SSN/ALT');
            
			 UPDATE dbo.GlobalVar set VarValue = @n_lookup_ssn_alt where VarName = 'n_lookup_ssn_alt' and  BatchId = @a_batch_id AND Module_Id = 3

            SET @n_has_facility_id = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Has Facility ID');

            -- UPDATE dbo.GlobalVar set VarValue = @n_has_plan_eff where VarName = 'n_has_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
			 UPDATE dbo.GlobalVar set VarValue = @n_has_facility_id where VarName = 'n_has_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
			 
			SET @n_new_mb_w_fc_id = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'New Member w/ FC');
            
            SET @n_has_multiple_gp = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'multi group plan');
            
            SET @n_add_to_cl_fc = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Add Closed FC');
            
            SET @n_has_rate_code = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Has Rate Code');
            
            SET @n_has_address = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Has Address');
 
		  SET @n_sub_age = dbo.dl_get_param_value(@a_batch_id, @a_sp_id, 'Subscriber Age');
            
            SET @n_has_plan_eff = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Has Plan Effective');
            UPDATE dbo.GlobalVar set VarValue = @n_has_plan_eff where VarName = 'n_has_plan_eff' and  BatchId = @a_batch_id AND Module_Id = 3
			
            SET @n_has_d_plan_term = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Dep Plan Term');
            
            SET @n_has_s_plan_term = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Sub Plan Term');

            UPDATE dbo.GlobalVar set VarValue = @n_has_s_plan_term where VarName = 'n_has_s_plan_term' and  BatchId = @a_batch_id AND Module_Id = 3
			
            SET @n_has_fac_eff = dbo.dl_get_param_value(@a_batch_id, @a_sp_id, 'Has FC Effective');
            
            SET @ls_process_eff_dt = dbo.dl_get_param_value(@a_batch_id, @a_sp_id,'Process Eff Period');
            
            SET @ls_process_exp_dt = dbo.dl_get_param_value(@a_batch_id,@a_sp_id,'Process Exp Period');

            UPDATE dbo.GlobalVar set VarValue = @n_has_d_plan_term where VarName = 'n_has_d_plan_term' and  BatchId = @a_batch_id AND Module_Id = 3
			UPDATE dbo.GlobalVar set VarValue = @n_sub_age where VarName = 'n_sub_age' and  BatchId = @a_batch_id AND Module_Id = 3
			UPDATE dbo.GlobalVar set VarValue = @n_has_rate_code where VarName = 'n_has_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
			UPDATE dbo.GlobalVar set VarValue = @n_has_multiple_gp where VarName = 'n_has_multiple_gp' and  BatchId = @a_batch_id AND Module_Id = 3
			UPDATE dbo.GlobalVar set VarValue = @n_new_mb_w_fc_id where VarName = 'n_new_mb_w_fc_id' and  BatchId = @a_batch_id AND Module_Id = 3
			UPDATE dbo.GlobalVar set VarValue = @n_has_fac_eff where VarName = 'n_has_fac_eff' and  BatchId = @a_batch_id AND Module_Id = 3

		   /* SET @SWV_cursor_var1 = CURSOR  FOR SELECT b.elig_opt 
      FROM dbo.dlsp_eg_group_plan a (NOLOCK), dbo.rel_gppl b (NOLOCK)
      WHERE a.config_id = @a_config_id AND
      a.group_id = b.group_id AND a.plan_id = b.plan_id;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_elig_opt;
            WHILE @@FETCH_STATUS = 0*/
			DECLARE @SWV_cursor_var1 TABLE
            (
              id INT IDENTITY ,
              elig_opt INT
            );
        INSERT  INTO @SWV_cursor_var1
                ( elig_opt
                )
				SELECT b.elig_opt 
      FROM dbo.dlsp_eg_group_plan a (NOLOCK), 
	  dbo.rel_gppl b (NOLOCK)
      WHERE a.config_id = @a_config_id 
	  AND   a.group_id = b.group_id 
	  AND	a.plan_id = b.plan_id

	   DECLARE @cur1_cnt INT ,
     @cur_i INT;
    SET @cur_i = 1;
    --Get the no. of records for the cursor
    SELECT  @cur1_cnt = COUNT(1)
    FROM    @SWV_cursor_var1;
    WHILE ( @cur_i <= @cur1_cnt )
                BEGIN

				SELECT  @i_elig_opt = elig_opt
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur_i;

                    IF @i_elig_opt = 0
                        BEGIN
                            SET @ls_mid_month = 'N';
                            
                            GOTO SWL_Label2;
                        END;
                    ELSE
                        BEGIN
  SET @ls_mid_month = 'Y';
                            
             END;
          -- FETCH NEXT FROM @SWV_cursor_var1 INTO @i_elig_opt;
				   SET @cur_i = @cur_i + 1;
             END;
            SWL_Label2:
            --CLOSE @SWV_cursor_var1;
            
            IF ( @ls_process_eff_dt IS NULL
                 OR @ls_process_eff_dt = ''
               )
                OR LEN(@ls_process_eff_dt) = 0
                RAISERROR('Missing Process Eff Period',16,1);
            ELSE
                BEGIN
                    SET @s_error_descr = 'Invalid Processing Eff Date Format';
                    
                    SET @d_process_eff_per = @ls_process_eff_dt;

                    UPDATE dbo.GlobalVar set VarValue = @d_process_eff_per where VarName = 'd_process_eff_per' and  BatchId = @a_batch_id AND Module_Id = 3
                    IF @ls_mid_month = 'N'
                        AND DATEPART(DAY,
                                     CONVERT(DATE, CONVERT(VARCHAR, @d_process_eff_per))) != 1
                        RAISERROR('Process Eff Period must be 1st of the month',16,1);
                END;

            
            IF ( @ls_process_exp_dt IS NULL
                 OR @ls_process_exp_dt = ''
               )
                OR LEN(@ls_process_exp_dt) = 0
                RAISERROR('Missing Process Exp Period',16,1);
            ELSE
                BEGIN
                    SET @s_error_descr = 'Invalid Processing Exp Date Format';
                    
                    SET @d_process_exp_per = @ls_process_exp_dt;
                    
                     UPDATE dbo.GlobalVar set VarValue = @d_process_exp_per where VarName = 'd_process_exp_per' and  BatchId = @a_batch_id AND Module_Id = 3
                    
                    IF @ls_mid_month = 'N'
                        AND DATEPART(DAY,
                                     CONVERT(DATE, CONVERT(VARCHAR, @d_process_exp_per))) != 1
                        RAISERROR('Process Exp Period must be 1st of the month',16,1);
                END;

            
            IF ( @n_lookup_ssn_alt IS NULL
                 OR @n_lookup_ssn_alt = ''
               )
                OR LEN(@n_lookup_ssn_alt) = 0
                RAISERROR('Missing Lookup By Value',16,1);
            ELSE
                BEGIN
            
                    IF @n_lookup_ssn_alt NOT IN ( 'A', 'S', 'U', 'F', 'Z' )
                        RAISERROR('Invalid Value for lookup',16,1);
                END;

            
            IF ( @n_has_facility_id IS NULL
                 OR @n_has_facility_id = ''
               )
                OR LEN(@n_has_facility_id) = 0
                RAISERROR('Missing Facility Change value',16,1);
            ELSE
                BEGIN
            
                    IF @n_has_facility_id NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Value for Facility Change',16,1);
                END;

            
            IF ( @n_new_mb_w_fc_id IS NULL
                 OR @n_new_mb_w_fc_id = ''
               )
                OR LEN(@n_new_mb_w_fc_id) = 0
                RAISERROR('Missing New Member with Facility value',16,1);
            ELSE
                BEGIN
            
                    IF @n_new_mb_w_fc_id NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Value for New Member with Facility',16,1);
                END;

            
       IF ( @n_has_multiple_gp IS NULL
                 OR @n_has_multiple_gp = ''
               )
                OR LEN(@n_has_multiple_gp) = 0
                RAISERROR('Missing Mulitple Group/Plan Indicator',16,1);
            ELSE
                BEGIN
            
                    IF @n_has_multiple_gp NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Multiple Group/Plan Indicator',16,1);
                END;

            
            IF ( @n_add_to_cl_fc IS NULL
                 OR @n_add_to_cl_fc = ''
)
                OR LEN(@n_add_to_cl_fc) = 0
                RAISERROR('Missing Indicator for Closed Facility',16,1);
            ELSE
                BEGIN
            
  IF @n_add_to_cl_fc NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Closed Facility Indicator',16,1);
                END;

            
            IF ( @n_has_rate_code IS NULL
                 OR @n_has_rate_code = ''
               )
                OR LEN(@n_has_rate_code) = 0
                RAISERROR('Missing Indicator for calculating rate code',16,1);
            ELSE
                BEGIN
            
                    IF @n_has_rate_code NOT IN ( 'Y', 'N' )
     RAISERROR('Invalid Indicator for calculating rate code',16,1);
                END;


            IF ( @n_has_address IS NULL
                 OR @n_has_address = ''
               )
          OR LEN(@n_has_address) = 0
                RAISERROR('Missing Indicator for Sub Address',16,1);
            ELSE
                BEGIN

                    IF @n_has_address NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Indicator for Sub Address',16,1);
                END;


            IF ( @n_has_d_plan_term IS NULL
                 OR @n_has_d_plan_term = ''
               )
                OR LEN(@n_has_d_plan_term) = 0
                RAISERROR('Missing Indicator for DepENDent Term Date',16,1);
            ELSE
                BEGIN

                    IF @n_has_d_plan_term NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Dep''s Terminate Date Indicator',16,1);
                END;


            IF ( @n_has_s_plan_term IS NULL
                 OR @n_has_s_plan_term = ''
               )
                OR LEN(@n_has_s_plan_term) = 0
                RAISERROR('Missing Indicator for Subscriber Term Date',16,1);
            ELSE
                BEGIN

                    IF @n_has_s_plan_term NOT IN ( 'Y', 'N' )
                        RAISERROR('Invalid Sub''s Terminate Date Indicator',16,1);
                END;

            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished validating BU elig parameters for this batch: ',
                                         @a_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            --SET @i_error_no = ERROR_NUMBER();
			SET @i_error_no = 0;
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1 * @i_error_no;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;