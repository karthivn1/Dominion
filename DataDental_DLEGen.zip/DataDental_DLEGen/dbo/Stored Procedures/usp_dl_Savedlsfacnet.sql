﻿

--drop procedure usp_dl_Savedlsfacnet
CREATE PROCEDURE [dbo].[usp_dl_Savedlsfacnet] (@dlsfacNet dbo.DlsFacNet READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_fac_net 
				SET dls_batch_id = dfn.dls_batch_id
					  ,alt_id = dfn.alt_id
					  ,fc_type = dfn.fc_type
					  ,fc_name = dfn.fc_name
					  ,fc_stat_eff_date = dfn.fc_stat_eff_date
					  ,fc_state = dfn.fc_state
					  ,fc_license = dfn.fc_license
					  ,fc_lrenew_dt = dfn.fc_lrenew_dt
					  ,vendor_id = dfn.vendor_id
					  ,fc_tax_id = dfn.fc_tax_id
					  ,tin = dfn.tin
					  ,fc_area = dfn.fc_area
					  ,fc_rep = dfn.fc_rep
					  ,fc_source = dfn.fc_source
					  ,phone_elig = dfn.phone_elig
					  ,fax_elig = dfn.fax_elig
					  ,print_dir = dfn.print_dir
					  ,fc_mst_con_dt = dfn.fc_mst_con_dt
					  ,emergency_phone = dfn.emergency_phone
					  ,em_phone_ext = dfn.em_phone_ext
					  ,emg_contact_type = dfn.emg_contact_type
					  ,legal_entity = dfn.legal_entity
					  ,fc_tax_name = dfn.fc_tax_name
					  ,pnrx = dfn.pnrx
					  ,no2 = dfn.no2
					  ,hndacs = dfn.hndacs
					  ,fc_capacity = dfn.fc_capacity
					  ,fc_warn = dfn.fc_warn
					  ,fc_no_new = dfn.fc_no_new
					  ,fc_max_enrl = dfn.fc_max_enrl
					  ,fc_opr_tory = dfn.fc_opr_tory
					  ,parent_id = dfn.parent_id
					  ,barrier_c = dfn.barrier_c
					  ,fc_cur_enrl = dfn.fc_cur_enrl
					  ,next_cap_date = dfn.next_cap_date
					  ,net_id = dfn.net_id
					  ,contract_type = dfn.contract_type
					  ,net_fc_eff_date = dfn.net_fc_eff_date
					  ,ovr_ride = dfn.ovr_ride
					  ,net_fc_exp_date = dfn.net_fc_exp_date
					  ,addr_type = dfn.addr_type
					  ,addr1 = dfn.addr1
					  ,addr2 = dfn.addr2
					  ,zip = dfn.zip
					  ,city = dfn.city
					  ,state = dfn.state
					  ,county = dfn.county
					  ,country = dfn.country
					  ,mail = dfn.mail
					  ,con_type = dfn.con_type
					  ,con_lname = dfn.con_lname
					  ,con_fname = dfn.con_fname
					  ,title = dfn.title
					  ,phone1 = dfn.phone1
					  ,ext1 = dfn.ext1
					  ,phone2 = dfn.phone2
					  ,ext2 = dfn.ext2
					  ,fax = dfn.fax
					  --,dls_facility_id = dfn.dls_facility_id
					  --,dls_network_id = dfn.dls_network_id
					  --,dls_action_code = dfn.dls_action_code
					  ,dls_fac_net.dls_status = CASE WHEN dfn.dls_status='E' OR dfn.dls_status='P' THEN 'V'
				ELSE dls_fac_net.dls_status END
					  --,dls_source = dfn.dls_source
				from @dlsfacNet dfn
				WHERE dls_fac_net.dls_sir_id = dfn.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END