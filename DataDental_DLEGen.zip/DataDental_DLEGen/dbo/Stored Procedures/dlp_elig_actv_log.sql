﻿CREATE PROCEDURE [dbo].[dlp_elig_actv_log]
    @subsys_code CHAR(2) ,
    @menu_opt CHAR(15) ,
    @group_id INT,
	@user_name CHAR(20)='SA'
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:26:26 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @ll_act_mast_id INT;
        DECLARE @mod_id INT;
        DECLARE @modid INT;           
        DECLARE @ls_code CHAR;
        DECLARE @ls_time CHAR;           
        DECLARE @ls_log CHAR;
        DECLARE @ls_reason CHAR;      
        DECLARE @ls_rsn_code CHAR(2);       
        DECLARE @cntr INT;
		      

        SET NOCOUNT ON;
        SELECT  @ll_act_mast_id = dbo.act_mast.act_mast_id ,
                @ls_log = dbo.act_mast.activity_flag ,
                @ls_reason = dbo.act_mast.reason_flag
        FROM    dbo.act_mast (NOLOCK) ,
                dbo.mod_def (NOLOCK)
        WHERE   ( dbo.act_mast.mod_id = dbo.mod_def.mod_id )
                AND ( ( dbo.mod_def.subsys_code = @subsys_code )
                      AND ( dbo.mod_def.menu_opt = @menu_opt )
                    );   
        

        IF @ll_act_mast_id IS NOT NULL
            AND @ll_act_mast_id > 0
            IF @ls_log = 'Y'
                BEGIN
                    SET @ls_rsn_code = 'DF';

					

                    INSERT  INTO dbo.act_log
                            ( sub_sys ,
                              act_mast_id ,
                              event_sys_id ,
                              action_code ,
                              reason_code ,
                              log_user ,
                              log_date ,
                              log_time
                            )
                    VALUES  ( @subsys_code ,
                              @ll_act_mast_id ,
                              @group_id ,
                              NULL ,
                              @ls_rsn_code ,
                              --ORIGINAL_LOGIN() ,
							  left(@user_name,8),
                              GETDATE() ,
                              GETDATE()
                            ); 
                END;
	     
        SET NOCOUNT OFF;
    END;