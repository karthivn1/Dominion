﻿CREATE procedure [dbo].[getsubpl_taxgrptyp] @TaxID CHAR(11), @GrpID INT,
 @InsType CHAR(1), @SvcDate DATE,@SWP_Ret_Value INT = NULL OUTPUT,@SWP_Ret_Value1 INT = NULL OUTPUT,@SWP_Ret_Value2 VARCHAR(64) = NULL OUTPUT 
AS
BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:36:36 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
   declare @ID INT
   declare @PlanID INT
   declare @MCnt INT
   declare @i_error_no INT
   declare @s_error_descr CHAR(64)
   declare @s_err_rtn_text CHAR(64)
   declare @i_isam_error INT

 ---------------exception Handling ------------------------
   SET NOCOUNT ON
   BEGIN TRY
      SET @ID = null
      SET @MCnt = 0
      if LEN(@TaxID) > 0
      begin
         Select   @MCnt = count(distinct m.family_id)
         from dbo.member m (NOLOCK),
		 dbo.rlmbgrpl g (NOLOCK),
		 dbo.[plan] p (NOLOCK)
         Where m.member_id = g.member_id
         and m.family_id = m.member_id
         and g.plan_id = p.plan_id
         and p.ins_type = @InsType
         and g.group_id = @GrpID
         and m.new_ssn = @TaxID
         and g.eff_gr_pl <= @SvcDate
         and (g.exp_gr_pl is null or g.exp_gr_pl > @SvcDate)
         if @MCnt = 0
         begin
            set @SWP_Ret_Value = -1
            set @SWP_Ret_Value1 = 0
            set @SWP_Ret_Value2 = ''
            RETURN
         end
		
         if @MCnt > 1
         begin
            set @SWP_Ret_Value = -2
            set @SWP_Ret_Value1 = 0
            set @SWP_Ret_Value2 = ''
            RETURN
         end
		
         Select distinct  @ID = m.family_id
         from dbo.member m (NOLOCK),
		 dbo.rlmbgrpl g (NOLOCK),
		 dbo.[plan] p (NOLOCK)
         Where m.member_id = g.member_id
         and m.family_id = m.member_id
         and g.plan_id = p.plan_id
         and p.ins_type = @InsType
         and g.group_id = @GrpID
         and m.new_ssn = @TaxID
         and g.eff_gr_pl <= @SvcDate
         and (g.exp_gr_pl is null or g.exp_gr_pl > @SvcDate)
         
      end
	
      if @ID is null
      begin
         set @SWP_Ret_Value = -1
         set @SWP_Ret_Value1 = 0
         set @SWP_Ret_Value2 = ''
         RETURN
      end
   else
      begin
         Select distinct  @PlanID = p.plan_id
         from dbo.member m (NOLOCK), 
		 dbo.rlmbgrpl g (NOLOCK),
		  dbo.[plan] p (NOLOCK)
         Where m.member_id = g.member_id
         and m.family_id = m.member_id
         and g.plan_id = p.plan_id
         and p.ins_type = @InsType
         and g.group_id = @GrpID
         and g.member_id = @ID
         and g.eff_gr_pl <= @SvcDate
         and (g.exp_gr_pl is null or g.exp_gr_pl > @SvcDate)
         
      end
	
      if @PlanID is null
      begin
         set @SWP_Ret_Value = @ID
         set @SWP_Ret_Value1 = 0
         set @SWP_Ret_Value2 = ''
         RETURN
      end
   else
      begin
         set @SWP_Ret_Value = @ID
         set @SWP_Ret_Value1 = @PlanID
         set @SWP_Ret_Value2 = ''
         RETURN
      end
   END TRY
   BEGIN CATCH
      SET @i_error_no = ERROR_NUMBER()
      SET @i_isam_error = ERROR_LINE()
      SET @s_error_descr = ERROR_MESSAGE()
      SET @s_err_rtn_text = CONCAT('DB Error: ',@i_error_no,' Error msg: ',@s_error_descr)
      set @SWP_Ret_Value = -1
      set @SWP_Ret_Value1 = 0
      set @SWP_Ret_Value2 = @s_err_rtn_text
      RETURN
   END CATCH
   SET NOCOUNT OFF

----------------------------------------------------------------------
End