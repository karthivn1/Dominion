﻿CREATE PROCEDURE [dbo].[usp_dl_log_error]
    @a_batch_id INT , --CH001
    @a_sp_id INT ,
    @a_sir_def_id INT ,
    @a_sir_id INT ,
    @a_error_no INT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:00:00 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
















000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_sir_def_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @c_severity CHAR(1);
        DECLARE @c_log_flag CHAR(1);
        DECLARE @c_in_use CHAR(1);

	

        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);
        DECLARE @s_user VARCHAR(15);
        DECLARE @dt_current DATETIME;
        DECLARE @s_current VARCHAR(22);
        DECLARE @s_today CHAR(10);
        DECLARE @ls_current_time Date; 

        SET NOCOUNT ON;
        SET @ls_current_time = '';
        
       BEGIN TRY
            IF @a_batch_id IS NULL
                RETURN -1;
	
            IF @a_sp_id < 0
                RETURN -1;
	
            SELECT  @c_severity = severity
            FROM    dbo.dl_sp_error (NOLOCK)
            WHERE   sp_id = @a_sp_id
                    AND error_no = @a_error_no;
					           
            IF ( @c_severity IS NULL
                 
               )
--		return -1;
                BEGIN
                    SET @c_severity = 'F';
                    SET @a_error_no = 0;
                END;
	                
            SET @s_current = FORMAT(GETDATE() , 'yyyy-MM-dd HH:mm:ss:ff')--CONVERT(VARCHAR, GETDATE()) 
                
            SELECT @s_user = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
			
			INSERT  INTO dbo.dl_log_error
                    ( config_bat_id ,
                      sp_id ,
                      sir_def_id ,
                      dls_sir_id ,
                      error_no ,
                      corrected ,
                      created_by ,
                      created_time
                    )
					
					VALUES  ( @a_batch_id ,
                      @a_sp_id ,
                      @a_sir_def_id ,
                      @a_sir_id ,
                      @a_error_no ,
                      'N' ,
                      @s_user,
                      @s_current
                    );
	
            IF @c_severity = 'F'
                RETURN -1;
			 ELSE
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_code = ERROR_NUMBER();
            SET @n_return_code = ERROR_LINE();
            SET @n_error_desc = ERROR_MESSAGE();

			 IF @c_severity = 'F'
                RETURN -1;
			 ELSE
            RETURN 1;

        END CATCH;
        SET NOCOUNT OFF;
    END;