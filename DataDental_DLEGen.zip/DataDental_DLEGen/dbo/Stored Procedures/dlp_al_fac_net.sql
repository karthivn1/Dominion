﻿CREATE PROCEDURE [dbo].[dlp_al_fac_net]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    


	/*error variable*/
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @s_sir_def_name CHAR(18);
        DECLARE @s_proc_name CHAR(18);
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
   	
        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_in_transaction CHAR(1);

        DECLARE @t_sir_id INT;
	/* 20130804$$ks - expanded facility.alt_id fields to 40 chars
	 *  and changed name from t_ to fc_
	 */
        DECLARE @fc_alt_id CHAR(40);
        DECLARE @t_fc_type CHAR(2);
        DECLARE @t_phone_elig CHAR(1);
        DECLARE @t_fax_elig CHAR(1);
        DECLARE @t_print_dir CHAR(1);
        DECLARE @t_legal_entity CHAR(2);
        DECLARE @t_fc_tax_name CHAR(50);
        DECLARE @t_fc_name CHAR(50);
        DECLARE @t_pnrx CHAR(1);
        DECLARE @t_no2 CHAR(1);
        DECLARE @t_hndacs CHAR(1);
        DECLARE @t_fc_opr_tory CHAR(11);
        DECLARE @t_ovr_ride CHAR(1);
        DECLARE @t_zip CHAR(10);
        DECLARE @t_city CHAR(30);
        DECLARE @t_state CHAR(2);
        DECLARE @t_county CHAR(20);
        DECLARE @t_country CHAR(3);
        DECLARE @t_mail CHAR(1);
        DECLARE @d_city CHAR(30);
        DECLARE @d_state CHAR(2);
        DECLARE @d_county CHAR(20);

        DECLARE @n_process_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
        DECLARE @n_al_count INT;
        DECLARE @i_delete_id INT;
        DECLARE @i_zip_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_config_id INT;
        DECLARE @SWV_dl_get_sp_id INT;
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @cSIR CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
		DECLARE @created_by CHAR(15)


        SET NOCOUNT ON;
        SET @i_sp_id = 0 ;
        --EXECUTE SWPCrtGlVar 'i_sp_id';
        --EXECUTE SWPAddGlVar 'i_sp_id', @i_sp_id;
        SET @i_sir_def_id = 0;
        --EXECUTE SWPCrtGlVar 'i_sir_def_id';
        --EXECUTE SWPAddGlVar 'i_sir_def_id', @i_sir_def_id;
        SET @i_config_id = 0 ;
        --EXECUTE SWPCrtGlVar 'i_config_id';
        --EXECUTE SWPAddGlVar 'i_config_id', @i_config_id;
        BEGIN TRY
            
            
            SET @s_proc_name = 'al_fac_net';
            SET @s_sir_def_name = 'fac_net';
            EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, @s_proc_name
                 
            SET @i_sp_id = @SWV_dl_get_sp_id;
            --EXECUTE SWPAddGlVar 'i_sp_id', @i_sp_id;
            --EXECUTE SWPGetGlVar 'i_sp_id', @i_sp_id OUTPUT;
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Invalid SP Name',16,1);
				END
	
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            --EXECUTE SWPAddGlVar 'i_sir_def_id', @i_sir_def_id;
            --EXECUTE SWPGetGlVar 'i_sir_def_id', @i_sir_def_id OUTPUT;
            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Invalid SIR TABLE Definition',16,1);
				END
	
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;

					SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
          
            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
               start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                  tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      --ORIGINAL_LOGIN() ,
					  @created_by,
                      @a_start_time
                    );
	
            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dbo.dl_bat_statistics (NOLOCK)
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
           
            SET @n_process_count = 0;
            SET @n_succ_count = 0;
            SET @n_in_transaction = 'N';
            IF EXISTS ( SELECT  *
                        FROM    dbo.dl_log_error
                        WHERE   config_bat_id = @a_batch_id
                                AND sp_id = @i_sp_id )
                BEGIN
                    /*
					SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id 
         FROM dbo.dls_fac_net (NOLOCK)
         WHERE dls_batch_id = @a_batch_id AND dls_status = 'V';
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_delete_id;
                    WHILE @@FETCH_STATUS = 0
					*/
                    DECLARE @SWV_cursor_var1 TABLE
                        (
                          id INT IDENTITY ,
                          dls_sir_id INT
                        );

                    INSERT  INTO @SWV_cursor_var1
                            ( dls_sir_id
                            )
                            SELECT  dls_sir_id
                            FROM    dbo.dls_fac_net (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V';

                    DECLARE @cur1_cnt INT ,
                        @cur1_i INT;

                    SET @cur1_i = 1;

				--Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;

                    WHILE ( @cur1_i <= @cur1_cnt )
                        BEGIN
                            SELECT  @i_delete_id = dls_sir_id
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur1_i;

                           -- EXECUTE SWPGetGlVar 'i_sp_id', @i_sp_id OUTPUT;
                            EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                @i_delete_id, @i_sp_id, @i_error_no OUTPUT,
                                @s_error_descr OUTPUT;
                            UPDATE  dbo.dls_fac_net
                            SET     dls_status = 'L'
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V'
                                    AND dls_sir_id = @i_delete_id;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_delete_id;
                            SET @cur1_i = @cur1_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var1;
                END;
	
           /*
		    SET @cSIR = CURSOR  FOR SELECT	dls_sir_id, alt_id, fc_type, phone_elig, fax_elig, print_dir,
		legal_entity, fc_tax_name, fc_name, pnrx, no2, hndacs,
		fc_opr_tory, ovr_ride, zip, city, state, county, country, mail
	
      FROM dbo.dls_fac_net (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'L';
            OPEN @cSIR;
       FETCH NEXT FROM @cSIR INTO @t_sir_id, @fc_alt_id, @t_fc_type,
                @t_phone_elig, @t_fax_elig, @t_print_dir, @t_legal_entity,
                @t_fc_tax_name, @t_fc_name, @t_pnrx, @t_no2, @t_hndacs,
                @t_fc_opr_tory, @t_ovr_ride, @t_zip, @t_city, @t_state,
                @t_county, @t_country, @t_mail;
            WHILE @@FETCH_STATUS = 0
			*/
            DECLARE @SWV_cursor_var2 TABLE
                (
                  id INT IDENTITY ,
                  dls_sir_id INT ,
                  alt_id CHAR(40) ,
                  fc_type CHAR(2) ,
                  phone_elig CHAR(1) ,
                  fax_elig CHAR(1) ,
                  print_dir CHAR(1) ,
                  legal_entity CHAR(2) ,
                  fc_tax_name CHAR(50) ,
                  fc_name CHAR(50) ,
                  pnrx CHAR(1) ,
                  no2 CHAR(1) ,
                  hndacs CHAR(1) ,
                  fc_opr_tory CHAR(11) ,
                  ovr_ride CHAR(1) ,
                  zip CHAR(10) ,
                  city CHAR(30) ,
                  state CHAR(2) ,
                  county CHAR(20) ,
                  country CHAR(3) ,
                  mail CHAR(1)
                );

            INSERT  INTO @SWV_cursor_var2
                    ( dls_sir_id ,
                      alt_id ,
                      fc_type ,
                      phone_elig ,
                      fax_elig ,
                      print_dir ,
                      legal_entity ,
                      fc_tax_name ,
                      fc_name ,
                      pnrx ,
                      no2 ,
                      hndacs ,
                      fc_opr_tory ,
                      ovr_ride ,
                      zip ,
                      city ,
                      state ,
                      county ,
                      country ,
                      mail
                    )
                    SELECT  dls_sir_id ,
                            alt_id ,
                            fc_type ,
                            phone_elig ,
                            fax_elig ,
                            print_dir ,
                            legal_entity ,
                            fc_tax_name ,
                            fc_name ,
                            pnrx ,
                            no2 ,
                            hndacs ,
                            fc_opr_tory ,
                            ovr_ride ,
                            zip ,
                            city ,
                            state ,
                            county ,
                            country ,
                            mail
                    FROM    dbo.dls_fac_net (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status = 'L';


            DECLARE @cur2_cnt INT ,
                @cur2_i INT;

            SET @cur2_i = 1;

				--Get the no. of records for the cursor
            SELECT  @cur2_cnt = COUNT(1)
            FROM    @SWV_cursor_var2;

            WHILE ( @cur2_i <= @cur2_cnt )
                BEGIN
                    BEGIN
					
                        SELECT  @t_sir_id = dls_sir_id ,
                                @fc_alt_id = alt_id ,
                                @t_fc_type = fc_type ,
                                @t_phone_elig = phone_elig ,
                                @t_fax_elig = fax_elig ,
                                @t_print_dir = print_dir ,
                                @t_legal_entity = legal_entity ,
                                @t_fc_tax_name = fc_tax_name ,
                                @t_fc_name = fc_name ,
                                @t_pnrx = pnrx ,
                                @t_no2 = no2 ,
                  @t_hndacs = hndacs ,
                                @t_fc_opr_tory = fc_opr_tory ,
                                @t_ovr_ride = ovr_ride ,
            @t_zip = zip ,
                                @t_city = city ,
                                @t_state = state ,
                                @t_county = county ,
                                @t_country = country ,
                                @t_mail = mail
                        FROM    @SWV_cursor_var2
                        WHERE   id = @cur2_i;

                       -- DECLARE @SWV_cursor_var2 CURSOR;
                        BEGIN TRY
                            SET @s_error = 'N';
                            IF @n_in_transaction = 'N'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'Y';
                                END;
		
                            SET @a_error_no = 10;
                            IF ( (@t_fc_type IS NULL
                                 OR @t_fc_type = '')
                               )
                                OR LEN(@t_fc_type) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     fc_type = 'D'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 20;
                            IF ( (@t_phone_elig IS NULL
                                 OR @t_phone_elig = '')
                               )
                                OR LEN(@t_phone_elig) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     phone_elig = 'Y'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 30;
                            IF ( (@t_fax_elig IS NULL
                                 OR @t_fax_elig = '')
                               )
                                OR LEN(@t_fax_elig) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     fax_elig = 'Y'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 40;
                            IF ( (@t_print_dir IS NULL
                                 OR @t_print_dir = '')
                               )
                                OR LEN(@t_print_dir) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     print_dir = 'Y'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 50;
                            IF ( (@t_legal_entity IS NULL
                                 OR @t_legal_entity = '')
                               )
                                OR LEN(@t_legal_entity) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     legal_entity = 'SP'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 60;
                            IF ( (@t_fc_tax_name IS NULL
                                 OR @t_fc_tax_name = '')
                               )
                                OR LEN(@t_fc_tax_name) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     fc_tax_name = @t_fc_name
                                WHERE   dls_batch_id = @a_batch_id
            AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 70;
                            IF ( (@t_pnrx IS NULL
                                 OR @t_pnrx = '')
        )
                                OR LEN(@t_pnrx) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     pnrx = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 80;
    IF ( (@t_no2 IS NULL
                                 OR @t_no2 = '')
                               )
                                OR LEN(@t_no2) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     no2 = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 90;
                            IF ( (@t_hndacs IS NULL
                                 OR @t_hndacs = '')
                               )
                                OR LEN(@t_hndacs) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     hndacs = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 100;
                            IF ( (@t_fc_opr_tory IS NULL
                                 OR @t_fc_opr_tory = '')
                               )
                                OR LEN(@t_fc_opr_tory) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     fc_opr_tory = '1'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 110;
                            IF ( (@t_ovr_ride IS NULL
                                 OR @t_ovr_ride = '')
                               )
                                OR LEN(@t_ovr_ride) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     ovr_ride = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 120;
                            IF ( (@t_country IS NULL
                                 OR @t_country = '')
                               )
                                OR LEN(@t_country) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     country = 'USA'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 130;
                            IF ( (@t_mail IS NULL
                                 OR @t_mail = '')
                               )
                                OR LEN(@t_mail) = 0
                                UPDATE  dbo.dls_fac_net
                                SET     mail = 'N'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		

                --CHANGE for handling multiple cities per zip
                            SET @a_error_no = 140;
                           
						   /*
						   SET @SWV_cursor_var2 = CURSOR  FOR SELECT city, state_code, county, zip_id
		     
               FROM dbo.usa_zip (NOLOCK)
               WHERE zip_code = SUBSTRING(@t_zip,1,5)
               ORDER BY zip_id;
                            OPEN @SWV_cursor_var2;
    FETCH NEXT FROM @SWV_cursor_var2 INTO @d_city,
                                @d_state, @d_county, @i_zip_id;
                            WHILE @@FETCH_STATUS = 0
							*/ 
                            DECLARE @SWV_cursor_var3 TABLE
                              (
                                  id INT IDENTITY ,
                                  city CHAR(30) ,
                                  state_code CHAR(2) ,
                                  county CHAR(20) ,
                                  zip_id INT
   );

                            INSERT  INTO @SWV_cursor_var3
     ( city ,
                                      state_code ,
                                      county ,
                                      zip_id
                                    )
                                    SELECT  city ,
                                            state_code ,
                                            county ,
                                            zip_id
                                    FROM    dbo.usa_zip (NOLOCK)
                                    WHERE   zip_code = SUBSTRING(@t_zip, 1, 5)
                                    ORDER BY zip_id;


                            DECLARE @cur3_cnt INT ,
                                @cur3_i INT;

                            SET @cur3_i = 1;

				--Get the no. of records for the cursor
                            SELECT  @cur3_cnt = COUNT(1)
                            FROM    @SWV_cursor_var3;

                            WHILE ( @cur3_i <= @cur3_cnt )
                                BEGIN
                                    SELECT  @d_city = city ,
                                            @d_state = state_code ,
                                            @d_county = county ,
                                            @i_zip_id = zip_id
                                    FROM    @SWV_cursor_var3
                                    WHERE   id = @cur3_i;
                                    GOTO SWL_Label2;
                                    /*
									FETCH NEXT FROM @SWV_cursor_var2 INTO @d_city,
                                        @d_state, @d_county, @i_zip_id;
										*/
                                    SET @cur3_i = @cur3_i + 1;
                                END;
                            SWL_Label2:
                            --CLOSE @SWV_cursor_var2;
                            SET @a_error_no = 150;
                            IF ( @t_city IS NULL
                                 OR @t_city = ''
                               )
                                AND ( @d_city IS NOT NULL
                                      AND @d_city <> ''
                                    )
                                UPDATE  dbo.dls_fac_net
                                SET     city = @d_city
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 160;
                            IF ( @t_state IS NULL
                                 OR @t_state = ''
                               )
                                AND ( @d_state IS NOT NULL
                                      AND @d_state <> ''
                                    )
                                UPDATE  dbo.dls_fac_net
                                SET     state = @d_state
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @t_sir_id;
		
                            SET @a_error_no = 170;
                            IF ( @t_county IS NULL
                                 OR @t_county = ''
                               )
                                AND ( @d_county IS NOT NULL
                                      AND @d_county <> ''
                                    )
                                UPDATE  dbo.dls_fac_net
                                SET     county = @d_county
                                WHERE   dls_batch_id = @a_batch_id
                         AND dls_sir_id = @t_sir_id;
		
                            IF @s_error = 'Y'
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    UPDATE  dbo.dls_fac_net
                                    SET     dls_status = 'E'
  WHERE  dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
                            ELSE
                                BEGIN
                                    SET @n_process_count = @n_process_count
                                        + 1;
                                    SET @n_succ_count = @n_succ_count + 1;
                                    UPDATE  dbo.dls_fac_net
                                    SET     dls_status = 'V'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
		
                            IF @n_process_count % 100 = 0
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = @n_process_count
                                        - @n_succ_count
                                WHERE   bat_statistics_id = @i_statistics_id;
		
                            IF @n_in_transaction = 'Y'
                                BEGIN
                                    
                                    SET @n_in_transaction = 'N';
                                END;
                        END TRY
                        BEGIN CATCH
						IF ERROR_NUMBER() = 50000
						BEGIN
						 EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @a_error_no;
								END
								ELSE
								BEGIN

                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @n_in_transaction = 'Y'
                                        BEGIN
                                            
                                            SET @n_in_transaction = 'N';
                                        END;
				
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
			
                           -- EXECUTE SWPGetGlVar 'i_sp_id', @i_sp_id OUTPUT;
                           -- EXECUTE SWPGetGlVar 'i_sir_def_id',
                              --  @i_sir_def_id OUTPUT;
                            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @i_sp_id, @i_sir_def_id, @t_sir_id,
                                @a_error_no;
                            IF @i_fatal <> 1
                                SET @s_error = 'Y';
								END
                        END CATCH;
                    END;
                    /*
					FETCH NEXT FROM @cSIR INTO @t_sir_id, @fc_alt_id,
                        @t_fc_type, @t_phone_elig, @t_fax_elig, @t_print_dir,
                        @t_legal_entity, @t_fc_tax_name, @t_fc_name, @t_pnrx,
                        @t_no2, @t_hndacs, @t_fc_opr_tory, @t_ovr_ride, @t_zip,
                @t_city, @t_state, @t_county, @t_country, @t_mail;
						*/
                    SET @cur2_i = @cur2_i + 1;
                END;
            --CLOSE @cSIR;
            SET @n_error_count = @n_process_count - @n_succ_count;
            EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @n_error_count
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                    + @n_error_count ),
                                                 ' Failed to update statistics');
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish After-load process for Batch ',
                                         @a_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

	--trace off;



	--set debug file to "/tmp/dlp_al_fac_net.trc";
	--trace on;

    END;