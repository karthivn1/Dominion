﻿CREATE PROCEDURE [dbo].[dlp_bu_lockbox]
    @p_batch_id INT ,
    @p_sir_id INT ,
    @p_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_bu_lockbox
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This SP performs before update pre-processing on DataDental
--           LockBox for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------

/*
check_no field will no longer be required.
*/
AS
    BEGIN
/*-- This procedure was converted on Fri Aug 19 05:40:40 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB,











 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).

   */
   
   
        DECLARE @s_sir_def_name VARCHAR(18);
        DECLARE @s_proc_name VARCHAR(18);
   
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @s_err_rtn_text VARCHAR(64);
        DECLARE @s_error CHAR(1);
        DECLARE @i_fatal INT;
        DECLARE @a_error_no INT;

        DECLARE @i_tmp_sp_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @i_invoice_no INT;
   
        DECLARE @s_dls_status CHAR(1);
        DECLARE @s_alloc_flag CHAR(1);

        DECLARE @t_invoice_no CHAR(9);		--char(9).
        DECLARE @t_invoice_date CHAR(8);		--char(8).
        DECLARE @t_invoice_amt CHAR(9);		--char(9).
        DECLARE @t_check_no CHAR(9);			--char(9).
        DECLARE @t_paid_amt CHAR(9);			--char(9).
        DECLARE @t_dls_group_id INT;		--integer.
   --define n_dep_acct     like dls_lockbox.dls_deposit_acct;	--char(30).
        DECLARE @t_pay_token CHAR(50);		--char(50).

        DECLARE @s_pay_max VARCHAR(12);
   
        DECLARE @s_batch_type CHAR(1);
        DECLARE @s_alw_non_annl CHAR(1);
        DECLARE @g_ck_tol CHAR(1);
        DECLARE @s_acct_num CHAR(20);
        DECLARE @s_group_type CHAR(2);
	
        DECLARE @m_paid_amt MONEY;
        DECLARE @m_tot_paid MONEY;
        DECLARE @m_pay_max MONEY;
   
        DECLARE @i_oc_id INT;
        DECLARE @i_group_id INT;
        DECLARE @i_check_no INT;
   
        DECLARE @c_prev_err CHAR(1);
   
        DECLARE @i_process_count INT;
        DECLARE @i_error_count INT;
        DECLARE @i_succ_count INT;
        DECLARE @i_init_count INT;
        DECLARE @t_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @SWV_dl_get_sp_id INT;
        --DECLARE @cSIR CURSOR;
        --DECLARE @cCHECK_ERR CURSOR;
		
								DECLARE @cSIR TABLE
                                (
                                  id INT IDENTITY ,
                                  dls_sir_id INT,
								  invoice_no varchar(10),   
								  invoice_date varchar(10),   
								  invoice_amt varchar(10),   
								  check_no varchar(10),   
								  paid_amt varchar(10),   
								  dls_group_id INT,   
								  pay_token varchar(50)
                                );
								
								DECLARE @cCHECK_ERR TABLE
                                (
                                  id INT IDENTITY ,
                                  dls_sir_id INT,
								  group_id INT, 
								  error_no INT
                                );

        DECLARE @SWV_dl_upd_statistics INT;

   -------------------exception handling--------------------------------------
   

   -- intrpt - server or user terminated -----NO ROLLBACK---
 SET NOCOUNT ON;

 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 5 AND BatchId = @p_batch_id )
 BEGIN
	 INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id]) 
	  SELECT N'i_sir_def_id',		 N'', @p_batch_id, 5
	  UNION ALL SELECT N'i_sp_id',	 N'', @p_batch_id, 5
	  UNION ALL SELECT N't_sir_id',	 N'', @p_batch_id, 5
	  
 END
        SET @t_sir_id = 0;
      
        SET @i_sp_id = 0;

        SET @i_sir_def_id = 0;
 
        BEGIN TRY
             
   
--   set debug file to "/tmp/dlp_bu_lockbox.trc";
--   TRACE ON;
   

            SET @s_proc_name = 'bu_lockbox';
            SET @s_sir_def_name = 'lockbox';
            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @p_batch_id, @s_proc_name

		
            SET @i_sp_id = @SWV_dl_get_sp_id;

			UPDATE GlobalVar SET VarValue=@i_sp_id WHERE BatchId=@p_batch_id AND  Module_Id = 5 and VarName='i_sp_id'
        
            IF @i_sp_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
				RETURN
			END
   
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);

			UPDATE GlobalVar SET VarValue=@i_sir_def_id WHERE BatchId=@p_batch_id AND  Module_Id = 5 and VarName='i_sir_def_id'
            
            IF @i_sir_def_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve valid SIR Table ID',16,1);
				RETURN
			END
   

   ------------------get params from user-------------------------------------
            
            SET @s_pay_max = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                    'Max Amount');
            IF ( @s_pay_max IS NULL
                 OR @s_pay_max = ''
               )
                OR LEN(@s_pay_max) = 0
				BEGIN
					SET @i_error_no=0
                RAISERROR('Missing Max Allowed Payment Value',16,1);
				RETURN
			END
            ELSE
                BEGIN
                    SET @a_error_no = 170;
                    SET @m_pay_max =CAST(@s_pay_max AS MONEY);
                    SET @a_error_no = 0;
                END;  -- reset err no
   
            
            SET @g_ck_tol = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                   'Check Pay Tol');
            IF ( @g_ck_tol IS NULL
                 OR @g_ck_tol = ''
               )
                OR LEN(@g_ck_tol) = 0
				BEGIN
				SET @i_error_no=0
                RAISERROR('Missing Check Payment Tolerance Value',16,1);
				RETURN
			END
            ELSE
                IF @g_ck_tol NOT IN ( 'Y', 'N' )
				BEGIN
					SET @i_error_no=0
                    RAISERROR('Check Payment Tolerance Type must be (Y or N)',16,1);
					RETURN
			END
      
   

   -- get data using gen procs                                    --
   -- this param is also used in afterload, so just grab that one --
            EXECUTE @i_tmp_sp_id = dbo.dl_get_sp_id @p_batch_id, 'al_lockbox';
            IF @i_tmp_sp_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve Store Procedure ID for Parameter',16,1);
				RETURN
			END
   
            SET @s_batch_type = dbo.dl_get_param_value(@p_batch_id,
                                                       @i_tmp_sp_id,
                                                       'Batch Type');
            SET @i_tmp_sp_id = NULL;	--Only used once just above to grab a parameter value
   							--which is associated with After Load, but also the
							--parameter value is needed here in pre-processing
							--(the third of four steps).
   
            IF ( @s_batch_type IS NULL
                 OR @s_batch_type = ''
               )
                OR LEN(@s_batch_type) = 0
				BEGIN
				SET @i_error_no=0
                RAISERROR('Missing Batch Type Value',16,1);
				RETURN
			END
            ELSE
            IF @s_batch_type NOT IN ( 'G', 'I' )
				BEGIN
					SET @i_error_no=0
                    RAISERROR('Batch Type must be (G or I)',16,1);
					RETURN
			END
      
   
   
   -- for single groups, get flag indicating whether non-annual bill freq allow
            IF @s_batch_type LIKE 'I'
                BEGIN
                    
                    SET @s_alw_non_annl = dbo.dl_get_param_value(@p_batch_id,
                                                              @i_sp_id,
                                                              'Non-Annuals');
      IF ( @s_alw_non_annl IS NULL
                         OR @s_alw_non_annl = ''
                       )
                        OR LEN(@s_alw_non_annl) = 0
						BEGIN
						SET @i_error_no=0
          RAISERROR('Missing Single Group Non-Annuals Flag',16,1);
						RETURN
			END
                    ELSE
            IF @s_alw_non_annl NOT IN ( 'Y', 'N' )
				BEGIN
							SET @i_error_no=0
								RAISERROR('Non-Annuals Flag must be (Y or N)',16,1);
								RETURN
				END
         
                END;
   
   
   -- prepare for keeping stats on preprocessing-----------------------------
            
            EXECUTE dbo.dl_it_statistics @p_batch_id, @i_sp_id, @p_start_time,
                @i_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_descr OUTPUT;
            IF @i_error_no <= 0
			BEGIN
			SET @i_error_no=0
                RAISERROR('(Internal) error when creating statistics',16,1);
				RETURN
			END
   

   -- remove any previously logged actions from prior pre-process runs
            IF @p_sir_id > 0
      -- for when running single row at a time
                BEGIN
                    IF EXISTS ( SELECT  *
                                FROM    dbo.dl_action (NOLOCK)
                                WHERE   batch_id = @p_batch_id
                                        AND dls_sir_id = @p_sir_id )
                        DELETE  FROM dbo.dl_action
                        WHERE   batch_id = @p_batch_id
                                AND dls_sir_id = @p_sir_id;
                END;
            ELSE
                IF EXISTS ( SELECT  *
                            FROM    dbo.dl_action (NOLOCK)
                            WHERE   batch_id = @p_batch_id
                                    AND dls_sir_id IN (
                                    SELECT  dls_sir_id
                                    FROM    dbo.dls_lockbox (NOLOCK)
                                    WHERE   dls_batch_id = @p_batch_id
                                            AND dls_status = 'V' ) )
                    DELETE  FROM dbo.dl_action
                    WHERE   batch_id = @p_batch_id
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_lockbox (NOLOCK)
                            WHERE   dls_batch_id = @p_batch_id
                                    AND dls_status = 'V' );
  
   
   
   -- check if there were errors logged for prev runs
            IF EXISTS ( SELECT  *
                        FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @p_batch_id
                                AND sp_id = @i_sp_id )
                SET @c_prev_err = 'T';
            ELSE
                SET @c_prev_err = 'F';
   

   -- get initial count of rows that have passed pre-processing --
            SELECT  @i_init_count = COUNT(*)
            FROM    dbo.dls_lockbox (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'P';

   -- create a temp table that will hold pymt tol errs---------
            CREATE TABLE #dls_lockbox_var
                (
                  tt_id INT IDENTITY
                            NOT NULL
                            PRIMARY KEY ,
                  dls_sir_id INT ,
      group_id INT ,
                  error_no INT
                ); 
            CREATE INDEX dls_lockbox_var1 ON #dls_lockbox_var 
            (group_id);
            CREATE INDEX dls_lockbox_var2 ON
            #dls_lockbox_var 
            (dls_sir_id,
         group_id,
            error_no);
		
   -- create a temp table that will hold pymt tol errs---------
            CREATE TABLE #dls_lb_money_paid
                (
                  tt_id INT IDENTITY
                            NOT NULL
                            PRIMARY KEY ,
             group_id INT ,
                  paid_amt DECIMAL(16, 2)
                ); 
            CREATE INDEX dls_lb_money_paid1 ON #dls_lb_money_paid 
            (group_id);
             
            SET @i_process_count = 0;
   -- single row passed in

      /*------- catch all other errors -------*/
            SET @i_succ_count = 0;
    
   /*--------------------------------------* /
   / * begin PRE-PROCESS, one row at a time * /
   / *--------------------------------------*/
   

      ------- conversion err - char to numeric or numeric to char -------
      

      ------- code gen err -------
      
      
      ---------perform initial checks-------------------------------------------
	   INSERT INTO @cSIR (dls_sir_id, invoice_no,   invoice_date,   invoice_amt,   check_no,   paid_amt,   dls_group_id,   pay_token)
	   SELECT dls_sir_id, invoice_no,   invoice_date,   invoice_amt,   check_no,   paid_amt,   dls_group_id,   pay_token
            FROM dbo.dls_lockbox (NOLOCK)
      WHERE dls_batch_id = @p_batch_id
      AND dls_status = 'V'
      AND ((@p_sir_id > 0 AND dls_sir_id = @p_sir_id) -- allows procees for
      OR   (@p_sir_id = 0 AND dls_sir_id > 0))
            /*SET @cSIR = CURSOR  FOR SELECT dls_sir_id, invoice_no,   invoice_date,   invoice_amt,   check_no,   paid_amt,   dls_group_id,   pay_token
      
      FROM dbo.dls_lockbox (NOLOCK)
      WHERE dls_batch_id = @p_batch_id
      AND dls_status = 'V'
      AND ((@p_sir_id > 0 AND dls_sir_id = @p_sir_id) -- allows procees for
      OR   (@p_sir_id = 0 AND dls_sir_id > 0));
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_invoice_no,
                @t_invoice_date, @t_invoice_amt, @t_check_no, @t_paid_amt,
                @t_dls_group_id, @t_pay_token;
            WHILE @@FETCH_STATUS = 0 */
				 DECLARE @cur_cnt INT ,
                                @cur_i INT;

                            SET @cur_i = 1;

				--Get the no. of records for the cursor
                            SELECT  @cur_cnt = COUNT(1)
                            FROM    @cSIR;

                            WHILE ( @cur_i <= @cur_cnt )
                BEGIN
				SELECT @t_sir_id = dls_sir_id, @t_invoice_no = invoice_no,
                @t_invoice_date =invoice_date , @t_invoice_amt = invoice_amt, @t_check_no = check_no, @t_paid_amt = paid_amt,
                @t_dls_group_id = dls_group_id, @t_pay_token = pay_token from @cSIR where id = @cur_i

				UPDATE GlobalVar SET VarValue=@t_sir_id WHERE BatchId=@p_batch_id AND  Module_Id = 5 and VarName='t_sir_id'

                    BEGIN

         /* sets status to Error if condition deemed fatal * /
         

         / * sets status to Error if condition deemed fatal */
                        BEGIN TRY
                            
      
      -- if this proc and batch had prev stored errors, then
      -- call sub-proc to see if it was this row, and if so, 
      -- move to err history table
                            IF @c_prev_err = 'T'
                                BEGIN
                                    
                                    EXECUTE dbo.dl_clean_curr_err @p_batch_id,
                                        @t_sir_id, @i_sp_id,
                                        @i_error_no OUTPUT,
                                        @s_err_rtn_text OUTPUT;
                         END;
      
      
      -- set to default values
                            SET @s_alloc_flag = 'A';
							 SET @s_error = 'N';
                            SET @i_process_count = @i_process_count + 1;
      
      /* check invoice amount for null */
                            IF ( @t_invoice_amt IS NULL
                                 OR @t_invoice_amt = ''
 )
         SET @t_invoice_amt = '0';	--Added 20131205.
         --RAISE EXCEPTION -746, 52, "No Invoice Amt";	--Taken out 20131205.
      

      /* check invoice number for null and convert to an int */
              SET @i_invoice_no = NULL;
			                              IF ( ( @t_invoice_no IS NULL
                                   OR @t_invoice_no = ''
                                 )
                                 OR LEN(RTRIM(LTRIM(@t_invoice_no))) = 0
                               )
	  	--let t_invoice_no = "0";	--Added 20131205.  Commented out 20131206.
		--let t_invoice_no = t_dls_group_id;	--Added 20131206.  Out 20131206.
						BEGIN
							SET @i_error_no=61
                                RAISERROR('No Invoice No',16,1);	--Invoice number should have been set to something
		 											--in dlp_al_lockbox().
							END
                            SET @a_error_no = 60;
                            SET @i_invoice_no = @t_invoice_no;

	  /*	Commented out 20131205.
      / * check invoice date for null * /
      IF t_invoice_date is NULL THEN
         RAISE EXCEPTION -746, 70, "No Invoice Date";
      END IF;
	  */
	  
	  --Added this paragraph 20131205.
	  
                            IF ( (@t_paid_amt IS NULL
                                 OR @t_paid_amt = '')
                               )
                                SET @t_paid_amt = '0';
	  
	  
      /* check paid amount is not null and within range */
                            SET @m_paid_amt = NULL;
                            SET @a_error_no = 55;
                            SET @m_paid_amt = CAST(@t_paid_amt AS MONEY);
                            SET @a_error_no = 0;
	  
/*20131124$$ks -- Can be null or zero if Token being updated
 *
 *     IF t_paid_amt is NULL OR 
 *        m_paid_amt < 0.01 OR 
 *        m_paid_amt > m_pay_max THEN
 *        
 *        RAISE EXCEPTION -746, 57, "Paid amount null or out of range";
 *     END IF;
 * /
	
	/ *
	20131217:  dls_lockbox.check_no at this stage in processing, due to the
	previous work of procedure dlp_al_lockbox(), will either be null or will
	be a legitimate check number string holding only digits.  So, no further checks
	at this stage are needed.
	*/
	
	--/ *  20131205:  check number will not be inserted into any tables.
	
	-- convert check # to an int for later use
	
                            SET @i_check_no = NULL;
                            IF ( NOT ( @t_check_no IS NULL
                                       OR @t_check_no = ''
                                     )
                               )
		--LET a_error_no = 65;
                                BEGIN
                                    SET @i_check_no = @t_check_no;
                                    SET @a_error_no = 0;
                                END;
	
	--*/
	  
	  --Employer group
      ------------checks based on batch type 'group'----------------- DataLoad Employer Group (EG).
      
                            IF @s_batch_type = 'G'
      	/* Temp out.  This check doesn't make sense for what we are doing at this time
			until underlying code is revised.
			
			So, for us at Dominion Dental, we need the dls_alloc_flag which has to
			do with "allocation tolerance" and the dls_deposit_acct (bank account
			number).
			
			We will not look up the group ID using the invoice number, just use the
			group ID we already know (t_dls_group_id).
		 */
                                BEGIN 
             --i_group_id, 
           EXECUTE dbo.dlp_lb_group @t_dls_group_id,
                                        @p_batch_id, @i_invoice_no, @g_ck_tol,
                                        @m_paid_amt, @i_error_no OUTPUT,
                                        @s_alloc_flag OUTPUT,
                                        @s_acct_num OUTPUT,
                                        @s_error_descr OUTPUT;
                           SET @i_group_id = @t_dls_group_id;
		 --let i_error_no = 0;	--Temp line.
		 
         -- fatal err occurred and was logged
                                    IF @i_error_no = -1
                      BEGIN
                       UPDATE  dbo.dls_lockbox
                                            SET     dls_status = 'E'
											WHERE   dls_batch_id = @p_batch_id
											AND dls_sir_id = @t_sir_id 
                    -- WHERE CURRENT OF @cSIR;
                 
            
            -- continue looping on next row in batch
                                            GOTO SWL_Label2;
                                        END;
                                    ELSE
                                        IF @i_error_no < -1
                                            BEGIN
                                                 
                                                DROP TABLE #dls_lockbox_var;
                                                DROP TABLE #dls_lb_money_paid;
                                                SET @SWP_Ret_Value = -1;
                                                SET @SWP_Ret_Value1 = @s_error_descr;
                                                RETURN;
                                            END;
                                END;
         
	  --Single Group
	  
                            ELSE ------ batch type is "I" - individual------------------ DataLoad Single Group (SG).

      	/* Temp out.  This check doesn't make sense for what we are doing at this time
			until underlying code is revised.
			
			So, for us at Dominion Dental, we need the dls_alloc_flag which has to
			do with "allocation tolerance" and the dls_deposit_acct (bank account
			number).
			
			We will not look up the group ID using the invoice number, just use the
			group ID we already know (t_dls_group_id).
		 */
                                BEGIN
             --i_group_id,
                                    EXECUTE dbo.dlp_lb_indv @t_dls_group_id,
                                        @p_batch_id, @i_invoice_no,
                                        @m_paid_amt, @g_ck_tol,
                                        @s_alw_non_annl, @i_error_no OUTPUT,
                                        @s_alloc_flag OUTPUT,
                                        @s_acct_num OUTPUT,
                                        @s_error_descr OUTPUT;
                                    SET @i_group_id = @t_dls_group_id;
		 --let i_error_no = 0;	--Temp line.
		 
         -- fatal err occurred and was logged
                                    IF @i_error_no = -1
                                        BEGIN
                                            UPDATE  dbo.dls_lockbox
                                            SET     dls_status = 'E'
											WHERE   dls_batch_id = @p_batch_id
											AND dls_sir_id = @t_sir_id
                                         --   WHERE CURRENT OF @cSIR;
                                             
            
      -- continue looping on next row in batch
                                            GOTO SWL_Label2;
                                        END;
                                    ELSE
                                        IF @i_error_no < -1
                                            BEGIN
                                                 
                                                DROP TABLE #dls_lockbox_var;
                                                DROP TABLE #dls_lb_money_paid;
                                               SET @SWP_Ret_Value = -1;
                                                SET @SWP_Ret_Value1 = @s_error_descr;
                                          RETURN;
                                            END;
                                END;
           -- else batch type "I"
      
	 /*
      -----------check batch already stored in allocation tables ----------------
      IF EXISTS( SELECT credit_id
                 FROM al_batches
                 WHERE group_id = i_group_id
  AND   amount = m_paid_amt
                 AND   check_no = i_check_no)  THEN

         RAISE EXCEPTION -746, 150, "Record already loaded";
      END IF;
      */
	  
      ------------update dls_lockbox with acquired data-------------------------
	  
	  /*
	  I guess some lines from the following paragraph
	  comes out for now also since it is updating stuff
	  that is not related to Dominion Dental.
	  */
	  
	  
                            IF @s_error = 'Y'
                                UPDATE  dbo.dls_lockbox
                                SET     dls_status = 'E' ,
                --dls_group_id     = i_group_id,
                                        dls_deposit_acct = @s_acct_num ,
                                        dls_alloc_flag = @s_alloc_flag
										WHERE   dls_batch_id = @p_batch_id
										AND dls_sir_id = @t_sir_id
                                -- WHERE  CURRENT OF @cSIR;
                            ELSE
                                BEGIN
                                    UPDATE  dbo.dls_lockbox
                                    SET     dls_status = 'P' ,
                --dls_group_id     = i_group_id,
                                            dls_deposit_acct = @s_acct_num ,
                                            dls_alloc_flag = @s_alloc_flag
											WHERE   dls_batch_id = @p_batch_id
											AND dls_sir_id = @t_sir_id
                                   -- WHERE  CURRENT OF @cSIR;
                        SET @i_succ_count = @i_succ_count + 1;
                                END;
      
	  
	  
      ---------update stats every 100 records-----------------------
                            IF @i_process_count % 100 = 0
                                BEGIN
                                    SET @i_error_count = @i_process_count
                                        - @i_succ_count;

      -----update the stats----------
                                    UPDATE  dbo.dl_bat_statistics
                                    SET     tot_record = @i_process_count ,
                                            tot_success_rec = @i_succ_count ,
                                            tot_fail_rec = @i_error_count
                                    WHERE   bat_statistics_id = @i_statistics_id;
                                END;
      
                             
                        END TRY
                        BEGIN CATCH
                            --SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            
							
         --- problems retrieving data from dB----
		 IF ERROR_NUMBER()=50000
		 BEGIN
                                    
                                   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                        @i_sp_id, @i_sir_def_id, @t_sir_id,
                                        @i_error_no;
                                   
                                    GOTO SWL_Label2;
		END;

                            IF @i_error_no IN ( -244, -245, -246 )
                                BEGIN
                                    
                                   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
          @i_sp_id, @i_sir_def_id, @t_sir_id,
                                 1000;
                                   
                                    GOTO SWL_Label2;
                                END;
                            ELSE
                                BEGIN
                                    DROP TABLE #dls_lockbox_var;
                              DROP TABLE #dls_lb_money_paid;
                                   SET @s_err_rtn_text = 'DB Error: '
                                        + cast (@i_error_no as varchar)+ ' Error msg: '
                                        + @s_error_descr;
                                    SET @SWP_Ret_Value = -1;
                                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                                    RETURN;
                                END;
                        END CATCH;
                    END;
                    SWL_Label2:
                    /*FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_invoice_no,
                        @t_invoice_date, @t_invoice_amt, @t_check_no,
                        @t_paid_amt, @t_dls_group_id, @t_pay_token; */
						set @cur_i = @cur_i + 1
          END;
           -- CLOSE @cSIR;  -- major loop------------------------------------------------

            

   -- now loop thru temp table and log errs for tolerance failures
            SET @s_error = 'N';
            SET @t_sir_id = NULL;
            
            SET @i_group_id = NULL;
   SET @a_error_no = 0;
			 INSERT INTO @cCHECK_ERR (dls_sir_id, group_id, error_no)
			 SELECT dls_sir_id, group_id, error_no
            FROM #dls_lockbox_var
      WHERE dls_sir_id IS NOT NULL
      AND   group_id   IS NOT NULL
      AND   error_no   IS NOT NULL
            /* SET @cCHECK_ERR = CURSOR  FOR SELECT dls_sir_id, group_id, error_no
            
      FROM #dls_lockbox_var
      WHERE dls_sir_id IS NOT NULL
      AND   group_id   IS NOT NULL
      AND   error_no   IS NOT NULL;
            OPEN @cCHECK_ERR;
            FETCH NEXT FROM @cCHECK_ERR INTO @t_sir_id, @i_group_id,
                @a_error_no;
            WHILE @@FETCH_STATUS = 0 */

				 DECLARE @cur2_cnt INT ,
                                @cur2_i INT;

                            SET @cur2_i = 1;

				--Get the no. of records for the cursor
                            SELECT  @cur2_cnt = COUNT(1)
                            FROM    @cCHECK_ERR;

                            WHILE ( @cur2_i <= @cur2_cnt )

                BEGIN
				SELECT @t_sir_id = dls_sir_id, @i_group_id = group_id,
                @a_error_no = error_no from @cCHECK_ERR where id = @cur2_i


                    EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id, @i_sp_id,
                        @i_sir_def_id, @t_sir_id, @a_error_no;
                    IF @i_fatal <> 1
                        UPDATE  dbo.dls_lockbox
                        SET     dls_status = 'E'
                        WHERE   dls_batch_id = @p_batch_id
                                AND dls_sir_id = @t_sir_id;
      
                    SET @s_error = 'N';
                    SET @t_sir_id = NULL;
                    
                    SET @i_group_id = NULL;
                    SET @a_error_no = 0;
                   /* FETCH NEXT FROM @cCHECK_ERR INTO @t_sir_id, @i_group_id,
                        @a_error_no; */
						SET @cur2_i = @cur2_i + 1
                END;
            --CLOSE @cCHECK_ERR;
             
   
   ---------------perform final err count, update stats-----------------------
            
            DROP TABLE #dls_lockbox_var;
            DROP TABLE #dls_lb_money_paid;
            SELECT  @i_succ_count = COUNT(*)
            FROM    dbo.dls_lockbox (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'P';
            SET @i_succ_count = @i_succ_count - @i_init_count;
            SET @i_error_count = @i_process_count - @i_succ_count;
			EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
                @i_succ_count, @i_error_count
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(( @i_process_count ),
                              ' Failed to update statistics');
						IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 5 AND BatchId = @p_batch_id )
						BEGIN
							DELETE FROM GlobalVar WHERE Module_Id = 5 AND BatchId = @p_batch_id
						END
                    RETURN;
                END;
   
            UPDATE  dbo.dl_cfg_bat_det
			SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
             
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished Preprocess for Batch ',
                                         @p_batch_id);

					IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 5 AND BatchId = @p_batch_id )
					BEGIN
						DELETE FROM GlobalVar WHERE Module_Id = 5 AND BatchId = @p_batch_id
					END
            RETURN;
        END TRY
        BEGIN CATCH
			IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 5 AND BatchId = @p_batch_id )
			BEGIN
				DELETE FROM GlobalVar WHERE Module_Id = 5 AND BatchId = @p_batch_id
			END
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
             
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
		 SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

--   TRACE OFF;


   
   -------------begin body of proc--------------------------------------------
    END;