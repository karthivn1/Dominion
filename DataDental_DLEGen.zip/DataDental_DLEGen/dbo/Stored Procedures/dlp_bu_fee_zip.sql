﻿/***************************************************************************************************************
DATE :08/02/2016
MODIFIED BY :COGNIZANT
CHANGE DESCRIPTION :Invalid column name SWV_dl_log_error (SQLWAYS conversion issue)
CHANGE NUMBER :CH001
*****************************************************************************************************************/
CREATE PROCEDURE [dbo].[dlp_bu_fee_zip]
@a_batch_id INT ,
@a_sir_id INT ,
@a_start_time VARCHAR(22) ,
@SWP_Ret_Value INT = NULL OUTPUT ,
@SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT

------------------------------------------------------------------------------
--
-- Procedure: dlp_bu_fee_zip
--
-- Created: 06/04/1999 
-- Author: Ameeta Mahendra
--
-- Purpose: This SP performs before update pre-processing on DataDental
-- fee schedule zip for the DataLoad Product of STC
--
--
-- Modification History:
--
-- DATE AUTHOR DETAILS
--
-------------------------------------------------------------------------------
AS
BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
　
　
DECLARE @i_cfg_bat_det_id INT;
DECLARE @c_prev_err CHAR(1);
DECLARE @i_statistics_id INT;
DECLARE @n_error_no INT;
DECLARE @s_proc_name CHAR(14);
DECLARE @s_sir_def_name CHAR(14);
DECLARE @i_process_count INT;
DECLARE @i_succ_count INT;
DECLARE @i_init_count INT;
DECLARE @i_error_count INT;
DECLARE @i_error_no INT;
DECLARE @i_error INT;
DECLARE @i_fatal INT;
DECLARE @s_error_text VARCHAR(64);
DECLARE @s_err_rtn_text VARCHAR(64);
DECLARE @i_isam_error INT;
DECLARE @s_zip_code_3 CHAR(3);
DECLARE @s_zip_code CHAR(3);
　
DECLARE @i_zip_code_3 INT;
DECLARE @i_zip_code INT;
DECLARE @s_p_source CHAR(6);
DECLARE @s_p_version CHAR(6);
DECLARE @i_sir_id integer 
DECLARE @i_sp_id integer 
DECLARE @i_sp_id2 integer 
DECLARE @i_sir_def_id integer 

DECLARE @SWV_dl_get_sp_id INT;
DECLARE @SWV_dl_get_sir_def_id INT;
-- DECLARE @cFeeSIR CURSOR;
DECLARE @cFeeSIR TABLE
(
id INT IDENTITY ,
dls_sir_id INT,
zip_code_3 VARCHAR(3), 
zip_code VARCHAR(3)
);
DECLARE @SWV_dl_upd_statistics INT;
DECLARE @SWV_dl_log_error INT;
-----exception handling------------------------------------------
SET NOCOUNT ON;
SET @i_sir_id = 0;
SET @i_sp_id = 0;
SET @i_sp_id2 = 0;
SET @i_sir_def_id = 0;
BEGIN TRY
--SET DEBUG FILE TO '/tmp/dlp_bu_fee_zip.trc';
--TRACE ON;
-----Initialize stored procedure variables-----------------------------------
SET @s_proc_name = 'bu_fee_zip';
SET @s_sir_def_name = 'fee_zip';
EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, @s_proc_name
SET @i_sp_id = @SWV_dl_get_sp_id 
IF @i_sp_id = -1
BEGIN
SET @i_isam_error=0
RAISERROR('Can not retrieve valid Store Procedure ID',16,1);
RETURN
END
EXECUTE @SWV_dl_get_sp_id = dbo.dl_get_sp_id @a_batch_id, 'up_fee_sched'
SET @i_sp_id2 = @SWV_dl_get_sp_id
IF @i_sp_id2 = -1
BEGIN
SET @i_isam_error=0
RAISERROR('Can not retrieve valid Store Procedure ID',16,1);
RETURN
END
EXECUTE @SWV_dl_get_sir_def_id = dbo.dl_get_sir_def_id @s_sir_def_name
SET @i_sir_def_id = @SWV_dl_get_sir_def_id
IF @i_sir_def_id = -1
BEGIN
SET @i_isam_error=5
RAISERROR('Can not retrieve valid SIR TABLE Definition ID',16,1);
RETURN
END
　
　
-- check if there were errors logged for prev runs
IF EXISTS ( SELECT *
FROM dbo.dl_log_error (NOLOCK)
WHERE config_bat_id = @a_batch_id
AND sp_id = @i_sp_id )
SET @c_prev_err = 'T';
ELSE
SET @c_prev_err = 'F';
　
　
-- get initial count of rows that have passed pre-processing --
SELECT @i_init_count = COUNT(*)
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_status = 'P';
/*
SELECT cfg_bat_det_id INTO i_cfg_bat_det_id
FROM dl_cfg_bat_det
WHERE config_bat_id = a_batch_id and sp_id = i_sp_id;
--*/
-- EXECUTE SWPGetGlVar 'i_sp_id', @i_sp_id OUTPUT;
EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
@n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
@i_statistics_id OUTPUT, @s_error_text OUTPUT;
IF @n_error_no <= 0
BEGIN
SET @i_isam_error=0
RAISERROR('(Internal) error when creating statistics',16,1);
RETURN
END
SET @i_process_count = 0;
SET @i_succ_count = 0;
----------get params from user--------------------
EXECUTE @s_p_version = dbo.dl_get_param_value @a_batch_id, @i_sp_id2, 'Version'
IF ( @s_p_version IS NULL
OR @s_p_version = ''
)
OR LEN(@s_p_version) < 6
BEGIN
SET @i_isam_error=0
RAISERROR('Missing Version parameter value',16,1);
RETURN
END
EXECUTE @s_p_source = dbo.dl_get_param_value @a_batch_id, @i_sp_id2, 'Source'
-- single row passed in
-----exception handling w/in FOREACH---------------------------------
/*------- catch all other errors -------*/
IF ( @s_p_source IS NULL
OR @s_p_source = ''
)
OR LEN(@s_p_source) < 1
BEGIN
SET @i_isam_error=0
RAISERROR('Missing Source parameter value',16,1);
RETURN
END
　
　
　
　
-----Begin processing, one row at a time-------------------------------------
--- problems retrieving data from dB----
--business rules handling
--error multiple records returned from a subquery
-- known multiple return error for member id
------------------------------------------------------------------------
---------perform initial checks---------------------------------------
INSERT INTO @cFeeSIR (dls_sir_id, zip_code_3, zip_code)
SELECT dls_sir_id, zip_code_3, zip_code
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND (dls_status = 'L' OR dls_status = 'V')
AND ((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) -- allows process for
OR (@a_sir_id = 0 AND dls_sir_id > 0));
/* SET @cFeeSIR = CURSOR FOR SELECT dls_sir_id, zip_code_3, zip_code
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND (dls_status = 'L' OR dls_status = 'V')
AND ((@a_sir_id > 0 AND dls_sir_id = @a_sir_id) -- allows process for
OR (@a_sir_id = 0 AND dls_sir_id > 0));
OPEN @cFeeSIR;
FETCH NEXT FROM @cFeeSIR INTO @i_sir_id, @s_zip_code_3,
@s_zip_code;
WHILE @@FETCH_STATUS = 0 */
DECLARE @cur_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur_cnt = COUNT(1)
FROM @cFeeSIR;
WHILE ( @cur_i <= @cur_cnt )
BEGIN
SELECT @i_sir_id = dls_sir_id, @s_zip_code_3 = zip_code_3,
@s_zip_code = zip_code from @cFeeSIR where id = @cur_i
BEGIN
-- sets status to Error if condition deemed fatal --
-- fatal error
-- reset error no
BEGIN TRY
-- if this proc and batch had prev stored errors, then
-- call sub-proc to see if it was this row, and if so, 
-- move to err history table
IF @c_prev_err = 'T'
BEGIN
--EXECUTE SWPGetGlVar 'i_sir_id',
-- @i_sir_id OUTPUT;
--EXECUTE SWPGetGlVar 'i_sp_id',
-- @i_sp_id OUTPUT;
EXECUTE dbo.dl_clean_curr_err @a_batch_id,
@i_sir_id, @i_sp_id,
@i_error_no OUTPUT,
@s_err_rtn_text OUTPUT;
END;
-- initialize variables for each record check----------------
SET @i_error = 0;
SET @i_process_count = @i_process_count + 1;
SET @i_error = 10; -- Non Numeric zip code
SET @i_zip_code_3 = @s_zip_code_3;
SET @i_error = 20; -- Non Numeric zip code
SET @i_zip_code = @s_zip_code;
IF ( @s_zip_code_3 IS NULL
OR @s_zip_code_3 = ''
)
OR LEN(@s_zip_code_3) = 0
BEGIN
SET @i_isam_error=30
RAISERROR('ZIP code is required',16,1);
RETURN
END
IF ( @s_zip_code IS NULL
OR @s_zip_code = ''
)
OR LEN(@s_zip_code) = 0
BEGIN
SET @i_isam_error=40
RAISERROR('ZIP code is required',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.fee_source (NOLOCK)
WHERE source = @s_p_source
AND version = @s_p_version
AND zip_code_3 = @s_zip_code_3 )
BEGIN
SET @i_isam_error=50
RAISERROR('Zip Code already exist',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.fee_source (NOLOCK)
WHERE source = @s_p_source
AND version = @s_p_version
AND zip_code_3 = @s_zip_code )
BEGIN
SET @i_isam_error=60
RAISERROR('Zip Code already exist',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code_3 = @s_zip_code_3
AND zip_code = @s_zip_code
AND dls_sir_id != @i_sir_id )
BEGIN
SET @i_isam_error=70
RAISERROR('Duplicate Record',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code = @s_zip_code
AND dls_sir_id != @i_sir_id )
BEGIN
SET @i_isam_error=80
RAISERROR('Duplicate Record',16,1);
RETURN
END
IF @s_zip_code_3 = @s_zip_code
BEGIN
IF NOT EXISTS ( SELECT *
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code_3 = @s_zip_code_3 )
BEGIN
SET @i_isam_error=100
RAISERROR('Affected ZIP code does not exists in Fee Sched SIR ',16,1);
RETURN
END
END;
ELSE
BEGIN
IF NOT EXISTS ( SELECT *
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code_3 = zip_code
AND zip_code_3 = @s_zip_code_3 )
BEGIN
SET @i_isam_error=90
RAISERROR('Affected ZIP CODE record is missing',16,1);
RETURN
END
IF EXISTS ( SELECT *
FROM dbo.dls_fee_sched (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND zip_code_3 = @s_zip_code )
BEGIN
SET @i_isam_error=110
RAISERROR('Fee Schedule ZIP code exists in Fee Sched SIR ',16,1);
RETURN
END
END;
/* update dls_status */
UPDATE dbo.dls_fee_zip
SET dls_status = 'P'
WHERE dls_batch_id = @a_batch_id and dls_sir_id = @i_sir_id   -- CURRENT OF @cFeeSIR;
SET @i_succ_count = @i_succ_count + 1;
/* update stats every 100 rows evaluated */
IF @i_process_count % 100 = 0
-----update the stats----------
UPDATE dbo.dl_bat_statistics
SET tot_record = @i_process_count ,
tot_success_rec = @i_succ_count ,
tot_fail_rec = ( @i_process_count
- @i_succ_count )
WHERE bat_statistics_id = @i_statistics_id;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
SET @i_isam_error = ERROR_LINE();
SET @s_error_text = ERROR_MESSAGE();
-- known error conditions, including any conversion errors
-- fatal error
IF @i_error_no IN ( 244, 245, 246 )
BEGIN
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
@i_sp_id, @i_sir_def_id, @i_sir_id,
1000;
GOTO SWL_Label2;
END;
ELSE
IF (@i_error != 0 OR ERROR_NUMBER()=50000)
BEGIN
--------Modified for conversion issue against CH001
EXECUTE @SWV_dl_log_error = usp_dl_log_error @a_batch_id,
@i_sp_id, @i_sir_def_id, @i_sir_id,
@i_isam_error;
IF @SWV_dl_log_error != 1
BEGIN
UPDATE dbo.dls_fee_zip
SET dls_status = 'E'
WHERE dls_batch_id = @a_batch_id and dls_sir_id = @i_sir_id   -- WHERE CURRENT OF @cFeeSIR;
SET @i_error = 0; -- reset error no
GOTO SWL_Label2;
END;
END;
ELSE
BEGIN
SET @s_err_rtn_text = 'DB Error: '
+ @i_error_no + ' Error msg: '
+ @s_error_text;
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = @s_err_rtn_text;
RETURN;
END;
END CATCH;
END;
SWL_Label2:
/* FETCH NEXT FROM @cFeeSIR INTO @i_sir_id, @s_zip_code_3,
@s_zip_code; */
set @cur_i = @cur_i +1
END;
-- CLOSE @cFeeSIR;
---------------perform final err count, update stats-----------------------
SELECT @i_succ_count = COUNT(*)
FROM dbo.dls_fee_zip (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_status = 'P';
SET @i_succ_count = @i_succ_count - @i_init_count;
SET @i_error_count = @i_process_count - @i_succ_count;
/* update statistics */
EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
@i_succ_count, @i_error_count;
IF @SWV_dl_upd_statistics <> 1
BEGIN
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
' Failed to update statistics');
RETURN;
END;
UPDATE dbo.dl_cfg_bat_det
SET cfg_bat_det_stat = 'S'
WHERE cfg_bat_det_id = @i_cfg_bat_det_id;
--TRACE OFF;
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
' records are processed for Batch ',
@a_batch_id);
RETURN;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
SET @i_isam_error = ERROR_LINE();
SET @s_error_text = ERROR_MESSAGE();
SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
' Error msg: ', @s_error_text);
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = @s_err_rtn_text;
RETURN;
END CATCH;
SET NOCOUNT OFF;
　
　
-----------------------------------------------------------------
END;