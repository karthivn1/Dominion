﻿CREATE PROCEDURE [dbo].[dlp_ld_lockbox_part1]
    @p_batch_id INT ,
    @p_db_name CHAR(128) ,
    @p_start_time VARCHAR(22)
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_ld_lockbox
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This SP loads lockbox data into a holding area of DataLoad as the
--           first step in the processing of data for the DataDental Allocation
--           Module.  This is a DataLoad product of STC.
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @n_err_rtn_text VARCHAR(64);
        DECLARE @n_rtn_text VARCHAR(100);

        DECLARE @n_system_cmd CHAR(512);
        DECLARE @n_sys_cmd1 CHAR(200);
        DECLARE @n_sys_cmd2 CHAR(200);
        DECLARE @n_load_file CHAR(128);
        DECLARE @n_tmp_file CHAR(64);
        DECLARE @n_date_str VARCHAR(10);
        DECLARE @n_sir_count INT;
        DECLARE @n_ld_exist INT;
        DECLARE @n_splt_fname CHAR(64);
        DECLARE @n_file_count INT;
        DECLARE @s_suffix CHAR(2);
        DECLARE @n_min_sir INT;
        DECLARE @n_max_sir INT;
        DECLARE @n_sp_id INT;
        DECLARE @n_sir_def_id INT;
        DECLARE @n_cfg_bat_det_id INT;
        DECLARE @n_statistics_id INT;
        DECLARE @n_line_cnt INT;
   
        DECLARE @i_temp INT;
   
        DECLARE @n_tmp_len INT;

        DECLARE @s_sir_def_name VARCHAR(18);
        DECLARE @s_proc_name VARCHAR(18);
        DECLARE @SWV_RaiseMsg VARCHAR(400);
        DECLARE @SWV_dl_upd_statistics INT;

        SET NOCOUNT ON;
     --SET DEBUG has no equivalent in MSSQL
--SET DEBUG FILE TO "/tmp/dlp_ld_lockbox.trc";

   
--   TRACE ON;
   
   
      
        SET @s_proc_name = 'ld_lockbox';
        SET @s_sir_def_name = 'lockbox';
        SET @n_line_cnt = 1000;
        EXECUTE @n_sp_id = dbo.dl_get_sp_id @p_batch_id, @s_proc_name;
        IF @n_sp_id = -1
		BEGIN
            RAISERROR('~Could not retrieve valid Store Procedure ID~',16,1);
			RETURN
		END
   
        EXECUTE @n_sir_def_id = dbo.dl_get_sir_def_id @s_sir_def_name;
        IF @n_sir_def_id = -1
		BEGIN
            RAISERROR('~Could not retrieve valid SIR Table ID~',16,1);
			RETURN
		END
   
   

   /* FIRST, check if this stage has already been performed */
        EXECUTE @n_ld_exist = dbo.dl_dlp_status @p_batch_id, @n_sir_def_id,
            @n_sp_id, 'LD';
        IF @n_ld_exist = 1
            BEGIN
                SET @SWV_RaiseMsg = CONCAT('~You only need to load LOCKBOX data once for batch ',
                                           CAST(@p_batch_id AS VARCHAR(20)),'~');
                RAISERROR(@SWV_RaiseMsg,16,1);
				RETURN
            END;
   

   -- prepare for keeping stats on preprocessing-----------------------------
        EXECUTE dbo.dl_it_statistics @p_batch_id, @n_sp_id, @p_start_time,
            @n_error_no OUTPUT, @n_cfg_bat_det_id OUTPUT,
            @n_statistics_id OUTPUT, @n_error_text OUTPUT;
        IF @n_error_no <= 0
		BEGIN

            RAISERROR('~(Internal) error when creating statistics~',16,1);
			RETURN
		END
   

   /* get name of data file from user as entered for param file_name */
        EXECUTE @n_load_file=dbo.dl_get_param_value @p_batch_id, @n_sp_id, 'File Name' ;

        IF ( @n_load_file IS NULL
             OR @n_load_file = ''
           )
            OR LEN(@n_load_file) = 0
			BEGIN
            RAISERROR('~Missing Data File~',16,1);
			RETURN
			END
    
   SELECT LTRIM(RTRIM(@n_load_file)) 'LoadFile'
      
        SET NOCOUNT OFF;
   
    END;