﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_ValidatePlan]
@PlanID INT,@PlanName Char(20),@planOption nVarchar(10) out,@planInsType char(2) out,@ErrorMsg nVarchar(50) out
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
BEGIN TRY
	SET NOCOUNT ON;

DECLARE @pID INT=0;

 IF @PlanID>0
BEGIN

IF NOT EXISTS( Select 
   plan_id From [plan](nolock)
	Where plan_id =@PlanID)
	BEGIN
	    SET @ErrorMsg='Plan could not be found with the given options. ';
	    RETURN @pID
	END
		   SELECT @pID=plan_id,@planOption=IIF(ins_opt='FFS','PPO',ins_opt),@planInsType=ins_type From [plan](nolock) Where plan_id =@PlanID

END
ELSE IF LEN(@PlanName)>0
BEGIN
   IF NOT EXISTS( Select 
    plan_id From [plan]
	Where plan_dsp_name =@PlanName AND plan_id>0)
	BEGIN
	   SET @ErrorMsg='Plan could not be found with the given options. ';
	   RETURN @pID
	END
	   Select @pID=plan_id,@planOption=IIF(ins_opt='FFS','PPO',ins_opt),@planInsType=ins_type From [plan] Where plan_dsp_name =@PlanName AND plan_id>0
END
 --needs to take the plan_id>0 and check the options FFS-->PPO
 --select *from [plan]
 
--PRINT 'PlanID=' + Cast(@pID as nvarchar) + ' Plan Option' + @planOption + 'Plan Ins_type' + @planInsType



RETURN @pID
END TRY
BEGIN CATCH
THROW;
END CATCH

END