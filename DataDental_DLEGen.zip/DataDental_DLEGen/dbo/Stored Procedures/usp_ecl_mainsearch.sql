﻿
CREATE PROCEDURE  [dbo].[usp_ecl_mainsearch]
@Status				CHAR(2) 		=NULL,
@RecievedDate		VARCHAR(12)		=NULL,
@DloadConfigName	VARCHAR(50)  	=NULL,
@ErrorCode			CHAR(10)  		=NULL,
@FileName			VARCHAR(50)  	=NULL,
@AltId				CHAR(20)  		=NULL,
@ReopenDate			VARCHAR(12)  	=NULL,
@DocNo				CHAR(15)  		=NULL,
@PatientFirstName	CHAR(20)  		=NULL,
@PatientMidName		CHAR(1)  		=NULL,
@PatientLastName	CHAR(30)  		=NULL,
@PatientMemberId	CHAR(20)  		=NULL,
@PatientSSN			CHAR(11)  		=NULL,
@PatientAltId		CHAR(20)  		=NULL,
@PatientSourceId	CHAR(20)  		=NULL,
@PCP				CHAR(50)  		=NULL,
@PCPNPId			CHAR(10)  		=NULL,
@PCPAltId			CHAR(20)  		=NULL,
@PatientFacilityId	CHAR(20)  		=NULL,
@SubFirstName		CHAR(20)  		=NULL,
@SubMidName			CHAR(1)  		=NULL,
@SubLastName		CHAR(30)  		=NULL,
@SubMemberId		CHAR(20)  		=NULL,
@SubSSN				CHAR(11)  		=NULL,
@SubAltId			CHAR(20)  		=NULL,
@SubSourceId		CHAR(20)  		=NULL,
@GroupName			CHAR(50)  		=NULL,
@GroupAltId			CHAR(20)  		=NULL,
@GroupId			CHAR(20)  		=NULL,
@PlanName			CHAR(30)  		=NULL,
@InsType			CHAR(1)  		=NULL,
@PlanType			CHAR(3)  		=NULL,
@PlanId				CHAR(20)  		=NULL,
@ProviderFirstName	CHAR(20)  		=NULL,
@ProviderMidName	CHAR(1)  		=NULL,
@ProviderLastName	CHAR(30)  		=NULL,
@ProviderId			CHAR(20)  		=NULL,
@ProviderTaxId		CHAR(11)  		=NULL,
@ProviderNPId		CHAR(10)  		=NULL,
@ProviderAltId		CHAR(20)  		=NULL,
@LicensingState		CHAR(2)  		=NULL,
@ProviderAddress1	CHAR(30)  		=NULL,
@ProviderAddress2	CHAR(30)  		=NULL,
@ProviderCity		CHAR(20)  		=NULL,
@ProviderState		CHAR(2)  		=NULL,
@ProviderZip		CHAR(10)  		=NULL,
@ContrFacilityName	CHAR(50)  		=NULL,
@ContrNPId			CHAR(10)  		=NULL,
@ContrAltId			CHAR(20)  		=NULL,
@ContrFacilityId	CHAR(20)  		=NULL,
@EmergencySwitch	CHAR(1)  		=NULL,
@PreAuthSwitch		CHAR(1)  		=NULL,
@PayPrvSwitch		CHAR(1)  		=NULL,
@SpecialityType		CHAR(2)  		=NULL,
@HMOClaimType		CHAR(2)  		=NULL,
@SpecialDeal		CHAR(1)  		=NULL,
@Remarks			CHAR(100)  		=NULL,
@UD1				CHAR(15)  		=NULL,
@UD2				CHAR(15)  		=NULL,
@UD3				CHAR(15)  		=NULL,
@UD4				CHAR(15)  		=NULL,
@UD5				CHAR(100)		=NULL,
@PageSize			INT,
@SkipRows			INT,
@TotalRows			INT OUTPUT	
AS
BEGIN
SET NOCOUNT ON;
   DECLARE  @BaseQuery VARCHAR(MAX),
			@WhereQuery VARCHAR(MAX)=NULL,
			@Query VARCHAR(MAX),
			@selectCount NVARCHAR(max),
			@COUNT INT
   
  SET @BaseQuery ='
    SELECT eclaim_id	AS EclaimId
                                      ,alt_id		AS AltId
                                      ,document_no	AS DocNo
                                      ,status		AS Status
                                      ,error_code	AS ErrorCode
                                      ,received_date AS ReceivedDate
	                                  ,dls_status	AS DataLoadStatus
	                                  ,config_name	AS DloadConfigName
	                                  ,dls_batch_id AS BatchId
	                                  ,pv_id		AS ProviderId,
									  FORMAT((SELECT max(cast(svc_date as date))  FROM eclaim_d(NOLOCK) where 
		eclaim_d.eclaim_id = eclaim_h.eclaim_id and ISDATE(svc_date)=1),''MM/dd/yyyy'', ''en-us'') as ServiceDate
                                  FROM eclaim_h(NOLOCK) where'
								  
						IF(@Status IS NOT NULL )
							SET @WhereQuery = ' status = '+@Status

						IF(ISDATE (@RecievedDate) = 1)
							BEGIN
							 IF(@RecievedDate IS NOT NULL)
								SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
															@WhereQuery+' AND cast(received_date as date) = '+char(39)+cast(cast(@RecievedDate as date) as varchar)+char(39)
															ELSE ' cast(received_date as date) = '+char(39)+cast(cast(@RecievedDate as date) as varchar)+char(39) END
							END 
						ELSE 
							BEGIN
								IF(@RecievedDate IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND received_date = '+char(39)+@RecievedDate+char(39)
														ELSE ' received_date = '+char(39)+@RecievedDate+char(39) END
							END

						 IF(@DloadConfigName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND config_name = '+char(39)+@DloadConfigName+char(39)
														ELSE ' config_name = '+char(39)+@DloadConfigName+char(39) END
						IF(ISDATE (@ReopenDate) = 1)
							BEGIN
							 IF(@ReopenDate IS NOT NULL)
								SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
															@WhereQuery+' AND reopen_date = '+char(39)+cast(cast(@ReopenDate as date) as varchar)+char(39)
															ELSE ' reopen_date = '+char(39)+cast(cast(@ReopenDate as date) as varchar)+char(39) END
							END
						
						 IF(@ErrorCode IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND error_code = '+char(39)+@ErrorCode+char(39)
														ELSE ' error_code = '+char(39)+@ErrorCode+char(39) END
						IF(@FileName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND file_name = '+char(39)+@FileName+char(39)
														ELSE ' file_name = '+char(39)+@FileName+char(39) END
						 IF(@AltId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND alt_id = '+char(39)+@AltId+char(39)
														ELSE ' alt_id = '+char(39)+@AltId+char(39) END
						 IF(@DocNo IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND document_no = '+char(39)+@DocNo+char(39)
														ELSE ' document_no = '+char(39)+@DocNo+char(39) END
						 IF(@PatientFirstName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pat_f_name = '+char(39)+@PatientFirstName+char(39)
														ELSE ' pat_f_name = '+char(39)+@PatientFirstName+char(39) END
						 IF(@PatientMidName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pat_mi = '+char(39)+@PatientMidName+char(39)
														ELSE ' pat_mi = '+char(39)+@PatientMidName+char(39) END
						 IF(@PatientLastName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pat_l_name = '+char(39)+@PatientLastName+char(39)
														ELSE ' pat_l_name = '+char(39)+@PatientLastName+char(39) END
						IF(@PatientMemberId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND patient_id = '+char(39)+@PatientMemberId+char(39)
														ELSE ' patient_id = '+char(39)+@PatientMemberId+char(39) END
						 IF(@PatientSSN IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pat_tax_id = '+char(39)+@PatientSSN+char(39)
														ELSE ' pat_tax_id = '+char(39)+@PatientSSN+char(39) END
						 IF(@PatientAltId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+'AND pat_alt_id = '+char(39)+@PatientAltId+char(39)
														ELSE ' pat_alt_id = '+char(39)+@PatientAltId+char(39) END
						IF(@PatientSourceId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pat_source_id = '+char(39)+@PatientSourceId+char(39)
														ELSE ' pat_source_id = '+char(39)+@PatientSourceId+char(39) END
						 IF(@PCP IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pcp_name = '+char(39)+@PCP+char(39)
														ELSE ' pcp_name = '+char(39)+@PCP+char(39) END
						 IF(@PCPNPId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pcp_np_id = '+char(39)+@PCPNPId+char(39)
														ELSE ' pcp_np_id = '+char(39)+@PCPNPId+char(39) END
						IF(@PCPAltId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pcp_alt_id = '+char(39)+@PCPAltId+char(39)
														ELSE ' pcp_alt_id = '+char(39)+@PCPAltId+char(39) END
						 IF(@PatientFacilityId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pcp_id = '+char(39)+@PatientFacilityId+char(39)
														ELSE ' pcp_id = '+char(39)+@PatientFacilityId+char(39) END
						 IF(@SubFirstName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND sub_f_name = '+char(39)+@SubFirstName+char(39)
														ELSE ' sub_f_name = '+char(39)+@SubFirstName+char(39) END
						 IF(@SubMidName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND sub_mi = '+char(39)+@SubMidName+char(39)
														ELSE ' sub_mi = '+char(39)+@SubMidName+char(39) END
						 IF(@SubLastName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND sub_l_name = '+char(39)+@SubLastName+char(39)
														ELSE ' sub_l_name = '+char(39)+@SubLastName+char(39) END
						 IF(@SubMemberId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND subscriber_id = '+char(39)+@SubMemberId+char(39)
														ELSE ' subscriber_id = '+char(39)+@SubMemberId+char(39) END
						IF(@SubSSN IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND sub_tax_id = '+char(39)+@SubSSN+char(39)
														ELSE ' sub_tax_id = '+char(39)+@SubSSN+char(39) END
						 IF(@SubAltId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND sub_alt_id = '+char(39)+@SubAltId+char(39)
														ELSE ' sub_alt_id = '+char(39)+@SubAltId+char(39) END
						 IF(@SubSourceId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND sub_source_id = '+char(39)+@SubSourceId+char(39)
														ELSE ' sub_source_id = '+char(39)+@SubSourceId+char(39) END
						 IF(@GroupName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+'AND group_name = '+char(39)+@GroupName+char(39)
														ELSE ' group_name = '+char(39)+@GroupName+char(39) END
						 IF(@GroupAltId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND group_alt_id = '+char(39)+@GroupAltId+char(39)
														ELSE ' group_alt_id = '+char(39)+@GroupAltId+char(39) END
						 IF(@GroupId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND group_id = '+char(39)+@GroupId+char(39)
														ELSE ' group_id = '+char(39)+@GroupId+char(39) END
						IF(@PlanName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+'AND plan_dsp_name = '+char(39)+@PlanName+char(39)
														ELSE ' plan_dsp_name = '+char(39)+@PlanName+char(39) END
						 IF(@InsType IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND ins_type = '+char(39)+@InsType+char(39)
														ELSE ' ins_type = '+char(39)+@InsType+char(39) END
						 IF(@PlanType IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND plan_type = '+char(39)+@PlanType+char(39)
														ELSE ' plan_type = '+char(39)+@PlanType+char(39) END
						 IF(@PlanId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND plan_id = '+char(39)+@PlanId+char(39)
														ELSE ' plan_id = '+char(39)+@PlanId+char(39) END
						 IF(@ProviderFirstName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_f_name = '+char(39)+@ProviderFirstName+char(39)
														ELSE ' pv_f_name = '+char(39)+@ProviderFirstName+char(39) END
						 IF(@ProviderMidName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_mi = '+char(39)+@ProviderMidName+char(39)
														ELSE ' pv_mi = '+char(39)+@ProviderMidName+char(39) END
						IF(@ProviderLastName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_l_name = '+char(39)+@ProviderLastName+char(39)
														ELSE ' pv_l_name = '+char(39)+@ProviderLastName+char(39) END
						 IF(@ProviderId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_id = '+char(39)+@ProviderId+char(39)
														ELSE ' pv_id = '+char(39)+@ProviderId+char(39) END
						 IF(@ProviderTaxId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_tax_id = '+char(39)+@ProviderTaxId+char(39)
														ELSE ' pv_tax_id = '+char(39)+@ProviderTaxId+char(39) END
						IF(@ProviderNPId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_np_id = '+char(39)+@ProviderNPId+char(39)
														ELSE ' pv_np_id = '+char(39)+@ProviderNPId+char(39) END
						 IF(@ProviderAltId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_alt_id = '+char(39)+@ProviderAltId+char(39)
														ELSE ' pv_alt_id = '+char(39)+@ProviderAltId+char(39) END
						 IF(@LicensingState IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_lic_state = '+char(39)+@LicensingState+char(39)
														ELSE ' pv_lic_state = '+char(39)+@LicensingState+char(39) END
						IF(@ProviderAddress1 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_addr1 = '+char(39)+@ProviderAddress1+char(39)
														ELSE ' pv_addr1 = '+char(39)+@ProviderAddress1+char(39) END
						 IF(@ProviderAddress2 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_addr2 = '+char(39)+@ProviderAddress2+char(39)
														ELSE ' pv_addr2 = '+char(39)+@ProviderAddress2+char(39) END
						 IF(@ProviderCity IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_city = '+char(39)+@ProviderCity+char(39)
														ELSE ' pv_city = '+char(39)+@ProviderCity+char(39) END
						 IF(@ProviderState IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_state = '+char(39)+@ProviderState+char(39)
														ELSE ' pv_state = '+char(39)+@ProviderState+char(39) END
						 IF(@ProviderZip IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pv_zip = '+char(39)+@ProviderZip+char(39)
														ELSE ' pv_zip = '+char(39)+@ProviderZip+char(39) END
						 IF(@ContrFacilityName IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND contr_fc_name = '+char(39)+@ContrFacilityName+char(39)
														ELSE ' contr_fc_name = '+char(39)+@ContrFacilityName+char(39) END
						IF(@ContrNPId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND contr_fc_alt_id = '+char(39)+@ContrNPId+char(39)
														ELSE ' contr_fc_alt_id = '+char(39)+@ContrNPId+char(39) END
						 IF(@ContrFacilityId IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND contr_fc_id = '+char(39)+@ContrFacilityId+char(39)
														ELSE ' contr_fc_id = '+char(39)+@ContrFacilityId+char(39) END
						 IF(@EmergencySwitch IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND emergency_switch = '+char(39)+@EmergencySwitch+char(39)
														ELSE ' emergency_switch = '+char(39)+@EmergencySwitch+char(39) END
						IF(@PreAuthSwitch IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND preauth_switch = '+char(39)+@PreAuthSwitch+char(39)
														ELSE ' preauth_switch = '+char(39)+@PreAuthSwitch+char(39) END
						IF(@PayPrvSwitch IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND pay_prv_switch = '+char(39)+@PayPrvSwitch+char(39)
														ELSE ' pay_prv_switch = '+char(39)+@PayPrvSwitch+char(39) END
						 IF(@SpecialityType IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND speciality_type = '+char(39)+@SpecialityType+char(39)
														ELSE ' speciality_type = '+char(39)+@SpecialityType+char(39) END
						 IF(@HMOClaimType IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND hmo_claim_type = '+char(39)+@HMOClaimType+char(39)
														ELSE ' hmo_claim_type = '+char(39)+@HMOClaimType+char(39) END
						 IF(@SpecialDeal IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND special_deal_flg = '+char(39)+@SpecialDeal+char(39)
														ELSE ' special_deal_flg = '+char(39)+@SpecialDeal+char(39) END
						 IF(@Remarks IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND remarks = '+char(39)+@Remarks+char(39)
														ELSE ' remarks = '+char(39)+@Remarks+char(39) END
						 IF(@UD1 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND ud_1 = '+char(39)+@UD1+char(39)
														ELSE ' ud_1 = '+char(39)+@UD1+char(39) END
						IF(@UD2 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND ud_2 = '+char(39)+@UD2+char(39)
														ELSE ' ud_2 = '+char(39)+@UD2+char(39) END
						IF(@UD3 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND ud_3 = '+char(39)+@UD3+char(39)
														ELSE ' ud_3 = '+char(39)+@UD3+char(39) END
						IF(@UD4 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND ud_4 = '+char(39)+@UD4+char(39)
														ELSE ' ud_4 = '+char(39)+@UD4+char(39) END
						IF(@UD5 IS NOT NULL)
							SET @WhereQuery = CASE WHEN @WhereQuery IS NOT NULL THEN  
														@WhereQuery+' AND ud_5 = '+char(39)+@UD5+char(39)
														ELSE ' ud_5 = '+char(39)+@UD5+char(39) END
 
 SET @Query=@BaseQuery+@WhereQuery+' ORDER BY eclaim_id
		OFFSET '+CAST(@SkipRows AS varchar)+' ROWS
		FETCH NEXT '+CAST(@PageSize AS varchar)+' ROWS ONLY OPTION (RECOMPILE);'
 --PRINT @Query
 EXEC (@Query)

 SET @selectCount =' SELECT @count = COUNT(eclaim_id) FROM eclaim_h(NOLOCK) WHERE '+@WhereQuery 
		EXECUTE sp_executesql @selectCount, N'@count int OUTPUT',@count=@COUNT output
		SET @TotalRows = @COUNT 

SET NOCOUNT OFF;
END