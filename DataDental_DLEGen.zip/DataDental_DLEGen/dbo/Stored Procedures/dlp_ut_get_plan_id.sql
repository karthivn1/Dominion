﻿CREATE PROCEDURE [dbo].[dlp_ut_get_plan_id]
    @a_member_id INT ,
    @a_group_id INT ,
    @a_ins_type CHAR(1) ,
    @a_type CHAR(2) ,
    @d_svc_beg DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT
    



------------------------------------------------------------------------------
--
--            Procedure:   dlp_ut_get_plan_id
--
--            Created:     02/01/1999 
--            Author:      Kim Nguyen, Gene Albers
--
-- Purpose:  This SP retrieves the plan id for a given member within the 
--           Data Dental database.  This procedure supports the pre-processing
--           phase of the Utilization Extension, a DataLoad Product of STC
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_plan_id_count INT;
        DECLARE @s_ins_opt CHAR(4);
        DECLARE @i_plan_id INT;
        DECLARE @i_error_no INT;
        DECLARE @i_error INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_text VARCHAR(64);



-----exception handling------------------------------------------

        SET NOCOUNT ON;
        BEGIN TRY
            SET @s_ins_opt = NULL;
            SELECT  @i_plan_id_count = COUNT(*)
            FROM    dbo.rlmbgrpl (NOLOCK) ,
                    dbo.[plan] (NOLOCK)
            WHERE   dbo.rlmbgrpl.member_id = @a_member_id
                    AND dbo.rlmbgrpl.group_id = @a_group_id
                    AND dbo.rlmbgrpl.plan_id = dbo.[plan].plan_id
                    AND dbo.[plan].ins_type = @a_ins_type
                    AND dbo.rlmbgrpl.eff_gr_pl <= @d_svc_beg
                    AND ( dbo.rlmbgrpl.exp_gr_pl > @d_svc_beg
--20101014$$ks removed '=' from exp_gr_pl test
-- AND  (rlmbgrpl.exp_gr_pl >= d_svc_beg
                          OR dbo.rlmbgrpl.exp_gr_pl IS NULL
                        );
 
	   --could not find plan id using subs id, group id, &amp; ins type

            IF @i_plan_id_count = 0
			BEGIN
			SET @i_error_no=120
                RAISERROR('Error',16,1);
			END
            ELSE
                IF @i_plan_id_count = 1
                    BEGIN
                        SELECT  @i_plan_id = dbo.[plan].plan_id
                        FROM    dbo.rlmbgrpl (NOLOCK) ,
                                dbo.[plan] (NOLOCK)
                        WHERE   dbo.rlmbgrpl.member_id = @a_member_id
                                AND dbo.rlmbgrpl.group_id = @a_group_id
                                AND dbo.rlmbgrpl.plan_id = dbo.[plan].plan_id
                                AND dbo.[plan].ins_type = @a_ins_type
                                AND dbo.rlmbgrpl.eff_gr_pl <= @d_svc_beg
                                AND ( dbo.rlmbgrpl.exp_gr_pl > @d_svc_beg
--20101014$$ks removed '=' from exp_gr_pl test
--		AND(rlmbgrpl.exp_gr_pl >= d_svc_beg
                                      OR dbo.rlmbgrpl.exp_gr_pl IS NULL
                                    );
                        
                    END;
                ELSE
                    IF ( @a_type IS NOT NULL
                         AND @a_type <> ''
                       )
                        BEGIN
                            IF LEN(@a_type) = 0
                                SET @s_ins_opt = 'FFS';
                            ELSE
                                SET @s_ins_opt = 'HMO';
		
                            SELECT  @i_plan_id_count = COUNT(*)
                            FROM    dbo.rlmbgrpl (NOLOCK) ,
                                    dbo.[plan] (NOLOCK)
                            WHERE   dbo.rlmbgrpl.member_id = @a_member_id
                                    AND dbo.rlmbgrpl.group_id = @a_group_id
                                    AND dbo.rlmbgrpl.plan_id = dbo.[plan].plan_id
                       AND dbo.[plan].ins_type = @a_ins_type
                                    AND dbo.[plan].ins_opt = @s_ins_opt
                                    AND dbo.rlmbgrpl.eff_gr_pl <= @d_svc_beg
                                    AND ( dbo.rlmbgrpl.exp_gr_pl > @d_svc_beg
--20101014$$ks removed '=' from exp_gr_pl test
--			AND(rlmbgrpl.exp_gr_pl >= d_svc_beg
                                          OR dbo.rlmbgrpl.exp_gr_pl IS NULL
                                        );
		 --could not find plan id
		 
			 --multiple plans currently active for member and group
                            IF @i_plan_id_count = 0
                              BEGIN 
							  SET @i_error_no=130
								RAISERROR('Error',16,1);
							END
                            ELSE
                                IF @i_plan_id_count > 1
								BEGIN
									SET @i_error_no = 140
                                    RAISERROR('Error',16,1);
								END
                                ELSE
                                    BEGIN
                                        SELECT  @i_plan_id = dbo.[plan].plan_id
                                        FROM    dbo.rlmbgrpl (NOLOCK) ,
                                                dbo.[plan] (NOLOCK)
                                        WHERE   dbo.rlmbgrpl.member_id = @a_member_id
                                                AND dbo.rlmbgrpl.group_id = @a_group_id
                                                AND dbo.rlmbgrpl.plan_id = dbo.[plan].plan_id
                                                AND dbo.[plan].ins_type = @a_ins_type
                                                AND dbo.[plan].ins_opt = @s_ins_opt
                                                AND dbo.rlmbgrpl.eff_gr_pl <= @d_svc_beg
                                                AND ( dbo.rlmbgrpl.exp_gr_pl > @d_svc_beg
--20101014$$ks removed '=' from exp_gr_pl test
--			AND(rlmbgrpl.exp_gr_pl >= d_svc_beg
                                                      OR dbo.rlmbgrpl.exp_gr_pl IS NULL
                                                    );
                                        
                                    END;
                        END;
                    ELSE
					BEGIN
						SET @i_error_no =150
                        RAISERROR('Error',16,1);
					END 
		--can not differentiate from multiple plans without claim type
	

            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @i_plan_id;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @i_error_no;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;



-----------------------------------------------------------------

    END;