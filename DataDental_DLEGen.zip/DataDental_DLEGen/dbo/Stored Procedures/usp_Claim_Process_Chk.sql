﻿CREATE PROCEDURE [dbo].[usp_Claim_Process_Chk] 
@Batch_id INT,
@cnt INT = NULL OUTPUT 
AS
BEGIN
/*********************************************************************
Proc Name   : Cliam_Process_Chk
Author      : Cognizant
Date        : 19-May-2017
Description : 
Change History:
-------------------------------------------------
Date         Author            Change Description
-------------------------------------------------
19-May-2017  
*********************************************************************/ 
SET NOCOUNT ON;
	DECLARE @claimId INT;
	DECLARE @service VARCHAR(20);
	DECLARE @locked INT;
	DECLARE @sleep_to DATETIME;
	DECLARE @familyclaimId INT;
	DECLARE @familyservice VARCHAR(20);
	DECLARE @familylocked INT;
	DECLARE @familysleep_to DATETIME;
	Declare @familyID INT;

	SET @cnt  = 0

	DECLARE @SWV_cursor_var1 TABLE
                (
                  id INT IDENTITY ,
                  object_id INT,
				  service CHAR(20),
				  locked smallint,
				  sleep_to datetime
                );

				INSERT  INTO @SWV_cursor_var1
                    ( object_id,
					 service,
					 locked,
					 sleep_to 
                    )
					SELECT a.object_id,a.service,a.locked,a.sleep_to 
	FROM object_queue a(NOLOCK) ,
	Claim_Process_No b (NOLOCK)
	where a.object_id= b.object_id
	AND b.Batch_id =  @Batch_id
	AND a.service in ('TrafficCop','eligibility','validator','procsubst','claim_pricer','claim_payer','claim_denier' )

		DECLARE @cur1_cnt INT ,
                @cur_i INT;

            SET @cur_i = 1;

					--Get the no. of records for the cursor
            SELECT  @cur1_cnt = COUNT(1)
            FROM    @SWV_cursor_var1;
					
					--while @@FETCH_STATUS = 0
            WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
					
					SELECT  @claimId=object_id,
							@service=service,
							@locked=locked,
							@sleep_to=sleep_to 
					FROM @SWV_cursor_var1
					  
				  Select @familyID = mbgrpl_id 
				  from claim_h(NOLOCK)
				  where claim_id = @claimId

				  IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
					DROP TABLE #SWV_cursor_var2

				  CREATE TABLE #SWV_cursor_var2
                (
                  id INT IDENTITY ,
                  object_id INT,
				  service CHAR(20),
				  locked smallint,
				  sleep_to datetime
                );

				INSERT  INTO #SWV_cursor_var2
                    ( object_id,
					 service,
					 locked,
					 sleep_to 
                    )
					SELECT object_id,service,locked,sleep_to 
				  from object_queue o (NOLOCK), 
					claim_h c (NOLOCK)
					Where o.object_id = c.claim_id --and o.object_queue_id !=
					and c.mbgrpl_id = @familyID 
					and o.service not in ('claim_entry', 'claim_review', 'ExternalPricer')
					and (o.sleep_to is null or sleep_to <= GETDATE())

					DECLARE @cur2_cnt INT ,
						@cur2_i INT;

					SET @cur2_i = 1;

							--Get the no. of records for the cursor
					SELECT  @cur2_cnt = COUNT(1)
					FROM    #SWV_cursor_var2;
					
							--while @@FETCH_STATUS = 0
					WHILE ( @cur2_i <= @cur2_cnt )
					BEGIN
						
						SELECT  @familyclaimId=object_id,
								@familyservice=service,
								@familylocked=locked,
								@familysleep_to=sleep_to 
						FROM #SWV_cursor_var2

							   IF (@familyservice = 'TrafficCop' OR @familyservice = 'eligibility' OR @familyservice = 'validator' OR @familyservice = 'procsubst'
									  OR @familyservice = 'claim_pricer' OR @familyservice = 'claim_payer'OR @familyservice = 'claim_denier')
							   BEGIN 
								   set @cnt = @cnt + 1;
							   END 
							   ELSE
							   BEGIN
									  BREAK
							   END
							   SET @cur2_i = @cur2_i + 1;
				  END;
				               
		    SET @cur_i = @cur_i + 1;
	END;
	

SET NOCOUNT OFF;
END