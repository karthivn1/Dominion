﻿CREATE PROCEDURE [dbo].[dlp_ut_ver_surface]
    @a_batch_id INT ,
    @a_surface CHAR(5) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(5) = NULL OUTPUT
     

------------------------------------------------------------------------------
--
--            Procedure:   dlp_ut_ver_surface
--
--            Created:     02/23/1999 
--            Author:      Gene Albers
--
-- Purpose:  
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/ 
   
   
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @i_fatal INT;
        DECLARE @s_error_descr VARCHAR(64);

        DECLARE @temp_char CHAR(5);
        DECLARE @a_surf_len INT;
        DECLARE @i_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
      
   ---------------------perform exception handling------------------------------

        SET NOCOUNT ON;
        SET @i_sir_id = 0;
        
        SET @i_sp_id = 0 ;
        
        SET @i_sir_def_id = 0 ;
        
        BEGIN TRY
            SET @a_surf_len = LEN(@a_surface);
   
   -- now verify each char of field is a valid surface type
            IF SUBSTRING(@a_surface, 1, 1) NOT IN (
                SELECT  code
                FROM    dbo.typ_table (NOLOCK)
                WHERE   subsys_code LIKE 'CL'
                        AND tab_name LIKE 'surface' )
                RAISERROR('Invalid surface',16,1);
   
            IF @a_surf_len >= 2
                IF SUBSTRING(@a_surface, 2, 1) NOT IN (
                    SELECT  code
                    FROM    dbo.typ_table  (NOLOCK)
                    WHERE   subsys_code LIKE 'CL'
                            AND tab_name LIKE 'surface' )
                    RAISERROR('Invalid surface',16,1);
	
   
            IF @a_surf_len >= 3
                IF SUBSTRING(@a_surface, 3, 1) NOT IN (
                    SELECT  code
                    FROM    dbo.typ_table  (NOLOCK)
                    WHERE   subsys_code LIKE 'CL'
                            AND tab_name LIKE 'surface' )
                    RAISERROR('Invalid surface',16,1);
	
   
            IF @a_surf_len >= 4
                IF SUBSTRING(@a_surface, 4, 1) NOT IN (
                    SELECT  code
                    FROM    dbo.typ_table  (NOLOCK)
                    WHERE   subsys_code LIKE 'CL'
                            AND tab_name LIKE 'surface' )
                    RAISERROR('Invalid surface',16,1);
	
   
   

	-- verifies a valid surface code --
	

	-- verifies that there is no repeat surface codes in string--	
	

	-- verifies that there is no repeat surface codes in string--	
            IF @a_surf_len >= 5
                BEGIN
                    IF SUBSTRING(@a_surface, 5, 1) NOT IN (
                        SELECT  code
                        FROM    dbo.typ_table  (NOLOCK)
                        WHERE   subsys_code LIKE 'CL'
                                AND tab_name LIKE 'surface' )
                        RAISERROR('Invalid surface',16,1);
	

	-- verifies that there is no repeat surface codes in string--	
                    IF ( SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface, 2,
                                                              1)
                         OR SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                        3, 1)
                         OR SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              4, 1)
                         OR SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              5, 1)
                         OR SUBSTRING(@a_surface, 2, 1) = SUBSTRING(@a_surface,
                                                              3, 1)
                         OR SUBSTRING(@a_surface, 2, 1) = SUBSTRING(@a_surface,
                                                              4, 1)
                         OR SUBSTRING(@a_surface, 2, 1) = SUBSTRING(@a_surface,
                                                              5, 1)
                         OR SUBSTRING(@a_surface, 3, 1) = SUBSTRING(@a_surface,
                                                              4, 1)
                         OR SUBSTRING(@a_surface, 3, 1) = SUBSTRING(@a_surface,
                                                              5, 1)
                         OR SUBSTRING(@a_surface, 4, 1) = SUBSTRING(@a_surface,
                                                              5, 1)
                       )
                        RAISERROR('Repetitive surface codes',16,1);
	
	
	-- now place chars in alpha order if not already there
	
                    SET @temp_char = @a_surface;
	
	-- bubble the first two chars
                    IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface, 2,
                                                              1)
                        BEGIN
                            SET @a_surface = STUFF(@a_surface, 1, 1,
                                                   SUBSTRING(@a_surface, 2, 1));
                            SET @a_surface = STUFF(@a_surface, 2, 1,
                                                   SUBSTRING(@temp_char, 1, 1));
                        END;
	
                    SET @temp_char = @a_surface;
	
	-- bubble the third char
                    IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface, 3,
                                                              1)
                        BEGIN
                            SET @a_surface = STUFF(@a_surface, 1, 1,
                                                   SUBSTRING(@a_surface, 3, 1));
                            SET @a_surface = STUFF(@a_surface, 2, 1,
                                                   SUBSTRING(@temp_char, 1, 1));
                            SET @a_surface = STUFF(@a_surface, 3, 1,
                                                   SUBSTRING(@temp_char, 2, 1));
                        END;
                    ELSE
                        IF SUBSTRING(@a_surface, 2, 1) > SUBSTRING(@a_surface,
                                                              3, 1)
                            BEGIN
                                SET @a_surface = STUFF(@a_surface, 2, 1,
                                                       SUBSTRING(@a_surface, 3,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 3, 1,
                                                       SUBSTRING(@temp_char, 2,
                                                              1));
                            END;
                    SET @temp_char = @a_surface;
	
	-- bubble the fourth char
                    IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface, 4,
                                                              1)
                        BEGIN
                            SET @a_surface = STUFF(@a_surface, 1, 1,
                                                   SUBSTRING(@a_surface, 4, 1));
                            SET @a_surface = STUFF(@a_surface, 2, 1,
                                                   SUBSTRING(@temp_char, 1, 1));
                           SET @a_surface = STUFF(@a_surface, 3, 1,
                                                   SUBSTRING(@temp_char, 2, 1));
                            SET @a_surface = STUFF(@a_surface, 4, 1,
                                                   SUBSTRING(@temp_char, 3, 1));
                        END;
                    ELSE
                        IF SUBSTRING(@a_surface, 2, 1) > SUBSTRING(@a_surface,
                                                              4, 1)
                            BEGIN
                                SET @a_surface = STUFF(@a_surface, 2, 1,
                                                       SUBSTRING(@a_surface, 4,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 3, 1,
                                                       SUBSTRING(@temp_char, 2,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 4, 1,
                                                       SUBSTRING(@temp_char, 3,
                                                              1));
                            END;
                        ELSE
                            IF SUBSTRING(@a_surface, 3, 1) > SUBSTRING(@a_surface,
                                                              4, 1)
                                BEGIN
                                    SET @a_surface = STUFF(@a_surface, 3, 1,
                                                           SUBSTRING(@a_surface,
                                                              4, 1));
                                    SET @a_surface = STUFF(@a_surface, 4, 1,
                                                           SUBSTRING(@temp_char,
                                                              3, 1));
                                END;
                    SET @temp_char = @a_surface;

	-- bubble the fifth char
                    IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface, 5,
                                                              1)
                        BEGIN
                            SET @a_surface = STUFF(@a_surface, 1, 1,
                                                   SUBSTRING(@a_surface, 5, 1));
                            SET @a_surface = STUFF(@a_surface, 2, 1,
                                                   SUBSTRING(@temp_char, 1, 1));
                            SET @a_surface = STUFF(@a_surface, 3, 1,
                                                   SUBSTRING(@temp_char, 2, 1));
                            SET @a_surface = STUFF(@a_surface, 4, 1,
                                                   SUBSTRING(@temp_char, 3, 1));
                            SET @a_surface = STUFF(@a_surface, 5, 1,
                                                   SUBSTRING(@temp_char, 4, 1));
                        END;
                    ELSE
                        IF SUBSTRING(@a_surface, 2, 1) > SUBSTRING(@a_surface,
                                                              5, 1)
                            BEGIN
                                SET @a_surface = STUFF(@a_surface, 2, 1,
                                                       SUBSTRING(@a_surface, 5,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 3, 1,
                                                       SUBSTRING(@temp_char, 2,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 4, 1,
                                                  SUBSTRING(@temp_char, 3,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 5, 1,
                SUBSTRING(@temp_char, 4,
                                                              1));
                            END;
                        ELSE
                            IF SUBSTRING(@a_surface, 3, 1) > SUBSTRING(@a_surface,
                                                              5, 1)
                                BEGIN
                                    SET @a_surface = STUFF(@a_surface, 3, 1,
                                                           SUBSTRING(@a_surface,
                                                              5, 1));
                                    SET @a_surface = STUFF(@a_surface, 4, 1,
                                                           SUBSTRING(@temp_char,
                                                              3, 1));
                                    SET @a_surface = STUFF(@a_surface, 5, 1,
                                                           SUBSTRING(@temp_char,
                                                              4, 1));
                                END;
                            ELSE
                                IF SUBSTRING(@a_surface, 4, 1) > SUBSTRING(@a_surface,
                                                              5, 1)
                                    BEGIN
                                        SET @a_surface = STUFF(@a_surface, 4,
                                                              1,
                                                              SUBSTRING(@a_surface,
                                                              5, 1));
                                        SET @a_surface = STUFF(@a_surface, 5,
                                                              1,
                                                              SUBSTRING(@temp_char,
                                                              4, 1));
                                    END;
                END;
            ELSE
                IF @a_surf_len = 4
                    BEGIN
                        IF ( SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              2, 1)
                             OR SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              3, 1)
                             OR SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              4, 1)
                             OR SUBSTRING(@a_surface, 2, 1) = SUBSTRING(@a_surface,
                                                              3, 1)
                             OR SUBSTRING(@a_surface, 2, 1) = SUBSTRING(@a_surface,
                                                              4, 1)
                             OR SUBSTRING(@a_surface, 3, 1) = SUBSTRING(@a_surface,
                                                              4, 1)
                           )
                            RAISERROR('Repetitive surface codes',16,1);
	
	
	-- now place chars in alpha order if not already there
	
                        SET @temp_char = @a_surface;
	
	-- bubble the first two chars
                        IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface,
                                                              2, 1)
                            BEGIN
                                SET @a_surface = STUFF(@a_surface, 1, 1,
                                                       SUBSTRING(@a_surface, 2,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 2, 1,
                                                  SUBSTRING(@temp_char, 1,
                                                              1));
                            END;
	
                        SET @temp_char = @a_surface;
	
	-- bubble the third char
                        IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface,
                                                              3, 1)
                            BEGIN
                                SET @a_surface = STUFF(@a_surface, 1, 1,
                                                       SUBSTRING(@a_surface, 3,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 2, 1,
                                                       SUBSTRING(@temp_char, 1,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 3, 1,
                                                       SUBSTRING(@temp_char, 2,
                                                              1));
                            END;
                        ELSE
                            IF SUBSTRING(@a_surface, 2, 1) > SUBSTRING(@a_surface,
                                                              3, 1)
                                BEGIN
                                    SET @a_surface = STUFF(@a_surface, 2, 1,
                                                           SUBSTRING(@a_surface,
                                                              3, 1));
                                    SET @a_surface = STUFF(@a_surface, 3, 1,
                                                           SUBSTRING(@temp_char,
                                                              2, 1));
                                END;
                        SET @temp_char = @a_surface;
	
	-- bubble the fourth char
                        IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface,
                                                              4, 1)
                            BEGIN
                                SET @a_surface = STUFF(@a_surface, 1, 1,
                                                       SUBSTRING(@a_surface, 4,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 2, 1,
                                                       SUBSTRING(@temp_char, 1,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 3, 1,
                                                       SUBSTRING(@temp_char, 2,
                                                              1));
                                SET @a_surface = STUFF(@a_surface, 4, 1,
                                                       SUBSTRING(@temp_char, 3,
                                                              1));
                            END;
                        ELSE
                            IF SUBSTRING(@a_surface, 2, 1) > SUBSTRING(@a_surface,
                                                              4, 1)
                                BEGIN
                                    SET @a_surface = STUFF(@a_surface, 2, 1,
                                                           SUBSTRING(@a_surface,
                                                              4, 1));
                                    SET @a_surface = STUFF(@a_surface, 3, 1,
                                                           SUBSTRING(@temp_char,
                                                              2, 1));
                                    SET @a_surface = STUFF(@a_surface, 4, 1,
                                                           SUBSTRING(@temp_char,
                                                              3, 1));
                END;
                            ELSE
                                IF SUBSTRING(@a_surface, 3, 1) > SUBSTRING(@a_surface,
                                                              4, 1)
                                    BEGIN
                  SET @a_surface = STUFF(@a_surface, 3,
                                                              1,
                                                              SUBSTRING(@a_surface,
                                                              4, 1));
                                        SET @a_surface = STUFF(@a_surface, 4,
                                                              1,
                                                              SUBSTRING(@temp_char,
                                                              3, 1));
                                    END;
                    END;
                ELSE
                    IF @a_surf_len = 3
                        BEGIN
                            IF ( SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              2, 1)
                                 OR SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              3, 1)
                                 OR SUBSTRING(@a_surface, 2, 1) = SUBSTRING(@a_surface,
                                                              3, 1)
                               )
                                RAISERROR('Repetitive surface codes',16,1);
	

	-- now place chars in alpha order if not already there
	
                            SET @temp_char = @a_surface;
	
	-- bubble the first two chars
                            IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface,
                                                              2, 1)
                                BEGIN
                                    SET @a_surface = STUFF(@a_surface, 1, 1,
                                                           SUBSTRING(@a_surface,
                                                              2, 1));
                                    SET @a_surface = STUFF(@a_surface, 2, 1,
                                                           SUBSTRING(@temp_char,
                                                              1, 1));
                                END;
	
                            SET @temp_char = @a_surface;
	
	-- bubble the third char
                            IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface,
                                                              3, 1)
                                BEGIN
                                    SET @a_surface = STUFF(@a_surface, 1, 1,
                                                           SUBSTRING(@a_surface,
                                                              3, 1));
                                    SET @a_surface = STUFF(@a_surface, 2, 1,
                                                           SUBSTRING(@temp_char,
                                                              1, 1));
                                    SET @a_surface = STUFF(@a_surface, 3, 1,
                                                           SUBSTRING(@temp_char,
                                                              2, 1));
                                END;
                            ELSE
                                IF SUBSTRING(@a_surface, 2, 1) > SUBSTRING(@a_surface,
                                                              3, 1)
                                    BEGIN
                                        SET @a_surface = STUFF(@a_surface, 2,
                                                              1,
                                                              SUBSTRING(@a_surface,
                                                              3, 1));
                                        SET @a_surface = STUFF(@a_surface, 3,
                                                              1,
                                                              SUBSTRING(@temp_char,
              2, 1));
                                    END;
                        END;
                    ELSE
                        IF @a_surf_len = 2
                            BEGIN
                                IF ( SUBSTRING(@a_surface, 1, 1) = SUBSTRING(@a_surface,
                                                              2, 1) )
                                    RAISERROR('Repetitive surface codes',16,1);
	

	-- now place chars in alpha order if not already there
	
                                SET @temp_char = @a_surface;
	
	-- bubble the first two chars
                                IF SUBSTRING(@a_surface, 1, 1) > SUBSTRING(@a_surface,
                                                              2, 1)
                                    BEGIN
                                        SET @a_surface = STUFF(@a_surface, 1,
                                                              1,
                                                              SUBSTRING(@a_surface,
                                                              2, 1));
                                        SET @a_surface = STUFF(@a_surface, 2,
                                                              1,
                                                              SUBSTRING(@temp_char,
                                                              1, 1));
                                    END;
                            END;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @a_surface;
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            IF @i_error_no IN ( -244, -245, -246 )
                BEGIN
                   
                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
                        @i_sir_def_id, @i_sir_id, 1000;
                END;
            ELSE
                BEGIN
                   
                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
                        @i_sir_def_id, @i_sir_id, @i_error_no;
                END;
	
            
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


      
   -------------------------begin body of code----------------------------------

   -- get length of the surface field
    END;