﻿CREATE PROCEDURE [dbo].[getsub_altgrppln]
    @AltID CHAR(20) ,
    @GrpID INT ,
    @PlanID INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:35:35 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @ID INT;
        DECLARE @MCnt INT;
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;

 ---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            SET @ID = NULL;
            SET @MCnt = 0;
            IF LEN(@AltID) > 0
                BEGIN
                    SELECT DISTINCT
                            @ID = m.family_id
                    FROM    dbo.member m ( NOLOCK ) ,
                            dbo.rlmbgrpl g ( NOLOCK )
                    WHERE   m.member_id = g.member_id
                            AND m.family_id = m.member_id
                            AND g.group_id = @GrpID
                            AND g.plan_id = @PlanID
                            AND m.alt_id = @AltID;
                    
                END;
	
            IF @ID IS NULL
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = '';
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = @ID;
                    SET @SWP_Ret_Value1 = '';
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

----------------------------------------------------------------------
    END;