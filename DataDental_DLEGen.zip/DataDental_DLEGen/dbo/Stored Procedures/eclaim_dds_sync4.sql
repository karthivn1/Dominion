﻿CREATE PROCEDURE [dbo].[eclaim_dds_sync4]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(80) = NULL OUTPUT ,
    @SWP_Ret_Value2 VARCHAR(80) = NULL OUTPUT
    


-- Create 01/18/06 by John Kalimon
-- of Dominion Dental Services

-- Intended to update an eClaims with a status of "6" -
-- Awaiting Info once they become "n" old.
-- The number of days (48) is hard-coded into the SELECT SQL.
-- New status becomes "4" - Pend for Denial.
-- New error_code becomes a hard-coded value if found
-- otherwise error_code stays the same.
-- Updating error_code is necessary because it is used
-- to select claims needed for outside review.

-- Modification 03/27/06 per Jen Flynn:
-- Exception: When error code = "PERIOHIST" status becomes
-- "1" - Ready to Submit and error code remains "PERIOHIST".
-- Added new variable "NeweClaimStatus" to hold new eClaim status.
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:28:28 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);

        DECLARE @eClaimID INT;
        DECLARE @eClaimStatus INT;
        DECLARE @eClaimErrorCode CHAR(10);
        DECLARE @eClaimhuser CHAR(20);
        DECLARE @eClaimhdatetime DATETIME;

        DECLARE @UpdateCount INT;
        DECLARE @NoMatchCount INT;
        DECLARE @NewErrorCode CHAR(10);
        DECLARE @NeweClaimStatus INT;
        DECLARE @SWV_cursor_var1 CURSOR;

---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            SET LOCK_TIMEOUT 30000;

--set debug file to 'sync4.trc';
--trace on;

            SET @UpdateCount = 0;
            SET @NoMatchCount = 0;
            SET @NewErrorCode = '';
            BEGIN TRAN;
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT eclaim_id, status, error_code, h_user, h_datetime
	  
      FROM dbo.eclaim_h (NOLOCK)
      WHERE status = 6
      AND h_user = 'LetterSync'
      AND DATEDIFF(DAY,CONVERT(DATE,h_datetime),CONVERT(DATE,GETDATE())) >= 48;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID, @eClaimStatus,
                @eClaimErrorCode, @eClaimhuser, @eClaimhdatetime;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    SET @NewErrorCode = '';
                    SET @NeweClaimStatus = 4;
                    IF @eClaimErrorCode = 'TOOTH'
                        SET @NewErrorCode = 'DN-TOOTH';
                    ELSE
                        IF @eClaimErrorCode = 'PANOXRAY'
                            SET @NewErrorCode = 'DN-PAXR';
                        ELSE
                            IF @eClaimErrorCode = 'NOXRAY'
                                SET @NewErrorCode = 'DN-NOXR';
                            ELSE
                                IF @eClaimErrorCode = 'NOCOB'
                                    SET @NewErrorCode = 'DN-NOCOB';
                                ELSE
                                    IF @eClaimErrorCode = 'CR-PERIO'
                                        SET @NewErrorCode = 'DN-PERIO';
                                    ELSE
                                        IF @eClaimErrorCode = 'CR-XRPR'
                                            SET @NewErrorCode = 'DN-XRPR';
                                        ELSE
                                            IF @eClaimErrorCode = 'PA-XRPR'
                                                SET @NewErrorCode = 'DN-PAXRPR';
                                            ELSE
                                                IF @eClaimErrorCode = 'PA-PERIO'
                                                    SET @NewErrorCode = 'DN-PAPR';
                                                ELSE
                                                    IF @eClaimErrorCode = 'CODE'
                                                        SET @NewErrorCode = 'DN-CODE';
                                                    ELSE
                                                        IF @eClaimErrorCode = 'PERIOHIST'
                                                            BEGIN
                                                              SET @NewErrorCode = 'PERIOHIST';
                                                              SET @NeweClaimStatus = 1;
                                                            END;
                                                        ELSE
                                                            BEGIN
                                                              SET @NewErrorCode = @eClaimErrorCode;
                                                              SET @NoMatchCount = @NoMatchCount
                                                              + 1;
                                                            END;
	
                    UPDATE  dbo.eclaim_h
                    SET     status = @NeweClaimStatus ,
                            error_code = @NewErrorCode ,
                            h_user = 'DDSSync' ,
                            h_datetime = GETDATE()
                    WHERE   eclaim_id = @eClaimID;
                    SET @UpdateCount = @UpdateCount + 1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @eClaimID,
                        @eClaimStatus, @eClaimErrorCode, @eClaimhuser,
                        @eClaimhdatetime;
                END;
            CLOSE @SWV_cursor_var1;
            COMMIT;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('eClaims ''Awaiting Info'' Sync Completed. ',
                                         'Total number of records updated was: ',
                                         @UpdateCount, '.');
            SET @SWP_Ret_Value2 = CONCAT('Of the total, ', @NoMatchCount,
                                         ' records did not have a new matching error code.');
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            SET @SWP_Ret_Value2 = '';
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;


----------------------------------------------------------------------
    END;