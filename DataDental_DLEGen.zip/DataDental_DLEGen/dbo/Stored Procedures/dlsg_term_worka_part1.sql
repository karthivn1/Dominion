﻿CREATE PROCEDURE [dbo].[dlsg_term_worka_part1]
    @BatchID INT ,
    @FileName CHAR(200) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(200) = NULL OUTPUT
    

/* DO NOT RUN THIS SCRIPT IF YOU DO NOT UNDERSTAND ALL THE STEPS!!
 * First create a new batch using DataLoad/SG and the MassTerm configuration.
 * make sure your input file includes this batch_id 
 * and the input file is in the pipe delimited format
 * 	0|BatchID|GroupID|TermDate|
 * IF YOU DO NOT KNOW HOW TO RUN DATALOAD - DO NOT USE THIS SCRIPT (find someone that can).
 *
*/

--------Error Variables ---------------------------------------------------------
AS
    BEGIN

        SET NOCOUNT ON;
/*
-- This procedure was converted on Wed Jul 27 12:33:33 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr CHAR(80);
        DECLARE @s_err_rtn_text CHAR(80);
        DECLARE @i_isam_error INT;

-------Counters and processing variables -----------------------------------------
        DECLARE @i_error_count INT;
        DECLARE @i_total_count INT;
        DECLARE @i_init_count INT;
        DECLARE @i_count INT;
        DECLARE @i_fatal INT;
        DECLARE @i_succ_count INT;
        DECLARE @c_cur_err_flag CHAR(1);
        DECLARE @InTrans SMALLINT;
        DECLARE @SUser CHAR(10);
        DECLARE @CurrDT DATETIME2(0);
        DECLARE @StringDT CHAR(20);
        DECLARE @SUnixRun CHAR(250);

        DECLARE @retVal1 INT;
        DECLARE @retVal2 CHAR(64);
------------Variable Types --------------------------------------------------------
        DECLARE @EffDate DATE;

        DECLARE @RecID INT;

        DECLARE @Name CHAR(50);
        DECLARE @serialid VARBINARY(8000);

-----exception handling---------------------------------------------------------


 -- error converting text param values to correct type


 -- intrpt - server or user terminated --
        SET @serialid = CAST(0 AS VARBINARY(8000));
        EXECUTE SWPCrtGlVar 'serialid';
        EXECUTE SWPAddGlVar 'serialid', @serialid;

----------- Global Variable for getting serial ID from existing table -----------
----------- Insert Trigger of table must call SetSerialID() ---------------------
        BEGIN TRY--SET DEBUG has no equivalent in MSSQL
--SET DEBUG FILE TO  '/tmp/sg_term_workaround.trc';

--TRACE statement has no equivalent in MSSQL
--TRACE ON;


			--set explain on;
            SET LOCK_TIMEOUT 120000;
            SET @CurrDT = GETDATE();
            SET @StringDT = @CurrDT;
            SET @SUser = 'termSG' + ORIGINAL_LOGIN(); 
            SET @BatchID = @BatchID;
            SET @FileName = @FileName;
            SET @i_total_count = 0;
            SET @i_succ_count = 0;
            SET @i_error_count = 0;
            SET @a_error_no = 0;
            SET @InTrans = 0;
            SET @c_cur_err_flag = 'F';
            SET @RecID = 0;
     
            INSERT  INTO dbo.dls_sg_member
                    ( dls_batch_id ,
                      dls_group_id ,
                      dls_plan_id ,
                      mb_term_date
                    )
                    SELECT  @BatchID ,
                            dbo.rlmbgrpl.group_id ,
                            dbo.rlmbgrpl.plan_id ,
                            term_date
                    FROM    dbo.sg_temp (NOLOCK) ,
                            dbo.rlmbgrpl (NOLOCK)
                    WHERE   dbo.sg_temp.group_id = dbo.rlmbgrpl.group_id
                            AND dbo.rlmbgrpl.exp_gr_pl IS NULL;

			--Update default values
            UPDATE  dbo.dls_sg_member
            SET     dls_sub_sir_id = dls_sir_id ,
                    member_flag = '00' ,
                    dls_status = 'L' ,
                    dls_source = 'F'
            WHERE   dls_batch_id = @BatchID;

			-- get sub id
            UPDATE  dbo.dls_sg_member
            SET     dls_subscriber_id = ( SELECT DISTINCT
                                                    member_id
                                          FROM      dbo.rlmbgrpl (NOLOCK)
                                          WHERE     group_id = dbo.dls_sg_member.dls_group_id
                                                    AND dls_batch_id = @BatchID
                                        )
            WHERE   EXISTS ( SELECT mb_gr_pl_id
                             FROM   dbo.rlmbgrpl (NOLOCK)
                             WHERE  group_id = dbo.dls_sg_member.dls_group_id
                                    AND dls_batch_id = @BatchID );

			--- get sub info
            UPDATE  dbo.dls_sg_member
            SET     alt_id = ( SELECT   alt_id
                               FROM     dbo.member (NOLOCK)
                               WHERE    member_id = dls_subscriber_id
                                        AND dls_batch_id = @BatchID
                             ) ,
                    ssn = ( SELECT  new_ssn
                            FROM    dbo.member (NOLOCK)
                            WHERE   member_id = dls_subscriber_id
                                    AND dls_batch_id = @BatchID
                          ) ,
                    sub_ssn = ( SELECT  new_ssn
                                FROM    dbo.member (NOLOCK)
                                WHERE   member_id = dls_subscriber_id
                                        AND dls_batch_id = @BatchID
                              ) ,
                    sub_alt_id = ( SELECT   alt_id
                                   FROM     dbo.member (NOLOCK)
                                   WHERE    member_id = dls_subscriber_id
                                            AND dls_batch_id = @BatchID
                                 ) ,
                    last_name = ( SELECT    last_name
                                  FROM      dbo.member (NOLOCK)
                                  WHERE     member_id = dls_subscriber_id
                                            AND dls_batch_id = @BatchID
                                ) ,
                    first_name = ( SELECT   first_name
                                   FROM     dbo.member (NOLOCK)
                                   WHERE    member_id = dls_subscriber_id
                                            AND dls_batch_id = @BatchID
                                 ) ,
                    middle_init = ( SELECT  middle_init
                                    FROM    dbo.member(NOLOCK)
                                    WHERE   member_id = dls_subscriber_id
                                            AND dls_batch_id = @BatchID
                                  ) ,
                    date_of_birth = ( SELECT    date_of_birth
                                      FROM      dbo.member(NOLOCK)
                                      WHERE     member_id = dls_subscriber_id
                                                AND dls_batch_id = @BatchID
                                    ) ,
                    dls_member_id = ( SELECT    member_id
                                      FROM      dbo.member(NOLOCK)
                                      WHERE     member_id = dls_subscriber_id
                                                AND dls_batch_id = @BatchID
                                    ) ,
                    member_code = ( SELECT  member_code
                                    FROM    dbo.member (NOLOCK)
                                    WHERE   member_id = dls_subscriber_id
                                            AND dls_batch_id = @BatchID
                     ) ,
                    new_ssn = ( SELECT  new_ssn
                                FROM    dbo.member (NOLOCK)
                                WHERE   member_id = dls_subscriber_id
                                        AND dls_batch_id = @BatchID
                              ) ,
                    subnew_ssn = ( SELECT   new_ssn
                                   FROM     dbo.member (NOLOCK)
                                   WHERE    member_id = dls_subscriber_id
                                            AND dls_batch_id = @BatchID
                                 )
            WHERE   EXISTS ( SELECT member_id
                             FROM   dbo.member(NOLOCK)
                             WHERE  member_id = dbo.dls_sg_member.dls_subscriber_id
                                    AND dls_batch_id = @BatchID );

			-- set alt_id so update does not error
            UPDATE  dbo.dls_sg_member
            SET     alt_id = 'XX'
            WHERE   dls_batch_id = @BatchID
                    AND ( ( alt_id IS NULL
                            OR alt_id = ''
                          )
                          OR alt_id = ''
                        );

			-- get group-plan info
            UPDATE  dbo.dls_sg_member
            SET     msg_alt_id = ( SELECT   g2.alt_id
                                   FROM     dbo.[group] g ( NOLOCK ) ,
                                            dbo.[group] g2 ( NOLOCK ) ,
                                            dbo.[plan] p ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                            dbo.rlmbrt rt ( NOLOCK )
                                   WHERE    g2.group_id = g.group_parent
                                            AND g.group_id = dls_group_id
                                            AND grpl.plan_id = p.plan_id
                                            AND dls_subscriber_id = grpl.member_id
                                            AND dls_batch_id = @BatchID
                                            AND grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                            AND rt.exp_rt_date IS NULL
                                            AND grpl.exp_gr_pl IS NULL
                                            AND dls_status = 'L'
                                 ) ,
                    plan_dsp_name = ( SELECT    p.plan_dsp_name
                                      FROM      dbo.[group] g ( NOLOCK ) ,
                                                dbo.[group] g2 ( NOLOCK ) ,
                                                dbo.[plan] p ( NOLOCK ) ,
                                                dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                                dbo.rlmbrt rt ( NOLOCK )
                                      WHERE     g2.group_id = g.group_parent
                                                AND g.group_id = dls_group_id
                                                AND grpl.plan_id = p.plan_id
                                                AND dls_subscriber_id = grpl.member_id
                                                AND dls_batch_id = @BatchID
                                                AND grpl.group_id = dls_group_id
                                                AND grpl.plan_id = dls_plan_id
                                                AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                                AND rt.exp_rt_date IS NULL
                                                AND grpl.exp_gr_pl IS NULL
                                                AND dls_status = 'L'
                                    ) ,
                    mb_gppl_eff_date = ( SELECT grpl.eff_gr_pl
                        FROM   dbo.[group] g ,
                                                dbo.[group] g2 ,
                                                dbo.[plan] p ,
                                                dbo.rlmbgrpl grpl ,
                                                dbo.rlmbrt rt
                                         WHERE  g2.group_id = g.group_parent
                                                AND g.group_id = dls_group_id
                                                AND grpl.plan_id = p.plan_id
                                                AND dls_subscriber_id = grpl.member_id
                                                AND dls_batch_id = @BatchID
                                                AND grpl.group_id = dls_group_id
                                                AND grpl.plan_id = dls_plan_id
                                                AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                                AND rt.exp_rt_date IS NULL
                                                AND grpl.exp_gr_pl IS NULL
                                                AND dls_status = 'L'
                                       ) ,
                    mb_fc_eff_date = ( SELECT   grpl.eff_gr_pl
                                       FROM     dbo.[group] g ( NOLOCK ) ,
                                                dbo.[group] g2 ( NOLOCK ) ,
                                                dbo.[plan] p ( NOLOCK ) ,
                                                dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                                dbo.rlmbrt rt ( NOLOCK )
                                       WHERE    g2.group_id = g.group_parent
                                                AND g.group_id = dls_group_id
                                                AND grpl.plan_id = p.plan_id
                                                AND dls_subscriber_id = grpl.member_id
                                                AND dls_batch_id = @BatchID
                                                AND grpl.group_id = dls_group_id
                                                AND grpl.plan_id = dls_plan_id
                                                AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                                AND rt.exp_rt_date IS NULL
                                                AND grpl.exp_gr_pl IS NULL
                                                AND dls_status = 'L'
                                     ) ,
                    dls_msg_id = ( SELECT   g2.group_id
                                   FROM     dbo.[group] g ( NOLOCK ) ,
                                            dbo.[group] g2 ( NOLOCK ) ,
                                            dbo.[plan] p ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                            dbo.rlmbrt rt ( NOLOCK )
                                   WHERE    g2.group_id = g.group_parent
                                            AND g.group_id = dls_group_id
                                            AND grpl.plan_id = p.plan_id
                                            AND dls_subscriber_id = grpl.member_id
                                            AND dls_batch_id = @BatchID
                                            AND grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                            AND rt.exp_rt_date IS NULL
                                            AND grpl.exp_gr_pl IS NULL
                                            AND dls_status = 'L'
                                 ) ,
                    dls_plan_id = ( SELECT  p.plan_id
                                    FROM    dbo.[group] g ( NOLOCK ) ,
                                      dbo.[group] g2 ( NOLOCK ) ,
                                            dbo.[plan] p ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                            dbo.rlmbrt rt ( NOLOCK )
                                    WHERE   g2.group_id = g.group_parent
                                            AND g.group_id = dls_group_id
                                            AND grpl.plan_id = p.plan_id
                                            AND dls_subscriber_id = grpl.member_id
                                            AND dls_batch_id = @BatchID
                                            AND grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                            AND rt.exp_rt_date IS NULL
                                            AND grpl.exp_gr_pl IS NULL
                                            AND dls_status = 'L'
                                  ) ,
                    msg_group_id = ( SELECT g2.group_id
                                     FROM   dbo.[group] g ( NOLOCK ) ,
                                            dbo.[group] g2 ( NOLOCK ) ,
                                            dbo.[plan] p ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                            dbo.rlmbrt rt ( NOLOCK )
                                     WHERE  g2.group_id = g.group_parent
                                            AND g.group_id = dls_group_id
                                            AND grpl.plan_id = p.plan_id
                                            AND dls_subscriber_id = grpl.member_id
                                            AND dls_batch_id = @BatchID
                                            AND grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                            AND rt.exp_rt_date IS NULL
                                            AND grpl.exp_gr_pl IS NULL
                                            AND dls_status = 'L'
                                   ) ,
                    plan_id = ( SELECT  p.plan_id
                                FROM    dbo.[group] g ( NOLOCK ) ,
                                        dbo.[group] g2 ( NOLOCK ) ,
                                        dbo.[plan] p ( NOLOCK ) ,
                                        dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                        dbo.rlmbrt rt ( NOLOCK )
                                WHERE   g2.group_id = g.group_parent
                                        AND g.group_id = dls_group_id
                                        AND grpl.plan_id = p.plan_id
                                        AND dls_subscriber_id = grpl.member_id
                                        AND dls_batch_id = @BatchID
                                        AND grpl.group_id = dls_group_id
                                        AND grpl.plan_id = dls_plan_id
                                        AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                        AND rt.exp_rt_date IS NULL
                                        AND grpl.exp_gr_pl IS NULL
                                        AND dls_status = 'L'
                              ) ,
                    rate_code = ( SELECT    rt.rate_code
                                  FROM      dbo.[group] g ( NOLOCK ) ,
                                            dbo.[group] g2 ( NOLOCK ) ,
                                            dbo.[plan] p ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                         dbo.rlmbrt rt ( NOLOCK )
                                  WHERE     g2.group_id = g.group_parent
                                            AND g.group_id = dls_group_id
                                            AND grpl.plan_id = p.plan_id
                                            AND dls_subscriber_id = grpl.member_id
                                            AND dls_batch_id = @BatchID
                                            AND grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.mb_gr_pl_id = rt.mb_gr_pl_id
                                            AND rt.exp_rt_date IS NULL
                                            AND grpl.exp_gr_pl IS NULL
                                            AND dls_status = 'L'
                                )
            WHERE   EXISTS ( SELECT member_id
                             FROM   dbo.rlmbgrpl (NOLOCK)
                             WHERE  dbo.rlmbgrpl.member_id = dls_subscriber_id
                                    AND dbo.dls_sg_member.dls_batch_id = @BatchID
                                    AND dbo.rlmbgrpl.group_id = dls_group_id
                                    AND dbo.rlmbgrpl.plan_id = dls_plan_id
                                    AND dls_status = 'L'
                                    AND dbo.rlmbgrpl.exp_gr_pl IS NULL );

			-- get facility info if there is any

			/* print 'get facility info - update' */
            UPDATE  dbo.dls_sg_member
            SET     fc_alt_id = ( SELECT    f.alt_id
                                  FROM      dbo.facility f ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                            dbo.rlplfc plfc ( NOLOCK )
                                  WHERE     grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.member_id = dls_subscriber_id
                                            AND grpl.exp_gr_pl IS NULL
                                            AND plfc.mb_gr_pl_id = grpl.mb_gr_pl_id
                                            AND plfc.member_id = dls_subscriber_id
                                            AND plfc.exp_date IS NULL
                                            AND ( plfc.facility_id IS NOT NULL
                                                  AND plfc.facility_id = f.fc_id
                                                )
                                            AND dls_batch_id = @BatchID
                                ) ,
                    dls_facility_id = ( SELECT  f.fc_id
                                        FROM    dbo.facility f ( NOLOCK ) ,
                                                dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                                dbo.rlplfc plfc ( NOLOCK )
                                        WHERE   grpl.group_id = dls_group_id
                                                AND grpl.plan_id = dls_plan_id
                                                AND grpl.member_id = dls_subscriber_id
                                                AND grpl.exp_gr_pl IS NULL
                                                AND plfc.mb_gr_pl_id = grpl.mb_gr_pl_id
                                                AND plfc.member_id = dls_subscriber_id
                                                AND plfc.exp_date IS NULL
                                                AND ( plfc.facility_id IS NOT NULL
                                                      AND plfc.facility_id = f.fc_id
                                                    )
                                                AND dls_batch_id = @BatchID
                                      ) ,
                    facility_id = ( SELECT  f.fc_id
									FROM    dbo.facility f ( NOLOCK ) ,
                                            dbo.rlmbgrpl grpl ( NOLOCK ) ,
                                            dbo.rlplfc plfc ( NOLOCK )
                                    WHERE   grpl.group_id = dls_group_id
                                            AND grpl.plan_id = dls_plan_id
                                            AND grpl.member_id = dls_subscriber_id
                                            AND grpl.exp_gr_pl IS NULL
                                            AND plfc.mb_gr_pl_id = grpl.mb_gr_pl_id
                                            AND plfc.member_id = dls_subscriber_id
                                            AND plfc.exp_date IS NULL
                                            AND ( plfc.facility_id IS NOT NULL
                                                  AND plfc.facility_id = f.fc_id
                                                )
                                            AND dls_batch_id = @BatchID
                                  )
            WHERE   EXISTS ( SELECT member_id
                             FROM   dbo.rlmbgrpl (NOLOCK)
                             WHERE  dbo.rlmbgrpl.member_id = dls_subscriber_id
                                    AND dbo.dls_sg_member.dls_batch_id = @BatchID
                                    AND dbo.rlmbgrpl.group_id = dls_group_id
                                    AND dbo.rlmbgrpl.exp_gr_pl IS NULL );

			/*print 'get facility info - update complete'*/

			--set error records
            UPDATE  dbo.dls_sg_member
            SET     dls_status = 'E'
            WHERE   dls_batch_id = @BatchID
                    AND ( dls_member_id IS NULL
                          OR dls_msg_id IS NULL
                          OR dls_plan_id IS NULL
                        );

			-- create action records
            INSERT  INTO dbo.dl_action
                    ( batch_id ,
                      dls_sir_id ,
                      action_code ,
                      action_date ,
                      process_status
                    )
                    SELECT  dls_batch_id ,
                            dls_sir_id ,
                            'ST' ,
                            mb_term_date ,
                            'N'
                    FROM    dbo.dls_sg_member (NOLOCK)
                    WHERE   dls_batch_id = @BatchID
                            AND dls_status = 'L';

			/*print 'After dl_action insert'*/

			-- prepare batch for "Update"
            UPDATE  dbo.dls_sg_member
            SET     dls_status = 'P'
            WHERE   dls_batch_id = @BatchID
                    AND EXISTS ( SELECT dls_sir_id
                                 FROM   dbo.dl_action (NOLOCK)
                                 WHERE  dbo.dl_action.batch_id = dbo.dls_sg_member.dls_batch_id
                                        AND dls_batch_id = @BatchID
                                        AND dbo.dls_sg_member.dls_sir_id = dbo.dl_action.dls_sir_id );

			/* print 'After Process' */

 ------------- May need to call other procedure to process --------------------
            EXECUTE dbo.dlp_up_sg_member @BatchID, @StringDT, @retVal1 OUTPUT, @retVal2 OUTPUT;

            IF @retVal1 = 1
                SET @i_succ_count = @i_succ_count + 1;

            IF @retVal1 < 0
                SET @i_error_count = @i_error_count + 1;

            IF @i_error_count > 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_error_count, ' Errors;  Message of error');
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_succ_count, ' Success message');
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();

            IF @InTrans = 1
                ROLLBACK; 
	
            IF @i_error_no < 0 -- GT 0 -> Text set in code
                BEGIN
                    SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no, ' Error msg: ', @s_error_descr);
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_err_rtn_text;
                    RETURN;
                END;
	
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            RETURN;
        END CATCH;

--TRACE OFF;

        SET NOCOUNT OFF;
--------------------------------------------------------------------------------

    END;