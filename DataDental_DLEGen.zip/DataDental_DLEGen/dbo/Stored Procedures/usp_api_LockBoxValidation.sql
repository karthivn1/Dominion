﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_LockBoxValidation 0,'',214453,NULL,541157964,42.00,NULL,'','01/03/2017',''
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_LockBoxValidation]
@GroupID INT,@GroupAltID NVARCHAR(20),@InvoiceNum INT,@InvoiceDate NVARCHAR(10),
@CheckNum NVARCHAR(10),@AmtPaid NVARCHAR(10),@PayToken NVARCHAR(50), 
@ConfigName NVARCHAR(50),@AsOFDate VARCHAR(10),@Status NVARCHAR(50) OUT,@BatchID INT OUT	
    WITH RECOMPILE
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempError') IS NOT NULL
    DROP TABLE #tempError

IF OBJECT_ID('tempdb..#tempClaim') IS NOT NULL
    DROP TABLE #tempGroup

IF OBJECT_ID('tempdb..#tempPayee') IS NOT NULL
    DROP TABLE #tempPayee
	
CREATE TABLE #tempError(ID INT IDENTITY(1,1),ErrorName NVARCHAR(50),ErrorDesc NVARCHAR(1000))	
CREATE TABLE #tempGroup(group_id INT,group_name NVARCHAR(50) NULL,group_type NVARCHAR(4),group_payee INT NULL,bill_type NVARCHAR(4) NULL)

SET @Status='Good'

BEGIN TRY


IF @GroupID>0
BEGIN
	INSERT INTO #tempGroup
	SELECT g.group_id, g.group_name, g.group_type,ISNULL(g.group_payee,0) AS group_payee, g.bill_type
			FROM [group] g
			WHERE g.group_id=@GroupID

END
ELSE IF LEN(@GroupAltID)>0
BEGIN
	INSERT INTO #tempGroup
	SELECT g.group_id, g.group_name, g.group_type, ISNULL(g.group_payee,0) AS group_payee, g.bill_type
			FROM [group] g
			WHERE g.alt_id=@GroupAltID

END
ELSE IF @InvoiceNum>0
BEGIN

	SELECT DISTINCT g.group_payee,b.invoice_num
			INTO #tempPayee
			from bill_sum b
			JOIN [group] g on g.group_id=b.group_id
			WHERE b.invoice_num=64316

--Select *From #tempPayee
	INSERT INTO #tempGroup
	SELECT g.group_id, g.group_name, g.group_type, ISNULL(g.group_payee,0) AS group_payee, g.bill_type
			FROM #tempPayee t
			JOIN [group] g ON g.group_id=t.group_payee


END

--Select *From #tempGroup
IF NOT EXISTS(SELECT t.group_payee FROM #tempGroup t WHERE t.group_payee>0)
BEGIN
	SET @Status='GroupNotFound'
	INSERT INTO #tempError VALUES ('Group','Group could not be found with the given options. ');
	THROW 51000,'User Validation Faild',1
END

IF EXISTS(SELECT t.bill_type FROM #tempGroup t WHERE t.bill_type='AH')
BEGIN
	SET @Status='BadBillType'
	INSERT INTO #tempError VALUES ('Group','Bill Type is ACH, Group payment is credited during billing run. ');
	THROW 51000,'User Validation Faild',1
END
IF EXISTS(SELECT t.group_type FROM #tempGroup t WHERE t.group_type='EG') AND @InvoiceNum=0
BEGIN

Select @InvoiceNum=max(b.invoice_num)
	--b.invoice_num 
	from #tempGroup t
	JOIN [group] g ON g.group_payee=t.group_id
	JOIN bill_sum b ON b.group_id=g.group_id 


IF @InvoiceNum=0
BEGIN
	SET @Status='Fail'
	INSERT INTO #tempError VALUES ('Group','Unable to find Invoice for group');
	THROW 51000,'User Validation Faild',1
END

END

IF LEN(@ConfigName)=0
BEGIN
	IF EXISTS(SELECT t.group_type FROM #tempGroup t WHERE t.group_type='EG')
		SET @ConfigName = 'LockBox-API-EG' 
	
	ELSE IF EXISTS(SELECT t.group_type FROM #tempGroup t WHERE t.group_type='SG')
		SET @ConfigName = 'LockBox-API-SG'
	ELSE
	BEGIN
		INSERT INTO #tempError VALUES ('Batch','Invalid Group Type must be EG or SG');
		THROW 51000,'User Validation Faild',1
	END	 
	
END

SET @BatchID=0
DECLARE @dls_sir_id INT=0
DECLARE @ModName NVARCHAR(50)='Lockbox Module'
BEGIN TRY

EXEC @BatchID=usp_api_CreateBatch @ModName,@ConfigName,@AsOFDate,'Api'

END TRY
BEGIN CATCH
	INSERT INTO #tempError VALUES ('Batch',ERROR_MESSAGE());
	THROW 51000,'User Validation Faild',1
END CATCH


INSERT INTO dls_lockbox  
		   (dls_batch_id, dls_status, dls_source, invoice_no,
		    invoice_date, invoice_amt, check_no, paid_amt, pay_token )
SELECT DISTINCT @BatchID,'L' AS [Status],'F' AS [source],IIF(t.group_type='EG',@InvoiceNum,t.group_id) AS invoice_no,
		@InvoiceDate,'0.00' AS invoice_amt,@CheckNum,@AmtPaid,@PayToken     
		FROM #tempGroup t

SET @dls_sir_id=SCOPE_IDENTITY();

 SELECT t.ErrorName AS ErrorType,t.ErrorDesc AS ErrorMsg FROM #tempError t

 
END TRY
BEGIN CATCH
IF ERROR_MESSAGE()='User Validation Faild'
BEGIN
  Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempError t
END
ELSE 
 THROW; 
END CATCH
END