﻿-- =============================================
-- Author:		UTHAYAN.S
-- Create date: 15 Dec 2016
-- Description:	Delete Configuration
-- =============================================
CREATE PROCEDURE [dbo].[usp_dl_DeleteConfiguration] 
	-- Add the parameters for the stored procedure here
	@configurationId int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DELETE FROM dl_config_param
	WHERE config_id = @configurationId;
	
	DELETE FROM dl_config_job_det
	WHERE config_id = @configurationId;

	DELETE FROM dl_cfg_bat_param
	WHERE config_bat_id in (
		SELECT config_bat_id FROM dl_config_bat
		 WHERE config_id = @configurationId);
		 
	DELETE FROM dl_log_error
	WHERE config_bat_id in (
		SELECT config_bat_id FROM dl_config_bat
		 WHERE config_id = @configurationId);
	
	DELETE FROM dl_log_error_h
	WHERE config_bat_id in (
		SELECT config_bat_id FROM dl_config_bat
		 WHERE config_id = @configurationId);
		 
	DELETE FROM dl_bat_statistics
	WHERE cfg_bat_det_id in (
		SELECT cfg_bat_det_id 
		  FROM dl_cfg_bat_det
	    WHERE config_bat_id in (
				SELECT config_bat_id 
				  FROM dl_config_bat
		 		 WHERE config_id = @configurationId));
	
	DELETE FROM dl_cfg_bat_det
	WHERE config_bat_id in (
		SELECT config_bat_id FROM dl_config_bat
		 WHERE config_id = @configurationId);

	DELETE FROM dl_config_bat
	WHERE config_id = @configurationId;
	
	DELETE FROM dl_config
	WHERE config_id = @configurationId;
END