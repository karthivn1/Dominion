﻿CREATE PROCEDURE [dbo].[dlp_mbgrpl_info_count]
    @a_group_id INT ,
    @a_plan_id INT ,
    @a_member_id INT ,
    @a_as_of_date DATE ,
    @a_future CHAR(1) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 INT = NULL OUTPUT ,
    @SWP_Ret_Value4 SMALLINT = NULL OUTPUT ,
    @SWP_Ret_Value5 DATE = NULL OUTPUT ,
    @SWP_Ret_Value6 DATE = NULL OUTPUT
    
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_group_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_eff_gr_pl DATE;
        DECLARE @n_exp_gr_pl DATE;
        DECLARE @n_count INT;
        DECLARE @n_mb_gr_pl_id INT;
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_sub_in_plan SMALLINT;

        SET NOCOUNT ON;
        BEGIN TRY
            SET @n_count = 0;
            SET @n_group_id = NULL;
            SET @n_plan_id = NULL;
            SET @n_mb_gr_pl_id = NULL;
            SET @n_eff_gr_pl = NULL;
            SET @n_exp_gr_pl = NULL;
            SET @n_sub_in_plan = NULL;

            DECLARE @SWV_cursor_var TABLE
                (
                  mb_gr_pl_id INT ,
                  group_id INT ,
                  plan_id INT ,
                  eff_gr_pl DATE ,
                  exp_gr_pl DATE ,
                  sub_in_plan SMALLINT
                );

            IF @a_future = 'Y'
                IF @a_group_id > 0
                    IF @a_plan_id > 0
                        BEGIN
						
                            INSERT  INTO @SWV_cursor_var
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
                                    )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                                            plan_id ,
                                            eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND group_id = @a_group_id
                                            AND plan_id = @a_plan_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );
						  
                            SELECT  @n_count = @@ROWCOUNT;
	  
                        END;
                    ELSE
                        BEGIN

                            INSERT  INTO @SWV_cursor_var
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
                                    )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                                            plan_id ,
                                            eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND group_id = @a_group_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            SELECT  @n_count = @@ROWCOUNT;
                        END;
		
                ELSE
                    IF @a_plan_id > 0
                        BEGIN

                            INSERT  INTO @SWV_cursor_var
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
                                    )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                                            plan_id ,
                                            eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND plan_id = @a_plan_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            SELECT  @n_count = @@ROWCOUNT;

                        END;
                    ELSE
                        BEGIN
                            INSERT  INTO @SWV_cursor_var
                                    ( mb_gr_pl_id ,
                                      group_id ,
                                      plan_id ,
                                      eff_gr_pl ,
                                      exp_gr_pl ,
                                      sub_in_plan
                                    )
                                    SELECT  mb_gr_pl_id ,
                                            group_id ,
                                            plan_id ,
                                            eff_gr_pl ,
                                            exp_gr_pl ,
                                            sub_in_plan
                                    FROM    dbo.rlmbgrpl (NOLOCK)
                                    WHERE   member_id = @a_member_id
                                            AND eff_gr_pl > @a_as_of_date
                                            AND ( exp_gr_pl > eff_gr_pl
                                                  OR exp_gr_pl IS NULL
                                                );

                            SELECT  @n_count = @@ROWCOUNT;
                        END;
		
            ELSE
                IF @a_future = 'N'
                    IF @a_group_id > 0
                        IF @a_plan_id > 0
                            BEGIN

                                INSERT  INTO @SWV_cursor_var
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
                                        )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                                plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND group_id = @a_group_id
                                                AND plan_id = @a_plan_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                SELECT  @n_count = @@ROWCOUNT;
                            END;
                        ELSE
                            BEGIN
                                INSERT  INTO @SWV_cursor_var
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
                                        )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                                plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND group_id = @a_group_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                SELECT  @n_count = @@ROWCOUNT;

                            END;
		
                    ELSE
                        IF @a_plan_id > 0
                            BEGIN

							
                                INSERT  INTO @SWV_cursor_var
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
                                        )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                                plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND plan_id = @a_plan_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                SELECT  @n_count = @@ROWCOUNT;

                            END;
                        ELSE
                            BEGIN

                                INSERT  INTO @SWV_cursor_var
                                        ( mb_gr_pl_id ,
                                          group_id ,
                                          plan_id ,
                                          eff_gr_pl ,
                                          exp_gr_pl ,
                                          sub_in_plan
                                        )
                                        SELECT  mb_gr_pl_id ,
                                                group_id ,
                                                plan_id ,
                                                eff_gr_pl ,
                                                exp_gr_pl ,
                                                sub_in_plan
                                        FROM    dbo.rlmbgrpl (NOLOCK)
                                        WHERE   member_id = @a_member_id
                                                AND eff_gr_pl <= @a_as_of_date
                                                AND ( exp_gr_pl > @a_as_of_date
                                                      OR exp_gr_pl IS NULL
                                                    );

                                SELECT  @n_count = @@ROWCOUNT;

                            END;
		
                ELSE
                    IF @a_future = 'E'
                        IF @a_group_id > 0
                            IF @a_plan_id > 0
                                BEGIN

                                    INSERT  INTO @SWV_cursor_var
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
                                            )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND group_id = @a_group_id
                                                    AND plan_id = @a_plan_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );

                                    SELECT  @n_count = @@ROWCOUNT;
                                END;
                            ELSE
                                BEGIN

                                    INSERT  INTO @SWV_cursor_var
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
                                            )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND group_id = @a_group_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );
								   
                                    SELECT  @n_count = @@ROWCOUNT;

                                END;
		
                        ELSE
                            IF @a_plan_id > 0
                                BEGIN

                                    INSERT  INTO @SWV_cursor_var
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
                                            )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND plan_id = @a_plan_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );

                                    SELECT  @n_count = @@ROWCOUNT;

                                END;
                            ELSE
                                BEGIN

                                    INSERT  INTO @SWV_cursor_var
                                            ( mb_gr_pl_id ,
                                              group_id ,
                                              plan_id ,
                                              eff_gr_pl ,
                                              exp_gr_pl ,
                                              sub_in_plan
                                            )
                                            SELECT  mb_gr_pl_id ,
                                                    group_id ,
                                                    plan_id ,
                                                    eff_gr_pl ,
                                                    exp_gr_pl ,
                                                    sub_in_plan
                                            FROM    dbo.rlmbgrpl (NOLOCK)
                                            WHERE   member_id = @a_member_id
                                                    AND eff_gr_pl <= @a_as_of_date
                                                    AND ( exp_gr_pl IS NOT NULL
                                                          AND eff_gr_pl = exp_gr_pl
                                                        );

                                    SELECT  @n_count = @@ROWCOUNT;

	  
                                END;
		
	
            SET @SWP_Ret_Value = @n_count;

            SELECT  @SWP_Ret_Value1 = mb_gr_pl_id ,
                    @SWP_Ret_Value2 = group_id ,
                    @SWP_Ret_Value3 = plan_id ,
                    @SWP_Ret_Value4 = sub_in_plan ,
                    @SWP_Ret_Value5 = eff_gr_pl ,
                    @SWP_Ret_Value6 = exp_gr_pl
            FROM    @SWV_cursor_var;

			

            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = NULL;
            SET @SWP_Ret_Value4 = NULL;
            SET @SWP_Ret_Value5 = NULL;
            SET @SWP_Ret_Value6 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;