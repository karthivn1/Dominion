﻿
CREATE PROCEDURE [dbo].[eClaims_Load_Process]
	@Mode VARCHAR(4),
	@FileDir VARCHAR(4000)

AS
BEGIN
/*********************************************************************
Proc Name   : eClaims_Load_Process
Author      : Cognizant
Date        : 19-May-2017
Description : 
Change History:
-------------------------------------------------
Date         Author            Change Description
-------------------------------------------------
19-May-2017  
*********************************************************************/ 

/*
  
  Purpose:  Automates the entire claim process from eClaim file load
            to running eClaim syncs         
               1. Detects new eClaim files in /export/home/stc
               2. Loads the new file(s) into eClaims
               3. Runs eClaims stored procedure "Set Status (Batch)"

		4. Submit to DataLoad (= DataLoad "Load")
		5. Run DataLoad "After Load"
		6. Run DataLoad "Preprocess"
		7. Run DataLoad "Update"
		8. Start and monitor claim services to completion

		9. DataLoad Sync
		10.DataDental Sync - 1 of 3
		11.DataDental Sync - 2 of 3
		12.DataDental Sync - 3 of 3
*/
 SET NOCOUNT ON;

	DECLARE @Batch_ID		INT
	DECLARE @Current_Date	DATETIME
	DECLARE @subdirectory	VARCHAR(50)
	DECLARE @Error_Desc	    VARCHAR(50)
	DECLARE @Status			VARCHAR(1)

	IF OBJECT_ID('tempdb..#eclaim_files') IS NOT NULL
		DROP TABLE #eclaim_files

	INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Loading Files into eClaims',getdate(),original_login())

	CREATE TABLE #eclaim_files(subdirectory VARCHAR(50),depth INT,filename INT)

	INSERT INTO #eclaim_files(subdirectory,depth,filename) -- Get all Eclaim files from Directory
	EXEC master.dbo.xp_dirtree @FileDir,1,1 

	IF @@ROWCOUNT <> 0
	BEGIN
		DECLARE @Files table (ID INT IDENTITY(1,1),subdirectory varchar(20))

		INSERT INTO @Files(subdirectory)
		SELECT subdirectory
		FROM #eclaim_files (NOLOCK)
		WHERE filename=1
		AND subdirectory like 'src%_h.dat' 
		--and subdirectory like 'src2722%_h.dat' 
	

	
		DECLARE @cur_cnt INT
				,@cur_i INT;

		 SET @cur_i = 1;

	
		 SELECT  @cur_cnt = COUNT(1)
		 FROM    @Files 
							
	
		WHILE ( @cur_i <= @cur_cnt )
		BEGIN
				SELECT @subdirectory=substring(subdirectory,0,(len(subdirectory)-5)) 
				FROM @Files 
				WHERE ID=@cur_i

			IF NOT EXISTS (SELECT 'x' 
							FROM eclaim_h (NOLOCK)
							WHERE file_name=@subdirectory)	--1. Detects new eClaim files to load
			BEGIN
				INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Loading Files into eClaims for "'+@subdirectory+'" Initiated',GETDATE(),ORIGINAL_LOGIN())
				BEGIN TRY
				
					EXECUTE eclaim_init_ld @subdirectory,'dle_gen'	--2. Loads the new file(s) into eClaims
					INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Loading Files into eClaims for "'+@subdirectory+'" Completed',GETDATE(),ORIGINAL_LOGIN())
					SET @Status='Y'

				END TRY
				BEGIN CATCH

					SET @Error_Desc = ERROR_MESSAGE()
					INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES (@Error_Desc,GETDATE(),ORIGINAL_LOGIN())

				END CATCH
				END
				SET @cur_i = @cur_i + 1
		END

		IF @Status ='Y'
		BEGIN
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Eclaims Running Set Status',GETDATE(),ORIGINAL_LOGIN())

			EXECUTE eclaim_upd_status -- Run "Set Status (Batch)" Stored Procedure
		
			/*####################################
			#  End of stop claim services for  #
			#  both 'FULL' and 'LOAD'.         #
			#  Submit claims for 'FULL'        #
			#  processing starts here.         #
			####################################*/

			IF @Mode = 'FULL'
			BEGIN
				INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Eclaims New Batch Initiated',GETDATE(),ORIGINAL_LOGIN())
				EXECUTE dload_new_batch 15

				SELECT  @Batch_ID=MAX(config_bat_id)
				FROM dl_config c, 
					dl_config_bat b
				WHERE c.config_name = 'ECLAIM'
				AND c.config_id		= b.config_id

				SET @Current_Date = GETDATE()

				INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Submitting eClaims to DataLoad/u',GETDATE(),ORIGINAL_LOGIN())

				INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('DataLoad/u After Load Phase',GETDATE(),ORIGINAL_LOGIN())
				EXECUTE dlp_al_utilization @Batch_ID, @Current_Date

				INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('DataLoad/u Preprocess Phase',GETDATE(),ORIGINAL_LOGIN())
				EXECUTE dlp_bu_utilization @Batch_ID, 0, @Current_Date

				INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('DataLoad/u Update Phase',GETDATE(),ORIGINAL_LOGIN())
				EXECUTE dlp_up_utilization @Batch_ID, @Current_Date
			END


			/* Start and monitor claim services to completion */
			
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('DataLoad Monitor claim Services/Start',GETDATE(),ORIGINAL_LOGIN())

			DECLARE @cnt INT = 1;
			WHILE(@cnt<>0)
			BEGIN
		
				WAITFOR DELAY '00:01';

				EXECUTE usp_Claim_Process_Chk @Batch_ID,@cnt OUTPUT
			END

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('DataLoad Monitor claim Services/Stop',GETDATE(),ORIGINAL_LOGIN())

			/*

				####################################
				# For Full and Load
				#	1. DataLoad Sync
				#	2. DataDental Sync - 1 of 3
				#	3. DataDental Sync - 2 of 3
				#	4. DataDental Sync - 3 of 3
				#
				####################################
			*/

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('eClaim DataLoad Sync Initiated',GETDATE(),ORIGINAL_LOGIN())
			EXECUTE dload_sync
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('eClaim DataLoad Sync Completed',GETDATE(),ORIGINAL_LOGIN())

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Running the eClaim sync1 procedures',GETDATE(),ORIGINAL_LOGIN())
			EXECUTE eclaim_dds_sync1
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Completed the eClaim sync1 procedures',GETDATE(),ORIGINAL_LOGIN())

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Running the eClaim sync2 procedures',GETDATE(),ORIGINAL_LOGIN())
			EXECUTE eclaim_dds_sync2
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Completed the eClaim sync2 procedures',GETDATE(),ORIGINAL_LOGIN())

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Running the eClaim sync4 procedures',GETDATE(),ORIGINAL_LOGIN())
			EXECUTE eclaim_dds_sync4
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Completed the eClaim sync4 procedures',GETDATE(),ORIGINAL_LOGIN())

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Running the eClaim sync3 procedures',GETDATE(),ORIGINAL_LOGIN())
			EXECUTE eclaim_dds_sync3
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('Completed the eClaim sync3 procedures',GETDATE(),ORIGINAL_LOGIN())
			

			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('End of DataLoad and DataDental Syncs',GETDATE(),ORIGINAL_LOGIN())

		END
		ELSE
		BEGIN
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('No Files Loaded',GETDATE(),ORIGINAL_LOGIN())
		END
	END
	ELSE
	BEGIN
			INSERT INTO Cron_Job_Log (description,created_date,created_by) VALUES ('File/Path does not exist',GETDATE(),ORIGINAL_LOGIN())
	END


	SET NOCOUNT OFF;
END