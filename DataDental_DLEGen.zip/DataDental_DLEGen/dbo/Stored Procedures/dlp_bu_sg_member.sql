﻿CREATE PROCEDURE [dbo].[dlp_bu_sg_member]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
	

/*
 *       Created Date    : 02/04/2001
 *       Created By      : Jacky Chang
 *       Reason          : Subscriber Single Group Eligibility Preprocessing.
 *	20131004$$ks - Have had to make major changes to process 
 *	previously the interface was only used to add new SG members and terminate
 *	them.  With Health Care Reform the SG DataLoad needs to have full capability
 */
	--error variable
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 11:30:30 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
	
        DECLARE @i_error_no INT;
		DECLARE @s_error_no INT;
        DECLARE @d_valid_error INT;
        DECLARE @d_error_descr VARCHAR(64);
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;
        DECLARE @a_fail_rec INT;
	
        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @ls_now VARCHAR(22);
        DECLARE @i_statistics_id INT;
        DECLARE @n_error_count INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @i_count INT;
	--paramater variable
	     DECLARE @d_gp_eff_date DATE;
        DECLARE @d_gp_exp_date DATE;
        DECLARE @d_gppl_eff DATE;
        DECLARE @d_gppl_exp DATE;
        DECLARE @n_mb_count INT;
        DECLARE @n_mbgrpl_id INT;
        DECLARE @n_group_id INT;
        DECLARE @n_plan_id INT;
        DECLARE @n_sub_in_plan SMALLINT;
        DECLARE @n_rate_code CHAR(2);
        DECLARE @n_eff_gr_pl DATE;
        DECLARE @n_exp_gr_pl DATE;
        DECLARE @n_eff_rt_date DATE;
        DECLARE @n_exp_rt_date DATE;
        DECLARE @n_eff_date DATE;
        DECLARE @n_exp_date DATE;
        DECLARE @n_facility_id INT;
        DECLARE @n_eff_fc_date DATE;
        DECLARE @n_exp_fc_date DATE;
        DECLARE @i_dent_cnt INT;
        DECLARE @i_vsion_cnt INT;
        DECLARE @n_count_future INT;
        DECLARE @n_count_gp INT;
        DECLARE @n_rlplfc_id INT;
	--define s_group_type char(2);
        DECLARE @as_action_code CHAR(2);
        DECLARE @as_addr_action CHAR(2);
        DECLARE @as_hold_action CHAR(2);
        DECLARE @as_pd_action CHAR(2);
        DECLARE @as_sub_id INT;
        DECLARE @as_member_id INT;
        DECLARE @as_msg_id INT;
        DECLARE @as_gp_id INT;
        DECLARE @as_pl_id INT;
        DECLARE @as_fc_id INT;
        DECLARE @as_gpplrt_eff DATE;
        DECLARE @as_fc_eff DATE;
        DECLARE @as_term_date DATE;
        DECLARE @as_pd_id INT;
        DECLARE @as_pdcomm_eff DATE;

        DECLARE @n_sub_count INT;
        DECLARE @s_change_dep_pc CHAR(1);
        DECLARE @d_fc_eff DATE;
        DECLARE @d_fc_exp DATE;
        DECLARE @t_del_sir INT;
        DECLARE @new_sg_rec CHAR(1);
        DECLARE @s_existing_sgmbr CHAR(1);
        DECLARE @s_sub_error CHAR(1);
        DECLARE @i_return_value INT;
        DECLARE @def_fc_id INT;
        DECLARE @d_fc_state CHAR(2);
        DECLARE @n_bu_count INT;
        DECLARE @n_count INT;
        DECLARE @s_batch_status CHAR(1);
        DECLARE @s_transfer_dep_gp CHAR(1);
        DECLARE @s_clean_err CHAR(1);
		DECLARE @t_temp_sir_id INT;
        DECLARE @t_temp_sir INT;
        DECLARE @d_ins_type CHAR(5);
        DECLARE @d_ins_opt CHAR(5);
        DECLARE @d_valid_status INT;
        DECLARE @i_sp_id INT;
        DECLARE @sg_sp_id INT;
		DECLARE @i_sir_def_id INT;
		DECLARE @sg_sir_def_id INT;
        DECLARE @sg_sir_def_name varchar(14);
        DECLARE @sg_proc_name varchar(14);
        DECLARE @sg_config_id INT;
        DECLARE @from_api smallint;
        
		DECLARE @n_has_facility_id char(1) ;
	DECLARE @n_multiple_plans char(1) ;
	DECLARE @n_allow_pl_change char(1) ;
	DECLARE @n_multiple_fc char(1) ;
	DECLARE @n_allow_fc_change char(1) ;
	DECLARE @n_def_eff_date char(10) ;
	DECLARE @n_def_exp_date char(10) ;
	DECLARE @n_has_term_date char(1) ;
	DECLARE @d_def_eff_date date ;
	DECLARE @d_def_exp_date date ;
	DECLARE @s_dls_sir_id INT ;
	DECLARE @s_dls_sub_sir_id INT ;
	DECLARE @s_member_flag char(2) ;
	DECLARE @s_alt_id char(20) ;
	DECLARE @s_ssn char(11) ;
	DECLARE @s_sub_ssn char(11) ;
	DECLARE @s_sub_alt_id char(20) ;
	DECLARE @s_member_code char(3) ;
	DECLARE @s_optional_5 char(5) ;
	DECLARE @s_paperless char(1) ;
	DECLARE @s_last_name char(15) ;
	DECLARE @s_first_name char(15) ;
	DECLARE @s_middle_init char(1) ;
	DECLARE @s_date_of_birth char(10) ;
	DECLARE @s_student_flag char(1) ;
	DECLARE @s_disable_flag char(1) ;
	DECLARE @s_cobra_flag char(1) ;
	DECLARE @s_msg_group_id INT ;
	DECLARE @s_plan_id INT ;
	DECLARE @s_facility_id INT ;
	DECLARE @s_rate_code char(2) ;
	DECLARE @s_mb_gppl_eff_date char(10) ;
	DECLARE @s_mb_fc_eff_date char(10) ;
	DECLARE @s_mb_term_date char(10) ;
	DECLARE @s_bank_account char(25) ;
	DECLARE @s_account_type char(2) ;
	DECLARE @s_trans_rt_nbr char(9) ;
	DECLARE @s_transaction_code char(2) ;
	DECLARE @s_address1 char(30) ;
	DECLARE @s_address2 char(30) ;
	DECLARE @s_city char(30) ;
	DECLARE @s_state char(2) ;
	DECLARE @s_zip char(5) ;
	DECLARE @s_zipx char(4) ;
	DECLARE @s_home_phone char(10) ;
	DECLARE @s_home_ext char(5) ;
	DECLARE @s_work_phone char(10) ;
	DECLARE @s_work_ext char(5) ;
 	DECLARE @s_email char(250) ;
	DECLARE @s_producer_id INT ;
	DECLARE @s_comm_scheme_id char(5) ;
	DECLARE @s_pd_type char(2) ;
	DECLARE @s_license_number char(9) ;
	DECLARE @s_selling_period char(1) ;
	DECLARE @s_pdcomm_eff_date char(10) ;
	DECLARE @s_msg_group_alt_id char(20) ;
	DECLARE @s_plan_dsp_name char(30) ;
	DECLARE @s_facility_alt_id char(20) ;
	DECLARE @s_producer_alt_id char(20) ;
	DECLARE @s_new_ssn char(11) ;
	DECLARE @s_src_id char(20) ;
	DECLARE @s_subnew_ssn char(11) ;
	DECLARE @s_subsrc_id char(20) ;
	DECLARE @s_ext_id_col char(20) ;
	DECLARE @d_date_of_birth date ;
	DECLARE @d_mb_gpplrt_eff date ;
	DECLARE @d_mb_fc_eff date ;
	DECLARE @d_mb_term_date date ;
	DECLARE @d_comm_scheme_id INT ;
	DECLARE @n_ffs_plan INT ;
	DECLARE @api_mbr_id INT ;
	DECLARE @api_sub_id INT ;
	DECLARE @api_plan_id INT ;
	DECLARE @api_fc_id INT ;
	DECLARE @api_msg_id INT ;
	DECLARE @api_grp_id INT ;
	DECLARE @t_sub_in_plan smallint ;

        DECLARE @n_process_count INT;
        DECLARE @n_succ_count INT;
		DECLARE @n_succ_count1 INT;
        DECLARE @SWV_dl_get_sp_id INT;
        DECLARE @SWV_dl_get_sir_def_id INT;
        DECLARE @SWV_dl_get_param_value VARCHAR(128);
        --DECLARE @SWV_cursor_var1 CURSOR;
        --DECLARE @cSIR CURSOR;
        DECLARE @SWV_func_DLP_SG_MISSING_par0 DATE;
	
        SET NOCOUNT ON;

		 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 1 AND BatchId = @a_batch_id )
		 BEGIN
	
				INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id])
				SELECT N'api_fc_id',						N'', @a_batch_id, 1
				UNION ALL SELECT N'api_grp_id',				N'', @a_batch_id, 1
				UNION ALL SELECT N'api_mbr_id',				N'', @a_batch_id, 1
				UNION ALL SELECT N'api_msg_id',				N'', @a_batch_id, 1
				UNION ALL SELECT N'api_plan_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N'api_sub_id',				N'', @a_batch_id, 1
				UNION ALL SELECT N'from_api',				N'', @a_batch_id, 1
				UNION ALL SELECT N'n_process_count',		N'', @a_batch_id, 1
				UNION ALL SELECT N'n_succ_count',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_account_type',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_address1',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_address2',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_alt_id',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_bank_account',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_city',					N'', @a_batch_id, 1
				UNION ALL SELECT N's_cobra_flag',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_comm_scheme_id',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_date_of_birth',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_disable_flag',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_dls_sir_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_email',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_facility_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_first_name',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_home_ext',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_home_phone',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_last_name',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_license_number',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_mb_fc_eff_date',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_mb_gppl_eff_date',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_mb_term_date',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_member_code',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_member_flag',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_msg_group_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_paperless',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_pd_type',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_pdcomm_eff_date',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_plan_id',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_producer_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_rate_code',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_selling_period',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_ssn',					N'', @a_batch_id, 1
				UNION ALL SELECT N's_state',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_student_flag',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_sub_alt_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_sub_ssn',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_trans_rt_nbr',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_transaction_code',		N'', @a_batch_id, 1
				UNION ALL SELECT N's_work_ext',				N'', @a_batch_id, 1
				UNION ALL SELECT N's_work_phone',			N'', @a_batch_id, 1
				UNION ALL SELECT N's_zip',					N'', @a_batch_id, 1
				UNION ALL SELECT N'sg_sir_def_id',			N'', @a_batch_id, 1
				UNION ALL SELECT N'sg_sp_id',				N'', @a_batch_id, 1
		
										
		END

		 SET @n_process_count = 0 ;
		SET @n_succ_count = 0;

			UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
			UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
        
        IF EXISTS ( SELECT  *
                    FROM  tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#dls_elig_sg_temp')
                            AND xtype = 'U' )
            DROP TABLE #dls_elig_sg_temp;
        CREATE TABLE #dls_elig_sg_temp ( dls_sub_temp_id INT ); 
        BEGIN TRY--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/dlp_bu_sg_member.trc";

--TRACE statement has no equivalent in MSSQL
--trace on;

--set explain on;

 BEGIN
  DECLARE @currentDateAndTime DATETIME;
                DECLARE @userSessionId INT;
	--TRACE statement has no equivalent in MSSQL
--trace "dlp_bu_sg_member():  Entered.";

                SET @currentDateAndTime = GETDATE();
                SET @userSessionId = @@spid;
	--TRACE statement has no equivalent in MSSQL
--trace "a_batch_id = " || a_batch_id;

	--TRACE statement has no equivalent in MSSQL
--trace "a_sir_id = " || a_sir_id;

	--TRACE statement has no equivalent in MSSQL
--trace "a_start_time = " || a_start_time;

            END;
           
  SET @sg_proc_name = 'bu_sg_member' ;
            
            SET @sg_sir_def_name = 'sg_member';
            

            SET @a_error_no = 0;
            SET @n_sub_in_plan = NULL;

            SELECT  @sg_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;

           
            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @a_batch_id, @sg_proc_name
			
            SET @sg_sp_id = @SWV_dl_get_sp_id;

            UPDATE dbo.GlobalVar set VarValue = @sg_sp_id where VarName = 'sg_sp_id' and  BatchId = @a_batch_id AND Module_Id = 1
			
            IF @sg_sp_id IS NULL
                OR @sg_sp_id <= 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Invalid SP Name',16,1);
					RETURN
				END
	
            
            SET @i_sp_id =@sg_sp_id ;
            
            EXECUTE @SWV_dl_get_sir_def_id=dbo.dl_get_sir_def_id @sg_sir_def_name

            SET @sg_sir_def_id = @SWV_dl_get_sir_def_id ;

             UPDATE dbo.GlobalVar set VarValue = @sg_sir_def_id where VarName = 'sg_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 1

            IF @sg_sir_def_id IS NULL
                OR @sg_sir_def_id <= 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Invalid SIR TABLE Definition',16,1);
					RETURN
				END
	
           
            SET @i_sir_def_id = @sg_sir_def_id;
          
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Has Facility ID'
            SET @n_has_facility_id = @SWV_dl_get_param_value;
            
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Multiple Plans'
            SET @n_multiple_plans = @SWV_dl_get_param_value;
            
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Allow PL Change'
            SET @n_allow_pl_change = @SWV_dl_get_param_value;
            

            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Multiple Facilities'

            SET @n_multiple_fc = @SWV_dl_get_param_value ;
            
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Allow FC Change'
            SET @n_allow_fc_change = @SWV_dl_get_param_value;
            
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Default EFF Date'
            SET @n_def_eff_date = @SWV_dl_get_param_value;
            
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Default EXP Date'

            SET @n_def_exp_date = @SWV_dl_get_param_value;
            
            EXECUTE @SWV_dl_get_param_value=dbo.dl_get_param_value @a_batch_id, @sg_sp_id,
                'Has Term Date Flag'

        SET @n_has_term_date =@SWV_dl_get_param_value;
            
            IF ( @n_has_facility_id IS NULL
                 
               )
                OR LEN(@n_has_facility_id) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Has Facility ID Flag',16,1);
					RETURN
				END
            ELSE
                BEGIN
                   
            IF @n_has_facility_id NOT IN ( 'Y', 'N' )
					BEGIN
					SET @s_error_no = 0;
					RAISERROR('Invalid Has Facility ID Flag',16,1);
						RETURN
					END
                END;
	
            
            IF ( @n_multiple_plans IS NULL
    
       )
                OR LEN(@n_multiple_plans) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Multiple Plans Flag',16,1);
					RETURN
				END
            ELSE
                BEGIN
                 
                    IF @n_multiple_plans NOT IN ( 'Y', 'N' )
					BEGIN
						SET @s_error_no = 0;
                      RAISERROR('Invalid Multiple Plans Flag',16,1);
						RETURN
					END
                END;
	
            
            IF ( @n_allow_pl_change IS NULL
                 
               )
                OR LEN(@n_allow_pl_change) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Allow Plan Change Flag',16,1);
					RETURN
				END
            ELSE
                BEGIN
                   
                    IF @n_allow_pl_change NOT IN ( 'Y', 'N' )
					BEGIN
						SET @s_error_no = 0;
                        RAISERROR('Invalid Allow Plan Change Flag',16,1);
						RETURN
					END
                END;
	
            
            IF ( @n_multiple_fc IS NULL
                 
               )
                OR LEN(@n_multiple_fc) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Multiple Facilities Flag',16,1);
					RETURN
				END
            ELSE
                BEGIN
                    
                    IF @n_multiple_fc NOT IN ( 'Y', 'N' )
					BEGIN
                        RAISERROR('Invalid Multiple Facilities Flag',16,1);
						RETURN
					END
                END;
	
            
            IF ( @n_allow_fc_change IS NULL
                 
               )
                OR LEN(@n_allow_fc_change) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Allow Facility Change Flag',16,1);
					RETURN
				END
            ELSE
                BEGIN
                  
                    IF @n_allow_fc_change NOT IN ( 'Y', 'N' )
					BEGIN
						SET @s_error_no = 0;
                        RAISERROR('Invalid Allow Facility Change Flag',16,1);
						RETURN
					END
                END;
	
            IF ( @n_def_eff_date IS NULL
                 
               )
                OR LEN(@n_def_eff_date) = 0
				BEGIN
					SET @s_error_no = 0;
				   RAISERROR('Missing Default Effective Date Value',16,1);
				   RETURN
			   END
            ELSE
                BEGIN
					SET @s_error_no = 0;
                    SET @s_error_descr = 'Invalid Default Effective Date Format';
                    
                    SET @d_def_eff_date = cast(@n_def_eff_date as date) ;

                   
                    IF DATEPART(DAY,
                                @d_def_eff_date) != 1
						BEGIN
							SET @s_error_no = 0;
							RAISERROR('Default Effective Date must be 1st of the month',16,1);
							RETURN
						END
                END;
	
            
            IF ( @n_def_exp_date IS NULL
                 
               )
                OR LEN(@n_def_exp_date) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Default Expiration Date Value',16,1);
					RETURN
				END
            ELSE
                BEGIN
					SET @s_error_no = 0;
                    SET @s_error_descr = 'Invalid Default Expiration Date Format';
                   
                    SET @d_def_exp_date = CONVERT(VARCHAR, CONVERT(DATE, @n_def_exp_date)) ;
                  
        IF DATEPART(DAY,
                                CONVERT(DATE, CONVERT(VARCHAR, @d_def_exp_date))) != 1
						BEGIN
							SET @s_error_no = 0;
							RAISERROR('Default Expiration Date must be 1st of the month',16,1);
							RETURN
						END
                END;
	
    
            IF ( @n_has_term_date IS NULL
              
               )
 OR LEN(@n_has_term_date) = 0
				BEGIN
					SET @s_error_no = 0;
					RAISERROR('Missing Has Term Date Flag',16,1);
					RETURN
				END
            ELSE
                BEGIN
                   
            IF @n_has_term_date NOT IN ( 'Y', 'N' )
					BEGIN
					SET @s_error_no = 0;
                        RAISERROR('Invalid Has Term Date Flag',16,1);
						RETURN
					END
                END;
	
	/* 20121008$$ks API will have already looked up member info
	 * if dls_member_id or dls_sub_id is not zero then one can assume they are
	 * the correct IDs and not have to validate or re-look up member
	 */
	 
            SET @from_api = 0 ;
            
            SELECT  @from_api = 1
            FROM    dbo.dl_config (NOLOCK)
            WHERE   config_id = @sg_config_id
                    AND config_name LIKE '%API%';
           
                 
            IF @from_api IS NULL
                BEGIN
                    SET @from_api = 0;
                   
                END;
	
           
            EXECUTE dbo.dl_it_statistics @a_batch_id, @sg_sp_id, @a_start_time,
                @n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_descr OUTPUT;

            IF @n_error_no <= 0
			BEGIN
				SET @s_error_no = 0;
                RAISERROR('(Internal) error when creating statistics',16,1);
				RETURN
			END
	
            --SET @n_process_count = 0 ;
			--SET @n_succ_count = 0;
		
            SET @n_sub_count = 0;
            

			UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
			UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
            
            SET @s_clean_err = 'N';

			
            IF @a_sir_id > 0
                BEGIN
                    SELECT  @a_sir_id = dls_sub_sir_id
                 FROM    dbo.dls_sg_member (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @a_sir_id;
                   
                    DELETE  FROM dbo.dls_sg_member
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sub_sir_id = @a_sir_id
                            AND dls_source = 'A'
                            AND dls_status IN ( 'P', 'E' );
                    
					UPDATE  dbo.dls_sg_member
                    SET     dls_status = 'V'
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_status IN ( 'P', 'E' )
                            AND dls_sub_sir_id = @a_sir_id;

							
                    DELETE  FROM dbo.dl_action
                    WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dbo.dls_sg_member (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @a_sir_id );

                    /*
					SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id  FROM dbo.dls_sg_member (NOLOCK)
         WHERE dls_batch_id = @a_batch_id AND dls_sub_sir_id = @a_sir_id
         AND dls_source = 'F';
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @t_del_sir;
                    WHILE @@FETCH_STATUS = 0
					*/

                    DECLARE @SWV_cursor_var1 TABLE
                        (
                          id INT IDENTITY ,
                          dls_sir_id INT
                        );
                    INSERT  INTO @SWV_cursor_var1
                            ( dls_sir_id
                            )
                            SELECT  dls_sir_id
                            FROM    dbo.dls_sg_member (NOLOCK)
         WHERE   dls_batch_id = @a_batch_id
								AND dls_sub_sir_id = @a_sir_id
                                    AND dls_source = 'F';

                    DECLARE @cur1_cnt INT ,
                        @cur1_i INT;
              SET @cur1_i = 1;
    --Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;
                    WHILE ( @cur1_i <= @cur1_cnt )
   BEGIN
                       SELECT  @t_del_sir = dls_sir_id
   FROM    @SWV_cursor_var1
                  WHERE   id = @cur1_i;
                            
                            EXECUTE dbo.dl_clean_curr_err @a_batch_id,
                                @t_del_sir, @sg_sp_id, @n_error_no OUTPUT,
           @n_error_text OUTPUT;
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @t_del_sir;
                            SET @cur1_i = @cur1_i + 1;
                        END;
                    --CLOSE @SWV_cursor_var1;
                END;
            ELSE
                BEGIN
                    BEGIN
                        --DECLARE @SWV_cursor_var2 CURSOR;
                        BEGIN TRY
                            DELETE  FROM #dls_elig_sg_temp;
                            INSERT  INTO #dls_elig_sg_temp
                                    SELECT DISTINCT
                                            dls_sub_sir_id
                                    FROM    dbo.dls_sg_member (NOLOCK)
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_status = 'V'; --20131006$$ks - otherwise sets even updated record 

                            CREATE INDEX dls_elig_sg_tmp1 ON #dls_elig_sg_temp 
									(dls_sub_temp_id);

							/*
                            SET @SWV_cursor_var2 = CURSOR  FOR SELECT dls_sub_temp_id  FROM #dls_elig_sg_temp;
                            OPEN @SWV_cursor_var2;
                            FETCH NEXT FROM @SWV_cursor_var2 INTO @t_temp_sir_id;
                            WHILE @@FETCH_STATUS = 0
							*/
							
                            DECLARE @SWV_cursor_var2 TABLE
                                (
                                  id INT IDENTITY ,
                                  dls_sub_temp_id INT
                                );
                            INSERT  INTO @SWV_cursor_var2
                                    ( dls_sub_temp_id
                                    )
                                    SELECT  dls_sub_temp_id
                                    FROM    #dls_elig_sg_temp;

                            DECLARE @cur2_cnt INT ,
                                @cur2_i INT;
                            SET @cur2_i = 1;
    --Get the no. of records for the cursor
                            SELECT  @cur2_cnt = COUNT(1)
                            FROM    @SWV_cursor_var2;

							
							WHILE ( @cur2_i <= @cur2_cnt )
                                BEGIN
                                    SELECT  @t_temp_sir_id = dls_sub_temp_id
                                    FROM    @SWV_cursor_var2
                                    WHERE   id = @cur2_i;

                                    DELETE  FROM dbo.dls_sg_member
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sub_sir_id = @t_temp_sir_id
                                            AND dls_source = 'A';
								
								 UPDATE  dbo.dls_sg_member
                                    SET     dls_status = 'V'
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sub_sir_id = @t_temp_sir_id;

											
                                    --FETCH NEXT FROM @SWV_cursor_var2 INTO @t_temp_sir_id;
                                    SET @cur2_i = @cur2_i + 1;
                    END;
                            --CLOSE @SWV_cursor_var2;
                            DROP TABLE #dls_elig_sg_temp;
							
END TRY
                        BEGIN CATCH
                            SET @n_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            DELETE  FROM #dls_elig_sg_temp;
            DROP TABLE #dls_elig_sg_temp;
 
   END CATCH;
END;
                    DELETE  FROM dbo.dl_action
 WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
     FROM dbo.dls_sg_member (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
                  
				    DELETE  FROM dbo.dl_log_error
                    WHERE   config_bat_id = @a_batch_id
                            AND sp_id = @sg_sp_id
                            AND dls_sir_id IN (
							
							SELECT  dls_sir_id
                            FROM    dbo.dls_sg_member (NOLOCK)
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
                END;
	
										 
	/*
            SET @cSIR = CURSOR  FOR SELECT dls_sir_id, dls_sub_sir_id, member_flag, alt_id, ssn, sub_ssn,
		sub_alt_id, member_code, RTRIM(LTRIM(nameprefix)), namesuffix,
		last_name, first_name, middle_init, date_of_birth, student_flag,
		disable_flag, cobra_flag, msg_group_id, plan_id, facility_id, rate_code,
		mb_gppl_eff_date, mb_fc_eff_date, mb_term_date, bank_account,
		account_type, transit_route_nbr, transaction_code, address1,
		address2, city, state, zip, zipx, home_phone, home_ext,
		work_phone, work_ext, email, producer_id, comm_scheme_id, pd_type,
		license_number, selling_period, pdcomm_eff_date,
		msg_alt_id,plan_dsp_name, fc_alt_id, prod_alt_id, new_ssn,
		source_id, subnew_ssn, subsource_id, ext_id_col, dls_member_id,
		dls_subscriber_id, dls_msg_id, dls_group_id,
		dls_plan_id, dls_facility_id, sub_in_plan
	  
      FROM dbo.dls_sg_member (NOLOCK) WHERE dls_batch_id = @a_batch_id
      AND member_flag = '00' AND dls_status = 'V'
      AND ((@a_sir_id > 0 AND dls_sub_sir_id = @a_sir_id) OR
		 (@a_sir_id = 0 AND dls_sir_id > 0));
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @s_dls_sir_id, @s_dls_sub_sir_id,
                @s_member_flag, @s_alt_id, @s_ssn, @s_sub_ssn, @s_sub_alt_id,
                @s_member_code, @s_paperless, @s_optional_5, @s_last_name,
                @s_first_name, @s_middle_init, @s_date_of_birth,
                @s_student_flag, @s_disable_flag, @s_cobra_flag,
                @s_msg_group_id, @s_plan_id, @s_facility_id, @s_rate_code,
                @s_mb_gppl_eff_date, @s_mb_fc_eff_date, @s_mb_term_date,
                @s_bank_account, @s_account_type, @s_trans_rt_nbr,
                @s_transaction_code, @s_address1, @s_address2, @s_city,
                @s_state, @s_zip, @s_zipx, @s_home_phone, @s_home_ext,
                @s_work_phone, @s_work_ext, @s_email, @s_producer_id,
                @s_comm_scheme_id, @s_pd_type, @s_license_number,
                @s_selling_period, @s_pdcomm_eff_date, @s_msg_group_alt_id,
      @s_plan_dsp_name, @s_facility_alt_id, @s_producer_alt_id,
                @s_new_ssn, @s_src_id, @s_subnew_ssn, @s_subsrc_id,
                @s_ext_id_col, @api_mbr_id, @api_sub_id, @api_msg_id,
                @api_grp_id, @api_plan_id, @api_fc_id, @t_sub_in_plan;
            WHILE @@FETCH_STATUS = 0

			*/
            DECLARE @SWV_cursor_var3 TABLE
                (
                  id INT IDENTITY ,
                 dls_sir_id INT ,
        dls_sub_sir_id INT ,
                  member_flag CHAR(2) ,
                  alt_id CHAR(20) ,
                  ssn CHAR(11) ,
            sub_ssn CHAR(11) ,
                  sub_alt_id CHAR(20) ,
                  member_code CHAR(3) ,
                  nameprefix CHAR(5) ,
                  namesuffix CHAR(5) ,
  last_name CHAR(15) ,
                  first_name CHAR(15) ,
                  middle_init CHAR(1) ,
                  date_of_birth CHAR(10) ,
    student_flag CHAR ,
   disable_flag CHAR ,
    cobra_flag CHAR ,
      msg_group_id INT ,
                  plan_id INT ,
                  facility_id INT ,
           rate_code CHAR(2) ,
                  mb_gppl_eff_date CHAR(10) ,
                  mb_fc_eff_date CHAR(10) ,
                  mb_term_date CHAR(10) ,
     bank_account CHAR(25) ,
      account_type CHAR(2) ,
                  transit_route_nbr CHAR(9) ,
                  transaction_code CHAR(2) ,
                  address1 CHAR(30) ,
                  address2 CHAR(30) ,
                  city CHAR(20) ,
                  state CHAR(2) ,
                  zip CHAR(5) ,
                  zipx CHAR(4) ,
                  home_phone CHAR(10) ,
                  home_ext CHAR(5) ,
                  work_phone CHAR(10) ,
                  work_ext CHAR(5) ,
                  email VARCHAR(250) ,
                  producer_id INT ,
                  comm_scheme_id CHAR(5) ,
                  pd_type CHAR(2) ,
                  license_number CHAR(9) ,
                  selling_period CHAR ,
                  pdcomm_eff_date CHAR(10) ,
                  msg_alt_id CHAR(20) ,
                  plan_dsp_name CHAR(30) ,
                  fc_alt_id CHAR(20) ,
				 prod_alt_id CHAR(20) ,
                  new_ssn CHAR(11) ,
                  source_id CHAR(20) ,
                  subnew_ssn CHAR(11) ,
                  subsource_id CHAR(20) ,
                  ext_id_col CHAR(20) ,
                  dls_member_id INT ,
                  dls_subscriber_id INT ,
                  dls_msg_id INT ,
                  dls_group_id INT ,
                  dls_plan_id INT ,
                  dls_facility_id INT ,
                  sub_in_plan SMALLINT
                );
            INSERT  INTO @SWV_cursor_var3
                    ( dls_sir_id ,
                      dls_sub_sir_id ,
                      member_flag ,
                      alt_id ,
                      ssn ,
                      sub_ssn ,
                      sub_alt_id ,
                      member_code ,
                      nameprefix ,
                      namesuffix ,
                      last_name ,
                      first_name ,
                      middle_init ,
                      date_of_birth ,
                      student_flag ,
                      disable_flag ,
                      cobra_flag ,
                      msg_group_id ,
                      plan_id ,
                      facility_id ,
                      rate_code ,
                      mb_gppl_eff_date ,
                      mb_fc_eff_date ,
                      mb_term_date ,
                      bank_account ,
                      account_type ,
                      transit_route_nbr ,
                      transaction_code ,
                      address1 ,
address2 ,
                      city ,
                      state ,
                      zip ,
                      zipx ,
                      home_phone ,
                      home_ext ,
                      work_phone ,
                      work_ext ,
                      email ,
                      producer_id ,
                      comm_scheme_id ,
                      pd_type ,
                   license_number ,
                      selling_period ,
                 pdcomm_eff_date ,
                      msg_alt_id ,
                      plan_dsp_name ,
    fc_alt_id ,
                      prod_alt_id ,
                      new_ssn ,
                      source_id ,
                      subnew_ssn ,
                      subsource_id ,
                      ext_id_col ,
                      dls_member_id ,
  dls_subscriber_id ,
 dls_msg_id ,
      dls_group_id ,
dls_plan_id ,
                 dls_facility_id ,
                      sub_in_plan
  )
  SELECT  dls_sir_id ,
                            dls_sub_sir_id ,
                            member_flag ,
                            alt_id ,
                            ssn ,
                            sub_ssn ,
  sub_alt_id ,
                            member_code ,
                            RTRIM(LTRIM(nameprefix)) ,
                            namesuffix ,
                            last_name ,
                            first_name ,
                            middle_init ,
                            date_of_birth ,
                            student_flag ,
                            disable_flag ,
                            cobra_flag ,
                            msg_group_id ,
                         plan_id ,
                            facility_id ,
                            rate_code ,
                            mb_gppl_eff_date ,
                            mb_fc_eff_date ,
                            mb_term_date ,
                            bank_account ,
                            account_type ,
                            transit_route_nbr ,
                            transaction_code ,
                            address1 ,
                            address2 ,
                            city ,
                            state ,
                            zip ,
                            zipx ,
                            home_phone ,
                            home_ext ,
                            work_phone ,
                            work_ext ,
                            email ,
                            producer_id ,
                            comm_scheme_id ,
                            pd_type ,
                            license_number ,
                            selling_period ,
                            pdcomm_eff_date ,
                            msg_alt_id ,
                            plan_dsp_name ,
                            fc_alt_id ,
                            prod_alt_id ,
                            new_ssn ,
                            source_id ,
                            subnew_ssn ,
                            subsource_id ,
                            ext_id_col ,
                            dls_member_id ,
                            dls_subscriber_id ,
                            dls_msg_id ,
                            dls_group_id ,
                            dls_plan_id ,
                            dls_facility_id ,
                            sub_in_plan
                    FROM    dbo.dls_sg_member (NOLOCK)
                    WHERE   dls_batch_id = @a_batch_id
                            AND member_flag = '00'
                            AND dls_status = 'V'
                            AND ( ( @a_sir_id > 0
                                    AND dls_sub_sir_id = @a_sir_id
                                  )
                                  OR ( @a_sir_id = 0
                                       AND dls_sir_id > 0
                                     )
                                );

            DECLARE @cur3_cnt INT ,
                @cur3_i INT;
            SET @cur3_i = 1;
    --Get the no. of records for the cursor
            SELECT  @cur3_cnt = COUNT(1)
      FROM    @SWV_cursor_var3;
            WHILE ( @cur3_i <= @cur3_cnt )
                BEGIN
				
       SELECT				@s_dls_sir_id = dls_sir_id ,
                            @s_dls_sub_sir_id = dls_sub_sir_id ,
   @s_member_flag = member_flag ,
                            @s_alt_id = alt_id ,
                            @s_ssn = ssn ,
                            @s_sub_ssn = sub_ssn ,
                            @s_sub_alt_id = sub_alt_id ,
                            @s_member_code = member_code ,
							@s_paperless = nameprefix ,
                 @s_optional_5 = namesuffix ,
                          @s_last_name = last_name ,
          @s_first_name = first_name ,
                            @s_middle_init = middle_init ,
                            @s_date_of_birth = date_of_birth ,
                            @s_student_flag = student_flag ,
@s_disable_flag = disable_flag ,
 @s_cobra_flag = cobra_flag ,
                @s_msg_group_id = msg_group_id ,
                            @s_plan_id = plan_id ,
                            @s_facility_id = facility_id ,
                            @s_rate_code = rate_code ,
                            @s_mb_gppl_eff_date = mb_gppl_eff_date ,
                            @s_mb_fc_eff_date = mb_fc_eff_date ,
                            @s_mb_term_date = mb_term_date ,
                            @s_bank_account = bank_account ,
                            @s_account_type = account_type ,
                            @s_trans_rt_nbr = transit_route_nbr ,
                            @s_transaction_code = transaction_code ,
                            @s_address1 = address1 ,
                            @s_address2 = address2 ,
                            @s_city = city ,
                            @s_state = state ,
                            @s_zip = zip ,
                            @s_zipx = zipx ,
                            @s_home_phone = home_phone ,
                            @s_home_ext = home_ext ,
                            @s_work_phone = work_phone ,
                            @s_work_ext = work_ext ,
                            @s_email = email ,
                            @s_producer_id = producer_id ,
                            @s_comm_scheme_id = comm_scheme_id ,
                            @s_pd_type = pd_type ,
                            @s_license_number = license_number ,
                            @s_selling_period = selling_period ,
                            @s_pdcomm_eff_date = pdcomm_eff_date ,
                            @s_msg_group_alt_id = msg_group_id ,
                            @s_plan_dsp_name = plan_dsp_name ,
                            @s_facility_alt_id = fc_alt_id ,
                            @s_producer_alt_id = prod_alt_id ,
                            @s_new_ssn = new_ssn ,
                            @s_src_id = source_id ,
                            @s_subnew_ssn = subnew_ssn ,
                            @s_subsrc_id = subsource_id ,
                            @s_ext_id_col = ext_id_col ,
                            @api_mbr_id = dls_member_id ,
                            @api_sub_id = dls_subscriber_id ,
                            @api_msg_id = dls_msg_id ,
                            @api_grp_id = dls_group_id ,
							@api_plan_id = dls_plan_id ,
                            @api_fc_id = dls_facility_id ,
                            @t_sub_in_plan = sub_in_plan
                    FROM    @SWV_cursor_var3
                    WHERE   id = @cur3_i;

					
									
					UPDATE dbo.GlobalVar set VarValue = @s_member_flag where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_mb_gppl_eff_date where VarName = 's_mb_gppl_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_mb_fc_eff_date where VarName = 's_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_mb_term_date where VarName = 's_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @from_api where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_msg_group_id where VarName = 's_msg_group_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_dls_sir_id where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_first_name where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_last_name where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 1	
					UPDATE dbo.GlobalVar set VarValue = @s_date_of_birth where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_msg_id where VarName = 'api_msg_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_grp_id where VarName = 'api_grp_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_sub_id where VarName = 'api_sub_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_mbr_id where VarName = 'api_mbr_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_plan_id where VarName = 'api_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @api_fc_id where VarName = 'api_fc_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_alt_id where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_ssn where VarName = 's_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_sub_ssn where VarName = 's_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_sub_alt_id where VarName = 's_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_member_code where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 1
					
               		UPDATE dbo.GlobalVar set VarValue = @s_bank_account where VarName = 's_bank_account' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_account_type where VarName = 's_account_type' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_trans_rt_nbr where VarName = 's_trans_rt_nbr' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_transaction_code where VarName = 's_transaction_code' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_plan_id where VarName = 's_plan_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_student_flag where VarName = 's_student_flag' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_disable_flag where VarName = 's_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_cobra_flag where VarName = 's_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 1

					UPDATE dbo.GlobalVar set VarValue = @s_paperless where VarName = 's_paperless' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_address1 where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_address2 where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_zip where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_city where VarName = 's_city' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_state where VarName = 's_state' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_home_phone where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_home_ext where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_work_phone where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_work_ext where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_email where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 1

					UPDATE dbo.GlobalVar set VarValue = @s_producer_id where VarName = 's_producer_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_pd_type where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_license_number where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_selling_period where VarName = 's_selling_period' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_pdcomm_eff_date where VarName = 's_pdcomm_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_comm_scheme_id where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 1
					UPDATE dbo.GlobalVar set VarValue = @s_facility_id where VarName = 's_facility_id' and  BatchId = @a_batch_id AND Module_Id = 1
					

					

        BEGIN
      BEGIN TRY
                 
		--TRACE statement has no equivalent in MSSQL
--trace "s_dls_sub_sir_id = " || s_dls_sub_sir_id;

        
                            IF ( @t_sub_in_plan IS NOT NULL )
                                BEGIN
                                    
    IF ( @t_sub_in_plan < 0
                                         OR @t_sub_in_plan > 1
                      )
                                        BEGIN
                                            SET @t_sub_in_plan = 1;
                                            
                                        END;	--The default is one.
                                END;
                            ELSE
                                BEGIN
                                    SET @t_sub_in_plan = 1;
                                   
                                END;
		
                            SET @s_sub_error = 'N';
                            SET @s_change_dep_pc = 'N';
                            SET @s_transfer_dep_gp = 'N';
                           		
							SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1					
                            SET @n_process_count = @n_process_count + 1;
							UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1

                           
                            SET @n_sub_count = @n_sub_count + 1;
                            SET @as_action_code = NULL;
                            SET @as_addr_action = NULL;
                            SET @as_pd_action = NULL;
                            SET @as_sub_id = NULL;
                            SET @as_member_id = NULL;
                            SET @as_msg_id = NULL;
                            SET @as_gp_id = NULL;
                            SET @as_pl_id = NULL;
                            SET @as_fc_id = NULL;
                            SET @as_gpplrt_eff = NULL;
                            SET @as_fc_eff = NULL;
                            SET @as_term_date = NULL;
                            SET @as_pd_id = NULL;
                            SET @as_pdcomm_eff = NULL;
                            SET @a_error_no = 0;
                            SET @n_mb_count = 0;
                            SET @n_mbgrpl_id = 0;
                            SET @n_group_id = 0;
                            SET @n_plan_id = 0;
                            SET @n_rate_code = NULL;
                            SET @n_eff_gr_pl = NULL;
                            SET @n_exp_gr_pl = NULL;
                            SET @n_eff_rt_date = NULL;
                            SET @n_exp_rt_date = NULL;
                            SET @n_facility_id = 0;
                            SET @n_eff_fc_date = NULL;
  SET @n_exp_fc_date = NULL;
		--  created new procedure with code seperated from dlp_valid_sg
                            EXECUTE @d_valid_error=dbo.dlp_sg_precheck @a_batch_id
							
							
                            IF @d_valid_error < 0
                                SET @s_sub_error = 'Y';
								
                           
                            IF ( @s_mb_gppl_eff_date IS NULL
                                 
                               )
                                BEGIN
                                    
                                   SET @s_mb_gppl_eff_date = CONVERT(VARCHAR, @d_def_eff_date) ;
                       UPDATE dbo.GlobalVar set VarValue = @s_mb_gppl_eff_date where VarName = 's_mb_gppl_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
                                END;
		
                     
                            IF ( @s_mb_fc_eff_date IS NULL
              
                               )
                                BEGIN
                
                                    SET @s_mb_gppl_eff_date = CONVERT(VARCHAR, @d_def_eff_date);
      UPDATE dbo.GlobalVar set VarValue = @s_mb_gppl_eff_date where VarName = 's_mb_gppl_eff_date' and  BatchId = @a_batch_id AND Module_Id = 1
                            END;
		
                            SET @d_valid_error = 0;
		-- dlp_valid_sg
 		-- This procedure validates member, msg group, group relation
		-- seperated code to validate producer to a different procedure
		-- removed code to validate facility and now using the same function that elig uses
		-- removed code for address validation and moved to a different procedure
		-- Now returns as_action_code SA if member not found in DD, MU if member identified
		/* 20121010$$ks - Need to change logic some member not looked up for exiting member 
		 * where API has already determined member exists!
		 *  Include dls_member_id and dls_subscriber_id in loop above skip look up logic 
		 * in dlp_valid_sg when these fields are not zero and from_api = 1
		 * only things needed from dlp_valid_sg is 
		 * action code 
		 * rate code
		 * existing FC ID 
		 * existing dates 
		 */
                           
                            IF @api_mbr_id IS NULL
                                BEGIN
                                    SET @api_mbr_id = 0;
                                   
                                END;
		
                           
                            IF @api_sub_id IS NULL
                                BEGIN
                                    SET @api_sub_id = 0 ;
                           
                                END;
		
                           
                            IF @api_plan_id IS NULL
                                BEGIN
                                    SET @api_plan_id = 0 ;
                                   
                                END;
		
                            
                            IF @api_fc_id IS NULL
                                BEGIN
                                    SET @api_fc_id = 0;
                                   
                                END;
		
                            IF @api_msg_id IS NULL
                                BEGIN
                                    SET @api_msg_id = 0;
                                    
                                END;
		
                            IF @api_grp_id IS NULL
                                BEGIN
                                    SET @api_grp_id = 0;
                                    
                                END;
		
                           
                            IF @from_api = 1   -- reset s_faciity_id only if from_api is 1
                                BEGIN
                                    UPDATE dbo.GlobalVar set VarValue = @api_fc_id where VarName = 's_facility_id' and  BatchId = @a_batch_id AND Module_Id = 1
                                    SET @s_facility_id =@api_fc_id ;
                                  
                                END;
		
                            EXECUTE dbo.dlp_valid_sg @a_batch_id,
                                @d_valid_error OUTPUT, @d_error_descr OUTPUT,
								@as_action_code OUTPUT, @as_sub_id OUTPUT,
                                @as_member_id OUTPUT, @as_msg_id OUTPUT,
                                @as_gp_id OUTPUT, @as_pl_id OUTPUT,
								@as_fc_id OUTPUT, @as_gpplrt_eff OUTPUT,
                                @as_fc_eff OUTPUT, @as_term_date OUTPUT,
                                @s_rate_code OUTPUT;

								
								
                            IF @d_valid_error < 0 --20131004$$ks what if return value is minus 1???
                                BEGIN
                                    SET @SWP_Ret_Value = -1;
                            SET @SWP_Ret_Value1 = @d_error_descr;
                   -- RETURN;
                                END;
		
                            IF @d_valid_error = 0
                                SET @s_sub_error = 'Y';
		
                        IF @s_sub_error = 'N'
          BEGIN
                                SET @n_ffs_plan = 1;
                  
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.[plan] (NOLOCK) ,
                                                            dbo.ins_opt (NOLOCK)
                                                    WHERE   dbo.[plan].plan_id = @as_pl_id
                                                AND dbo.[plan].ins_opt = dbo.ins_opt.ins_opt
                                                            AND dbo.ins_opt.ins_opt_qual = 'I' )
                                        BEGIN
                                            SET @n_ffs_plan = 0;
                                          
                                        END;
			
                                    SELECT  @d_ins_opt = ins_opt ,
                                            @d_ins_type = ins_type
                                    FROM    dbo.[plan] (NOLOCK)
                                    WHERE   plan_id = @as_pl_id;
                                    
                                    IF @d_ins_type = 'D'
		   	-- UNKNOWN FACILITY FOR DENTAL FACILITY
                                        BEGIN
                                            SET @def_fc_id = 1;
                                            SET @d_fc_state = 'UK';
                                        END;
                                    ELSE
		   	-- UNKNOWN FACILITY FOR VISION FACILITY
                                        BEGIN
                                            SET @def_fc_id = 2;
                                            SET @d_fc_state = 'UK';
                                        END;
		 	
                                    IF @as_action_code = 'MU'
                                        BEGIN
                                           
                                            EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                @s_dls_sir_id, @as_action_code,
                                                @as_gpplrt_eff;
                                        END; -- action = MU
			
                                    IF @as_action_code = 'SA'
                                        BEGIN
                                            IF @as_sub_id IS NOT NULL
                                                AND @as_sub_id > 0
												BEGIN
													SET @s_error_no = 221;
												RAISERROR('Mbr already found in the database. Cannot perform Add',16,1);
												RETURN
											END
				
                                            BEGIN -----**
				-- do not log action as SA always adds address
                                EXECUTE dbo.dlp_check_sg_addr @a_batch_id,
                                                    'Y', @as_member_id,
                                                    @d_valid_error OUTPUT,
                                                    @as_addr_action OUTPUT;

													
                                                IF @d_valid_error < 0
                                                    SET @s_sub_error = 'Y';
		 	
		-- This function returns pd_action code. In future it can be used to expire, Add, update
		-- pd_action currently returned is "CA". 
		-- For new sub not logging action as CA is done before
		-- checking for other actions
                                                
                                                EXECUTE dbo.dlp_check_pd @a_batch_id,
                                                    @s_dls_sir_id, @as_msg_id,
                      0, @as_pl_id,
                                  @as_gpplrt_eff,
                                                    @d_valid_error OUTPUT,
													@as_pd_action OUTPUT,
@as_pd_id OUTPUT,
             @as_pdcomm_eff OUTPUT;

													
             IF @d_valid_error < 0
                                                    SET @s_sub_error = 'Y';
			
                                             
                                                IF @n_ffs_plan = 0
    BEGIN
                                                        
              IF @n_has_facility_id = 'Y'
                                                            BEGIN
        IF ( @as_fc_id IS NULL
                                                             
                                                              )
                                                              SET @as_fc_id = @def_fc_id;
						
                                                            
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              1;

															  
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
															 
                                                            END;
                                                        ELSE
                                                            BEGIN
                                                              SET @as_fc_id = @def_fc_id;
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              1;

															  
                                                              IF @n_error_no < 0
															  SET @s_sub_error = 'Y';
									  
                                                              ELSE
                                                              SET @as_fc_id = @def_fc_id;
                                                            END;
                                                    END;
				
    IF ( @s_sub_error = 'N' )
                                                    BEGIN
                                                     
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                         @s_dls_sir_id,
															@as_action_code,
                                                            @as_gpplrt_eff;
                                                    END; -- action = SA
				
                                            END;
                                        END; -- SA
			
              IF @as_action_code = 'PA'
                                        BEGIN
                                            IF @as_msg_id IS NULL
											BEGIN 
											SET @s_error_no = 250;
                                                RAISERROR('Missing MSG record while Member Info is located',16,1);
												RETURN
											END
				
                          IF @as_gp_id IS NULL
 SET @as_gp_id = 0; -- adding plan to new MSG
				
 IF @as_pl_id IS NULL
											BEGIN
											SET @s_error_no = 252;
            RAISERROR('Missing PL record while Member Info is located',16,1);
												RETURN
											END
				
                                 IF ( @s_sub_error = 'N' )
				/** PA is usually final action but in some cases we need to become PC
				 ** Need new error for term_date != Null
				 */
                                                BEGIN
                                                    IF @as_term_date IS NOT NULL
                                      SET @as_term_date = NULL; -- cannot have exp_date if PA
					
					/* 20131018$$ks - new_member is not "Y" if any above Action Codes
					 *	CALL dlp_check_sg_addr(a_batch_id, "Y", as_member_id)
					 */
                                                    EXECUTE dbo.dlp_check_sg_addr @a_batch_id,
                                                        'N', @as_member_id,
                                                        @d_valid_error OUTPUT,
                                                        @as_addr_action OUTPUT;

														
                                                    IF @d_valid_error < 0
                                                        SET @s_sub_error = 'Y';
														
                                                    ELSE
                                                        IF @as_addr_action LIKE 'G[1-7]'
                                                            ESCAPE '\'
                                                            BEGIN
                                                         
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_addr_action,
                                                              @as_gpplrt_eff;
                                                            END;
						
					
                                                    EXECUTE dbo.dlp_check_pd @a_batch_id,
                                                        @s_dls_sir_id,
                                                        @as_msg_id, 0,
                                                        @as_pl_id,
                                                        @as_gpplrt_eff,
                                                        @d_valid_error OUTPUT,
                                                        @as_pd_action OUTPUT,
                                                        @as_pd_id OUTPUT,
                                                        @as_pdcomm_eff OUTPUT;

														
                                                    IF @d_valid_error < 0
       SET @s_sub_error = 'Y';
														
                                                    ELSE
                      IF ( @as_pd_action IS NOT NULL
                       AND @as_pd_action <> ''
                                    )
                                          AND @as_pd_action = 'CA'
                                                            BEGIN
                                                             
												  EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_pd_action,
                   @as_gpplrt_eff;
                                                            END;
						
					
						--match group, plan, member
						-- changed to use same function as elig
						--Whenever dlp_mbgrpl_info_sg() is called
						-- and sub-group-plan found, also call dlp_bu_elig_subnpl().
						
                                            SET @n_count = 0;
             BEGIN --******* 
      --DECLARE @SWV_cursor_var3 CURSOR;
             IF @as_gp_id > 0
                BEGIN
                                                              EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                         @as_pl_id,
@as_member_id,
                                                              @as_gpplrt_eff,
                                                         'N',
                                                              @n_count OUTPUT,
                                                              @n_mbgrpl_id OUTPUT,
                                                              @n_group_id OUTPUT,
                                                              @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                      @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
                                                              IF @n_count > 1 --more than 1 record found
															  BEGIN
																SET @s_error_no = 240;
																RAISERROR('Sub is active in multiple Group and Plan',16,1);
																RETURN
															  END
						
                                                              IF @n_count = 1 -- moved subinplan test here where s-g-p is found
															  BEGIN
																	SET @s_error_no = 0;
																  RAISERROR('Plan Added since load began!',16,1); -- NEW
																  RETURN
															  END
						
                           IF @n_count = 0  -- Tape Type Group, Plan, Plan Eff Date
						-- Group, Plan member not found as of date
                                                              BEGIN
                                                              EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                              @as_pl_id,
                                                              @as_member_id,
                                                              @as_gpplrt_eff,
                                                              'Y',
                                                              @n_count OUTPUT,
                                                              @n_mbgrpl_id OUTPUT,
                                                              @n_group_id OUTPUT,
                                                              @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                              @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
 IF @n_count = 1
															  BEGIN
																SET @s_error_no = 135;
																  RAISERROR('Sub-Gp-PL is active in future',16,1);
																  RETURN
															  END
							
                                                        EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                              0, @as_member_id,
                                                              @as_gpplrt_eff,
                                                              'N',
                                                              @n_count OUTPUT,
                                    @n_mbgrpl_id OUTPUT,
                                                              @n_group_id OUTPUT,
  @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                        @n_eff_gr_pl OUTPUT,
             @n_exp_gr_pl OUTPUT;
             END;
						
						/* 20131028$$ks make >= 1 instead of > 1 */
                                                              IF @n_count >= 1 -- Same Group, Diff Plan (s)
                             BEGIN
                                    SELECT
                       @d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                            FROM
                                                              dbo.group_status (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                                                      AND ( group_status = 'A4' )
             AND exp_date IS NULL;
                                                             
                                                              IF @d_gp_eff_date IS NULL -- should this be a warning only ?
															  BEGIN
																SET @s_error_no = 137;
																  RAISERROR('MSG is not active',16,1);
																  RETURN
															  END
							
                                                              IF @d_gp_eff_date > @as_gpplrt_eff
															  BEGIN
																SET @s_error_no = 138;
																  RAISERROR('MSG is not active as of Sub plan eff_date',16,1);
																  RETURN
															  END
							
                                                              IF NOT EXISTS ( SELECT 'X'
															  FROM   dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                                                              AND plan_id = @as_pl_id )
															  BEGIN
																SET @s_error_no = 139;
																  RAISERROR('Missing Subscriber Group/Plan Association',16,1);
																  RETURN
															  END
							
                                                              SET @d_gppl_eff = NULL;
                                                              SET @d_gppl_exp = NULL;
															  /*
                                                              SET @SWV_cursor_var3 = CURSOR  FOR SELECT eff_date, exp_date 
                                 FROM dbo.rel_gppl (NOLOCK)
                                 WHERE group_id = @as_msg_id AND plan_id = @as_pl_id
                                 AND eff_date <= @as_gpplrt_eff
                                 AND (exp_date > @as_gpplrt_eff OR exp_date IS NULL)
                                 ORDER BY eff_date DESC,exp_date;
                                                              OPEN @SWV_cursor_var3;
                                                              FETCH NEXT FROM @SWV_cursor_var3 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                                                        WHILE @@FETCH_STATUS = 0
															  */

															  IF OBJECT_ID('tempdb..#SWV_cursor_var4') IS NOT NULL
															DROP TABLE #SWV_cursor_var4

                                                        CREATE TABLE #SWV_cursor_var4
                                                              (
                                                              id INT IDENTITY ,
                                                              eff_date DATE ,
                                                  exp_date DATE
                     );
                                                              INSERT
                                                              INTO #SWV_cursor_var4
(
                        eff_date ,
                                exp_date
                       )
                       SELECT
          eff_date ,
                                       exp_date
                                    FROM
                                dbo.rel_gppl (NOLOCK)
        WHERE
                                                              group_id = @as_msg_id
                           AND plan_id = @as_pl_id
               AND eff_date <= @as_gpplrt_eff
                                                    AND ( exp_date > @as_gpplrt_eff
              OR exp_date IS NULL
                                                              )
                                                              ORDER BY eff_date DESC ,
                                                              exp_date;

                                                              DECLARE @cur4_cnt INT ,
                                                              @cur4_i INT;
                                                              SET @cur4_i = 1;
    --Get the no. of records for the cursor
                                                              SELECT
                                                              @cur4_cnt = COUNT(1)
                                                              FROM
                                                              #SWV_cursor_var4;
                                                              WHILE ( @cur4_i <= @cur4_cnt )
                                                              BEGIN
                                                              SELECT
                                                              @d_gppl_eff = eff_date ,
                                                              @d_gppl_exp = exp_date
                                                              FROM
                                                              #SWV_cursor_var4
                                                              WHERE
                                                              id = @cur4_i;
                                                              GOTO SWL_Label14;
                                                              --FETCH NEXT FROM @SWV_cursor_var3 INTO @d_gppl_eff,@d_gppl_exp;
                                                              SET @cur4_i = @cur4_i
                                                              + 1;
                                                              END;
                                                              SWL_Label14:
                --CLOSE @SWV_cursor_var3;
                                                              IF @d_gppl_eff IS NULL
															  BEGIN
																SET @s_error_no = 45;
																  RAISERROR('No Active Group/Plan as of Subs plan effdate',16,1);
																  RETURN
															  END
							
                                                              EXECUTE dbo.dlp_plan_xfer_sg @as_member_id,
                                                              @as_gp_id,
                                                              @as_msg_id,
                   @as_pl_id,
    @as_gpplrt_eff,
                                                              @d_valid_status OUTPUT,
                  @as_hold_action OUTPUT;
                                                              IF @d_valid_status = 0
															  BEGIN
																SET @s_error_no = 200;
																  RAISERROR('Group Ins Cnt doesnt allow another PlanAdd',16,1);
																  RETURN
															  END
							
                                               IF @d_valid_status = -1
											   BEGIN
											   SET @s_error_no = 136;
												RAISERROR('Ambiguous existing records.  Don''t know which record to terminate',16,1);
												END
							
                            IF @as_hold_action = 'PC'
                                                         BEGIN
                        
                                                              IF @n_allow_pl_change = 'N'
															  BEGIN
																SET @s_error_no = 200;
																  RAISERROR('Need new error here-Gp at max plans and PC not allowed',16,1);
																   RETURN
															   END
                                                              ELSE
   SET @as_action_code = 'PC';
                                       END;
							
                                                              IF @as_action_code = 'PA'
                                                              BEGIN
                                                             
                                  IF @n_multiple_plans <> 'Y'
									-- $$20120501$$ks - Multi plans OK if diff type (D vs. V)
                                                              IF EXISTS ( SELECT
                                                              dbo.[plan].plan_id
                                                              FROM
                                                              dbo.rlmbgrpl (NOLOCK) ,
                                                              dbo.[plan] (NOLOCK)
                                                              WHERE
                                                              dbo.[plan].plan_id = dbo.rlmbgrpl.plan_id
                                                              AND exp_gr_pl IS NULL
                                                              AND dbo.rlmbgrpl.member_id = @as_member_id
                                                              AND dbo.[plan].ins_type IN (
                                                              SELECT
                                                              p2.ins_type
                                                              FROM
                                                              dbo.[plan] p2 ( NOLOCK )
                                                              WHERE
                                                              p2.plan_id = @as_pl_id ) )
                                                              BEGIN
                                                             
                                                              IF @n_allow_pl_change = 'N'
															  BEGIN
																SET @s_error_no = 200;
																  RAISERROR('Need new error here-No plan change and no multi-plans',16,1);
																  RETURN
															  END
                                                          ELSE
                                                           SET @as_action_code = 'PC';
                                                              END;
									 -- sub has active plan for ins type
                                                              END; -- no multiple plans
                                                              END; -- as_action = "PA"
                                                            END; -- if count >= 0
					 -- if as_gp_id > 0
                                                      
                                                        IF @n_ffs_plan = 0
                           BEGIN
          
                          IF @n_has_facility_id = 'Y'
                                           BEGIN
                      
                                                              IF @s_facility_id IS NULL
                                                              
                                 SET @as_fc_id = @def_fc_id;
                                                              ELSE
                BEGIN
               
																SET @as_fc_id = @s_facility_id;
     END;
							
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                          @s_dls_sir_id,
@as_fc_id,
        @as_pl_id,
        @as_gpplrt_eff,
                                                              1;

															  
                      IF @n_error_no < 0
               SET @s_sub_error = 'Y';
															  
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              SET @as_fc_id = @def_fc_id;
                                                             
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                           @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              1;

															  

                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
															  
                                                              END;
                                                            END;
					
                                                        IF @s_sub_error = 'N'
                                                            BEGIN
                                                              
                                                              IF @n_has_term_date = 'Y'
       IF @as_action_code = 'PC'
                                                              SET @s_change_dep_pc = 'Y'; --get dep to change plan
							
						                          
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
																@as_action_code,
                                                              @as_gpplrt_eff;
                                                            END;
					
                                                    END;
                                                END;  -- *****
                                        END;   --  END OF "if s_sub_error = "N""
			  --  End of "if as_action_code = "PA"" 
			
                                    IF @as_action_code = 'MU'
                          BEGIN
                                            IF @as_msg_id IS NULL
											BEGIN
											SET @s_error_no = 250;
										RAISERROR('Missing MSG record while Member Info is located',16,1);
												RETURN
											END
				
                                            IF @as_gp_id IS NULL
											BEGIN
												SET @s_error_no = 251;
                                                RAISERROR('Missing SG record while Member Info is located',16,1);
												RETURN
											END
				
           IF @as_pl_id IS NULL
											BEGIN
												SET @s_error_no = 252;
                                                RAISERROR('Missing PL record while Member Info is located',16,1);
												RETURN
											END
				
                                            IF ( @s_sub_error = 'N' )
				/** CASE 1 - TAPE RECORD ACTIVE AT DDS EFF/EXP DATES ? ** /
				/ ** Possible Action Codes: RI, ST, PA, PC, RC, FA, FX, CA, and NC **/
                 IF @as_term_date IS NULL
					/* 20131018$$ks - new_member is not "Y" if any above Action Codes
					 *	CALL dlp_check_sg_addr(a_batch_id, "Y", as_member_id)
					 */
                                 BEGIN
                                        EXECUTE dbo.dlp_check_sg_addr @a_batch_id,
  'N', @as_member_id,
                                                            @d_valid_error OUTPUT,
                                                            @as_addr_action OUTPUT;

															
                                                        IF @d_valid_error < 0
                                                            SET @s_sub_error = 'Y';
															
                                                        ELSE
   IF @as_addr_action LIKE 'G[1-7]'
                                                              ESCAPE '\'
                                                              BEGIN
                                                             
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_addr_action,
                                                              @as_gpplrt_eff;
                                                              END;
							
						                                                      
                                                        EXECUTE dbo.dlp_check_pd @a_batch_id,
                                                            @s_dls_sir_id,
                                                            @as_msg_id, 0,
                                                            @as_pl_id,
                                                            @as_gpplrt_eff,
															   @d_valid_error OUTPUT,
															 @as_pd_action OUTPUT,
                                                            @as_pd_id OUTPUT,
                                                            @as_pdcomm_eff OUTPUT;

															
                                                        IF @d_valid_error < 0
                                                            SET @s_sub_error = 'Y';
															
                                                        ELSE
                                                            IF ( @as_pd_action IS NOT NULL
                                                              AND @as_pd_action <> ''
                                                              )
                                                              AND @as_pd_action = 'CA'
  BEGIN
                                                              
                                      EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_pd_action,
                                                             @as_gpplrt_eff;
                                                          END;
							
						
						--match group, plan, member
						-- changed to use same function as elig
						--Whenever dlp_mbgrpl_info_sg() is called
						-- and sub-group-plan found, also call dlp_bu_elig_subnpl().
						
      SET @n_count = 0;
                                                        BEGIN --******* 
               DECLARE @SWV_dlp_bu_elig_subnpl SMALLINT;
															/*                                           DECLARE #SWV_cursor_var4 CURSOR;
                                                            DECLARE #SWV_cursor_var5 CURSOR;
                                                            DECLARE #SWV_cursor_var6 CURSOR;
DECLARE #SWV_cursor_var7 CURSOR;
                                                            DECLARE #SWV_cursor_var8 CURSOR;
                             DECLARE #SWV_cursor_var9 CURSOR;
                 DECLARE #SWV_cursor_var10 CURSOR;
                                   DECLARE #SWV_cursor_var11 CURSOR;
                       DECLARE #SWV_cursor_var12 CURSOR;
															*/

                                                       EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                              @as_pl_id,
                                                              @as_member_id,
                                                              @as_gpplrt_eff,
                                                              'N',
                                                              @n_count OUTPUT,
                                                              @n_mbgrpl_id OUTPUT,
                                                              @n_group_id OUTPUT,
                                                              @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                              @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;

						--BEGIN --******* moved before test for MU 
                                                            IF @n_count > 1 --more than 1 record found
															BEGIN
																SET @s_error_no = 240;
															 RAISERROR('Sub is active in multiple Group and Plan',16,1);
															 RETURN
													 END
						
                                                            IF @n_count = 1 -- moved subinplan test here where s-g-p is found
                                                              BEGIN
                                                              
                                                              EXECUTE dbo.dlp_bu_elig_subnpl @n_count,
                                                              @t_sub_in_plan,
                                                           @n_sub_in_plan,
                                                              @a_batch_id,
                                                              @i_sp_id,
                                                              @i_sir_def_id,
                                                              @s_dls_sub_sir_id,
                                                              @SWV_dlp_bu_elig_subnpl OUTPUT;
                                                              SET @t_sub_in_plan = @SWV_dlp_bu_elig_subnpl ;
                                                             
						-- 1 match found for the given group, plan, member in rlmbgrpl
						-- Plan found -- cannot PA, PC
						-- Possible actions are FA, FX
                                                              IF @n_exp_gr_pl IS NOT NULL
															  BEGIN 
															  SET @s_error_no = 134;
													--Cannot RI as of as_gpplrt_eff, as sub exp is in future.
													  RAISERROR('Subscriber is expired in DataDental',16,1);
													  END
                                                              ELSE
      BEGIN

															  /*
                                                 SET #SWV_cursor_var4 = CURSOR  FOR SELECT rate_code, eff_rt_date 
                                    FROM dbo.rlmbrt (NOLOCK)
                                    WHERE mb_gr_pl_id = @n_mbgrpl_id AND exp_rt_date IS NULL
                                 ORDER BY 2 DESC;
                                                      OPEN #SWV_cursor_var4;
                                                              FETCH NEXT FROM #SWV_cursor_var4 INTO @n_rate_code,
        @n_eff_rt_date;
                                                              WHILE @@FETCH_STATUS = 0
															  */
															  IF OBJECT_ID('tempdb..#SWV_cursor_var5') IS NOT NULL
																DROP TABLE #SWV_cursor_var5

                                             CREATE TABLE #SWV_cursor_var5 
                        (
         id INT IDENTITY ,
           rate_code CHAR(2) ,
                                                              eff_rt_date DATE
                 );
             INSERT
                                                              INTO #SWV_cursor_var5
                           (
                                                              rate_code ,
                                                              eff_rt_date
                                                              )
                             SELECT
                                                              rate_code ,
                                                              eff_rt_date
                                                              FROM
                                                              dbo.rlmbrt (NOLOCK)
                                                              WHERE
                                                              mb_gr_pl_id = @n_mbgrpl_id
                                                              AND exp_rt_date IS NULL
                                                              ORDER BY 2 DESC;

   DECLARE @cur5_cnt INT ,
                                 @cur5_i INT;
                                                              SET @cur5_i = 1;
    --Get the no. of records for the cursor
                                                              SELECT
                                                              @cur5_cnt = COUNT(1)
  FROM
                                                              #SWV_cursor_var5;
                                                              WHILE ( @cur5_i <= @cur5_cnt )
                                                              BEGIN
                                                              SELECT
                                                              @n_rate_code = rate_code ,
                                                              @n_eff_rt_date = eff_rt_date
                                                              FROM
                                           #SWV_cursor_var5
                                                       WHERE
                                                              id = @cur5_i;
                                                              GOTO SWL_Label15;
                                                              --FETCH NEXT FROM #SWV_cursor_var4 INTO @n_rate_code,@n_eff_rt_date;
   SET @cur5_i = @cur5_i
                                                              + 1;
                                                              END;
                SWL_Label15:
                                                              --CLOSE #SWV_cursor_var4;
                                                              IF ( @n_rate_code IS NULL
                                                           
                                    )
                                             OR @n_eff_rt_date IS NULL
															  BEGIN
																SET @s_error_no = 614;
																  RAISERROR('Sub has no active rate code',16,1);
																  RETURN
															  END
                                                              ELSE
                                                              BEGIN
                                   
                      IF ( @s_rate_code IS NOT NULL
            AND @s_rate_code <> ''
                                                              )
                                                              AND @n_rate_code <> @s_rate_code
BEGIN
                                                              
                                                              SET @n_rate_code = @s_rate_code;
        END;
                                                              END;
								
    SET @n_facility_id = NULL;
            SET @d_fc_exp = NULL;
                                                   SET @d_fc_eff = NULL;

															  /*
                                                              SET #SWV_cursor_var5 = CURSOR  FOR SELECT facility_id, eff_date, exp_date
								   
                                    FROM dbo.rlplfc (NOLOCK)
                                    WHERE mb_gr_pl_id = @n_mbgrpl_id AND member_id = @as_member_id
                                    AND (eff_date <= @as_fc_eff AND exp_date IS NULL)
                             ORDER BY eff_date DESC,exp_date;
                                                              OPEN #SWV_cursor_var5;
                                                              FETCH NEXT FROM #SWV_cursor_var5 INTO @n_facility_id,
                     @d_fc_eff,
                                                              @d_fc_exp;
                                                              WHILE @@FETCH_STATUS = 0
															  */
																IF OBJECT_ID('tempdb..#SWV_cursor_var6') IS NOT NULL
																DROP TABLE #SWV_cursor_var6

                                                              CREATE TABLE #SWV_cursor_var6 
                                                              (
                                                              id INT IDENTITY ,
                                                              facility_id INT ,
                                                              eff_date DATE ,
                                                            exp_date DATE
                                                              );
                                                              INSERT
                                                              INTO #SWV_cursor_var6
                                                              (
                                                       facility_id ,
              eff_date ,
                                                              exp_date 
                                                              )
                                                              SELECT
          facility_id ,
                                                              eff_date ,
                  exp_date
                                                   FROM
                     dbo.rlplfc (NOLOCK)
                                                              WHERE
                                                              mb_gr_pl_id = @n_mbgrpl_id
                                AND member_id = @as_member_id
                                                              AND ( eff_date <= @as_fc_eff
    AND exp_date IS NULL
                                                              )
                   ORDER BY eff_date DESC ,
                 exp_date;
                                                              DECLARE @cur6_cnt INT ,
                                                      @cur6_i INT;
                   SET @cur6_i = 1;
    --Get the no. of records for the cursor
                                                              SELECT
                             @cur6_cnt = COUNT(1)
                                                              FROM
                                                   #SWV_cursor_var6;
                       WHILE ( @cur6_i <= @cur6_cnt )
                                 BEGIN
                                              SELECT
                                                              @n_facility_id = facility_id ,
              @d_fc_eff = eff_date ,
      @d_fc_exp = exp_date
                                                              FROM
                                                              #SWV_cursor_var6
                                                              WHERE
             id = @cur6_i;
                      GOTO SWL_Label16;
															  /*                                                              
															  FETCH NEXT FROM #SWV_cursor_var5 INTO @n_facility_id,
                                                              @d_fc_eff,
             @d_fc_exp;
															  */
                                                              SET @cur6_i = @cur6_i
                                                              + 1;
          END;
                                                              SWL_Label16:
                                                              --CLOSE #SWV_cursor_var5;
                                                              IF @d_fc_eff IS NULL
															  BEGIN
																SET @s_error_no = 615;
																  RAISERROR('Sub missing active facility record',16,1);
																  RETURN
															  END
								
             
                                                              IF @n_ffs_plan = 0
                                                              BEGIN
                                                              
                                IF @n_has_facility_id = 'Y'
                  BEGIN
                                                              
                                                              IF @s_facility_id IS NOT NULL
        BEGIN
                                                             
                                                              IF ( @s_facility_id IS NULL
                                                              OR @s_facility_id = 0
                                                              )
                                                              BEGIN
                   SET @s_facility_id =@n_facility_id;
                                   
                                                              END;
											
                                                       
                                                              IF @n_facility_id != @s_facility_id
                                                              BEGIN
                                                  
                                                              SET @as_fc_id = @s_facility_id;
                                                             
                                               
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                        @s_dls_sir_id,
                                       @s_facility_id,
             @as_pl_id,
                                           @as_fc_eff, 1;

															  
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
															 
                                                              ELSE
                                                              BEGIN
                                              
												   -- CH001
                                                              SET @as_fc_eff = CAST(@s_mb_fc_eff_date AS DATE);
                                           
                                         IF @n_allow_fc_change = 'Y'
                                                              SET @as_action_code = 'FX';
													
                                                             
  EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
        @as_fc_eff;
                                                              END;
      END;
                                                              ELSE
                       SET @as_fc_id = @n_facility_id;
                                                              END;
                                                              ELSE
                                                              SET @as_fc_id = @n_facility_id;
   END;
                                                              ELSE
                                                              SET @as_fc_id = @n_facility_id;
									
                       IF @s_sub_error = 'N'
    AND ( @as_action_code IS NULL
        )
                                                              BEGIN
                                                              SET @as_action_code = 'MU';
                                                             
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
              @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_fc_eff;
                                                              END;
                                                              END;
                                                              END;  -- END IF of "IF n_ffs_plan = 0 THEN"
           END; -- mb_gr_pl is not null
						  -- END IF of "IF n_count = 1 THEN"
						
                                         IF @n_count = 0  -- Tape Type Group, Plan, Plan Eff Date
						-- Group, Plan member not found as of date
                                                              BEGIN
                                                              EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
     @as_pl_id,
                                                              @as_member_id,
                                                              @as_gpplrt_eff,
                                                              'Y',
                      @n_count OUTPUT,
                                                              @n_mbgrpl_id OUTPUT,
                                                              @n_group_id OUTPUT,
                                                 @n_plan_id OUTPUT,
                                                           @n_sub_in_plan OUTPUT,
          @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
                                                              IF @n_count = 1
															  BEGIN
																SET @s_error_no = 135;
																  RAISERROR('Subscriber is active in future',16,1);
																  RETURN
															  END
							
                                                              EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                              0, @as_member_id,
                                                              @as_gpplrt_eff,
                                                              'N',
                @n_count OUTPUT,
                                                              @n_mbgrpl_id OUTPUT,
                                                            @n_group_id OUTPUT,
 @n_plan_id OUTPUT,
                                                  @n_sub_in_plan OUTPUT,
                    @n_eff_gr_pl OUTPUT,
            @n_exp_gr_pl OUTPUT;
                                      IF @n_count = 0  -- Same Group, Diff Plan (NOT FOUND)
                                                              BEGIN
                                                              EXECUTE dbo.dlp_mbgrpl_info_sg 0,
                        0, @as_member_id,
                          @as_gpplrt_eff,
                                                              'N',
                                        @n_count_gp OUTPUT,
                                       @n_mbgrpl_id OUTPUT,
                                           @n_group_id OUTPUT,
           @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                              @n_eff_gr_pl OUTPUT,
                                                              @n_exp_gr_pl OUTPUT;
                                                              IF @n_count_gp = 0 -- Diff Group , Diff Plan not found
                            BEGIN
                                                              EXECUTE dbo.dlp_mbgrpl_info_sg 0,
                                                              0, @as_member_id,
                                                              @as_gpplrt_eff,
                                                              'Y',
                             @n_count_future OUTPUT,
                                                              @n_mbgrpl_id OUTPUT,
                                               @n_group_id OUTPUT,
   @n_plan_id OUTPUT,
                                                              @n_sub_in_plan OUTPUT,
                                                              @n_eff_gr_pl OUTPUT,
                                                     @n_exp_gr_pl OUTPUT;
                                                              IF @n_count_future = 0
									-- should be left with exp_gr_pl < as of date
                                 BEGIN
                                                              IF EXISTS ( SELECT
                                                              *
                                                              FROM
      dbo.rlmbgrpl (NOLOCK)
                                                              WHERE
                                                              group_id = @as_gp_id
                                                              AND plan_id = @as_pl_id
                                                       AND member_id = @as_member_id )
                   SET @as_action_code = 'RI';
										
                                       SELECT
                                            @d_gp_eff_date = eff_date ,
                                                              @d_gp_exp_date = exp_date
                                                              FROM
                                                              dbo.group_status (NOLOCK)
                                               WHERE
                                                              group_id = @as_msg_id
                                                              AND group_status = 'A4'
                                                              AND exp_date IS NULL;
                                                             
                           IF @d_gp_eff_date IS NULL
															  BEGIN
																SET @s_error_no = 137;
																  RAISERROR('Group is not active',16,1);
																  RETURN
															  END
										
                  IF @d_gp_eff_date > @as_gpplrt_eff
															  BEGIN
																SET @s_error_no = 138;
																  RAISERROR('Grp not active as of Sub plan effdate',16,1);
																  RETURN
															  END
										
                                                      IF NOT EXISTS ( SELECT
                                                *
                                                              FROM
                           dbo.rel_gppl (NOLOCK)
                                                        WHERE
                       group_id = @as_msg_id
                 AND plan_id = @as_pl_id )
															  BEGIN
																SET @s_error_no = 139;
																  RAISERROR('Missing SubGroup/Plan Association',16,1);
																  RETURN
															  END
										
    SET @d_gppl_eff = NULL;
                                                              SET @d_gppl_exp = NULL;

															  /*
                          SET #SWV_cursor_var6 = CURSOR  FOR SELECT eff_date, exp_date 
                                          FROM dbo.rel_gppl (NOLOCK)
                                          WHERE group_id = @as_msg_id AND plan_id = @as_pl_id
                                          AND eff_date <= @as_gpplrt_eff
             AND (exp_date > @as_gpplrt_eff OR exp_date IS NULL)
                                          ORDER BY eff_date DESC,exp_date;
                                                              OPEN #SWV_cursor_var6;
                                                              FETCH NEXT FROM #SWV_cursor_var6 INTO @d_gppl_eff,
                                                        @d_gppl_exp;
                                                              WHILE @@FETCH_STATUS = 0
															  */
															  IF OBJECT_ID('tempdb..#SWV_cursor_var7 ') IS NOT NULL
															DROP TABLE #SWV_cursor_var7 

													CREATE TABLE #SWV_cursor_var7 
                                                              (
                                                              id INT IDENTITY ,
                                                              eff_date DATE ,
                                                              exp_date DATE
                                                              );
                                                              INSERT
                                                              INTO #SWV_cursor_var7
                                                              (
                                                              eff_date ,
                                                              exp_date 
)
                                                              SELECT
                  eff_date ,
                                                              exp_date
     FROM
                                                     dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                                                              AND plan_id = @as_pl_id
               AND eff_date <= @as_gpplrt_eff
                     AND ( exp_date > @as_gpplrt_eff
                                                              OR exp_date IS NULL
                )
                                                              ORDER BY eff_date DESC ,
                             exp_date;

                                                DECLARE @cur7_cnt INT ,
                                 @cur7_i INT;
                                                              SET @cur7_i = 1;
    --Get the no. of records for the cursor
                                                              SELECT
                                     @cur7_cnt = COUNT(1)
                    FROM
                                 #SWV_cursor_var7;
   WHILE ( @cur7_i <= @cur7_cnt )
            BEGIN
                                                    SELECT
           @d_gppl_eff = eff_date ,
               @d_gppl_exp = exp_date
                                                              FROM
                                                              #SWV_cursor_var7
                                                              WHERE
        id = @cur7_i;
                                                              GOTO SWL_Label17;
															  /*
                                                              FETCH NEXT FROM #SWV_cursor_var6 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
															  */
                                              SET @cur7_i = @cur7_i
                                                              + 1;
                                                              END;
                                                              SWL_Label17:
                                                      --CLOSE #SWV_cursor_var6;
        IF @d_gppl_eff IS NULL
															  BEGIN
																SET @s_error_no = 45;
																  RAISERROR('No Active Gp/Plan for Sub-plan effdt',16,1);
																  RETURN
															  END
										
                                                              SET @n_mbgrpl_id = NULL;
                                                              SET @n_eff_gr_pl = NULL;

															  /*
                                                              SET #SWV_cursor_var7 = CURSOR  FOR SELECT mb_gr_pl_id, eff_gr_pl, exp_gr_pl
											
                                          FROM dbo.rlmbgrpl (NOLOCK)
                                   WHERE member_id = @as_member_id AND group_id = @as_gp_id
                                          AND plan_id = @as_pl_id
                                          ORDER BY eff_gr_pl DESC;
                                                      OPEN #SWV_cursor_var7;
                                                              FETCH NEXT FROM #SWV_cursor_var7 INTO @n_mbgrpl_id,
                                                              @n_eff_gr_pl,
                                                @n_exp_gr_pl;
                           WHILE @@FETCH_STATUS = 0
															  */
															  IF OBJECT_ID('tempdb..#SWV_cursor_var8') IS NOT NULL
																DROP TABLE #SWV_cursor_var8

                                                              CREATE TABLE #SWV_cursor_var8 
																(
                                                              id INT IDENTITY ,
                                                              mb_gr_pl_id INT ,
                                                              eff_gr_pl DATE ,
                       exp_gr_pl DATE
                                                              );
                                                              INSERT
                                          INTO #SWV_cursor_var8
                 (
                                                              mb_gr_pl_id ,
                                                           eff_gr_pl ,
                                                              exp_gr_pl
        )
                                                              SELECT
                                                              mb_gr_pl_id ,
                                               eff_gr_pl ,
                    exp_gr_pl
                                                              FROM
                                                              dbo.rlmbgrpl (NOLOCK)
                                                WHERE
    member_id = @as_member_id
                                                              AND group_id = @as_gp_id
                               AND plan_id = @as_pl_id
                                   ORDER BY eff_gr_pl DESC;

                                                              DECLARE @cur8_cnt INT ,
                                                          @cur8_i INT;
                                                              SET @cur8_i = 1;
    --Get the no. of records for the cursor
           SELECT
                                                              @cur8_cnt = COUNT(1)
                                                              FROM
                                                              #SWV_cursor_var8;
                                         WHILE ( @cur8_i <= @cur8_cnt )
                                                              BEGIN
         SELECT
                                                              @n_mbgrpl_id = mb_gr_pl_id ,
                       @n_eff_gr_pl = eff_gr_pl ,
                                                              @n_exp_gr_pl = exp_gr_pl
                                                              FROM
                                                              #SWV_cursor_var8
                                                WHERE
                                                              id = @cur8_i;

                                                              GOTO SWL_Label18;
															  /*
         FETCH NEXT FROM #SWV_cursor_var7 INTO @n_mbgrpl_id,
                                                              @n_eff_gr_pl,
                                                              @n_exp_gr_pl;
															  */
                                                              SET @cur8_i = @cur8_i
                    + 1;
                                                              END;
     SWL_Label18:
                                                              --CLOSE #SWV_cursor_var7;
                                                              IF @n_mbgrpl_id IS NOT NULL
                             BEGIN
                                                              SET @n_facility_id = NULL;
                                     SET @n_eff_date = NULL;

															  /*
                                                              SET #SWV_cursor_var8 = CURSOR  FOR SELECT facility_id, eff_date 
                                             FROM dbo.rlplfc (NOLOCK)
                                             WHERE member_id = @as_member_id AND mb_gr_pl_id = @n_mbgrpl_id
                                             ORDER BY eff_date DESC;
                                                              OPEN #SWV_cursor_var8;
                                    FETCH NEXT FROM #SWV_cursor_var8 INTO @n_facility_id,
                                                              @n_eff_date;
                                              WHILE @@FETCH_STATUS = 0
															  */
															  IF OBJECT_ID('tempdb..#SWV_cursor_var9') IS NOT NULL
															DROP TABLE #SWV_cursor_var9

                                                      CREATE TABLE #SWV_cursor_var9
                    (
                                   id INT IDENTITY ,
                                                              facility_id INT ,
                                                              eff_date DATE
                                                              );
                                    INSERT
                                                              INTO #SWV_cursor_var9
         (
                   facility_id ,
                                                              eff_date 
                                                              )
                                                    SELECT
                                                    facility_id ,
         eff_date
                                                         FROM
                                                              dbo.rlplfc (NOLOCK)
                                                              WHERE
            member_id = @as_member_id
                                                              AND mb_gr_pl_id = @n_mbgrpl_id
                                                              ORDER BY eff_date DESC;

                                                              DECLARE @cur9_cnt INT ,
                                          @cur9_i INT;
                  SET @cur9_i = 1;
    --Get the no. of records for the cursor
                                                              SELECT
       @cur9_cnt = COUNT(1)
                                                              FROM
                                    #SWV_cursor_var9;
                                                              WHILE ( @cur9_i <= @cur9_cnt )
                                                              BEGIN
                                                              SELECT
                                   @n_facility_id = facility_id ,
                                                              @n_eff_date = eff_date
                                                              FROM
                                                              #SWV_cursor_var9
                                           WHERE
                      id = @cur9_i;
                                                              GOTO SWL_Label19;
															  /*
                                                              FETCH NEXT FROM #SWV_cursor_var8 INTO @n_facility_id,
                                                              @n_eff_date;
															  */
 SET @cur9_i = @cur9_i
                                                              + 1;
 END;
                                                              SWL_Label19:
                                                              --CLOSE #SWV_cursor_var8;
                                      IF @n_facility_id IS NOT NULL
                                                              SET @as_fc_id = @n_facility_id;
              END;
										
                                                              
                                                              IF @n_ffs_plan = 0
                                                       BEGIN
                                                              
              IF @n_has_facility_id = 'Y'
                                                  BEGIN
                                                              
                                                              IF @s_facility_id IS NULL
                                                              OR @s_facility_id = 0
                                        IF @as_fc_id IS NULL
                                            OR @as_fc_id = 0
                                                              BEGIN
                                                              SET @as_fc_id = @def_fc_id;
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                            @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                      1;

															  
              IF @n_error_no < 0
       SET @s_sub_error = 'Y';
															  
                                                              END;
                                                              ELSE
                                                              BEGIN
                                             
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                                  @as_gpplrt_eff,
    0;
  IF @n_error_no < 0
                                                              BEGIN
                                                              
                  EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
       1;

															  
                                                              IF @n_error_no < 1
                                                              SET @s_sub_error = 'Y';
															  
                                                              ELSE
                                                              SET @as_fc_id = @def_fc_id;
                           END;
                                                     END;
													
                                                       ELSE
                                                              BEGIN
                                                             
      SET @as_fc_id = @s_facility_id;
               
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
															  @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
																1;

																

                                                              IF @n_error_no < 1
                           SET @s_sub_error = 'Y';
															 
                                                              END;
                                                              END;
                                                              ELSE
                                                   BEGIN
                                                              IF @as_fc_id IS NOT NULL
                                                              BEGIN
                                    
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                                              @as_pl_id,
                                           @as_gpplrt_eff,
                                                             0;
                                                              END;
                                                              ELSE
                                                              SET @n_error_no = -1;
												
                                         IF @n_error_no < 0
                                                              BEGIN
                                 SET @as_fc_id = @def_fc_id;
                                                              
      EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                                               @as_pl_id,
                                                              @as_gpplrt_eff,
                     1;

															  
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
															 
                           END;
                                                   END;
                                                              END;  -- end of "IF n_has_facility_id= "Y" THEN"
                                                              ELSE
                             SET @as_fc_id = NULL;
										  -- end of "IF n_ffs_plan = 0 THEN"
      IF @s_sub_error = 'N'
                                                              BEGIN
                                                             
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
                    @as_gpplrt_eff;
                                                              END;
                                            END;
         END;  -- end of "IF n_count_future = 0 THEN"
                                                              END; -- end of n_count_gp = 0 THEN
							 --Same Group, Diff Plan (NOT FOUND)
                           IF @n_count > 1 -- Same Group, Diff Plan (>1 FOUND)
                                                              BEGIN
            SELECT
                                                              @d_gp_eff_date = eff_date ,
           @d_gp_exp_date = exp_date
                                                              FROM
                                                              dbo.group_status (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                    AND group_status = 'A4'
                                                              AND exp_date IS NULL;
                                                             
                                                              IF @d_gp_eff_date IS NULL
															  BEGIN
																SET @s_error_no = 137;
																  RAISERROR('Group is not active',16,1);
																  RETURN
															  END
								
                                                              IF @d_gp_eff_date > @as_gpplrt_eff
															  BEGIN
																SET @s_error_no = 138;
																  RAISERROR('Group is not active as of Sub plan eff_date',16,1);
																  RETURN
															  END
								
                                                              IF NOT EXISTS ( SELECT
                                                              *
                                                              FROM
													dbo.rel_gppl (NOLOCK)
                   WHERE
                                                              group_id = @as_msg_id
                                                              AND plan_id = @as_pl_id )
															  BEGIN
																SET @s_error_no = 139;
																  RAISERROR('Missing Subscriber Group/Plan Association',16,1);
																  RETURN
															  END
								
                            SET @d_gppl_eff = NULL;
                                                              SET @d_gppl_exp = NULL;

															  /*
                                                              SET #SWV_cursor_var9 = CURSOR  FOR SELECT eff_date, exp_date 
                                    FROM dbo.rel_gppl (NOLOCK)
                                    WHERE group_id = @as_msg_id AND plan_id = @as_pl_id
                AND eff_date <= @as_gpplrt_eff
                             AND (exp_date > @as_gpplrt_eff OR exp_date IS NULL)
                            ORDER BY eff_date DESC,exp_date;
                                                      OPEN #SWV_cursor_var9;
                                    FETCH NEXT FROM #SWV_cursor_var9 INTO @d_gppl_eff,
                                                         @d_gppl_exp;
                                                              WHILE @@FETCH_STATUS = 0
															  */
																IF OBJECT_ID('tempdb..#SWV_cursor_var10') IS NOT NULL
																	DROP TABLE #SWV_cursor_var10

                                                              CREATE TABLE #SWV_cursor_var10 
                              (
                      id INT IDENTITY ,
                                                              eff_date DATE ,
                                                              exp_date DATE
                                                 );
                                                              INSERT
                                                              INTO #SWV_cursor_var10
                                                              (
                     eff_date ,
                                                              exp_date 
                                                              )
                                                              SELECT
            eff_date ,
                                        exp_date
                                   FROM
                                                              dbo.rel_gppl (NOLOCK)
     WHERE
                                                              group_id = @as_msg_id
                                                              AND plan_id = @as_pl_id
                                                              AND eff_date <= @as_gpplrt_eff
                                                              AND ( exp_date > @as_gpplrt_eff
                                                              OR exp_date IS NULL
                                                       )
                                                              ORDER BY eff_date DESC ,
                                                              exp_date;
                                                              DECLARE @cur10_cnt INT ,
                                                              @cur10_i INT;
        SET @cur10_i = 1;
    --Get the no. of records for the cursor
                            SELECT
                                                              @cur10_cnt = COUNT(1)
FROM
                  #SWV_cursor_var10;
                                                              WHILE ( @cur10_i <= @cur10_cnt )
                                                              BEGIN
                                                              SELECT
                                                              @d_gppl_eff = eff_date ,
                                                   @d_gppl_exp = exp_date
                                                              FROM
                                                              #SWV_cursor_var10
                                         WHERE
                                                      id = @cur10_i;

                                  GOTO SWL_Label20;
															  /*
                                FETCH NEXT FROM #SWV_cursor_var9 INTO @d_gppl_eff,
                     @d_gppl_exp;
															  */
                                                              SET @cur10_i = @cur10_i
                                                 + 1;
                                                              END;
             SWL_Label20:
                                                              --CLOSE #SWV_cursor_var9;
                 IF @d_gppl_eff IS NULL
															  BEGIN
																SET @s_error_no = 45;
																  RAISERROR('No Active Group/Plan as of Subs plan effdate',16,1);
																  RETURN
															  END
								
                                                              EXECUTE dbo.dlp_plan_xfer_sg @as_member_id,
            @as_gp_id,
  @as_msg_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              @d_valid_status OUTPUT,
                                          @as_action_code OUTPUT;
                                                              IF @d_valid_status = 0
															  BEGIN
															  SET @s_error_no = 200;
                             RAISERROR('Group Ins Cnt doesnt allow another PlanAdd',16,1);
															  RETURN
															  END
								
                                                              IF @d_valid_status = -1
															  BEGIN
																SET @s_error_no = 136;
																  RAISERROR('Ambiguous existing records.  Don''t know which record to terminate',16,1);
																  RETURN
															  END
								
                                                             
           IF @n_ffs_plan = 0
                 BEGIN
                                          
                                                              IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                                            
                                                              IF @s_facility_id IS NULL
                                            OR @s_facility_id = 0
                                      SET @as_fc_id = @def_fc_id;
        ELSE
                                                              BEGIN
                                                              
                                       SET @as_fc_id = @s_facility_id;
                                                              END;
										
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
															  @as_fc_id,
                        @as_pl_id,
                                                              @as_gpplrt_eff,
															  1;
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
															
                                                              END;
                                                              ELSE
           BEGIN
      SET @as_fc_id = @def_fc_id;
                                                              
           EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
            @as_fc_id,
 @as_pl_id,
                                                              @as_gpplrt_eff,
                                                 1;
                             IF @n_error_no < 0
                   SET @s_sub_error = 'Y';
															 
                                                              END;
                                                              END;
								
                                                              IF @s_sub_error = 'N'
                                                         BEGIN
                                                IF @as_action_code = 'PA'
                                                              BEGIN
                                                              
                                                              IF @n_multiple_plans <> 'Y'
										-- $$20120501$$ks - Multi plans OK if diff type (D vs. V)
    IF EXISTS ( SELECT
           dbo.[plan].plan_id
                                                              FROM
                         dbo.rlmbgrpl (NOLOCK) ,
                                                              dbo.[plan] (NOLOCK)
       WHERE
                                                              dbo.[plan].plan_id = dbo.rlmbgrpl.plan_id
                                                              AND exp_gr_pl IS NULL
                                       AND dbo.rlmbgrpl.member_id = @as_member_id
     AND dbo.[plan].ins_type IN (
                                              SELECT
                                                              p2.ins_type
                                                              FROM
                                                              dbo.[plan] p2 ( NOLOCK )
                                                        WHERE
                                                              p2.plan_id = @as_pl_id ) )
 SET @as_action_code = 'PC';
											
										
										/* 20131114$$in case previous record in batch termed group
										 */
                                                             
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              'GR',
                                                              @as_gpplrt_eff;
                                          END;
									
                                                            
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_action_code,
        @as_gpplrt_eff;
                                                              END;
              END;
							  -- END OF "IF n_count > 1 THEN"

                                                              IF @n_count = 1 --Same Group, Diff Plan (1 FOUND)
                                                              BEGIN
                                                              IF @n_eff_gr_pl > @as_gpplrt_eff
															  BEGIN
																SET @s_error_no = 605;
																  RAISERROR('Current Existing Plan is eff in the future',16,1);
																  RETURN
															  END
								
                                              IF @n_exp_gr_pl IS NOT NULL
                                               BEGIN
                                                              IF @n_exp_gr_pl > @as_gpplrt_eff
															  BEGIN
																SET @s_error_no = 606;
																  RAISERROR('Existing Plan expired after plan effdate',16,1);
																  RETURN
															  END
									
                                                              SET @as_action_code = 'RI';
               END;
                                                              ELSE
                         BEGIN
                           SET @as_action_code = 'PA';
                                                              
                                                              IF @n_multiple_plans <> 'Y'
									-- $$20120501$$ks - Multi plans OK if diff type (D vs. V)
                                                              IF EXISTS ( SELECT
                  dbo.[plan].plan_id
                                   FROM
 dbo.rlmbgrpl (NOLOCK) ,
dbo.[plan] (NOLOCK)
                                   WHERE
                                                              dbo.[plan].plan_id = dbo.rlmbgrpl.plan_id
                                                       AND exp_gr_pl IS NULL
                               AND dbo.rlmbgrpl.member_id = @as_member_id
                                                              AND dbo.[plan].ins_type IN (
                                                              SELECT
                                                              p2.ins_type
                            FROM
                                                              dbo.[plan] p2 ( NOLOCK )
             WHERE
                                                              p2.plan_id = @as_pl_id ) )
                                                              SET @as_action_code = 'PC';
										
                            END;
								
								/* Note: if msg group.dental_count is null then system 
								 *  assumes groups are only allowed 1 plan
								 *  if count = 1 and group has plan then must be PC
								 *  if count = 1 and group has multiple plans then error
								 */
                                                              IF @as_action_code = 'PA'
								-- need to verify you are allowed multiplans
                                                              BEGIN
                                                              EXECUTE dbo.dlp_plan_xfer_sg @as_member_id,
                                                              @as_gp_id,
@as_msg_id,
                                                              @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              @d_valid_status OUTPUT,
                                                              @as_action_code OUTPUT;
                                                              IF @d_valid_status = 0
															  BEGIN
																SET @s_error_no = 200;
																  RAISERROR('Grp Ins Cnt does not allow another Plan Add',16,1);
																  RETURN
															  END
									
                                                              IF @d_valid_status = -1
															  BEGIN
																SET @s_error_no = 136;
																  RAISERROR('Ambiguous existing records.  Don''t know which record to terminate',16,1);
																  RETURN
															  END

                                 END;
								
                                                              SELECT
                                                              @d_gp_eff_date = eff_date ,
    @d_gp_exp_date = exp_date
                                                              FROM
             dbo.group_status (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                            AND group_status = 'A4'
                                                              AND exp_date IS NULL;
                                         
                                                        IF @d_gp_eff_date IS NULL
															  BEGIN
																SET @s_error_no = 137;
																  RAISERROR('Group is not active',16,1);
																  RETURN
															  END
								
                                                              IF @d_gp_eff_date > @as_gpplrt_eff
															  BEGIN
																SET @s_error_no = 138;
																  RAISERROR('Group is not active as of Sub plan eff_date',16,1);
																  RETURN
															  END
								
                                                              IF NOT EXISTS ( SELECT 'X'
   FROM
                                                              dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                                                              AND plan_id = @as_pl_id )
															  BEGIN
																SET @s_error_no = 139;
																  RAISERROR('Missing Subscriber Group/Plan Association',16,1);
																  RETURN
															  END
								
                                       SET @d_gppl_eff = NULL;
                                          SET @d_gppl_exp = NULL;

															  /*
SET #SWV_cursor_var10 = CURSOR  FOR SELECT eff_date, exp_date  FROM dbo.rel_gppl (NOLOCK)
   WHERE group_id = @as_msg_id AND plan_id = @as_pl_id
                                    AND eff_date <= @as_gpplrt_eff
                                    AND (exp_date > @as_gpplrt_eff OR exp_date IS NULL)
                                    ORDER BY eff_date DESC,exp_date;
                                                              OPEN #SWV_cursor_var10;
                                                              FETCH NEXT FROM #SWV_cursor_var10 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
                                                              WHILE @@FETCH_STATUS = 0
															  */

															  IF OBJECT_ID('tempdb..#SWV_cursor_var11') IS NOT NULL
																DROP TABLE #SWV_cursor_var11

                                                              CREATE TABLE #SWV_cursor_var11
                                                              (
                                 id INT IDENTITY ,
                                  eff_date DATE ,
																exp_date DATE
                                                              );
                                                              INSERT
                                                              INTO #SWV_cursor_var11
                                                              (
                                                              eff_date ,
                 exp_date 
                                                              )
                                                              SELECT
              eff_date ,
                  exp_date
                                                              FROM
                                           dbo.rel_gppl (NOLOCK)
                                                              WHERE
                                                              group_id = @as_msg_id
                                                              AND plan_id = @as_pl_id
                                       AND eff_date <= @as_gpplrt_eff
                                                              AND ( exp_date > @as_gpplrt_eff
                                          OR exp_date IS NULL
                                                              )
                                                              ORDER BY eff_date DESC ,
                                                              exp_date;
DECLARE @cur11_cnt INT ,
                                                              @cur11_i INT;
                                                              SET @cur11_i = 1;
    --Get the no. of records for the cursor
   SELECT
                                                     @cur11_cnt = COUNT(1)
    FROM
                                                              #SWV_cursor_var11;
                                                              WHILE ( @cur11_i <= @cur11_cnt )
                                                              BEGIN
                                  SELECT
                                                              @d_gppl_eff = eff_date ,
                                                              @d_gppl_exp = exp_date
                                                              FROM
                                                              #SWV_cursor_var11
                                                          WHERE
                                                              id = @cur11_i;
                                     GOTO SWL_Label21;
															  /*
     FETCH NEXT FROM #SWV_cursor_var10 INTO @d_gppl_eff,
                                                              @d_gppl_exp;
															  */
                                                              SET @cur11_i = @cur11_i
                                                              + 1;
                                                END;
                          SWL_Label21:
                                                          --CLOSE #SWV_cursor_var10;
                                                              IF @d_gppl_eff IS NULL
															  BEGIN
																SET @s_error_no = 45;
																  RAISERROR('No Active Group/Plan as of Subs plan effdate',16,1);
																  RETURN
															  END
								
                                                              
                                                              IF @n_ffs_plan = 0
BEGIN
                                                              
                                                              IF @n_has_facility_id = 'Y'
                                                              BEGIN
                                                      
                                                              IF @s_facility_id IS NULL
                                                              OR @s_facility_id = 0
                                                              BEGIN

															  /*
                                                              SET #SWV_cursor_var11 = CURSOR  FOR SELECT eff_date, exp_date, facility_id
												
                          FROM dbo.rlplfc (NOLOCK)
                       WHERE member_id = @as_member_id AND mb_gr_pl_id = @n_mbgrpl_id
                                         ORDER BY eff_date DESC,exp_date;
                                                              OPEN #SWV_cursor_var11;
                                                              FETCH NEXT FROM #SWV_cursor_var11 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                              @as_fc_id;
                                          WHILE @@FETCH_STATUS = 0
															  */
										IF OBJECT_ID('tempdb..#SWV_cursor_var12') IS NOT NULL
									DROP TABLE #SWV_cursor_var12

                                  CREATE TABLE #SWV_cursor_var12
                                                              (
                                              id INT IDENTITY ,
                                                              eff_date DATE ,
                                                              exp_date DATE ,
    facility_id INT
                                                              );
                                                 INSERT
                                           INTO #SWV_cursor_var12
           (
                                                              eff_date ,
                                                              exp_date ,
                                                              facility_id
                                                              )
                            SELECT
                                                              eff_date ,
                                                              exp_date ,
                                         facility_id
                                                FROM
                                          dbo.rlplfc (NOLOCK)
                                                              WHERE
                                                              member_id = @as_member_id
                                                              AND mb_gr_pl_id = @n_mbgrpl_id
                                 ORDER BY eff_date DESC ,
                  exp_date;
                                                          DECLARE @cur12_cnt INT ,
                                                              @cur12_i INT;
                                                              SET @cur12_i = 1;
  --Get the no. of records for the cursor
SELECT
@cur12_cnt = COUNT(1)
                                                              FROM
                                #SWV_cursor_var12;
                                                              WHILE ( @cur12_i <= @cur12_cnt )
                                                              BEGIN

                                                  SELECT
                                                              @d_fc_eff = eff_date ,
                                                              @d_fc_exp = exp_date ,
                                                              @as_fc_id = facility_id
                                                   FROM
                                                              #SWV_cursor_var12
                                                              WHERE
                                                              id = @cur12_i;
                                                              GOTO SWL_Label22;
															  /*
    FETCH NEXT FROM #SWV_cursor_var11 INTO @d_fc_eff,
                                                              @d_fc_exp,
                   @as_fc_id;
															  */
                                           SET @cur12_i = @cur12_i
                          + 1;
                                                              END;
                                                              SWL_Label22:
                                                        --CLOSE #SWV_cursor_var11;
                                                              IF @as_fc_id IS NULL
                                                              SET @as_fc_id = @def_fc_id;
											
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
               @as_pl_id,
                                 @as_gpplrt_eff,
                                                              0;
                                                              IF @n_error_no < 0
                                                              BEGIN
                                   SET @as_fc_id = @def_fc_id;
                                                             
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                          @as_fc_id,
                                                              @as_pl_id,
                                                  @as_gpplrt_eff,
                                                              1;
                                                              IF @n_error_no < 0
                                                              SET @s_sub_error = 'Y';
															
                            END;
                                                              END;
                      ELSE
                                                              BEGIN
                                               
                                                       SET @as_fc_id = @s_facility_id;
                                                              
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                   @s_dls_sir_id,
                                                              @as_fc_id,
                                               @as_pl_id,
                                                              @as_gpplrt_eff,
            0;
                                                              IF @n_error_no < 0
                                                           BEGIN
                                            SET @as_fc_id = @def_fc_id;
                                                             
                                                              EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
															 @s_dls_sir_id,
                                                              @as_fc_id,
                                                    @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              1;
                                                              IF @n_error_no < 0
                         SET @s_sub_error = 'Y';
													  
                                                              END;
                                                              END;
                                                              END;
                                                     ELSE
                               BEGIN
                                                              SET @d_fc_eff = NULL;
                                                              SET @d_fc_exp = NULL;

															  /*
                                                              SET #SWV_cursor_var12 = CURSOR  FOR SELECT eff_date, exp_date, facility_id
											
                                          FROM dbo.rlplfc (NOLOCK)
                                          WHERE member_id = @as_member_id AND mb_gr_pl_id = @n_mbgrpl_id
                                          AND eff_date <= @as_fc_eff
                                          AND (exp_date > @as_fc_eff OR exp_date IS NULL)
ORDER BY eff_date DESC,exp_date;
                                                              OPEN #SWV_cursor_var12;
                                                         FETCH NEXT FROM #SWV_cursor_var12 INTO @d_fc_eff,
                                                              @d_fc_exp,
                                                              @as_fc_id;
                                                              WHILE @@FETCH_STATUS = 0
															  */

															  IF OBJECT_ID('tempdb..#SWV_cursor_var13') IS NOT NULL
															DROP TABLE #SWV_cursor_var13

                       CREATE TABLE #SWV_cursor_var13
                                                              (
                                                              id INT IDENTITY ,
                                                      eff_date DATE ,
                                                  exp_date DATE ,
                                                              facility_id INT
                                                              );
                                                              INSERT
                                                              INTO #SWV_cursor_var13
                                                 (
                                                              eff_date ,
                exp_date ,
                              facility_id
                                                              )
                                                              SELECT
                                                              eff_date ,
                                                              exp_date ,
                                                  facility_id
       FROM
                    dbo.rlplfc (NOLOCK)
                                                              WHERE
                                                              member_id = @as_member_id
                            AND mb_gr_pl_id = @n_mbgrpl_id
     AND eff_date <= @as_fc_eff
                                                              AND ( exp_date > @as_fc_eff
                                                              OR exp_date IS NULL
                              )
                                                              ORDER BY eff_date DESC ,
                                                              exp_date;
                            DECLARE @cur13_cnt INT ,
                                                              @cur13_i INT;
                                                              SET @cur13_i = 1;
    --Get the no. of records for the cursor
                                                              SELECT
                                                              @cur13_cnt = COUNT(1)
                                                              FROM
         #SWV_cursor_var13;
                                                              WHILE ( @cur13_i <= @cur13_cnt )
                                                              BEGIN
                                                              SELECT
                                                              @d_fc_eff = eff_date ,
                                                              @d_fc_exp = exp_date ,
                                                              @as_fc_id = facility_id
                                                              FROM
                                                          #SWV_cursor_var13
                                    WHERE
              id = @cur13_i;

                                                              GOTO SWL_Label23;
															  /*
  FETCH NEXT FROM #SWV_cursor_var12 INTO @d_fc_eff,
                                                              @d_fc_exp,
             @as_fc_id;
															  */
                                                              SET @cur13_i = @cur13_i
                                                              + 1;
                                                              END;
                                                              SWL_Label23:
                                                --CLOSE #SWV_cursor_var12;
        IF @as_fc_id IS NOT NULL
     BEGIN
                                                       
                  EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                                              @as_fc_id,
                     @as_pl_id,
                                                              @as_gpplrt_eff,
                        0;
                                                              END;
                                                              ELSE
                                                              SET @n_error_no = -1;
										
      IF @n_error_no < 0
                                                              BEGIN
                                                              SET @as_fc_id = @def_fc_id;
                                                              
                               EXECUTE @n_error_no = dbo.dlp_chk_facility @a_batch_id,
                                                              @s_dls_sir_id,
                                   @as_fc_id,
                                                @as_pl_id,
                                                              @as_gpplrt_eff,
                                                              1;
                                                              IF @n_error_no < 0
                              SET @s_sub_error = 'Y';
												 
                                                              END;
                                                              END;
                                              END;
                                                              ELSE
                                                              SET @as_fc_id = NULL;
								  -- END OF "IF n_ffs_plan = 0 THEN"
                 IF @s_sub_error = 'N'
                                                              BEGIN
                                                              IF @as_action_code = 'PA'
                                                              BEGIN
           
                                                              IF @n_multiple_plans <> 'Y'
											-- $$20120501$$ks - Multi plans OK if diff type (D vs. V)
                                                              IF EXISTS ( SELECT
     dbo.[plan].plan_id
                                                              FROM
                                                              dbo.rlmbgrpl (NOLOCK) ,
  dbo.[plan] (NOLOCK)
              WHERE
                                      dbo.[plan].plan_id = dbo.rlmbgrpl.plan_id
                                                              AND exp_gr_pl IS NULL
                                                              AND dbo.rlmbgrpl.member_id = @as_member_id
                                                              AND dbo.[plan].ins_type IN (
        SELECT
                                                              p2.ins_type
                                                          FROM
                     dbo.[plan] p2 ( NOLOCK )
                                                              WHERE
                                                              p2.plan_id = @as_pl_id ) )
                           SET @as_action_code = 'PC';
											
                                                              END;
									
                                                             
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                           @s_dls_sir_id,
                                                              @as_action_code,
                                                              @as_gpplrt_eff;
           END;
								
                                                             
                                                              IF @n_has_term_date = 'Y'
                                                              IF @as_action_code = 'PC'
                                                              SET @s_change_dep_pc = 'Y'; --get dep to change plan
									
                                                              END;
                                END;  -- END OF "IF n_count = 1 THEN"
						  -- END OF "IF n_count = 0 THEN" Tape Type Group, Plan, Plan Eff Date
                                                        END;
                                END;  -- *****
					   --  End of "if s_mb_term_date is null"
             END;   --  END OF "if s_sub_error = "N""
			  --  End of "if as_action_code = "MU"" 
			
                                    IF @as_action_code = 'ST' --when member with plan_term_date
                                        BEGIN
                                           
                                            EXECUTE dbo.dlp_mbgrpl_info_sg @as_gp_id,
                                                @as_pl_id, @as_member_id,
                                                @s_mb_term_date, 'N',
                     @n_count OUTPUT,
                                                @n_mbgrpl_id OUTPUT,
                                                @n_group_id OUTPUT,
												@n_plan_id OUTPUT,
                                             @n_sub_in_plan OUTPUT,
												@n_eff_gr_pl OUTPUT,
                                                @n_exp_gr_pl OUTPUT;
           BEGIN
					 -- CH001
                       -- DECLARE @SWV_dlp_bu_elig_subnpl SMALLINT
                                                --DECLARE #SWV_cursor_var13 CURSOR;
                                       IF @n_count = 0
												BEGIN
													SET @s_error_no = 223;
                                         RAISERROR('Can''t find active subscriber to be terminated',16,1);
													RETURN
												END
				
                                                IF @n_count > 1
												BEGIN
													SET @s_error_no = 607;
                RAISERROR('Mulitple Active Member records to be terminated',16,1);
													RETURN
												END
				
                                                EXECUTE dbo.dlp_bu_elig_subnpl @n_count,
                      @t_sub_in_plan,
                                                    @n_sub_in_plan,
                                                    @a_batch_id, @i_sp_id,
                                                    @i_sir_def_id,
                                                    @s_dls_sub_sir_id,
                                                    @SWV_dlp_bu_elig_subnpl OUTPUT;
         SET @t_sub_in_plan = @SWV_dlp_bu_elig_subnpl;
                                               
						-- CH001
                                                IF @s_mb_gppl_eff_date != @n_eff_gr_pl
                                                    BEGIN
 SET @s_mb_gppl_eff_date = CONVERT(VARCHAR, @n_eff_gr_pl) ;
            
                                                    END;
				
                                                IF @n_group_id != @as_gp_id
												BEGIN
													SET @s_error_no = 39;
                                                    RAISERROR('Active with different Group',16,1);
													RETURN
												END
				
                                                IF @n_plan_id != @as_pl_id
												BEGIN
													SET @s_error_no = 182;
        RAISERROR('Active with diffent Plan',16,1);
													RETURN
												END
				
                                                IF @n_exp_gr_pl IS NOT NULL
                                     BEGIN
                                         
														IF @n_exp_gr_pl = CAST (@s_mb_term_date AS DATE)
                                                            SET @as_action_code = 'MU';
                                                        ELSE
														BEGIN
															SET @s_error_no = 144;
            RAISERROR('Sub already terminated with diff date',16,1);
															RETURN
														END
                                                    END;
                                                ELSE
        BEGIN
                                                        IF NOT EXISTS ( SELECT
                                                              *
                                       FROM
                                                              dbo.rlmbrt (NOLOCK)
                                                              WHERE
                                                              mb_gr_pl_id = @n_mbgrpl_id
                                AND eff_rt_date <= CAST(@s_mb_term_date AS DATE)
                                      AND exp_rt_date IS NULL )
															  BEGIN
																SET @s_error_no = 614;
																RAISERROR('No Active Subscriber Rate Code',16,1);
																RETURN
															END
					
                                    SET @n_eff_date = NULL;
                                                   SET @n_exp_date = NULL;
                                                        SET @n_facility_id = NULL;

														/*
                               SET #SWV_cursor_var13 = CURSOR  FOR SELECT facility_id, eff_date, exp_date
						
                           FROM dbo.rlplfc (NOLOCK)
                      WHERE mb_gr_pl_id = @n_mbgrpl_id AND member_id = @as_member_id
                           AND eff_date <= CAST(@s_mb_term_date AS DATE)
AND (exp_date > CAST(@s_mb_term_date AS DATE) OR exp_date IS NULL)
                           ORDER BY eff_date DESC,exp_date;
                                     OPEN #SWV_cursor_var13;
                                                        FETCH NEXT FROM #SWV_cursor_var13 INTO @n_facility_id,
                                                            @n_eff_date,
                                                            @n_exp_date;
                                                        WHILE @@FETCH_STATUS = 0
														*/
														IF OBJECT_ID('tempdb..#SWV_cursor_var14') IS NOT NULL
												DROP TABLE #SWV_cursor_var14
                                                        CREATE TABLE #SWV_cursor_var14
               (
                                                              id INT IDENTITY ,
                                                              facility_id INT ,
                                                              eff_date DATE ,
                                                              exp_date DATE
                                                   );
                                        INSERT
                                                              INTO #SWV_cursor_var14
                                     (
 facility_id ,
                                                              eff_date ,
                                                              exp_date 
                                                              )
            SELECT
                                                              facility_id ,
                                                              eff_date ,
                               exp_date
                                                              FROM
                    dbo.rlplfc (NOLOCK)
                                                    WHERE
                                                              mb_gr_pl_id = @n_mbgrpl_id
                                                            AND member_id = @as_member_id
                                                              AND eff_date <= CAST(@s_mb_term_date AS DATE)
                                                              AND ( exp_date > CAST(@s_mb_term_date AS DATE)
    OR exp_date IS NULL
                                                              )
  ORDER BY eff_date DESC ,
                                                              exp_date;
                                                        DECLARE @cur14_cnt INT ,
                                                            @cur14_i INT;
                                                        SET @cur14_i = 1;
    --Get the no. of records for the cursor
        SELECT
                                                    @cur14_cnt = COUNT(1)
                                                        FROM  #SWV_cursor_var14;
                                                        WHILE ( @cur14_i <= @cur14_cnt )
                                                            BEGIN
      SELECT
                                                              @n_facility_id = facility_id ,
                                                              @n_eff_date = eff_date ,
                                                              @n_exp_date = exp_date
                                                          FROM
                                                              #SWV_cursor_var14
                                                              WHERE
       id = @cur14_i;

                 GOTO SWL_Label24;
															  /*                                                 
															  FETCH NEXT FROM #SWV_cursor_var13 INTO @n_facility_id,
                    @n_eff_date,
                                                              @n_exp_date;
															  */
                                                              SET @cur14_i = @cur14_i
                                                              + 1;
                                                      END;
                                           SWL_Label24:
                                                 --CLOSE #SWV_cursor_var13;
                                                        IF @n_eff_date IS NULL
														BEGIN
															SET @s_error_no = 615;
    RAISERROR('Subscriber has no active fac record',16,1);
															RETURN
														END
					
                                                        SET @as_fc_id = @n_facility_id;
                                                        SET @as_fc_eff = @n_eff_date;
                                                        SET @as_gpplrt_eff = @n_eff_gr_pl;
                                                 SET @as_action_code = 'ST';
                                                    END;
				
                                                IF @s_sub_error = 'N'
                                                    BEGIN
                  
                                                        EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                            @s_dls_sir_id,
                                                            @as_action_code,
                            @s_mb_term_date;
                                      END;
				
                                         END;
                                        END;
                                END;
		  --  End of "if s_sub_err = "N""
                            IF @s_sub_error = 'N'
							   UPDATE  dbo.dls_sg_member
                                SET     dls_member_id = @as_member_id ,
                                        dls_subscriber_id = @as_sub_id ,
                          dls_msg_id = @as_msg_id ,
                                        dls_group_id = @as_gp_id ,
       dls_plan_id = @as_pl_id ,
                                        rate_code = @s_rate_code ,
                                        dls_facility_id = @as_fc_id ,
                       dls_producer_id = @as_pd_id ,
      dls_action_code = @as_action_code ,
                                        dls_status = 'P'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @s_dls_sir_id;

								
                            ELSE
                                UPDATE  dbo.dls_sg_member
                                SET     dls_member_id = @as_member_id ,
                                        dls_subscriber_id = @as_sub_id ,
										dls_msg_id = @as_msg_id ,
                                        dls_group_id = @as_gp_id ,
                                        dls_plan_id = @as_pl_id ,
                                        rate_code = @s_rate_code ,
                                        dls_facility_id = @as_fc_id ,
                                        dls_producer_id = @as_pd_id ,
                                        dls_action_code = @as_action_code ,
                                        dls_status = 'E'
                                WHERE   dls_batch_id = @a_batch_id
       AND dls_sir_id = @s_dls_sir_id;
		
                           
                  EXECUTE dbo.dlp_bu_sg_dep @a_batch_id,
									@s_dls_sub_sir_id, @as_sub_id, @n_mbgrpl_id,@n_succ_count1 OUTPUT,@d_valid_error OUTPUT

									 --SET @n_succ_count = @n_succ_count + @n_succ_count1;
									-- SET @n_process_count = @n_process_count + @n_succ_count1;
									 
       IF @d_valid_error <= 0
           BEGIN
		   
                                    
                                    EXECUTE @i_fatal=dbo.usp_dl_log_error @a_batch_id,
                                        @sg_sp_id, @sg_sir_def_id,
                                        @s_dls_sir_id, 999
                                END;
		
                            IF @s_sub_error = 'Y'
                                BEGIN
                                  
            EXECUTE @i_fatal=dbo.dlp_set_sg_fam_err @a_batch_id,
                                        @s_dls_sub_sir_id
                                END;
		
                            IF @s_sub_error = 'Y'
                                OR @d_valid_error <= 0
                                BEGIN
                                     
                                    GOTO SWL_Label13;
                                END;
		
                  IF @s_sub_error != 'Y'
                                BEGIN
                                  
                                    IF ( @n_multiple_plans = 'Y'
                                         OR @n_allow_pl_change = 'Y'
                                       )
                 AND @s_change_dep_pc = 'Y'
                                        BEGIN
                                            SET @n_error_no = 1;
                      
         EXECUTE @n_error_no=dbo.dlp_sg_dep_plch @a_batch_id,
                                                @n_mbgrpl_id,
                                   @s_dls_sub_sir_id, @as_sub_id,
                                                @as_gpplrt_eff

              IF @n_error_no <= 0
											BEGIN
											SET @s_error_no = 400;
                                                RAISERROR('Failed to do dep plan change',16,1);
												RETURN
											END
                                        END;
			
                                    SET @n_error_no = 1;
                                    
                                    EXECUTE @n_error_no=dbo.dlp_sg_cal_rate @a_batch_id,
                                        @s_dls_sub_sir_id, @as_sub_id

                                    IF @n_error_no <= 0
                                        BEGIN
											SET @s_error_no = 500;
                                            RAISERROR('Failed during rate code calculation',16,1);
											RETURN
                                            
                                         EXECUTE @n_error_no=dbo.dlp_set_sg_fam_err @a_batch_id,
          @s_dls_sub_sir_id
                                        END;
			
                                END;
		
                            IF @s_sub_error != 'Y'
                                BEGIN
                                   SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
                                    SET @n_succ_count = @n_succ_count + 1;
									UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1
									
                                END;
									
								SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
								SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1

                            IF @n_sub_count % 100 = 0
			   -- CH001
                                UPDATE  dbo.dl_bat_statistics
									SET     tot_record = @n_process_count,
                           tot_success_rec = @n_succ_count ,
                                        tot_fail_rec = CAST(@n_process_count AS INT)
                                        - CAST (@n_succ_count AS INT)
                                WHERE   bat_statistics_id = @i_statistics_id;
		                             
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
       SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
					 IF @i_error_no IN ( -213, -457 )
                                BEGIN
									 IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
			
                            IF @i_error_no IN ( -244, -245, -246 )
                                BEGIN
                                    
                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @sg_sp_id, @sg_sir_def_id,
                                        @s_dls_sub_sir_id, 1000;
                                     
							END;
                            ELSE
                                BEGIN
                          
                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
                                        @sg_sp_id, @sg_sir_def_id,
                                        @s_dls_sir_id, @s_error_no;--0
                                     
                                END;
			
                            IF @i_fatal <> 1
                                SET @s_sub_error = 'Y';

								  IF @s_sub_error = 'N'
							   UPDATE  dbo.dls_sg_member
                                SET     dls_member_id = @as_member_id ,
                                        dls_subscriber_id = @as_sub_id ,
                                        dls_msg_id = @as_msg_id ,
                                        dls_group_id = @as_gp_id ,
                                        dls_plan_id = @as_pl_id ,
                                        rate_code = @s_rate_code ,
                                        dls_facility_id = @as_fc_id ,
                       dls_producer_id = @as_pd_id ,
                                        dls_action_code = @as_action_code ,
                                        dls_status = 'P'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @s_dls_sir_id;

								
                            ELSE
                                UPDATE  dbo.dls_sg_member
     SET     dls_member_id = @as_member_id ,
                                        dls_subscriber_id = @as_sub_id ,
       dls_msg_id = @as_msg_id ,
                                        dls_group_id = @as_gp_id ,
                                        dls_plan_id = @as_pl_id ,
                                        rate_code = @s_rate_code ,
                                        dls_facility_id = @as_fc_id ,
                                        dls_producer_id = @as_pd_id ,
                                        dls_action_code = @as_action_code ,
                                        dls_status = 'E'
                                WHERE   dls_batch_id = @a_batch_id
                                        AND dls_sir_id = @s_dls_sir_id;
		

                        END CATCH;
                    END;
                    SWL_Label13:
             /*
					FETCH NEXT FROM @cSIR INTO @s_dls_sir_id,
                        @s_dls_sub_sir_id, @s_member_flag, @s_alt_id, @s_ssn,
                        @s_sub_ssn, @s_sub_alt_id, @s_member_code,
                        @s_paperless, @s_optional_5, @s_last_name,
                        @s_first_name, @s_middle_init, @s_date_of_birth,
         @s_student_flag, @s_disable_flag, @s_cobra_flag,
    @s_msg_group_id, @s_plan_id, @s_facility_id,
                        @s_rate_code, @s_mb_gppl_eff_date, @s_mb_fc_eff_date,
                        @s_mb_term_date, @s_bank_account, @s_account_type,
                        @s_trans_rt_nbr, @s_transaction_code, @s_address1,
   @s_address2, @s_city, @s_state, @s_zip, @s_zipx,
                        @s_home_phone, @s_home_ext, @s_work_phone, @s_work_ext,
                        @s_email, @s_producer_id, @s_comm_scheme_id,
                        @s_pd_type, @s_license_number, @s_selling_period,
 @s_pdcomm_eff_date, @s_msg_group_alt_id,
                        @s_plan_dsp_name, @s_facility_alt_id,
                        @s_producer_alt_id, @s_new_ssn, @s_src_id,
                        @s_subnew_ssn, @s_subsrc_id, @s_ext_id_col,
   @api_mbr_id, @api_sub_id, @api_msg_id, @api_grp_id,
                        @api_plan_id, @api_fc_id, @t_sub_in_plan;
						*/
                    SET @cur3_i = @cur3_i + 1;
                END;
            --CLOSE @cSIR;
			
            IF @a_sir_id = 0
                BEGIN
                    
                    IF @n_has_term_date = 'N'
                        BEGIN
                            
                            SET @SWV_func_DLP_SG_MISSING_par0 = CONVERT(DATE, CONVERT(VARCHAR, @d_def_exp_date));
                            EXECUTE @n_error_no=dbo.dlp_sg_missing @a_batch_id,
                                @SWV_func_DLP_SG_MISSING_par0
                        END;
                END;
	
            
	  -- CH001
	  
	  SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 1
	  SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 1

            SET @a_fail_rec = CAST(@n_process_count AS INT)- CAST(@n_succ_count AS INT); 

            DECLARE @SWV_dl_upd_statistics INT;

  EXEC @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                @n_succ_count, @a_fail_rec

            IF @SWV_dl_upd_statistics <> 1
                BEGIN
               SET @SWP_Ret_Value = -1;
                    
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                 + @n_error_count ),
                                           ' Failed update statistics');
					IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 1 AND BatchId = @a_batch_id )
					BEGIN
						DELETE FROM GlobalVar WHERE Module_Id = 1 AND BatchId = @a_batch_id
					END
                    RETURN;
                END;
	
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished preprocess for Batch ',
                                         @a_batch_id);
				IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 1 AND BatchId = @a_batch_id )
				BEGIN
					DELETE FROM GlobalVar WHERE Module_Id = 1 AND BatchId = @a_batch_id
				END
            RETURN;
--TRACE statement has no equivalent in MSSQL
--trace off;
        END TRY
        BEGIN CATCH
		IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 1 AND BatchId = @a_batch_id )
		BEGIN
			DELETE FROM GlobalVar WHERE Module_Id = 1 AND BatchId = @a_batch_id
		END
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
			
         RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;