﻿CREATE PROCEDURE [dbo].[getserialid]
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 04:57:57 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @ReturnVal INT;
        DECLARE @serialid VARBINARY(8000);
        SET NOCOUNT ON;
        SET @serialid = CAST(0 AS VARBINARY(8000));
        EXECUTE SWPCrtGlVar 'serialid';
        EXECUTE SWPAddGlVar 'serialid', @serialid;
        EXECUTE SWPGetGlVar 'serialid', @serialid OUTPUT;
        SET @ReturnVal = @serialid;
        SET @serialid = CAST(0 AS VARBINARY(8000));
        EXECUTE SWPAddGlVar 'serialid', @serialid;
        RETURN  @ReturnVal;
        SET NOCOUNT OFF;
    END;