﻿CREATE PROCEDURE [dbo].[dlp_ut_ck_addr]
    @a_batch_id INT ,
    @a_addr1 CHAR(30) ,
    @a_city CHAR(20) ,
    @a_county CHAR(20) ,
    @a_state CHAR(2) ,
    @a_zip CHAR(10) ,
	@i_sir_id INT,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(20) = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(20) = NULL OUTPUT ,
    @SWP_Ret_Value3 CHAR(2) = NULL OUTPUT
    


------------------------------------------------------------------------------
--
--            Procedure:   dlp_ut_ck_addr
--
--            Created:     02/01/1999 
--            Author:      Kim Nguyen, Gene Albers
--
-- Purpose:  This SP validates a providers address for the pre-processing
--         step of the Utilization Extension the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/




        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_text VARCHAR(64);

        DECLARE @t_zip_id CHAR(10);
        DECLARE @t_city CHAR(20);
        DECLARE @t_county CHAR(20);
        DECLARE @t_state CHAR(2);
        --DECLARE @i_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
		DECLARE @i_fatal INT;


-----exception handling------------------------------------------
        SET NOCOUNT ON;
       -- SET @i_sir_id = 0;
        
        SET @i_sp_id = 23;
        
        SET @i_sir_def_id = 0;
		EXECUTE @i_sir_def_id = dbo.dl_get_sir_def_id 'utilization'
        
        BEGIN TRY
            SET @t_zip_id = NULL;
            SET @t_city = NULL;
            SET @t_county = NULL;
            SET @t_state = NULL;
            IF ( @a_addr1 IS NULL
                 OR @a_addr1 = ''
               )
                OR LEN(@a_addr1) = 0
				BEGIN 
				SET @i_error_no =650
                RAISERROR('Adding provider to target db, provider''s street address required',         16,1);
				END

            IF ( @a_zip IS NULL
                 OR @a_zip = ''
               )
			   BEGIN
			   SET @i_error_no =640
                RAISERROR('Adding provider to target db, provider''s zip code required',         16,1);
				END

            SELECT  @t_zip_id = zip_id ,
                    @t_city = city ,
                    @t_county = county ,
                    @t_state = state_code
            FROM    dbo.usa_zip (NOLOCK)
            WHERE   zip_code = @a_zip;
            
            IF ( @t_zip_id IS NULL
                 OR @t_zip_id = ''
               )
			   BEGIN 
			   SET @i_error_no=630
                RAISERROR('Provider''s zip code is not recognized by DataDental',16,1);
			END

            IF ( @t_city IS NOT NULL
                 AND @t_city <> ''
               )
                IF ( @a_city IS NOT NULL
                     AND @a_city <> ''
                   )
                    AND LEN(@a_city) > 0
                    BEGIN
                        IF @t_city <> @a_city
						BEGIN
							SET @i_error_no = 600
                            RAISERROR('Provider''s city does not match zip code ',0,1);
							EXEC  usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error_no;
						END
                    END;
                ELSE
                    SET @a_city = @t_city;
	

            IF ( @t_county IS NOT NULL
      AND @t_county <> ''
               )
                IF ( @a_county IS NOT NULL
                     AND @a_county <> ''
                   )
                    AND LEN(@a_county) > 0
                    BEGIN
                        IF @t_county <> @a_county
						BEGIN
							SET @i_error_no = 610
                            RAISERROR('Provider''s county does not match zip code ',0,1);
							EXEC  usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error_no;
						END
                    END;
                ELSE
                    SET @a_county = @t_county;
	

            IF ( @t_state IS NOT NULL
                 AND @t_state <> ''
               )
                IF ( @a_state IS NOT NULL
                     AND @a_state <> ''
                   )
                    AND LEN(@a_state) > 0
                    BEGIN
                        IF @t_state <> @a_state
						BEGIN
							SET @i_error_no = 620
                            RAISERROR('State and Zip Code do not match',16,1);  -- fatal
						END
                    END;
                ELSE
                    SET @a_state = @t_state;
	

            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = @a_city;
            SET @SWP_Ret_Value2 = @a_county;
            SET @SWP_Ret_Value3 = @a_state;
            RETURN;
        END TRY
        BEGIN CATCH
            --SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
			EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,
										@i_sir_def_id, @i_sir_id, @i_error_no;
						
			IF @i_fatal <> 1 
			BEGIN
				UPDATE dls_utilization
				SET   dls_status = 'E'
				WHERE dls_sir_id = @i_sir_id
														
			END ;
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;



-----------------------------------------------------------------
    END;