﻿CREATE PROC [dbo].[usp_ecl_SubmitToDataLoad]
    WITH RECOMPILE
AS
BEGIN
	DECLARE @SUBMITTODATALOAD INT
	DECLARE @SUBMITTEDSTATUS INT
	DECLARE @LOCKEDSTATUS INT
	DECLARE @COMPLETEDSTATUS INT
	DECLARE @ERRORSTATUS INT
	DECLARE @BATCH_ID INT
	DECLARE @BATCH_PARAM VARCHAR(100)
	DECLARE @configId INT
	DECLARE @JobID INT
	DECLARE @ParamTable TABLE(ID INT IDENTITY,ParamVal int)
	SET @SUBMITTEDSTATUS =1
	SET @SUBMITTODATALOAD =3
	SET @LOCKEDSTATUS= 2
	SET @COMPLETEDSTATUS =4
	SET @ERRORSTATUS=5
	SET @BATCH_ID =0 
	DECLARE	@SWP_Ret_Value int,
			@SWP_Ret_Value1 varchar(MAX)
	SELECT  @BATCH_ID = ISNULL(batch_id,0),@BATCH_PARAM=batch_param  FROM [batch_process_details] 
			WHERE event_id =  @SUBMITTODATALOAD AND status= @SUBMITTEDSTATUS ORDER BY batch_id ASC
	IF (@BATCH_ID <> 0 AND (LEN(@BATCH_PARAM) > 0))
	BEGIN
		UPDATE [batch_process_details] SET status = @LOCKEDSTATUS WHERE batch_id = @BATCH_ID
		INSERT INTO @ParamTable
			SELECT * FROM [dbo].[udf_SplitString](@BATCH_PARAM,',') --15,16 input  
		 DECLARE @cur1_cnt INT ,@cur_i INT;
            SET @cur_i = 1;
            SELECT  @cur1_cnt = COUNT(1)  FROM @ParamTable;
            WHILE ( @cur_i <= @cur1_cnt ) 
			BEGIN
				SELECT @configId = ParamVal FROM @ParamTable WHERE ID=@cur_i
				INSERT INTO [dbo].[eclaim_report] ([StartDate],[Source],[ProcName],[StatusId],[HUser],[BatchId],[Parameters])
				VALUES (GETDATE(),'SubmitToDL', 'dload_new_batch',1,SYSTEM_USER,@BATCH_ID,@configId);
				SET @JobID = SCOPE_IDENTITY();
				SET @cur_i = @cur_i + 1;
				BEGIN TRY
					EXEC [dbo].[dload_new_batch]
					@ConfigID = @configId,
					@SWP_Ret_Value = @SWP_Ret_Value OUTPUT,
					@SWP_Ret_Value1 = @SWP_Ret_Value1 OUTPUT
					IF(@SWP_Ret_Value<0) --  -1 -failed output 
						BEGIN
							RAISERROR (@SWP_Ret_Value1, 16, 1 );
						END
					ELSE -- success output
						BEGIN
							UPDATE dbo.eclaim_report SET StatusId=2,EndDate=GETDATE(), ReturnValue = @SWP_Ret_Value WHERE JobId=@JobID 
						END
				UPDATE [batch_process_details] SET status = @COMPLETEDSTATUS , completed_time = GETDATE() WHERE batch_id = @BATCH_ID
				END TRY 
				BEGIN CATCH
				SET @SWP_Ret_Value1=ERROR_MESSAGE();
					UPDATE dbo.eclaim_report SET StatusId=3, ErrorDetail=@SWP_Ret_Value1 WHERE JobId=@JobID
					UPDATE [batch_process_details] SET status = @ERRORSTATUS WHERE batch_id = @BATCH_ID
					RAISERROR (@SWP_Ret_Value1, 16, 1 );
				END CATCH
			END
	END
END