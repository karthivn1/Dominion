﻿CREATE PROCEDURE [dbo].[SWPCrtGlVar] @name VARCHAR(255)
    
AS
    IF NOT EXISTS ( SELECT  *
                    FROM    tempdb..sysobjects
                    WHERE   id = OBJECT_ID('tempdb..##SwtGlVar')
                            AND xtype = 'U' )
        CREATE TABLE ##SwtGlVar
            (
              spid INT NOT NULL ,
              name VARCHAR(255) NOT NULL ,
              value VARBINARY(8000) NULL ,
              PRIMARY KEY ( spid, name )
            );
    IF NOT EXISTS ( SELECT  *
                    FROM    ##SwtGlVar
                    WHERE   spid = @@spid
                            AND name = @name )
        INSERT  INTO ##SwtGlVar
        VALUES  ( @@spid, @name, NULL );
    ELSE
        UPDATE  ##SwtGlVar
        SET     value = NULL
        WHERE   spid = @@spid
                AND name = @name;