﻿CREATE PROCEDURE [dbo].[dlp_bu_fac_net]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    


/*error variable*/
AS
    BEGIN
	/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;

        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);

        DECLARE @i_pre_process_sp INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT; 
        DECLARE @s_batch_status CHAR(1);
        DECLARE @curr_fcstat_id INT;
        DECLARE @curr_fcstat CHAR(2);
        DECLARE @curr_fcstat_eff DATE;
        DECLARE @curr_fcstat_exp DATE;
        DECLARE @curr_fcnet_id INT;
        DECLARE @curr_fcnet_eff DATE;
        DECLARE @curr_fcnet_exp DATE;
        DECLARE @tape_fcnet_eff DATE;
        DECLARE @tape_fcnet_exp DATE;
        DECLARE @d_valid_error INT;
        DECLARE @d_error_descr VARCHAR(64);
        DECLARE @n_error_no INT; 
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @fcnet_sir_def_name CHAR(18);
        DECLARE @fcnet_proc_name CHAR(18);
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_config_id INT;
        DECLARE @n_def_eff_date CHAR(10);
        DECLARE @d_def_eff_date DATE;
        DECLARE @n_def_exp_date CHAR(10);
        DECLARE @d_def_exp_date DATE;
        DECLARE @n_has_term_date CHAR(1);
        DECLARE @n_net_id INT;
        DECLARE @t_sir_id INT;
        DECLARE @t_alt_id CHAR(40);
        DECLARE @t_fc_type CHAR(2);
        DECLARE @t_fc_name CHAR(50);
        DECLARE @t_fc_status CHAR(2);
        DECLARE @t_fc_stat_eff_date CHAR(10);
        DECLARE @t_fc_stat_exp_date CHAR(10);
        DECLARE @t_fc_state CHAR(2);
        DECLARE @t_fc_license CHAR(18);
        DECLARE @t_fc_lrenew_dt CHAR(10);
        DECLARE @t_vendor_id CHAR(40);
        DECLARE @t_fc_tax_id CHAR(9);
        DECLARE @t_tin CHAR;
        DECLARE @t_fc_area CHAR(11);
        DECLARE @t_fc_rep CHAR(20);
        DECLARE @t_fc_source CHAR(2);
        DECLARE @t_phone_elig CHAR;
        DECLARE @t_fax_elig CHAR;
        DECLARE @t_print_dir CHAR;
        DECLARE @t_fc_mst_con_dt CHAR(10);
        DECLARE @t_emergency_phone CHAR(14);
        DECLARE @t_em_phone_ext CHAR(5);
        DECLARE @t_emg_contact_type CHAR(2);
        DECLARE @t_legal_entity CHAR(2);
        DECLARE @t_fc_tax_name CHAR(50);
        DECLARE @t_pnrx CHAR;
        DECLARE @t_no2 CHAR;
        DECLARE @t_hndacs CHAR;
        DECLARE @t_fc_capacity CHAR(11);
        DECLARE @t_fc_warn  CHAR(9);
        DECLARE @t_fc_no_new  CHAR(9);
        DECLARE @t_fc_max_enrl CHAR(11);
        DECLARE @t_fc_opr_tory CHAR(11);
        DECLARE @t_parent_id CHAR(40);
        DECLARE @t_barrier_c CHAR(10);
        DECLARE @t_fc_cur_enrl CHAR(11);
        DECLARE @t_next_cap_date CHAR(10);
        DECLARE @t_net_id CHAR(20);
        DECLARE @t_contract_type CHAR(3);
        DECLARE @t_net_fc_eff_date CHAR(10);
        DECLARE @t_ovr_ride CHAR;
        DECLARE @t_net_fc_exp_date CHAR(10);
        DECLARE @t_addr_type CHAR(2);
        DECLARE @t_addr1 CHAR(30);
        DECLARE @t_addr2 CHAR(30);
        DECLARE @t_zipcode CHAR(10);
        DECLARE @t_city CHAR(30);
        DECLARE @t_state CHAR(2);
        DECLARE @t_county CHAR(20);
        DECLARE @t_country CHAR(3);
        DECLARE @t_mail CHAR;
    DECLARE @t_con_type CHAR(2);
        DECLARE @t_con_lname CHAR(15);
        DECLARE @t_con_fname CHAR(10);
        DECLARE @t_title CHAR(25);
        DECLARE @t_phone1 CHAR(14);
        DECLARE @t_ext1 CHAR(5);
        DECLARE @t_phone2 CHAR(14);
        DECLARE @t_ext2 CHAR(5);
        DECLARE @t_fax CHAR(14);
  DECLARE @i_fc_id INT;
        DECLARE @as_action_code CHAR(2);
        DECLARE @as_fc_stat_eff DATE;
        DECLARE @as_fc_net_eff DATE;
        DECLARE @as_fc_net_exp DATE;
        DECLARE @d_fc_stat_eff_date DATE;
        DECLARE @d_fc_lrenew_dt DATE;
        DECLARE @d_fc_area INT;
        DECLARE @d_fc_rep INT;
        DECLARE @d_fc_mst_con_dt DATE;
        DECLARE @d_fc_capacity INT;
        DECLARE @d_fc_warn DECIMAL(5,2);
        DECLARE @d_fc_no_new DECIMAL(5,2);
        DECLARE @d_fc_max_enrl INT;
        DECLARE @d_fc_opr_tory INT;
        DECLARE @d_barrier_c DECIMAL(6,2);
        DECLARE @d_fc_cur_enrl INT;
        DECLARE @d_next_cap_date DATE;
        DECLARE @d_net_id INT;
        DECLARE @d_net_fc_eff_date DATE;
        DECLARE @d_net_fc_exp_date DATE;
        DECLARE @d_zip INT;
        DECLARE @d_phone_err CHAR(1);
        DECLARE @d_phone1 INT;
        DECLARE @d_ext1 INT;
        DECLARE @d_phone2 INT;
        DECLARE @d_ext2 INT;
        DECLARE @d_fax INT;
        DECLARE @n_process_count INT;
        DECLARE @n_error_count INT;
        DECLARE @n_succ_count INT;
		DECLARE @created_by CHAR(15)
        --DECLARE @cSIR CURSOR;
        DECLARE @SWV_func_DLP_FC_MISSING_par0 VARCHAR(255);


        SET NOCOUNT ON;
		 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 6 AND BatchId = @a_batch_id )
		 BEGIN
	
				INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id])
				SELECT N'n_process_count',						N'', @a_batch_id, 6
				UNION ALL SELECT N'n_succ_count',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_addr_type',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_addr1',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_addr2',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_alt_id',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_barrier_c',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_city',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_con_fname',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_con_lname',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_con_type',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_contract_type',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_country',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_county',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_em_phone_ext',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_emergency_phone',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_emg_contact_type',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_ext1',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_ext2',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_fax',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_fax_elig',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_area',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_capacity',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_cur_enrl',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_license',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_lrenew_dt',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_max_enrl',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_mst_con_dt',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_name',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_no_new',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_opr_tory',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_rep',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_source',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_stat_eff_date',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_state',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_tax_id',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_tax_name',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_type',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_fc_warn',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_hndacs',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_legal_entity',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_mail',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_net_fc_eff_date',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_net_fc_exp_date',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_net_id',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_next_cap_date',			N'', @a_batch_id, 6
				UNION ALL SELECT N't_no2',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_ovr_ride',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_parent_id',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_phone_elig',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_phone1',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_phone2',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_pnrx',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_print_dir',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_sir_id',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_state',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_tin',						N'', @a_batch_id, 6
				UNION ALL SELECT N't_title',					N'', @a_batch_id, 6
				UNION ALL SELECT N't_vendor_id',				N'', @a_batch_id, 6
				UNION ALL SELECT N't_zipcode',					N'', @a_batch_id, 6

								
		END
        SET @fcnet_sir_def_name = ''       
        SET @fcnet_proc_name = '' 
        SET @i_sp_id = 0 ;
        SET @i_sir_def_id = 0
        SET @i_config_id = 0 
        SET @n_def_eff_date = '' 
        SET @d_def_eff_date = NULL 
        SET @n_def_exp_date = '' 
        SET @d_def_exp_date = NULL
        SET @n_has_term_date = '' 
        SET @n_net_id = 0 
        SET @t_sir_id = 0 
		SET @t_alt_id = '' 
        SET @t_fc_type =''
        SET @t_fc_name = '' 
        SET @t_fc_status = '' 
        SET @t_fc_stat_eff_date = '' 
        SET @t_fc_stat_exp_date = '' 
        SET @t_fc_state = '' 
        SET @t_fc_license = '' 
        SET @t_fc_lrenew_dt = '' 
        SET @t_vendor_id = '' 
        SET @t_fc_tax_id = '' 
        SET @t_tin = '' 
        SET @t_fc_area = '' 
        SET @t_fc_rep = '' 
        SET @t_fc_source = '' 
        SET @t_phone_elig = '' 
        SET @t_fax_elig = '' 
        SET @t_print_dir = '' 
		SET @t_fc_mst_con_dt = '' 
        SET @t_emergency_phone = '' 
        SET @t_em_phone_ext = ''
        SET @t_emg_contact_type = '' 
        SET @t_legal_entity = '' 
        SET @t_fc_tax_name = '' 
        SET @t_pnrx = '' 
        SET @t_no2 = ''
        SET @t_hndacs = '' 
        SET @t_fc_capacity ='' 
        SET @t_fc_warn = '' 
        SET @t_fc_no_new = '' 
        SET @t_fc_max_enrl = '' 
        SET @t_fc_opr_tory = '' 
        SET @t_parent_id = '' 
        SET @t_barrier_c = '' 
        SET @t_fc_cur_enrl = '' 
        SET @t_next_cap_date = '' 
        SET @t_net_id = '' 
        SET @t_contract_type = '' 
        SET @t_net_fc_eff_date = '' 
        SET @t_ovr_ride = ''
        SET @t_net_fc_exp_date = ''
        SET @t_addr_type = '' 
        SET @t_addr1 = '' 
        SET @t_addr2 = '' 
        SET @t_zipcode = '' 
        SET @t_city = '' 
        SET @t_state = '' 
        SET @t_county = '' 
        SET @t_country = '' 
        SET @t_mail = '' 
        SET @t_con_type = '' 
        SET @t_con_lname = '' 
        SET @t_con_fname = '' 
        SET @t_title = '' 
        SET @t_phone1 = '' 
        SET @t_ext1 = '' 
        SET @t_phone2 = '' 
        SET @t_ext2 ='' 
        SET @t_fax = '' 
        SET @i_fc_id = 0 
        SET @as_action_code = '' 
        SET @as_fc_stat_eff = NULL        
  SET @as_fc_net_eff = NULL        
		SET @as_fc_net_exp = NULL         
        SET @d_fc_stat_eff_date = NULL 
        SET @d_fc_lrenew_dt = NULL 
        SET @d_fc_area = 0 
        SET @d_fc_rep = 0 
        SET @d_fc_mst_con_dt = NULL 
        SET @d_fc_capacity = 0
        SET @d_fc_warn = 0    
        SET @d_fc_no_new = 0      
        SET @d_fc_max_enrl = 0    
 SET @d_fc_opr_tory = 0       
        SET @d_barrier_c = 0       
        SET @d_fc_cur_enrl = 0      
   SET @d_next_cap_date = NULL     
        SET @d_net_id = 0    
        SET @d_net_fc_eff_date = NULL        
        SET @d_net_fc_exp_date = NULL       
        SET @d_zip = 0    
        SET @d_phone_err = ''       
        SET @d_phone1 =0      
        SET @d_ext1 = 0    
        SET @d_phone2 = 0      
        SET @d_ext2 = 0     
        SET @d_fax = 0     
        SET @n_process_count = 0    
		UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
        SET @n_error_count = 0        
        SET @n_succ_count = 0
		UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
        
        BEGIN TRY
            
            SET @fcnet_proc_name = 'bu_fac_net' 
           
            SET @fcnet_sir_def_name = 'fac_net' 
           
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, @fcnet_proc_name ;
   
            IF @i_sp_id IS NULL
                OR @i_sp_id <= 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Invalid SP Name',16,1);
				RETURN
				END

        
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@fcnet_sir_def_name) ;

            IF @i_sir_def_id IS NULL
                OR @i_sir_def_id <= 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Invalid SIR TABLE Definition',16,1);
				RETURN
				END


            SET @n_def_eff_date = dbo.dl_get_param_value(@a_batch_id,
                                                              @i_sp_id,
                                          'Default Eff Date') ;
        
            SET @n_def_exp_date = dbo.dl_get_param_value(@a_batch_id,@i_sp_id,'Default Exp Date') 
        
            SET @n_has_term_date = dbo.dl_get_param_value(@a_batch_id,@i_sp_id,'Has Term Date Flag') 
            
            SET @n_net_id = dbo.dl_get_param_value(@a_batch_id, @i_sp_id,
                                                        'Working Network ID');
            
            IF ( @n_def_eff_date IS NULL
                 OR @n_def_eff_date = ''
               )
                OR LEN(@n_def_eff_date) = 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Default Effective Date',16,1);
				RETURN
				END
            ELSE
                BEGIN
                    
                    SET @d_def_eff_date = @n_def_eff_date;
                    
                    IF DATEPART(DAY,@d_def_eff_date) <> 1
					BEGIN
					SET @a_error_no = 0
                        RAISERROR('Default Effective Date is not first of the month',16,1);
						RETURN
						END
                END;

           
            IF ( @n_def_exp_date IS NULL
                 OR @n_def_exp_date = ''
               )
                OR LEN(@n_def_exp_date) = 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Default Expiration Date',16,1);
				RETURN
				END
            ELSE
                BEGIN
                   
                    SET @d_def_exp_date = @n_def_exp_date 
                    
                    IF DATEPART(DAY,
                                @d_def_exp_date) <> 1
								BEGIN
								SET @a_error_no = 0
                        RAISERROR('Default Expiration Date is not first of the month',16,1);
						RETURN
						END
          END;

            
            IF ( @n_has_term_date IS NULL
                 OR @n_has_term_date = ''
               )
                OR LEN(@n_has_term_date) = 0
				BEGIN
				SET @a_error_no = 0
                RAISERROR('Missing Has Term Date Flag',16,1);
				RETURN
				END
            ELSE
      BEGIN
                    
                    IF @n_has_term_date NOT IN ( 'Y', 'N' )
					BEGIN
					SET @a_error_no = 0
                        RAISERROR('Invalid Value for Has Term Date flag',16,1);
						RETURN 
						END
        END;

            
         IF @n_net_id IS NULL
                OR @n_net_id <= 0
				BEGIN
				SET @a_error_no = 0
RAISERROR('Invalid Working Network ID',16,1);
				RETURN
				END

            SELECT  @i_config_id = config_id ,
                    @s_batch_status = config_bat_status
            FROM    dl_config_bat
            WHERE   config_bat_id = @a_batch_id;
           
            
            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
      FROM    dl_cfg_bat_det
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;
					
					SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
            
            INSERT  INTO dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                  NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      --ORIGINAL_LOGIN() ,
					  @created_by,
                      @a_start_time
                    );

            SELECT  @i_statistics_id = MAX(bat_statistics_id)
            FROM    dl_bat_statistics
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            
            --SET @n_process_count = 0 
            --  SET @n_succ_count = 0 
			UPDATE GlobalVar SET VarValue = @n_process_count WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE GlobalVar SET VarValue = @n_succ_count WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
            
            IF @a_sir_id > 0
                BEGIN
                    UPDATE  dls_fac_net
                    SET     dls_status = 'V'
                    WHERE   dls_batch_id = @a_batch_id
                            AND dls_sir_id = @a_sir_id;
                    DELETE  FROM dl_action
                    WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                            AND dls_sir_id = @a_sir_id;
                   
                    EXECUTE dbo.dl_clean_curr_err @a_batch_id, @a_sir_id,
                        @i_sp_id, @n_error_no OUTPUT, @n_error_text OUTPUT;
                END;
            ELSE
                BEGIN
                    DELETE  FROM dl_action
                    WHERE   batch_id = @a_batch_id
                            AND process_status = 'N'
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dls_fac_net
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
                    DELETE  FROM dl_log_error
                    WHERE   config_bat_id = @a_batch_id
                            AND sp_id = @i_sp_id
                            AND dls_sir_id IN (
                            SELECT  dls_sir_id
                            FROM    dls_fac_net
                            WHERE   dls_batch_id = @a_batch_id
                                    AND dls_status = 'V' );
                END;

				DECLARE @cSIR TABLE
                        (
                         id INT IDENTITY ,
						dls_sir_id INT,
						alt_id CHAR(40), 
						fc_type CHAR(2),
						fc_name CHAR(50), 
						fc_stat_eff_date CHAR(10),
		                fc_state CHAR(2),
		                fc_license CHAR(18), 
		                fc_lrenew_dt CHAR(10), 
		                vendor_id CHAR(40), 
		                fc_tax_id CHAR(9),
		                tin CHAR,
		                fc_area CHAR(11),
		                fc_rep CHAR(20), 
		                fc_source CHAR(2), 
		                phone_elig CHAR, 
		        fax_elig CHAR,
		  print_dir CHAR, 
		                fc_mst_con_dt CHAR(10), 
		                emergency_phone CHAR(14), 
		                em_phone_ext CHAR(5),
		                emg_contact_type CHAR(2), 
		          legal_entity CHAR(2), 
		                fc_tax_name CHAR(50), 
		                pnrx CHAR, 
		                no2 CHAR,
		                hndacs CHAR, 
		    fc_capacity CHAR(11), 
		                fc_warn CHAR(9), 
						fc_no_new CHAR(9), 
		                fc_max_enrl CHAR(11),
		                fc_opr_tory CHAR(11), 
		                parent_id CHAR(40), 
		                barrier_c CHAR(10), 
		                fc_cur_enrl CHAR(11), 
		                next_cap_date CHAR(10),
		                net_id CHAR(20), 
		                contract_type CHAR(3), 
		                net_fc_eff_date CHAR(10), 
		                ovr_ride CHAR,
		                net_fc_exp_date CHAR(10), 
		                addr_type CHAR(2), 
		                addr1 CHAR(30), 
						addr2 CHAR(30),
		                zip CHAR(10), 
		                city CHAR(30), 
		                state CHAR(2),
		                county CHAR(20), 
		                country CHAR(3),
		                mail CHAR, 
		                con_type CHAR(2), 
		                con_lname CHAR(15), 
		                con_fname CHAR(10),
		                title CHAR(25), 
		                phone1 CHAR(14), 
		                ext1 CHAR(5), 
		                phone2 CHAR(14), 
		                ext2 CHAR(5), 
		                fax CHAR(14)
                        );

						INSERT  INTO @cSIR
                                ( dls_sir_id, alt_id, fc_type, fc_name, fc_stat_eff_date,
		fc_state, fc_license, fc_lrenew_dt, vendor_id, fc_tax_id,
		tin, fc_area, fc_rep, fc_source, phone_elig, fax_elig,
		print_dir, fc_mst_con_dt, emergency_phone, em_phone_ext,
		emg_contact_type, legal_entity, fc_tax_name, pnrx, no2,
		hndacs, fc_capacity, fc_warn, fc_no_new, fc_max_enrl,
		fc_opr_tory, parent_id, barrier_c, fc_cur_enrl, next_cap_date,
		net_id, contract_type, net_fc_eff_date, ovr_ride,
		net_fc_exp_date, addr_type, addr1, addr2, zip, city, [state],
		county, country, mail, con_type, con_lname, con_fname,
		title, phone1, ext1, phone2, ext2, fax
                                )
								SELECT dls_sir_id, alt_id, fc_type, fc_name, fc_stat_eff_date,
		fc_state, fc_license, fc_lrenew_dt, vendor_id, fc_tax_id,
		tin, fc_area, fc_rep, fc_source, phone_elig, fax_elig,
		print_dir, fc_mst_con_dt, emergency_phone, em_phone_ext,
		emg_contact_type, legal_entity, fc_tax_name, pnrx, no2,
		hndacs, fc_capacity, fc_warn, fc_no_new, fc_max_enrl,
		fc_opr_tory, parent_id, barrier_c, fc_cur_enrl, next_cap_date,
		net_id, contract_type, net_fc_eff_date, ovr_ride,
		net_fc_exp_date, addr_type, addr1, addr2, zip, city, [state],
		county, country, mail, con_type, con_lname, con_fname,
		title, phone1, ext1, phone2, ext2, fax
	
      FROM dls_fac_net
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'V';

	 DECLARE @cur_cnt INT ,
                            @cur_i INT;

                        SET @cur_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur_cnt = COUNT(1)
                        FROM    @cSIR;

				/*

            SET @cSIR = CURSOR  FOR SELECT dls_sir_id, alt_id, fc_type, fc_name, fc_stat_eff_date,
		fc_state, fc_license, fc_lrenew_dt, vendor_id, fc_tax_id,
		tin, fc_area, fc_rep, fc_source, phone_elig, fax_elig,
		print_dir, fc_mst_con_dt, emergency_phone, em_phone_ext,
		emg_contact_type, legal_entity, fc_tax_name, pnrx, no2,
		hndacs, fc_capacity, fc_warn, fc_no_new, fc_max_enrl,
		fc_opr_tory, parent_id, barrier_c, fc_cur_enrl, next_cap_date,
		net_id, contract_type, net_fc_eff_date, ovr_ride,
		net_fc_exp_date, addr_type, addr1, addr2, zip, city, state,
		county, country, mail, con_type, con_lname, con_fname,
		title, phone1, ext1, phone2, ext2, fax
	
      FROM #dls_fac_net
      WHERE dls_batch_id = @a_batch_id AND dls_status = 'V';
            OPEN @cSIR;
            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_alt_id, @t_fc_type,
             @t_fc_name, @t_fc_stat_eff_date, @t_fc_state, @t_fc_license,
                @t_fc_lrenew_dt, @t_vendor_id, @t_fc_tax_id, @t_tin,
                @t_fc_area, @t_fc_rep, @t_fc_source, @t_phone_elig,
                @t_fax_elig, @t_print_dir, @t_fc_mst_con_dt,
                @t_emergency_phone, @t_em_phone_ext, @t_emg_contact_type,
                @t_legal_entity, @t_fc_tax_name, @t_pnrx, @t_no2, @t_hndacs,
                @t_fc_capacity, @t_fc_warn, @t_fc_no_new, @t_fc_max_enrl,
                @t_fc_opr_tory, @t_parent_id, @t_barrier_c, @t_fc_cur_enrl,
                @t_next_cap_date, @t_net_id, @t_contract_type,
                @t_net_fc_eff_date, @t_ovr_ride, @t_net_fc_exp_date,
                @t_addr_type, @t_addr1, @t_addr2, @t_zipcode, @t_city,
  @t_state, @t_county, @t_country, @t_mail, @t_con_type,
                @t_con_lname, @t_con_fname, @t_title, @t_phone1, @t_ext1,
                @t_phone2, @t_ext2, @t_fax;
            WHILE @@FETCH_STATUS = 0
			*/

              WHILE ( @cur_i <= @cur_cnt )
            BEGIN
			SELECT  @t_sir_id             =dls_sir_id, 
			       @t_alt_id 			 =alt_id,
			       @t_fc_type			  = fc_type,
                    @t_fc_name			  =fc_name,
				   @t_fc_stat_eff_date	  =fc_stat_eff_date,
				   @t_fc_state			  =fc_state,
				   @t_fc_license		  =fc_license,
                    @t_fc_lrenew_dt		  =fc_lrenew_dt,
				   @t_vendor_id		  =vendor_id,
				   @t_fc_tax_id		  =fc_tax_id,
				   @t_tin				  =tin, 
                    @t_fc_area			  =fc_area,
				   @t_fc_rep			  =fc_rep,
				   @t_fc_source		  =fc_source, 
				   @t_phone_elig		  =phone_elig,
                    @t_fax_elig			  =fax_elig,
				   @t_print_dir		  =print_dir,
				   @t_fc_mst_con_dt	  =fc_mst_con_dt,
                    @t_emergency_phone 	 =emergency_phone,
				   @t_em_phone_ext		  =em_phone_ext,
				   @t_emg_contact_type	  =emg_contact_type,
                    @t_legal_entity 	 =legal_entity,
				   @t_fc_tax_name		  =fc_tax_name,
				   @t_pnrx				  =pnrx,
				   @t_no2				  =no2,
				   @t_hndacs			  =hndacs,
                    @t_fc_capacity		  =fc_capacity,   
				   @t_fc_warn			  =fc_warn,
				   @t_fc_no_new		  =fc_no_new,
				   @t_fc_max_enrl		  =fc_max_enrl,
                    @t_fc_opr_tory 		 =fc_opr_tory,
				   @t_parent_id		  =parent_id,
				   @t_barrier_c		  = barrier_c,
				   @t_fc_cur_enrl		  = fc_cur_enrl,
                    @t_next_cap_date 	 =next_cap_date,
				   @t_net_id 			 =net_id,
				   @t_contract_type	  =contract_type,
                    @t_net_fc_eff_date	  = net_fc_eff_date, 
				   @t_ovr_ride			  =ovr_ride,
				   @t_net_fc_exp_date	  =net_fc_exp_date, 
                    @t_addr_type		  =addr_type, 
				   @t_addr1 			 =addr1, 
				   @t_addr2 			 =addr2, 
				   @t_zipcode 			 =zip, 
				   @t_city				  =city, 
                    @t_state			  =[state],
				   @t_county 			 =county, 
				   @t_country 			 =country, 
				   @t_mail 			 =mail, 
				   @t_con_type			  =con_type,
                    @t_con_lname		  =con_lname, 
				   @t_con_fname		  =con_fname,
				   @t_title			  =title, 
				   @t_phone1			  =phone1, 
					@t_ext1				  =ext1, 
                    @t_phone2			  =phone2, 
				   @t_ext2 			 = ext2,
				   @t_fax				  =fax

            FROM    @cSIR
            WHERE   id = @cur_i;

			UPDATE dbo.GlobalVar set VarValue = @t_sir_id where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_alt_id where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_type where VarName = 't_fc_type' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_name where VarName = 't_fc_name' and  BatchId = @a_batch_id AND Module_Id = 6
			--UPDATE dbo.GlobalVar set VarValue = @t_fc_stat_eff_date where VarName = 't_fc_stat_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@t_fc_stat_eff_date,'') <>'' then STUFF(STUFF(@t_fc_stat_eff_date,3,0,'/'),6,0,'/') ELSE @t_next_cap_date END where VarName = 't_fc_stat_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_state where VarName = 't_fc_state' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_license where VarName = 't_fc_license' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_lrenew_dt where VarName = 't_fc_lrenew_dt' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_vendor_id where VarName = 't_vendor_id' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_tax_id where VarName = 't_fc_tax_id' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_tin where VarName = 't_tin' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_area where VarName = 't_fc_area' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_rep where VarName = 't_fc_rep' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_source where VarName = 't_fc_source' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_phone_elig where VarName = 't_phone_elig' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fax_elig where VarName = 't_fax_elig' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_print_dir where VarName = 't_print_dir' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_mst_con_dt where VarName = 't_fc_mst_con_dt' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_emergency_phone where VarName = 't_emergency_phone' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_em_phone_ext where VarName = 't_em_phone_ext' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_emg_contact_type where VarName = 't_emg_contact_type' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_legal_entity where VarName = 't_legal_entity' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_tax_name where VarName = 't_fc_tax_name' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_pnrx where VarName = 't_pnrx' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_no2 where VarName = 't_no2' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_hndacs where VarName = 't_hndacs' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_capacity where VarName = 't_fc_capacity' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_warn where VarName = 't_fc_warn' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_no_new where VarName = 't_fc_no_new' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_max_enrl where VarName = 't_fc_max_enrl' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_opr_tory where VarName = 't_fc_opr_tory' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_parent_id where VarName = 't_parent_id' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_barrier_c where VarName = 't_barrier_c' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fc_cur_enrl where VarName = 't_fc_cur_enrl' and  BatchId = @a_batch_id AND Module_Id = 6
			--UPDATE dbo.GlobalVar set VarValue = @t_next_cap_date where VarName = 't_next_cap_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@t_next_cap_date,'')<>'' then STUFF(STUFF(@t_next_cap_date,3,0,'/'),6,0,'/') ELSE @t_next_cap_date END  where VarName = 't_next_cap_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_net_id where VarName = 't_net_id' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_contract_type where VarName = 't_contract_type' and  BatchId = @a_batch_id AND Module_Id = 6
			--UPDATE dbo.GlobalVar set VarValue = @t_net_fc_eff_date where VarName = 't_net_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@t_net_fc_eff_date,'')<>'' then STUFF(STUFF(@t_net_fc_eff_date,3,0,'/'),6,0,'/') ELSE @t_net_fc_eff_date END where VarName = 't_net_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_ovr_ride where VarName = 't_ovr_ride' and  BatchId = @a_batch_id AND Module_Id = 6
			--UPDATE dbo.GlobalVar set VarValue = @t_net_fc_exp_date where VarName = 't_net_fc_exp_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = CASE WHEN ISNULL(@t_net_fc_exp_date,'')<>'' then STUFF(STUFF(@t_net_fc_exp_date,3,0,'/'),6,0,'/') ELSE @t_net_fc_exp_date END where VarName = 't_net_fc_exp_date' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_addr_type where VarName = 't_addr_type' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_addr1 where VarName = 't_addr1' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_addr2 where VarName = 't_addr2' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_zipcode where VarName = 't_zipcode' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_city where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_state where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_county where VarName = 't_county' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_country where VarName = 't_country' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_mail where VarName = 't_mail' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_con_type where VarName = 't_con_type' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_con_lname where VarName = 't_con_lname' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_con_fname where VarName = 't_con_fname' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_title where VarName = 't_title' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_phone1 where VarName = 't_phone1' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_ext1 where VarName = 't_ext1' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_phone2 where VarName = 't_phone2' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_ext2 where VarName = 't_ext2' and  BatchId = @a_batch_id AND Module_Id = 6
			UPDATE dbo.GlobalVar set VarValue = @t_fax where VarName = 't_fax' and  BatchId = @a_batch_id AND Module_Id = 6

                 BEGIN
                        --DECLARE #SWV_cursor_var1 CURSOR;
                        --DECLARE @SWV_cursor_var2 CURSOR;
                        BEGIN TRY
                            
                            SET @s_error = 'N';
                            SET @as_action_code = NULL 
                            
                            EXECUTE dbo.dlp_valid_fcnet @a_batch_id,
                                @d_valid_error OUTPUT, @d_error_descr OUTPUT,
                         @i_fc_id OUTPUT, @d_net_id OUTPUT,
                      @as_fc_stat_eff OUTPUT, @as_fc_net_eff OUTPUT,
                                @as_fc_net_exp OUTPUT;
                            IF @d_valid_error < 0
                                BEGIN
                                    IF @d_valid_error <> 50000
                                        SET @d_error_descr = CAST(@d_valid_error AS VARCHAR)
                                            + ':' + @d_error_descr;
                                    RAISERROR(@d_error_descr,16,1);
                                END;
                            ELSE
                                IF @d_valid_error = 0
     SET @s_error = 'Y';

	/*-- ACTION CODE: 
		FA - Facility and Facility Network Add 
		FR - Facility Reinstate
	--*/
                            SET @curr_fcstat = NULL;

							IF OBJECT_ID('tempdb..#SWV_cursor_var1') IS NOT NULL
							DROP TABLE #SWV_cursor_var1
						CREATE TABLE #SWV_cursor_var1
                        (
                         id INT IDENTITY ,
						fc_stat_id INT, 
						[status] CHAR(2),
						eff_date DATE, 
						exp_date DATE
                        );

						INSERT  INTO #SWV_cursor_var1
                                ( fc_stat_id, [status], eff_date, exp_date
                        )
                 SELECT fc_stat_id, [status], eff_date, exp_date
		
               FROM dbo.fcstat
               WHERE facility_id = @i_fc_id
               ORDER BY fc_stat_id DESC;

				DECLARE @cur1_cnt INT ,
                            @cur1_i INT;

                       SET @cur1_i = 1;
						--Get the no. of records for the cursor
      SELECT  @cur1_cnt = COUNT(1)
                        FROM    #SWV_cursor_var1;

							/*
                            SET #SWV_cursor_var1 = CURSOR  FOR SELECT fc_stat_id, status, eff_date, exp_date
		
               FROM dbo.fcstat
               WHERE facility_id = @i_fc_id
               ORDER BY fc_stat_id DESC;
                            OPEN #SWV_cursor_var1;
                            FETCH NEXT FROM #SWV_cursor_var1 INTO @curr_fcstat_id,
                                @curr_fcstat, @curr_fcstat_eff,
                                @curr_fcstat_exp;
                            WHILE @@FETCH_STATUS = 0
							*/

                                WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
			SELECT  @curr_fcstat_id =fc_stat_id,
                    @curr_fcstat=[status], 
					@curr_fcstat_eff=eff_date,
                    @curr_fcstat_exp=exp_date
            FROM    #SWV_cursor_var1
            WHERE   id = @cur1_i;
                                    GOTO SWL_Label3;
                                    --FETCH NEXT FROM #SWV_cursor_var1 INTO @curr_fcstat_id,
                                    --    @curr_fcstat, @curr_fcstat_eff,
                                    --    @curr_fcstat_exp;
									SET @cur1_i = @cur1_i + 1;
                                END;
                            SWL_Label3:
                            --CLOSE #SWV_cursor_var1;
                            IF ( @curr_fcstat IS NULL
                                 OR @curr_fcstat = ''
                               )
                                BEGIN
                                    SET @as_action_code = 'FA' ;
    
                                   EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
               @as_action_code,
                                                             @as_fc_stat_eff;
                                    
                                    IF ( @t_net_fc_exp_date IS NOT NULL
                                         AND @t_net_fc_exp_date <> ''
                                       )
									  BEGIN
									  SET @a_error_no = 201
                                        RAISERROR('Will ignore Tape Network Facility Exp Date for FC Add Action',16,1);
					RETURN
					END
                                END;
                            ELSE
BEGIN
                                    IF @as_fc_stat_eff < @curr_fcstat_eff
									BEGIN
									SET @a_error_no = 200
                                        RAISERROR('Incoming Facility Status Effective Date is before current status eff date',16,1);
										RETURN
										END
                                    ELSE
                                        BEGIN
                                           
                                            IF @as_fc_stat_eff < @curr_fcstat_exp
											BEGIN
											SET @a_error_no = 205
                                                RAISERROR('Incoming Facility Status Effective Date is before current status exp date',16,1);
												RETURN
												END
                                            ELSE
                                                IF @curr_fcstat <> 'AC'
                                                    BEGIN
     SET @as_action_code = 'FR' 
                                                        
           EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
       @t_sir_id,
             @as_action_code,
                                                               @as_fc_stat_eff;
                                                       
   IF ( @t_net_fc_exp_date IS NOT NULL
      AND @t_net_fc_exp_date <> ''
                                                           )
														  BEGIN
														  SET @a_error_no = 201
                                                            RAISERROR('Will ignore Tape Network Facility Exp Date for FC Add Action',
                           16,1);
						  RETURN
						  END
                                                    END;
			
                                        END;
                                END;
	

	/*-- ACTION CODE: 
		NA - Facility Network Add 
		NC - No Change (no Facility Network date change)
		NR - Facility Network Reinstate
		NT - Facility Network Terminate (Existing or Missing)
	--*/
                           
                            IF ( @as_action_code IS NULL
                                 OR @as_action_code = ''
                    )
		
--		ELIF t_contract_type = "PPO" 
--		and n_net_id is not null and n_net_id > 0 and n_net_id = d_net_id THEN
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.net_facility
                                            WHERE   net_id <> @d_net_id
                                                    AND fc_id = @i_fc_id
                                                    AND con_type = 'PPO'
                                                    AND eff_date <= @as_fc_net_eff
                                                    AND ( exp_date IS NULL
                 OR exp_date > @as_fc_net_eff
                                                        ) )
														BEGIN
														SET @a_error_no = 210
                                    RAISERROR('Cannot process because the Facility is with another PPO Network',
                     16,1);
					RETURN
					END
                                ELSE
                                    BEGIN
                                        
 IF @t_contract_type = 'PPO'
                                            BEGIN
                                                
												SELECT @t_net_fc_eff_date=VarValue from dbo.GlobalVar where VarName = 't_net_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 6 
                                                SET @tape_fcnet_eff = CAST(@t_net_fc_eff_date AS DATE)--Modified for Conversion issue varbinary to date against CH001
                                                
             SET @tape_fcnet_exp = @t_net_fc_exp_date --Modified for Conversion issue varbinary to date against CH001
                                                SET @curr_fcnet_id = NULL;
                                                SET @curr_fcnet_eff = NULL;
                                                SET @curr_fcnet_exp = NULL;

												DECLARE @SWV_cursor_var2 TABLE
                        (
                         id INT IDENTITY ,
						net_fc_id INT, 
						eff_date DATE, 
						exp_date DATE
                        );

						INSERT  INTO @SWV_cursor_var2
                                ( net_fc_id, eff_date, exp_date
                                )
                                SELECT net_fc_id, eff_date, exp_date
			
                        FROM dbo.net_facility
                        WHERE net_id = @d_net_id
                        AND fc_id = @i_fc_id
                        AND con_type = 'PPO'
                        ORDER BY net_fc_id DESC;

				DECLARE @cur2_cnt INT ,
                            @cur2_i INT;

                        SET @cur2_i = 1;
						--Get the no. of records for the cursor
                        SELECT  @cur2_cnt = COUNT(1)
     FROM   @SWV_cursor_var2;


												/*
     SET @SWV_cursor_var2 = CURSOR  FOR SELECT net_fc_id, eff_date, exp_date
			
                        FROM dbo.net_facility
                        WHERE net_id = @d_net_id
                        AND fc_id = @i_fc_id
   AND con_type = 'PPO'
         ORDER BY net_fc_id DESC;
         OPEN @SWV_cursor_var2;
    FETCH NEXT FROM @SWV_cursor_var2 INTO @curr_fcnet_id,
                                                    @curr_fcnet_eff,
                                                    @curr_fcnet_exp;
        WHILE @@FETCH_STATUS = 0
												*/
                                                  

												 WHILE ( @cur2_i <= @cur2_cnt )
                                                  BEGIN
			                                     SELECT  @curr_fcnet_id =net_fc_id,
                                                          @curr_fcnet_eff =eff_date,
                                                          @curr_fcnet_exp =exp_date
                                                  FROM    @SWV_cursor_var2
                                                  WHERE   id = @cur2_i;

                                         GOTO SWL_Label4;
                                                        --FETCH NEXT FROM @SWV_cursor_var2 INTO @curr_fcnet_id,
                                                        --    @curr_fcnet_eff,
 --    @curr_fcnet_exp;
														SET @cur2_i = @cur2_i + 1;
                                                    END;
                                                SWL_Label4:
                                                --CLOSE @SWV_cursor_var2;
                                                IF @curr_fcnet_id IS NULL
                                                    BEGIN
                                                        SET @as_action_code ='NA'
                                                        
															
															EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @as_fc_net_eff;

                                           
                                                        IF ( @t_net_fc_exp_date IS NOT NULL
                                                             AND @t_net_fc_exp_date <> ''
                                                           )
														  BEGIN
														  SET @a_error_no = 201
                                                            RAISERROR('Will ignore Tape Network Facility Exp Date for FC Add Action',
                              16,1);
							 RETURN
							 END
                                                    END;
              ELSE
                                                    BEGIN
                                                        
         IF ( @t_net_fc_eff_date IS NULL
                                                             OR @t_net_fc_eff_date = ''
                                                           )
   BEGIN
                                                              
                                                              IF ( @t_net_fc_exp_date IS NOT NULL
                                                              AND @t_net_fc_exp_date <> ''
                                                              )
															 BEGIN
															 SET @a_error_no = 220
      RAISERROR('FC NET Eff Date cannot be null when FC NET Exp Date is provided',
                                 16,1);
								RETURN
								END
                                                              ELSE
  BEGIN
                                                              SET @as_action_code = 'NC' 
    
                           EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                         @t_sir_id,
                        @as_action_code,
                             @as_fc_net_eff;
  END;
                                                            END;
                                                      ELSE
                                                            IF @tape_fcnet_eff < @curr_fcnet_eff
															BEGIN
															SET @a_error_no = 230
                                                              RAISERROR('Incoming Facility Network Effective Date is before current network date',16,1);
															 RETURN
															 END
                                                            ELSE
                                                              BEGIN
                                                              
                                                              IF ( @t_net_fc_exp_date IS NULL
                                             OR @t_net_fc_exp_date = ''
                                                              )
                                                              AND @curr_fcnet_exp IS NULL
                                                              BEGIN
                                                              SET @as_action_code = 'NC' 
                                                              
               EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @as_fc_net_eff;
                                                              END;
                                         ELSE
                                                              BEGIN
               
                                                              IF ( @t_net_fc_exp_date IS NOT NULL
                                                              AND @t_net_fc_exp_date <> ''
                                                              )
                                                              AND @curr_fcnet_exp IS NULL
                                BEGIN
                                                              SET @as_action_code = 'NT' 
               
                         EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @as_fc_net_exp;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              
                                                              IF ( @t_net_fc_exp_date IS NULL
                                                              OR @t_net_fc_exp_date = ''
                                                              )
                                                              AND @curr_fcnet_exp IS NOT NULL
                                                              BEGIN
                                                              SET @as_action_code = 'NR' 
           
                                                              IF @curr_fcnet_exp > @as_fc_net_eff
                                    BEGIN
                                                       
                         EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                     @as_action_code,
                                         @curr_fcnet_exp;
                  END;
                                         ELSE
       BEGIN
                         
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @as_fc_net_eff;
                                                              END;
				
                                                              
                                                              IF ( @t_net_fc_exp_date IS NOT NULL
                                                              AND @t_net_fc_exp_date <> ''
                                                              )
															 BEGIN
															 SET @a_error_no = 201
                                                              RAISERROR('Will ignore Tape Network Facility Exp Date for FC Add Action',
                                          16,1);
										 RETURN
										 END
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                             
                                                              IF ( @t_net_fc_exp_date IS NOT NULL
                                                              AND @t_net_fc_exp_date <> ''
                                                              )
                                                              AND @curr_fcnet_exp IS NOT NULL
                                                              IF @tape_fcnet_eff < @curr_fcnet_eff
															 BEGIN
															 SET @a_error_no = 240
                                                              RAISERROR('Given effective date cannot reinstate a terminated network record',
                                             16,1);
											RETURN
											END
                        ELSE
                                                              BEGIN
         SET @as_action_code = 'NR'
                              
                                                              IF @curr_fcnet_exp > @as_fc_net_eff
                                               BEGIN
                                                              
                               EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
          @as_action_code,
                                                              @curr_fcnet_exp;
                                                              END;
                                                              ELSE
                                                              BEGIN
                                                              
                                                              EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @as_fc_net_eff;
                                                 END;
					
                                 
                                                              IF ( @t_net_fc_exp_date IS NOT NULL
                                                              AND @t_net_fc_exp_date <> ''
                                                              )
															 BEGIN
															 SET @a_error_no = 201
                                 RAISERROR('Will ignore Tape Network Facility Exp Date for FC Add Action',
        16,1);
												RETURN
												END
                   END;
                                                 ELSE
                                                              BEGIN
                                                       SET @as_action_code ='NC' 
                                                              
                                               EXECUTE @n_error_no = dbo.dl_log_action @a_batch_id,
                                                              @t_sir_id,
                                                              @as_action_code,
                                                              @as_fc_net_eff;
                                      END;
                                               END;
                                                              END;
                                                              END;
                                                              END;
                                                    END;
                                            END;
                                    END;
	
                        IF @s_error = 'Y'
                                BEGIN
                                    SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6

                                    SET @n_process_count = @n_process_count + 1;

									UPDATE GlobalVar
									SET VarValue = @n_process_count
									WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
                                    
                                    UPDATE  dls_fac_net
                                    SET     dls_status = 'E' ,
                                            dls_facility_id = @i_fc_id ,
                                            dls_network_id = @d_net_id ,
                                            dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
                            ELSE
                                BEGIN
                          
									SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
									SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6

                                    SET @n_process_count = @n_process_count+ 1;
                                                       
                                    SET @n_succ_count = @n_succ_count + 1;

									UPDATE GlobalVar
									SET VarValue = @n_process_count
									WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6


									UPDATE GlobalVar
									SET VarValue = @n_succ_count
									WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
                                   
                                    UPDATE  dls_fac_net
                                    SET     dls_status = 'P' ,
                                            dls_facility_id = @i_fc_id ,
                                            dls_network_id = @d_net_id ,
                                            dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;

                            	SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
								SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6

                            IF @n_process_count % 100 = 0
							UPDATE  dl_bat_statistics
              SET     tot_record = @n_process_count ,
                                        tot_success_rec = @n_succ_count ,
         tot_fail_rec = @n_process_count- @n_succ_count
                                WHERE   bat_statistics_id = @i_statistics_id;
	
                            
                        END TRY

							BEGIN CATCH

							IF ERROR_NUMBER() = 50000
							BEGIN
							EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
															@i_sp_id,
  @i_sir_def_id,
                                                             @t_sir_id, @a_error_no;
							END

                            SET @i_error_no = ERROR_NUMBER();
							SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)  + ':' + @s_error_descr;
								RAISERROR(@s_error_descr,16,1);
							END;
		
    
               --             EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id,
															--@i_sp_id,
               --                                              @i_sir_def_id,
               --                                              @t_sir_id, 0;
								IF @i_fatal <> 1
                                SET @s_error = 'Y';

								  IF @s_error = 'Y'
                                BEGIN
                                    SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
									

                                    SET @n_process_count = @n_process_count+ 1;

									UPDATE GlobalVar
									SET VarValue = @n_process_count
									WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
                                    
                                    UPDATE  dls_fac_net
                                    SET     dls_status = 'E' ,
                                            dls_facility_id = @i_fc_id ,
                                            dls_network_id = @d_net_id ,
                                            dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;
                            ELSE
                                BEGIN

								SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
									SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
                                    
                                    SET @n_process_count = @n_process_count+ 1;
                                                 
                                    SET @n_succ_count = @n_succ_count + 1;

									UPDATE GlobalVar
									SET VarValue = @n_process_count
									WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6

									UPDATE GlobalVar
									SET VarValue = @n_succ_count
									WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
                                   
                                    UPDATE  dls_fac_net
                                    SET     dls_status = 'P' ,
                                            dls_facility_id = @i_fc_id ,
                                            dls_network_id = @d_net_id ,
                                            dls_action_code = @as_action_code
                                    WHERE   dls_batch_id = @a_batch_id
                                            AND dls_sir_id = @t_sir_id;
                                END;


								 SET @SWP_Ret_Value = -1;
								SET @SWP_Ret_Value1 = @s_error_descr;
                        END CATCH;
                    END;
					/*
      FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_alt_id,
                        @t_fc_type, @t_fc_name, @t_fc_stat_eff_date,
                        @t_fc_state, @t_fc_license, @t_fc_lrenew_dt,
                        @t_vendor_id, @t_fc_tax_id, @t_tin, @t_fc_area,
                        @t_fc_rep, @t_fc_source, @t_phone_elig, @t_fax_elig,
                        @t_print_dir, @t_fc_mst_con_dt, @t_emergency_phone,
                        @t_em_phone_ext, @t_emg_contact_type, @t_legal_entity,
                        @t_fc_tax_name, @t_pnrx, @t_no2, @t_hndacs,
                        @t_fc_capacity, @t_fc_warn, @t_fc_no_new,
                        @t_fc_max_enrl, @t_fc_opr_tory, @t_parent_id,
                        @t_barrier_c, @t_fc_cur_enrl, @t_next_cap_date,
                        @t_net_id, @t_contract_type, @t_net_fc_eff_date,
                        @t_ovr_ride, @t_net_fc_exp_date, @t_addr_type,
                        @t_addr1, @t_addr2, @t_zipcode, @t_city, @t_state,
                        @t_county, @t_country, @t_mail, @t_con_type,
             @t_con_lname, @t_con_fname, @t_title, @t_phone1,
                        @t_ext1, @t_phone2, @t_ext2, @t_fax;
						*/
						SET @cur_i = @cur_i + 1;
                END;
            --CLOSE @cSIR;
            IF @a_sir_id = 0
                BEGIN
                   
                    SET @SWV_func_DLP_FC_MISSING_par0 =  @d_def_exp_date
					select @SWV_func_DLP_FC_MISSING_par0
                   EXECUTE @i_error_no = dbo.dlp_fc_missing @a_batch_id,
                                                         @n_net_id,
                                               @SWV_func_DLP_FC_MISSING_par0;
					IF @i_error_no < 0
					BEGIN
						SET @a_error_no = 0
                        RAISERROR('Error in Search Missing Records',16,1);
						RETURN
						END
                END;

				SELECT @n_process_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_process_count' AND  BatchId = @a_batch_id AND Module_Id = 6
				SELECT @n_succ_count = VarValue FROM  GlobalVar(NOLOCK) WHERE VarName ='n_succ_count' AND  BatchId = @a_batch_id AND Module_Id = 6
            
            SET @n_error_count =@n_process_count - @n_succ_count  --Modified for Conversion issue varbinary to date against CH001 
            
         DECLARE @SWV_dl_upd_statistics INT;
			EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @n_process_count,
                                     @n_succ_count, @n_error_count
			IF @SWV_dl_upd_statistics <>1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    
                    SET @SWP_Ret_Value1 = CONCAT(( @n_succ_count
                                           + @n_error_count ),
                                                 ' Failed to update statistics');
						IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 6 AND BatchId = @a_batch_id )
						BEGIN
							DELETE FROM GlobalVar WHERE Module_Id = 6 AND BatchId = @a_batch_id
						END
                    RETURN;
                END;

            UPDATE  dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finish Pre-Processing for Batch ', @a_batch_id);
			IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 6 AND BatchId = @a_batch_id )
			BEGIN
				DELETE FROM GlobalVar WHERE Module_Id = 6 AND BatchId = @a_batch_id
			END
            RETURN;
        END TRY
        BEGIN CATCH
			IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 6 AND BatchId = @a_batch_id )
			BEGIN
				DELETE FROM GlobalVar WHERE Module_Id = 6 AND BatchId = @a_batch_id
			END
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_error_descr;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

--trace off;



--set debug file to "/tmp/dlp_bu_fac_net.trc";
--trace on;

    END;