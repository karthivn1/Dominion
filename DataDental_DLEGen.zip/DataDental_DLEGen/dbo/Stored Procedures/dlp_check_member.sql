﻿CREATE PROCEDURE [dbo].[dlp_check_member]
@a_subscriber CHAR(2) ,
@a_batch_id INT ,
@a_sir_id INT ,
@a_family_id INT ,
@SWP_Ret_Value INT = NULL OUTPUT ,
@SWP_Ret_Value1 INT = NULL OUTPUT ,
@SWP_Ret_Value2 INT = NULL OUTPUT

AS
BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
DECLARE @i_error_no INT;
DECLARE @i_isam_error INT;
DECLARE @s_error_descr VARCHAR(64);
DECLARE @i_fatal INT;
DECLARE @i_fuzzy_match INT;
DECLARE @a_error_no INT;
DECLARE @s_found_error CHAR(1);
DECLARE @i_member_id INT;
DECLARE @i_family_id INT;
DECLARE @i_count INT;
DECLARE @li_count INT;
DECLARE @s_last_name CHAR(15);
DECLARE @s_first_name CHAR(15);
DECLARE @d_date_of_birth DATE;
DECLARE @s_middle_init CHAR(1);
DECLARE @ls_process_date char(10);
DECLARE @ld_process_date date;
DECLARE @n_lookup_ssn_alt char(1);
DECLARE @n_has_facility_id char(1);
DECLARE @n_has_multiple_gp char(1);
DECLARE @n_add_to_cl_fc char(1);
DECLARE @n_has_rate_code char(1);
DECLARE @n_has_address char(1);
DECLARE @n_sub_age char(11);
DECLARE @n_has_plan_eff char(1);
DECLARE @n_has_fac_eff char(1);
DECLARE @n_has_s_plan_term char(1);
DECLARE @n_has_d_plan_term char(1);
DECLARE @d_process_date date;
DECLARE @i_sub_age integer;
DECLARE @s_sub_age char(11);
DECLARE @t_sir_id integer;
DECLARE @t_sub_sir_id integer;
DECLARE @t_subscriber char(2);
DECLARE @t_alt_id char(20);
DECLARE @t_ssn char(11);
DECLARE @t_sub_ssn char(11);
DECLARE @t_sub_alt_id char(20);
DECLARE @t_member_code char(2);
DECLARE @t_last_name char(15);
DECLARE @t_first_name char(15);
DECLARE @t_middle_init char(1);
DECLARE @t_date_of_birth date;
DECLARE @t_student_flag char(1);
DECLARE @t_disable_flag char(1);
DECLARE @t_cobra_flag char(1);
DECLARE @t_address1 char(30);
DECLARE @t_address2 char(30);
DECLARE @t_city char(30);
DECLARE @t_state char(2);
DECLARE @t_zip char(5);
DECLARE @t_zipx char(4);
DECLARE @t_home_phone char(10);
DECLARE @t_home_ext char(4);
DECLARE @t_work_phone char(10);
DECLARE @t_work_ext char(4);
DECLARE @t_rate_code char(2);
DECLARE @t_plan_eff_date date;
DECLARE @t_plan_term_date date;
DECLARE @t_fac_eff_date date;
DECLARE @t_group_id integer;
DECLARE @t_plan_id integer;
DECLARE @t_facility_id integer;
DECLARE @t_def_key char(2);
DECLARE @t_type char(2);
DECLARE @t_sub_id integer;
DECLARE @t_member_id integer;
DECLARE @i_config_id integer;
DECLARE @i_sp_id int;
DECLARE @i_sir_def_id INT;
--DECLARE @SWV_cursor_var1 CURSOR;
--DECLARE @SWV_cursor_var2 CURSOR;
--DECLARE @SWV_cursor_var3 CURSOR;
--DECLARE @SWV_cursor_var4 CURSOR;
--DECLARE @SWV_cursor_var5 CURSOR;
--DECLARE @SWV_cursor_var6 CURSOR;
　
SET NOCOUNT ON;
SET @i_sp_id =0;
SET @i_sir_def_id =0; 
SET @ls_process_date = ''; 
SET @ld_process_date = NULL; 
SET @n_lookup_ssn_alt = ''; 
SET @n_has_facility_id = ''; 
SET @n_has_multiple_gp = ''; 
SET @n_add_to_cl_fc = ''; 
SET @n_has_rate_code = ''; 
SET @n_has_address = ''; 
SET @n_sub_age = ''; 
SET @n_has_plan_eff = ''; 
SET @n_has_fac_eff = ''; 
SET @n_has_s_plan_term = ''; 
SET @n_has_d_plan_term = ''; 
SET @d_process_date = NULL; 
SET @i_sub_age =0; 
SET @s_sub_age = ''; 
SET @t_sir_id =0; 
SET @t_sub_sir_id =0; 
SET @t_subscriber = ''; 
SET @t_alt_id = ''; 
SET @t_ssn = ''; 
SET @t_sub_ssn = ''; 
SET @t_sub_alt_id = ''; 
SET @t_member_code = ''; 
SET @t_last_name = ''; 
SET @t_first_name = ''; 
SET @t_middle_init = ''; 
SET @t_date_of_birth = NULL; 
SET @t_student_flag = ''; 
SET @t_disable_flag = ''; 
SET @t_cobra_flag = ''; 
SET @t_address1 = ''; 
SET @t_address2 = ''; 
SET @t_city = ''; 
SET @t_state = ''; 
SET @t_zip = ''; 
SET @t_zipx = ''; 
SET @t_home_phone = ''; 
SET @t_home_ext = ''; 
SET @t_work_phone = ''; 
SET @t_work_ext = ''; 
SET @t_rate_code = ''; 
SET @t_plan_eff_date = NULL; 
SET @t_plan_term_date = NULL; 
SET @t_fac_eff_date = NULL; 
SET @t_group_id =0; 
SET @t_plan_id =0; 
SET @t_facility_id =0; 
SET @t_def_key = ''; 
SET @t_type = ''; 
SET @t_sub_id =0; 
SET @t_member_id =0; 
SET @i_config_id =0;
BEGIN TRY

SELECT @t_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_subscriber = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_subscriber' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_member_code' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_last_name' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_first_name' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_middle_init' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_student_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_cobra_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address1' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_address2' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_city' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_state' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zip' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_zipx' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_home_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_phone' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_work_ext' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_rate_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_rate_code' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_term_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_term_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_fac_eff_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_fac_eff_date' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_group_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_group_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_plan_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_plan_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_facility_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_facility_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_def_key = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_def_key' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @t_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_type' and  BatchId = @a_batch_id AND Module_Id = 3
select @i_sir_def_id = VarValue from GlobalVar(NOLOCK) where  VarName = 'i_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @i_sp_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'i_sp_id' and  BatchId = @a_batch_id AND Module_Id = 3
SELECT @n_lookup_ssn_alt = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_lookup_ssn_alt' and  BatchId = @a_batch_id AND Module_Id = 3

	EXECUTE @i_sir_def_id = dbo.dl_get_sir_def_id 'elig';
	EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'bu_eligibility';

SET @s_found_error = 'N';
SET @i_member_id = NULL;
SET @i_family_id = NULL;
SET @i_count = 0;
SET @i_fuzzy_match = 1;
IF @n_lookup_ssn_alt = 'A'
BEGIN
IF ( @t_alt_id IS NULL
--OR @t_alt_id = ''
)
OR LEN(@t_alt_id) = 0
BEGIN
SET @i_isam_error = 12
RAISERROR('Missing Member''s alt_id',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';

END
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'S'
BEGIN
IF ( @t_ssn IS NULL
OR @t_ssn = ''
)
OR LEN(@t_ssn) = 0
BEGIN
SET @i_isam_error = 1
RAISERROR('Missing Member''s SSN',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
END;
/* Next block added for APIS */
IF @n_lookup_ssn_alt = 'Z' -- get ids from SIR record
BEGIN
SELECT @i_member_id = dls_member_id ,
@i_family_id = dls_sub_id
FROM dbo.dls_elig (NOLOCK)
WHERE dls_sir_id = @a_sir_id;
IF @i_family_id = 0
BEGIN
SET @i_family_id = NULL;
IF @i_member_id != 0
BEGIN
SET @i_isam_error = 12
RAISERROR('Missing Family ID',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
ELSE
SET @i_member_id = NULL;
END;
IF @i_member_id = 0
SET @i_member_id = NULL;
IF @i_member_id IS NULL
BEGIN
SET @SWP_Ret_Value = 0;
SET @SWP_Ret_Value1 = @i_member_id;
SET @SWP_Ret_Value2 = @i_family_id;
RETURN;
END;
ELSE
BEGIN
SET @SWP_Ret_Value = 2;
SET @SWP_Ret_Value1 = @i_member_id;
SET @SWP_Ret_Value2 = @i_family_id;
RETURN;
END; ---Force system update
END;
IF @t_subscriber = '00' -- Subscriber
BEGIN
-- Use Unique Alt. search
-- Incorporate Group IDs in batch configuration setup into lookup.
-- Use Fuzzy Logic search
/*
20130906$$cs - added t_def_key and t_type values to determine if
subscriber exists more than once.
*/
--check member by ssn
/*
20130906$$cs - added t_def_key and t_type values to determine if
subscriber exists more than once.
*/
IF @n_lookup_ssn_alt = 'U'
BEGIN
SET @li_count = 0;
/*
SET @SWV_cursor_var1 = CURSOR FOR SELECT a.member_id, a.family_id
FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
WHERE a.member_id = a.family_id
AND a.family_id = b.member_id
AND a.alt_id = @t_alt_id
AND b.group_id IN(SELECT group_id
FROM dbo.dlsp_eg_group_plan (NOLOCK)
WHERE config_id = @i_config_id);
OPEN @SWV_cursor_var1;
FETCH NEXT FROM @SWV_cursor_var1 INTO @i_member_id, @i_family_id;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var1 TABLE
(
id INT IDENTITY ,
member_id INT, family_id INT
);
INSERT INTO @SWV_cursor_var1
( member_id, family_id
)
SELECT a.member_id, a.family_id 
FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
WHERE a.member_id = a.family_id
AND a.family_id = b.member_id
AND a.alt_id = @t_alt_id
AND b.group_id IN(SELECT group_id
FROM dbo.dlsp_eg_group_plan (NOLOCK)
WHERE config_id = @i_config_id);
DECLARE @cur1_cnt INT ,
@cur_i INT;
SET @cur_i = 1;
--Get the no. of records for the cursor
SELECT @cur1_cnt = COUNT(1)
FROM @SWV_cursor_var1;
WHILE ( @cur_i <= @cur1_cnt )
BEGIN
SELECT @i_member_id = member_id, @i_family_id = family_id
FROM @SWV_cursor_var1
WHERE id = @cur_i;
SET @li_count = @li_count + 1;
-- FETCH NEXT FROM @SWV_cursor_var1 INTO @i_member_id, @i_family_id;
SET @cur_i = @cur_i + 1;
END;
--CLOSE @SWV_cursor_var1;
-- added by ameeta on 06/08/00
IF @li_count > 1
BEGIN
SET @i_isam_error = 40
RAISERROR('Found more than one member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
--
IF @li_count = 1
AND @i_member_id IS NOT NULL
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = @i_member_id;
SET @SWP_Ret_Value2 = @i_family_id;
RETURN;
END;
IF @li_count = 0
-- Use fuzzy logic here
BEGIN
EXECUTE dbo.dlp_chk_sub_fuzzy @a_subscriber,
@a_batch_id, @a_sir_id, @a_family_id,
@i_fuzzy_match OUTPUT,
@i_member_id OUTPUT,
@i_family_id OUTPUT;
IF @i_fuzzy_match = -1
SET @s_found_error = 'Y';
END;
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'F'
BEGIN
EXECUTE dbo.dlp_chk_sub_fuzzy @a_subscriber,
@a_batch_id, @a_sir_id, @a_family_id,
@i_fuzzy_match OUTPUT,
@i_member_id OUTPUT,
@i_family_id OUTPUT;
IF @i_fuzzy_match = -1
SET @s_found_error = 'Y';
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'A'
BEGIN
IF EXISTS ( SELECT
*
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND alt_id = @t_alt_id
AND member_flag = @t_subscriber
AND def_key != 'FI'
AND def_key = @t_def_key
AND type = @t_type
AND dls_sir_id != @t_sir_id
AND dls_source = 'F' )
BEGIN
SET @i_isam_error = 40
RAISERROR('Duplicate subscriber records',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
/*
SET @SWV_cursor_var2 = CURSOR FOR SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE alt_id = @t_alt_id AND
member_id = family_id;
OPEN @SWV_cursor_var2;
FETCH NEXT FROM @SWV_cursor_var2 INTO @i_member_id,
@i_family_id, @s_last_name,
@s_first_name, @s_middle_init,
@d_date_of_birth;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var2 TABLE
(
id INT IDENTITY ,
member_id int, family_id int, last_name char(15), first_name char(15),middle_init char(1), date_of_birth date
);
INSERT INTO @SWV_cursor_var2
( member_id, family_id, last_name, first_name, middle_init, date_of_birth
)
SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE alt_id = @t_alt_id AND
member_id = family_id;
DECLARE @cur2_cnt INT ,
@cur2_i INT;
SET @cur2_i = 1;
--Get the no. of records for the cursor
SELECT @cur2_cnt = COUNT(1)
FROM @SWV_cursor_var2;
WHILE ( @cur2_i <= @cur2_cnt )
BEGIN
SELECT @i_member_id = member_id,
@i_family_id = family_id, 
@s_last_name = last_name,
@s_first_name = first_name, 
@s_middle_init = middle_init,
@d_date_of_birth = date_of_birth
FROM @SWV_cursor_var2
WHERE id = @cur2_i;
SET @i_count = @i_count + 1;
--FETCH NEXT FROM @SWV_cursor_var2 INTO @i_member_id,
-- @i_family_id,
-- @s_last_name,
-- @s_first_name,
-- @s_middle_init,
-- @d_date_of_birth;
SET @cur2_i = @cur2_i + 1;
END;
--CLOSE @SWV_cursor_var2;
IF @i_count = 0
BEGIN
IF ( @t_ssn IS NULL
OR @t_ssn = ''
)
OR LEN(@t_ssn) = 0
BEGIN
SET @i_isam_error = 1
RAISERROR('Missing Member''s SSN',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
IF @i_count = 1
BEGIN
IF @s_last_name <> @t_last_name
BEGIN
SET @i_isam_error = 6
RAISERROR('Last Name mismatch for existing member',0,1)
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
---- RETURN
END
IF @s_first_name <> @t_first_name
BEGIN
SET @i_isam_error = 7
RAISERROR('First Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF @t_date_of_birth != '01/01/1900'
AND @t_date_of_birth <> @d_date_of_birth
BEGIN
SET @i_isam_error = 8
RAISERROR('Date of Birth mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
IF @i_count > 1
BEGIN
SET @a_error_no = 39;
SELECT @i_member_id = member_id ,
@i_family_id = family_id
FROM dbo.member (NOLOCK)
WHERE alt_id = @t_alt_id
AND member_id = family_id
AND last_name = @t_last_name
AND first_name = @t_first_name
AND ( ( ( ( @t_middle_init IS NULL
OR @t_middle_init = ''
)
OR LEN(@t_middle_init) = 0
OR @t_middle_init = ' '
)
OR ( LEN(middle_init) = 0
OR middle_init IS NULL
OR middle_init = ' '
)
)
OR ( ( @t_middle_init IS NOT NULL
AND @t_middle_init <> ''
)
AND middle_init = @t_middle_init
)
)
AND ( ( date_of_birth = @t_date_of_birth
AND @t_date_of_birth != '01/01/1900'
AND date_of_birth != '01/01/1900'
)
OR ( @t_date_of_birth = '01/01/1900'
OR date_of_birth = '01/01/1900'
)
);
END;
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'S'
BEGIN
IF EXISTS ( SELECT
*
FROM
dbo.dls_elig (NOLOCK)
WHERE
dls_batch_id = @a_batch_id
AND dls_sir_id != @t_sir_id
AND member_flag = @t_subscriber
AND ssn = @t_ssn
AND def_key = @t_def_key
AND type = @t_type
AND dls_sub_sir_id != @t_sub_sir_id
AND dls_source = 'F' )
BEGIN
SET @i_isam_error = 41
RAISERROR('Duplication records found based on ssn',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
/*
SET @SWV_cursor_var3 = CURSOR FOR SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE member_ssn = @t_sub_ssn AND
member_id = family_id;
OPEN @SWV_cursor_var3;
FETCH NEXT FROM @SWV_cursor_var3 INTO @i_member_id,
@i_family_id,
@s_last_name,
@s_first_name,
@s_middle_init,
@d_date_of_birth;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var3 TABLE
(
id INT IDENTITY ,
member_id int, family_id int, last_name char(15), first_name char(15),middle_init char(1), date_of_birth date
);
INSERT INTO @SWV_cursor_var3
( member_id, family_id, last_name, first_name,
middle_init, date_of_birth
)
SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE member_ssn = @t_sub_ssn AND
member_id = family_id;
DECLARE @cur3_cnt INT ,
@cur3_i INT;
SET @cur3_i = 1;
--Get the no. of records for the cursor
SELECT @cur3_cnt = COUNT(1)
FROM @SWV_cursor_var3;
WHILE ( @cur3_i <= @cur3_cnt )
BEGIN
SELECT @i_member_id = member_id,
@i_family_id = family_id, 
@s_last_name = last_name,
@s_first_name = first_name, 
@s_middle_init = middle_init,
@d_date_of_birth = date_of_birth
FROM @SWV_cursor_var3
WHERE id = @cur3_i;
SET @i_count = @i_count
+ 1;
--FETCH NEXT FROM @SWV_cursor_var3 INTO @i_member_id,
-- @i_family_id,
-- @s_last_name,
-- @s_first_name,
-- @s_middle_init,
-- @d_date_of_birth;
SET @cur3_i = @cur3_i + 1;
END;
--CLOSE @SWV_cursor_var3;
IF @i_count = 0
BEGIN
IF ( @t_ssn IS NULL
OR @t_ssn = ''
)
OR LEN(@t_ssn) = 0
BEGIN
SET @i_isam_error = 1
RAISERROR('Missing Member''s SSN',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
IF @i_count = 1
BEGIN
IF @s_last_name <> @t_last_name
BEGIN
SET @i_isam_error = 6
RAISERROR('Last Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF @s_first_name <> @t_first_name
BEGIN
SET @i_isam_error = 7
RAISERROR('First Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF @t_date_of_birth != '01/01/1900'
AND @t_date_of_birth <> @d_date_of_birth
BEGIN
SET @i_isam_error = 8
RAISERROR('Date of Birth mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
---- RETURN
END
END;
IF @i_count > 1
BEGIN
SET @a_error_no = 38;
SELECT
@i_member_id = member_id ,
@i_family_id = family_id
FROM
dbo.member (NOLOCK)
WHERE
member_ssn = @t_sub_ssn
AND member_id = family_id
AND last_name = @t_last_name
AND first_name = @t_first_name
AND ( ( ( ( @t_middle_init IS NULL
OR @t_middle_init = ''
)
OR LEN(@t_middle_init) = 0
OR @t_middle_init = ' '
)
OR ( LEN(middle_init) = 0
OR middle_init IS NULL
OR middle_init = ' '
)
)
OR ( ( @t_middle_init IS NOT NULL
AND @t_middle_init <> ''
)
AND middle_init = @t_middle_init
)
)
AND ( ( date_of_birth = @t_date_of_birth
AND @t_date_of_birth != '01/01/1900'
)
OR ( @t_date_of_birth = '01/01/1900'
OR date_of_birth = '01/01/1900'
)
);
END;
END;
END;
END;
END;
END;
ELSE
--check dependent record by ssn or alt_id
/* 20140104$$ks - i_family_id not always being set for DA conditions
*/
BEGIN
IF @a_family_id IS NOT NULL
AND @a_family_id > 0
SET @i_family_id = @a_family_id;
-- Use Unique Alt. search
-- Incorporate Group IDs in batch configuration setup into lookup.
-- Use Fuzzy Logic search
--check dependent by ssn
IF @n_lookup_ssn_alt = 'U'
BEGIN
SET @li_count = 0;
/*
SET @SWV_cursor_var4 = CURSOR FOR SELECT a.member_id, a.family_id
FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
WHERE a.member_id != a.family_id
AND a.family_id = @a_family_id
AND a.alt_id = @t_alt_id
AND a.family_id = b.member_id
AND b.group_id IN(SELECT group_id
FROM dbo.dlsp_eg_group_plan (NOLOCK)
WHERE config_id = @i_config_id);
OPEN @SWV_cursor_var4;
FETCH NEXT FROM @SWV_cursor_var4 INTO @i_member_id,
@i_family_id;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var4 TABLE
(
id INT IDENTITY ,
member_id INT, family_id INT
);
INSERT INTO @SWV_cursor_var4
( member_id, family_id
)
SELECT a.member_id, a.family_id
FROM dbo.member a (NOLOCK), dbo.rlmbgrpl b (NOLOCK)
WHERE a.member_id != a.family_id
AND a.family_id = @a_family_id
AND a.alt_id = @t_alt_id
AND a.family_id = b.member_id
AND b.group_id IN(SELECT group_id
FROM dbo.dlsp_eg_group_plan (NOLOCK)
WHERE config_id = @i_config_id);
　
DECLARE @cur4_cnt INT ,
@cur4_i INT;
SET @cur4_i = 1;
--Get the no. of records for the cursor
SELECT @cur4_cnt = COUNT(1)
FROM @SWV_cursor_var4;
WHILE ( @cur4_i <= @cur4_cnt )
BEGIN
SELECT @i_member_id = member_id, @i_family_id = family_id
FROM @SWV_cursor_var4
WHERE id = @cur4_i;
SET @li_count = @li_count + 1;
--FETCH NEXT FROM @SWV_cursor_var4 INTO @i_member_id,
-- @i_family_id;
SET @cur4_i = @cur4_i + 1;
END;
--CLOSE @SWV_cursor_var4;
IF @li_count = 1
AND @i_member_id IS NOT NULL
BEGIN
SET @SWP_Ret_Value = 1;
SET @SWP_Ret_Value1 = @i_member_id;
SET @SWP_Ret_Value2 = @i_family_id;
RETURN;
END;
-- ameeta 06/21/00 added few lines below to check fuzzy logic if no dep found
IF @li_count = 0
BEGIN
EXECUTE dbo.dlp_chk_dep_fuzzy @a_subscriber,
@a_batch_id, @a_sir_id, @a_family_id,
@i_fuzzy_match OUTPUT,
@i_member_id OUTPUT,
@i_family_id OUTPUT;
IF @i_fuzzy_match = -1
SET @s_found_error = 'Y';
END;
IF @li_count > 1
BEGIN
SET @i_isam_error = 42
RAISERROR('Found more than one member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'F'
BEGIN
EXECUTE dbo.dlp_chk_dep_fuzzy @a_subscriber,
@a_batch_id, @a_sir_id, @a_family_id,
@i_fuzzy_match OUTPUT,
@i_member_id OUTPUT,
@i_family_id OUTPUT;
IF @i_fuzzy_match = -1
SET @s_found_error = 'Y';
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'A'
BEGIN
IF EXISTS ( SELECT
*
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_sir_id != @t_sir_id
AND alt_id = @t_alt_id
AND dls_sub_sir_id = @t_sub_sir_id
AND member_flag != '00'
AND dls_source = 'F' )
BEGIN
SET @i_isam_error = 42
RAISERROR('Duplicate dependent records within same family',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF EXISTS ( SELECT
*
FROM dbo.dls_elig (NOLOCK)
WHERE dls_batch_id = @a_batch_id
AND dls_sir_id = @t_sir_id
AND alt_id = @t_alt_id
AND dls_sub_sir_id != @t_sub_sir_id )
BEGIN
SET @i_isam_error = 43
RAISERROR('same Dep''s alt_id found in different family',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
/*
SET @SWV_cursor_var5 = CURSOR FOR SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE alt_id = @t_alt_id AND
family_id = @a_family_id AND
member_id != family_id;
OPEN @SWV_cursor_var5;
FETCH NEXT FROM @SWV_cursor_var5 INTO @i_member_id,
@i_family_id, @s_last_name,
@s_first_name, @s_middle_init,
@d_date_of_birth;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var5 TABLE
(
id INT IDENTITY ,
member_id int, family_id int, last_name char(15), first_name char(15),middle_init char(1), date_of_birth date
);
INSERT INTO @SWV_cursor_var5
( member_id, family_id, last_name, first_name,
middle_init, date_of_birth
)
SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE alt_id = @t_alt_id AND
family_id = @a_family_id AND
member_id != family_id;
　
DECLARE @cur5_cnt INT ,
@cur5_i INT;
SET @cur5_i = 1;
--Get the no. of records for the cursor
SELECT @cur5_cnt = COUNT(1)
FROM @SWV_cursor_var5;
WHILE ( @cur5_i <= @cur5_cnt )
BEGIN
SELECT @i_member_id = member_id,
@i_family_id = family_id, 
@s_last_name = last_name,
@s_first_name = first_name, 
@s_middle_init = middle_init,
@d_date_of_birth = date_of_birth
FROM @SWV_cursor_var5
WHERE id = @cur5_i;
SET @i_count = @i_count + 1;
--FETCH NEXT FROM @SWV_cursor_var5 INTO @i_member_id,
-- @i_family_id,
-- @s_last_name,
-- @s_first_name,
-- @s_middle_init,
-- @d_date_of_birth;
SET @cur5_i = @cur5_i + 1;
END;
--CLOSE @SWV_cursor_var5;
IF @i_count = 0
BEGIN
IF ( @t_ssn IS NULL
OR @t_ssn = ''
)
OR LEN(@t_ssn) = 0
BEGIN
SET @i_isam_error = 2
RAISERROR('Missing Member''s SSN',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
IF @i_count = 1
BEGIN
IF @s_last_name <> @t_last_name
BEGIN
SET @i_isam_error = 6
RAISERROR('Last Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF @s_first_name <> @t_first_name
BEGIN
SET @i_isam_error = 7
RAISERROR('First Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF @t_date_of_birth != '01/01/1900'
AND @t_date_of_birth <> @d_date_of_birth
BEGIN
SET @i_isam_error = 8
RAISERROR('Date of Birth mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
IF @i_count > 1
BEGIN
SET @a_error_no = 39;
SELECT @i_member_id = member_id ,
@i_family_id = family_id
FROM dbo.member (NOLOCK)
WHERE alt_id = @t_alt_id
AND member_id != family_id
AND family_id = @a_family_id
AND last_name = @t_last_name
AND first_name = @t_first_name
AND ( ( ( ( @t_middle_init IS NULL
OR @t_middle_init = ''
)
OR LEN(@t_middle_init) = 0
OR @t_middle_init = ' '
)
OR ( LEN(middle_init) = 0
OR middle_init IS NULL
OR middle_init = ' '
)
)
OR ( ( @t_middle_init IS NOT NULL
AND @t_middle_init <> ''
)
AND middle_init = @t_middle_init
)
)
AND ( ( date_of_birth = @t_date_of_birth
AND @t_date_of_birth != '01/01/1900'
)
OR ( @t_date_of_birth = '01/01/1900'
OR date_of_birth = '01/01/1900'
)
);
END;
END;
ELSE
BEGIN
IF @n_lookup_ssn_alt = 'S'
BEGIN
IF EXISTS ( SELECT
*
FROM
dbo.dls_elig (NOLOCK)
WHERE
dls_batch_id = @a_batch_id
AND dls_sir_id != @t_sir_id
AND ssn = @t_ssn
AND first_name = @t_first_name
AND last_name = @t_last_name
AND date_of_birth = @t_date_of_birth
AND dls_sub_sir_id = @t_sub_sir_id
AND member_flag != '00'
AND dls_source = 'F' )
BEGIN
SET @i_isam_error = 44
RAISERROR('Dupl dep records within same family base on ssn',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF EXISTS ( SELECT
*
FROM
dbo.dls_elig (NOLOCK)
WHERE
dls_batch_id = @a_batch_id
AND dls_sir_id = @t_sir_id
AND ssn = @t_ssn
AND dls_sub_sir_id != @t_sub_sir_id )
BEGIN
SET @i_isam_error = 45
RAISERROR('same Dep''s ssn found in different family',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
/*
SET @SWV_cursor_var6 = CURSOR FOR SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE member_ssn = @t_ssn AND
family_id = @a_family_id AND
member_id != family_id;
OPEN @SWV_cursor_var6;
FETCH NEXT FROM @SWV_cursor_var6 INTO @i_member_id,
@i_family_id,
@s_last_name,
@s_first_name,
@s_middle_init,
@d_date_of_birth;
WHILE @@FETCH_STATUS = 0
*/
DECLARE @SWV_cursor_var6 TABLE
(
id INT IDENTITY ,
member_id int, family_id int, last_name char(16), first_name char(16),middle_init char(1), date_of_birth date
);
INSERT INTO @SWV_cursor_var6
( member_id, family_id, last_name, first_name,
middle_init, date_of_birth
)
SELECT member_id, family_id, last_name, first_name,
middle_init, date_of_birth
FROM dbo.member (NOLOCK)
WHERE member_ssn = @t_ssn AND
family_id = @a_family_id AND
member_id != family_id;
　
DECLARE @cur6_cnt INT ,
@cur6_i INT;
SET @cur6_i = 1;
--Get the no. of records for the cursor
SELECT @cur6_cnt = COUNT(1)
FROM @SWV_cursor_var6;
WHILE ( @cur6_i <= @cur6_cnt )
BEGIN
SELECT @i_member_id = member_id,
@i_family_id = family_id, 
@s_last_name = last_name,
@s_first_name = first_name, 
@s_middle_init = middle_init,
@d_date_of_birth = date_of_birth
FROM @SWV_cursor_var6
WHERE id = @cur6_i;
SET @i_count = @i_count + 1;
--FETCH NEXT FROM @SWV_cursor_var6 INTO @i_member_id,
-- @i_family_id,
-- @s_last_name,
-- @s_first_name,
-- @s_middle_init,
-- @d_date_of_birth;
SET @cur6_i = @cur6_i + 1;
END;
--CLOSE @SWV_cursor_var6;
IF @i_count = 0
BEGIN
IF ( @t_ssn IS NULL
OR @t_ssn = ''
)
OR LEN(@t_ssn) = 0
BEGIN
SET @i_isam_error = 2
RAISERROR('Missing Member''s SSN',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
IF @i_count = 1
IF @d_date_of_birth IS NOT NULL
BEGIN
IF @d_date_of_birth = @t_date_of_birth
BEGIN
IF @s_last_name <> @t_last_name
BEGIN
SET @i_isam_error = 6
RAISERROR('Last Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
IF @s_first_name <> @t_first_name
BEGIN
SET @i_isam_error = 7
RAISERROR('First Name mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
END;
ELSE
BEGIN
IF @t_date_of_birth != '01/01/1900'
AND @t_date_of_birth <> @d_date_of_birth
AND @s_last_name = @t_last_name
AND @s_first_name = @t_first_name
AND @s_middle_init = @t_middle_init
BEGIN
SET @i_isam_error = 8
RAISERROR('Date of Birth mismatch for existing member',0,1);
EXEC @i_fatal = usp_dl_log_error @a_batch_id, @i_sp_id,@i_sir_def_id,
			@t_sir_id, @i_isam_error;
		IF @i_fatal <> 1 
			SET @s_found_error = 'Y';
-- RETURN
END
ELSE
SET @i_member_id = NULL;
END;
END;
ELSE
BEGIN
IF @s_last_name <> @t_last_name
SET @i_member_id = NULL;
ELSE
BEGIN
IF @s_first_name <> @t_first_name
SET @i_member_id = NULL;
END;
END;
IF @i_count > 1
BEGIN
SET @a_error_no = 38;
SELECT
@i_member_id = member_id ,
@i_family_id = family_id
FROM
dbo.member (NOLOCK)
WHERE
member_ssn = @t_ssn
AND member_id != family_id
AND family_id = @a_family_id
AND last_name = @t_last_name
AND first_name = @t_first_name
AND ( ( ( ( @t_middle_init IS NULL
OR @t_middle_init = ''
)
OR LEN(@t_middle_init) = 0
OR @t_middle_init = ' '
)
OR ( LEN(middle_init) = 0
OR middle_init IS NULL
OR middle_init = ' '
)
)
OR ( ( @t_middle_init IS NOT NULL
AND @t_middle_init <> ''
)
AND middle_init = @t_middle_init
)
)
AND ( ( date_of_birth = @t_date_of_birth
AND @t_date_of_birth != '01/01/1900'
)
OR ( @t_date_of_birth = '01/01/1900'
OR date_of_birth = '01/01/1900'
)
);
END;
END;
END;
END;
END;
END;
IF @s_found_error = 'Y'
BEGIN
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = NULL;
SET @SWP_Ret_Value2 = NULL;
RETURN;
END;
ELSE
IF @i_member_id IS NOT NULL
BEGIN
SET @SWP_Ret_Value = @i_fuzzy_match;
SET @SWP_Ret_Value1 = @i_member_id;
SET @SWP_Ret_Value2 = @i_family_id;
RETURN;
END;
ELSE
BEGIN
SET @SWP_Ret_Value = 0;
SET @SWP_Ret_Value1 = @i_member_id;
SET @SWP_Ret_Value2 = @i_family_id;
RETURN;
END;
END TRY
BEGIN CATCH
SET @i_error_no = ERROR_NUMBER();
--SET @i_isam_error = ERROR_LINE();
SET @s_error_descr = ERROR_MESSAGE();
EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @i_sp_id,
@i_sir_def_id, @t_sir_id, @i_isam_error;
SET @SWP_Ret_Value = -1;
SET @SWP_Ret_Value1 = NULL;
SET @SWP_Ret_Value2 = NULL;
RETURN;
END CATCH;
SET NOCOUNT OFF;
　
END;