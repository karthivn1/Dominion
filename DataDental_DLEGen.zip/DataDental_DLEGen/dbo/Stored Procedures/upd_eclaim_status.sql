﻿CREATE PROCEDURE [dbo].[upd_eclaim_status]
    @eclaimid INT ,
    @old_status SMALLINT ,
    @new_status SMALLINT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:28:28 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1


000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        SET NOCOUNT ON;
        IF @old_status = @new_status
            RETURN;
	
        UPDATE  dbo.eclaim_status
        SET     exp_date = GETDATE() ,
                h_user = ORIGINAL_LOGIN()
        WHERE   eclaim_id = @eclaimid
                AND exp_date IS NULL
                AND status = @old_status;
        INSERT  INTO dbo.eclaim_status
                ( eclaim_id ,
                  status ,
                  eff_date ,
                  h_user
                )
        VALUES  ( @eclaimid ,
                  @new_status ,
                  GETDATE() ,
                  ORIGINAL_LOGIN()
                );
        SET NOCOUNT OFF;
    END;