﻿CREATE PROCEDURE [dbo].[dlp_al_utilization]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    
	

------------------------------------------------------------------------------
--
--            Procedure:   dlp_al_utilization
--
--            Created:     02/01/1999 
--            Author:      Kim Nguyen, Gene Albers
--
-- Purpose:  This SP performs after-load processing on DataDental
--           Electronic Claims for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 05:08:08 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1




000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @i_error_no INT;
        DECLARE @a_error_no INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_text VARCHAR(64);
        DECLARE @s_error_msg VARCHAR(64);
        DECLARE @i_isam_error INT;

        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @s_proc_name CHAR(14);
        DECLARE @s_sir_def_name CHAR(14);
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @dc_cob_amt DECIMAL(16, 2);
        DECLARE @dc_sub_amt DECIMAL(16, 2);
        DECLARE @d_rec_date DATE;

        DECLARE @s_update CHAR(1);

        DECLARE @s_ins_type CHAR(1);
        DECLARE @s_x_rays_rqd CHAR(1);
        DECLARE @s_preauth_switch CHAR(9);
        DECLARE @s_emergency_switch CHAR(9);
        DECLARE @s_pay_prv_switch CHAR(9);
        DECLARE @s_cob_amt CHAR(20);
        DECLARE @s_submitted_amt CHAR(20);
        DECLARE @s_rec_date CHAR(10);
		DECLARE @dls_sir_id INT
        DECLARE @t_ins_type CHAR(1);
        DECLARE @t_x_rays_rqd CHAR(1);
        DECLARE @t_preauth_switch CHAR(9); 
        DECLARE @t_emergency_switch CHAR(9); 
        DECLARE @t_pay_prv_switch CHAR(9); 
        DECLARE @t_cob_amt CHAR(20);
        DECLARE @t_submitted_amt CHAR(20);
        DECLARE @t_f_name CHAR(20);
        DECLARE @t_mid_init CHAR(1);
        DECLARE @t_l_name CHAR(30);
        DECLARE @t_doc_no CHAR(15);
        DECLARE @t_rec_date CHAR(10);

        DECLARE @i_process_count INT;
        DECLARE @i_succ_count INT;
       -- DECLARE @cUtilSIR CURSOR;
	   DECLARE @cUtilSIR TABLE
                                (
                                  id INT IDENTITY ,
                                  dls_sir_id INT,
								  ins_type VARCHAR(2),
								  x_rays_rqd VARCHAR(2), 
								  preauth_switch VARCHAR(2), 
								  emergency_switch VARCHAR(2),
									pay_prv_switch VARCHAR(2), 
									cob_amt VARCHAR(20),    
									submitted_amt VARCHAR(20),  
									first_name VARCHAR(20),
									middle_init VARCHAR(2),    
									last_name VARCHAR(30),  
									document_no VARCHAR(15),    
									received_date  VARCHAR(10)
                                );
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;

-----exception handling----------------------------------------------
---------------------------------------------------------------------

        SET NOCOUNT ON;
        BEGIN TRY
            
            SET @a_error_no = 0;

-----Initialize stored procedure variables-----------------------------------
            SET @s_proc_name = 'al_utilization';
            SET @s_sir_def_name = 'utilization';
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, @s_proc_name;
            IF @i_sp_id = -1
                RAISERROR('Could not retrieve valid Store Procedure ID',16,1);

            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
            IF @i_sir_def_id = -1
                RAISERROR('Could not retrieve valid SIR Table ID',16,1);



-----Prepare for keeping stats on preprocessing-------------------------------
            EXECUTE dbo.dl_it_statistics @a_batch_id, @i_sp_id, @a_start_time,
                @i_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_text OUTPUT;
            IF @i_error_no <= 0
                RAISERROR('(Internal) error when creating statistics',16,1);


-----Get default values--------------------------------------------------------

-- get Ins Type------------
            SET @s_ins_type = dbo.dl_get_param_value(@a_batch_id, @i_sp_id,
                                                     'Insurance Type');
            IF ( @s_ins_type IS NULL
                 OR @s_ins_type = ''
               )
                OR LEN(@s_ins_type) != 1
                RAISERROR('Missing Insurance Type parameter value',16,1);
            ELSE
                IF @s_ins_type NOT IN ( 'D', 'V' )
                    RAISERROR('Insurance Type must be (D or V)',16,1);

-- get X-Rays Req--------------
            SET @s_x_rays_rqd = dbo.dl_get_param_value(@a_batch_id, @i_sp_id,
                                                       'X-rays Included');
            IF ( @s_x_rays_rqd IS NULL
                 OR @s_x_rays_rqd = ''
               )
                OR LEN(@s_x_rays_rqd) != 1
                RAISERROR('Missing X-rays Included parameter value',16,1);
            ELSE
                IF @s_x_rays_rqd NOT IN ( 'Y', 'N' )
                    RAISERROR('X-rays Included must be (Y or N)',16,1);

-- get Pre-Authorization-------------
            SET @s_preauth_switch = dbo.dl_get_param_value(@a_batch_id,
                                                           @i_sp_id,
                                                           'Preauthorization');
            IF ( @s_preauth_switch IS NULL
                 OR @s_preauth_switch = ''
               )
                OR LEN(@s_preauth_switch) != 1
                RAISERROR('Missing Preauthorization parameter value',16,1);
            ELSE
                IF @s_preauth_switch NOT IN ( 'Y', 'N' )
                    RAISERROR('Preauthorization must be (Y or N)',16,1);

-- get Emergency Switch-------------
            SET @s_emergency_switch = dbo.dl_get_param_value(@a_batch_id,
                                                             @i_sp_id,
                                                             'Emergency');
            IF ( @s_emergency_switch IS NULL
                 OR @s_emergency_switch = ''
               )
                OR LEN(@s_emergency_switch) != 1
                RAISERROR('Missing Emergency parameter value',16,1);
            ELSE
                IF @s_emergency_switch NOT IN ( 'Y', 'N' )
                    RAISERROR('Emergency must be (Y or N)',16,1);

-- get Pay Provider Switch----------------
            SET @s_pay_prv_switch = dbo.dl_get_param_value(@a_batch_id,
                                                           @i_sp_id,
                                                           'Whom to Pay');
            IF ( @s_pay_prv_switch IS NULL
                 OR @s_pay_prv_switch = ''
               )
                OR LEN(@s_pay_prv_switch) != 1
                RAISERROR('Missing Whom to Pay parameter value',16,1);
            ELSE
                IF @s_pay_prv_switch NOT IN ( '0', '1', '2', '3' )
                    RAISERROR('Whom to Pay must be (0, 1, 2, 3)',16,1);

-- get COB Amount------------------------
            SET @s_cob_amt = dbo.dl_get_param_value(@a_batch_id, @i_sp_id,
                                                    'COB Amount');
            IF ( @s_cob_amt IS NULL
                 OR @s_cob_amt = ''
               )
                OR LEN(@s_cob_amt) < 1
  RAISERROR('Missing COB Amount parameter value',16,1);
            ELSE
                BEGIN
                    SET @s_error_msg = 'Can not convert COB Amount to type decimal';
                    SET @a_error_no = 50;
                    SET @dc_cob_amt = @s_cob_amt;
                    SET @a_error_no = 0;
                END;


-- get submitted amount-------------------
            SET @s_submitted_amt = dbo.dl_get_param_value(@a_batch_id,
                                                          @i_sp_id,
                                                          'Submitted Amount');
       IF ( @s_submitted_amt IS NULL
                 OR @s_submitted_amt = ''
               )
                OR LEN(@s_submitted_amt) < 1
                RAISERROR('Missing Submitted Amount parameter value',16,1);
            ELSE
                BEGIN
                    SET @s_error_msg = 'Can not convert Submitted Amount to type decimal';
                    SET @a_error_no = 50;
                    SET @dc_sub_amt = @s_submitted_amt;
                    SET @a_error_no = 0;
                END;



-- get received date-------------------
            SET @s_rec_date = dbo.dl_get_param_value(@a_batch_id, @i_sp_id,
                                                     'Received Date');
            IF ( @s_rec_date IS NULL
                 OR @s_rec_date = ''
               )
                OR LEN(@s_rec_date) < 1
                RAISERROR('Missing Received Date parameter value',16,1);
            ELSE
                BEGIN
                    SET @s_error_msg = 'Can not convert Received Date to type Date';
                    SET @a_error_no = 60;
                    SET @d_rec_date = @s_rec_date;
                    SET @a_error_no = 0;
                END;

            
            SET @i_process_count = 0;



	-----exception handling w/in FOREACH-----------------------------------------------------------
            SET @i_succ_count = 0;

-----begin eval data, one row at a time------------------------------------------


	-----end exception within FOREACH--------------------------------------------------------------

	INSERT INTO @cUtilSIR (dls_sir_id, ins_type ,
								  x_rays_rqd , 
								  preauth_switch , 
								  emergency_switch,
									pay_prv_switch , 
									cob_amt ,    
									submitted_amt ,  
									first_name ,
									middle_init ,   
									last_name ,  
									document_no ,    
									received_date  
									)
	SELECT  dls_sir_id, ins_type,       x_rays_rqd, preauth_switch, emergency_switch,
		pay_prv_switch, cob_amt,    submitted_amt,  first_name,
		middle_init,    last_name,  document_no,    received_date
	
      FROM  dbo.dls_utilization (NOLOCK)
      WHERE	dls_batch_id = @a_batch_id AND dls_status = 'L';
          /*  SET @cUtilSIR = CURSOR  FOR SELECT  ins_type,       x_rays_rqd, preauth_switch, emergency_switch,
		pay_prv_switch, cob_amt,    submitted_amt,  first_name,
		middle_init,    last_name,  document_no,    received_date
	
      FROM  dbo.dls_utilization (NOLOCK)
      WHERE	dls_batch_id = @a_batch_id AND dls_status = 'L';
            OPEN @cUtilSIR;
            FETCH NEXT FROM @cUtilSIR INTO	@t_ins_type, @t_x_rays_rqd,
                @t_preauth_switch, @t_emergency_switch, @t_pay_prv_switch,
                @t_cob_amt, @t_submitted_amt, @t_f_name, @t_mid_init,
                @t_l_name, @t_doc_no, @t_rec_date;
            WHILE @@FETCH_STATUS = 0 */

			 DECLARE @cur_cnt INT ,
                                @cur_i INT;

                            SET @cur_i = 1;

				--Get the no. of records for the cursor
                            SELECT  @cur_cnt = COUNT(1)
                            FROM    @cUtilSIR;

                            WHILE ( @cur_i <= @cur_cnt )
                BEGIN

				SELECT @dls_sir_id = dls_sir_id, @t_ins_type = ins_type, @t_x_rays_rqd = x_rays_rqd,
                @t_preauth_switch = preauth_switch, @t_emergency_switch = emergency_switch, @t_pay_prv_switch = pay_prv_switch,
                @t_cob_amt = cob_amt, @t_submitted_amt = submitted_amt, @t_f_name = first_name, @t_mid_init = middle_init,
                @t_l_name = last_name , @t_doc_no = document_no, @t_rec_date = received_date FROM @cUtilSIR where id = @cur_i 

				     BEGIN
                        BEGIN TRY
                            SET @i_process_count = @i_process_count + 1;
                            SET @s_update = 'F';
                            

	/* Assign default values for the following fields*/

	--ins_type
                            IF ( ( @t_ins_type IS NULL
                                   OR @t_ins_type = ''
                                 )
                                 OR LEN(@t_ins_type) != 1
                               )
                                OR ( @t_ins_type NOT IN ( 'D', 'V' ) )
                                BEGIN
                                    SET @s_update = 'T';
                                    SET @t_ins_type = @s_ins_type;
                                END;
	

	--x_rays_rqd 
                            IF ( (@t_x_rays_rqd IS NULL
                                 OR @t_x_rays_rqd = '')
                               )
                                OR ( LEN(@t_x_rays_rqd) != 1 )
                                OR ( @t_x_rays_rqd NOT IN ( 'Y', 'N' ) )
                                BEGIN
                                    SET @s_update = 'T';
                                    SET @t_x_rays_rqd = @s_x_rays_rqd;
                                END;
	

	--preauth_switch
                            IF ( (@t_preauth_switch IS NULL
                                 OR @t_preauth_switch = '')
                               )
                                OR ( LEN(@t_preauth_switch) != 1 )
                                OR ( @t_preauth_switch NOT IN ( 'Y', 'N' ) )
          BEGIN
                                    SET @s_update = 'T';
                                    SET @t_preauth_switch = @s_preauth_switch;
                                END;
	

	--emergency_switch
                            IF ( (@t_emergency_switch IS NULL
                                 OR @t_emergency_switch = '')
                               )
                                OR ( LEN(@t_emergency_switch) != 1 )
                                OR ( @t_emergency_switch NOT IN ( 'Y', 'N' ) )
                                BEGIN
                                    SET @s_update = 'T';
                                    SET @t_emergency_switch = @s_emergency_switch;
                                END;
	

	--pay_prv_switch 
                            IF ( (@t_pay_prv_switch IS NULL
                                 OR @t_pay_prv_switch = '')
                               )
                                OR ( LEN(@t_pay_prv_switch) != 1 )
                                OR ( @t_pay_prv_switch NOT IN ( '1', '2', '3',
                                                              '4' ) )
                                BEGIN
                                    SET @s_update = 'T';
                                    SET @t_pay_prv_switch = @s_pay_prv_switch;
                                END;
	

	--cob_amt
                            IF ( (@t_cob_amt IS NULL
                                 OR @t_cob_amt = '')
                               )
                                OR LEN(@t_cob_amt) < 1
                                BEGIN
                                    SET @s_update = 'T';
                                    SET @t_cob_amt = @s_cob_amt;
                                END;
	

	--submitted_amt
                            IF ( (@t_submitted_amt IS NULL
                                 OR @t_submitted_amt = '')
                               )
                                OR LEN(@t_submitted_amt) < 1
            BEGIN
                        SET @s_update = 'T';
                                    SET @t_submitted_amt = @s_submitted_amt;
                                END;
	
	
	-- first name
                            IF ( @t_f_name IS NULL
                                 OR @t_f_name = ''
                               )
                                OR LEN(@t_f_name) < 1
                                BEGIN
                                    SET @t_f_name = ' ';
                                    SET @s_update = 'T';
                                END;
	

	-- middle initial
                            IF ( @t_mid_init IS NULL
                                 OR @t_mid_init = ''
                               )
                                OR LEN(@t_mid_init) < 1
                                BEGIN
                                    SET @t_mid_init = ' ';
                                    SET @s_update = 'T';
                                END;
	

	-- last name
                            IF ( @t_l_name IS NULL
                                 OR @t_l_name = ''
                               )
                                OR LEN(@t_l_name) < 1
                                BEGIN
                                    SET @t_l_name = ' ';
                                    SET @s_update = 'T';
                                END;
	

	-- document no.
                            IF ( @t_doc_no IS NULL
                                 OR @t_doc_no = ''
                               )
                                OR LEN(@t_doc_no) < 1
                                BEGIN
                                    SET @t_doc_no = ' ';
                                    SET @s_update = 'T';
                                END;
	

	-- received date
                            IF ( @t_rec_date IS NULL
                                 OR @t_rec_date = ''
                               )
         OR LEN(@t_rec_date) < 1
                                BEGIN
                                    SET @t_rec_date = @s_rec_date;
                                    SET @s_update = 'T';
                                END;
	
                            IF @s_update = 'F'
                                UPDATE  dbo.dls_utilization
                                SET     dls_status = 'V'
                               -- WHERE CURRENT OF @cUtilSIR;
							   WHERE dls_sir_id = @dls_sir_id
                            ELSE
                                UPDATE  dbo.dls_utilization
                                SET     ins_type = @t_ins_type ,
                                        x_rays_rqd = @t_x_rays_rqd ,
                                        preauth_switch = @t_preauth_switch ,
                                        emergency_switch = @t_emergency_switch ,
                                        pay_prv_switch = @t_pay_prv_switch ,
                                        cob_amt = @t_cob_amt ,
                                        submitted_amt = @t_submitted_amt ,
                                        first_name = @t_f_name ,
                                        middle_init = @t_mid_init ,
                                        last_name = @t_l_name ,
                                        document_no = @t_doc_no ,
                                        received_date = @t_rec_date ,
                                        dls_status = 'V'
                                --WHERE CURRENT OF @cUtilSIR;
								WHERE dls_sir_id = @dls_sir_id
	
                            
                            SET @i_succ_count = @i_succ_count + 1;
	
	/* update stats every 100 rows evaluated */
                            IF @i_process_count % 100 = 0

	   -----update the stats----------
                                UPDATE  dbo.dl_bat_statistics
                                SET     tot_record = @i_process_count ,
                                        tot_success_rec = @i_succ_count ,
       tot_fail_rec = ( @i_process_count
                                                         - @i_succ_count )
                                WHERE   bat_statistics_id = @i_statistics_id;
                        END TRY
                        BEGIN CATCH
                            SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_text = ERROR_MESSAGE();
                            
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_text = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_text;
                                    RAISERROR(@s_error_text,16,1);
                                END;
		
                            GOTO SWL_Label2;
                        END CATCH;
                    END;
                    SWL_Label2:
                   /* FETCH NEXT FROM @cUtilSIR INTO @t_ins_type, @t_x_rays_rqd,
                        @t_preauth_switch, @t_emergency_switch,
                        @t_pay_prv_switch, @t_cob_amt, @t_submitted_amt,
                        @t_f_name, @t_mid_init, @t_l_name, @t_doc_no,
                        @t_rec_date; */
						set @cur_i = @cur_i + 1
                END;
            -- CLOSE @cUtilSIR;

/* update statistics */

            SET @SWV_func_DL_UPD_STATISTICS_par0 = ( @i_process_count
                                                     - @i_succ_count );
            EXECUTE @SWV_dl_upd_statistics = dbo.dl_upd_statistics @i_statistics_id, @i_process_count,
                @i_succ_count, @SWV_func_DL_UPD_STATISTICS_par0;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_process_count,
                                                 ' Failed to update statistics');
                    RETURN;
                END;

            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Afterload for Batch ', @a_batch_id,
                                         ' is completed');
            RETURN;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            IF @a_error_no > 0
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = @s_error_msg;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @s_error_msg = CONCAT('DB Error: ', @i_error_no,
                                              ' Error msg: ', @s_error_text);
                    SET @SWP_Ret_Value = @i_error_no;
                    SET @SWP_Ret_Value1 = @s_error_text;
                    RETURN;
                END;
        END CATCH;
        SET NOCOUNT OFF;

--TRACE OFF;
 



-----begin after loading procedure---------------------------------------------
-------------------------------------------------------------------------------
--SET DEBUG FILE TO '/tmp/dlp_al_utilization.trc';
--TRACE ON;


    END;