﻿CREATE PROCEDURE [dbo].[dlp_set_family_err]
    @a_batch_id INT ,
    @a_sub_sir_id INT
    
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @i_dls_sir_id INT;
        DECLARE @i_fatal INT;
        DECLARE @i_sp_id INT
        DECLARE @i_sir_def_id INT
        --DECLARE @SWV_cursor_var1 CURSOR;
        SET NOCOUNT ON;
        SET @i_sp_id = 0
        
        SET @i_sir_def_id = 0
        
        BEGIN TRY

  DECLARE @SWV_cursor_var1 TABLE
                        (
                         id INT IDENTITY ,
       dls_sir_id INT
                        );
                          INSERT  INTO @SWV_cursor_var1
                                ( 
        dls_sir_id 
                                )
        SELECT dls_sir_id 
      FROM dbo.dls_elig (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND
      dls_sub_sir_id = @a_sub_sir_id AND
      dls_status != 'E';
   DECLARE @cur1_cnt INT ,
                            @cur1_i INT;
                        SET @cur1_i = 1;
      --Get the no. of records for the cursor
                        SELECT  @cur1_cnt = COUNT(1)
                        FROM  @SWV_cursor_var1;
  /*
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sir_id 
      FROM dbo.dls_elig (NOLOCK)
      WHERE dls_batch_id = @a_batch_id AND
      dls_sub_sir_id = @a_sub_sir_id AND
      dls_status != 'E';
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_dls_sir_id;
            WHILE @@FETCH_STATUS = 0
   */
               WHILE ( @cur1_i <= @cur1_cnt )
            BEGIN
   SELECT  @i_dls_sir_id=dls_sir_id
     FROM @SWV_cursor_var1
            WHERE   id = @cur1_i;
                    
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @i_dls_sir_id;
     SET @cur1_i = @cur1_i + 1;
                END;
            --CLOSE @SWV_cursor_var1;
            UPDATE  dbo.dls_elig
            SET     dls_status = 'E'
            WHERE   dls_batch_id = @a_batch_id
                    AND dls_sub_sir_id = @a_sub_sir_id;
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;
    END;