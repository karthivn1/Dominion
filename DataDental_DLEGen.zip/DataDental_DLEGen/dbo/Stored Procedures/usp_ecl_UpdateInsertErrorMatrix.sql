﻿CREATE PROCEDURE [dbo].[usp_ecl_UpdateInsertErrorMatrix]
			@MatrixId INT,
			@ErrorCode CHAR(10), 
			@Status INT=NULL,
			@ErrorDescription VARCHAR(250),
			@LetterName VARCHAR(50)=NULL,
			@Message VARCHAR(MAX)=NULL,
			@Level SMALLINT,
			@User varchar(20)
AS
BEGIN

DECLARE @ERR_MSG AS NVARCHAR(4000),
		@ERR_SEV AS SMALLINT,
		@ERR_STA AS SMALLINT
		--UPDATE AN ERROR MATRIX
	IF(@MatrixId!=0)
	BEGIN
		BEGIN TRY
			BEGIN TRAN
			IF ( UPPER(@ErrorCode)!=(SELECT error_code FROM eclaim_matrix WHERE matrix_id=@MatrixId))
			BEGIN 
				if exists(SELECT * FROM eclaim_matrix where error_code=upper(@ErrorCode))
				 RAISERROR ('The same Error Code is already exist in database.', 16, 1 );
			END
				UPDATE eclaim_matrix
				SET error_code			=UPPER(@ErrorCode),
					status_to_assign	=@Status,
					error_desc			=@ErrorDescription,
					letter_name			=@LetterName,
					letter_verbiage		=@Message,
					level				=@Level,
					h_user				=@User,
					h_datetime			=GETDATE()
				WHERE matrix_id=@MatrixId
			COMMIT TRAN
		END TRY
		BEGIN CATCH
			 ROLLBACK
			 SELECT  @ERR_MSG = ERROR_MESSAGE(),
					 @ERR_SEV =ERROR_SEVERITY(),
					 @ERR_STA = ERROR_STATE()
			 RAISERROR (@ERR_MSG, @ERR_SEV, @ERR_STA);
		END CATCH
	END
	--ADD NEW ERROR MATRIX 
	ELSE IF(@MatrixId=0)
	BEGIN TRY
		BEGIN TRAN 
		if EXISTS(SELECT * FROM eclaim_matrix WHERE error_code=UPPER(@ErrorCode))
				 RAISERROR ('The same Error Code is already exist in database.', 16, 1 );

			INSERT INTO eclaim_matrix  (error_code,
										status_to_assign,
										error_desc,
										letter_name,
										letter_verbiage,
										level,
										h_user)
								VALUES( UPPER(@ErrorCode),
										@Status,
										@ErrorDescription,
										@LetterName,
										@Message,
										@Level,
										@User )
		COMMIT TRAN
	END TRY
	BEGIN CATCH
		 ROLLBACK
		 SELECT  @ERR_MSG = ERROR_MESSAGE(),
				 @ERR_SEV =ERROR_SEVERITY(),
				 @ERR_STA = ERROR_STATE()
		 RAISERROR (@ERR_MSG, @ERR_SEV, @ERR_STA);
	END CATCH
  END