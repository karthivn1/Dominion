﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_EligibilityInquiry 36069,'',1517,'',1016678,'','','',0,'','703-55-6677','','','Child','2013-01-02'
-- =============================================
CREATE PROC [dbo].[usp_api_EligibilityInquiry] 
@GroupID INT,@GroupAltID Char(20),@PlanID INT,@PlanName Char(20),
@SubID INT,@SubSSN Char(11),@SubSourceID char(20),@SubAltID char(20),@DepSW bit,
@PatID INT,@PatSSN Char(11),@patSourceID char(20),@PatAltID char(20),@PatMemberCode char(20),
@AsOfDate Date
AS
BEGIN

DECLARE @asDate date=convert(date, @AsOfDate, 104);
DECLARE @EligStatus nVarchar(20)=null;


DECLARE @gID INT=0;
DECLARE @pID INT=0; 

DECLARE @planOption nVarchar(10)=null
DECLARE @planInsType char(2)=null;
DECLARE @groupType char(2)=null;
DECLARE @ErrorMsg nVarchar(50)='';

SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tempErrorTable') IS NOT NULL
    DROP TABLE #tempErrorTable
IF OBJECT_ID('tempdb..#tempMGP') IS NOT NULL
    DROP TABLE #tempMGP
IF OBJECT_ID('tempdb..#tempPatient') IS NOT NULL
    DROP TABLE #tempPatient
IF OBJECT_ID('tempdb..#GRPL') IS NOT NULL
    DROP TABLE #GRPL
IF OBJECT_ID('tempdb..#AssignedFCs') IS NOT NULL
    DROP TABLE #AssignedFCs
IF OBJECT_ID('tempdb..#tempAssignedFCs') IS NOT NULL
    DROP TABLE #tempAssignedFCs
IF OBJECT_ID('tempdb..#tempGRPL') IS NOT NULL
    DROP TABLE #tempGRPL
IF OBJECT_ID('tempdb..#subAddr') IS NOT NULL
    DROP TABLE #subAddr
IF OBJECT_ID('tempdb..#patAddr') IS NOT NULL
    DROP TABLE #patAddr
		

Create table #tempErrorTable(ID int identity(1,1),ErrorName nvarchar(50),ErrorDesc nvarchar(1000))	
CREATE TABLE #tempMGP(mb_gr_pl_id INT,member_id INT null,group_id INT null,plan_id int null,sub_in_plan int null,eff_gr_pl date null,exp_gr_pl date null,SubStatus int null)
Create Table #tempPatient(member_id INT null) 
            	
BEGIN TRY

--Validate Group
EXEC @gID=usp_api_ValidateGroup @GroupID,@GroupAltID,@ErrorMsg OUT

IF Len(@ErrorMsg)>0
BEGIN
       SET @EligStatus='Error'
	  INSERT INTO #tempErrorTable Values ('Group',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END
   ---need to get the groupID   

Select @groupType=g.group_type From [group] g Where g.group_id=@gID

 --validatePlan
EXEC @pID=usp_api_ValidatePlan @PlanID,@PlanName,@planOption out,@planInsType out,@ErrorMsg out

IF Len(@ErrorMsg)>0
BEGIN
	SET @EligStatus='Error'	
	  INSERT INTO #tempErrorTable Values ('Plan',@ErrorMsg);
	   THROW 51000,'User Validation Faild',1
END

--validateSub

 IF @SubID>0
BEGIN

IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID
		        and r.plan_id =@pID and m.member_id = @SubID AND m.family_id=m.member_id)
				BEGIN
				---add
				 INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.group_id,r.plan_id,r.sub_in_plan,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id=@SubID
						AND m.family_id=m.member_id
						order by r.mb_gr_pl_id
				END
				 
END
ELSE IF len(@SubSSN)>0
BEGIN
   IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN AND m.family_id=m.member_id)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.group_id,r.plan_id,r.sub_in_plan,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.new_ssn=@SubSSN
						AND m.family_id=m.member_id
						order by r.mb_gr_pl_id

				END
			
END
ELSE IF len(@SubSourceID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID AND m.family_id=m.member_id)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.group_id,r.plan_id,r.sub_in_plan,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.source_id=@SubSourceID
						AND m.family_id=m.member_id
						order by r.mb_gr_pl_id
				END
			
END

ELSE IF len(@SubAltID)>0
BEGIN
    IF EXISTS(Select mb_gr_pl_id 
                FROM rlmbgrpl r
				Join member m on m.member_id=r.member_id 
				Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID AND m.family_id=m.member_id)
				BEGIN
				   INSERT INTO #tempMGP
				   Select r.mb_gr_pl_id,r.member_id,r.group_id,r.plan_id,r.sub_in_plan,r.eff_gr_pl,r.exp_gr_pl,null  
						FROM rlmbgrpl r
						Join member m on m.member_id=r.member_id 
						Where r.group_id =@gID AND r.plan_id =@pID AND r.member_id >0 AND m.alt_id=@SubAltID
						AND m.family_id=m.member_id
						order by r.mb_gr_pl_id
				END
			
END


IF EXISTS(Select member_id from #tempMGP)
BEGIN 
  IF EXISTS(Select t.member_id from #tempMGP t 
			JOIN #tempMGP s ON s.member_id<>t.member_id)
  BEGIN
     SET @EligStatus='Error'	
	 INSERT INTO #tempErrorTable Values ('SubInput','Multiple Member found in the database for the given options');
	 THROW 51000,'User Validation Faild',1
	END

---needs to check the range values

IF NOT EXISTS (Select member_id
	From #tempMGP t
	Where t.eff_gr_pl<= @AsOfDate
	AND (t.exp_gr_pl IS NULL OR (t.exp_gr_pl is not null and t.eff_gr_pl <> t.exp_gr_pl and t.exp_gr_pl >@AsOfDate))
	AND member_id>0)
	BEGIN
     SET @EligStatus='InActive'
	 INSERT INTO #tempErrorTable Values ('SubInput','Subscriber not active in the given group plan as of '+Cast(@AsOfDate as nvarchar(10)) );
	 THROW 51000,'User Validation Faild',1
	END


--IF NOT EXISTS (Select member_id
--	From #tempMGP t
--	Where t.eff_gr_pl=convert(date, @AsOfDate, 104)
--	AND (t.exp_gr_pl IS NULL OR (t.exp_gr_pl is not null and t.eff_gr_pl <> t.exp_gr_pl and t.exp_gr_pl >convert(date, @AsOfDate, 104)))
--	AND member_id>0)
--	BEGIN
--     SET @EligStatus='InActive'
--	 INSERT INTO #tempErrorTable Values ('Sub','Subscriber not active in the given group plan as of '+Cast(@AsOfDate as nvarchar(10)) );
--	 THROW 51000,'User Validation Faild',1
--	END

--Get the memberGroup for memberid and asOfDate

Select  r.mb_gr_pl_id,
        r.member_id, 
        r.group_id, 
        r.plan_id, 
        r.sub_in_plan, 
        r.sign_flag, 
        r.cobra_flag, 
        r.rec_date, 
        r.eff_gr_pl, 
        r.exp_gr_pl 
	INTO #GRPL
	From #tempMGP t
	JOIN rlmbgrpl r on r.member_id=t.member_id
	Where r.mb_gr_pl_id>0 AND r.member_id>0 AND
	r.eff_gr_pl<= @AsOfDate
	AND (r.exp_gr_pl IS NULL OR (r.exp_gr_pl is not null and r.eff_gr_pl <> r.exp_gr_pl and r.exp_gr_pl >@AsOfDate))

END
ELSE
BEGIN
     SET @EligStatus='Error'	
     INSERT INTO #tempErrorTable Values ('SubInput','No member identified with the given options in the group plan.');
	 THROW 51000,'User Validation Faild',1

END

--validate Patient
IF @DepSW=1
BEGIN
IF @PatID>0
BEGIN
IF EXISTS (Select m.member_id 
			   From member m
			   JOIN #tempMGP t on m.family_id=t.member_id
			   Where m.member_id<>m.family_id AND m.member_id=@PatID AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				Select Distinct m.member_id 
				   From member m
				   JOIN #tempMGP t on m.family_id=t.member_id
				   Where m.member_id<>m.family_id AND m.member_id=@PatID AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END

END
ELSE IF len(@PatAltID)>0
BEGIN

IF EXISTS (Select m.member_id 
			   From member m
			   JOIN #tempMGP t on m.family_id=t.member_id
			   Where m.member_id<>m.family_id AND m.alt_id=@PatAltID AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				Select Distinct m.member_id 
				   From member m
				   JOIN #tempMGP t on m.family_id=t.member_id
				   Where m.member_id<>m.family_id AND m.alt_id=@PatAltID AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END

END

ELSE IF len(@PatSSN)>0
BEGIN

IF EXISTS (Select m.member_id 
			   From member m
			   JOIN #tempMGP t on m.family_id=t.member_id
			   Where m.member_id<>m.family_id AND m.member_ssn=@PatSSN AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				Select Distinct m.member_id 
				   From member m
				   JOIN #tempMGP t on m.family_id=t.member_id
				   Where m.member_id<>m.family_id AND m.member_ssn=@PatSSN  AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END
END
ELSE IF len(@patSourceID)>0
BEGIN

IF EXISTS (Select m.member_id 
			   From member m
			   JOIN #tempMGP t on m.family_id=t.member_id
			   Where m.member_id<>m.family_id AND m.source_id=@patSourceID AND m.member_id>0 AND m.member_code=@PatMemberCode)
			   BEGIN
			    INSERT INTO #tempPatient
				Select Distinct m.member_id 
				   From member m
				   JOIN #tempMGP t on m.family_id=t.member_id
				   Where m.member_id<>m.family_id AND m.source_id=@patSourceID AND m.member_id>0
				   AND m.member_code=@PatMemberCode

			   END

END

END

---if patient info not available check take from subscriber

IF @DepSW=0
BEGIN

INSERT INTO #tempPatient
		 Select top 1 member_id
			From #tempMGP t
			

END

IF EXISTS(Select member_id from #tempPatient)
BEGIN 
  IF EXISTS(Select t.member_id from #tempPatient t 
	JOIN #tempPatient s ON s.member_id<>t.member_id)
  BEGIN
	 INSERT INTO #tempErrorTable Values ('PatientInput','Multiple Patients found in the database for the given options ');
	 THROW 51000,'User Validation Faild',1
	END

---needs to check the range values

Select  m.rlplfc_id, 
            	m.mb_gr_pl_id, 
            	m.member_id, 
            	m.facility_id, 
            	m.eff_date, 
            	m.exp_date 
				INTO #AssignedFCs
				FROM rlplfc m, rlmbgrpl s ,#tempPatient t
				where t.member_id=s.member_id   
                and m.mb_gr_pl_id = s.mb_gr_pl_id   
                and (s.exp_gr_pl is null or (s.exp_gr_pl is not null and s.exp_gr_pl != s.eff_gr_pl and  s.exp_gr_pl > @AsOfDate ) )  
                and (m.exp_date is null or m.exp_date != m.eff_date) 

--drop table #AssignedFCs 

IF NOT EXISTS(Select *From #AssignedFCs a
Where (a.eff_date<= @AsOfDate ) AND (a.exp_date is null OR a.exp_date < @AsOfDate))
BEGIN
     SET @EligStatus='InActive'	
     INSERT INTO #tempErrorTable Values ('PatientInput','Patient is not active in the given Group Plan as of the given date '+Cast(@AsOfDate as nvarchar(10)));
	 THROW 51000,'User Validation Faild',1
END

--IF NOT EXISTS(Select *From #AssignedFCs a
--Where (a.eff_date>@AsOfDate OR a.eff_date=@AsOfDate ) AND (a.exp_date is null OR a.exp_date < @AsOfDate))
--BEGIN
--     SET @EligStatus='InActive'	
--     INSERT INTO #tempErrorTable Values ('Pat','Patient is not active in the given Group Plan as of the given date . ');
--	 THROW 51000,'User Validation Faild',1
--END

END
ELSE
BEGIN
	 SET @EligStatus='Error'	
     INSERT INTO #tempErrorTable Values ('PatientInput','No matching Patient found in the database for the given options ');
	 THROW 51000,'User Validation Faild',1

END

DECLARE @EffDate date=null;
DECLARE @EligibilityEnd date=null;
DECLARE @EligibilityBegin date=null;
DECLARE @ExpGRPL date=null;
DECLARE @iFCCount INT=0
DECLARE @iCount INT=1

Select @ExpGRPL=t.exp_gr_pl
	From #GRPL t
	JOIN #tempMGP m on t.mb_gr_pl_id=m.mb_gr_pl_id


Select 
    ROW_NUMBER() Over (order by a.mb_gr_pl_id asc) as id,a.*
	INTO #tempAssignedFCs
	From #AssignedFCs a
	Join #tempMGP t on t.mb_gr_pl_id=a.mb_gr_pl_id
	
Select @iFCCount=Count(1) From #tempAssignedFCs

SET @EligStatus = 'Active';

--select *From #tempAssignedFCs
BEGIN TRY
While @iCount<=@iFCCount
BEGIN

	DECLARE @getFCEffDate date=null;
	DECLARE @getFCExpDate date=null;

	Select @getFCEffDate=t.eff_date,@getFCExpDate=t.exp_date 
	from #tempAssignedFCs t Where t.id=@iCount

	IF @EligibilityBegin is NULL
		SET @EligibilityBegin=@getFCEffDate

	IF @EligibilityEnd is not null AND @getFCEffDate>@EligibilityEnd 
	BEGIN
      SET @EligStatus='--Patient Lapse';
	  THROW 51000,'User Validation Faild',1
    END
	IF @ExpGRPL is null
	  SET @EligibilityEnd=@getFCExpDate
	ELSE 
	BEGIN
		IF @getFCExpDate is not null AND @getFCExpDate< @ExpGRPL
			SET @EligibilityEnd=@getFCExpDate
		ELSE
		    SET @EligibilityEnd=@ExpGRPL	
	 

	END

	IF @EligibilityEnd is null
	BEGIN
	  SET @EligStatus='--Continuous coverage';
	  THROW 51000,'User Validation Faild',1
	END

	SET @iCount= @iCount+1
END
END TRY
BEGIN CATCH
IF ERROR_MESSAGE()<>'User Validation Faild'
 THROW;
END CATCH

DECLARE @iGCount INT=0
DECLARE @iG INT=1

Select ROW_NUMBER() Over(Order by l.mb_gr_pl_id asc) as Id,l.*
	INTO #tempGRPL
	From #GRPL l
	JOIN #tempMGP t on t.group_id=l.group_id AND t.plan_id=l.plan_id

Select @iGCount=COUNT(1) From #tempGRPL

BEGIN TRY
WHILE @iG<=@iGCount
BEGIN
	DECLARE @getGEffDate date=null;
	DECLARE @getGExpDate date=null;

	Select  @getGEffDate=l.eff_gr_pl, @getGExpDate=l.exp_gr_pl  From #tempGRPL l
	Where l.Id=@iCount

 IF @EligibilityEnd IS NOT NULL
 BEGIN
	IF @getGEffDate=@EligibilityEnd
	BEGIN
	 SET @EligibilityEnd=@getGExpDate
	 SET @EffDate=@getGExpDate
			
			        SET @iCount=1
					SET @ExpGRPL=@getGExpDate

					While @iCount<=@iFCCount
					BEGIN

						SET @getFCEffDate =null;
						SET @getFCExpDate =null;

						Select @getFCEffDate=t.eff_date,@getFCExpDate=t.exp_date 
						from #tempAssignedFCs t Where t.id=@iCount

						IF @EligibilityBegin is NULL
							SET @EligibilityBegin=@getFCEffDate

						IF @EligibilityEnd is not null AND @getFCEffDate>@EligibilityEnd 
						BEGIN
						  SET @EligStatus='--Patient Lapse';
						  THROW 51000,'User Validation Faild',1
						END
						IF @ExpGRPL is null
						  SET @EligibilityEnd=@getFCExpDate
						ELSE 
						BEGIN
							IF @getFCExpDate is not null AND @getFCExpDate< @ExpGRPL
								SET @EligibilityEnd=@getFCExpDate
							ELSE
								SET @EligibilityEnd=@ExpGRPL	
	 

						END

						IF @EligibilityEnd is null
						BEGIN
						  SET @EligStatus='--Continuous coverage';
						  THROW 51000,'User Validation Faild',1
						END

						SET @iCount= @iCount+1
					END
					
	END
	
	ELSE IF @getGEffDate>@EligibilityEnd
	BEGIN
	 SET @EligStatus='--Subscriber Lapse';
     THROW 51000,'User Validation Faild',1
	END

 END

 SET @iG=@iG+1

END
END TRY
BEGIN CATCH
IF ERROR_MESSAGE()<>'User Validation Faild'
 THROW;
END CATCH

IF(@EligibilityEnd=null)
BEGIN
 SET @EligStatus='--Continuous coverage'
END

IF EXISTS( Select temp.mb_gr_pl_id From #GRPL temp
JOIN #tempMGP t on t.group_id<>temp.group_id)
BEGIN
---Group change
 SET @EligStatus='--Group Change'
END

IF EXISTS( Select temp.mb_gr_pl_id From #GRPL temp
JOIN #tempMGP t on t.group_id=temp.group_id
Where t.plan_id<>temp.plan_id
)
BEGIN
---Plan change
 SET @EligStatus='--Plan Change'
END

IF @EligibilityEnd IS NOT NULL
AND @EligStatus NOT IN ('--Subscriber Lapse','--Continuous coverage','--Patient Lapse')
BEGIN
  SET @EligStatus='--Future Term'
END

---error table info
Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempErrorTable t

---Eligibility info

Select @EligStatus as PatEligStatus,@EligibilityBegin as PatEligBeginDate,@EligibilityEnd as PatEligEndDate

---get group info

Select g.group_id as GroupID,g.alt_id as GroupAltID,g.group_name as GroupName
	From [group] g
	Where g.group_id=@gID


--get Plan info

Select p.plan_id as PlanID,p.plan_dsp_name as PlanDSPName
	From [plan] p
	Where p.plan_id=@pID

--Get subscriber info
Select 
	m.member_id as MemberID,
	m.family_id as FamilyID,
	m.alt_id as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	m.first_name as FirstName,
	m.middle_init as MiddleInitial,
	m.last_name as LastName,
	m.date_of_birth as DOB,
	m.member_ssn as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	m.action_code as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	m.h_action as UserAction,
	m.h_user as [User],
	m.hire_date as Hire,
	--m.new_ssn as SSN,
	m.source_id as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
	t.group_id AS GroupID,
	t.plan_id AS PlanID
	From #tempMGP t
	JOIN member m ON m.member_id=t.member_id
	 
--Get Subscriber Address info
Select
	a.addr_type AS [Type],
	a.addr1 AS Addr1,
	a.addr2 AS Addr2,
	a.city AS City,
	a.country AS Country,
	a.county AS County,
	a.[state] AS [State],
	a.zip AS Zip,
	p.home_phone AS Home,
	p.home_ext AS HomeX,
	p.work_phone AS Work,
	p.work_ext AS WorkX,
	p.fax AS Fax,
	p.email AS Email
	From #tempMGP t
	JOIN [address] a on t.member_id=a.sys_rec_id
	Left JOIN mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'
	
--Get Patient info

Select m.member_id as MemberID,
	m.family_id as FamilyID,
	m.alt_id as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	m.first_name as FirstName,
	m.middle_init as MiddleInitial,
	m.last_name as LastName,
	m.date_of_birth as DOB,
	m.member_ssn as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	m.action_code as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	m.h_action as UserAction,
	m.h_user as [User],
	m.hire_date as Hire,
	--m.new_ssn as SSN,
	m.source_id as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
    @gID AS GroupID,
	@pID AS PlanID
	From #tempPatient t
	JOIN member m on m.member_id=t.member_id

Select 
	a.addr_type AS [Type],
	a.addr1 AS Addr1,
	a.addr2 AS Addr2,
	a.city AS City,
	a.country AS Country,
	a.county AS County,
	a.[state] AS [State],
	a.zip AS Zip,
	p.home_phone AS Home,
	p.home_ext AS HomeX,
	p.work_phone AS Work,
	p.work_ext AS WorkX,
	p.fax AS Fax,
	p.email AS Email
	From #tempPatient t
	JOIN [address] a on t.member_id=a.sys_rec_id
	Left Join mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'
	

END TRY
BEGIN CATCH
IF ERROR_MESSAGE()='User Validation Faild'
BEGIN
  Select t.ErrorName as ErrorType,t.ErrorDesc as ErrorMsg From #tempErrorTable t

  ---Eligibility info

	Select @EligStatus as PatEligStatus,@EligibilityBegin as PatEligBeginDate,@EligibilityEnd as PatEligEndDate
	
	Select g.group_id as GroupID,g.alt_id as GroupAltID,g.group_name as GroupName
	From [group] g
	Where g.group_id=@gID


--get Plan info

Select p.plan_id as PlanID,p.plan_dsp_name as PlanDSPName
	From [plan] p
	Where p.plan_id=@pID

--Get subscriber info
Select 
	m.member_id as MemberID,
	m.family_id as FamilyID,
	m.alt_id as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	m.first_name as FirstName,
	m.middle_init as MiddleInitial,
	m.last_name as LastName,
	m.date_of_birth as DOB,
	m.member_ssn as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	m.action_code as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	m.h_action as UserAction,
	m.h_user as [User],
	m.hire_date as Hire,
	--m.new_ssn as SSN,
	m.source_id as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
	t.group_id AS GroupID,
	t.plan_id AS PlanID
	From #tempMGP t
	JOIN member m ON m.member_id=t.member_id
	 
--Get Subscriber Address info
Select
	a.addr_type AS [Type],
	a.addr1 AS Addr1,
	a.addr2 AS Addr2,
	a.city AS City,
	a.country AS Country,
	a.county AS County,
	a.[state] AS [State],
	a.zip AS Zip,
	p.home_phone AS Home,
	p.home_ext AS HomeX,
	p.work_phone AS Work,
	p.work_ext AS WorkX,
	p.fax AS Fax,
	p.email AS Email
	From #tempMGP t
	JOIN [address] a on t.member_id=a.sys_rec_id
	Left JOIN mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'
	
--Get Patient info

Select m.member_id as MemberID,
	m.family_id as FamilyID,
	m.alt_id as AltID,
	CASE 
		WHEN m.member_code=10 THEN 'Male'
		WHEN m.member_code=20 THEN 'Female'
		ELSE null
    END
	 AS Gender,
	m.first_name as FirstName,
	m.middle_init as MiddleInitial,
	m.last_name as LastName,
	m.date_of_birth as DOB,
	m.member_ssn as SSN,
	m.oed as OED,
	m.dod as DOD,
	IIF(m.student_flag='Y',1,0) AS Student,
	IIF(m.disable_flag='Y',1,0) AS [Disabled],
	m.action_code as ActionCode,
	m.h_datetime,
	m.h_msi as UserMSI,
	m.h_action as UserAction,
	m.h_user as [User],
	m.hire_date as Hire,
	--m.new_ssn as SSN,
	m.source_id as SrcID,
	m.ext_id_type as ExtIdType,
	m.student_exp as StudentExp,
	IIF(m.paperless ='Y',1,0) AS Paperless,
    @gID AS GroupID,
	@pID AS PlanID
	From #tempPatient t
	JOIN member m on m.member_id=t.member_id

Select 
	a.addr_type AS [Type],
	a.addr1 AS Addr1,
	a.addr2 AS Addr2,
	a.city AS City,
	a.country AS Country,
	a.county AS County,
	a.[state] AS [State],
	a.zip AS Zip,
	p.home_phone AS Home,
	p.home_ext AS HomeX,
	p.work_phone AS Work,
	p.work_ext AS WorkX,
	p.fax AS Fax,
	p.email AS Email
	From #tempPatient t
	JOIN [address] a on t.member_id=a.sys_rec_id
	Left Join mbr_phone p on p.address_id=a.address_id
	Where a.subsys_code='MB' AND a.addr_type='L'
END
ELSE 
 THROW; 
END CATCH

END