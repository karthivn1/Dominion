﻿CREATE PROC [dbo].[procidtest]
as
SELECT OBJECT_NAME(@@PROCID)