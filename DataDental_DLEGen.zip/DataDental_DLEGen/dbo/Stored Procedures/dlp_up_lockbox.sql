﻿/*********************************************************************
DATE				: 22/08/2016
MODIFIED BY			: COGNIZANT
CHANGE DESCRIPTION	: Issue with the procedure calling
CHANGE NUMBER		: CH001
*********************************************************************/
CREATE PROCEDURE [dbo].[dlp_up_lockbox]
    @p_batch_id INT ,
    @p_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT
    

------------------------------------------------------------------------------
--
--            Procedure:   dlp_up_lockbox
--
--            Created:     11/25/98 
--            Author:      Gene Albers
--
-- Purpose:  This SP performs update processing on DataDental LockBox
--           for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:53:53 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1







000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
   
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @s_err_rtn_text VARCHAR(64);
        DECLARE @s_error CHAR(1);
        DECLARE @a_error_no INT;
        DECLARE @i_fatal INT;
 
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @i_tmp_sp_id INT;
   
        DECLARE @err_sir_id INT;
   
        DECLARE @s_rein_group CHAR(1);
        DECLARE @ls_user CHAR(20);
   
        DECLARE @d_eff_date DATE;
        DECLARE @d_temp_date DATE;
   
        DECLARE @i_ac_id INT;
   
        DECLARE @i_ret_val1 INT;
        DECLARE @i_ret_val2 INT;
        DECLARE @i_rtn INT;
   
   -- pulled from user params
        DECLARE @s_run_date CHAR(11);
        DECLARE @s_batch_size CHAR(10);
        DECLARE @d_run_date DATE;
        DECLARE @i_batch_size INT;
        DECLARE @s_batch_type CHAR(1);
        DECLARE @c_prev_err CHAR(1);

        DECLARE @dd_batch_num VARCHAR(18);
   
        DECLARE @d_cur_stamp DATETIME;
   
   
        DECLARE @s_sir_def_name VARCHAR(18);
        DECLARE @s_proc_name VARCHAR(18);
   
        DECLARE @t_check_no CHAR(9);				--char(9).
        DECLARE @t_paid_amt CHAR(9);				--char(9).
        DECLARE @i_group_id INT;			--integer.
        DECLARE @t_dep_acct CHAR(30);		--char(30).
        DECLARE @t_alloc_flag CHAR(1);		--char(1).
        DECLARE @t_pay_token CHAR(50);			--char(50).

        DECLARE @m_paid_amt DECIMAL(16, 2);
 
        DECLARE @i_ref_id INT;
        DECLARE @i_check_no INT;
   
        DECLARE @i_batch_count INT;  -- batch count for insertion in al_batches
        DECLARE @i_total_count INT;  -- total, including row errors skipped
        DECLARE @i_last_total INT;
        DECLARE @i_sub_count INT;
        DECLARE @i_al_count INT;
        DECLARE @i_error_count INT;
        DECLARE @i_succ_count INT;
        DECLARE @i_init_count INT;
        DECLARE @t_sir_id INT;
        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @SWV_dl_get_sp_id INT;
        DECLARE @cGROUPS CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @v_Null INT;
   
   -----------------------begin exception handling----------------------------
   
   
   -- error converting text param values to correct type
   
   
   -- intrpt - server or user terminated -----NO ROLLBACK---
        SET NOCOUNT ON;
        SET @t_sir_id = 0;
    
        SET @i_sp_id = 0;
 
        SET @i_sir_def_id = 0;
   
        BEGIN TRY
             
   
-- set debug file to "/tmp/dlp_up_lockbox.trc";
--   TRACE ON;
   
            
            SET @s_proc_name = 'up_lockbox';
            SET @s_sir_def_name = 'lockbox';
            SET @d_cur_stamp = GETDATE();
            SET @ls_user = CONCAT('dl', @p_batch_id);
            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @p_batch_id, @s_proc_name

            SET @i_sp_id = @SWV_dl_get_sp_id;
       
            IF @i_sp_id = -1
			BEGIN
			SET @i_error_no=0
                RAISERROR('Could not retrieve valid Store Procedure ID',16,1);
				RETURN
			END
   
            SET @i_sir_def_id = dbo.dl_get_sir_def_id(@s_sir_def_name);
     
            IF @i_sir_def_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve valid SIR Table ID',16,1);
				RETURN
			END
   
   

   ------------------get params from user-------------------------------------
            
            SET @s_run_date = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                     'Run Date');
            IF ( @s_run_date IS NULL
                 OR @s_run_date = ''
               )
                OR LEN(@s_run_date) = 0
				BEGIN
				SET @i_error_no=0
                RAISERROR('Missing Run Date',16,1);
				RETURN
			END
            ELSE
                BEGIN
				BEGIN
                    SET @s_error_descr = 'Invalid Run Date Format';
					--RETURN
					END
                    IF SUBSTRING(@s_run_date, 3, 1) != '/'
                        SET @s_run_date = SUBSTRING(@s_run_date, 6, 2) + '/'
                            + SUBSTRING(@s_run_date, 9, 2) + '/'
                            + SUBSTRING(@s_run_date, 1, 4);
		
		
                    SET @d_run_date = cast(@s_run_date as date);
                END;
   
               
            SET @s_batch_size = dbo.dl_get_param_value(@p_batch_id, @i_sp_id,
                                                       'Batch Size');
            IF ( @s_batch_size IS NULL
                 OR @s_batch_size = ''
               )
                OR LEN(@s_batch_size) = 0
				BEGIN
				SET @i_error_no=0
                RAISERROR('Missing Batch Size',16,1);
				RETURN
			END
            ELSE
                BEGIN
				
                    SET @s_error_descr = 'Invalid Batch Size prameter';
					--RETURN
					SET @i_batch_size = @s_batch_size;
                END;
   

   -- get data using gen procs          --
   -- this param is also used in afterload, so just grab that one --
            EXECUTE @i_tmp_sp_id = dbo.dl_get_sp_id @p_batch_id, 'al_lockbox';
            IF @i_tmp_sp_id = -1
			BEGIN
				SET @i_error_no=0
                RAISERROR('Could not retrieve Store Procedure ID for Parameter',16,1);
				RETURN
			END
   
            SET @s_batch_type = dbo.dl_get_param_value(@p_batch_id,
                                                       @i_tmp_sp_id,
                                                       'Batch Type');
            IF ( @s_batch_type IS NULL
                 OR @s_batch_type = ''
               )
                OR LEN(@s_batch_type) = 0
				BEGIN
					SET @i_error_no=0
                RAISERROR('Missing Batch Type Value',16,1);
				RETURN
			END
            ELSE
                IF @s_batch_type NOT IN ( 'G', 'I' )
				BEGIN
					SET @i_error_no=0
                    RAISERROR('Batch Type must be (G or I)',16,1);
					RETURN
			END
      
   


   ---------------get batch num for al_batches-------------------
            EXECUTE dbo.dlp_lb_gen_bnum @p_batch_id,@dd_batch_num OUTPUT;
			IF ( @dd_batch_num IS NULL
                 OR @dd_batch_num = ''
               )
			   BEGIN
				SET @i_error_no=0
                RAISERROR('Cannot generate a batch number',16,1);
				RETURN
			END
   
   
   -- prepare for keeping stats on preprocessing-----------------
            
          EXECUTE dbo.dl_it_statistics @p_batch_id, @i_sp_id, @p_start_time,
                @i_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @s_error_descr OUTPUT;
            IF @i_error_no <= 0
			BEGIN
			SET @i_error_no=0
      RAISERROR('(Internal) error when creating statistics',16,1);
				RETURN
			END
   
             
   
   -- check if there were errors logged for prev runs
            IF EXISTS ( SELECT  *
                        FROM    dbo.dl_log_error (NOLOCK)
                        WHERE   config_bat_id = @p_batch_id
                                AND sp_id = @i_sp_id )
                SET @c_prev_err = 'T';
            ELSE
                SET @c_prev_err = 'F';
   

   -- get initial count of rows that have passed pre-processing --
            SELECT  @i_init_count = COUNT(*)
            FROM    dbo.dls_lockbox (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'U';
  
   -- begin with 1, cuz 1st insert into alloc tbl must begin with 1
            SET @i_batch_count = 1;
            SET @i_total_count = 0;
            SET @i_succ_count = 0;
            SET @i_last_total = 0;
   --------------------------------------------------------------------------
   -- retrieve unique group id and proccess one group at a time------------
   --------------------------------------------------------------------------
   
      
         ---user or server terminated------
         
      
         -- exit if could not gen new batch #
         
      
      --------------------begin external loop-----------------------
            SET @cGROUPS = CURSOR  FOR SELECT DISTINCT dls_group_id 
      FROM dbo.dls_lockbox (NOLOCK)
      WHERE dls_batch_id = @p_batch_id
      AND dls_status = 'P';

            OPEN @cGROUPS;
            FETCH NEXT FROM @cGROUPS INTO @i_group_id;
			
			
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    BEGIN
                        DECLARE @cSIR CURSOR;
         
         -- only other exception of -746 is reinstatement failure
         
         -- get num of group rows already counted
         
            
         -- subtract the # of rows to be rolled back from the
         -- batch count and the succes count
          -- rolls back entire group's records 

         
         
         -- if err was gen because could not reinstate group, then
         --    set status to error in dls_lockbox for entire group
         --    log an error for each row that belongs to group
                        BEGIN TRY
                            
                            SET @s_error = 'N';
                            SET @s_rein_group = 'N';
                            SET @d_eff_date = NULL;
      
      --------------------------------------------------------------------------
      -- retrieve unique group id and proccess one group at a time------------
      --------------------------------------------------------------------------
      
         
            -- problems retrieving data from dB --------
               

         -- intrpt - server or user terminated --------
         
      
            -- record identified as being in alloc tables already
               

         ---------begin update of allocation tables-------------

         -- if this proc and batch had prev stored errors, then
         -- call sub-proc to see if it was this row, and if so, 
         -- move to err history table
                            SET @cSIR = CURSOR  FOR SELECT dls_sir_id, paid_amt,   dls_deposit_acct, check_no,   dls_alloc_flag, pay_token
      
               FROM dbo.dls_lockbox (NOLOCK)
               WHERE dls_batch_id = @p_batch_id
               AND dls_status = 'P'
               AND dls_group_id = @i_group_id;
                            OPEN @cSIR;
                            FETCH NEXT FROM @cSIR INTO @t_sir_id, @t_paid_amt,
                                @t_dep_acct, @t_check_no, @t_alloc_flag,
                                @t_pay_token;
								
                            WHILE @@FETCH_STATUS = 0
                                BEGIN
   BEGIN
         
               -- total count, regardless of success
               
           
               -- will continue with next record of group, if exists
               
      
            -- if fatal err, rollback and cont with next grp - else resume
            
      
               -- get num of group rows not already counted
               
            
               -- get num of group rows inserted in alloc tables,
               -- that will be rolled back
               
            
               -- only set row that failed to "E", tot count will include
               -- all rows for group as processed above
               
            
               -- prev call was rolled back
               
            
               -- will break out of inner foreach and continue with next group
                                        BEGIN TRY
                                            IF @c_prev_err = 'T'
                                                BEGIN
                                                   
                                                    EXECUTE dbo.dl_clean_curr_err @p_batch_id,
                                                        @t_sir_id, @i_sp_id,
                                                        @i_error_no OUTPUT,
                                                        @s_err_rtn_text OUTPUT;
                                                END;
         

         -- convert the check no from a char str to an integer
         --LET a_error_no = 65;
		 --t_check_no is already guaranteed to contain only digits else it will be null
		 --(see dlp_al_lockbox()).
                                            SET @i_check_no = @t_check_no;

         -- convert paid amount from char str to money
                                            SET @a_error_no = 55;
                                            SET @m_paid_amt = CAST(@t_paid_amt AS DECIMAL(16,2));
                                            SET @a_error_no = 0;
		 
		 /*
         -----------check if record already in alloc tables --------
         IF EXISTS( SELECT credit_id
                    FROM al_batches
                    WHERE group_id = i_group_id
                    AND   amount = m_paid_amt
                    AND   check_no = i_check_no)  THEN

            RAISE EXCEPTION -746, 150, "Record already loaded";
         END IF;
         */
		 
                                            IF ( (@t_pay_token IS NOT NULL
                                                 AND @t_pay_token <> '')
                                               )
                                                IF ( LEN(RTRIM(LTRIM(@t_pay_token))) > 0 )
                                                    UPDATE  dbo.[group]
                                                    SET     pay_token = @t_pay_token
                                                    WHERE   group_id = @i_group_id;
			
		
		 
         ---- begin updating allocation tables with data from record ----
		 
                      IF ( @m_paid_amt IS NOT NULL
                                                 AND @m_paid_amt > 0.00
                                               )

											 													  

                                                INSERT  INTO dbo.al_batches
                                                        ( batch_no ,
                                                          batch_seq ,
															group_id ,
                                                          recv_date ,
                                                          deposit_date ,
                                                          amount ,
                                                          deposit_account ,
                                                     open_batch ,
														  a_m_alloc_flag ,
                                                          source ,
                                                          check_no ,
                                                          al_userid ,
                                                          timestamp
                                                        )
                                                VALUES  ( @dd_batch_num ,           -- unique batch no
                                                          @i_batch_count ,          -- num of record for this batch no
                                                          @i_group_id ,             -- group id
                                                          @d_run_date ,             -- date entered by user in GUI
                                                          @d_run_date ,             -- date entered by user in GUI
                                                          @m_paid_amt ,             -- amount paid to the account
                                                          @t_dep_acct ,             -- account no the payment was deposited in
                                                          'C' ,                    -- batch status - 'C'losed
                                                          @t_alloc_flag ,           -- allocation type - 'M'anual or 'A'uto
                                                          @s_batch_type ,           -- source - 'G'roup or 'I'ndividual
                                                          @i_check_no ,             -- check no
                                                          @ls_user ,                -- batch id of dataload proc
                                                          @d_cur_stamp
                                                        );           -- current time stamp
         
                                            IF ( @m_paid_amt IS NOT NULL
                                                 AND @m_paid_amt > 0.00
                                               )
                                                BEGIN
                                                    SELECT  @i_ref_id = credit_id
                                                    FROM    dbo.al_batches (NOLOCK)
                                                    WHERE   batch_no = @dd_batch_num
                                                            AND batch_seq = @i_batch_count
                                                            AND timestamp = @d_cur_stamp;
                                                   
                                                    IF @i_ref_id IS NULL
													BEGIN
														SET @i_error_no=180
                                                        RAISERROR('Cannot retrieve batch record from al_batches',16,1);
														RETURN
													END
                                                END;
		 
                                            IF ( @m_paid_amt IS NOT NULL
                                                 AND @m_paid_amt > 0.00
                                               )
                                                INSERT  INTO dbo.allocation
                                                        ( group_id ,
                                   al_transaction ,
                                                          tran_code ,
                                                          tran_type ,
                                                          plan_id ,
                                        fee_id ,
                                                          invoice_ref ,
                                                          ref_id ,
                                                          amount ,
                                   bal_due ,
                                       reversal_id ,
                                                          rev_from_id ,
                                                          al_userid ,
                                                          al_timestamp
                                                        )
                                                VALUES  ( @i_group_id ,    -- group id
                                                          NULL ,          -- al_transaction
                                                          'CP' ,          -- transaction code
                                                          'A' ,           -- transaction type
                                                          NULL ,          -- plan id
                                                          NULL ,          -- fee id
                                                          NULL ,          -- invoice no
                                                          @i_ref_id ,      -- al_batches ref id
                                                          @m_paid_amt ,    -- amount paid
                                                          0 ,             -- bal_due
                                                          NULL ,          -- reversal_id
                                                          NULL ,          -- rev_from _id
                                                          @ls_user ,       -- batch id of dataload proc
                                                          @d_cur_stamp
                                                        );  -- current time stamp
         
		 
         -- check to see if there is an action to reinstate group 
         -- for this entry in dls_lockbox
                                            SET @i_ac_id = NULL;
                                            SET @d_temp_date = NULL;
                                            SELECT  @d_temp_date = action_date ,
                                                    @i_ac_id = action_code_id
                                            FROM    dbo.dl_action (NOLOCK)
                                            WHERE   dls_sir_id = @t_sir_id
                                                    AND batch_id = @p_batch_id
                                                    AND action_code = 'RG'
                                                    AND process_status = 'N';
                                            
                                            IF @i_ac_id IS NOT NULL
                                                BEGIN
                                                    UPDATE  dbo.dl_action
                                                    SET     process_status = 'Y'
                                                    WHERE   action_code_id = @i_ac_id;
                                                    IF @s_rein_group = 'N'
                                                        AND @d_temp_date IS NOT NULL
                                                        BEGIN
                                                            SET @d_eff_date = @d_temp_date;
                                                            SET @s_rein_group = 'Y';
                                                        END;
                     END;
         

         -- update row status to 'U'pdate, pending no group problems
                                            UPDATE  dbo.dls_lockbox
                                            SET     dls_status = 'U'
                                            WHERE dls_sir_id=@t_sir_id;
         
       -- total count, regardless of success
                                            SET @i_total_count = @i_total_count
                                                + 1;
  SET @i_succ_count = @i_succ_count
                                                + 1;
                SET @i_batch_count = @i_batch_count
                                                + 1;
                                        END TRY
                                        BEGIN CATCH
                                            --SET @i_error_no = ERROR_NUMBER();
                                            SET @i_isam_error = ERROR_LINE();
                                            SET @s_error_descr = ERROR_MESSAGE();
                                            IF @i_error_no = -244
                                                OR @i_error_no = -245
                                                OR @i_error_no = -246
                                                SET @a_error_no = 1000;

												IF ERROR_NUMBER()=50000
												 BEGIN
                                    
													   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
															@i_sp_id, @i_sir_def_id, @t_sir_id,
															@i_error_no;
                                   
													 END;
            
                                            IF @a_error_no = 0
                                                SET @a_error_no = @i_error_no;
            
         
            -- if fatal err, rollback and cont with next grp - else resume
                                          
                        -- CH001 : Ossue with the procedure  calling 
                                            DECLARE @SWV_dl_get_err_sevr CHAR;	
                                            EXECUTE dl_get_err_sevr @i_sp_id,
                                                @a_error_no,
                                                @SWV_dl_get_err_sevr OUTPUT;
                                            IF ( @SWV_dl_get_err_sevr ) = 'F'
      
               -- get num of group rows not already counted
                                                BEGIN
                                                    SELECT  @i_sub_count = COUNT(*)
                                                    FROM    dbo.dls_lockbox (NOLOCK)
                                                    WHERE   dls_group_id = @i_group_id
                                                            AND dls_batch_id = @p_batch_id
                                                            AND dls_status IN (
                                                            'P' );
                                                    SET @i_total_count = @i_total_count
                                                        + @i_sub_count;
            
               -- get num of group rows already inserted into allocation tables
                                                    SELECT  @i_al_count = COUNT(*)
                                                    FROM    dbo.dls_lockbox (NOLOCK)
                        WHERE   dls_group_id = @i_group_id
                                                            AND dls_batch_id = @p_batch_id
                                                            AND dls_status IN (
                                                            'U' );
                                                    SET @i_batch_count = @i_batch_count
                                                        - @i_al_count;
                                                    SET @i_succ_count = @i_succ_count
                                                        - @i_al_count;
                                                     
                                                    
            
               -- only set row that failed to "E", tot count will include
   -- all rows for group as processed above
                                                    UPDATE  dbo.dls_lockbox
                                                    SET     dls_status = 'E'
                                                    WHERE   dls_sir_id = @t_sir_id;
            
               -- log error that occurred on current record
                                                   
                                                    EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
                                                        @i_sp_id,
                                                        @i_sir_def_id,
                                                        @t_sir_id, @a_error_no;
                                                    SET @s_error = 'Y';
                                                     
            
               -- will break out of inner foreach and continue with next group
                                                    GOTO SWL_Label3;
                                                END;
                                        END CATCH;
                                    END;
                                    SWL_Label4:
                                    FETCH NEXT FROM @cSIR INTO @t_sir_id,
                                        @t_paid_amt, @t_dep_acct, @t_check_no,
                                        @t_alloc_flag, @t_pay_token;
                                END;
                            SWL_Label3:
                            CLOSE @cSIR; -----internal loop------end of unique group processing-------
      
      -- check if any errors occured while updating the last group
                            IF @s_error = 'N'
      
         -- check if need to reinstate group
		/* temp $$ks - 20140521$$ks stop reinstate of group until we figure out if we want to do this here
         IF s_rein_group = "Y" THEN
         
            LET i_ret_val1,
                i_ret_val2,
                s_error_descr = dlp_lb_rein_grp( p_batch_id,
                                                 i_group_id,
                                                 d_eff_date);
        IF i_ret_val1 = -746 THEN
               RAISE EXCEPTION -746, i_ret_val2, s_error_descr;
            ELIF i_ret_val1 = -1 THEN
               RAISE EXCEPTION i_ret_val2, 0, s_error_descr;
            END IF;
         END IF;
	 */
                                IF @s_error = 'N'
         
            -- commits all changes made to 
            -- allocation tables, dls_lockbox and dl_action
                                    BEGIN
                                         
         
            -- check if new group no needs to be generated
                                        IF @i_batch_count > @i_batch_size
            
               -- get new batch no and reset total count
                                            BEGIN
                                                EXECUTE dbo.dlp_lb_gen_bnum @p_batch_id,@dd_batch_num OUTPUT;
                                                IF ( @dd_batch_num IS NULL
                                                     OR @dd_batch_num = ''
                                                   )
												   BEGIN
													SET @i_error_no=200
                                                    RAISERROR('Cannot generate a batch number',16,1);
													RETURN
													END
               
                                                SET @i_batch_count = 1;
                                            END;
                                    END;
         
       -- end check error condition for specific group


      ---------update stats every 100 records-----------------------
                            IF @i_total_count > ( @i_last_total + 100 )
                                BEGIN
                                    SET @i_error_count = @i_total_count
                                        - @i_succ_count;
         
         -----update the stats----------
                                    UPDATE  dbo.dl_bat_statistics
                                    SET     tot_record = @i_total_count ,
                                            tot_success_rec = @i_succ_count ,
         tot_fail_rec = @i_error_count
                                    WHERE   bat_statistics_id = @i_statistics_id;
                                    SET @i_last_total = @i_total_count;
                                END;
                        END TRY
                        BEGIN CATCH
                           -- SET @i_error_no = ERROR_NUMBER();
                            SET @i_isam_error = ERROR_LINE();
                            SET @s_error_descr = ERROR_MESSAGE();

         --- problems retrieving data from dB----
    
            -- do nothing
				IF ERROR_NUMBER()=50000
												 BEGIN
                                    
													   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
															@i_sp_id, @i_sir_def_id, @t_sir_id,
															@i_error_no;
                                   
													 END;
            
                            IF @i_error_no IN ( -213, -457 )
                                BEGIN
                                    IF @i_error_no <> 50000
                                        SET @s_error_descr = CAST(@i_error_no AS VARCHAR)
                                            + ':' + @s_error_descr;
                                    RAISERROR(@s_error_descr,16,1);
                                END;
                            ELSE
                                IF @i_error_no IN ( -244, -245, -246 )
                                    BEGIN
                                        SET @v_Null = 0;
                                    END;
                                ELSE
                                    BEGIN
                                         
                                        SET @s_err_rtn_text = 'DB Error: '
                                            + @i_error_no + ' Error msg: '
                                            + @s_error_descr;
                                        SET @SWP_Ret_Value = -1;
                                        SET @SWP_Ret_Value1 = @s_err_rtn_text;
                                        RETURN;
                                    END;
                        END CATCH;
                    END;
                    FETCH NEXT FROM @cGROUPS INTO @i_group_id;
                END;
            CLOSE @cGROUPS;  --------------end of outside loop---------------------------

   
   ---------------perform final err count, update stats-----------------------

            SELECT  @i_succ_count = COUNT(*)
            FROM    dbo.dls_lockbox (NOLOCK)
            WHERE   dls_batch_id = @p_batch_id
                    AND dls_status = 'U';
            SET @i_succ_count = @i_succ_count - @i_init_count;
            SET @i_error_count = @i_total_count - @i_succ_count;
            EXECUTE @SWV_dl_upd_statistics=dbo.dl_upd_statistics @i_statistics_id, @i_total_count,
                @i_succ_count, @i_error_count;
            IF @SWV_dl_upd_statistics <> 1

      --TRACE OFF;
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = CONCAT(@i_total_count,
                                                 ' Failed to update statistics');
                    RETURN;
                END;
   

   -- updates this step (sp_id) to S  Success/Complete  --
            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;

   --  updates entire batch status to S Success/Complete  --
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @p_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Finished Update (the final process) for Batch ',
                                         @p_batch_id);
            RETURN;
        END TRY
        BEGIN CATCH
            --SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();

			IF ERROR_NUMBER()=50000
												 BEGIN
                                    
													   EXECUTE @i_fatal = dbo.usp_dl_log_error @p_batch_id,
															@i_sp_id, @i_sir_def_id, @t_sir_id,
															@i_error_no;
                                   
													 END;
            
             
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
			RETURN;
        END CATCH;
        SET NOCOUNT OFF;

   
   -------------begin body of proc--------------------------------------------
    END;