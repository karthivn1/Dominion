﻿/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/
CREATE PROCEDURE [dbo].[dlp_check_sg_addr]
    @a_batch_id INT ,
    @a_new_member CHAR(1) ,
    @i_member_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(2) = NULL OUTPUT
    
 
/*error variable*/
AS
    BEGIN
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error CHAR(1);
        DECLARE @s_error_descr VARCHAR(64);
        DECLARE @i_fatal INT;

        DECLARE @a_error_no INT;
        DECLARE @n_error_no INT;
        DECLARE @n_error_text VARCHAR(64);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @n_error_count INT;
        DECLARE @s_dls_status CHAR(1);
        DECLARE @n_g1 INT;
        DECLARE @n_g2 INT;
        DECLARE @n_g4 INT;
        DECLARE @has_addr CHAR(1);
        DECLARE @has_phone CHAR(1);
        DECLARE @dds_addr_id INT;
        DECLARE @dds_addr1 CHAR(30);
        DECLARE @dds_addr2 CHAR(30);
        DECLARE @dds_city VARCHAR(30);
        DECLARE @dds_state CHAR(2);
        DECLARE @dds_zip CHAR(5);
        DECLARE @mb_phone_count INT;
        DECLARE @dds_home_phone CHAR(10);
        DECLARE @dds_home_ext CHAR(5);
        DECLARE @dds_work_phone CHAR(10);
        DECLARE @dds_work_ext CHAR(5);
        DECLARE @dds_email VARCHAR(250);
/* paramater variable*/

/*member info in sir table*/

        DECLARE @d_zip_id INT;
        DECLARE @d_city CHAR(30);
        DECLARE @d_state CHAR(2);
        DECLARE @d_county CHAR(30);
        DECLARE @d_phone_err CHAR(1);
        DECLARE @d_phone INT;
        DECLARE @d_ext INT;
        DECLARE @d_email VARCHAR(250);
        DECLARE @as_mb_id INT;
        DECLARE @as_action_code CHAR(2);

DECLARE @sg_sp_id integer;
DECLARE @sg_sir_def_id integer;
DECLARE @sg_sir_def_name varchar(14);
DECLARE @sg_proc_name varchar(14);
DECLARE @sg_config_id integer;
DECLARE @n_has_facility_id char(1);
DECLARE @n_multiple_plans char(1);
DECLARE @n_allow_pl_change char(1);
DECLARE @n_multiple_fc char(1);
DECLARE @n_allow_fc_change char(1);
DECLARE @n_def_eff_date char(10);
DECLARE @n_def_exp_date char(10);
DECLARE @n_has_term_date char(1);
DECLARE @d_def_eff_date date;
DECLARE @d_def_exp_date date;
DECLARE @s_dls_sir_id integer;
DECLARE @s_dls_sub_sir_id integer;
DECLARE @s_member_flag char(2);
DECLARE @s_alt_id char(20);
DECLARE @s_ssn char(11);
DECLARE @s_sub_ssn char(11);
DECLARE @s_sub_alt_id char(20);
DECLARE @s_member_code char(3);
DECLARE @s_last_name char(15);
DECLARE @s_paperless char(1);
DECLARE @s_first_name char(15);
DECLARE @s_middle_init char(1);
DECLARE @s_name_prefix char(5);
DECLARE @s_name_suffix char(5);
DECLARE @s_date_of_birth char(10);
DECLARE @s_student_flag char(1);
DECLARE @s_disable_flag char(1);
DECLARE @s_cobra_flag char(1);
DECLARE @s_msg_group_id integer ;
DECLARE @s_plan_id integer;
DECLARE @s_facility_id integer;
DECLARE @s_address1 char(30);
DECLARE @s_address2 char(30);
DECLARE @s_city char(30);
DECLARE @s_state char(2);
DECLARE @s_zip char(5);
DECLARE @s_zipx char(4);
DECLARE @s_home_phone char(10);
DECLARE @s_home_ext char(5);
DECLARE @s_work_phone char(10);
DECLARE @s_work_ext char(5);
DECLARE @s_email char(250);

  --DECLARE @SWV_cursor_var1 CURSOR;
        SET NOCOUNT ON;
        SET @sg_sp_id =0;
        
        
        SET @sg_sir_def_id =0;
        
        SET @sg_sir_def_name ='';
        
        SET @sg_proc_name ='';
        
        SET @sg_config_id =0;
        
        SET @n_has_facility_id ='';
        
        SET @n_multiple_plans ='';
        
        SET @n_allow_pl_change ='';
        
        SET @n_multiple_fc ='';
        
        SET @n_allow_fc_change ='';
        
        SET @n_def_eff_date ='';
        
        SET @n_def_exp_date ='';
        
        SET @n_has_term_date ='';
        
        SET @d_def_eff_date =NULL;

     SET @d_def_exp_date =NULL;
  
        SET @s_dls_sir_id =0;
        
        SET @s_dls_sub_sir_id =0;
        
        SET @s_member_flag ='';
        
        SET @s_alt_id ='';
        
        SET @s_ssn ='';
        
        SET @s_sub_ssn ='';
        
        SET @s_sub_alt_id ='';
        
        SET @s_member_code ='';
        
        SET @s_last_name ='';
        
        SET @s_paperless ='';
        
        SET @s_first_name ='';
        
        SET @s_middle_init ='';
        
        SET @s_name_prefix ='';
        
        SET @s_name_suffix ='';
        
        SET @s_date_of_birth ='';
        
        SET @s_student_flag ='';
        
        SET @s_disable_flag ='';
        
        SET @s_cobra_flag ='';
        
        SET @s_msg_group_id =0;
        
        SET @s_plan_id =0;
        
        SET @s_facility_id =0;
        
        SET @s_address1 ='';
        
        SET @s_address2 ='';
        
        SET @s_city ='';
        
        SET @s_state ='';
        
        SET @s_zip ='';
        
        SET @s_zipx ='';
        
        SET @s_home_phone ='';
        
        SET @s_home_ext ='';
        
        SET @s_work_phone ='';
        
        SET @s_work_ext ='';
        
        SET @s_email ='';
       
        BEGIN TRY
            
            SET @s_error = 'N';
            SET @mb_phone_count = 0;
            SET @a_error_no = 0;
            SET @as_action_code = NULL;
            SET @has_addr = NULL;
            SET @has_phone = NULL;
            SET @n_g1 = 0;
            SET @n_g2 = 0;
            SET @n_g4 = 0;
	-- 20120528$$ks - since DOB is a required field for matching SG member
	-- I am using g1 to indicate need to update paperless switch

		select @s_paperless = VarValue from GlobalVar(NOLOCK) where VarName = 's_paperless' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_address1 = VarValue from GlobalVar(NOLOCK) where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_address2 = VarValue from GlobalVar(NOLOCK) where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_zip = VarValue from GlobalVar(NOLOCK) where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_city = VarValue from GlobalVar(NOLOCK) where VarName = 's_city' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_state = VarValue from GlobalVar(NOLOCK) where VarName = 's_state' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_home_phone = VarValue from GlobalVar(NOLOCK) where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_home_ext = VarValue from GlobalVar(NOLOCK) where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_work_phone = VarValue from GlobalVar(NOLOCK) where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_work_ext = VarValue from GlobalVar(NOLOCK) where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_email = VarValue from GlobalVar(NOLOCK) where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 1
		select @sg_sp_id = VarValue from GlobalVar(NOLOCK) where VarName = 'sg_sp_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @sg_sir_def_id = VarValue from GlobalVar(NOLOCK) where VarName = 'sg_sir_def_id' and  BatchId = @a_batch_id AND Module_Id = 1
		select @s_dls_sir_id = VarValue from GlobalVar(NOLOCK) where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 1
		
            IF ( @s_paperless IS NOT NULL
                 AND @s_paperless <> ''
               )
                AND @s_paperless IN ( 'Y', 'N' )
                SET @n_g1 = 1;
	
            
            IF ( ( ( @s_address1 IS NOT NULL
                     AND @s_address1 <> ''
                   )
                   AND LEN(@s_address1) > 0
                 )
                 OR ( ( @s_address2 IS NOT NULL
                        AND @s_address2 <> ''
                      )
                      AND LEN(@s_address2) > 0
                    )
                 OR ( ( @s_zip IS NOT NULL
                        AND @s_zip <> ''
                      )
                      AND LEN(@s_zip) > 0
                    )
                 OR ( ( @s_city IS NOT NULL
                        AND @s_city <> ''
                      )
                      AND LEN(@s_city) > 0
                    )
             OR ( ( @s_state IS NOT NULL
                        AND @s_state <> ''
                      )
                      AND LEN(@s_state) > 0
                    )
               )
                SET @has_addr = 'Y';
            ELSE
                SET @has_addr = 'N';
	
            IF ( @a_new_member = 'Y'
                 OR @has_addr = 'Y'
               )
                BEGIN
                    
                    IF ( @s_address1 IS NULL
                         OR @s_address1 = ''
                       )
                        OR LEN(@s_address1) = 0
                        BEGIN
						SET @a_error_no =90
                            RAISERROR('Missing Address 1 info',16,1);
						End
                            /*Cognizant 07/10/17: Commented the below validation as per Dean’s request in UAT */
       --                     IF ( @s_address2 IS NULL
       --                          OR @s_address2 = ''
       --                        )
       --                         OR LEN(@s_address2) = 0
							--BEGIN
							--	SET @a_error_no =91
       --                         RAISERROR('Missing both Address 1 and 2',16,1);
							-- END;
		
                    
                    IF ( @s_zip IS NULL
                         OR @s_zip = ''
                       )
                        OR LEN(@s_zip) = 0
						BEGIN
							SET @a_error_no =92
							RAISERROR('Missing Zip Code info',16,1);
						END
                    ELSE
                        BEGIN
                            SET @a_error_no = 93;
                            /*
							SET @SWV_cursor_var1 = CURSOR  FOR SELECT zip_id, city, state_code, county
			  
            FROM dbo.usa_zip (NOLOCK) WHERE zip_code = @s_zip;
                            OPEN @SWV_cursor_var1;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @d_zip_id,
                                @d_city, @d_state, @d_county;
                            WHILE @@FETCH_STATUS = 0.
							*/
							DECLARE @SWV_cursor_var1 TABLE
            (
              id INT IDENTITY ,
              zip_id int, 
			  city char(30), 
			  state_code char(2),
			  county char(20)
            );

        INSERT  INTO @SWV_cursor_var1
                ( zip_id, city, state_code, county
                )
                SELECT zip_id, city, state_code, county
			  
            FROM dbo.usa_zip (NOLOCK) WHERE zip_code = @s_zip;

        DECLARE @cur1_cnt INT ,
            @cur_i INT;

        SET @cur_i = 1;

			--Get the no. of records for the cursor
        SELECT  @cur1_cnt = COUNT(1)
        FROM    @SWV_cursor_var1;
	
	WHILE ( @cur_i <= @cur1_cnt )
                                BEGIN
								
								SELECT @d_zip_id=zip_id,
								 @d_city=city, 
								 @d_state=state_code, 
								 @d_county=county
								FROM    @SWV_cursor_var1
								WHERE   id = @cur_i;

                                    
          IF ( @s_city IS NOT NULL
                                         AND @s_city <> ''
                                       )
                                        AND LEN(@s_city) > 0
                                        BEGIN
                                           
                                            IF @s_city = @d_city

                                                GOTO SWL_Label2;
                                        END;
                                    ELSE
                                        GOTO SWL_Label2; -- take first if no city provided
                                   /* FETCH NEXT FROM @SWV_cursor_var1 INTO @d_zip_id,
                                        @d_city, @d_state, @d_county;*/
										 SET @cur_i = @cur_i + 1;
                                END;
                            SWL_Label2:
                            --CLOSE @SWV_cursor_var1;
                            IF @d_zip_id IS NOT NULL
                                BEGIN
          
         IF ( @s_city IS NOT NULL
                                         AND @s_city <> ''
                                       )
                                        AND @s_city <> @d_city
										BEGIN
										SET @a_error_no =95
                                        RAISERROR('Different City found by USA ZIP code',16,1);
										END
				
                                   
                                    IF ( @s_state IS NOT NULL
                                         AND @s_state <> ''
                                       )
                                        AND @s_state <> @d_state
										BEGIN
										SET @a_error_no =96
                                        RAISERROR('Different State found by USA ZIP code',16,1);
										END
                                END;
                        END;
                END;
	
            SET @has_phone = 'N';
           
            IF ( @s_home_phone IS NOT NULL
                 AND @s_home_phone <> ''
               )
                AND LEN(@s_home_phone) <> 0
                BEGIN
                   
                    IF LEN(@s_home_phone) <> 10
					BEGIN
						SET @a_error_no =97
                        RAISERROR('Member Home Phone must be 10 digits long',16,1);
					END
		
                    SET @d_phone_err = 'N';
                    SET @a_error_no = 98;
                    
                    SET @d_phone = SUBSTRING(@s_home_phone, 1, 3);
                    IF @d_phone < 0
                        SET @d_phone_err = 'Y';
		
                    SET @a_error_no = 99;
                    
                    SET @d_phone = SUBSTRING(@s_home_phone, 4, 3);
                    IF @d_phone < 0
                        SET @d_phone_err = 'Y';
		
                    SET @a_error_no = 100;
                    
                    SET @d_phone = SUBSTRING(@s_home_phone, 7, 4);
                    IF @d_phone < 0
                        SET @d_phone_err = 'Y';
		
                    IF @d_phone_err = 'Y'
					BEGIN
						SET @a_error_no =101
                        RAISERROR('Error in Member Home Phone',16,1);
					END
		
                    SET @has_phone = 'Y';
                END;
	 
           
            IF ( @s_home_ext IS NOT NULL
                 AND @s_home_ext <> ''
               )
                AND LEN(@s_home_ext) <> 0
                BEGIN
                    SET @a_error_no = 102;
                    
                    SET @d_ext = SUBSTRING(@s_home_ext, 1, 5);
                    IF @d_ext < 0
					BEGIN
						SET @a_error_no =103
                        RAISERROR('Error in Member Home Phone Extension',16,1);
					END
		
                   
                    IF LEN(@s_home_ext) > 5
					BEGIN
					SET @a_error_no =104
                        RAISERROR('Member Home Phone Extension is more than 5 digits long',16,            1);
					END
		
                    
                    IF ( @s_home_phone IS NULL
                         OR @s_home_phone = ''
                       )
					   BEGIN
					   SET @a_error_no =105
                        RAISERROR('Member Home Phone is missing while Home Phone Extension is given',            16,1);
						END
		
                    SET @has_phone = 'Y';
                END;
	
            
            IF ( @s_work_phone IS NOT NULL
                 AND @s_work_phone <> ''
               )
                AND LEN(@s_work_phone) <> 0
                BEGIN
                    
                    IF LEN(@s_work_phone) <> 10
					BEGIN
						SET @a_error_no =106
                        RAISERROR('Member Work Phone must be 10 digits long',16,1);
					END
		
                    SET @d_phone_err = 'N';
                    SET @a_error_no = 107;
                    
                    SET @d_phone = SUBSTRING(@s_work_phone, 1, 3);
                    IF @d_phone < 0
    SET @d_phone_err = 'Y';
		
                    SET @a_error_no = 108;
                    
                    SET @d_phone = SUBSTRING(@s_work_phone, 4, 3);
                    IF @d_phone < 0
                        SET @d_phone_err = 'Y';
		
                    SET @a_error_no = 109;
                   
                    SET @d_phone = SUBSTRING(@s_work_phone, 7, 4);
                    IF @d_phone < 0
                        SET @d_phone_err = 'Y';
		
                    IF @d_phone_err = 'Y'
					BEGIN
						SET @a_error_no =110
                        RAISERROR('Error in Member Work Phone',16,1);
					END
		
                    SET @has_phone = 'Y';
                END;
	
            
            IF ( @s_work_ext IS NOT NULL
                 AND @s_work_ext <> ''
               )
                AND LEN(@s_work_ext) <> 0
                BEGIN
                    SET @a_error_no = 111;
                   
                    SET @d_ext = SUBSTRING(@s_work_ext, 1, 5);
                    IF @d_ext < 0
					BEGIN
						SET @a_error_no =112
                        RAISERROR('Error in Member Work Phone Extension',16,1);
					END
		
                    
                    IF LEN(@s_work_ext) > 5
					BEGIN
						SET @a_error_no =113
                        RAISERROR('Member Work Phone Extension is more than 5 digits long',16,            1);
					END
		
                  
                    IF ( @s_work_phone IS NULL
                         OR @s_work_phone = ''
                       )
					   BEGIN
						SET @a_error_no =114
                        RAISERROR('Member Wrok Phone is missing while Work Phone Extension is given',            16,1);
						END
		
                    SET @has_phone = 'Y';
                END;
	
           
            IF ( @s_email IS NOT NULL
                 AND @s_email <> ''
               )
                AND LEN(@s_email) <> 0
                SET @has_phone = 'Y';
	
	/* 20131004$$ks i_member_id is null or zero if new member = "Y"
	 */
            IF ( @a_new_member != 'Y'
                 AND ( @has_addr = 'Y'
                       OR @has_phone = 'Y'
                     )
               )
               BEGIN
                    SET @a_error_no = 160;
                    SELECT  @dds_addr_id = address_id ,
                            @dds_addr1 = addr1 ,
                            @dds_addr2 = addr2 ,
                            @dds_city = city ,
                            @dds_state = state ,
                            @dds_zip = zip
                    FROM    dbo.address (NOLOCK)
                    WHERE   subsys_code = 'MB'
                            AND sys_rec_id = @i_member_id
                            AND addr_type = 'L';
                    
                    IF @dds_addr_id IS NOT NULL
                        BEGIN
                            IF ( @has_addr = 'Y' )
                                BEGIN
                                  
                                    IF ( @s_address1 IS NOT NULL
                                         AND @s_address1 <> ''
                                       )
                                        IF ( @dds_addr1 IS NOT NULL
                                             AND @dds_addr1 <> ''
                                           )
                                            BEGIN
                                               
                                                IF @dds_addr1 != @s_address1
                                                    SET @n_g2 = 1;
                                            END;
                                        ELSE
                                            SET @n_g2 = 1;
					
				
                                    IF @n_g2 = 0
                                        BEGIN

   IF ( @s_address2 IS NOT NULL
                                     AND @s_address2 <> ''
                                               )
                                                IF ( @dds_addr2 IS NOT NULL
                                                     AND @dds_addr2 <> ''
                                                   )
                                                    BEGIN
                                                       
                                                        IF @dds_addr2 != @s_address2
                                                            SET @n_g2 = 1;
                                                    END;
                                                ELSE
                                                    SET @n_g2 = 1;
						
                                        END;
				
                                    IF @d_zip_id IS NOT NULL
                                        BEGIN
        
                                            IF ( @dds_zip IS NOT NULL
                                                 AND @dds_zip <> ''
                                               )
                                                AND @dds_zip != @s_zip
                                                IF ( (@d_city IS NULL
											   OR @d_city = '')
                                                   )
                                                    OR ( (@d_state IS NULL
                                                         OR @d_state = '')
                                                       )
                                                    OR ( (@d_county IS NULL
                                                         OR @d_county = '')
                                                       )
													   BEGIN
													   SET @a_error_no =94
                                                    RAISERROR('Member Addr ZipCode is not in USA_ZIP table',16,1);
													END
						
                                        END;
                                END;
			
                            SELECT  @mb_phone_count = COUNT(*)
                            FROM    dbo.mbr_phone (NOLOCK)
                            WHERE   address_id = @dds_addr_id;
                            IF @mb_phone_count > 1
							BEGIN
								SET @a_error_no =161
                                RAISERROR('Multiple Member Phone Records',16,1);
							END
			
                            IF @mb_phone_count = 1
                                BEGIN
                                    IF ( @has_phone = 'Y' )
                                        BEGIN
                                            SELECT  @dds_home_phone = home_phone ,
                                                    @dds_home_ext = home_ext ,
                                                    @dds_work_phone = work_phone ,
                                                    @dds_work_ext = work_ext ,
                                                    @dds_email = email
                                            FROM    dbo.mbr_phone (NOLOCK)
                                            WHERE   address_id = @dds_addr_id;
                                            
                                            IF @n_g4 = 0
                                                IF ( @dds_email IS NULL
                                                     OR @dds_email = ''
                                                   )
                                                    BEGIN
                                                        
                                                        IF ( @s_email IS NOT NULL
                                                             AND @s_email <> ''
                                                           )
                                                            SET @n_g4 = 1;
                        END;
                                           ELSE
                                                   BEGIN
                                                        
                                                        IF ( @s_email IS NOT NULL
                                                             AND @s_email <> ''
                                                           )
                                                            BEGIN
                                                              
                                                              IF @dds_email != @s_email
           SET @n_g4 = 1;
                                                            END;
                                                    END;
						
					
                IF @n_g4 = 0
                                                IF ( @dds_home_phone IS NULL
                                                     OR @dds_home_phone = ''
                                                   )
       BEGIN
                                                        
                                                        IF ( @s_home_phone IS NOT NULL
                                                             AND @s_home_phone <> ''
                                                           )
                                                            SET @n_g4 = 1;
                                                    END;
                                                ELSE
                                                    BEGIN
                                                       
                                                        IF ( @s_home_phone IS NOT NULL
                                                             AND @s_home_phone <> ''
                                                           )
                                                            BEGIN
                                                              
                                                              IF @dds_home_phone != @s_home_phone
                                                              SET @n_g4 = 1;
                                                              ELSE
                                                              BEGIN
                                                             
                                                              IF ( @s_home_ext IS NOT NULL
                                                              AND @s_home_ext <> ''
                                                              )
                                                              BEGIN
                                                             
                                                              IF ( @dds_home_ext IS NULL
                                                              OR @dds_home_ext = ''
                                                              )
                                                              OR @dds_home_ext != @s_home_ext
                                                              SET @n_g4 = 1;
                                                              END;
                                                              END;
                                                            END;
                                                    END;
						
					
                                            IF @n_g4 = 0
                                                IF ( @dds_work_phone IS NULL
                                                     OR @dds_work_phone = ''
                                                   )
                                                    BEGIN
                                                       
                                               IF ( @s_work_phone IS NOT NULL
              AND @s_work_phone <> ''
                     )
             SET @n_g4 = 1;
  END;
                                                ELSE
                                                    BEGIN
                                                       
                                                        IF ( @s_work_phone IS NOT NULL
                                                             AND @s_work_phone <> ''
                                                           )
                                                            BEGIN
                                                            
                                                              IF @s_work_phone != @dds_work_phone
                                                              SET @n_g4 = 1;
                                                              ELSE
                                                              BEGIN
                                   
                                                              IF ( @s_work_ext IS NOT NULL
                                                              AND @s_work_ext <> ''
                                                              )
                                                              BEGIN
                                                           
                                                              IF ( @dds_work_ext IS NULL
                                                              OR @dds_work_ext = ''
                                                              )
                                                              OR @dds_work_ext != @s_work_ext
                                                              SET @n_g4 = 1;
                                                              END;
                                                              END;
                                                            END;
                                                    END;
						
                                        END;
                                END;
                            ELSE
                                BEGIN
                                    SET @n_g2 = 1;
                                   
                                    IF NOT ( ( @s_home_phone IS NULL
                                               OR @s_home_phone = ''
                                             )
                                             OR ( @s_work_phone IS NULL
                                                  OR @s_work_phone = ''
                                                )
                                           )
                                        SET @n_g4 = 1;
                                END;
                        END;
                END;
	
            SET @n_g4 = @n_g4 * 4 + @n_g2 * 2 + @n_g1;
            IF @n_g4 > 0
                SET @as_action_code = CONCAT('G', @n_g4);
            ELSE
                SET @as_action_code = NULL;
	
	
--trace off;
            IF @s_error = 'Y'
                BEGIN
                    SET @SWP_Ret_Value = -1;
     SET @SWP_Ret_Value1 = @as_action_code;
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = @as_action_code;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
           -- SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            
            EXECUTE @i_fatal = dbo.usp_dl_log_error @a_batch_id, @sg_sp_id,
                @sg_sir_def_id, @s_dls_sir_id, @a_error_no;
            IF @i_fatal <> 1
                SET @s_error = 'Y';
        END CATCH;
        SET NOCOUNT OFF;

--set debug file to "/tmp/dlp_sg_addr.trc";
--trace on;
    END;