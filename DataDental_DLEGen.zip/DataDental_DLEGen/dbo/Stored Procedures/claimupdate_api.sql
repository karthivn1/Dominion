﻿CREATE PROCEDURE [dbo].[claimupdate_api]
    @proc CHAR(2) ,
    @a INT ,
    @b CHAR(10)
    
AS
    BEGIN

/*-- This procedure was converted on Fri Aug 19 02:26:26 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB,

 1
000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/

        DECLARE @returnvalue INT;
        DECLARE @returnmsg char(64);

        SET NOCOUNT ON;
        SET @returnvalue = 0;
        
        SET @returnmsg = 'Invalid Stage Cd:' ;
       
        IF ( @proc = 'AL' )
            BEGIN
                EXECUTE dbo.dlp_al_utilization @a, @b, @returnvalue OUTPUT,
                    @returnmsg OUTPUT;
					SELECT @returnvalue 'returnvalue',@returnmsg 'returnmsg'
					RETURN

            END;
        ELSE
            IF @proc = 'BU'
                BEGIN
                    EXECUTE dbo.dlp_bu_utilization @a, 0, @b,
                        @returnvalue OUTPUT, @returnmsg OUTPUT;
                    SELECT @returnvalue 'returnvalue',@returnmsg 'returnmsg'
					RETURN
                END;
            ELSE
                IF @proc = 'UP'
                    BEGIN
                        EXECUTE dbo.dlp_up_utilization @a, @b,
                            @returnvalue OUTPUT, @returnmsg OUTPUT;
                       SELECT @returnvalue 'returnvalue',@returnmsg 'returnmsg'
					RETURN
                    END;
                ELSE
                    BEGIN
                       
                        SET @returnmsg = @returnmsg;
                        RAISERROR(@returnmsg,16,1)
						RETURN
                    END;
        SET NOCOUNT OFF;
    END;