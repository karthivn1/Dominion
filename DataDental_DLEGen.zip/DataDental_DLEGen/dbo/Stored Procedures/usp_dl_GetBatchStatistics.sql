﻿CREATE PROC [dbo].[usp_dl_GetBatchStatistics]
@BatchDetailId INT
AS
BEGIN
	SELECT bat_statistics_id AS BatchStatisticsId,
		   cfg_bat_det_id AS BatchDetailId,
		   start_time AS StartTime,
		   finish_time AS FinishTime,
		   tot_record AS TotalRecord,
		   tot_success_rec AS TotalSuccessRecord,
		   tot_fail_rec AS TotalfailiureRecord,
		   created_by AS CreatedBy,
		   created_time AS CreatedTime 
	 FROM dl_bat_statistics
	 WHERE cfg_bat_det_id = @BatchDetailId
END