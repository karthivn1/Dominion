﻿CREATE PROCEDURE [dbo].[dlp_lookup_member]
    @a_full_name CHAR(1) ,
    @a_subscriber CHAR(2) ,
    @a_ssn CHAR(11) ,
    @a_last_name CHAR(15) ,
    @a_first_name CHAR(15) ,
    @a_middle_init CHAR(1) ,
    @a_date_of_birth DATE ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 INT = NULL OUTPUT ,
    @SWP_Ret_Value3 CHAR(20) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 03:43:43 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 0
00 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_member_id INT;
        DECLARE @n_family_id INT;
        DECLARE @n_alt_id CHAR(20);
        DECLARE @n_count INT;
        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;
        DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @SWV_cursor_var4 CURSOR;

        SET NOCOUNT ON;
        SET @n_count = 0;
        SET @n_member_id = NULL;
        SET @n_family_id = NULL;
        SET @n_alt_id = NULL;

        IF @a_full_name = 'Y'
            IF @a_subscriber = '00'
                BEGIN
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT member_id, family_id, alt_id
				
         FROM dbo.member (NOLOCK)
         WHERE member_ssn = @a_ssn AND
         last_name = @a_last_name AND
         first_name = @a_first_name AND
         member_code IN('10','20');
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @n_member_id,
                        @n_family_id, @n_alt_id;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            SET @n_count = @n_count + 1;
                            FETCH NEXT FROM @SWV_cursor_var1 INTO @n_member_id,
                                @n_family_id, @n_alt_id;
                        END;
                    CLOSE @SWV_cursor_var1;
                END;
            ELSE
                BEGIN
                    SET @SWV_cursor_var2 = CURSOR  FOR SELECT member_id, family_id, alt_id
				
         FROM dbo.member (NOLOCK)
         WHERE member_ssn = @a_ssn AND
         last_name = @a_last_name AND
         first_name = @a_first_name AND
					((((@a_middle_init IS NULL OR  @a_middle_init = '') OR LEN(@a_middle_init) = 0) AND
						(LEN(middle_init) = 0 OR middle_init IS NULL)) OR
						((@a_middle_init IS NOT NULL AND  @a_middle_init <> '') AND @a_middle_init = middle_init)) AND
         date_of_birth = @a_date_of_birth AND
         member_code NOT IN('10','20');
                    OPEN @SWV_cursor_var2;
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @n_member_id,
                        @n_family_id, @n_alt_id;
                    WHILE @@FETCH_STATUS = 0
                        BEGIN
                            SET @n_count = @n_count + 1;
                            FETCH NEXT FROM @SWV_cursor_var2 INTO @n_member_id,
                                @n_family_id, @n_alt_id;
                        END;
                    CLOSE @SWV_cursor_var2;
                END;
	
        ELSE
            BEGIN
                SET @a_first_name = SUBSTRING(@a_first_name, 1, 1) + '%';
                IF @a_subscriber = '00'
                    BEGIN
                        SET @SWV_cursor_var3 = CURSOR  FOR SELECT member_id, family_id, alt_id
				
         FROM dbo.member (NOLOCK)
         WHERE member_ssn = @a_ssn AND
         last_name = @a_last_name AND
         first_name LIKE RTRIM(@a_first_name) AND
         member_code IN('10','20');
                        OPEN @SWV_cursor_var3;
                        FETCH NEXT FROM @SWV_cursor_var3 INTO @n_member_id,
                            @n_family_id, @n_alt_id;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                SET @n_count = @n_count + 1;
                                FETCH NEXT FROM @SWV_cursor_var3 INTO @n_member_id,
                                    @n_family_id, @n_alt_id;
                            END;
                        CLOSE @SWV_cursor_var3;
                    END;
                ELSE
                    BEGIN
                        SET @SWV_cursor_var4 = CURSOR  FOR SELECT member_id, family_id, alt_id
				
         FROM dbo.member (NOLOCK)
         WHERE member_ssn = @a_ssn AND
         last_name = @a_last_name AND
         first_name LIKE RTRIM(@a_first_name) AND
         member_code NOT IN('10','20');
                        OPEN @SWV_cursor_var4;
                        FETCH NEXT FROM @SWV_cursor_var4 INTO @n_member_id,
                            @n_family_id, @n_alt_id;
                        WHILE @@FETCH_STATUS = 0
                            BEGIN
                                SET @n_count = @n_count + 1;
                                FETCH NEXT FROM @SWV_cursor_var4 INTO @n_member_id,
                                    @n_family_id, @n_alt_id;
                            END;
                        CLOSE @SWV_cursor_var4;
                    END;
            END;


        SET @SWP_Ret_Value = @n_count;
        SET @SWP_Ret_Value1 = @n_member_id;
        SET @SWP_Ret_Value2 = @n_family_id;
        SET @SWP_Ret_Value3 = @n_alt_id;
        RETURN;
        SET NOCOUNT OFF;
    END;