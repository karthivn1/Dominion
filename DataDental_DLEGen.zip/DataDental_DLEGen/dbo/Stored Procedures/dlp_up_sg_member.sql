﻿CREATE PROCEDURE [dbo].[dlp_up_sg_member]
    @a_batch_id INT ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    
	


--Created Date	: 05/03/2001 
--Created By	: Jacky Chang 
--Reason		: Subscriber Single Group Eligibility Updating.

--error variable
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:06:06 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1






000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_fatal INT;

        DECLARE @t_temp_action_code CHAR(2);


        DECLARE @tot_msi INT;

        DECLARE @li_1000_count INT;
        DECLARE @li_tt_prcs_cnt INT;
        DECLARE @li_family_nbr INT;
        DECLARE @li_prcs_gd_cnt INT;
        DECLARE @li_prcs_bad_cnt INT;
        DECLARE @li_dep_sir_id INT;
        DECLARE @ls_rate_code CHAR(2);
        DECLARE @s_next_family CHAR(1);
        DECLARE @t_clean_sir INT;
        DECLARE @d_pdcomm_eff DATE;
        DECLARE @t_sir_id INT;
        DECLARE @sg_config_id INT;
        DECLARE @sg_bu_sp_id INT;
        DECLARE @sg_up_sp_id INT;
        DECLARE @sg_sir_def_id INT;
        DECLARE @t_sub_sir_id INT;
        DECLARE @t_action_date DATE;
        DECLARE @n_msi INT;
        DECLARE @msi_num INT;
        DECLARE @msi_num1 INT;
        DECLARE @msi_upper INT;
        DECLARE @n_datetime datetime;
        DECLARE @s_dls_sir_id INT;
        DECLARE @s_dls_batch_id INT;
        DECLARE @s_dls_sub_sir_id INT;
        DECLARE @s_member_flag char(2);
        DECLARE @s_alt_id char(20);
        DECLARE @s_ssn char(11);
        DECLARE @s_sub_ssn char(11);
        DECLARE @s_sub_alt_id char(20);
        DECLARE @s_member_code char(3);
        DECLARE @s_optional_5 char(5);
        DECLARE @s_paperless char(1);
        DECLARE @s_last_name char(15);
        DECLARE @s_first_name char(15);
        DECLARE @s_middle_init char(1);
        DECLARE @s_date_of_birth char(10);
        DECLARE @s_student_flag char(1);
        DECLARE @s_disable_flag char(1);
        DECLARE @s_cobra_flag char(1);
        DECLARE @s_msg_group_id INT;
        DECLARE @s_plan_id INT;
        DECLARE @s_facility_id INT;
        DECLARE @s_rate_code char(2);
        DECLARE @s_mb_gppl_eff char(10);
        DECLARE @s_mb_fc_eff_date char(10);
        DECLARE @s_mb_term_date char(10);
        DECLARE @s_bank_account char(25);
        DECLARE @s_account_type char(2);
        DECLARE @s_tr_nbr char(9);
        DECLARE @s_process_code char(1);
        DECLARE @s_return_code char(3);
        DECLARE @s_return_descr char(20);
        DECLARE @s_trans_code char(2);
        DECLARE @s_address1 char(30);
        DECLARE @s_address2 char(30);
        DECLARE @s_city char(30);
        DECLARE @s_state char(2);
        DECLARE @s_zip char(5);
        DECLARE @s_zipx char(4);
        DECLARE @s_home_phone char(10);
        DECLARE @s_home_ext char(5);
        DECLARE @s_work_phone char(10);
        DECLARE @s_work_ext char(5);
       DECLARE @s_email char(250);
        DECLARE @s_producer_id int;
        DECLARE @s_comm_scheme_id char(5);
        DECLARE @s_pd_type char(2);
        DECLARE @s_license_number char(9);
        DECLARE @s_selling_period char(1);
        DECLARE @s_pdcomm_eff char(10);
        DECLARE @s_dls_mb_id INT;
        DECLARE @s_dls_sub_id INT;
        DECLARE @s_dls_msg_id INT;
        DECLARE @s_dls_group_id INT;
        DECLARE @s_dls_plan_id INT;
 DECLARE @s_dls_fc_id INT;
 DECLARE @s_dls_pd_id INT;
        DECLARE @s_dls_act_code char(2);
        DECLARE @s_new_ssn char(11);
        DECLARE @s_src_id char(20);
        DECLARE @s_subnew_ssn char(11);
        DECLARE @s_subsrc_id char(20);
        DECLARE @s_ext_id_col char(20);
        DECLARE @from_api smallint;
        DECLARE @s_sub_in_plan smallint;
        DECLARE @s_eligibility_id char(40);
        DECLARE @s_dls_pend_action smallint;
        DECLARE @SWV_dl_get_sp_id INT;
        --DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_dl_upd_statistics INT;
        DECLARE @SWV_func_DL_UPD_STATISTICS_par0 INT;	


        SET NOCOUNT ON;
		 IF NOT EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 2 AND BatchId = @a_batch_id )
			 BEGIN
	
					INSERT [dbo].[GlobalVar] ([VarName], [VarValue], [BatchId],[Module_Id])
					SELECT N'from_api',								N'', @a_batch_id, 2				
					UNION ALL SELECT N'msi_upper',					N'', @a_batch_id, 2
					UNION ALL SELECT N'n_msi',						N'', @a_batch_id, 2
					UNION ALL SELECT N's_account_type',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_address1',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_address2',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_alt_id',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_bank_account',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_city',						N'', @a_batch_id, 2
					UNION ALL SELECT N's_cobra_flag',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_comm_scheme_id',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_date_of_birth',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_disable_flag',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_act_code',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_batch_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_fc_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_group_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_mb_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_msg_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_pd_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_pend_action',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_plan_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_sir_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_sub_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_dls_sub_sir_id',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_eligibility_id',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_email',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_ext_id_col',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_facility_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_first_name',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_home_ext',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_home_phone',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_last_name',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_license_number',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_mb_fc_eff_date',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_mb_gppl_eff',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_mb_term_date',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_member_code',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_member_flag',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_middle_init',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_msg_group_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_new_ssn',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_optional_5',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_paperless',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_pd_type',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_pdcomm_eff',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_plan_id',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_process_code',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_producer_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_rate_code',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_return_code',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_return_descr',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_selling_period',			N'', @a_batch_id, 2
					UNION ALL SELECT N's_src_id',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_ssn',						N'', @a_batch_id, 2
					UNION ALL SELECT N's_state',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_student_flag',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_sub_alt_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_sub_in_plan',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_sub_ssn',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_subnew_ssn',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_subsrc_id',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_tr_nbr',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_trans_code',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_work_ext',					N'', @a_batch_id, 2
					UNION ALL SELECT N's_work_phone',				N'', @a_batch_id, 2
					UNION ALL SELECT N's_zip',						N'', @a_batch_id, 2
					UNION ALL SELECT N's_zipx',						N'', @a_batch_id, 2
					UNION ALL SELECT N't_action_date',				N'', @a_batch_id, 2
					UNION ALL SELECT N't_sir_id',					N'', @a_batch_id, 2
																			
			END

        SET @t_sir_id = 0;
       
        SET @sg_config_id = 0;
       
        SET @sg_bu_sp_id = 0;
      
        SET @sg_up_sp_id = 0;
      
        SET @sg_sir_def_id = 0;
      
        SET @t_sub_sir_id = 0;
           
        SET @n_msi = 0
        
        SET @msi_num = 0;
       
        SET @msi_num1 = 0;
       
        SET @msi_upper = 0;
        
        SET @n_datetime = NULL;
        
        SET @s_dls_sir_id = 0;
        
        SET @s_dls_batch_id = 0;
         
        SET @s_dls_sub_sir_id = 0;
       
        SET @s_member_flag = '';
      
        SET @s_alt_id = '';
       
        SET @s_ssn = '';
       
   SET @s_sub_ssn = '';
       
        SET @s_sub_alt_id = '';
       
        SET @s_member_code = '';
      
        SET @s_optional_5 = '';
      
        SET @s_paperless = '';
        
        SET @s_last_name = '';
       
        SET @s_first_name = '';
 
        SET @s_middle_init = '';
       
        SET @s_date_of_birth = '';
      
        SET @s_student_flag = '';
     
        SET @s_disable_flag = '';
        
        SET @s_cobra_flag = '';
        
        SET @s_msg_group_id = 0;

        SET @s_plan_id = 0;
      
        SET @s_facility_id = 0;
     
        SET @s_rate_code = '';
      
        SET @s_mb_gppl_eff = '';
    
        SET @s_mb_fc_eff_date = '';
     
        SET @s_mb_term_date = '';
 
        SET @s_bank_account = '';
     
        SET @s_account_type = '';
       
        SET @s_tr_nbr = '';
 
        SET @s_process_code = '';
     
        SET @s_return_code = '';

        SET @s_return_descr = '';
    
        SET @s_trans_code = '';
        
        SET @s_address1 = '';
        
        SET @s_address2 = '';
       
        SET @s_city = '';
    
        SET @s_state = '';
     
        SET @s_zip = '';
      
        SET @s_zipx = '';
     
        SET @s_home_phone = '';
        
        SET @s_home_ext = '';
      
        SET @s_work_phone = '';

        SET @s_work_ext = '';
       
        SET @s_email = '';
    
        SET @s_producer_id = 0;
      
        SET @s_comm_scheme_id = '';
     
        SET @s_pd_type = '';
       
        SET @s_license_number = '';
      
        SET @s_selling_period = '';
  
        SET @s_pdcomm_eff = '';
       
        SET @s_dls_mb_id = 0;
      
        SET @s_dls_sub_id = 0;
    
        SET @s_dls_msg_id = 0;
   
        SET @s_dls_group_id = 0;
        
        SET @s_dls_plan_id = 0;
       
        SET @s_dls_fc_id = 0;

        SET @s_dls_pd_id = 0;
        
        SET @s_dls_act_code = '';
      
        SET @s_new_ssn = '';
     
    SET @s_src_id = '';
      
        SET @s_subnew_ssn = '';
      
        SET @s_subsrc_id = '';
     
        SET @s_ext_id_col = '';
        
        SET @from_api = 0;
       
        SET @s_sub_in_plan = NULL;
     
        SET @s_eligibility_id = '';
 
        SET @s_dls_pend_action = 0;
   
        IF EXISTS ( SELECT  *
                    FROM    tempdb.dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'tempdb..#hold_sgmb_action')
                            AND xtype = 'U' )
            DROP TABLE #hold_sgmb_action;
CREATE TABLE #hold_sgmb_action
      (
             action_code_id INT IDENTITY ,
              batch_id INT ,
              dls_sir_id INT ,
              action_code CHAR(2) ,
              action_date DATE ,
              process_status CHAR(1)
            ); 
/* 20120228$$ks - added new field optional_5 using namesuffix field* /

-- 20120528$$ks - added paperless field using nameprefix field

/ * 20120228$$ks - changed bank_account from 17 to 25 chars */
	--Subscriber in plan.  This global is used by dlp_up_sg_mbship().

        
           BEGIN
                DECLARE @currentDateAndTime DATETIME;
                DECLARE @userSessionId INT;
--	trace "dlp_up_sg_member():  Entered.";
                SET @currentDateAndTime = GETDATE();
                SET @userSessionId = @@spid;
--	trace "a_batch_id = " || a_batch_id;
--	trace "a_start_time = " || a_start_time;
           END;
            
            
            SET @n_in_transaction = 'N';

            SELECT  @sg_config_id = config_id
            FROM    dbo.dl_config_bat (NOLOCK)
            WHERE   config_bat_id = @a_batch_id;
            
            
            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @a_batch_id, 'up_sg_member'

            SET @sg_up_sp_id = @SWV_dl_get_sp_id;
           
            IF @sg_up_sp_id IS NULL
                OR @sg_up_sp_id <= 0
                BEGIN
				RAISERROR('Invalid SP name',16,1);
				RETURN
			END
			

            EXECUTE @SWV_dl_get_sp_id=dbo.dl_get_sp_id @a_batch_id, 'bu_sg_member'
            SET @sg_bu_sp_id = @SWV_dl_get_sp_id;
    
            IF @sg_bu_sp_id IS NULL
                OR @sg_bu_sp_id <= 0
                BEGIN
				RAISERROR('Invalid Preprocess Procedure Name',16,1);
				RETURN
			END

            SET @sg_sir_def_id = dbo.dl_get_sir_def_id('sg_member');
          
            IF @sg_sir_def_id IS NULL
                OR @sg_sir_def_id <= 0
                BEGIN
				RAISERROR('Invalid DSIR table name',16,1);
				RETURN
			END

            
            EXECUTE dbo.dl_it_statistics @a_batch_id, @sg_up_sp_id,
                @a_start_time, @n_error_no OUTPUT, @i_cfg_bat_det_id OUTPUT,
                @i_statistics_id OUTPUT, @n_error_text OUTPUT;
            IF @n_error_no <= 0
                BEGIN
                    SET @n_error_text = CAST(-746 AS VARCHAR) + ':'+ @n_error_text;
                    RAISERROR(@n_error_text,16,1);
                END;


/* 20121017$$ks - When information comes from SG API all lookups have been performed
 * some validation is no longer necessary and it sometimes causes errors
 * added "from_api" logic to avoid unnecessary logic
 */
            SET @from_api = 0;
            
            SELECT  @from_api = 1
            FROM    dbo.dl_config (NOLOCK)
            WHERE   config_id = @sg_config_id
                    AND config_name LIKE '%API%';
            
            IF @from_api IS NULL
                BEGIN
                    SET @from_api = 0;
                    
                END;

				 UPDATE GlobalVar SET VarValue = @from_api  where VarName = 'from_api' and  BatchId = @a_batch_id AND Module_Id = 2

            SET @li_1000_count = 0;
            SET @li_tt_prcs_cnt = 0;
            SET @li_prcs_gd_cnt = 0;
            SET @li_prcs_bad_cnt = 0;

            BEGIN
                BEGIN TRY
   DELETE  FROM #hold_sgmb_action;
                END TRY
                BEGIN CATCH
                    SET @n_error_no = ERROR_NUMBER();
                    SET @n_isam_error = ERROR_LINE();
                    SET @n_error_text = ERROR_MESSAGE();
				
                    DROP TABLE #hold_sgmb_action;
                    DELETE  FROM #hold_sgmb_action;
                END CATCH;
           END;
			
            
			DECLARE @SWV_cursor_var1 TABLE
			(
              id INT IDENTITY ,
              dls_sub_sir_id INT
            );
			INSERT  INTO @SWV_cursor_var1
( dls_sub_sir_id
    )
				SELECT dls_sub_sir_id
				FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND dls_status = 'P' AND member_flag = '00';

	   DECLARE @cur1_cnt INT ,

	   @cur_i INT;
    SET @cur_i = 1;
    SELECT  @cur1_cnt = COUNT(1)
    FROM    @SWV_cursor_var1;
    WHILE ( @cur_i <= @cur1_cnt )
                BEGIN
                    SELECT  @t_sub_sir_id = dls_sub_sir_id
                    FROM    @SWV_cursor_var1
                    WHERE   id = @cur_i;
					
			/*
			SET @SWV_cursor_var1 = CURSOR  FOR SELECT dls_sub_sir_id 
      FROM dbo.dls_sg_member (NOLOCK)
      WHERE dls_batch_id = @a_batch_id
      AND dls_status = 'P' AND member_flag = '00';
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @t_sub_sir_id;
            WHILE @@FETCH_STATUS = 0
			*/
               
               --     BEGIN
                        --DECLARE #SWV_cursor_var2 CURSOR;
                        --DECLARE #SWV_cursor_var3 CURSOR;
                        --DECLARE #SWV_cursor_var4 CURSOR;
                        --DECLARE #SWV_cursor_var5 CURSOR;
       BEGIN TRY
                            /*SET #SWV_cursor_var2 = CURSOR  FOR SELECT dls_sir_id 
               FROM dbo.dls_sg_member (NOLOCK)
               WHERE dls_batch_id = @a_batch_id
               AND dls_sub_sir_id = @t_sub_sir_id;
                            OPEN #SWV_cursor_var2;
                            FETCH NEXT FROM #SWV_cursor_var2 INTO @t_clean_sir;
                            WHILE @@FETCH_STATUS = 0
							*/
							IF OBJECT_ID('tempdb..#SWV_cursor_var2') IS NOT NULL
						DROP TABLE #SWV_cursor_var2

							CREATE TABLE #SWV_cursor_var2
							(
              id INT IDENTITY ,
              dls_sir_id INT
            );
			        INSERT  INTO #SWV_cursor_var2
                ( dls_sir_id
                )
							SELECT dls_sir_id 
               FROM dbo.dls_sg_member (NOLOCK)
               WHERE dls_batch_id = @a_batch_id
               AND dls_sub_sir_id = @t_sub_sir_id;

			   DECLARE @cur2_cnt INT,
     @cur2_i INT;
    SET @cur2_i = 1;
    SELECT  @cur2_cnt = COUNT(1)
    FROM    #SWV_cursor_var2;
    WHILE ( @cur2_i <= @cur2_cnt )
                   BEGIN

                    SELECT  @t_clean_sir = dls_sir_id
                    FROM    #SWV_cursor_var2
                    WHERE   id = @cur2_i;

                                    EXECUTE dbo.dl_clean_curr_err @a_batch_id,
										@t_clean_sir, @sg_up_sp_id,
                                        @n_error_no OUTPUT,
                                        @n_error_text OUTPUT;
                                    --FETCH NEXT FROM #SWV_cursor_var2 INTO @t_clean_sir;
									SET @cur2_i = @cur2_i + 1;
                                END;
                            --CLOSE #SWV_cursor_var2;
                            SET @s_next_family = 'N';
                         
                            IF @t_sub_sir_id IS NULL
									BEGIN
                                    RAISERROR('No record found (sub_sir_id) for batch',16,1);
									SET @SWP_Ret_Value = @n_error_no;
                                    SET @SWP_Ret_Value1 = @n_error_text;
                                    RETURN;
                               END
	
                            DELETE  FROM #hold_sgmb_action
                            WHERE   1 = 1;
                            SET IDENTITY_INSERT #hold_sgmb_action ON;
                            INSERT  INTO #hold_sgmb_action(action_code_id,batch_id,dls_sir_id,action_code,action_date,process_status)
                                    SELECT  action_code_id,batch_id,dls_sir_id,action_code,action_date,process_status
                                    FROM    dbo.dl_action (NOLOCK)
                                    WHERE   batch_id = @a_batch_id
                                            AND process_status = 'N'
AND dls_sir_id IN (
            SELECT dls_sir_id
FROM    dbo.dls_sg_member (NOLOCK)
                                      WHERE   dls_batch_id = @a_batch_id
                                                    AND dls_sub_sir_id = @t_sub_sir_id );
                            SET IDENTITY_INSERT #hold_sgmb_action OFF;

/* 20131027$$ks - I think we are using more msi numbers than needed with this logic
 * 	also note that the action codes Cx relate to producers not to Cobra as it does in EG
 *		however producer logic does not seem to have been implemented
 */
							-- SELECT *FROM #hold_sgmb_action
                            SELECT  @msi_num = COUNT(*)
                            FROM    #hold_sgmb_action
                            WHERE   process_status != 'Y'
                                    AND action_code NOT IN ( 'CA', 'CT', 'CX',
                                                             'G[1-7]', 'NC' );
                            
                            SELECT  @msi_num1 = COUNT(*)
							FROM    #hold_sgmb_action
                            WHERE   process_status != 'Y'
                                    AND action_code IN ( 'FX', 'PC', 'RC' );
                            
                            IF @msi_num1 IS NULL
                                BEGIN
                                    SET @msi_num1 = 0;
                                    
                                END;
	
                            SELECT  @li_family_nbr = COUNT(DISTINCT dls_sir_id)
                            FROM    #hold_sgmb_action;
                         
                            SET @tot_msi = @msi_num + @msi_num1;
                            UPDATE  dbo.sysdatetime
                            SET     msi = msi + @tot_msi;
                           --select @tot_msi -- 3
							SELECT  @msi_upper = msi ,
                                    @n_datetime = datetime_id
                            FROM    dbo.sysdatetime;
                           -- select @msi_upper -- 21298339
                            SET @n_msi = @msi_upper - @tot_msi;

								
                            UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2
							UPDATE GlobalVar SET VarValue = @msi_upper  where VarName = 'msi_upper' and  BatchId = @a_batch_id AND Module_Id = 2
							
							/*
							SET #SWV_cursor_var3 = CURSOR  FOR SELECT DISTINCT action_date 
               FROM #hold_sgmb_action ORDER BY action_date;
                            OPEN #SWV_cursor_var3;
                            FETCH NEXT FROM #SWV_cursor_var3 INTO @t_action_date;
                            WHILE @@FETCH_STATUS = 0
							*/
							IF OBJECT_ID('tempdb..#SWV_cursor_var3') IS NOT NULL
							DROP TABLE #SWV_cursor_var3

							CREATE TABLE #SWV_cursor_var3 
							(
							id INT IDENTITY ,
							action_date DATE
							);
							INSERT  INTO #SWV_cursor_var3
							( action_date
							)
							SELECT DISTINCT action_date 
							FROM #hold_sgmb_action ORDER BY action_date;

							DECLARE @cur3_cnt INT ,
						 @cur3_i INT;
						SET @cur3_i = 1;
						SELECT  @cur3_cnt = COUNT(1)
						FROM    #SWV_cursor_var3;
						WHILE ( @cur3_i <= @cur3_cnt )
									BEGIN
										SELECT  @t_action_date = action_date
										FROM    #SWV_cursor_var3
										WHERE   id = @cur3_i;
										UPDATE GlobalVar SET VarValue = @t_action_date where VarName = 't_action_date' and  BatchId = @a_batch_id AND Module_Id = 2


                       IF ( @t_action_date) IS NULL
                                        BEGIN
										RAISERROR('No action found for subscriber',16,1);
										RETURN
										END
	   
                                    
                                    SET @n_in_transaction = 'Y';
                                    
									/*
									SET #SWV_cursor_var4 = CURSOR  FOR SELECT dls_sir_id, action_code 
                  FROM #hold_sgmb_action
                 WHERE action_date = CONVERT(DATE,CONVERT(VARCHAR,@t_action_date))
                  ORDER BY dls_sir_id;
                                    OPEN #SWV_cursor_var4;
   FETCH NEXT FROM #SWV_cursor_var4 INTO @t_sir_id,
                                        @t_temp_action_code;
  WHILE @@FETCH_STATUS = 0
									*/
									IF OBJECT_ID('tempdb..#SWV_cursor_var4') IS NOT NULL
										DROP TABLE #SWV_cursor_var4

									CREATE TABLE #SWV_cursor_var4
									(
								  id INT IDENTITY ,
								  dls_sir_id INT, action_code CHAR(2)
									);
									INSERT  INTO #SWV_cursor_var4
									( dls_sir_id, action_code
									)

									SELECT dls_sir_id, action_code 
									FROM #hold_sgmb_action
									WHERE action_date = @t_action_date
									ORDER BY dls_sir_id;

									DECLARE @cur4_cnt INT ,
									     @cur4_i INT;
									SET @cur4_i = 1;
									
									SELECT  @cur4_cnt = COUNT(1)
									FROM    #SWV_cursor_var4;
									WHILE ( @cur4_i <= @cur4_cnt )
												BEGIN
													SELECT  @t_sir_id = dls_sir_id, @t_temp_action_code = action_code
													FROM    #SWV_cursor_var4
													WHERE   id = @cur4_i;

													UPDATE GlobalVar SET VarValue = @t_sir_id  where VarName = 't_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
													--UPDATE GlobalVar SET VarValue = @s_dls_sir_id  where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
                                   
                                            IF @t_temp_action_code != 'NC'
                                                BEGIN
                       -- CH001 : Conversion issues to varbinary
                                                    SELECT  @s_dls_sir_id = dls_sir_id,
                                                            @s_dls_batch_id = dls_batch_id,
                                                            @s_dls_sub_sir_id = dls_sub_sir_id,
                                                            @s_member_flag = member_flag,
                                                            @s_alt_id = alt_id,
                                                            @s_ssn = ssn,
                                                            @s_sub_ssn = sub_ssn,
                                                            @s_sub_alt_id = sub_alt_id,
                                                            @s_member_code = member_code,
                                                            @s_paperless = RTRIM(LTRIM(nameprefix)),
                                                            @s_optional_5 = namesuffix,
                                                            @s_last_name = last_name,
															@s_first_name = first_name,
                                                            @s_middle_init = middle_init,
                                                            @s_date_of_birth = date_of_birth,
                                                            @s_student_flag = student_flag,
                                                            @s_disable_flag = disable_flag,
                                                            @s_cobra_flag = cobra_flag,
       @s_msg_group_id = msg_group_id,
															@s_plan_id = plan_id,
                                                            @s_facility_id = facility_id,
                                                            @s_rate_code = rate_code,
                                                            @s_mb_gppl_eff = mb_gppl_eff_date,
                                                            @s_mb_fc_eff_date = mb_fc_eff_date,
                                                            @s_mb_term_date = mb_term_date,
                                                            @s_bank_account = bank_account,
														   @s_account_type = account_type,
															@s_tr_nbr = transit_route_nbr,
																@s_process_code = process_code,
																 @s_trans_code = transaction_code,
                                                        @s_return_code = return_code,
                                                            @s_return_descr = return_descr,
															@s_address1 = address1,
																							 @s_address2 = address2,
																					   @s_city = city,
                                                            @s_state = state,
                                                            @s_zip = zip,
                                                            @s_zipx = zipx,
                                                            @s_home_phone = home_phone,
                                                            @s_home_ext = home_ext,
                                                            @s_work_phone = work_phone,
                                                            @s_work_ext = work_ext,
                                                            @s_email = email,
                                                            @s_producer_id = producer_id,
                                                            @s_comm_scheme_id = comm_scheme_id,
                                                            @s_pd_type = pd_type,
                                                            @s_license_number = license_number,
                                                            @s_selling_period = selling_period,
                                                            @s_pdcomm_eff = pdcomm_eff_date,
                                                            @s_dls_mb_id = dls_member_id,
                                                            @s_dls_sub_id = dls_subscriber_id,
                                                            @s_dls_msg_id = dls_msg_id,
                                                            @s_dls_group_id = dls_group_id,
                                                            @s_dls_plan_id = dls_plan_id,
                                                            @s_dls_fc_id = dls_facility_id,
                                                            @s_dls_pd_id = dls_producer_id,
                                                            @s_dls_act_code = dls_action_code,
                                                            @s_new_ssn = new_ssn,
                                                            @s_src_id = source_id,
                                                            @s_subnew_ssn = subnew_ssn,
                                                            @s_subsrc_id = subsource_id,
                                                            @s_ext_id_col = ext_id_col,
                                                            @s_sub_in_plan = sub_in_plan,
                                                            @s_dls_pend_action = dls_pend_action,
                                                            @s_eligibility_id = eligibility_id 
                                                    FROM    dbo.dls_sg_member
                                                    WHERE   dls_batch_id = @a_batch_id
													AND dls_sir_id = @t_sir_id;
													

												    UPDATE GlobalVar SET VarValue = @s_dls_sir_id  where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_batch_id  where VarName = 's_dls_batch_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_sub_sir_id where VarName = 's_dls_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_member_flag where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_alt_id where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_ssn where VarName = 's_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_sub_ssn where VarName = 's_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_sub_alt_id where VarName = 's_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_member_code where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_paperless where VarName = 's_paperless' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_optional_5 where VarName = 's_optional_5' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_last_name where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_first_name where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_middle_init where VarName = 's_middle_init' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_date_of_birth where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_student_flag where VarName = 's_student_flag' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_disable_flag where VarName = 's_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_cobra_flag where VarName = 's_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_msg_group_id where VarName = 's_msg_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_plan_id where VarName = 's_plan_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_facility_id where VarName = 's_facility_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_rate_code where VarName = 's_rate_code' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_mb_gppl_eff where VarName = 's_mb_gppl_eff' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_mb_fc_eff_date where VarName = 's_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_mb_term_date where VarName = 's_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_bank_account where VarName = 's_bank_account' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_account_type where VarName = 's_account_type' and  BatchId = @a_batch_id AND Module_Id = 2 
													UPDATE GlobalVar SET VarValue = @s_tr_nbr where VarName = 's_tr_nbr' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_process_code where VarName = 's_process_code' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_trans_code where VarName = 's_trans_code' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_return_code where VarName = 's_return_code' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_return_descr where VarName = 's_return_descr' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_address1 where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_address2 where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_city where VarName = 's_city' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_state where VarName = 's_state' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_zip where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_zipx where VarName = 's_zipx' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_home_phone where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_home_ext where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_work_phone where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_work_ext where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_email where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_producer_id where VarName = 's_producer_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_comm_scheme_id where VarName = 's_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_pd_type where VarName = 's_pd_type' and  BatchId = @a_batch_id AND Module_Id = 2 
													UPDATE GlobalVar SET VarValue = @s_license_number where VarName = 's_license_number' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_selling_period where VarName = 's_selling_period' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_pdcomm_eff where VarName = 's_pdcomm_eff' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_mb_id where VarName = 's_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_sub_id where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_msg_id where VarName = 's_dls_msg_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_group_id where VarName = 's_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_plan_id where VarName = 's_dls_plan_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_fc_id where VarName = 's_dls_fc_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_pd_id where VarName = 's_dls_pd_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_act_code where VarName = 's_dls_act_code' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_new_ssn where VarName = 's_new_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_src_id where VarName = 's_src_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_subnew_ssn where VarName = 's_subnew_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_subsrc_id where VarName = 's_subsrc_id' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_ext_id_col where VarName = 's_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_sub_in_plan where VarName = 's_sub_in_plan' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_dls_pend_action where VarName = 's_dls_pend_action' and  BatchId = @a_batch_id AND Module_Id = 2
													UPDATE GlobalVar SET VarValue = @s_eligibility_id where VarName = 's_eligibility_id' and  BatchId = @a_batch_id AND Module_Id = 2 
													
													                                                    
                                                    IF ( @s_sub_in_plan IS NOT NULL )
                                                        BEGIN
                                                            
                                                             
                                                            IF ( @s_sub_in_plan < 0
                                                              OR @s_sub_in_plan > 1
                                                              )
                                                              BEGIN
                                                              SET @s_sub_in_plan = 1;
                                                             
                                                              END;	--The default is one.
         END;
                          ELSE
                       BEGIN
                SET @s_sub_in_plan = 1;
                                                            
                                                        END;
				
                                                    SET @s_dls_act_code = @t_temp_action_code;
													UPDATE GlobalVar SET VarValue = @s_dls_act_code where VarName = 's_dls_act_code' and  BatchId = @a_batch_id AND Module_Id = 2

                                                    IF @s_dls_act_code = 'RC'
            BEGIN
                                                            SET @li_dep_sir_id = NULL;
                                                            /*
															SET #SWV_cursor_var5 = CURSOR  FOR SELECT dls_sir_id  FROM #hold_sgmb_action
                           WHERE dls_sir_id <> @s_dls_sir_id AND action_date = CONVERT(DATE,CONVERT(VARCHAR,@t_action_date));
                      OPEN #SWV_cursor_var5;
                                                            FETCH NEXT FROM #SWV_cursor_var5 INTO @li_dep_sir_id;
                                                            WHILE @@FETCH_STATUS = 0
															*/

															IF OBJECT_ID('tempdb..#SWV_cursor_var5') IS NOT NULL
														DROP TABLE #SWV_cursor_var5

															CREATE TABLE #SWV_cursor_var5
															            (
															  id INT IDENTITY ,
															  dls_sir_id INT
															);
															        INSERT  INTO #SWV_cursor_var5
															( dls_sir_id
															)
															SELECT dls_sir_id  FROM #hold_sgmb_action
															WHERE dls_sir_id <> @s_dls_sir_id AND action_date = @t_action_date;
															DECLARE @cur5_cnt INT ,
															 @cur5_i INT;
															SET @cur5_i = 1;
															
															SELECT  @cur5_cnt = COUNT(1)
															FROM    #SWV_cursor_var5;
															WHILE ( @cur5_i <= @cur5_cnt )
																	BEGIN	
																			SELECT  @li_dep_sir_id = dls_sir_id
																			FROM    #SWV_cursor_var5
																			WHERE   id = @cur5_i;

      
                                                              GOTO SWL_Label8;
                                        --FETCH NEXT FROM #SWV_cursor_var5 INTO @li_dep_sir_id;
															  SET @cur5_i = @cur5_i + 1;
                                                              END;
                                                            SWL_Label8:
                                                            --CLOSE #SWV_cursor_var5;
                                                            IF @li_dep_sir_id IS NULL
                                                              BEGIN
															  RAISERROR('Null dependant sir_id, action RC ',16,1);
															  RETURN
															END
					
                                                            SET @ls_rate_code = NULL;
                                                            SELECT
                                                              @ls_rate_code = rate_code
                                                            FROM
                                                              dbo.dls_sg_member (NOLOCK)
                                                            WHERE
                                                              dls_batch_id = @a_batch_id
                                                              AND dls_sir_id = @li_dep_sir_id;
                                                            
                                                            SET @s_rate_code = @ls_rate_code;
                                                            
                                                        END;
								                                                 
                                                    IF @s_dls_act_code = 'CA'
                                                       BEGIN
   
														SET @d_pdcomm_eff = CAST(@s_pdcomm_eff AS DATE);
                                                            EXECUTE @n_fatal = dlp_up_sg_pdcomm @a_batch_id,
                                                              @d_pdcomm_eff;
                           END;
                                                    ELSE
 EXECUTE @n_fatal = dlp_up_sg_mbship @a_batch_id;
				
												IF @n_fatal < 0
                                                        BEGIN
                                                            
                                                            SET @n_in_transaction = 'N';
															IF @n_fatal IN (-244, -245, -246 )
																SET @n_fatal = -1000;
                    ELSE
       IF @n_fatal IN (-1, -200 )
                                                              SET @n_fatal = -100;
						
                                                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                                              @sg_up_sp_id,
                                                              @sg_sir_def_id,
                                                              @s_dls_sir_id,
                                                              @n_fatal;
                                                            IF @n_fatal < 0
                                                              SET @s_next_family = 'Y';
                                                        END;
                                               END;
			
                                            SET @li_1000_count = @li_1000_count+ 1;
                                            IF @li_1000_count % 100 = 0
                                                BEGIN
                                                    SET @li_prcs_bad_cnt = @li_tt_prcs_cnt
                                                        - @li_prcs_gd_cnt;
                                                    UPDATE  dbo.dl_bat_statistics
        SET     tot_record = @li_tt_prcs_cnt ,
                                                            tot_success_rec = @li_prcs_gd_cnt ,
                                                   tot_fail_rec = @li_prcs_bad_cnt
                                                    WHERE   bat_statistics_id = @i_statistics_id;
                                                END;
			
                                            IF @s_next_family = 'Y'
				-- LET n_in_transaction = "N";
				-- ROLLBACK WORK;
                                                GOTO SWL_Label7;
			
                                            UPDATE  dbo.dl_action
                                            SET     process_status = 'Y'
                                            WHERE   batch_id = @a_batch_id
                                                    AND dls_sir_id = @s_dls_sir_id
                                                    AND action_date = @t_action_date;
                                            --FETCH NEXT FROM #SWV_cursor_var4 INTO @t_sir_id,                                                @t_temp_action_code;
											SET @cur4_i = @cur4_i + 1;
                                        END;
           SWL_Label7:
         --CLOSE #SWV_cursor_var4; -- action code cursor
		 
							IF @s_next_family = 'Y'
                                        GOTO SWL_Label6; -- action code for action date cursor 
		
                                    UPDATE  dbo.dl_action
									SET     process_status = 'Y'
                                    WHERE   batch_id = @a_batch_id
                                            AND action_date =  @t_action_date
                                            AND dls_sir_id IN (
                                            SELECT  dls_sir_id
									FROM    #hold_sgmb_action );
                                    
             SET @n_in_transaction = 'N';
                                    --FETCH NEXT FROM #SWV_cursor_var3 INTO @t_action_date;
									SET @cur3_i = @cur3_i + 1;
                                END;
                            SWL_Label6:
                            --CLOSE #SWV_cursor_var3; -- action date cursor


               SET @li_tt_prcs_cnt = @li_tt_prcs_cnt  + @li_family_nbr;
						  IF @s_next_family = 'Y'
                                GOTO SWL_Label5;
	
                            SET @li_prcs_gd_cnt = @li_prcs_gd_cnt + @li_family_nbr;
           
						SET @n_in_transaction = 'Y';

						
                            
						UPDATE  dbo.dls_sg_member
       SET     dls_status = 'U'
							WHERE   dls_batch_id = @a_batch_id
                                    AND dls_sub_sir_id = @t_sub_sir_id;
                            
                            SET @n_in_transaction = 'N';

                        END TRY
                        BEGIN CATCH
                            SET @n_error_no = ERROR_NUMBER();
                            SET @n_isam_error = ERROR_LINE();
                            SET @n_error_text = ERROR_MESSAGE();
							
                            IF @n_in_transaction = 'Y'
                               
                            EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @sg_up_sp_id, @sg_sir_def_id, @t_sub_sir_id,
                                1000;
								--RETURN
                        END CATCH;
                --   END;
                    SWL_Label5:
                    --FETCH NEXT FROM @SWV_cursor_var1 INTO @t_sub_sir_id;
					SET @cur_i = @cur_i + 1;
                END;
            --CLOSE @SWV_cursor_var1; -- Subscriber Cursor


            SET @SWV_func_DL_UPD_STATISTICS_par0 = @li_tt_prcs_cnt
                - @li_prcs_gd_cnt;
           EXECUTE @SWV_dl_upd_statistics= dbo.dl_upd_statistics @i_statistics_id, @li_tt_prcs_cnt,
                @li_prcs_gd_cnt, @SWV_func_DL_UPD_STATISTICS_par0
                --@SWV_dl_upd_statistics OUTPUT;
            IF @SWV_dl_upd_statistics <> 1
                BEGIN
                    SET @SWP_Ret_Value = -1;
        SET @SWP_Ret_Value1 = CONCAT(@li_tt_prcs_cnt,
                                                 ' Failed to update statistics');
					IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 2 AND BatchId = @a_batch_id )
					BEGIN
						DELETE FROM GlobalVar WHERE Module_Id = 2 AND BatchId = @a_batch_id
					END
                    RETURN;
                END;

            UPDATE  dbo.dl_cfg_bat_det
            SET     cfg_bat_det_stat = 'S'
            WHERE   cfg_bat_det_id = @i_cfg_bat_det_id;
            SET @n_in_transaction = 'N';
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'S'
            WHERE   config_bat_id = @a_batch_id;
            SET @SWP_Ret_Value = 1;
            SET @SWP_Ret_Value1 = CONCAT('Final Process for Batch ',
                                         @a_batch_id, ' is completed');

				IF EXISTS (SELECT 'X' FROM GlobalVar (NOLOCK) WHERE Module_Id = 2 AND BatchId = @a_batch_id )
				BEGIN
					DELETE FROM GlobalVar WHERE Module_Id = 2 AND BatchId = @a_batch_id
				END
            RETURN;
        
       
SET NOCOUNT OFF;

--trace off;



--set debug file to "/tmp/dlp_up_sg_member_dev.trc";
--trace on;
--set explain on;

    END;