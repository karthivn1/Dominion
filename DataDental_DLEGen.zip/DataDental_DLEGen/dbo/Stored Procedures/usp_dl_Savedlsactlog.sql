﻿--dls_actlog
CREATE PROCEDURE [dbo].[usp_dl_Savedlsactlog] (@dlsActLog dbo.DlsActlog READONLY)                                                
AS 
BEGIN 
	SET NOCOUNT ON 
	BEGIN TRAN 
		BEGIN TRY 
			BEGIN
				UPDATE dls_actlog 
				 SET dls_batch_id = dal.dls_batch_id
					  ,dls_actlog.dls_status = CASE WHEN dal.dls_status='E' OR dal.dls_status='P' THEN 'V'
							ELSE dls_actlog.dls_status END
					  --,dls_source = dal.dls_source
					  ,subsys_code = dal.subsys_code
					  ,sysrec_id = dal.sysrec_id
					  ,reason_code = dal.reason_code
					  --,dls_act_mast_id = dal.dls_act_mast_id
					  ,act_date = dal.act_date
					  ,act_time = dal.act_time
				from @dlsActLog dal
				WHERE dls_actlog.dls_sir_id = dal.dls_sir_id
			END
	COMMIT TRAN 
	END TRY
	BEGIN CATCH
			ROLLBACK TRAN
			DECLARE
			@erMessage NVARCHAR(2048),
			@erSeverity INT,
			@erState INT
 
			SELECT
			@erMessage = ERROR_MESSAGE(),
			@erSeverity = ERROR_SEVERITY(),
			@erState = ERROR_STATE()
 
			RAISERROR (@erMessage,
			@erSeverity,
			@erState )
			
	END CATCH
END