﻿CREATE PROCEDURE [dbo].[dlp_up_add_sg]
    @a_batch_id INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    



/*
	Created Date	: 05/14/2001 
	Created By	: Jacky Chang 
	Reason		: Single Group Update -  GROUP MODULE.
* /


/ *error variable*/
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:43:43 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1





000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_fatal INT;

        DECLARE @t_temp_action_code CHAR(2);
        DECLARE @tot_msi INT;
        DECLARE @s_group_source CHAR(2);
        DECLARE @i_group_sic INT;
        DECLARE @i_renewal_intervl INT;
        DECLARE @i_sub_enrol INT;
        DECLARE @i_enrol_dep INT;
        DECLARE @s_prev_carrier CHAR(35);
        DECLARE @s_curr_carrier CHAR(35);
        DECLARE @i_elig_empl INT;
        DECLARE @i_elig_depd INT;
        DECLARE @s_self_funded CHAR(1);
        DECLARE @dc_empl_perc DECIMAL(5, 2);
        DECLARE @dc_depd_perc DECIMAL(5, 2);
        DECLARE @s_mail_id_card CHAR(2);
        DECLARE @i_group_area INT;
        DECLARE @i_enrol_territory INT;
        DECLARE @i_close_territory INT;
        DECLARE @i_oc_id INT;
        DECLARE @s_adv_cap CHAR(1);
        DECLARE @s_guar_elig CHAR(1);
        DECLARE @s_guar_cap CHAR(1);
        DECLARE @i_bill_first INT;
        DECLARE @i_bill_last INT;
        DECLARE @s_alloc_type CHAR(2);
        DECLARE @dc_pymt_toler DECIMAL(5, 2);
        DECLARE @s_late_notice CHAR(2);
        DECLARE @i_bill_copies INT;
        DECLARE @i_bill_freq INT;
        DECLARE @s_bill_type CHAR(2);
        DECLARE @s_skip_bill_m1 CHAR(2);
        DECLARE @s_skip_bill_m2 CHAR(2);
        DECLARE @s_supres_bill CHAR(1);
        DECLARE @s_supres_print CHAR(1);
        DECLARE @i_vision_cnt INT;
        DECLARE @i_dental_cnt INT;
        DECLARE @s_grp_client_class CHAR(2);
        DECLARE @i_retro_limit SMALLINT;
        DECLARE @i_cap_retro_limit SMALLINT;
        DECLARE @i_bill_cycle SMALLINT;
        DECLARE @s_pays_own_claims CHAR(1);

        DECLARE @i_ext_grp_id INT;
        DECLARE @d_elig_opt INT;
        DECLARE @d_elig_opt_bill INT;
        DECLARE @d_elig_opt_cap INT;
        DECLARE @d_sub_gr_pl_eff DATE;
        DECLARE @d_group_oed DATE;
        DECLARE @s_group_name CHAR(50);
        DECLARE @s_group_type CHAR(2);
        DECLARE @d_group_alt_id CHAR(20);
        DECLARE @i_group_parent INT;
        DECLARE @i_group_size INT;
        DECLARE @d_next_renew_date DATE;
        DECLARE @d_next_enrol_date DATE;
        DECLARE @i_add_month INT;
        DECLARE @d_paid_to_date DATE;
        DECLARE @i_gfee_amt_id INT;
        DECLARE @i_std_goccur_amt INT;
        DECLARE @i_grp_goccur_amt INT;
        DECLARE @dc_std_gfee_amt MONEY;
        DECLARE @dc_grp_gfee_amt MONEY;
        DECLARE @i_grp_gcount INT;
        DECLARE @dc_grp_gpaid MONEY;
        DECLARE @i_options_id INT;
        DECLARE @i_options_seq INT;
        DECLARE @s_options_reqd CHAR(1);
        DECLARE @i_add_bill INT;
        DECLARE @i_add_cap INT;
        DECLARE @i_term_bill INT;
        DECLARE @i_term_cap INT;
        DECLARE @dt_eff_date DATE;
        DECLARE @dt_exp_date DATE;
        DECLARE @i_rel_gppl_id INT;
        DECLARE @s_gp_rate_code CHAR(2);
        DECLARE @i_method INT;
        DECLARE @i_age_lb INT;
        DECLARE @i_age_ub INT;
        DECLARE @dc_prm_amt MONEY;
        DECLARE @s_cap_dol_pct CHAR(1);
		DECLARE @dc_cap_dol MONEY;
        DECLARE @dc_cap_pct DECIMAL(6, 2);

        DECLARE @ls_user CHAR(20);
        DECLARE @ls_datetime DATE;
        DECLARE @d_mb_gr_pl_id INT;
        DECLARE @d_eff_gr_pl DATE;
        DECLARE @d_exp_gr_pl DATE;
        DECLARE @n_ffs_plan INT;
        DECLARE @s_ins_opt CHAR(3);
        DECLARE @n_new_eff_date DATE;
        DECLARE @i_new_sg_id INT;
        DECLARE @s_sg_err CHAR(64);
        DECLARE @grp_count INT;
		
		DECLARE @t_sir_id				INT;
		DECLARE @sg_bu_sp_id			INT;
		DECLARE @sg_up_sp_id			INT;
		DECLARE @sg_sir_def_id		INT;
		DECLARE @t_sub_sir_id			INT;
		DECLARE @t_action_date		DATE;
		DECLARE @n_msi					INT;
		DECLARE @msi_num				INT;
		DECLARE @msi_num1				INT;
		DECLARE @msi_upper				INT;
		DECLARE @n_datetime			DATETIME;
		DECLARE @s_dls_sir_id			INT;
		DECLARE @s_dls_batch_id		INT;
		DECLARE @s_dls_sub_sir_id	INT;
		DECLARE @s_member_flag		char(2);
		DECLARE @s_alt_id				char(20);
		DECLARE @s_ssn					char(11);
		DECLARE @s_sub_ssn				char(11);
		DECLARE @s_sub_alt_id			char(20);
		DECLARE @s_member_code		char(3);
		DECLARE @s_last_name			char(15);
		DECLARE @s_first_name			char(15);
		DECLARE @s_middle_init		char(1);
		DECLARE @s_date_of_birth		char(10);
		DECLARE @s_student_flag		char(1);
		DECLARE @s_disable_flag		char(1);
		DECLARE @s_cobra_flag			char(1);
		DECLARE @s_msg_group_id		INT;
		DECLARE @s_plan_id				INT;
		DECLARE @s_facility_id		INT;
		DECLARE @s_rate_code			char(2);
		DECLARE @s_mb_gppl_eff		char(10);
		DECLARE @s_mb_fc_eff_date	char(10);
		DECLARE @s_mb_term_date		char(10);
		DECLARE @s_bank_account		char(25);
		DECLARE @s_account_type		char(2);
		DECLARE @s_tr_nbr				char(9);
		DECLARE @s_trans_code			char(2);
		DECLARE @s_address1			char(30);
		DECLARE @s_address2			char(30);
		DECLARE @s_city					char(30);
		DECLARE @s_state				char(2);
		DECLARE @s_zip 					char(5);
		DECLARE @s_zipx 				char(4);
		DECLARE @s_home_phone			char(10);
		DECLARE @s_home_ext 			char(5);
		DECLARE @s_work_phone			char(10);
		DECLARE @s_work_ext			char(5);
		DECLARE @s_producer_id		INT;
		DECLARE @s_comm_scheme_id 	char(5);
		DECLARE @s_pd_type				char(2);
		DECLARE @s_license_number	char(9);
		DECLARE @s_selling_period	char(1);
		DECLARE @s_pdcomm_eff			char(10);
		DECLARE @s_dls_mb_id			INT;
		DECLARE @s_dls_sub_id			INT;
		DECLARE @s_dls_msg_id			INT;
		DECLARE @s_dls_group_id		INT;
		DECLARE @s_dls_plan_id		INT;
		DECLARE @s_dls_fc_id			INT;
		DECLARE @s_dls_pd_id			INT;
		DECLARE @s_dls_act_code		char(2);

        DECLARE @SWV_cursor_var1 CURSOR;
        DECLARE @SWV_cursor_var2 CURSOR;
        DECLARE @SWV_cursor_var3 CURSOR;
        DECLARE @v_Null INT;

        SET NOCOUNT ON;
        SET @t_sir_id = 0;
      
        SET @sg_bu_sp_id = 0;
    
        SET @sg_up_sp_id = 0;
       
        SET @sg_sir_def_id = 0;
      
        SET @t_sub_sir_id = 0;
      
        SET @t_action_date = NULL;
        
        SET @n_msi = 0;
        
        SET @msi_num = 0;
        
        SET @msi_num1 = 0;
        
        SET @msi_upper = 0;
        
        SET @n_datetime = NULL;
       
        SET @s_dls_sir_id = 0;
        
        SET @s_dls_batch_id = 0;
        
        SET @s_dls_sub_sir_id = 0;
        
        SET @s_member_flag = '';
       
        SET @s_alt_id = '';
        
        SET @s_ssn = '';
        SET @s_sub_ssn = '';
        SET @s_sub_alt_id = '';
        SET @s_member_code = '';
        SET @s_last_name = '';
        SET @s_first_name = '';
        SET @s_middle_init = '';
        SET @s_date_of_birth = '';
        SET @s_student_flag = '';
        SET @s_disable_flag = '';
        SET @s_cobra_flag = '';
        SET @s_msg_group_id = 0;
        SET @s_plan_id = 0;
        SET @s_facility_id = 0;
        SET @s_rate_code = '';
        SET @s_mb_gppl_eff = '';
        SET @s_mb_fc_eff_date = '';
        SET @s_mb_term_date = '';
        SET @s_bank_account = '';
        SET @s_account_type = '';
        SET @s_tr_nbr = '';
        SET @s_trans_code = '';
        SET @s_address1 = '';
        SET @s_address2 = '';
        SET @s_city = '';
        SET @s_state = '';
        SET @s_zip = '';
        SET @s_zipx = '';
        SET @s_home_phone = '';
        SET @s_home_ext = '';
        SET @s_work_phone = '';
        SET @s_work_ext = '';
        SET @s_producer_id = 0;
        SET @s_comm_scheme_id = '';
        SET @s_pd_type = '';
        SET @s_license_number = '';
        SET @s_selling_period = '';
        SET @s_pdcomm_eff = '';
        SET @s_dls_mb_id = 0;
        SET @s_dls_sub_id = 0;
        SET @s_dls_msg_id = 0;
        SET @s_dls_group_id = 0;
        SET @s_dls_plan_id = 0;
        SET @s_dls_fc_id = 0;
        SET @s_dls_pd_id = 0;
        SET @s_dls_act_code = '';
        
		BEGIN TRY
			
	
		select @t_action_date		=VarValue from GlobalVar(NOLOCK) where VarName='t_action_date' and  BatchId = @a_batch_id AND Module_Id = 2
		select @n_msi				=VarValue from GlobalVar(NOLOCK) where VarName='n_msi' and  BatchId = @a_batch_id AND Module_Id = 2
	
		select @msi_upper			=VarValue from GlobalVar(NOLOCK) where VarName='msi_upper' and  BatchId = @a_batch_id AND Module_Id = 2
		
		select @s_dls_sir_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_batch_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_batch_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_sub_sir_id	=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_sub_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_member_flag		=VarValue from GlobalVar(NOLOCK) where VarName='s_member_flag' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_alt_id			=VarValue from GlobalVar(NOLOCK) where VarName='s_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_ssn				=VarValue from GlobalVar(NOLOCK) where VarName='s_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_sub_ssn			=VarValue from GlobalVar(NOLOCK) where VarName='s_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_sub_alt_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_member_code		=VarValue from GlobalVar(NOLOCK) where VarName='s_member_code' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_last_name			=VarValue from GlobalVar(NOLOCK) where VarName='s_last_name' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_first_name		=VarValue from GlobalVar(NOLOCK) where VarName='s_first_name' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_middle_init		=VarValue from GlobalVar(NOLOCK) where VarName='s_middle_init' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_date_of_birth		=VarValue from GlobalVar(NOLOCK) where VarName='s_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_student_flag		=VarValue from GlobalVar(NOLOCK) where VarName='s_student_flag' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_disable_flag		=VarValue from GlobalVar(NOLOCK) where VarName='s_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_cobra_flag		=VarValue from GlobalVar(NOLOCK) where VarName='s_cobra_flag' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_msg_group_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_msg_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_plan_id			=VarValue from GlobalVar(NOLOCK) where VarName='s_plan_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_facility_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_facility_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_rate_code			=VarValue from GlobalVar(NOLOCK) where VarName='s_rate_code' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_mb_gppl_eff		=VarValue from GlobalVar(NOLOCK) where VarName='s_mb_gppl_eff' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_mb_fc_eff_date	=VarValue from GlobalVar(NOLOCK) where VarName='s_mb_fc_eff_date' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_mb_term_date		=VarValue from GlobalVar(NOLOCK) where VarName='s_mb_term_date' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_bank_account		=VarValue from GlobalVar(NOLOCK) where VarName='s_bank_account' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_account_type		=VarValue from GlobalVar(NOLOCK) where VarName='s_account_type' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_tr_nbr			=VarValue from GlobalVar(NOLOCK) where VarName='s_tr_nbr' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_trans_code		=VarValue from GlobalVar(NOLOCK) where VarName='s_trans_code' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_address1			=VarValue from GlobalVar(NOLOCK) where VarName='s_address1' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_address2			=VarValue from GlobalVar(NOLOCK) where VarName='s_address2' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_city				=VarValue from GlobalVar(NOLOCK) where VarName='s_city' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_state				=VarValue from GlobalVar(NOLOCK) where VarName='s_state' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_zip 				=VarValue from GlobalVar(NOLOCK) where VarName='s_zip' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_zipx 				=VarValue from GlobalVar(NOLOCK) where VarName='s_zipx' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_home_phone		=VarValue from GlobalVar(NOLOCK) where VarName='s_home_phone' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_home_ext 			=VarValue from GlobalVar(NOLOCK) where VarName='s_home_ext' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_work_phone		=VarValue from GlobalVar(NOLOCK) where VarName='s_work_phone' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_work_ext			=VarValue from GlobalVar(NOLOCK) where VarName='s_work_ext' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_producer_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_producer_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_comm_scheme_id 	=VarValue from GlobalVar(NOLOCK) where VarName='s_comm_scheme_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_pd_type			=VarValue from GlobalVar(NOLOCK) where VarName='s_pd_type' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_license_number	=VarValue from GlobalVar(NOLOCK) where VarName='s_license_number' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_selling_period	=VarValue from GlobalVar(NOLOCK) where VarName='s_selling_period' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_pdcomm_eff		=VarValue from GlobalVar(NOLOCK) where VarName='s_pdcomm_eff' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_mb_id			=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_sub_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_msg_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_msg_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_group_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_group_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_plan_id		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_plan_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_fc_id			=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_fc_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_pd_id			=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_pd_id' and  BatchId = @a_batch_id AND Module_Id = 2
		select @s_dls_act_code		=VarValue from GlobalVar(NOLOCK) where VarName='s_dls_act_code' and  BatchId = @a_batch_id AND Module_Id = 2
            											
            SET @ls_user = CONCAT('dl', @a_batch_id);
            SET @ls_datetime = CONVERT(DATE, CONVERT(DATE, GETDATE()));
            SELECT  @s_group_source = group_source ,
                    @i_group_sic = group_sic ,
                    @i_renewal_intervl = renewal_intervl ,
                    @i_sub_enrol = sub_enrol ,
                    @i_enrol_dep = enrol_dep ,
                    @s_prev_carrier = prev_carrier ,
                    @s_curr_carrier = curr_carrier ,
                    @i_elig_empl = elig_empl ,
                    @i_elig_depd = elig_depd ,
                    @s_self_funded = self_funded ,
                    @dc_empl_perc = empl_perc ,
                    @dc_depd_perc = depd_perc ,
                    @s_mail_id_card = mail_id_card ,
                    @i_group_area = group_area ,
                    @i_enrol_territory = enrol_territory ,
                    @i_close_territory = close_territory ,
                    @i_oc_id = oc_id ,
                    @s_adv_cap = adv_cap ,
                    @s_guar_elig = guar_elig ,
                    @s_guar_cap = guar_cap ,
                    @i_bill_first = bill_first ,
                    @i_bill_last = bill_last ,
                    @s_alloc_type = alloc_type ,
                    @dc_pymt_toler = pymt_toler ,
                    @s_late_notice = late_notice ,
                    @i_bill_copies = bill_copies ,
                    @i_bill_freq = bill_freq ,
                    @s_bill_type = bill_type ,
                    @s_skip_bill_m1 = skip_bill_m1 ,
                    @s_skip_bill_m2 = skip_bill_m2 ,
                    @s_supres_bill = supres_bill ,
                    @s_supres_print = supres_print ,
                    @i_vision_cnt = vision_cnt ,
                    @i_dental_cnt = dental_cnt ,
                    @s_grp_client_class = group_client_class ,
                   @i_retro_limit = retro_limit ,
                    @i_cap_retro_limit = cap_retro_limit ,
                    @s_pays_own_claims = pays_own_claims ,
                    @i_bill_cycle = bill_cycle ,
                    @i_ext_grp_id = ext_grp_id
            FROM    dbo.[group] (NOLOCK)
            WHERE   group_id = @s_dls_msg_id;
            
           
            SET @d_sub_gr_pl_eff = CONVERT(DATE, CONVERT(VARCHAR, @t_action_date));
           
            SET @s_group_name = RTRIM(LTRIM(@s_last_name)) + ', '
                + RTRIM(LTRIM(@s_first_name));
            SET @s_group_type = 'SG';
            
            SET @d_group_alt_id = @s_alt_id;
            
            SET @i_group_parent = @s_dls_msg_id;
            SET @i_group_size = 1;
/* 20050912$$ks - Group related dates must be as of the 1st of each month */
            SET @d_group_oed = CONVERT(DATE, CONCAT(MONTH(@d_sub_gr_pl_eff),
                                                    '/01/',
                                                    YEAR(@d_sub_gr_pl_eff)));
            SET @d_next_renew_date = CONVERT(DATE, DATEADD(MONTH,
                                                           @i_renewal_intervl,
                                                           @d_group_oed));
            SET @d_next_enrol_date = CONVERT(DATE, DATEADD(MONTH,
                                                           @i_renewal_intervl,
                                                           @d_group_oed));
/*
LET d_next_renew_date = date(d_sub_gr_pl_eff + i_renewal_intervl units month);
LET d_next_enrol_date = date(d_sub_gr_pl_eff + i_renewal_intervl units month);
* /
/ * 20131006$$ks See if group already exists for this member within the same MSG
 */
            SELECT  @grp_count = COUNT(*)
            FROM    dbo.[group] (NOLOCK)
            WHERE   alt_id = @s_alt_id
                    AND group_name = @s_group_name
                    AND group_type = 'SG'
                    AND group_parent = @s_dls_msg_id;

	-- continue to the code below 
            IF @grp_count = 0
                BEGIN
                    SET @v_Null = 0;
                END;
            ELSE
                IF @grp_count = 1
                    BEGIN
                        SELECT  @i_new_sg_id = group_id
                        FROM    dbo.[group] (NOLOCK)
                        WHERE   alt_id = @s_alt_id
                                AND group_name = @s_group_name
                                AND group_type = 'SG'
                                AND group_parent = @s_dls_msg_id;
                        
	 /* 20131101$$ks -- Group Add should just create the new SG 
	  */
                        
                        IF @s_dls_act_code = 'GA'
                            BEGIN
                                SET @SWP_Ret_Value = @i_new_sg_id;
                                SET @SWP_Ret_Value1 = 'Single Group is added';
                                RETURN;
                            END;
	
                    
                        EXECUTE dbo.dlp_add_sg_plan @d_sub_gr_pl_eff,
                            @s_plan_id, @s_dls_msg_id, @i_new_sg_id, @ls_user,
                            @ls_datetime, @i_rel_gppl_id OUTPUT,
                            @s_sg_err OUTPUT;
                        IF ( @i_rel_gppl_id < 1 )
                            BEGIN
                                SET @SWP_Ret_Value = -1;
                                SET @SWP_Ret_Value1 = 'Error Adding SG Plan record';
                                RETURN;
                            END;
                        ELSE
                            BEGIN
                                SET @SWP_Ret_Value = @i_new_sg_id;
                                SET @SWP_Ret_Value1 = 'Single Group is added';
                                RETURN;
                            END;
                    END;
   ELSE
                  BEGIN
                        SET @SWP_Ret_Value = 0;
                        SET @SWP_Ret_Value1 = 'Multiple SG already exist for this subscriber';
                        RETURN;
                    END;
 
/* 20131005$$ks invalid code
 * if exists (select * from group where alt_id = s_alt_id) then 
 *	return 0, "Single Group Already existed"; 
 * end if
 */

            IF @i_bill_freq = 12
                SET @i_add_month = 1;
            ELSE
                IF @i_bill_freq = 1
                    SET @i_add_month = 12;
                ELSE
                    IF @i_bill_freq = 4
                        SET @i_add_month = 3;
                    ELSE
                        IF @i_bill_freq = 2
                            SET @i_add_month = 6;
			
		
	

/* 20050912$$ks paid to date/next bill date -> effective date! */
            SET @d_paid_to_date = @d_group_oed;
/*
LET d_paid_to_date = date(d_sub_gr_pl_eff + i_add_month units month); 
WHILE (d_paid_to_date < today) 
	LET d_paid_to_date = date(d_paid_to_date + i_add_month units month); 
END WHILE;
* /
/ *
WHILE (d_next_renew_date < today) 
	LET d_next_renew_date = date(d_next_renew_date + i_renewal_intervl units month); 
END WHILE;

WHILE (d_next_enrol_date < today) 
	LET d_next_enrol_date = date(d_next_enrol_date + i_renewal_intervl units month); 
END WHILE;
*/

            BEGIN
                SET @n_error_no = 78;
                INSERT  INTO dbo.[group]
                        ( group_source ,
                          group_sic ,
                          group_name ,
                          group_type ,
                          group_oed ,
                          group_size ,
                          group_area ,
                          group_parent ,
                          group_payee ,
                          bill_first ,
          bill_last ,
                          bill_copies ,
                          bill_type ,
                          bill_freq ,
                          alloc_type ,
                          pymt_toler ,
                          late_notice ,
                          retro_limit ,
                          empl_perc ,
                          depd_perc ,
                          elig_empl ,
                          elig_depd ,
                          next_renew_date ,
                          curr_carrier ,
                          adv_cap ,
                          guar_elig ,
                          guar_cap ,
                          paid_to_date ,
                          next_enrol_date ,
                          sub_enrol ,
                          h_datetime ,
                          h_user ,
                          mail_id_card ,
                          vision_cnt ,
                          dental_cnt ,
                          alt_id ,
                          oc_id ,
                          self_funded ,
                          prev_carrier ,
                          cap_retro_limit ,
                          renewal_intervl ,
                          enrol_dep ,
                          enrol_territory ,
                          close_territory ,
                          supres_bill ,
                          supres_print ,
                          skip_bill_m1 ,
                          skip_bill_m2 ,
                          group_client_class ,
                          h_action ,
                          next_bill_date ,
                          bill_cycle ,
                          pays_own_claims ,
                          ext_grp_id
                        )
                VALUES  ( @s_group_source ,
                          @i_group_sic ,
                          @s_group_name ,
                          @s_group_type ,
                          @d_group_oed ,
                          @i_group_size ,
     @i_group_area ,
       @s_dls_msg_id ,
                          NULL ,
                          @i_bill_first ,
                          @i_bill_last ,
                          @i_bill_copies ,
                          @s_bill_type ,
                          @i_bill_freq ,
                          @s_alloc_type ,
                          @dc_pymt_toler ,
                          @s_late_notice ,
                          @i_retro_limit ,
                          @dc_empl_perc ,
                          @dc_depd_perc ,
                          @i_elig_empl ,
                          @i_elig_depd ,
                          @d_next_renew_date ,
                          @s_curr_carrier ,
                          @s_adv_cap ,
                          @s_guar_elig ,
                          @s_guar_cap ,
                          @d_sub_gr_pl_eff ,
                          @d_next_enrol_date ,
                          @i_sub_enrol ,
                          @ls_datetime ,
                          @ls_user ,
                          @s_mail_id_card ,
                          @i_vision_cnt ,
                          @i_dental_cnt ,
                          @s_alt_id ,
                          @i_oc_id ,
                          @s_self_funded ,
                          @s_prev_carrier ,
                          @i_cap_retro_limit ,
                          @i_renewal_intervl ,
                          @i_enrol_dep ,
                          @i_enrol_territory ,
                          @i_close_territory ,
                          @s_supres_bill ,
                          @s_supres_print ,
                          @s_skip_bill_m1 ,
                          @s_skip_bill_m2 ,
                          @s_grp_client_class ,
                          'SA' ,
                   @d_paid_to_date ,
                          @i_bill_cycle ,
                          @s_pays_own_claims ,
                          @i_ext_grp_id
                        );
            END;
            SELECT  @i_new_sg_id = MAX(group_id)
            FROM    dbo.[group] (NOLOCK)
            WHERE   group_name = @s_group_name
                    AND group_parent = @s_dls_msg_id;
            
            UPDATE  dbo.[group]
            SET     group_payee = @i_new_sg_id
            WHERE   group_id = @i_new_sg_id
                    AND group_parent = @s_dls_msg_id;

	-- Start inserting into the accessory tables

            INSERT  INTO dbo.group_status
                    ( group_id ,
                      group_status ,
                      eff_date ,
                      exp_date ,
                      h_datetime ,
                      h_user
                    )
            VALUES  ( @i_new_sg_id ,
                      'A4' ,
                      @d_sub_gr_pl_eff ,
                      NULL ,
                      @ls_datetime ,
                      @ls_user
                    );
	
            INSERT  INTO dbo.group_aliases
                    ( group_id ,
                      group_name ,
                      h_datetime ,
                      h_user ,
                      actual_name
                    )
            VALUES  ( @i_new_sg_id ,
                      @s_group_name ,
                      @ls_datetime ,
                      @ls_user ,
                      'Y'
                    );
	
            SET @SWV_cursor_var1 = CURSOR  FOR SELECT gfee_amt_id, std_goccur_amt, grp_goccur_amt,
		std_gfee_amt, grp_gfee_amt, grp_gcount, grp_gpaid
	
      FROM dbo.group_gfee_amt (NOLOCK)
      WHERE group_id = @s_dls_msg_id;
            OPEN @SWV_cursor_var1;
            FETCH NEXT FROM @SWV_cursor_var1 INTO @i_gfee_amt_id,
                @i_std_goccur_amt, @i_grp_goccur_amt, @dc_std_gfee_amt,
                @dc_grp_gfee_amt, @i_grp_gcount, @dc_grp_gpaid;
            WHILE @@FETCH_STATUS = 0
                BEGIN
    INSERT  INTO dbo.group_gfee_amt
                            ( group_id ,
                              gfee_amt_id ,
                              std_goccur_amt ,
                              grp_goccur_amt ,
                              std_gfee_amt ,
                              grp_gfee_amt ,
                              eff_date ,
                              exp_date ,
                              grp_gcount ,
                              grp_gpaid ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @i_new_sg_id ,
                              @i_gfee_amt_id ,
                              @i_std_goccur_amt ,
                              @i_grp_goccur_amt ,
                              @dc_std_gfee_amt ,
                              @dc_grp_gfee_amt ,
                              @d_sub_gr_pl_eff ,
                              NULL ,
                              @i_grp_gcount ,
                              @dc_grp_gpaid ,
                              @ls_datetime ,
                              @ls_user
                            );
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @i_gfee_amt_id,
                        @i_std_goccur_amt, @i_grp_goccur_amt, @dc_std_gfee_amt,
                        @dc_grp_gfee_amt, @i_grp_gcount, @dc_grp_gpaid;
                END;
            CLOSE @SWV_cursor_var1;
            SET @SWV_cursor_var2 = CURSOR  FOR SELECT options_id, options_seq, options_reqd
	
      FROM dbo.group_format (NOLOCK)
      WHERE group_id = @s_dls_msg_id;
            OPEN @SWV_cursor_var2;
            FETCH NEXT FROM @SWV_cursor_var2 INTO @i_options_id,
                @i_options_seq, @s_options_reqd;
        WHILE @@FETCH_STATUS = 0
                BEGIN
                    INSERT  INTO dbo.group_format
                            ( group_id ,
                              options_id ,
                              options_seq ,
                              options_reqd
                            )
                    VALUES  ( @i_new_sg_id ,
                              @i_options_id ,
                              @i_options_seq ,
                              @s_options_reqd
                            );
                    FETCH NEXT FROM @SWV_cursor_var2 INTO @i_options_id,
                        @i_options_seq, @s_options_reqd;
                END;
            CLOSE @SWV_cursor_var2;
            SET @SWV_cursor_var3 = CURSOR  FOR SELECT add_bill, add_cap, term_bill, term_cap, eff_date, exp_date
		
      FROM dbo.grp_retro_bill_cap (NOLOCK)
      WHERE group_id = @s_dls_msg_id
      AND ((eff_date <= @d_sub_gr_pl_eff AND (exp_date > @d_sub_gr_pl_eff OR exp_date IS NULL))
      OR (eff_date > @d_sub_gr_pl_eff AND (eff_date < exp_date OR exp_date IS NULL)));
            OPEN @SWV_cursor_var3;
            FETCH NEXT FROM @SWV_cursor_var3 INTO @i_add_bill, @i_add_cap,
                @i_term_bill, @i_term_cap, @dt_eff_date, @dt_exp_date;
            WHILE @@FETCH_STATUS = 0
                BEGIN
                    IF @dt_eff_date < @d_sub_gr_pl_eff
                        SET @dt_eff_date = @d_sub_gr_pl_eff;
		
                    INSERT  INTO dbo.grp_retro_bill_cap
                            ( add_bill ,
                              add_cap ,
                              term_bill ,
                              term_cap ,
                              group_id ,
                              eff_date ,
                              exp_date ,
                              h_datetime ,
                              h_user
                            )
                    VALUES  ( @i_add_bill ,
                              @i_add_cap ,
                              @i_term_bill ,
                              @i_term_cap ,
@i_new_sg_id ,
                              @dt_eff_date ,
                  @dt_exp_date ,
                              @ls_datetime ,
                              @ls_user
                            );
                    FETCH NEXT FROM @SWV_cursor_var3 INTO @i_add_bill,
                        @i_add_cap, @i_term_bill, @i_term_cap, @dt_eff_date,
                        @dt_exp_date;
                END;
            CLOSE @SWV_cursor_var3;
	
	/* 20131101$$ks -- Group Add should just create the new SG 
	 */
            
            IF @s_dls_act_code = 'GA'
                BEGIN
                    SET @SWP_Ret_Value = @i_new_sg_id;
                    SET @SWP_Ret_Value1 = 'Single Group is added';
                    RETURN;
                END;
	
	-- CALL THE ADD SGP PL PROCEDURE
         
            EXECUTE dbo.dlp_add_sg_plan @d_sub_gr_pl_eff, @s_plan_id,
                @s_dls_msg_id, @i_new_sg_id, @ls_user, @ls_datetime,
                @i_rel_gppl_id OUTPUT, @s_sg_err OUTPUT;
            IF ( @i_rel_gppl_id < 1 )
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = 'Error Adding SG Plan record';
                    RETURN;
                END;
	
	
	--trace off;

            SET @SWP_Ret_Value = @i_new_sg_id;
            SET @SWP_Ret_Value1 = 'Single Group is added';
            RETURN;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = @n_error_no;
       SET @SWP_Ret_Value1 = @n_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;




--set debug file to "/tmp/dlp_up_add_sg.trc";
--trace on;
--set explain on;

/* 20131006$$ks - Need to allow subscriber to be in multiple single groups
 *  as well as have muliple transactions for the sub and family in the same 
 *  batch.  Therefore adding a new sub and part of family to one plan
 *  and then same sub and different members to a different plan is allowed.
 *	 A sub can enter himself and spouse in msg group1 and plan1
 *	 and himself and children in msg 1 and plan 2
 *  or he could add himself to msg group2 and plan2.
 *  Since the family does not yet exist in the database BU will create the following actions:
 *	 Sub-MSG1-Plan1	SA
 *	 Dep-MSG1-Plan1	DA
 *	 Sub-MSG1-Plan2	SA
 *	 Dep-MSG1-Plan2	DA
 *  for as many new dependents are in the family
 *  DL will process the one Family-Msg-plan at a time but when the second Family-MSG-Plan 
 *  is processed the new member will be in the member table and if both sets of plans are
 *  in the same MSG, then the new group will also exists.
 *  We only want to have one SG group for each MSG per subscriber so I need to 
 *  change the code to determine if the new group is already set up for this MSG
 */
 
    END;