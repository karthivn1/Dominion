﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_ValidatePCP]
@PCPID INT,@PCPNPID Char(10),@PCPAltID Char(40),@ErrorMsg nVarchar(50) out
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
BEGIN TRY
	SET NOCOUNT ON;

DECLARE @pcID INT=0;

IF @PCPID>0
BEGIN
IF NOT EXISTS(Select fc_id
     FROM facility Where fc_id =@PCPID)
	 BEGIN
	   SET @ErrorMsg='Facility could not be found with the given options. ';
	   RETURN @pcID
	  END
  
  Select @pcID=fc_id FROM facility Where fc_id =@PCPID
END
ELSE IF LEN(@PCPAltID)>0
BEGIN

IF NOT EXISTS(Select fc_id
     FROM facility Where alt_id =@PCPAltID)
	 BEGIN
	    SET @ErrorMsg='Facility could not be found with the given options. ';
	   RETURN @pcID
	END
  Select @pcID=fc_id FROM facility Where alt_id =@PCPAltID
END
ELSE IF LEN(@PCPNPID)>0
BEGIN
IF NOT EXISTS(Select fc_id
     FROM facility Where np_id =@PCPNPID)
	 BEGIN
	   SET @ErrorMsg='Facility could not be found with the given options. ';
	   RETURN @pcID
	 END
	 Select @pcID=fc_id FROM facility Where np_id =@PCPNPID
END
ELSE
BEGIN
	SET @ErrorMsg='No PCP Identifier'
END

RETURN @pcID

END TRY
BEGIN CATCH
THROW;
END CATCH

END