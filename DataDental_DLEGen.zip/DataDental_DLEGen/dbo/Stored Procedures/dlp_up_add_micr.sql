﻿CREATE PROCEDURE [dbo].[dlp_up_add_micr]
    @a_batch_id INT ,
    @SWP_t_sir_id INT ,
    @t_group_id INT ,
    @a_action_code CHAR(2)
    

/* 20140120$$ks -- NOTE group ID in input parameters is not used s_dls_group_id is only
 * used but the name was originally just "group_id" and when we try to update 
 * group ... where group_id = s_dls_group_id the system was reading group_id as this value 
 * and not the group.group_id 
 * I changed the above value name to t_group_id AND forced the group update to include table 
 * name with column values
 */
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 06:41:41 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1



000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_in_transaction CHAR(1);
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @n_fatal INT;

        DECLARE @temp_id INT;

        DECLARE @s_status_code CHAR(1);
        DECLARE @s_account_name CHAR(25);
        DECLARE @s_found_error CHAR(1);
        DECLARE @sg_ach_err INT;
        DECLARE @i_ach_micrs_id INT;

DECLARE @t_sir_id		integer;
DECLARE @sg_bu_sp_id	integer;
DECLARE @sg_up_sp_id	integer;
DECLARE @sg_sir_def_id	integer;
DECLARE @t_sub_sir_id	integer;
DECLARE @t_action_date	date;
DECLARE @n_msi		integer;
DECLARE @msi_num		integer;
DECLARE @msi_num1		integer;
DECLARE @msi_upper		integer;
DECLARE @n_datetime	datetime2(2);

DECLARE @s_dls_sir_id	integer;
DECLARE @s_dls_batch_id	integer;
DECLARE @s_dls_sub_sir_id	integer;
DECLARE @s_member_flag	char(2);
DECLARE @s_alt_id		char(20);
DECLARE @s_ssn		char(11);


DECLARE @s_sub_ssn		char(11);
DECLARE @s_sub_alt_id	char(20);
DECLARE @s_member_code	char(3);
DECLARE @s_last_name	char(15);
DECLARE @s_first_name	char(15);
DECLARE @s_middle_init	char(1);
DECLARE @s_date_of_birth	char(10);
DECLARE @s_student_flag	char(1)
;
DECLARE @s_disable_flag	char(1);
DECLARE @s_cobra_flag	char(1);
DECLARE @s_msg_group_id	integer;
DECLARE @s_plan_id		integer;
DECLARE @s_facility_id	integer;
DECLARE @s_rate_code	char(2);
DECLARE @s_mb_gppl_eff	char(10);
DECLARE @s_mb_fc_eff_date	char(10);
DECLARE @s_mb_term_date	char(10);

DECLARE @s_bank_account	char(25);

DECLARE @s_optional_5 char(5);
DECLARE @s_account_type	char(2);
DECLARE @s_tr_nbr		char(9);
DECLARE @s_process_code	char(1);
DECLARE @s_return_code	char(3);
DECLARE @s_return_descr	char(20);
DECLARE @s_trans_code	char(2);
DECLARE @s_address1	char(30);
DECLARE @s_address2	char(30);
DECLARE @s_city		char(30);
DECLARE @s_state		char(2);
DECLARE @s_zip 		char(5);
DECLARE @s_zipx 		char(4);
DECLARE @s_home_phone	char(10);
DECLARE @s_home_ext 	char(5);
DECLARE @s_work_phone	char(10);
DECLARE @s_work_ext	char(5);
DECLARE @s_producer_id	integer;
DECLARE @s_comm_scheme_id 	char(5);
DECLARE @s_pd_type		char(2);
DECLARE @s_license_number	char(9);
DECLARE @s_selling_period	char(1);
DECLARE @s_pdcomm_eff	char(10);
DECLARE @s_dls_mb_id	integer;
DECLARE @s_dls_sub_id	integer;
DECLARE @s_dls_msg_id	integer;
DECLARE @s_dls_group_id	integer;
DECLARE @s_dls_plan_id	integer;
DECLARE @s_dls_fc_id	integer;
DECLARE @s_dls_pd_id	integer;
DECLARE @s_dls_act_code	char(2);
DECLARE @error_no INT;

        SET NOCOUNT ON;
        SET @t_sir_id = 0;
     
        SET @sg_bu_sp_id = 0;
      
        SET @sg_up_sp_id = 0;
      
        SET @sg_sir_def_id = 0;
       
        SET @t_sub_sir_id = 0;
       
        SET @t_action_date =NULL;
       
        SET @n_msi = 0;
       
        SET @msi_num = 0;
      
        SET @msi_num1 = 0;
      
        SET @msi_upper = 0;
      
        SET @n_datetime =NULL;
        
        SET @s_dls_sir_id = 0;
      
   SET @s_dls_batch_id = 0;
       
        SET @s_dls_sub_sir_id = 0;
       
        SET @s_member_flag ='';
        
        SET @s_alt_id ='';
     
        SET @s_ssn ='';
    
        SET @s_sub_ssn ='';
    
        SET @s_sub_alt_id ='';
      
        SET @s_member_code ='';
     
        SET @s_last_name ='';
     
        SET @s_first_name ='';
    
        SET @s_middle_init ='';
      
        SET @s_date_of_birth ='';
     
        SET @s_student_flag ='';
      
        SET @s_disable_flag ='';
     
        SET @s_cobra_flag ='';
       
        SET @s_msg_group_id = 0;
       
        SET @s_plan_id = 0;
        
        SET @s_facility_id = 0;
        
        SET @s_rate_code ='';
      
        SET @s_mb_gppl_eff ='';
       
        SET @s_mb_fc_eff_date ='';
       
        SET @s_mb_term_date ='';
       
        SET @s_bank_account ='';
     
        SET @s_optional_5 ='';
      
        SET @s_account_type ='';
      
        SET @s_tr_nbr ='';
      
        SET @s_process_code ='';
        
        SET @s_return_code ='';
     
        SET @s_return_descr ='';
   
        SET @s_trans_code ='';
      
        SET @s_address1 ='';
     
        SET @s_address2 ='';
 
        SET @s_city ='';
        
        SET @s_state ='';
        
        SET @s_zip ='';
    
        SET @s_zipx ='';
      
        SET @s_home_phone ='';
      
        SET @s_home_ext ='';
     
        SET @s_work_phone ='';
      
        SET @s_work_ext ='';
      
        SET @s_producer_id = 0;
       
        SET @s_comm_scheme_id ='';
      
        SET @s_pd_type ='';
     
        SET @s_license_number ='';
      
        SET @s_selling_period ='';
       
        SET @s_pdcomm_eff ='';
     
        SET @s_dls_mb_id = 0;
     
        SET @s_dls_sub_id = 0;
      
        SET @s_dls_msg_id = 0;
 
        SET @s_dls_group_id = 0;
      
        SET @s_dls_plan_id = 0;
       
        SET @s_dls_fc_id = 0;
      
        SET @s_dls_pd_id = 0;
     
        SET @s_dls_act_code ='';
      
        BEGIN TRY
		 
			SELECT @t_action_date = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 't_action_date' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_bank_account = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_bank_account' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_account_type = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_account_type' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_tr_nbr = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_tr_nbr' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_trans_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_trans_code' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_process_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_process_code' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_return_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_return_code' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_return_descr = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_return_descr' and  BatchId = @a_batch_id AND Module_Id = 2
			SELECT @s_optional_5 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_optional_5' and  BatchId = @a_batch_id AND Module_Id = 2
			           
            SET @s_found_error = 'N';
            SET @sg_ach_err = 0;
/*
 *IF exists ( SELECT group_id from ach_micrs 
 *				WHERE group_id = s_dls_group_id ) THEN
 *	IF  ( s_dls_act_code = "SA" and s_member_flag = "00" ) THEN
 *			RAISE EXCEPTION -746, 203, "Account information already exists";
 *	END IF
 *END IF
 */
       
            IF ( @s_bank_account IS NULL
                 OR @s_bank_account = ''
               )
                OR LEN(@s_bank_account) = 0 
	--	RAISE EXCEPTION -746, 507, "Missing bank account in client file"; 
	--	let sg_ach_err = 1;
                RETURN 0; /* 20140108$$ks -- no bank account then pull out */
	
         
            IF ( @s_account_type IS NULL
                 OR @s_account_type = ''
               )
                OR LEN(@s_account_type) = 0
                BEGIN
				SET @error_no =508
                    RAISERROR('Missing account type in client file',16,1);
                    SET @sg_ach_err = 1;
                END;
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'MB'
                                        AND tab_name = 'ach_acc_type'
                                        AND code = @s_account_type )
                    BEGIN
					SET @error_no =509
                        RAISERROR('Invalid Account Type',16,1);
                        SET @sg_ach_err = 1;
                    END;
		
	
           
            IF ( @s_tr_nbr IS NULL
                 OR @s_tr_nbr = ''
               )
                OR LEN(@s_tr_nbr) = 0
                BEGIN
				SET @error_no =511
                    RAISERROR('Missing Transit Route Number in client',16,1);
                    SET @sg_ach_err = 1;
                END;
	
           
            IF ( @s_trans_code IS NULL
                 OR @s_trans_code = ''
               )
                OR LEN(@s_trans_code) = 0
                BEGIN
				SET @error_no =512
                    RAISERROR('Missing Transaction Code in client file',16,1);
                    SET @sg_ach_err = 1;
                END;
            ELSE
                IF NOT EXISTS ( SELECT  *
                                FROM    dbo.typ_table (NOLOCK)
                                WHERE   subsys_code = 'MB'
                                        AND tab_name = 'ach_tran_code'
                                        AND code = @s_trans_code )
                    BEGIN
					SET @error_no =513
                        RAISERROR('Invalid Transaction Code',16,1);
                        SET @sg_ach_err = 1;
                    END;
		
	
          
            IF ( @s_process_code IS NULL
                 OR @s_process_code = ''
               )
                BEGIN
                    SET @s_process_code ='';
                    
                END;
	
          
            IF ( @s_return_code IS NULL
                 OR @s_return_code = ''
               )
                BEGIN
                    SET @s_return_code ='';
                   
                END;
	
          
            IF ( @s_return_descr IS NULL
                 OR @s_return_descr = ''
               )
                BEGIN
                    SET @s_return_descr ='';
                   
                END;
	
            
            IF ( @s_optional_5 IS NULL
                 OR @s_optional_5 = ''
               )
                BEGIN
                    SET @s_optional_5 ='';
                  
                END;
	
            IF @a_action_code = 'BI'
/* 20131005$$ks -- ach may already have been created so lets check first
 * 20080626$$ks - added trim to names and max(ach_micr_id) 
 */
                IF @sg_ach_err = 0
                    BEGIN
                      
                        SET @s_account_name = RTRIM(LTRIM(@s_first_name))
                            + ' ' + RTRIM(LTRIM(@s_last_name));
                        SELECT  @s_status_code = code
                        FROM    dbo.typ_table (NOLOCK)
                        WHERE   subsys_code = 'MB'
                                AND tab_name = 'ach_stat_code'
                                AND descr = 'Active';
                      
                        IF EXISTS ( SELECT  group_id
                                    FROM    dbo.ach_micrs (NOLOCK)
                                    WHERE   group_id = @s_dls_group_id
                                            AND account_type = @s_account_type
                                            AND account_name = @s_account_name
                                            AND status_code = @s_status_code )
                            RETURN 0;
		
    INSERT  INTO dbo.ach_micrs
                                ( group_id ,
                                  account_type ,
                       account_name ,
                                  bank_account ,
                                  transit_route_nbr ,
                                  process_code ,
                                  transaction_code ,
                                  pre_authorization ,
                                  void_check ,
                                  status_code ,
                                  return_code ,
                                  return_descr ,
                                  last_mod_date ,
                                  last_mod_user ,
                                  eff_date ,
                                  exp_date ,
                                  optional_5
                                )
                        VALUES  ( @s_dls_group_id ,
                                  @s_account_type ,
                                  @s_account_name ,
                                  @s_bank_account ,
                                  @s_tr_nbr ,
                                  @s_process_code ,
                                  @s_trans_code ,
                                  'Y' ,
                                  'N' ,
                                  @s_status_code ,
                                  @s_return_code ,
                                  @s_return_descr ,
                                  NULL ,
                                  NULL ,
                                  @t_action_date ,
                                  NULL ,
                                  @s_optional_5
                                );
 		
                        SELECT  @i_ach_micrs_id = MAX(ach_micrs_id)
                        FROM    dbo.ach_micrs (NOLOCK)
                        WHERE   group_id = @s_dls_group_id
                                AND account_type = @s_account_type
                                AND account_name = @s_account_name
                                AND bank_account = @s_bank_account
                                AND eff_date =  @t_action_date;
                       

--		IF NOT EXISTS ( SELECT * FROM ach_micrs 
-- 		WHERE group_id = s_dls_group_id ) then
                        IF @i_ach_micrs_id IS NULL
                            BEGIN
							SET @error_no =514
                                RAISERROR('Error in ACH_MICRS creation (SA)',16,1);
                                SET @sg_ach_err = -1;
                            END;
		
                        INSERT  INTO dbo.ach_micrs_d
                                ( ach_micrs_id ,
                                  status_code ,
                                  last_mod_date ,
                                  last_mod_user ,
                                  eff_date
                                )
                        VALUES  ( @i_ach_micrs_id ,
                                  @s_status_code ,
                                  GETDATE() ,
                                  ORIGINAL_LOGIN() ,
                                  @t_action_date
                                );
		/* 20140108$$ks -- copy bank account value to pay token field */
		
                       
                        SET @temp_id = @s_dls_group_id;
                        UPDATE  dbo.[group]
                        SET     pay_token = @s_bank_account
                        WHERE   dbo.[group].group_id = @temp_id;
                    END;
	

            RETURN @sg_ach_err;
        END TRY
        BEGIN CATCH
		IF ERROR_NUMBER() =50000
		EXECUTE @n_fatal = dbo.usp_dl_log_error @a_batch_id,
                                @sg_up_sp_id, @sg_sir_def_id, @t_sub_sir_id,
                                @error_no;
            RETURN -200;
        END CATCH;
        SET NOCOUNT OFF;



--set debug file to "/tmp/dlp_up_add_micr_" || a_batch_id || ".trc";
--trace on;

    END;