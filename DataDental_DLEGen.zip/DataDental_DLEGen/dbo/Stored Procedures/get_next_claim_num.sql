﻿CREATE PROCEDURE [dbo].[get_next_claim_num]
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(64) = NULL OUTPUT ,
    @SWP_Ret_Value3 FLOAT = NULL OUTPUT
    
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @ClaimNo FLOAT;
        DECLARE @Cl_Descr CHAR(12);
        DECLARE @Cldate DATE;
        DECLARE @ClToday DATE;
        DECLARE @Cl_Counter INT;
        DECLARE @ClNoId INT;
        DECLARE @Cntsize SMALLINT;
        DECLARE @ClmStr VARCHAR(16);
        DECLARE @n_zero INT;
        DECLARE @Debug INT;
        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @Zerosize INT;
        DECLARE @strctr VARCHAR(16);
        DECLARE @n_zero_str VARCHAR(16);
        DECLARE @i INT;
        DECLARE @tdate VARCHAR(3);
        DECLARE @SWV_LockVar INT;
        DECLARE @v_Null INT;

        SET NOCOUNT ON;
        BEGIN TRY
            SET @Debug = 0;
            IF ( @Debug = 1 )
                BEGIN
         -- NOT SUPPORTED SET EXPLAIN ON;

   --SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/get_next_clm.trc";

   --TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;
 
--BEGIN WORK;
            SET @Cl_Descr = NULL;
            SET @strctr = NULL;
            SET @Cl_Counter = 0;
            SET @Cntsize = 0;
            SET @Zerosize = 0;
            SET @n_zero = 0;
            SET @n_zero_str = '';
-- Trying to minimize number of hits to table!!!$$ks
--Select claim_num_gen_id into  ClNoID from claim_num_gen;


-- Executing dummy SELECT to lock table in exclusive mode
            SELECT TOP 1
                    @SWV_LockVar = 1
            FROM    dbo.claim_num_gen WITH ( HOLDLOCK, XLOCK );
            SELECT  @ClNoId = claim_num_gen_id ,
                    @Cl_Descr = descr ,
                    @Cldate = [date] ,
                    @Cl_Counter = counter ,
                    @Cntsize = counter_size ,
                    @ClToday = CONVERT(DATE, GETDATE())
            FROM    dbo.claim_num_gen (NOLOCK)
            WHERE   descr = 'CurrentClaim';
            
            IF ( @ClNoId IS NULL )
                BEGIN
                    
                    RAISERROR('Can not find default claim values for next claim number.',16,
         1);
                END;

            IF @Cldate IS NULL
                OR @Cl_Counter IS NULL
                BEGIN
                   
                    RAISERROR('claim_num_gen table contains invalid values!',16,1);
                END;

            IF @Cldate <> @ClToday
                BEGIN
                    UPDATE  dbo.claim_num_gen
                    SET     [date] = CONVERT(DATE, GETDATE()) ,
                            counter = 1
                    WHERE   descr = 'CurrentClaim';
                    SET @Cldate = @ClToday;
                    SET @Cl_Counter = 1;
                END;
            ELSE
                BEGIN
                    UPDATE  dbo.claim_num_gen
                    SET     counter = counter + 1
                    WHERE   descr = 'CurrentClaim';
                    SET @Cl_Counter = @Cl_Counter + 1;
                END;

           
            SET @strctr = @Cl_Counter;
            SET @n_zero = LEN(@strctr);
            IF @Cntsize > 0
                SET @Zerosize = @Cntsize - @n_zero;
            ELSE
                SET @Zerosize = 5 - @n_zero;

            IF @Zerosize > 0
                BEGIN
                    SET @n_zero_str = '0';
                    SET @Zerosize = @Zerosize - 1;
                    SET @i = 1;
                    WHILE @i <= @Zerosize
                        BEGIN
                            SET @n_zero_str = @n_zero_str + '0';  
                            SET @i = @i + 1;
                        END;
                END;
            ELSE
                BEGIN
                    SET @v_Null = 0;
                END;
--   Let ClmStr = ClmStr || Cl_Counter;

            SET @tdate = ( DATEDIFF(DAY,
                                    ( DATEADD(DAY, -1,
                                              CONVERT(DATE, CONCAT('01-01-',
                                                              YEAR(CONVERT(DATE, GETDATE()))))) ),
                                    CONVERT(DATE, CONVERT(DATE, GETDATE()))) ); 
--Let tdate  =  (date("01-01-1998") - (date("01-01-" || Year(today)) - 1)) ;
            IF LEN(@tdate) < 3
                IF LEN(@tdate) = 1
                    SET @tdate = '00' + @tdate;
                ELSE
                    IF LEN(@tdate) = 2
                        SET @tdate = '0' + @tdate;

/*
Let tdate = (date(today) - (date("01-01-" || Year(today)) - 1));

Let ClmStr = Year(Today) || (date(today) - date("01-01-" || Year(today)))||n_zero_str || Cl_Counter ;
*/
            SET @ClmStr = CONCAT(YEAR(CONVERT(DATE, GETDATE())), @tdate,
                                 @n_zero_str, @Cl_Counter); 
           
            SET @SWP_Ret_Value = 0;
            SET @SWP_Ret_Value1 = 0;
            SET @SWP_Ret_Value2 = NULL;
            SET @SWP_Ret_Value3 = CONVERT(FLOAT, @ClmStr);
            RETURN;
            IF ( @Debug = 1 )
                BEGIN--TRACE statement has no equivalent in MSSQL
--trace off;
                    SET @v_Null = 0;
                END;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = @n_error_no;
            SET @SWP_Ret_Value1 = @n_isam_error;
            SET @SWP_Ret_Value2 = @n_error_text;
            SET @SWP_Ret_Value3 = NULL;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;