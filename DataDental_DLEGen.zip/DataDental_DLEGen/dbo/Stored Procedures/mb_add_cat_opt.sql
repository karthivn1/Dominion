﻿CREATE PROCEDURE [dbo].[mb_add_cat_opt]
    @RlmbgrplID INT ,
    @MemberID INT ,
    @a_waiting_period VARCHAR(1) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(100) = NULL OUTPUT
    


/* Note: Commits and Rollbacks done in calling program * /
/ * 20110701-$$ks - fix dependent reinstate issues
	Insert mbr_pl_cat records if doesn't exist
	Update mbr_pl_cat records if already exists
	Reset OEDt date if dependent reinstated and waiting period not carried over 
*/
AS
    BEGIN
/*
DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server
*/
        DECLARE @i_error_no INT;
        DECLARE @i_isam_error INT;
        DECLARE @s_error_text VARCHAR(64);
        DECLARE @ErrMsg VARCHAR(100);


        DECLARE @CatName CHAR(50);
        DECLARE @ListName CHAR(50);
        DECLARE @relgpplID INT;
        DECLARE @planID INT;
        DECLARE @GroupID INT;--Modififed for Datatype Issue against Change# CH001
        DECLARE @FamilyID INT;
        DECLARE @OldMbgrplID INT;
        DECLARE @waitingPeriod INT;
        DECLARE @OEDt DATE;
        DECLARE @EffDate DATE;
        DECLARE @expdate DATE;
        DECLARE @GpplCatID INT;
        DECLARE @WaitingEff DATE;
        DECLARE @WaitingTemp DATE;
        DECLARE @debug INT;
        DECLARE @v_Null INT;

-----------------------------------------
--    Handle Warning & Non Fatal Errors
-----------------------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            
            SET @debug = 0;
            IF @debug = 1
                BEGIN--SET DEBUG has no equivalent in MSSQL
--set debug file to "/tmp/mb_add_cat.trc";

	--TRACE statement has no equivalent in MSSQL
--trace on;
                    SET @v_Null = 0;
                END;

            BEGIN
                BEGIN TRY
                    SELECT  @GroupID = gppl.group_id ,
                            @planID = gppl.plan_id ,
                            @EffDate = MIN(plfc.eff_date)
                    FROM    dbo.rlmbgrpl gppl ( NOLOCK ) ,
                            dbo.member mbr ( NOLOCK ) ,
                            dbo.rlplfc plfc ( NOLOCK )
                    WHERE   gppl.member_id = mbr.family_id
                            AND gppl.mb_gr_pl_id = plfc.mb_gr_pl_id
                            AND mbr.member_id = plfc.member_id
                            AND mbr.member_id = @MemberID
                            AND gppl.mb_gr_pl_id = @RlmbgrplID
                    GROUP BY gppl.group_id ,
                            gppl.plan_id;

						                    
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
                    RAISERROR('Failed to Retrieve Member''s Group Plan record.',16,1);
                END CATCH;
            END;
            SET @OEDt = @EffDate;
            SET @RlmbgrplID = @RlmbgrplID;
            BEGIN
                BEGIN TRY
                    SELECT  @relgpplID = dbo.rel_gppl.rel_gppl_id
                    FROM    dbo.rel_gppl (NOLOCK)
                    WHERE   dbo.rel_gppl.group_id = @GroupID
                            AND dbo.rel_gppl.plan_id = @planID
                            AND dbo.rel_gppl.eff_date <= @EffDate
                            AND dbo.rel_gppl.exp_date IS NULL;
							
                   
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
                    RAISERROR('Failed to Retrieve Group Plan record.',16,1);
                END CATCH;
            END;
            SELECT  @FamilyID = family_id
            FROM    dbo.member (NOLOCK)
            WHERE   member_id = @MemberID;
            
            SELECT  @OldMbgrplID = MAX(dbo.rlmbgrpl.mb_gr_pl_id)
            FROM    dbo.rlmbgrpl (NOLOCK)
            WHERE   member_id = @FamilyID
                    AND plan_id = @planID
                    AND ( mb_gr_pl_id != @RlmbgrplID
                          OR ( mb_gr_pl_id = @RlmbgrplID
                               AND exp_gr_pl IS NULL
                             )
                        );
            
            IF @OldMbgrplID IS NULL
                BEGIN
                    SELECT  @OldMbgrplID = MAX(m.mb_gr_pl_id)
                    FROM    dbo.rlmbgrpl m ( NOLOCK ) ,
                            dbo.[plan] p ( NOLOCK )
                    WHERE   m.member_id = @FamilyID
                            AND m.plan_id = p.plan_id
                            AND m.plan_id = @planID
                            AND ( m.mb_gr_pl_id != @RlmbgrplID
                                  OR ( m.mb_gr_pl_id = @RlmbgrplID
                                       AND m.exp_gr_pl IS NULL
                                     )
                                )
                            AND p.ins_type = ( SELECT   p2.ins_type
                                               FROM     dbo.[plan] p2 ( NOLOCK )
                                               WHERE    p2.plan_id = @planID
                                             );
                  
                END;
	
	/* Check if Dependent being reinstated with waiting periods reset! */
            IF @MemberID <> @FamilyID
                AND @a_waiting_period = 'Y'
                BEGIN
                    SELECT  @EffDate = MAX(eff_date)
                    FROM    dbo.rlplfc (NOLOCK)
                    WHERE   mb_gr_pl_id = @RlmbgrplID
                            AND member_id = @MemberID
                            AND ( exp_date IS NULL
                                  OR exp_date IS NOT NULL
                                  AND exp_date != eff_date
                                );
                    
                    IF @EffDate IS NOT NULL
                        SET @OEDt = @EffDate;
                    ELSE
                        RAISERROR('Failed to find most recent eff Dt for Dep',16,1);
                END;
	
            BEGIN
                DECLARE @SWV_cursor_var1 TABLE
                    (
                      id INT IDENTITY ,
                      gppl_cat_id INT ,
                  waiting_period INT ,
                      cat_name CHAR(50)
                    );
				
				--DECLARE @SWV_cursor_var1 CURSOR;
                BEGIN TRY

                    INSERT  INTO @SWV_cursor_var1
                            ( gppl_cat_id ,
                              waiting_period ,
                              cat_name
                            )
                            SELECT  gppl_cat_id ,
                                    waiting_period ,
                        cat_name
                            FROM    dbo.gppl_cat (NOLOCK)
                            WHERE   dbo.gppl_cat.rel_gppl_id = @relgpplID
                                    AND dbo.gppl_cat.exp_date IS NULL;
			/*
                    SET @SWV_cursor_var1 = CURSOR  FOR SELECT gppl_cat_id , waiting_period, cat_name
		
            FROM dbo.gppl_cat (NOLOCK)
            WHERE dbo.gppl_cat.rel_gppl_id = @relgpplID AND dbo.gppl_cat.exp_date IS NULL;
                    OPEN @SWV_cursor_var1;
                    FETCH NEXT FROM @SWV_cursor_var1 INTO @GpplCatID,
                        @waitingPeriod, @CatName; */

                    DECLARE @cur1_cnt INT ,
                        @cur_i INT;

                    SET @cur_i = 1;

			--Get the no. of records for the cursor
                    SELECT  @cur1_cnt = COUNT(1)
                    FROM    @SWV_cursor_var1;

                    WHILE ( @cur_i <= @cur1_cnt )

                    -- WHILE @@FETCH_STATUS = 0
                    BEGIN
						
                            SELECT  @GpplCatID = gppl_cat_id ,
                                    @waitingPeriod = waiting_period ,
                                    @CatName = cat_name
                            FROM    @SWV_cursor_var1
                            WHERE   id = @cur_i;

                            SET @WaitingEff = DATEADD(MONTH, @waitingPeriod,
                                                      @EffDate);
                            IF @a_waiting_period <> 'Y'
                                BEGIN
                                    SELECT  @OEDt = MAX(oed)
                                    FROM    dbo.mbr_pl_cat (NOLOCK)
                                    WHERE   mbgrpl_id = @OldMbgrplID
                                            AND member_id = @MemberID
                                            AND oed IS NOT NULL;
                                   
                                    IF NOT EXISTS ( SELECT  *
                                                    FROM    dbo.mbr_pl_cat mbcat ( NOLOCK ) ,
                                                            dbo.gppl_cat gpcat ( NOLOCK )
                                                    WHERE   mbcat.gppl_cat_id = gpcat.gppl_cat_id
                                                            AND gpcat.cat_name = @CatName
                                                            AND mbcat.mbgrpl_id = @OldMbgrplID
                                                            AND mbcat.member_id = @MemberID )
                                        BEGIN
                                            IF @OEDt IS NOT NULL
                                                SET @WaitingEff = DATEADD(MONTH,
                                                              @waitingPeriod,
                                                              @OEDt);
                                        END;
                                    ELSE
                                        BEGIN
                                            SELECT  @WaitingTemp = waiting_eff_date
                                            FROM    dbo.mbr_pl_cat mbcat ( NOLOCK ) ,
                                                    dbo.gppl_cat gpcat ( NOLOCK )
                                            WHERE   mbcat.gppl_cat_id = gpcat.gppl_cat_id
                                                    AND gpcat.cat_name = @CatName
                                                    AND mbcat.mbgrpl_id = @OldMbgrplID
                                                    AND mbcat.member_id = @MemberID;
                                           
                                            IF @WaitingTemp IS NOT NULL
                                                SET @WaitingEff = @WaitingTemp;
                                        END;
                                END;
		
    IF EXISTS ( SELECT  mbr_pl_cat_id
                                        FROM    dbo.mbr_pl_cat (NOLOCK)
                                        WHERE   gppl_cat_id = @GpplCatID
                                                AND mbgrpl_id = @RlmbgrplID
             AND member_id = @MemberID )
                                IF EXISTS ( SELECT  mbr_pl_cat_id
                                            FROM    dbo.mbr_pl_cat (NOLOCK)
                                            WHERE   gppl_cat_id = @GpplCatID
                                                    AND mbgrpl_id = @RlmbgrplID
                                                    AND member_id = @MemberID
                                                    AND waiting_eff_date = @WaitingEff
                                                    AND oed = @EffDate )
                                    BEGIN
                                        SET @v_Null = 0;
                                    END;
			-- Do nothing, record already exists and has correct values
                                ELSE
                                    UPDATE  dbo.mbr_pl_cat
                                    SET     waiting_eff_date = @WaitingEff ,
                                            oed = @OEDt ,
                                            h_user = ORIGINAL_LOGIN() ,
                                            h_datetime = GETDATE()
                                    WHERE   gppl_cat_id = @GpplCatID
                                            AND mbgrpl_id = @RlmbgrplID
                                            AND member_id = @MemberID
                                            AND lock = 'N'; -- dont update if record locked
			
                            ELSE
                                INSERT  INTO dbo.mbr_pl_cat
                                        ( gppl_cat_id ,
                                          mbgrpl_id ,
                                          member_id ,
                                          waiting_eff_date ,
                                          lock ,
                                          oed ,
                                          h_user ,
                                          h_datetime
                                        )
                                VALUES  ( @GpplCatID ,
                                          @RlmbgrplID ,
                                          @MemberID ,
                                          @WaitingEff ,
                                          'N' ,
                                          @OEDt ,
                                          ORIGINAL_LOGIN() ,
                                          GETDATE()
                                        );
	 	  
                            --FETCH NEXT FROM @SWV_cursor_var1 INTO @GpplCatID,@waitingPeriod, @CatName;
                            SET @cur_i = @cur_i + 1;

                        END;
                    --CLOSE @SWV_cursor_var1;
                END TRY
                BEGIN CATCH
                    SET @i_error_no = ERROR_NUMBER();
                    SET @i_isam_error = ERROR_LINE();
                    SET @s_error_text = ERROR_MESSAGE();
					RAISERROR('Failed to insert mbr_pl_cat record .',16,1);
                END CATCH;
            END;
			
            SET @SWP_Ret_Value = @MemberID;
            SET @SWP_Ret_Value1 = 'Member is added to Category Waiting Period .';
            RETURN;
            IF @debug = 1
                BEGIN--TRACE statement has no equivalent in MSSQL
--trace off;
                    SET @v_Null = 0;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_text = ERROR_MESSAGE();
            SET @SWP_Ret_Value = @i_error_no;
            SET @SWP_Ret_Value1 = @s_error_text;
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

    END;