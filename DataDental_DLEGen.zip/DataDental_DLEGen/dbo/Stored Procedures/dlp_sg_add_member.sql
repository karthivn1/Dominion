﻿CREATE PROCEDURE [dbo].[dlp_sg_add_member]
    @a_batch_id INT ,
    @a_tl_sir_id INT ,
    @a_has_address CHAR(1) ,
    @a_user CHAR(20) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 INT = NULL OUTPUT ,
    @SWP_Ret_Value2 DATETIME = NULL OUTPUT
    
	

-- DATE: 12/04/96


--	IF tl_log_error(s_dls_sir_id, n_return_code) != 0 THEN
AS
    BEGIN
/*
-- This procedure was converted on Fri Jul 29 12:08:08 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1




000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
--20120528$$ks - added paperless option using nameprefix field


/* 20120228$$ks - added new field optional_5 using namesuffix field*/
        DECLARE @n_ext_id CHAR(20);
        DECLARE @n_ext_id_col CHAR(20);
        DECLARE @n_ext_id_type INT;
        DECLARE @n_error_code INT;
        DECLARE @n_return_code INT;
        DECLARE @n_error_desc CHAR(64);

        DECLARE @n_fatal INT;
        DECLARE @n_count INT;
        DECLARE @n_tmp_zip CHAR(9);

DECLARE @s_dls_sir_id	integer;
DECLARE @s_dls_batch_id	integer;
DECLARE @s_dls_sub_sir_id	integer;
DECLARE @s_member_flag	char(2);
DECLARE @s_alt_id		char(20);
DECLARE @s_ssn		char(11);
DECLARE @s_sub_ssn		char(11);
DECLARE @s_sub_alt_id	char(20);
DECLARE @s_member_code	char(3);

DECLARE @s_paperless	char(1);
DECLARE @s_last_name	char(15);

DECLARE @s_optional_5	char(5);
DECLARE @s_first_name	char(15);
DECLARE @s_middle_init	char(1);
DECLARE @s_name_prefix	char(5);
DECLARE @s_name_suffix	char(5);
DECLARE @s_date_of_birth	char(10);
DECLARE @s_student_flag	char(1);
DECLARE @s_disable_flag	char(1);
DECLARE @s_cobra_flag	char(1);
DECLARE @s_msg_group_id	integer;
DECLARE @s_plan_id		integer;
DECLARE @s_facility_id	integer;
DECLARE @s_rate_code	char(2);
DECLARE @s_mb_gppl_eff	char(10);
DECLARE @s_mb_fc_eff_date	char(10);
DECLARE @s_mb_term_date	char(10);
 
DECLARE @s_bank_account	char(25);
DECLARE @s_account_type	char(2);
DECLARE @s_tr_nbr		char(9);
DECLARE @s_trans_code	char(2);
DECLARE @s_address1	char(30);
DECLARE @s_address2	char(30);
DECLARE @s_city		char(30);
DECLARE @s_state		char(2);
DECLARE @s_zip 		char(5);
DECLARE @s_zipx 		char(4);
DECLARE @s_home_phone	char(10);
DECLARE @s_home_ext 	char(5);
DECLARE @s_work_phone	char(10);
DECLARE @s_work_ext	char(5);
DECLARE @s_email		char(250);
DECLARE @s_producer_id	integer;
DECLARE @s_license_number	char(9);
DECLARE @s_selling_period	char(1);
DECLARE @s_pdcomm_eff	char(10);
DECLARE @s_dls_mb_id	integer;
DECLARE @s_dls_sub_id	integer;
DECLARE @s_dls_msg_id	integer;
DECLARE @s_dls_group_id	integer;
DECLARE @s_dls_plan_id	integer;
DECLARE @s_dls_fc_id	integer;
DECLARE @s_dls_pd_id	integer;
DECLARE @s_dls_act_code	char(2);
DECLARE @t_new_ssn char(11);
DECLARE @s_new_ssn char(11);
DECLARE @t_src_id char(20);
DECLARE @s_src_id char(20);
DECLARE @t_subnew_ssn char(11);
DECLARE @s_subnew_ssn char(11);
DECLARE @t_subsrc_id char(20);
DECLARE @s_subsrc_id char(20);
DECLARE @s_ext_id_col char(20);
DECLARE @t_ext_id_col char(20);

DECLARE @n_msi	integer;
DECLARE @msi_upper integer;

DECLARE @n_datetime	datetime2(2)

        DECLARE @d_address_id INT;
		DECLARE @error_code INT;

        
	-- Expected database error
	
--	END IF
        SET NOCOUNT ON;
        SET @s_dls_sir_id =0;
        
        SET @s_dls_batch_id =0;
       
        SET @s_dls_sub_sir_id =0;
     
        SET @s_member_flag ='';
      
        SET @s_alt_id ='';
        
        SET @s_ssn ='';
        
        SET @s_sub_ssn ='';
        
        SET @s_sub_alt_id ='';
        
        SET @s_member_code ='';
        
        SET @s_paperless ='';
      
        SET @s_last_name ='';
       
        SET @s_optional_5 ='';

    SET @s_first_name ='';
        
        SET @s_middle_init ='';
       
        SET @s_name_prefix ='';
      
        SET @s_name_suffix ='';
       
        SET @s_date_of_birth ='';
      
        SET @s_student_flag ='';
        
        SET @s_disable_flag ='';
        
        SET @s_cobra_flag ='';
       
        SET @s_msg_group_id =0;
       
        SET @s_plan_id =0;
        
        SET @s_facility_id =0;
       
        SET @s_rate_code ='';
        
        SET @s_mb_gppl_eff ='';
       
        SET @s_mb_fc_eff_date ='';
       
        SET @s_mb_term_date ='';
       
        SET @s_bank_account ='';
      
        SET @s_account_type ='';
       
        SET @s_tr_nbr ='';
        
        SET @s_trans_code ='';
       
        SET @s_address1 ='';
       
        SET @s_address2 ='';
       
        SET @s_city ='';
       
        SET @s_state ='';
      
        SET @s_zip ='';
       
        SET @s_zipx ='';
        
        SET @s_home_phone ='';
       
        SET @s_home_ext ='';
       
        SET @s_work_phone ='';
        
        SET @s_work_ext ='';
    
        SET @s_email ='';
       
        SET @s_producer_id =0;
       
        SET @s_license_number ='';
      
        SET @s_selling_period ='';
        
        SET @s_pdcomm_eff ='';
        
        SET @s_dls_mb_id =0;
      
        SET @s_dls_sub_id =0;
        
        SET @s_dls_msg_id =0;
       
        SET @s_dls_group_id =0;
      
        SET @s_dls_plan_id =0;
    
        SET @s_dls_fc_id =0;
     
        SET @s_dls_pd_id =0;
   
        SET @s_dls_act_code ='';
        
        SET @t_new_ssn ='';
        
        SET @s_new_ssn ='';
       
        SET @t_src_id ='';
        
        SET @s_src_id ='';
        
        SET @t_subnew_ssn ='';
        
        SET @s_subnew_ssn ='';
     
        SET @t_subsrc_id ='';
        
        SET @s_subsrc_id ='';
        
        SET @s_ext_id_col ='';
        
        SET @t_ext_id_col ='';
        
        SET @n_msi =0;
        
        SET @msi_upper =0;
        
        --SET @n_datetime = NULL;
		SET @n_datetime = GETDATE();

       
        BEGIN TRY

				SELECT @s_dls_sir_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_sir_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_last_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_last_name' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_first_name = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_first_name' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_sub_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_sub_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_member_code = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_member_code' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_date_of_birth = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_date_of_birth' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_paperless = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_paperless' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_disable_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_disable_flag' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_student_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_student_flag' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_ext_id_col = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_ext_id_col' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_member_flag = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_member_flag' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_subsrc_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_subsrc_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_subnew_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_subnew_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_dls_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
				--SELECT @s_dls_sub_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_src_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_src_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_new_ssn = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_new_ssn' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_zipx = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_zipx' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_zip = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_zip' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_email = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_email' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_dls_mb_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_dls_mb_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_address1 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_address1' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_address2 = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_address2' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_city = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_city' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_state = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_state' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_home_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_home_phone' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_home_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_home_ext' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_work_phone = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_work_phone' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_work_ext = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_work_ext' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @msi_upper = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'msi_upper' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @n_msi = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2
				SELECT @s_sub_alt_id = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_sub_alt_id' and  BatchId = @a_batch_id AND Module_Id = 2	
				SELECT @s_middle_init = VarValue from dbo.GlobalVar(NOLOCK) where VarName = 's_middle_init' and  BatchId = @a_batch_id AND Module_Id = 2															
						
            
            IF ( ( @s_last_name IS NULL
                   OR @s_last_name = ''
                 )
                 OR LEN(@s_last_name) = 0
               )
			   BEGIN
			   SET @error_code=201
                RAISERROR('Null Last Name',16,1);
				END

           
            IF ( ( @s_first_name IS NULL
                   OR @s_first_name = ''
                 )
                 OR LEN(@s_first_name) = 0
               )
			   BEGIN
			   SET @error_code=202
                RAISERROR('Null First Name',16,1);
				END

--if (s_alt_id is null or length(s_alt_id) = 0) then
--	RAISE EXCEPTION -746, 203, "Null member alt_id";
--end if

--if (s_sub_alt_id is null or length(s_sub_alt_id) = 0) then
--	RAISE EXCEPTION -746, 204, "Null family alt_id";
--end if

            
            IF ( ( @s_sub_ssn IS NULL
                   OR @s_sub_ssn = ''
                 )
                 OR LEN(@s_sub_ssn) = 0
               )
			   BEGIN
			   SET @error_code=205
                RAISERROR('Null subscriber''s SSN',16,1);
			END

           
            IF ( ( @s_member_code IS NULL
                   OR @s_member_code = ''
                 )
                 OR LEN(@s_member_code) = 0
               )
			   BEGIN
			   SET @error_code=206
                RAISERROR('Null member code',16,1);
				END
            
            IF ( (@s_date_of_birth IS NULL
                 OR @s_date_of_birth = '')
               )
			   BEGIN
			   SET @error_code=207
                RAISERROR('Null member date of birth',16,1);
				END
            
            IF ( (@s_paperless IS NULL
                 OR @s_paperless = '')
               )
                BEGIN
                    SET @s_paperless = 'N' ;
                    
                END;

            IF NOT EXISTS ( SELECT  *
                            FROM    dbo.mbr_code (NOLOCK)
                            WHERE   @s_member_code = mbr_code )
							BEGIN
			   SET @error_code=208
                RAISERROR('Invalid member code',16,1);
				END
           
            IF ( (@s_disable_flag IS NULL
                 OR @s_disable_flag = '')
               )
                BEGIN
                    SET @s_disable_flag = 'N';
                    
     END;
    ELSE
    BEGIN
         
        IF @s_disable_flag NOT IN ( 'Y', 'N' )
                        BEGIN
                            SET @s_disable_flag = 'N';
                            
                        END;
                END;

           
            IF ( (@s_student_flag IS NULL
                 OR @s_student_flag = '')
               )
                BEGIN
                    SET @s_student_flag = 'N' ;
                    
                END;
            ELSE
                BEGIN
                   
                    IF @s_student_flag NOT IN ( 'Y', 'N' )
                        BEGIN
                            SET @s_student_flag = 'N';
                           
                        END;
                END;

           
            IF ( ( @s_ext_id_col IS NULL
                   OR @s_ext_id_col = ''
                )
                 OR ( ( @s_ext_id_col IS NOT NULL
                        AND @s_ext_id_col <> ''
                      )
                      AND LEN(@s_ext_id_col) = 0
                    )
               )
                BEGIN
                    SELECT  @n_ext_id_type = CAST(int_1 AS INT) ,
                            @t_ext_id_col = str_1 
                    FROM    dbo.typ_table_exp t (NOLOCK),
                            dbo.dds_default m (NOLOCK)
                    WHERE   m.ext_id_type = t.int_1
                            AND t.subsys_code = 'MB'
                            AND t.tab_name = 'ext_id_type'; 
                  
                END;
            ELSE
                BEGIN
                   
                    SET @t_ext_id_col = @s_ext_id_col;
                  
                    SELECT  @n_ext_id_type = int_1
                    FROM    dbo.typ_table_exp t (NOLOCK)
                    WHERE   t.subsys_code = 'MB'
                            AND t.tab_name = 'ext_id_type'
                            AND t.str_1 = @s_ext_id_col; 
                    
                END;

           
            IF @s_member_flag = '00'
                BEGIN
                    
                    IF @s_member_code NOT IN ( '10', '20' )
                        OR @s_alt_id != @s_sub_alt_id
						BEGIN
			   SET @error_code=209
                        RAISERROR('Mismatched member code, alt_id',16,1);
			END
                    
                    IF ( @s_subsrc_id IS NULL
                         OR @s_subsrc_id = ''
                       )
                        BEGIN
                            SET @t_subsrc_id ='';
                           
                        END;
                    ELSE
                        BEGIN
                            
                            SET @t_subsrc_id = @s_subsrc_id;
                           
                        END;
	
                    
                    IF ( @s_subnew_ssn IS NULL
                         OR @s_subnew_ssn = ''
                       )
                        BEGIN
                            SET @t_subnew_ssn ='';
                            
                        END;
                    ELSE
                        BEGIN
                            
                            SET @t_subnew_ssn = @s_subnew_ssn;
                           
                        END;
	
                   IF @t_ext_id_col = 'new_ssn'
                        BEGIN
                            
                            SET @n_ext_id = @t_subnew_ssn;
                        END;
                    ELSE
                        BEGIN
                           
                            IF @t_ext_id_col = 'alt_id'
                                BEGIN
                                  
                                    SET @n_ext_id = @s_sub_alt_id;
                                END;
                            ELSE
                                BEGIN
            
 IF @t_ext_id_col = 'source_id'
                                        BEGIN
                                           
                                            SET @n_ext_id = @t_subsrc_id;
                                        END;
                                    ELSE
                                        BEGIN
                                           
                                            IF @t_ext_id_col = 'member_id'
                                                SET @n_ext_id = '-1';
                                            ELSE
											BEGIN
												SET @error_code=576
                                                RAISERROR('Invalid External ID value',16,1);
											END
                                        END;
                                END;
                        END;
                END;
            ELSE
                BEGIN
                   
                    IF @s_member_code NOT IN ( '30', '40', '50', '70' )
                        OR @s_alt_id = @s_sub_alt_id
						BEGIN
						SET @error_code=209
                        RAISERROR('Mismatched member code, alt_id',16,1);
					END
                    
                    IF @s_dls_sub_id IS NULL
		-- only will get subscriber id if subscriber is also new sub.
                        BEGIN
						select @s_sub_ssn as '@s_sub_ssn 530'
                            SELECT  @n_count = COUNT(*)
                            FROM    dbo.member (NOLOCK)
                            WHERE   member_ssn = @s_sub_ssn
                                    AND member_id = family_id;
                            IF @n_count > 1
							BEGIN
							SET @error_code=210
                                RAISERROR('Dependent has multiple subscribers by SSN',16,1);
							END
		
                            SELECT  @s_dls_sub_id = m.member_id ,
                                    @n_ext_id_type = m.ext_id_type ,
                                    @n_ext_id_col = t.str_1
                            FROM    dbo.member m (NOLOCK),
                                    dbo.typ_table_exp t (NOLOCK)
                            WHERE   m.member_ssn = @s_sub_ssn
                                    AND m.member_id = family_id
                                    AND t.subsys_code = 'MB'
                                    AND t.tab_name = 'ext_id_type'
                                    AND t.int_1 = m.ext_id_type; 

                            UPDATE GlobalVar SET VarValue = @s_dls_sub_id where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2
                           
                            IF @s_dls_sub_id IS NULL
							BEGIN
									SET @error_code=211
									RAISERROR('Dependent''s subscriber not found by SSN',16,1);
								END
                        END;
                    ELSE
                        BEGIN
                            SELECT  @n_ext_id_type = m.ext_id_type ,
                                    @n_ext_id_col = t.str_1
                            FROM    dbo.member m (NOLOCK),
                                    dbo.typ_table_exp t (NOLOCK)
                            WHERE   m.member_id = @s_dls_sub_id
                                    AND m.member_id = family_id
                                    AND t.subsys_code = 'MB'
                                    AND t.tab_name = 'ext_id_type'
                                    AND t.int_1 = m.ext_id_type; 
                          
                        END;
	
                    
                    IF @t_ext_id_col != @n_ext_id_col --Sub has diff type as sys default
                        BEGIN
                            SET @t_ext_id_col = @n_ext_id_col ;
                           
                        END;
	
                    
                    IF ( @s_src_id IS NULL
                         OR @s_src_id = ''
                       )
                        BEGIN
    SET @t_src_id ='';
          
              END;
  ELSE
                 BEGIN
                 
                            SET @t_src_id = @s_src_id;
                          
                        END;
	
                    
                    IF ( @s_new_ssn IS NULL
                         OR @s_new_ssn = ''
                       )
                        BEGIN
                            SET @t_new_ssn ='';
                            
                        END;
                    ELSE
                        BEGIN
                           
                            SET @t_new_ssn = @s_new_ssn;
                         
                        END;
	
                 
                    IF @t_ext_id_col = 'new_ssn'
                        BEGIN
                           
                            SET @n_ext_id = @t_new_ssn;
                        END;
                    ELSE
                        BEGIN
                           
                            IF @t_ext_id_col = 'alt_id'
                                BEGIN
   
                        SET @n_ext_id = @s_alt_id;
                                END;
                            ELSE
                                BEGIN
                                   
                                    IF @t_ext_id_col = 'source_id'
                                        BEGIN
                                           
                                            SET @n_ext_id = @t_src_id;
                                        END;
                                    ELSE
                                        BEGIN
                                           
                                            IF @t_ext_id_col = 'member_id'
                                                SET @n_ext_id = '-1';
                                            ELSE
											BEGIN
											SET @error_code=576
                                                RAISERROR('Invalid External ID value',16,1);
											END
                                        END;
                                END;
                        END;
                END;

/* 20131005$$ks Added alt_id to the test */
         
            IF @s_member_flag = '00'
                BEGIN
                    SELECT  @s_dls_mb_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_ssn = @s_sub_ssn
                            AND last_name = @s_last_name
                            AND first_name = @s_first_name
                            AND member_code IN ( '10', '20' )
                            AND ( alt_id IS NULL
                                  OR alt_id != ''
                                  OR alt_id = @s_alt_id
                                );

                END;
            ELSE
                BEGIN
                    SELECT  @s_dls_mb_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   member_ssn = @s_ssn
                            AND last_name = @s_last_name
                            AND first_name = @s_first_name
                            AND member_code NOT IN ( '10', '20' )
                            AND date_of_birth = CAST(@s_date_of_birth AS DATE)
                            AND ( alt_id IS NULL
                                  OR alt_id != ''
                                  OR alt_id = @s_alt_id
                                )
                            AND family_id = @s_dls_sub_id;
 
                END;  -- 20140129$$ks - existing dep for diff sub being picked up

           
            IF @s_dls_mb_id IS NOT NULL AND @s_dls_mb_id>0
                BEGIN
                   
                    SET @SWP_Ret_Value = @s_dls_mb_id;
                   
                    SET @SWP_Ret_Value1 = @n_msi + 1;
					UPDATE GlobalVar SET VarValue = @n_msi + 1  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2
         
					SET @SWP_Ret_Value2 = @n_datetime;
                    RETURN;
                END; -- 20131016$$ks - not error any more
	--RAISE EXCEPTION -746, 212, "Member already exists";
	
           
            SET @n_msi = @n_msi + 1;
           UPDATE GlobalVar SET VarValue = @n_msi  where VarName = 'n_msi' and  BatchId = @a_batch_id AND Module_Id = 2

		   

            IF @n_msi > @msi_upper
			BEGIN
			   SET @error_code=720
                RAISERROR('msi number exceeded the maximum allocated number(SA)',16,1);
			END
				
				

            IF @s_member_flag = '00'
                BEGIN

		                    INSERT  INTO dbo.member
                            ( family_id ,
                              alt_id ,
                              member_code ,
                              first_name ,
                              middle_init ,
                              last_name , 
	 --name_prefix, name_suffix, 
                              date_of_birth ,
                              member_ssn ,
                              oed ,
                              disable_flag ,
                              student_flag ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
								h_user ,
                              ext_id_type ,
                              new_ssn ,
                              source_id ,
                              paperless
                            )
                    VALUES  ( 0 ,
                              @s_alt_id ,
                              @s_member_code ,
                              @s_first_name ,
                              @s_middle_init ,
                              @s_last_name ,
	 --s_name_prefix, s_name_suffix,
                              CAST(@s_date_of_birth AS DATE) ,
                              @n_ext_id ,
                              CAST(@s_mb_gppl_eff AS DATE) ,
                              @s_disable_flag ,
                              @s_student_flag ,
                              'SA' ,
                              'SA' ,
                              @n_msi ,
                              @n_datetime ,
                              @a_user ,
                              @n_ext_id_type ,
                              @t_subnew_ssn ,
                              @t_subsrc_id ,
                              @s_paperless
                            );
	
                    SELECT  @s_dls_mb_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   h_msi = @n_msi;
     
                   
                    SET @s_dls_sub_id = @s_dls_mb_id;
					UPDATE GlobalVar SET VarValue = @s_dls_sub_id where VarName = 's_dls_sub_id' and  BatchId = @a_batch_id AND Module_Id = 2

                    UPDATE  dbo.member
                    SET     family_id = @s_dls_mb_id
                    WHERE   member_id = @s_dls_mb_id;
                    
                    IF @t_ext_id_col = 'member_id'
                        BEGIN
                          
                            SET @n_ext_id = @s_dls_mb_id;
                            UPDATE  dbo.member
                            SET     member_ssn = @n_ext_id
                            WHERE   member_id = @s_dls_mb_id;
                        END;
	
                    IF @a_has_address = 'Y'
                        BEGIN
                         
                            IF ( @s_zipx IS NULL
                                 OR @s_zipx = ''
                               )
                                OR LEN(@s_zipx) = 0
                                BEGIN
                                   
                                    SET @n_tmp_zip = @s_zip;
                                END;
                            ELSE
                                BEGIN
           
     SET @n_tmp_zip = @s_zip + @s_zipx;
                                END;
		
                           
                            EXECUTE @n_return_code = dbo.dlp_mbaddr @a_batch_id, @s_dls_sir_id,
                                @s_dls_mb_id, @s_address1, @s_address2,
 @s_city, @s_state, @n_tmp_zip, @s_home_phone,
                                @s_home_ext, @s_work_phone, @s_work_ext
                               
                            IF @n_return_code < 0
                                BEGIN
                                    SET @SWP_Ret_Value = @n_return_code;
                                    SET @SWP_Ret_Value1 = NULL;
                                    SET @SWP_Ret_Value2 = NULL;
                                    RETURN;
                                END;
		
                            SET @d_address_id = 0;
                            SELECT  @d_address_id = address_id
                            FROM    dbo.address (NOLOCK)
                            WHERE   subsys_code = 'MB'
                                    AND sys_rec_id = @s_dls_mb_id
                                    AND addr_type = 'L';
                            
		-- When all procedures calling dlp_mbaddr are modified then move code below to dlp_mbaddr
                        
              IF ( ( @s_email IS NOT NULL
                                   AND @s_email <> ''
                                 )
                                 AND LEN(@s_email) > 0
                               )
                                IF EXISTS ( SELECT  *
                                            FROM    dbo.mbr_phone (NOLOCK)
                                            WHERE   address_id = @d_address_id )
                                    UPDATE  dbo.mbr_phone
  SET     email = @s_email
                                    WHERE   address_id = @d_address_id;
			
                        END; 
-----------------------------------------------------------------------					 
		
                END;
            ELSE
                BEGIN
                    INSERT  INTO dbo.member
                            ( family_id ,
                              alt_id ,
                              member_code ,
                              first_name ,
                              middle_init ,
                              last_name , 
	 --name_prefix, name_suffix, 
                              date_of_birth ,
                              member_ssn ,
                              oed ,
                              disable_flag ,
                              student_flag ,
                              action_code ,
                              h_action ,
                              h_msi ,
                              h_datetime ,
                              h_user ,
                              ext_id_type ,
                              new_ssn ,
                              source_id ,
                              paperless
                            )
                    VALUES  ( @s_dls_sub_id ,
                              @s_alt_id ,
                              @s_member_code ,
                              @s_first_name ,
                              @s_middle_init ,
                              @s_last_name , 
	 --s_name_prefix, s_name_suffix, 
                              CAST(@s_date_of_birth AS DATE) ,
                              @n_ext_id ,
                              CAST(@s_mb_gppl_eff AS DATE) ,
                              @s_disable_flag ,
                              @s_student_flag ,
                              'DA' ,
                              'DA' ,
                              @n_msi ,
                              @n_datetime,
                              @a_user ,
                              @n_ext_id_type ,
                              @t_new_ssn ,
                              @t_src_id ,
                  @s_paperless
                 );
	
                    SELECT  @s_dls_mb_id = member_id
                    FROM    dbo.member (NOLOCK)
                    WHERE   h_msi = @n_msi;
                 
                
       IF @t_ext_id_col = 'member_id'
                        BEGIN
                           
                            SET @n_ext_id = @s_dls_mb_id;
                            UPDATE  dbo.member
                            SET     member_ssn = @n_ext_id
                            WHERE   member_id = @s_dls_mb_id;
                        END;
                END;


--trace off;

           
            SET @SWP_Ret_Value = @s_dls_mb_id;
            
            SET @SWP_Ret_Value1 = @n_msi;
            
            SET @SWP_Ret_Value2 = @n_datetime;
			
            RETURN;
        END TRY
        BEGIN CATCH

		If ERROR_NUMBER() = 50000
		BEGIN

		 SET @SWP_Ret_Value = -@error_code;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;

		END 
		ELSE
		BEGIN

            SET @SWP_Ret_Value = -200;
            SET @SWP_Ret_Value1 = NULL;
            SET @SWP_Ret_Value2 = NULL;
		END
           -- RETURN;
        END CATCH;
        SET NOCOUNT OFF;


--set debug file to "/tmp/tl_member.trc";
--trace on;

--LET n_msi = NULL;
--LET n_datetime = NULL;

   END;