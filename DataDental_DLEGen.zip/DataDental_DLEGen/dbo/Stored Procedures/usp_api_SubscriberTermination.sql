﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_api_SubscriberTermination]
	-- Add the parameters for the stored procedure here
@SubID INT,@PlanID INT,@GroupID INT,
@BatchID INT,@AsOfDate nvarchar(10),@ModName nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF OBJECT_ID('tempdb..#tmpSubInfo') IS NOT NULL
    DROP TABLE #tmpSubInfo

DECLARE @rlplfc_id INT=0;
DECLARE @Eff_Date DATE;
    -- Insert statements for procedure here
BEGIN TRY

   --SET @asDate=CONVERT(VARCHAR(10), @AsOfDate, 101)

	Select top 10*
	INTO #tmpSubInfo
		From member m
		Left Join [address] a On a.sys_rec_id=m.member_id
		Where a.subsys_code='MB' AND a.addr_type='L'
		AND m.member_id=@SubID 

		
---get sub planpPCPID

	Select @rlplfc_id=r.rlplfc_id,@Eff_Date=r.eff_date
		From rlplfc r
		join rlmbgrpl m on m.mb_gr_pl_id=r.mb_gr_pl_id
		Where m.group_id=@GroupID AND  m.plan_id=@PlanID
		AND m.member_id=@SubID AND r.mb_gr_pl_id >0
		order by rlplfc_id 	

	--SET @Eff_Date=CONVERT(VARCHAR(10), @Eff_Date, 101)
	
IF @ModName='Member Eligibility'	
BEGIN
  Insert into dls_elig
          (dls_batch_id, dls_sub_sir_id,
           member_flag, alt_id, ssn, sub_ssn, sub_alt_id, member_code,
           last_name, first_name, middle_init, date_of_birth,
           student_flag, disable_flag,address1, address2,
           city, state, zip, plan_eff_date,facility_eff_date, plan_term_date,
            dls_group_id, dls_plan_id, facility_id,
           def_key, type, dls_member_id, dls_sub_id,
           dls_status, dls_source, new_ssn, source_id, subnew_ssn,
           subsource_id,sub_in_plan,group_id,plan_id)

   Select @BatchID,0,'00',t.alt_id,t.member_ssn,t.member_ssn,t.alt_id,t.member_code,t.last_name,t.first_name,t.middle_init,	
	CONVERT(VARCHAR(10), t.date_of_birth, 101) as dob,t.student_flag,t.disable_flag,t.addr1,t.addr2,t.city,t.[state],t.zip,
	CONVERT(VARCHAR(10), @Eff_Date, 101) as mb_gppl_eff_date,CONVERT(VARCHAR(10) , @Eff_Date, 101) as mb_fc_eff_date,CONVERT(VARCHAR(10), @AsOfDate, 101) As AsofDate,
	@GroupID,
	@PlanID,@rlplfc_id, --needs to check the HMO option
	'AP','IS',@SubID,@SubID,'L' as [Status],'F' as [Source],t.new_ssn,t.source_id,t.new_ssn,t.source_id,0 as sub_in_plan,@GroupID as groupId,@PlanID as planId

	From #tmpSubInfo t

END
ELSE
BEGIN
	Insert into dls_sg_member  
		  (dls_batch_id,dls_sub_sir_id,member_flag,alt_id,ssn,sub_ssn,sub_alt_id, member_code,last_name,first_name,middle_init, 
		   date_of_birth,student_flag,disable_flag,--msg_group_id,
		   dls_group_id,plan_id,facility_id,mb_gppl_eff_date,mb_fc_eff_date,mb_term_date, 
           address1, address2,city,[state], zip,
		   dls_status,dls_source,new_ssn, source_id, subnew_ssn,subsource_id,sub_in_plan)
	
	Select @BatchID,0,'00',t.alt_id,t.member_ssn,t.member_ssn,t.alt_id,t.member_code,t.last_name,t.first_name,t.middle_init,	
	CONVERT(VARCHAR(10), t.date_of_birth, 101) as dob,t.student_flag,t.disable_flag,@GroupID,
	@PlanID,@rlplfc_id, --needs to check the HMO option
	CONVERT(VARCHAR(10), @Eff_Date, 101) as mb_gppl_eff_date,CONVERT(VARCHAR(10) , @Eff_Date, 101) as mb_fc_eff_date,CONVERT(VARCHAR(10), @AsOfDate, 101) As AsofDate,
	t.addr1,t.addr2,t.city,t.[state],t.zip,'L' as [Status],'F' as [Source],t.new_ssn,t.source_id,t.new_ssn,t.source_id,0 as sub_in_plan
	From #tmpSubInfo t
END

END TRY
BEGIN CATCH
THROW;
END CATCH

END