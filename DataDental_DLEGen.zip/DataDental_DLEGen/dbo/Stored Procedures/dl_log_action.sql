﻿CREATE PROCEDURE [dbo].[dl_log_action]
    @a_batch_id INT ,
    @a_sir_id INT ,
    @a_action_code CHAR(2) ,
    @a_as_of_date DATE
    
AS
    BEGIN
/*DD Upgrade Project::Cognizant - Migration of SP/Functions from Informix to SQL Server*/

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_descr VARCHAR(64);

        SET NOCOUNT ON;
        BEGIN TRY
	
		
            INSERT  INTO dbo.dl_action
                    ( batch_id ,
                      dls_sir_id ,
                      action_code ,
                      action_date ,
                      process_status
                    )
            VALUES  ( @a_batch_id ,
                      @a_sir_id ,
                      @a_action_code ,
                      @a_as_of_date ,
                      'N'
                    );
            RETURN 1;
        END TRY
        BEGIN CATCH
            SET @n_error_no = ERROR_NUMBER();
            SET @n_isam_error = ERROR_LINE();
            SET @n_error_descr = ERROR_MESSAGE();
            RETURN -1;
        END CATCH;
        SET NOCOUNT OFF;

    END;