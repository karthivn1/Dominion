﻿
-- =============================================
-- Author:		Uthayan.S
-- Create date: 12 June 2017
-- Description:	Get the Application Icons Enabled or Disabled based on Menu access
-- =============================================
--exec usp_home_getApplicationIcons 'nbaker',0,0,0,0
CREATE PROCEDURE [dbo].[usp_home_getApplicationIcons]
	-- Add the parameters for the stored procedure here
	@userCode varchar(15)=NULL,
	@dataDental bit OUTPUT,
	@dataLoad bit OUTPUT,
	@eClaim bit OUTPUT,
	@telStar bit OUTPUT
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here	
	Declare @userId int, @parentId int, @override int, @super Int, @acc smallint, @DD int,@DL int, @EC int,@TL int
	Declare @DLController varchar(50) = 'DataLoad',@ECController varchar(50) = 'Eclaim'

	SELECT @userId = usersl_id, @super = super, @override = ovr_ride, @parentId = parent_id  from user_tbl where ltrim(rtrim([user_tbl].user_id)) = @userCode
	SET @acc = 1;


IF OBJECT_ID('tempdb..##tempmenuwithnomenudef') IS NOT NULL
DROP TABLE #tempmenuwithnomenudef
	
	SELECT 
	@userId UserId,
	0 ModuleId,
	GETDATE() EffectiveDate,
	GETDATE() ExpirationDate,
	@acc Access,
	'' ModuleCode,		
	menudef.subsys_code SubSystemCode,
	'' MenuOption,		
	menudef.module Module,
	menudef.module_controller ModuleController,
	menudef.[sub_module] [SubModule],
	menudef.[action] Action,
	menudef.menu Menu,
	menudef.menu_description MenuDescription,
	menudef.menu_action MenuAction,
	menudef.submenu SubMenu,
	menudef.submenu_description SubMenuDescription,
	menudef.submenu_action SubMenuAction,	
	menudef.tab_name  TabName,	
	0 ActivityMasterId,
	'' ActivityReasonFlag,
	menudef.active_multiwindow IsActiveInMultiWindow into #tempmenuwithnomenudef		
	FROM menu_definition_new menudef 	
	WHERE  menudef.active=1 and menudef.mod_id=0 and menudef.menu_opt='' and menudef.subsys_code not in ('DL','TL','EL')

	SELECT @DD=COUNT(*) FROM (SELECT 
								@userId UserId,
								0 ModuleId,
								GETDATE() EffectiveDate,
								GETDATE() ExpirationDate,
								@acc Access,
								'' ModuleCode,		
								menudef.subsys_code SubSystemCode,
								'' MenuOption,		
								menudef.module Module,
								menudef.module_controller ModuleController,
								menudef.[sub_module] [SubModule],
								menudef.[action] Action,
								menudef.menu Menu,
								menudef.menu_description MenuDescription,
								menudef.menu_action MenuAction,
								menudef.submenu SubMenu,
								menudef.submenu_description SubMenuDescription,
								menudef.submenu_action SubMenuAction,	
								menudef.tab_name  TabName,	
								0 ActivityMasterId,
								'' ActivityReasonFlag	
								FROM menu_definition_new menudef 	
								WHERE  menudef.active=1 and menudef.mod_id=0 and menudef.menu_opt='' and menudef.subsys_code not in ('DL','TL','EL')) AS A

	IF(@super = 1)
	BEGIN
		SELECT @DD = COUNT(*) FROM (SELECT 
									[user].usersl_id UserId,
									modacc.mod_id ModuleId,
									GETDATE() EffectiveDate,
									NULL ExpirationDate,
									@acc Access,
									moddef.code ModuleCode,		
									moddef.subsys_code SubSystemCode,
									moddef.menu_opt MenuOption,		
									menudef.module Module,
									menudef.module_controller ModuleController,
									menudef.[sub_module] [SubModule],
									menudef.[action] Action,
									menudef.menu Menu,
									menudef.menu_description MenuDescription,
									menudef.menu_action MenuAction,
									menudef.submenu SubMenu,
									menudef.submenu_description SubMenuDescription,
									menudef.submenu_action SubMenuAction,
									menudef.tab_name  TabName,			
									actmast.act_mast_id ActivityMasterId,		
									(Case when actmast.reason_flag='Y' then 1 else 0 end) ActivityReasonFlag,
										menudef.active_multiwindow IsActiveInMultiWindow
								FROM user_tbl  [user] 
								INNER JOIN (select distinct mod_id, @userId as userid from mod_acc) modacc ON modacc.userid=[user].usersl_id
								INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
								INNER JOIN menu_definition_new menudef ON menudef.mod_id=moddef.mod_id and menudef.menu_opt=moddef.menu_opt and menudef.subsys_code not in ('DL','TL','EL')
								LEFT OUTER JOIN act_mast actmast ON actmast.mod_id=moddef.mod_id and actmast.activity_flag='Y'
								WHERE ltrim(rtrim([user].user_id)) = @userCode	
								AND menudef.active=1

								UNION

								select * from #tempmenuwithnomenudef) AS A
		
	END
	ELSE IF(@override = 1)
	BEGIN
			SELECT @DD=COUNT(*) FROM (SELECT 
			[user].usersl_id UserId,
			modacc.mod_id ModuleId,
			modacc.eff_date EffectiveDate,
			modacc.exp_date ExpirationDate,
			modacc.access Access,
			moddef.code ModuleCode,		
			moddef.subsys_code SubSystemCode,
			moddef.menu_opt MenuOption,		
			menudef.module Module,
			menudef.module_controller ModuleController,
			menudef.[sub_module] [SubModule],
			menudef.[action] Action,
			menudef.menu Menu,
			menudef.menu_description MenuDescription,
			menudef.menu_action MenuAction,
			menudef.submenu SubMenu,
			menudef.submenu_description SubMenuDescription,
			menudef.submenu_action SubMenuAction,
			menudef.tab_name  TabName,		
			actmast.act_mast_id ActivityMasterId,
			(Case when actmast.reason_flag='Y' then 1 else 0 end) ActivityReasonFlag,
				menudef.active_multiwindow IsActiveInMultiWindow
		FROM user_tbl  [user] 
		INNER JOIN  mod_acc modacc ON modacc.usersl_id=[user].usersl_id
		INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
		INNER JOIN menu_definition_new menudef ON menudef.mod_id=moddef.mod_id and menudef.menu_opt=moddef.menu_opt and menudef.subsys_code not in ('DL','TL','EL')
		LEFT OUTER JOIN act_mast actmast ON actmast.mod_id=moddef.mod_id and actmast.activity_flag='Y'
		WHERE	modacc.eff_date <=getdate() 
		AND modacc.type is NULL
		AND (modacc.exp_date >= getdate() OR modacc.exp_date IS NULL)
		AND ltrim(rtrim([user].user_id))=@userCode	
		and menudef.active=1
		union
		select * from #tempmenuwithnomenudef) AS B
	END
	ELSE
	BEGIN
		WITH 
				ModuleGroupAccess_CTE (modAccessId) AS  
				(  
					select 
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					 from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					 where usersl_id = @parentId and type = 'GP'
				),
				ModuleUserAccess_CTE (modAccessId) AS  
				(  
					select 
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					where usersl_id = @userId and type is null
				)  

				SELECT @DD=COUNT(*) FROM(SELECT 
					[user].usersl_id UserId,
					modaccJoin.modId ModuleId,
					modaccJoin.effDate EffectiveDate,
					modaccJoin.expDate ExpirationDate,
					modaccJoin.access Access,
					moddef.code ModuleCode,		
					moddef.subsys_code SubSystemCode,
					moddef.menu_opt MenuOption,			
					menudef.module Module,
					menudef.module_controller ModuleController,
					menudef.[sub_module] [SubModule],
					menudef.[action] Action,
					menudef.menu Menu,
					menudef.menu_description MenuDescription,
					menudef.menu_action MenuAction,
					menudef.submenu SubMenu,
					menudef.submenu_description SubMenuDescription,
					menudef.submenu_action SubMenuAction,	
					menudef.tab_name  TabName,		
					actmast.act_mast_id ActivityMasterId,
					(Case when actmast.reason_flag='Y' then 1 else 0 end) ActivityReasonFlag,
						menudef.active_multiwindow IsActiveInMultiWindow
					FROM user_tbl  [user] 
					INNER JOIN (SELECT @userId as userId, modacc.modacc_id as modaccId, modacc.mod_id as modId, modacc.eff_date as effDate, modacc.exp_date as expDate, modacc.access as access from mod_acc modacc
					INNER JOIN (SELECT modAccessId from ModuleGroupAccess_CTE UNION SELECT modAccessId FROM ModuleUserAccess_CTE) modAccCTE ON modAccCTE.modAccessId = modacc.modacc_id) modaccJoin ON modaccJoin.userId=[user].usersl_id
					INNER JOIN mod_def moddef ON moddef.mod_id=modaccJoin.modId
					INNER JOIN menu_definition_new menudef ON menudef.mod_id=moddef.mod_id and menudef.menu_opt = moddef.menu_opt and menudef.subsys_code not in ('DL','TL','EL')
					LEFT OUTER JOIN act_mast actmast ON actmast.mod_id=moddef.mod_id and actmast.activity_flag='Y'
					WHERE modaccJoin.effDate <=getdate()
					AND (modaccJoin.expDate>=getdate() OR modaccJoin.expDate IS NULL)
					AND ltrim(rtrim([user].user_id))=@userCode
					and menudef.active=1
					union
		select * from #tempmenuwithnomenudef) AS C
	END	
	
	---------------------DataLoad & Eclaim ---------------------------------
	SELECT 	@DL=COUNT(*)
		FROM   stc_user_group UG
		INNER JOIN mod_acc ModAcc on ModAcc.usersl_id = UG.group_id and ModAcc.[type]='DL'
		INNER JOIN mod_def ModDef ON ModAcc.mod_id = ModDef.mod_id
		INNER JOIN menu_definition_new MenuDef on MenuDef.mod_id = ModAcc.mod_id AND MenuDef.module_controller=@DLController
		WHERE UG.usersl_id=@userId	AND (UG.exp_date > GETDATE() OR UG.exp_date is null);

		--DECLARE @voyager_admin int,
		--			@voyager_view int,
		--			@voyager_admin_mod_id int,
		--			@mod_id int;

		--	SELECT @voyager_admin=groupsl_id FROM group_tbl WHERE group_id='Voyager Admin' and [type]='DL'
		--	SELECT @voyager_view=groupsl_id FROM group_tbl WHERE group_id='Voyager View' and [type]='DL'
		--	SELECT @voyager_admin_mod_id=mod_id FROM mod_acc WHERE usersl_id=@voyager_admin and [type]='DL'

		--	IF EXISTS(SELECT * FROM stc_user_group WHERE usersl_id=@userId AND group_id in (@voyager_admin,@voyager_view))
		--	BEGIN
		--			SET @mod_id = @voyager_admin_mod_id;
		--			SELECT 	@EC=COUNT(*)
		--					FROM   stc_user_group UG
		--					INNER JOIN mod_acc ModAcc on ModAcc.[type]='DL'
		--					INNER JOIN mod_def ModDef ON ModAcc.mod_id = ModDef.mod_id
		--					INNER JOIN menu_definition_new MenuDef on MenuDef.mod_id = ModAcc.mod_id AND MenuDef.module_controller=@ECController
		--					WHERE ModAcc.usersl_id IN (@voyager_admin,@voyager_view) AND MenuDef.mod_id=@mod_id AND UG.usersl_id=@userId AND (UG.exp_date > GETDATE() OR UG.exp_date is null) ;
		--	END
		--	ELSE
		--		BEGIN
		--			SET @EC=0;
		--		END;
			

			-------------------------E-Claim-----------------------------------------

			WITH 
				TLModuleGroupAccess_CTE (modId,modAccessId) AS  
				(  
					select moddef.mod_id modId,
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					 from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					 where usersl_id = @parentId and type = 'GP'
				),
				TLModuleUserAccess_CTE (modId,modAccessId) AS  
				(  
					select moddef.mod_id modId,
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					where usersl_id = @userId and type is null
				)  

		SELECT 	@EC=COUNT(*) 
			FROM menu_definition_new MenuDef				
			INNER JOIN (SELECT modId,modAccessId from TLModuleGroupAccess_CTE UNION SELECT modId,modAccessId FROM TLModuleUserAccess_CTE) modAccCTE ON modAccCTE.modId = MenuDef.mod_id
			INNER JOIN mod_acc ModAcc on modAccCTE.modAccessId = ModAcc.modacc_id --AND (ModAcc.exp_date >= getdate() OR ModAcc.exp_date IS NULL) AND ModAcc.eff_date <=getdate()
			INNER JOIN mod_def ModDef ON ModDef.mod_id = ModAcc.mod_id
			WHERE MenuDef.subsys_code='EL'	AND ModAcc.access = 1	;
		

	-------------------------TelStar-----------------------------------------

			WITH 
				TLModuleGroupAccess_CTE (modId,modAccessId) AS  
				(  
					select moddef.mod_id modId,
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetUserModAccess](@userId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					 from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					 where usersl_id = @parentId and type = 'GP'
				),
				TLModuleUserAccess_CTE (modId,modAccessId) AS  
				(  
					select moddef.mod_id modId,
					(Case	when modacc.access = 1 then modacc.modacc_id 
								when [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) = 0 then modacc.modacc_id
								else [dbo].[fn_GetGroupModAccess](@parentId, moddef.menu_opt, moddef.subsys_code) end) modAccessId
					from mod_acc modacc INNER JOIN mod_def moddef ON moddef.mod_id=modacc.mod_id
					where usersl_id = @userId and type is null
				)  

	SELECT 	@TL=COUNT(*) 
		FROM menu_definition_new MenuDef				
		INNER JOIN (SELECT modId,modAccessId from TLModuleGroupAccess_CTE UNION SELECT modId,modAccessId FROM TLModuleUserAccess_CTE) modAccCTE ON modAccCTE.modId = MenuDef.mod_id
		INNER JOIN mod_acc ModAcc on modAccCTE.modAccessId = ModAcc.modacc_id --AND (ModAcc.exp_date >= getdate() OR ModAcc.exp_date IS NULL) AND ModAcc.eff_date <=getdate()
		INNER JOIN mod_def ModDef ON ModDef.mod_id = ModAcc.mod_id
		WHERE MenuDef.subsys_code='TL'	AND ModAcc.access = 1	
			
	--SELECT CASE WHEN ISNULL(@DD,0)= 0 THEN 0 ELSE 1 END AS DD,
	--	   CASE WHEN ISNULL(@DL,0)= 0 THEN 0 ELSE 1 END AS DL,
	--	   CASE WHEN ISNULL(@EC,0)= 0 THEN 0 ELSE 1 END AS EC,
	--	   CASE WHEN ISNULL(@TL,0)= 0 THEN 0 ELSE 1 END AS TL		   

	SET @dataDental = CASE WHEN ISNULL(@DD,0)= 0 THEN 0 ELSE 1 END
	SET @dataLoad = CASE WHEN ISNULL(@DL,0)= 0 THEN 0 ELSE 1 END
	SET @eClaim = CASE WHEN ISNULL(@EC,0)= 0 THEN 0 ELSE 1 END
	SET @telStar = CASE WHEN ISNULL(@TL,0)= 0 THEN 0 ELSE 1 END
END