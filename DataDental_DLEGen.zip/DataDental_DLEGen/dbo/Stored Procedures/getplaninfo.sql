﻿CREATE PROCEDURE [dbo].[getplaninfo]
    @ID INT ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 VARCHAR(64) = NULL OUTPUT ,
    @SWP_Ret_Value2 CHAR(1) = NULL OUTPUT ,
    @SWP_Ret_Value3 CHAR(3) = NULL OUTPUT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 07:34:34 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @PlanName CHAR(64);
        DECLARE @InsType CHAR(1);
        DECLARE @PlanType CHAR(3);
        DECLARE @i_error_no INT;
        DECLARE @s_error_descr CHAR(64);
        DECLARE @s_err_rtn_text CHAR(64);
        DECLARE @i_isam_error INT;

 ---------------exception Handling ------------------------
        SET NOCOUNT ON;
        BEGIN TRY
            SET @PlanName = NULL;
            SELECT  @PlanName = plan_dsp_name ,
                    @InsType = ins_type ,
                    @PlanType = ins_opt
            FROM    dbo.[plan] (NOLOCK)
            WHERE   plan_id = @ID;
           
            IF ( @PlanName IS NULL
                 OR @PlanName = ''
               )
                BEGIN
                    SET @SWP_Ret_Value = -1;
                    SET @SWP_Ret_Value1 = '';
                    SET @SWP_Ret_Value2 = '';
                    SET @SWP_Ret_Value3 = '';
                    RETURN;
                END;
            ELSE
                BEGIN
                    SET @SWP_Ret_Value = 1;
                    SET @SWP_Ret_Value1 = @PlanName;
                    SET @SWP_Ret_Value2 = @InsType;
                    SET @SWP_Ret_Value3 = @PlanType;
                    RETURN;
                END;
        END TRY
        BEGIN CATCH
            SET @i_error_no = ERROR_NUMBER();
            SET @i_isam_error = ERROR_LINE();
            SET @s_error_descr = ERROR_MESSAGE();
            SET @s_err_rtn_text = CONCAT('DB Error: ', @i_error_no,
                                         ' Error msg: ', @s_error_descr);
            SET @SWP_Ret_Value = -1;
            SET @SWP_Ret_Value1 = @s_err_rtn_text;
            SET @SWP_Ret_Value2 = '';
            SET @SWP_Ret_Value3 = '';
            RETURN;
        END CATCH;
        SET NOCOUNT OFF;

----------------------------------------------------------

    END;