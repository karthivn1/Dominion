﻿CREATE PROCEDURE [dbo].[ip_dls_pv_assoc] @i_dls_sir_id INT
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1

000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @new_dls_sir_id int;
        SET NOCOUNT ON;
        SET @new_dls_sir_id = 0
      
        SET @new_dls_sir_id = @i_dls_sir_id
      
        SET NOCOUNT OFF;

    END;