﻿CREATE PROCEDURE [dbo].[ip_dl_sys_opt]
    @a_sys_id INT ,
    @a_opt_type CHAR(2)
    
AS
    BEGIN
/*
-- This procedure was converted on Fri Aug 19 02:27:27 2016 using Ispirer SQLWays 7.0 Build 3392 32bit Licensed to Dominion Dental - Andrew Michael - US (Professiona Project License, Ispirer MnMTK 2015 Informix to MSSQLServer Database Migration, 300 GB, 1



000 Tables, 104000 LOC, 5 Data and 12 SQL Support Requests, 6 Months, 20161022).
*/
        DECLARE @curr_time VARCHAR(23);
        DECLARE @curr_time1 VARCHAR(23);
        DECLARE @curr_time2 VARCHAR(23);

        SET NOCOUNT ON;
        SET @curr_time = GETDATE();
        SET @curr_time1 = SUBSTRING(@curr_time, 12, 11);
        SET @curr_time2 = CONVERT(VARCHAR, CONVERT(DATE, GETDATE())) + ' '
            + @curr_time1;

        IF @a_opt_type != 'BT'
            BEGIN
                INSERT  INTO dbo.stc_sys_opt
                        ( sys_opt_type ,
                          sys_id ,
                          sys_access_type ,
                          created_by ,
                          created_time
                        )
                VALUES  ( @a_opt_type ,
                          @a_sys_id ,
                          'RD' ,
                          SYSTEM_USER ,
                          @curr_time2
                        );
 	  
                INSERT  INTO dbo.stc_sys_opt
                        ( sys_opt_type ,
                          sys_id ,
                          sys_access_type ,
                          created_by ,
                          created_time
                        )
                VALUES  ( @a_opt_type ,
                          @a_sys_id ,
                          'AD' ,
                          SYSTEM_USER ,
                          @curr_time2
                        );
            END;
	
        INSERT  INTO dbo.stc_sys_opt
                ( sys_opt_type ,
                  sys_id ,
                  sys_access_type ,
                  created_by ,
                  created_time
                )
        VALUES  ( @a_opt_type ,
                  @a_sys_id ,
                  'ED' ,
                  SYSTEM_USER ,
                  @curr_time2
                );
	
        INSERT  INTO dbo.stc_sys_opt
                ( sys_opt_type ,
                  sys_id ,
                  sys_access_type ,
                  created_by ,
                  created_time
                )
        VALUES  ( @a_opt_type ,
                  @a_sys_id ,
                  'FC' ,
                  SYSTEM_USER,
                  @curr_time2
                );
        SET NOCOUNT OFF;

    END;