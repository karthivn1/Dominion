﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
--EXEC usp_api_CreateBatchForClaimUpdate 'SG Member','Elig-API-SG','12/14/2016 12:00:00 AM'
-- =============================================
CREATE PROC [dbo].[usp_api_CreateBatchForClaimUpdate] 
@Mod nVarchar(18),@CfgName nvarchar(50),@AsOfDate Date,@user nVarchar(15),
@ID INT=0,@cfg_bat_det_ID int=0,@cfg_bat_param_ID INT=0
AS
BEGIN

IF OBJECT_ID('tempdb..#tempErrorTable') IS NOT NULL
    DROP TABLE #tempErrorTable

IF OBJECT_ID('tempdb..#tempClaim') IS NOT NULL
    DROP TABLE #tempClaim

DECLARE @ErrorMsg nVarchar(1000)='';
--Create table #tempErrorTable(ID int identity(1,1),ErrorName nvarchar(50),ErrorDesc nvarchar(1000))	
--IF Exists(
--select d.config_id,  
--		 d.module_id ,  
--		 d.config_name ,  
--		 d.config_descr ,  
--		 d.job_def_id ,  
--		 d.config_contact_ln ,  
--		 d.config_contact_fn ,  
--		 d.config_contact_pho ,  
--		 d.config_cont_ph_ext ,  
--		 d.config_cont_email ,  
--		 d.config_status ,   
--		 d.created_by ,  
--		 d.created_time From dl_config d
--		 Join dl_module m on m.module_id=d.module_id
--		  where config_name =@CfgName AND m.module_name=@Mod)

--BEGIN
DECLARE @Config_bat_ID INT=0;
DECLARE @BatchID INT=0
DECLARE @Bat_det_id INT=0
DECLARE @Bat_param_id INT=0
BEGIN TRY

select d.config_id,  
		 d.module_id ,  
		 d.config_name ,  
		 d.config_descr ,  
		 d.job_def_id ,  
		 d.config_contact_ln ,  
		 d.config_contact_fn ,  
		 d.config_contact_pho ,  
		 d.config_cont_ph_ext ,  
		 d.config_cont_email ,  
		 d.config_status ,   
		 d.created_by ,  
		 d.created_time,si.sir_def_id INTO #tempConfig  From dl_config d
		 Join dl_module m on m.module_id=d.module_id
		 left Join dl_sir_def si on si.module_id=m.module_id
		 where config_name =@CfgName AND m.module_name=@Mod

--END

--Select *From #tempConfig

--Get Param
--select p.config_param_id,  
--		 p.config_id ,  
--		 p.sp_param_id ,  
--		 p.config_param_value ,  
--		 p.created_by ,  
--		 p.created_time From  dl_config_param p
--		 Join #tempConfig t on t.config_id=p.config_id

--get Detail

IF NOT EXISTS(Select *From #tempConfig)
BEGIN
  SET @ErrorMsg='Unable to get Configuration from Database for ConfigName:' + @CfgName;
  THROW 500,@ErrorMsg,1
END

select DISTINCT 
		 d.config_job_det_id,  
		 d.config_id ,  
		 d.sp_id ,  
		 d.tolerance , 
		 t.sir_def_id, 
		 d.created_by ,  
		 d.created_time,'N' as Status INTO #tempBatchDetail From dl_config_job_det d
		 Join #tempConfig t on t.config_id=d.config_id
		 Where d.config_id>0

select DISTINCT  
		p.sp_param_id ,p.config_param_value,  
		IIF(SUBSTRING(p.config_param_value,0,7)='$today',FORMAT(@AsOfDate , 'MM/dd/yyyy'),p.config_param_value) AS Value
		INTO #tempParam From  dl_config_param p
		Join #tempConfig t on t.config_id=p.config_id 

IF @Mod='Member Eligibility'
BEGIN
--load default param
Select t.sp_param_id,t.config_param_value,
CASE 
 WHEN d.param_name='create ssn' Then 'N'
 WHEN d.param_name='New Member w/ FC' Then 'N'
 WHEN d.param_name='Has Rate Code' Then 'N'
 WHEN d.param_name='SSN/ALT' Then 'Z'
 WHEN d.param_name='Has Facility ID' Then 'Y'
 WHEN d.param_name='Has FC Effective' Then 'Y'
 WHEN d.param_name='Has Address' Then 'Y'
 WHEN d.param_name='Has Plan Effective' Then 'Y'
 WHEN d.param_name='Sub Plan Term' Then 'Y'
 WHEN d.param_name='Dep Plan Term' Then 'Y'
 WHEN d.param_name='multi group plan'  Then 'Y'
 END AS Value
From #tempParam t
JOIN dl_sp_param d ON d.sp_param_id=t.sp_param_id

--Unable to get default parm info from Database for ID:
END
IF @ID>0
BEGIN

---batch update needs to be check
--Select *
Update d Set created_time = FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:00'),created_by = @user
	 From dl_config_bat d
	 Where d.config_bat_id=@ID

SET @BatchID=@ID;

END
Else 
BEGIN

Insert into dl_config_bat (config_id, config_bat_status, created_by, created_time) 
Select DISTINCT t.config_id,t.Status,@user,FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:00') From #tempBatchDetail t
Select @BatchID=SCOPE_IDENTITY();

END
IF @cfg_bat_det_ID=0 AND @BatchID>0
BEGIN

--insert
Insert into dl_cfg_bat_det (config_bat_id,sp_id,sir_def,cfg_bat_det_toler,cfg_bat_det_stat,created_by,created_time)
select DISTINCT @BatchID,t.sp_id,t.sir_def_id,t.tolerance,t.Status,@user, FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:00') FROM #tempBatchDetail t

--Select @Bat_det_id=SCOPE_IDENTITY();
		
END
ELSE IF @cfg_bat_det_ID>0 AND @BatchID>0
BEGIN
--Update
--Select *
Update d Set created_time = FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:00'),created_by = @user,config_bat_id=@BatchID
	 From  dl_cfg_bat_det  d
	 Where d.cfg_bat_det_id=@cfg_bat_det_ID

--SET @Bat_det_id=@cfg_bat_det_ID

END

IF @cfg_bat_param_ID=0 AND @BatchID>0
BEGIN

--insert
Insert into dl_cfg_bat_param  (config_bat_id, sp_param_id, param_value, created_by, created_time )
select DISTINCT @BatchID,t.sp_param_id,t.Value,@user, FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:00') From #tempParam t

--Select @Bat_param_id=SCOPE_IDENTITY();
		
END
ELSE IF @cfg_bat_det_ID>0 AND @BatchID>0
BEGIN
--Update
--Select *
Update d Set created_time = FORMAT(GETDATE() , 'MM/dd/yyyy HH:mm:ss:00'),created_by = @user,config_bat_id=@BatchID
	 From  dl_cfg_bat_param  d
	 Where d.cfg_bat_param_id=@cfg_bat_det_ID

--SET @Bat_det_id=@cfg_bat_det_ID

END

RETURN @BatchID;
--Select @BatchID

END TRY
BEGIN CATCH
THROW;
END CATCH
END