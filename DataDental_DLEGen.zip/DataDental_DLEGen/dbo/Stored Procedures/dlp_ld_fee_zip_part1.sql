﻿CREATE PROCEDURE [dbo].[dlp_ld_fee_zip_part1]
    @a_batch_id INT ,
    @a_db_name CHAR(128) ,
    @a_start_time VARCHAR(22) ,
    @SWP_Ret_Value INT = NULL OUTPUT ,
    @SWP_Ret_Value1 CHAR(64) = NULL OUTPUT
    

  
------------------------------------------------------------------------------
--
--            Procedure:   dlp_ld_fee_zip
--
--            Created:     06/05/1999 
--            Author:      Ameeta Mahendra 
--
-- Purpose:  This SP performs the loading of flat file records into an SIR
--           ZIP table to process fee schedule for the DataLoad Product of STC
--
--
-- Modification History:
--
--   DATE       AUTHOR       DETAILS
--
-------------------------------------------------------------------------------



   -- manually remove rows loaded by LOAD, they can not be rolled back
AS
    BEGIN

        DECLARE @n_error_no INT;
        DECLARE @n_isam_error INT;
        DECLARE @n_error_text CHAR(64);
        DECLARE @n_rtn_text VARCHAR(64);
        DECLARE @n_err_rtn_text VARCHAR(64);

        DECLARE @n_system_cmd CHAR(1024);
        DECLARE @n_sys_cmd1 CHAR(200);
        DECLARE @n_sys_cmd2 CHAR(200);
        DECLARE @n_sys_cmd3 CHAR(200);
        DECLARE @n_load_file CHAR(128);
        DECLARE @n_tmp_file CHAR(64);
        DECLARE @n_date_str VARCHAR(10);
        DECLARE @n_sir_count INT;
        DECLARE @i_ld_exist INT;
        DECLARE @n_pre_file CHAR(64);
        DECLARE @i_file_count INT;
        DECLARE @s_suffix CHAR(2);
        DECLARE @n_prefix_load VARCHAR(64);
        DECLARE @min_sir INT;
        DECLARE @max_sir INT;
        DECLARE @i_record_count INT;
        DECLARE @i_delete_count INT;
        DECLARE @i_no_load_record INT;

        DECLARE @i_sp_id INT;
        DECLARE @i_sir_def_id INT;
        DECLARE @i_cfg_bat_det_id INT;
        DECLARE @i_sir_id INT;
        DECLARE @i_statistics_id INT;
        DECLARE @i_temp INT;
        DECLARE @SWV_RaiseMsg VARCHAR(400);
        DECLARE @SWV_dl_upd_statistics INT;
		DECLARE @created_by CHAR(15)
-----exception handling----------------------------------------------
---------------------------------------------------------------------

        SET NOCOUNT ON;
        
            
            SET @i_no_load_record = 1000;
            SET @i_statistics_id = NULL;
            EXECUTE @i_sp_id = dbo.dl_get_sp_id @a_batch_id, 'ld_fee_zip';
            IF @i_sp_id = -1
			BEGIN
                RAISERROR('~Could not retrieve valid Store Procedure ID~',16,1);
				RETURN
			END

            SET @i_sir_def_id = dbo.dl_get_sir_def_id('fee_zip');
            IF @i_sir_def_id = -1
			BEGIN
                RAISERROR('~Could not retrieve valid SIR Table ID~',16,1);
				RETURN
			END

            SET @n_load_file = dbo.dl_get_param_value(@a_batch_id, @i_sp_id,
                                                      'File Name');
            IF ( @n_load_file IS NULL
                 OR @n_load_file = ''
               )
                OR LEN(@n_load_file) = 0
                BEGIN
                    SET @SWV_RaiseMsg = CONCAT('~No data file specified for ',
                                              CAST(@a_batch_id AS VARCHAR(20)),'~');
                    RAISERROR(@SWV_RaiseMsg,16,1);
					RETURN
			END;

            SET @i_ld_exist = dbo.dl_dlp_status(@a_batch_id, @i_sir_def_id,
                                                @i_sp_id, 'LD');
            IF @i_ld_exist = 1
                BEGIN
                    SET @SWV_RaiseMsg = CONCAT('~You only need to load FEE_SCHEDULE data once for batch ',
                                               CAST(@a_batch_id AS VARCHAR(20)),'~');
                    RAISERROR(@SWV_RaiseMsg,16,1);
					RETURN
                END;



            SELECT  @i_cfg_bat_det_id = cfg_bat_det_id
            FROM    dbo.dl_cfg_bat_det (NOLOCK)
            WHERE   config_bat_id = @a_batch_id
                    AND sp_id = @i_sp_id;

					SELECT @created_by = created_by FROM dl_config_bat (NOLOCK) WHERE config_bat_id = @a_batch_id
          
            INSERT  INTO dbo.dl_bat_statistics
                    ( cfg_bat_det_id ,
                      start_time ,
                      finish_time ,
                      tot_record ,
                      tot_success_rec ,
                      tot_fail_rec ,
                      created_by ,
                      created_time
                    )
            VALUES  ( @i_cfg_bat_det_id ,
                      @a_start_time ,
                      NULL ,
                      NULL ,
                      NULL ,
                      NULL ,
                      --ORIGINAL_LOGIN() ,
					  @created_by,
                      @a_start_time
                    );
	
                 
            UPDATE  dbo.dl_config_bat
            SET     config_bat_status = 'I'
            WHERE   config_bat_id = @a_batch_id;

			SELECT LTRIM(RTRIM(@n_load_file)) 'LoadFile'
           
         SET NOCOUNT OFF;

    END;