﻿CREATE SYNONYM [dbo].[net_cap] FOR [dds_prod].[dbo].[net_cap];

