﻿CREATE SYNONYM [dbo].[fc_mass_xfer] FOR [dds_prod].[dbo].[fc_mass_xfer];

