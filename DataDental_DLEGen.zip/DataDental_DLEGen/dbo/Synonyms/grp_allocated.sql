﻿CREATE SYNONYM [dbo].[grp_allocated] FOR [dds_prod].[dbo].[grp_allocated];

