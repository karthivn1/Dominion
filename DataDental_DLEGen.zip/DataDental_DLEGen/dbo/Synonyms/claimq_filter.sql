﻿CREATE SYNONYM [dbo].[claimq_filter] FOR [dds_prod].[dbo].[claimq_filter];

