﻿CREATE SYNONYM [dbo].[al_ipayh] FOR [dds_prod].[dbo].[al_ipayh];

