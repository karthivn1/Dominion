﻿CREATE SYNONYM [dbo].[fc_pro_detail] FOR [dds_prod].[dbo].[fc_pro_detail];

