﻿CREATE SYNONYM [dbo].[gppl_benefit] FOR [dds_prod].[dbo].[gppl_benefit];

