﻿CREATE SYNONYM [dbo].[bl_pl_mb_dtl] FOR [dds_prod].[dbo].[bl_pl_mb_dtl];

