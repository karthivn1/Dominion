﻿CREATE SYNONYM [dbo].[lp_commands] FOR [dds_prod].[dbo].[lp_commands];

