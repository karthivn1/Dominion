﻿CREATE SYNONYM [dbo].[bill_adj] FOR [dds_prod].[dbo].[bill_adj];

