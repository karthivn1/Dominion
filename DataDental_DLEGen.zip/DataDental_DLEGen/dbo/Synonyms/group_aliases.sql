﻿CREATE SYNONYM [dbo].[group_aliases] FOR [dds_prod].[dbo].[group_aliases];

