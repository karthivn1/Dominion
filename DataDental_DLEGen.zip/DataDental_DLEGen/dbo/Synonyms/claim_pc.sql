﻿CREATE SYNONYM [dbo].[claim_pc] FOR [dds_prod].[dbo].[claim_pc];

