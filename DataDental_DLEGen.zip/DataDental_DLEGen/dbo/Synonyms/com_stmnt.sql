﻿CREATE SYNONYM [dbo].[com_stmnt] FOR [dds_prod].[dbo].[com_stmnt];

