﻿CREATE SYNONYM [dbo].[mod_def] FOR [dds_prod].[dbo].[mod_def];

