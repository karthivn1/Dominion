﻿CREATE SYNONYM [dbo].[notes] FOR [dds_prod].[dbo].[notes];

