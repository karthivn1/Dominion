﻿CREATE SYNONYM [dbo].[cap_adj] FOR [dds_prod].[dbo].[cap_adj];

