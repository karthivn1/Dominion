﻿CREATE SYNONYM [dbo].[follow] FOR [dds_prod].[dbo].[follow];

