﻿CREATE SYNONYM [dbo].[bilctld] FOR [dds_prod].[dbo].[bilctld];

