﻿CREATE SYNONYM [dbo].[issues] FOR [dds_prod].[dbo].[issues];

