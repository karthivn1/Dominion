﻿CREATE SYNONYM [dbo].[fc_lvl_adj] FOR [dds_prod].[dbo].[fc_lvl_adj];

