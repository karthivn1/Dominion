﻿CREATE SYNONYM [dbo].[cap_hist] FOR [dds_prod].[dbo].[cap_hist];

