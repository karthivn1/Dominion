﻿CREATE SYNONYM [dbo].[benefit_rule_disp] FOR [dds_prod].[dbo].[benefit_rule_disp];

