﻿CREATE SYNONYM [dbo].[cap_rate] FOR [dds_prod].[dbo].[cap_rate];

