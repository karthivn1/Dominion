﻿CREATE SYNONYM [dbo].[batch_process_details] FOR [dds_prod].[dbo].[batch_process_details];

