﻿CREATE SYNONYM [dbo].[batch_event_master] FOR [dds_prod].[dbo].[batch_event_master];

