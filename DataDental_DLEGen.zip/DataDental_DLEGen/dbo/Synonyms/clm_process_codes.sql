﻿CREATE SYNONYM [dbo].[clm_process_codes] FOR [dds_prod].[dbo].[clm_process_codes];

