﻿CREATE SYNONYM [dbo].[cob] FOR [dds_prod].[dbo].[cob];

