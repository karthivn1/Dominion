﻿CREATE SYNONYM [dbo].[desig_det] FOR [dds_prod].[dbo].[desig_det];

