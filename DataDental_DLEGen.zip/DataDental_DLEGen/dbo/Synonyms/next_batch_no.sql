﻿CREATE SYNONYM [dbo].[next_batch_no] FOR [dds_prod].[dbo].[next_batch_no];

