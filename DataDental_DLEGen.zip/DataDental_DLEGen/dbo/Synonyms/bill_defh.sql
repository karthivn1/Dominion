﻿CREATE SYNONYM [dbo].[bill_defh] FOR [dds_prod].[dbo].[bill_defh];

