﻿CREATE SYNONYM [dbo].[check_vendor] FOR [dds_prod].[dbo].[check_vendor];

