﻿CREATE SYNONYM [dbo].[bill] FOR [dds_prod].[dbo].[bill];

