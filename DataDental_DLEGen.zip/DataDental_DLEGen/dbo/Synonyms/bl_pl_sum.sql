﻿CREATE SYNONYM [dbo].[bl_pl_sum] FOR [dds_prod].[dbo].[bl_pl_sum];

