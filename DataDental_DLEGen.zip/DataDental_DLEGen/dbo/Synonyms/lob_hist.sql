﻿CREATE SYNONYM [dbo].[lob_hist] FOR [dds_prod].[dbo].[lob_hist];

