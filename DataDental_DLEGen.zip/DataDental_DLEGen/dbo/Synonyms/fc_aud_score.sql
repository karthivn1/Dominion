﻿CREATE SYNONYM [dbo].[fc_aud_score] FOR [dds_prod].[dbo].[fc_aud_score];

