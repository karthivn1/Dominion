﻿CREATE SYNONYM [dbo].[menu_definition_new] FOR [dds_prod].[dbo].[menu_definition_new];

