﻿CREATE SYNONYM [dbo].[admin_disb] FOR [dds_prod].[dbo].[admin_disb];

