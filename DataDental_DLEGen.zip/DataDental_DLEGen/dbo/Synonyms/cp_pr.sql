﻿CREATE SYNONYM [dbo].[cp_pr] FOR [dds_prod].[dbo].[cp_pr];

