﻿CREATE SYNONYM [dbo].[fc_audit_d] FOR [dds_prod].[dbo].[fc_audit_d];

