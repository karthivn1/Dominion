﻿CREATE SYNONYM [dbo].[eop_adj] FOR [dds_prod].[dbo].[eop_adj];

