﻿CREATE SYNONYM [dbo].[al_batch_dupl] FOR [dds_prod].[dbo].[al_batch_dupl];

