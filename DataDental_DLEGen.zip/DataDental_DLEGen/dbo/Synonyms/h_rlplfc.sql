﻿CREATE SYNONYM [dbo].[h_rlplfc] FOR [dds_prod].[dbo].[h_rlplfc];

