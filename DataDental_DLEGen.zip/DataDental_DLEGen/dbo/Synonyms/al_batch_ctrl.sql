﻿CREATE SYNONYM [dbo].[al_batch_ctrl] FOR [dds_prod].[dbo].[al_batch_ctrl];

