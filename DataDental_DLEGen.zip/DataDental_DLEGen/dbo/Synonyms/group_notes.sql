﻿CREATE SYNONYM [dbo].[group_notes] FOR [dds_prod].[dbo].[group_notes];

