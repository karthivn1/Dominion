﻿CREATE SYNONYM [dbo].[area_desc] FOR [dds_prod].[dbo].[area_desc];

