﻿CREATE SYNONYM [dbo].[bill_defd] FOR [dds_prod].[dbo].[bill_defd];

