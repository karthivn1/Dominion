﻿CREATE SYNONYM [dbo].[comm_scheme] FOR [dds_prod].[dbo].[comm_scheme];

