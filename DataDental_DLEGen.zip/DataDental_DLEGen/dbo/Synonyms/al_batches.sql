﻿CREATE SYNONYM [dbo].[al_batches] FOR [dds_prod].[dbo].[al_batches];

