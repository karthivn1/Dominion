﻿CREATE SYNONYM [dbo].[fc_staff] FOR [dds_prod].[dbo].[fc_staff];

