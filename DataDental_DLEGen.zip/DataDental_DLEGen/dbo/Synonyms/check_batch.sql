﻿CREATE SYNONYM [dbo].[check_batch] FOR [dds_prod].[dbo].[check_batch];

