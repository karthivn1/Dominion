﻿CREATE SYNONYM [dbo].[griev_activity] FOR [dds_prod].[dbo].[griev_activity];

