﻿CREATE SYNONYM [dbo].[fc_contract_types] FOR [dds_prod].[dbo].[fc_contract_types];

