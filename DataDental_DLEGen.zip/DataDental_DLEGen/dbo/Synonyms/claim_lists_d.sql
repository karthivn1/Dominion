﻿CREATE SYNONYM [dbo].[claim_lists_d] FOR [dds_prod].[dbo].[claim_lists_d];

