﻿CREATE SYNONYM [dbo].[net_facility] FOR [dds_prod].[dbo].[net_facility];

