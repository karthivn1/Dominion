﻿CREATE SYNONYM [dbo].[fc_certified] FOR [dds_prod].[dbo].[fc_certified];

