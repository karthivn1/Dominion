﻿CREATE SYNONYM [dbo].[mod_acc] FOR [dds_prod].[dbo].[mod_acc];

