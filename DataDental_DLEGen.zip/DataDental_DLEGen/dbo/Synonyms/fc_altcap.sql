﻿CREATE SYNONYM [dbo].[fc_altcap] FOR [dds_prod].[dbo].[fc_altcap];

