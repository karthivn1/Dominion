﻿CREATE SYNONYM [dbo].[net_plans] FOR [dds_prod].[dbo].[net_plans];

