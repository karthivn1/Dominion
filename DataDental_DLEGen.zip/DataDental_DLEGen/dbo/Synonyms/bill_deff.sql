﻿CREATE SYNONYM [dbo].[bill_deff] FOR [dds_prod].[dbo].[bill_deff];

