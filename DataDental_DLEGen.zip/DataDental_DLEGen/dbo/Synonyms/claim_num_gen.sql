﻿CREATE SYNONYM [dbo].[claim_num_gen] FOR [dds_prod].[dbo].[claim_num_gen];

