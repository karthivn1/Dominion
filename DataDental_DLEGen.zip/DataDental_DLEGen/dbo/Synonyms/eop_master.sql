﻿CREATE SYNONYM [dbo].[eop_master] FOR [dds_prod].[dbo].[eop_master];

