﻿CREATE SYNONYM [dbo].[gppl_cat] FOR [dds_prod].[dbo].[gppl_cat];

