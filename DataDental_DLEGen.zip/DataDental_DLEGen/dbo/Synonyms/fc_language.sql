﻿CREATE SYNONYM [dbo].[fc_language] FOR [dds_prod].[dbo].[fc_language];

