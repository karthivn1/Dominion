﻿CREATE SYNONYM [dbo].[group_cap_rate] FOR [dds_prod].[dbo].[group_cap_rate];

