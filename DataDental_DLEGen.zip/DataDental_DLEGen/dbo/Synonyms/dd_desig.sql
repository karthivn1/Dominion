﻿CREATE SYNONYM [dbo].[dd_desig] FOR [dds_prod].[dbo].[dd_desig];

