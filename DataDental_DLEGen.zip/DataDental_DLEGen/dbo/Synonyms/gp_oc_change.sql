﻿CREATE SYNONYM [dbo].[gp_oc_change] FOR [dds_prod].[dbo].[gp_oc_change];

