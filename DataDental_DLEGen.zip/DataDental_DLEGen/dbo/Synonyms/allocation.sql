﻿CREATE SYNONYM [dbo].[allocation] FOR [dds_prod].[dbo].[allocation];

