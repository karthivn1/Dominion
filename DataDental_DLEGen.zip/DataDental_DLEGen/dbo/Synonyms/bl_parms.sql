﻿CREATE SYNONYM [dbo].[bl_parms] FOR [dds_prod].[dbo].[bl_parms];

