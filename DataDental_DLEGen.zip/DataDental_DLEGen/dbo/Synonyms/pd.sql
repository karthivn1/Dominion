﻿CREATE SYNONYM [dbo].[pd] FOR [dds_prod].[dbo].[pd];

