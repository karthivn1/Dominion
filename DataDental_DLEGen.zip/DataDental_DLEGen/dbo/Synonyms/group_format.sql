﻿CREATE SYNONYM [dbo].[group_format] FOR [dds_prod].[dbo].[group_format];

