﻿CREATE SYNONYM [dbo].[al_defaults] FOR [dds_prod].[dbo].[al_defaults];

