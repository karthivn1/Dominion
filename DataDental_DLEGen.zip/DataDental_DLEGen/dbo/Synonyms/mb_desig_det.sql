﻿CREATE SYNONYM [dbo].[mb_desig_det] FOR [dds_prod].[dbo].[mb_desig_det];

