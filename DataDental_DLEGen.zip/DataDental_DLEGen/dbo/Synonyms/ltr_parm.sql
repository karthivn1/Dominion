﻿CREATE SYNONYM [dbo].[ltr_parm] FOR [dds_prod].[dbo].[ltr_parm];

