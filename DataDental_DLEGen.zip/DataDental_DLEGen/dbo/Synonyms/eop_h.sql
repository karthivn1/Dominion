﻿CREATE SYNONYM [dbo].[eop_h] FOR [dds_prod].[dbo].[eop_h];

