﻿CREATE SYNONYM [dbo].[fc_roster] FOR [dds_prod].[dbo].[fc_roster];

