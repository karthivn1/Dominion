﻿CREATE SYNONYM [dbo].[pdafck] FOR [dds_prod].[dbo].[pdafck];

