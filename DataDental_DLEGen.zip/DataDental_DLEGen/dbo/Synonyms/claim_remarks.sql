﻿CREATE SYNONYM [dbo].[claim_remarks] FOR [dds_prod].[dbo].[claim_remarks];

