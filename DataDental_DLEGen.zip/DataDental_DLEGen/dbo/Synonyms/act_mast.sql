﻿CREATE SYNONYM [dbo].[act_mast] FOR [dds_prod].[dbo].[act_mast];

