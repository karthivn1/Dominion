﻿CREATE SYNONYM [dbo].[group_pdcomm] FOR [dds_prod].[dbo].[group_pdcomm];

