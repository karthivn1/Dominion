﻿CREATE SYNONYM [dbo].[next_batch_no2] FOR [dds_prod].[dbo].[next_batch_no2];

