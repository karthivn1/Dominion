﻿CREATE SYNONYM [dbo].[member] FOR [dds_prod].[dbo].[member];

