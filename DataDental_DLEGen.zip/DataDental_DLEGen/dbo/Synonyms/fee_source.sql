﻿CREATE SYNONYM [dbo].[fee_source] FOR [dds_prod].[dbo].[fee_source];

