﻿CREATE SYNONYM [dbo].[al_pointer] FOR [dds_prod].[dbo].[al_pointer];

