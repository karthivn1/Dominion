﻿CREATE SYNONYM [dbo].[grad_comm_time] FOR [dds_prod].[dbo].[grad_comm_time];

