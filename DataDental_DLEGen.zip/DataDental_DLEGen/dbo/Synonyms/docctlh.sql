﻿CREATE SYNONYM [dbo].[docctlh] FOR [dds_prod].[dbo].[docctlh];

