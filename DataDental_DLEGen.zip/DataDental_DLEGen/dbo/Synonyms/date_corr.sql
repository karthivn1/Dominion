﻿CREATE SYNONYM [dbo].[date_corr] FOR [dds_prod].[dbo].[date_corr];

