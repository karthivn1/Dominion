﻿CREATE SYNONYM [dbo].[annual_proc_err] FOR [dds_prod].[dbo].[annual_proc_err];

