﻿CREATE SYNONYM [dbo].[ach_micrs] FOR [dds_prod].[dbo].[ach_micrs];

