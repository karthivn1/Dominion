﻿CREATE SYNONYM [dbo].[capadj_log] FOR [dds_prod].[dbo].[capadj_log];

