﻿CREATE SYNONYM [dbo].[oper_comp_idstck] FOR [dds_prod].[dbo].[oper_comp_idstck];

