﻿CREATE SYNONYM [dbo].[bank_info] FOR [dds_prod].[dbo].[bank_info];

