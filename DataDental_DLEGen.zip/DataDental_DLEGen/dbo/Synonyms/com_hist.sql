﻿CREATE SYNONYM [dbo].[com_hist] FOR [dds_prod].[dbo].[com_hist];

