﻿CREATE SYNONYM [dbo].[gpterm_reason] FOR [dds_prod].[dbo].[gpterm_reason];

