﻿CREATE SYNONYM [dbo].[h_group] FOR [dds_prod].[dbo].[h_group];

