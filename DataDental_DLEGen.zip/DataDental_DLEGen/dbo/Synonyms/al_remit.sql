﻿CREATE SYNONYM [dbo].[al_remit] FOR [dds_prod].[dbo].[al_remit];

