﻿CREATE SYNONYM [dbo].[bl_fee_dtl] FOR [dds_prod].[dbo].[bl_fee_dtl];

