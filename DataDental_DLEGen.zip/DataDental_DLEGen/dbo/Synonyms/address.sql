﻿CREATE SYNONYM [dbo].[address] FOR [dds_prod].[dbo].[address];

