﻿CREATE SYNONYM [dbo].[h_rlmbrt] FOR [dds_prod].[dbo].[h_rlmbrt];

