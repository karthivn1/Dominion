﻿CREATE SYNONYM [dbo].[mbr_phone] FOR [dds_prod].[dbo].[mbr_phone];

