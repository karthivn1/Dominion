﻿CREATE SYNONYM [dbo].[blob_docs] FOR [dds_prod].[dbo].[blob_docs];

