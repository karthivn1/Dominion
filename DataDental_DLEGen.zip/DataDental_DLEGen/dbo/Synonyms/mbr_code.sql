﻿CREATE SYNONYM [dbo].[mbr_code] FOR [dds_prod].[dbo].[mbr_code];

