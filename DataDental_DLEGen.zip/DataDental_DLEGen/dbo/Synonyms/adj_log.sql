﻿CREATE SYNONYM [dbo].[adj_log] FOR [dds_prod].[dbo].[adj_log];

