﻿CREATE SYNONYM [dbo].[fc_audit_chk] FOR [dds_prod].[dbo].[fc_audit_chk];

