﻿CREATE SYNONYM [dbo].[mb_desig] FOR [dds_prod].[dbo].[mb_desig];

