﻿CREATE SYNONYM [dbo].[billstatus] FOR [dds_prod].[dbo].[billstatus];

