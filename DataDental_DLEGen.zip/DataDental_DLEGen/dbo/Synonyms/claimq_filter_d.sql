﻿CREATE SYNONYM [dbo].[claimq_filter_d] FOR [dds_prod].[dbo].[claimq_filter_d];

