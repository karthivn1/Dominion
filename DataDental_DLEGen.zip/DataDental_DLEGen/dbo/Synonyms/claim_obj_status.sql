﻿CREATE SYNONYM [dbo].[claim_obj_status] FOR [dds_prod].[dbo].[claim_obj_status];

