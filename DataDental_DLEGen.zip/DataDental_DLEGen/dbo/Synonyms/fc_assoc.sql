﻿CREATE SYNONYM [dbo].[fc_assoc] FOR [dds_prod].[dbo].[fc_assoc];

