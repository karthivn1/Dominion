﻿CREATE SYNONYM [dbo].[mod_def_win] FOR [dds_prod].[dbo].[mod_def_win];

