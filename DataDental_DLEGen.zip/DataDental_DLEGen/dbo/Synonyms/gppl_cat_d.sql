﻿CREATE SYNONYM [dbo].[gppl_cat_d] FOR [dds_prod].[dbo].[gppl_cat_d];

