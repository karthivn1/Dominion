﻿CREATE SYNONYM [dbo].[group_rules] FOR [dds_prod].[dbo].[group_rules];

