﻿CREATE SYNONYM [dbo].[oper_company] FOR [dds_prod].[dbo].[oper_company];

