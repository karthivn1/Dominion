﻿CREATE SYNONYM [dbo].[date_corr_d] FOR [dds_prod].[dbo].[date_corr_d];

