﻿CREATE SYNONYM [dbo].[blob_checks] FOR [dds_prod].[dbo].[blob_checks];

