﻿CREATE SYNONYM [dbo].[ib_new_grp] FOR [dds_prod].[dbo].[ib_new_grp];

