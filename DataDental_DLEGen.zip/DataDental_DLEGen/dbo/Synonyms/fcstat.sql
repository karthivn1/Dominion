﻿CREATE SYNONYM [dbo].[fcstat] FOR [dds_prod].[dbo].[fcstat];

