﻿CREATE SYNONYM [dbo].[ltr_arglist] FOR [dds_prod].[dbo].[ltr_arglist];

