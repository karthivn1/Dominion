﻿CREATE SYNONYM [dbo].[fc_alert_notes] FOR [dds_prod].[dbo].[fc_alert_notes];

