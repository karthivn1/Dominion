﻿CREATE SYNONYM [dbo].[al_gpayd] FOR [dds_prod].[dbo].[al_gpayd];

