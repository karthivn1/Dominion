﻿CREATE SYNONYM [dbo].[fc_cap] FOR [dds_prod].[dbo].[fc_cap];

