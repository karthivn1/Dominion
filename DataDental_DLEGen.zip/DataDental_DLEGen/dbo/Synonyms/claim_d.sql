﻿CREATE SYNONYM [dbo].[claim_d] FOR [dds_prod].[dbo].[claim_d];

