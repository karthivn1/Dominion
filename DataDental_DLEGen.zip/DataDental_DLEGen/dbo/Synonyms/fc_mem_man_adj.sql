﻿CREATE SYNONYM [dbo].[fc_mem_man_adj] FOR [dds_prod].[dbo].[fc_mem_man_adj];

