﻿CREATE SYNONYM [dbo].[claim_h] FOR [dds_prod].[dbo].[claim_h];

