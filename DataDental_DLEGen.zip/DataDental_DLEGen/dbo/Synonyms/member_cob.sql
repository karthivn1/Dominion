﻿CREATE SYNONYM [dbo].[member_cob] FOR [dds_prod].[dbo].[member_cob];

