﻿CREATE SYNONYM [dbo].[grad_comm_amt] FOR [dds_prod].[dbo].[grad_comm_amt];

