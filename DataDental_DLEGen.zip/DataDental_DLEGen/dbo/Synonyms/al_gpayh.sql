﻿CREATE SYNONYM [dbo].[al_gpayh] FOR [dds_prod].[dbo].[al_gpayh];

