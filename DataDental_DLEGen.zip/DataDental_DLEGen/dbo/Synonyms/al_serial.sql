﻿CREATE SYNONYM [dbo].[al_serial] FOR [dds_prod].[dbo].[al_serial];

