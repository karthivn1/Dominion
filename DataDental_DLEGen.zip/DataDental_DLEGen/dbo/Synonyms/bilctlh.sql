﻿CREATE SYNONYM [dbo].[bilctlh] FOR [dds_prod].[dbo].[bilctlh];

