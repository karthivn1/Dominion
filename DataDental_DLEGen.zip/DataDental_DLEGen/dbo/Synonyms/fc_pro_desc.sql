﻿CREATE SYNONYM [dbo].[fc_pro_desc] FOR [dds_prod].[dbo].[fc_pro_desc];

