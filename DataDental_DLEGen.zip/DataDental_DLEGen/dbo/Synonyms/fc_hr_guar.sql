﻿CREATE SYNONYM [dbo].[fc_hr_guar] FOR [dds_prod].[dbo].[fc_hr_guar];

