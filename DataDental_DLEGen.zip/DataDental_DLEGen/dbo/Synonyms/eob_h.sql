﻿CREATE SYNONYM [dbo].[eob_h] FOR [dds_prod].[dbo].[eob_h];

