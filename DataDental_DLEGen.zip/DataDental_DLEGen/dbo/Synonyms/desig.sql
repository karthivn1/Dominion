﻿CREATE SYNONYM [dbo].[desig] FOR [dds_prod].[dbo].[desig];

