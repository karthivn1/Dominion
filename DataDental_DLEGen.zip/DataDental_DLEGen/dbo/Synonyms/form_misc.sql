﻿CREATE SYNONYM [dbo].[form_misc] FOR [dds_prod].[dbo].[form_misc];

