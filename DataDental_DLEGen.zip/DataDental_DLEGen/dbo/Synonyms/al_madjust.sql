﻿CREATE SYNONYM [dbo].[al_madjust] FOR [dds_prod].[dbo].[al_madjust];

