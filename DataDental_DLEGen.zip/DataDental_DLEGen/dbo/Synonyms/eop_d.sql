﻿CREATE SYNONYM [dbo].[eop_d] FOR [dds_prod].[dbo].[eop_d];

