﻿CREATE SYNONYM [dbo].[desig_type] FOR [dds_prod].[dbo].[desig_type];

