﻿CREATE SYNONYM [dbo].[business_rules] FOR [dds_prod].[dbo].[business_rules];

