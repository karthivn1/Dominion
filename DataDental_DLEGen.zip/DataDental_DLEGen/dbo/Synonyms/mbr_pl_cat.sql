﻿CREATE SYNONYM [dbo].[mbr_pl_cat] FOR [dds_prod].[dbo].[mbr_pl_cat];

