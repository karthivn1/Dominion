﻿CREATE SYNONYM [dbo].[grp_retro_bill_cap] FOR [dds_prod].[dbo].[grp_retro_bill_cap];

