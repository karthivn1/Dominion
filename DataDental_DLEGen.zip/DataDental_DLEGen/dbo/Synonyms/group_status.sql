﻿CREATE SYNONYM [dbo].[group_status] FOR [dds_prod].[dbo].[group_status];

