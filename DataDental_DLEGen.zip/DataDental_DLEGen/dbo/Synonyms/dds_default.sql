﻿CREATE SYNONYM [dbo].[dds_default] FOR [dds_prod].[dbo].[dds_default];

