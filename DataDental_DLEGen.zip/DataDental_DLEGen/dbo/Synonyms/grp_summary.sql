﻿CREATE SYNONYM [dbo].[grp_summary] FOR [dds_prod].[dbo].[grp_summary];

