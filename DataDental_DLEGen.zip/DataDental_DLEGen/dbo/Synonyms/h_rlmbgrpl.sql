﻿CREATE SYNONYM [dbo].[h_rlmbgrpl] FOR [dds_prod].[dbo].[h_rlmbgrpl];

