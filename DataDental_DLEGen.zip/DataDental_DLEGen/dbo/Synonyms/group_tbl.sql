﻿CREATE SYNONYM [dbo].[group_tbl] FOR [dds_prod].[dbo].[group_tbl];

