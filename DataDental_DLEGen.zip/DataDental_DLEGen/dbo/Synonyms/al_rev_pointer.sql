﻿CREATE SYNONYM [dbo].[al_rev_pointer] FOR [dds_prod].[dbo].[al_rev_pointer];

