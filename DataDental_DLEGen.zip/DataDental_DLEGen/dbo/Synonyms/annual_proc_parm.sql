﻿CREATE SYNONYM [dbo].[annual_proc_parm] FOR [dds_prod].[dbo].[annual_proc_parm];

