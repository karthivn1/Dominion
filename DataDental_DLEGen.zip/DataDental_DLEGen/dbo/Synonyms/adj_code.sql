﻿CREATE SYNONYM [dbo].[adj_code] FOR [dds_prod].[dbo].[adj_code];

