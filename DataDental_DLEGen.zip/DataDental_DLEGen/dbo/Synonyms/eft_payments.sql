﻿CREATE SYNONYM [dbo].[eft_payments] FOR [dds_prod].[dbo].[eft_payments];

