﻿CREATE SYNONYM [dbo].[facility] FOR [dds_prod].[dbo].[facility];

