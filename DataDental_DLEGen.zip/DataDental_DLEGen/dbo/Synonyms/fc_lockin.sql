﻿CREATE SYNONYM [dbo].[fc_lockin] FOR [dds_prod].[dbo].[fc_lockin];

