﻿CREATE SYNONYM [dbo].[hcheck_vendor] FOR [dds_prod].[dbo].[hcheck_vendor];

