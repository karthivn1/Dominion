﻿CREATE SYNONYM [dbo].[bl_uniqc] FOR [dds_prod].[dbo].[bl_uniqc];

