﻿CREATE SYNONYM [dbo].[annual_proc] FOR [dds_prod].[dbo].[annual_proc];

