﻿CREATE SYNONYM [dbo].[claim_lists] FOR [dds_prod].[dbo].[claim_lists];

