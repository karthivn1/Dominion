﻿CREATE SYNONYM [dbo].[h_member] FOR [dds_prod].[dbo].[h_member];

