﻿CREATE SYNONYM [dbo].[al_late_fee] FOR [dds_prod].[dbo].[al_late_fee];

