﻿CREATE SYNONYM [dbo].[geo_zip] FOR [dds_prod].[dbo].[geo_zip];

