﻿CREATE SYNONYM [dbo].[fc_mass_xfer_log] FOR [dds_prod].[dbo].[fc_mass_xfer_log];

