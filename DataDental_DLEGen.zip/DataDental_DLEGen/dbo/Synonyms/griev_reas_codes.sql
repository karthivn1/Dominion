﻿CREATE SYNONYM [dbo].[griev_reas_codes] FOR [dds_prod].[dbo].[griev_reas_codes];

