﻿CREATE SYNONYM [dbo].[claim_d_hist] FOR [dds_prod].[dbo].[claim_d_hist];

