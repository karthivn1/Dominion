﻿CREATE SYNONYM [dbo].[fc_group_cap] FOR [dds_prod].[dbo].[fc_group_cap];

