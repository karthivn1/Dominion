﻿CREATE SYNONYM [dbo].[lob] FOR [dds_prod].[dbo].[lob];

