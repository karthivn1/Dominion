﻿CREATE SYNONYM [dbo].[fc_pr] FOR [dds_prod].[dbo].[fc_pr];

