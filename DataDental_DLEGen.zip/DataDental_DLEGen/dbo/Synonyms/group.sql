﻿CREATE SYNONYM [dbo].[group] FOR [dds_prod].[dbo].[group];

