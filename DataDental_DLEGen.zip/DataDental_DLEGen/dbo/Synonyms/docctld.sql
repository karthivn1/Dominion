﻿CREATE SYNONYM [dbo].[docctld] FOR [dds_prod].[dbo].[docctld];

