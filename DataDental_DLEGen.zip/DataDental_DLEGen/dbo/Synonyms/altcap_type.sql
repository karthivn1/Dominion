﻿CREATE SYNONYM [dbo].[altcap_type] FOR [dds_prod].[dbo].[altcap_type];

