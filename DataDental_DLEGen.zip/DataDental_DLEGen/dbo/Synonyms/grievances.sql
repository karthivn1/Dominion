﻿CREATE SYNONYM [dbo].[grievances] FOR [dds_prod].[dbo].[grievances];

