﻿CREATE SYNONYM [dbo].[bill_formats] FOR [dds_prod].[dbo].[bill_formats];

