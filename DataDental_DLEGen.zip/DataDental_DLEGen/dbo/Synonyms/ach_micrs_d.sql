﻿CREATE SYNONYM [dbo].[ach_micrs_d] FOR [dds_prod].[dbo].[ach_micrs_d];

