﻿CREATE SYNONYM [dbo].[com_detail] FOR [dds_prod].[dbo].[com_detail];

