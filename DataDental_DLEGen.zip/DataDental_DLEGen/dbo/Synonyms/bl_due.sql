﻿CREATE SYNONYM [dbo].[bl_due] FOR [dds_prod].[dbo].[bl_due];

