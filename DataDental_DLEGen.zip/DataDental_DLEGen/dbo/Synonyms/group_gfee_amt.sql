﻿CREATE SYNONYM [dbo].[group_gfee_amt] FOR [dds_prod].[dbo].[group_gfee_amt];

