﻿CREATE SYNONYM [dbo].[fee_sched_h] FOR [dds_prod].[dbo].[fee_sched_h];

