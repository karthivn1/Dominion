﻿CREATE SYNONYM [dbo].[cap] FOR [dds_prod].[dbo].[cap];

