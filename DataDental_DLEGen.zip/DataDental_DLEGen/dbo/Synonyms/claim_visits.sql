﻿CREATE SYNONYM [dbo].[claim_visits] FOR [dds_prod].[dbo].[claim_visits];

