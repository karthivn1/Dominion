﻿CREATE SYNONYM [dbo].[pat_tooth_status] FOR [dds_prod].[dbo].[pat_tooth_status];

