﻿CREATE SYNONYM [dbo].[object_queue_hist] FOR [dds_prod].[dbo].[object_queue_hist];

