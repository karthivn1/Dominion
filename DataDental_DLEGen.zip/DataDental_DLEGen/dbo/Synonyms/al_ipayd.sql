﻿CREATE SYNONYM [dbo].[al_ipayd] FOR [dds_prod].[dbo].[al_ipayd];

