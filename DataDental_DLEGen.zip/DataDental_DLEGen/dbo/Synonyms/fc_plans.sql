﻿CREATE SYNONYM [dbo].[fc_plans] FOR [dds_prod].[dbo].[fc_plans];

