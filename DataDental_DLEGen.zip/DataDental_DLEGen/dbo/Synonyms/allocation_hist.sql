﻿CREATE SYNONYM [dbo].[allocation_hist] FOR [dds_prod].[dbo].[allocation_hist];

