﻿CREATE SYNONYM [dbo].[clm_pc_access] FOR [dds_prod].[dbo].[clm_pc_access];

