﻿CREATE SYNONYM [dbo].[object_queue] FOR [dds_prod].[dbo].[object_queue];

