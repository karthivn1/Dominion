﻿CREATE SYNONYM [dbo].[network] FOR [dds_prod].[dbo].[network];

