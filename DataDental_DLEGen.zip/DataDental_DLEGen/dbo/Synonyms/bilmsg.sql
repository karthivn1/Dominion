﻿CREATE SYNONYM [dbo].[bilmsg] FOR [dds_prod].[dbo].[bilmsg];

