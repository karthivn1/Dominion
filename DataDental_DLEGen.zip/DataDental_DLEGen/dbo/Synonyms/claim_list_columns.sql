﻿CREATE SYNONYM [dbo].[claim_list_columns] FOR [dds_prod].[dbo].[claim_list_columns];

