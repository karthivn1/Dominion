﻿CREATE SYNONYM [dbo].[ltr_def] FOR [dds_prod].[dbo].[ltr_def];

