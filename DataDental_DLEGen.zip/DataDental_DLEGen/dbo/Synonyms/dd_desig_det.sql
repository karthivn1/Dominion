﻿CREATE SYNONYM [dbo].[dd_desig_det] FOR [dds_prod].[dbo].[dd_desig_det];

