﻿CREATE SYNONYM [dbo].[net_rep] FOR [dds_prod].[dbo].[net_rep];

