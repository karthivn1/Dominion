﻿CREATE SYNONYM [dbo].[bill_sum] FOR [dds_prod].[dbo].[bill_sum];

