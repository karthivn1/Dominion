﻿CREATE SYNONYM [dbo].[bill_hist] FOR [dds_prod].[dbo].[bill_hist];

