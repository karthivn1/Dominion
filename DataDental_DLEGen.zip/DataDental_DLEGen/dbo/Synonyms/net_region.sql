﻿CREATE SYNONYM [dbo].[net_region] FOR [dds_prod].[dbo].[net_region];

