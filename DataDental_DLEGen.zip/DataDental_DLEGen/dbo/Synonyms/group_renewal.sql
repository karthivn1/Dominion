﻿CREATE SYNONYM [dbo].[group_renewal] FOR [dds_prod].[dbo].[group_renewal];

