﻿CREATE SYNONYM [dbo].[annual_proc_coupon] FOR [dds_prod].[dbo].[annual_proc_coupon];

