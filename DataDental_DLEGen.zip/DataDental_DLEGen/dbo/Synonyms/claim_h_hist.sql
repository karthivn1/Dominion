﻿CREATE SYNONYM [dbo].[claim_h_hist] FOR [dds_prod].[dbo].[claim_h_hist];

