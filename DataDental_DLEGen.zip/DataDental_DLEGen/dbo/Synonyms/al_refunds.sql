﻿CREATE SYNONYM [dbo].[al_refunds] FOR [dds_prod].[dbo].[al_refunds];

