﻿CREATE SYNONYM [dbo].[ach_bill] FOR [dds_prod].[dbo].[ach_bill];

