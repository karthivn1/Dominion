﻿CREATE SYNONYM [dbo].[act_log] FOR [dds_prod].[dbo].[act_log];

