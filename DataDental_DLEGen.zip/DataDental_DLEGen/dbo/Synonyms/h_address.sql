﻿CREATE SYNONYM [dbo].[h_address] FOR [dds_prod].[dbo].[h_address];

