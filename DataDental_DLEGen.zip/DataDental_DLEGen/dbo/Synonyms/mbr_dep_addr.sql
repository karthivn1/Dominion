﻿CREATE SYNONYM [dbo].[mbr_dep_addr] FOR [dds_prod].[dbo].[mbr_dep_addr];

