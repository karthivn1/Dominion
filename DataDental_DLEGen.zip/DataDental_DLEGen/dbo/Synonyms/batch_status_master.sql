﻿CREATE SYNONYM [dbo].[batch_status_master] FOR [dds_prod].[dbo].[batch_status_master];

