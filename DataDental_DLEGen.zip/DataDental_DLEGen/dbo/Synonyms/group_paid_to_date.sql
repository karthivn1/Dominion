﻿CREATE SYNONYM [dbo].[group_paid_to_date] FOR [dds_prod].[dbo].[group_paid_to_date];

