﻿CREATE SYNONYM [dbo].[method] FOR [dds_prod].[dbo].[method];

