﻿CREATE SYNONYM [dbo].[h_bat_rpt] FOR [dds_prod].[dbo].[h_bat_rpt];

