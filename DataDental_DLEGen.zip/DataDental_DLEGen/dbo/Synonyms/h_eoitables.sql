﻿CREATE SYNONYM [dbo].[h_eoitables] FOR [dds_prod].[dbo].[h_eoitables];

