﻿CREATE SYNONYM [dbo].[cap_method] FOR [dds_prod].[dbo].[cap_method];

