﻿CREATE SYNONYM [dbo].[al_rev_serial] FOR [dds_prod].[dbo].[al_rev_serial];

