﻿CREATE SYNONYM [dbo].[ins_opt] FOR [dds_prod].[dbo].[ins_opt];

