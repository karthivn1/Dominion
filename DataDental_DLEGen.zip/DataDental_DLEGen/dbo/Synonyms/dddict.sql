﻿CREATE SYNONYM [dbo].[dddict] FOR [dds_prod].[dbo].[dddict];

