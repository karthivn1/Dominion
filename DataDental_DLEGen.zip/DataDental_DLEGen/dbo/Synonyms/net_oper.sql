﻿CREATE SYNONYM [dbo].[net_oper] FOR [dds_prod].[dbo].[net_oper];

