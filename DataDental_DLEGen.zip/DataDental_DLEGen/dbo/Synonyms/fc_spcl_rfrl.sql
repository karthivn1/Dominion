﻿CREATE SYNONYM [dbo].[fc_spcl_rfrl] FOR [dds_prod].[dbo].[fc_spcl_rfrl];

