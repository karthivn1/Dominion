﻿CREATE SYNONYM [dbo].[ltr_hst] FOR [dds_prod].[dbo].[ltr_hst];

