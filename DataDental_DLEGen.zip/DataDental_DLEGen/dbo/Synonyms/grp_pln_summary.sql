﻿CREATE SYNONYM [dbo].[grp_pln_summary] FOR [dds_prod].[dbo].[grp_pln_summary];

