﻿CREATE SYNONYM [dbo].[contact] FOR [dds_prod].[dbo].[contact];

